// ignore-tidy-filelength Fitxategi hau ia soilik `Iterator` definizioak osatzen du.
// Ezin dugu hori fitxategi anitzetan zatitu.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Iteratzaileekin tratatzeko interfaze bat.
///
/// Hau da trait iteratzaile nagusia.
/// Orokorrean errepikatzaileen kontzeptuari buruzko informazio gehiago nahi izanez gero, ikusi [module-level documentation].
/// Bereziki, [implement `Iterator`][impl] nola jakin jakin nahi duzu.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Errepikatzen diren elementuen mota.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Iteratzailea aurreratzen du eta hurrengo balioa itzultzen du.
    ///
    /// [`None`] itzultzen du errepikapena amaitutakoan.
    /// Iteratzaileen inplementazio indibidualek iterazioari berrekiteko aukera egin dezakete eta, beraz, `next()` berriro deitzeak agian edo noizbait [`Some(Item)`] berriro itzultzen has daiteke.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ra deitzeak hurrengo balioa itzultzen du ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... eta gero Bat ere ez amaitutakoan.
    /// assert_eq!(None, iter.next());
    ///
    /// // Dei gehiagok `None` itzul dezakete edo ez.Hemen, beti egingo dute.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Iteratzailearen gainerako luzeraren mugak itzultzen ditu.
    ///
    /// Zehazki, `size_hint()`-k tupla itzultzen du, non lehenengo elementua beheko muga den eta bigarren elementua goiko muga den.
    ///
    /// Itzultzen den tuplaren bigarren erdia [`Aukera`]`<`[`usize`] `>` da.
    /// Hemen [`None`] batek esan nahi du ez dagoela goiko muga ezagutzen, edo goiko muga [`usize`] baino handiagoa dela.
    ///
    /// # Ezartzeko oharrak
    ///
    /// Ez da aplikatzen iteratzaileen inplementazio batek adierazitako elementu kopurua ematen duenik.Buggy iteratzaile batek elementuen beheko muga baino gutxiago edo gehiago eman dezake.
    ///
    /// `size_hint()` batez ere iteratzailearen elementuei lekua gordetzea bezalako optimizazioetarako erabili nahi da, baina ez da fidagarria, adibidez, kode ez seguruan mugen egiaztapenak kentzea.
    /// `size_hint()` ezartzeak ez luke memoria segurtasun urraketarik ekarri behar.
    ///
    /// Hori bai, inplementazioak zenbatespen zuzena eman beharko luke, bestela trait protokoloaren urraketa litzateke.
    ///
    /// Inplementazio lehenetsiak `(0,` [`Bat ere ez]]`) itzultzen du, hau da, edozein iteratzailerentzat zuzena.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Adibide konplexuagoa:
    ///
    /// ```
    /// // Zerotik hamarra arteko zenbaki bikoitiak.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Baliteke zerotik hamar aldiz errepikatzea.
    /// // Bost zehazki direla jakitea ez litzateke posible filter() exekutatu gabe.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Gehi ditzagun beste bost zenbaki chain()-rekin
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // orain bi mugak bost handitzen dira
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` itzultzen goiko muga baterako:
    ///
    /// ```
    /// // errepikatzaile infinitu batek ez du goiko muga eta beheko muga ahalik eta gehien
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Iteratzailea kontsumitzen du, iterazio kopurua zenbatuz eta itzuliz.
    ///
    /// Metodo honek [`next`] behin eta berriz deituko du [`None`] topatu arte, [`Some`] ikusi duen aldiz itzuliz.
    /// Kontuan izan [`next`] gutxienez behin deitu behar dela, nahiz eta iteratzaileak ez duen elementurik.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Gainezkatze portaera
    ///
    /// Metodoak ez du gainezkatzerik babesten, beraz [`usize::MAX`] elementu baino gehiago dituzten iteratzaile baten elementuak zenbatzeak emaitza okerra edo panics sortzen du.
    ///
    /// Arazketa baieztapenak gaituta badaude, panic ziurtatuta dago.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izan liteke errepikatzaileak [`usize::MAX`] elementu baino gehiago baditu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Iteratzailea kontsumitzen du, azken elementua itzuliz.
    ///
    /// Metodo honek iteratzailea ebaluatuko du [`None`] itzultzen duen arte.
    /// Hori egiten ari den bitartean, uneko elementuaren jarraipena egiten du.
    /// [`None`] itzuli ondoren, `last()`-k ikusi zuen azken elementua itzuliko du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Aurreratzen du errepikatzailea `n` elementuekin.
    ///
    /// Metodo honek `n` elementuak saltatuko ditu gogoz [`next`] `n` bider deituz [`None`] topatu arte.
    ///
    /// `advance_by(n)` [`Ok(())`][Ok] itzuliko du errepikagailuak `n` elementuekin aurrera egiten badu, edo [`Err(k)`][Err] [`None`] aurkitzen bada, non `k` elementuak agortu baino lehen errepikatzen duen elementu kopurua den (hau da, `k`)
    /// iteratzailearen luzera).
    /// Kontuan izan `k` beti `n` baino txikiagoa dela.
    ///
    /// `advance_by(0)` deitzeak ez du inolako elementurik kontsumitzen eta beti [`Ok(())`][Ok] itzultzen du.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` bakarrik saltatu zen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Iteratzailearen `n`th elementua ematen du.
    ///
    /// Indexazio eragiketa gehienetan bezala, zenbaketa zerotik hasten da, beraz, `nth(0)`-k lehen balioa itzultzen du, `nth(1)`-k bigarrena eta abar.
    ///
    /// Kontuan izan aurreko elementu guztiak, baita itzulitako elementua ere, iteratzailetik kontsumituko direla.
    /// Horrek esan nahi du aurreko elementuak baztertu egingo direla eta, gainera, `nth(0)` errepikari berean hainbat aldiz deitzeak elementu desberdinak itzuliko dituela.
    ///
    ///
    /// `nth()` [`None`] itzuliko du `n` iteratzailearen luzera baino handiagoa edo berdina bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` behin baino gehiagotan deitzeak ez du errepikatzailea atzeratzen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None` itzultzea `n + 1` elementuak baino gutxiago badaude:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Iteratzaile bat sortzen du puntu beretik hasita, baina iterazio bakoitzean emandako kantitatearen arabera.
    ///
    /// 1. oharra: iteratzailearen lehen elementua beti itzuliko da, emandako urratsa edozein dela ere.
    ///
    /// 2. oharra: ezikusi diren elementuak tiratzeko unea ez da finkoa.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` sekuentzia bezala jokatzen du, baina sekuentzia bezala jokatzeko doakoa da
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Zenbait modutan erabil daiteke iteratzaile batzuentzat errendimendu arrazoiengatik.
    /// Bigarren bideak iteratzailea aurreratuko du eta elementu gehiago kontsumitzen ditu.
    ///
    /// `advance_n_and_return_first` honen baliokidea da:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metodoa panic izango da emandako urratsa `0` bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Bi iteratzaile hartzen ditu eta iteratzaile berri bat sortzen du bietan sekuentzian.
    ///
    /// `chain()` iteratzaile berri bat itzuliko du, lehenengo iteratzailearen balioak errepikatuko dituena eta gero bigarren iteratzailearen balioak gainetik errepikatuko dituena.
    ///
    /// Beste modu batera esanda, bi iteratzaile lotzen ditu, kate batean.🔗
    ///
    /// [`once`] normalean balio bakarra beste iterazio mota batzuen katean egokitzeko erabiltzen da.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()`-ren argumentuak [`IntoIterator`] erabiltzen duenez, [`Iterator`] bihur daitekeen edozer pasa dezakegu, ez [`Iterator`] bera bakarrik.
    /// Adibidez, (`&[T]`) zatiek [`IntoIterator`] inplementatzen dute eta, beraz, zuzenean `chain()`-ra pasa daitezke:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Windows APIarekin lan egiten baduzu, baliteke [`OsStr`] `Vec<u16>` bihurtzea:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Bi iteratzaile 'zatitu' bikotearen errepikatzaile bakarrean.
    ///
    /// `zip()` beste bi iteratzaile baino gehiagotan errepikatuko duen iteratzaile berria itzultzen du, lehen elementua lehenengo iteratzailetik datorren eta bigarren elementua bigarren iteratzailetik datorren tupla itzuliz.
    ///
    ///
    /// Beste modu batera esanda, bi iteratzaile zatitzen ditu, bakarrean.
    ///
    /// Iteratzaile batek [`None`] itzultzen badu, [`next`] konprimitutako iteratzailetik [`None`] itzuliko da.
    /// Lehenengo iteratzaileak [`None`] itzultzen badu, `zip` zirkuitulaburtu egingo da eta `next` ez da bigarren iteratzailean deituko.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()`-ren argumentuak [`IntoIterator`] erabiltzen duenez, [`Iterator`] bihur daitekeen edozer pasa dezakegu, ez [`Iterator`] bera bakarrik.
    /// Adibidez, (`&[T]`) zatiek [`IntoIterator`] inplementatzen dute eta, beraz, zuzenean `zip()`-ra pasa daitezke:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` sarritan erabiltzen da iteratzaile infinitu bat finitu batera konprimitzeko.
    /// Honek funtzionatzen du, iteratzaile finituak azkenean [`None`] itzuliko duelako, kremailera amaituz.`(0..)`-rekin konprimitzeak [`enumerate`]-ren antza izan dezake:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Iteratzaile berria sortzen du, `separator` ren kopia jatorrizko iteratzailearen ondoko elementuen artean kokatzen duena.
    ///
    /// `separator`-k [`Clone`] inplementatzen ez badu edo kalkulatu behar duen bakoitzean, erabili [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a`-ren lehen elementua.
    /// assert_eq!(a.next(), Some(&100)); // Bereizlea.
    /// assert_eq!(a.next(), Some(&1));   // `a`-ren hurrengo elementua.
    /// assert_eq!(a.next(), Some(&100)); // Bereizlea.
    /// assert_eq!(a.next(), Some(&2));   // `a`-ren azken elementua.
    /// assert_eq!(a.next(), None);       // Iteratzailea amaitu da.
    /// ```
    ///
    /// `intersperse` oso erabilgarria izan daiteke elementu komun bat erabiliz iteratzaile baten elementuak elkartzeko:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator`-ek sortutako elementua jatorrizko iteratzailearen ondoko elementuen artean kokatzen duen iteratzaile berria sortzen du.
    ///
    /// Itxiera zehazki deituko da elementu bat azpiko iteratzailetik aldameneko bi elementuren artean jartzen den bakoitzean;
    /// zehazki, itxiera ez da deitzen azpiko iteratzaileak bi elementu baino gutxiago ematen baditu eta azken elementua eman ondoren.
    ///
    ///
    /// Iteratzailearen elementuak [`Clone`] inplementatzen badu, errazagoa izango da [`intersperse`] erabiltzea.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v`-ren lehen elementua.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Bereizlea.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v`-ren hurrengo elementua.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Bereizlea.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v`-ren azken elementua.
    /// assert_eq!(it.next(), None);               // Iteratzailea amaitu da.
    /// ```
    ///
    /// `intersperse_with` bereizlea kalkulatu behar den egoeretan erabil daiteke:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Itxierak modu aldakorrean bere testuingurua maileguan hartzen du elementu bat sortzeko.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Itxiera hartu eta iteratzaile bat sortzen du elementu bakoitzari itxiera horri deitzen diona.
    ///
    /// `map()` iteratzaile bat beste bihurtzen du, bere argumentuaren bidez:
    /// [`FnMut`] inplementatzen duen zerbait.Iteratzaile berri bat sortzen du, itxiera horri jatorrizko iteratzailearen elementu bakoitzari deitzen diona.
    ///
    /// Tipotan pentsatzen trebea bazara, honela pentsa dezakezu `map()`:
    /// `A` motako elementuak ematen dituen iteratzailea baduzu eta beste `B` motako iteratzailea nahi baduzu, `map()` erabil dezakezu, `A` hartzen duen eta `B` bat itzultzen duen itxiera bat pasatuz.
    ///
    ///
    /// `map()` kontzeptualki [`for`] begizta baten antzekoa da.Hala ere, `map()` alferra denez, beste iteratzaile batzuekin lanean ari zarenean erabiltzen da.
    /// Bigarren mailako efektu bat lortzeko looping moduko bat egiten ari bazara, idiomatikotzat jotzen da [`for`] erabiltzea `map()` baino.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bigarren mailako efektuen bat egiten ari bazara, nahiago [`for`] `map()` baino:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ez egin hau:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ez du exekutatuko ere, alferra baita.Rust-k honen inguruan ohartaraziko zaitu.
    ///
    /// // Horren ordez, erabili honetarako:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Iteratzaile baten elementu bakoitzari itxiera deitzen dio.
    ///
    /// Iteratzailean [`for`] begizta erabiltzearen baliokidea da, itxiera batetik `break` eta `continue` ezin diren arren.
    /// `for` begizta erabiltzea idiomatikoagoa da normalean, baina `for_each` irakurgarriagoa izan daiteke iteratzaile-kate luzeagoen amaieran elementuak prozesatzean.
    ///
    /// Zenbait kasutan `for_each` ere begizta bat baino azkarragoa izan daiteke, barne iterazioa erabiliko baitu `Chain` bezalako egokitzaileetan.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Adibide txiki horren kasuan, `for` begizta garbiagoa izan daiteke, baina `for_each` hobe daiteke estilo funtzionala iteratzaile luzeagoekin mantentzea:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Elementu bat eman behar den zehazteko itxiera bat erabiltzen duen iteratzailea sortzen du.
    ///
    /// Elementu bat emanda itxierak `true` edo `false` itzuli behar du.Itzultzaile itzultzaileak itxiera egiazko bihurtzen duten elementuak bakarrik emango ditu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()`-era pasatutako itxierak erreferentzia bat hartzen duenez, eta iteratzaile askok erreferentziak errepikatzen dituztenez, egoera nahasgarria izan daiteke, itxiera mota erreferentzia bikoitza baita:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // bi * behar dituzu!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ohikoa da argumentuan desestructurazioa erabiltzea bat kentzeko:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // biak&eta *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// edo biak:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // bi &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// geruza horien.
    ///
    /// Kontuan izan `iter.filter(f).next()` `iter.find(f)` ren baliokidea dela.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Iragazkiak eta mapak dituen iteratzailea sortzen du.
    ///
    /// Itzulitako errepikatzaileak emandako itxierak `Some(value)` itzultzen duen `balioa` bakarrik ematen du.
    ///
    /// `filter_map` [`filter`] eta [`map`] kateak zehatzagoak izan daitezen erabil daiteke.
    /// Beheko adibidean `map().filter().map()` `filter_map` ra dei bakar batera nola laburtu daitekeen erakusten da.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hona hemen adibide bera, baina [`filter`] eta [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Uneko iterazio kopurua eta hurrengo balioa ematen duen iteratzailea sortzen du.
    ///
    /// Iteratzaileak itzultzen ditu `(i, val)` bikoteak, non `i` uneko iterazioaren indizea den eta `val` iteratzaileak itzultzen duen balioa.
    ///
    ///
    /// `enumerate()` [`usize`] gisa kontatzen du.
    /// Tamaina ezberdineko zenbaki oso batekin zenbatu nahi baduzu, [`zip`] funtzioak antzeko funtzionalitatea eskaintzen du.
    ///
    /// # Gainezkatze portaera
    ///
    /// Metodoak ez du gainezkatzerik babesten, beraz [`usize::MAX`] elementu baino gehiago zenbatuz gero emaitza okerra edo panics sortzen da.
    /// Arazketa baieztapenak gaituta badaude, panic ziurtatuta dago.
    ///
    /// # Panics
    ///
    /// Itzulitako errepikatzaileak panic liteke itzuliko den indizeak [`usize`] gainezka egingo balu.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] erabil dezakeen errepikagailu bat sortzen du iteratzailearen hurrengo elementua kontsumitu gabe begiratzeko.
    ///
    /// [`peek`] metodo bat gehitzen du iteratzaile bati.Informazio gehiagorako ikusi bere dokumentazioa.
    ///
    /// Kontuan izan azpiko iteratzailea oraindik aurreratuta dagoela [`peek`] lehen aldiz deitzen denean: hurrengo elementua berreskuratzeko, [`next`] azpiko iteratzaileari deitzen zaio, beraz, bigarren mailako efektuak (hau da,
    ///
    /// [`next`] metodoaren hurrengo balioa lortzeaz gain beste ezer gertatuko da.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future-ra sartzen uzten digu
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peek() hainbat aldiz egin dezakegu, iteratzaileak ez du aurrera egingo
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // iteratzailea amaitu ondoren, peek() ere bada
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Predikatu batean oinarritutako elementuak [`saltatu '] dituen errepikatzailea sortzen du.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` itxiera hartzen du argumentu gisa.Itxigailuaren elementu bakoitzari itxiera horri deituko dio, eta elementuak baztertuko ditu `false` itzultzen duen arte.
    ///
    /// `false` itzuli ondoren, `skip_while()`'s lana amaitu da, eta gainerako elementuak ematen dira.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()`-era pasatutako itxierak erreferentzia bat hartzen duenez, eta iteratzaile askok erreferentziak errepikatzen dituztenez, egoera nahasgarria izan daiteke, itxiera argumentuaren mota erreferentzia bikoitza baita:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // bi * behar dituzu!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hasierako `false` baten ondoren gelditzea:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // hau faltsua izango zen arren, dagoeneko faltsua lortu genuenez, skip_while() ez da gehiago erabiltzen
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Predikatu batean oinarritutako elementuak ematen dituen iteratzailea sortzen du.
    ///
    /// `take_while()` itxiera hartzen du argumentu gisa.Itxigailuaren elementu bakoitzari itxiera horri deituko dio, eta elementuak emango ditu `true` itzultzen duen bitartean.
    ///
    /// `false` itzuli ondoren, `take_while()`'s lana amaitu da, eta gainerako elementuak ez dira kontuan hartzen.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()`-era pasatutako itxierak erreferentzia bat hartzen duenez, eta iteratzaile askok erreferentziak errepikatzen dituztenez, egoera nahasgarria izan daiteke, itxiera mota erreferentzia bikoitza baita:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // bi * behar dituzu!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hasierako `false` baten ondoren gelditzea:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Zero baino gutxiago diren elementu gehiago ditugu, baina dagoeneko faltsua lortu dugunez, take_while() ez da gehiago erabiltzen
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()`-k balioa aztertu behar duenez, sartu behar den edo ez ikusteko, iteratzaileek kontsumitzen dutenean kentzen dela ikusiko dute:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ez dago jada, kontsumitu egin baitzen errepikapena gelditu behar zen ikusteko, baina ez zen berriro iteratzailean sartu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Bi predikatu eta mapetan oinarritutako elementuak ematen dituen iteratzailea sortzen du.
    ///
    /// `map_while()` itxiera hartzen du argumentu gisa.
    /// Itxigailuaren elementu bakoitzari itxiera horri deituko dio, eta elementuak emango ditu [`Some(_)`][`Some`] itzultzen duen bitartean.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hona hemen adibide bera, baina [`take_while`] eta [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hasierako [`None`] baten ondoren gelditzea:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32-n (4, 5) sar litezkeen elementu gehiago ditugu, baina `map_while`-ek `None`-era itzuli du `-3`-rentzat (`predicate`-k `None`-a itzuli duenez) eta `collect`-ek topatutako lehen `None`-ean gelditzen da.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()`-k balioa aztertu behar duenez, sartu behar den edo ez ikusteko, iteratzaileek kontsumitzen dutenean kentzen dela ikusiko dute:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ez dago jada, kontsumitu egin baitzen errepikapena gelditu behar zen ikusteko, baina ez zen berriro iteratzailean sartu.
    ///
    /// Kontuan izan [`take_while`] ez bezala iteratzaile hau **ez dela** bateratua.
    /// Ez da zehazten zer itzultzaile hau itzultzen duen lehen [`None`] itzuli ondoren.
    /// Fusionatutako iteratzailea behar baduzu, erabili [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Lehen `n` elementuak saltzen dituen errepikagailua sortzen du.
    ///
    /// Kontsumitu ondoren, gainerako elementuak ematen dira.
    /// Metodo hau zuzenean gainidatzi beharrean, ordeztu `nth` metodoa.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Bere lehen `n` elementuak ematen dituen iteratzailea sortzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` askotan iteratzaile infinituarekin erabiltzen da, finitua bihurtzeko:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` elementuak baino gutxiago badaude, `take` azpiko iteratzailearen tamainara mugatuko da:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Barruko egoera mantentzen duen eta iteratzaile berria sortzen duen [`fold`] ren antzeko iteratzaile egokitzailea.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` bi argumentu hartzen ditu: barne-egoera hazten duen hasierako balioa, eta itxiera bi argumenturekin, lehenengoa barne-egoerari buruzko erreferentzia aldagarria da eta bigarrena elementu iteratzailea.
    ///
    /// Itxierak barneko egoerari esleitu die iterazioen arteko egoera partekatzeko.
    ///
    /// Errepikapenean, itxiera iteratzailearen elementu bakoitzari aplikatuko zaio eta iteratzailearen itxieraren itzulerako balioa, [`Option`] bat, emango du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // errepikapen bakoitzean, egoera elementuarekin biderkatuko dugu
    ///     *state = *state * x;
    ///
    ///     // orduan, estatuaren ukazioa emango dugu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Mapak bezala funtzionatzen duen baina habiaratutako egitura berdindu egiten duen iteratzailea sortzen du.
    ///
    /// [`map`] egokitzailea oso erabilgarria da, baina itxiera argumentuak balioak sortzen dituenean bakarrik.
    /// Horren ordez, iteratzailea sortzen badu, ez dago indirekzio geruza gehigarririk.
    /// `flat_map()` geruza estra hau bere kabuz kenduko du.
    ///
    /// `flat_map(f)` pentsa dezakezu [`map`] ping-en baliokide semantikoa dela, eta gero [`berdindu`] `map(f).flatten()`-n bezala.
    ///
    /// `flat_map()`-ri buruz pentsatzeko beste modu bat: [`map`]-en itxierak elementu bakoitzeko elementu bat itzultzen du eta `flat_map()`'s-ren itxierak iteratzaile bat elementu bakoitzerako.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratzaile bat itzultzen du
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Habia egitura berdintzen duen iteratzailea sortzen du.
    ///
    /// Hau erabilgarria da iteratzaileen errepikatzaile bat edo iteratzaile bihur daitezkeen gauzen errepikatzaile bat duzunean eta indirekzio maila bat kendu nahi duzunean.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartografia eta gero berdintzea:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratzaile bat itzultzen du
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// [`flat_map()`]-ren arabera ere berridatzi dezakezu, kasu honetan hobe baita asmoa argiago adierazten duelako:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratzaile bat itzultzen du
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Lautzearekin batera habia egiteko maila bat bakarrik kentzen da:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hemen ikusiko dugu `flatten()`-k ez duela "deep" berdindu egiten.
    /// Horren ordez, habia egiteko maila bakarra kentzen da.Hau da, hiru dimentsiotako matrizea `flatten()` bada, emaitza bi dimentsiotakoa izango da eta ez dimentsio bakarra.
    /// Dimentsio bakarreko egitura lortzeko, `flatten()` berriro egin behar duzu.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Lehen [`None`] ondoren amaitzen den iteratzailea sortzen du.
    ///
    /// Iteratzaile batek [`None`] itzultzen duenean, future deiek [`Some(T)`] berriro eman dezakete edo ez.
    /// `fuse()` iteratzailea egokitzen du, [`None`] bat eman ondoren [`None`] betiko itzuliko duela ziurtatuz.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // Batzuk eta Bat ere ez tartekatzen dituen iteratzailea
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // bikoitia bada, Some(i32), bestela Bat ere ez
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // gure iteratzailea aurrera eta atzera doala ikus dezakegu
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // hala ere, behin fusionatuta ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // beti itzuliko da `None` lehen aldiz.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Iteratzaile baten elementu bakoitzarekin zerbait egiten du, balioa pasatuz.
    ///
    /// Iteratzaileak erabiltzen dituzunean, askotan haietako batzuk kateatzen dituzu.
    /// Kode hori lantzen ari zaren bitartean, baliteke kanalizazioko hainbat ataletan gertatzen ari denaren berri izatea.Horretarako, sartu deia `inspect()` telefonora.
    ///
    /// Ohikoagoa da `inspect()` arazketa tresna gisa erabiltzea zure azken kodean egotea baino, baina aplikazioek erabilgarria izan daiteke zenbait egoeratan akatsak baztertu aurretik erregistratu behar direnean.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // iteratzaile sekuentzia hau konplexua da.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // gehi ditzagun inspect() dei batzuk gertatzen ari dena ikertzeko
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Honek inprimatuko ditu:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Erregistro akatsak baztertu aurretik:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Honek inprimatuko ditu:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Iteratzaile bat maileguan hartzen du kontsumitu beharrean.
    ///
    /// Hau erabilgarria da iteratzaile egokitzaileak aplikatzea jatorrizko iteratzailearen jabetza mantenduz.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // berriro erabiltzen saiatzen bagara, ez du funtzionatuko.
    /// // Ondorengo lerroak "errorea ematen du: mugitutako balioa erabiltzea: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // saia gaitezen berriro
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // horren ordez, .by_ref() batean gehitzen dugu
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // orain ondo dago:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Iteratzailea bilduma bihurtzen du.
    ///
    /// `collect()` errepika daitekeen edozer har dezake eta dagokion bilduma bihur dezake.
    /// Liburutegi estandarraren metodo indartsuenetako bat da hau, hainbat testuingurutan erabiltzen dena.
    ///
    /// `collect()` erabiltzen den eredurik oinarrizkoena bilduma bat beste bihurtzea da.
    /// Bilduma bat hartu, [`iter`] deitu, transformazio pila bat egin eta amaieran `collect()`.
    ///
    /// `collect()` bilduma tipikoak ez diren moten kasuak sor ditzake.
    /// Adibidez, [`char`] s-tik [`String`] eraiki daiteke, eta [`Result<T, E>`][`Result`] elementuen errepikatzailea `Result<Collection<T>, E>`-ra bildu daiteke.
    ///
    /// Ikus beheko adibideak gehiago lortzeko.
    ///
    /// `collect()` oso orokorra denez, motak ondorioztatzeko arazoak sor ditzake.
    /// Honela, `collect()` da 'turbofish' izenarekin ezagutzen den sintaxia maitasunez ikusiko duzun bakanetako bat: `::<>`.
    /// Honek inferentzia algoritmoari zein bilduma biltzen saiatzen ari zaren zehazki ulertzen laguntzen dio.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Kontuan izan ezkerreko aldean `: Vec<i32>` behar genuela.Hau da, adibidez, [`VecDeque<T>`] batean bildu genezakeela:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// 'turbofish' erabiltzea `doubled` ohartarazi beharrean:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()`-k biltzen ari zarenaz soilik arduratzen denez, `_` motako aholku partziala erabil dezakezu turbofish-arekin:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` erabiliz [`String`] bat egiteko:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// [`Emaitza<T, E>`][`Emaitza`] s, `collect()` erabil dezakezu horietako batek huts egin duen ikusteko:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // lehen akatsa ematen digu
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // erantzunen zerrenda ematen digu
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Iteratzaile bat kontsumitzen du, hortik bi bilduma sortuz.
    ///
    /// `partition()`-era pasatutako predikatuak `true` edo `false` itzul dezake.
    /// `partition()` bikotea itzultzen du, `true` itzuli duen elementu guztiak eta `false` itzuli dituen elementu guztiak.
    ///
    ///
    /// Ikus [`is_partitioned()`] eta [`partition_in_place()`] ere.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Iteratzaile honen elementuak *bere lekuan* berrordenatzen ditu emandako predikatuaren arabera, hala nola `true` itzultzen duten guztiak `false` itzultzen duten guztien aurretik doazela.
    ///
    /// Aurkitutako `true` elementu kopurua ematen du.
    ///
    /// Partizionatutako elementuen ordena erlatiboa ez da mantentzen.
    ///
    /// Ikus [`is_partitioned()`] eta [`partition()`] ere.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Zatiketa berdinketen eta probabilitateen artean
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kezkatu behar al dugu zenbaketa gainezka egiteagatik?Baino gehiago izateko modu bakarra
        // `usize::MAX` alda daitezkeen erreferentziak partizio egiteko baliagarriak ez diren ZSTekin daude.

        // Ixteko "factory" funtzio hauek `Self`-en generikotasuna ekiditeko daude.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Behin eta berriz aurkitu lehenengo `false` eta trukatu azken `true` arekin.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Egiaztatu iteratzaile honen elementuak emandako predikatuaren arabera banatuta dauden, hala nola `true` itzultzen duten guztiak `false` itzultzen duten guztien aurretik doazela.
    ///
    ///
    /// Ikus [`partition()`] eta [`partition_in_place()`] ere.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Edo elementu guztiek `true` probatzen dute, edo lehen klausula `false`-n gelditzen da eta ondoren `true` elementu gehiago ez daudela egiaztatzen dugu.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Funtzio bat arrakastaz itzultzen den bitartean aplikatzen duen metodo errepikatzailea, azken balio bakarra sortuz.
    ///
    /// `try_fold()` bi argumentu hartzen ditu: hasierako balioa eta itxiera bi argumenturekin: 'accumulator' bat eta elementu bat.
    /// Itxiera arrakastaz itzultzen da, metagailuak hurrengo iteraziorako izan beharko lukeen balioarekin, edo huts egingo du, deitzaileari (short-circuiting) berehala hedatzen zaion errore-balioarekin.
    ///
    ///
    /// Hasierako balioa metagailuak lehen deian izango duen balioa da.Itxiera aplikatzeak iteratzailearen elementu guztien aurka egiten badu, `try_fold()`-k azken metagailua itzultzen du arrakasta gisa.
    ///
    /// Tolestea erabilgarria da zerbaiten bilduma duzunean eta hortik balio bakarra sortu nahi baduzu.
    ///
    /// # Inplementatzaileentzako oharra
    ///
    /// Beste (forward) metodo batzuek lehenetsitako inplementazioak dituzte honi dagokionez, beraz saiatu hau esplizituki ezartzen `for` begizta inplementazio lehenetsia baino zerbait hobea egin dezakeenean.
    ///
    /// Bereziki, saiatu errepikatzaile hau osatzen duten barne zatietan `try_fold()` dei hau izaten.
    /// Hainbat dei behar izanez gero, `?` operadorea komenigarria izan daiteke metagailuaren balioa kateatzeko, baina kontuz hasierako itzulera horiek egin aurretik mantendu behar diren aldaezinak.
    /// Hau `&mut self` metodoa da, beraz, iterazioa berriro hasi behar da hemen errore bat sakatu ondoren.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // array-aren elementu guztien batura egiaztatua
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Batuketa hori gainezka egiten du 100 elementua gehitzean
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Zirkuitulaburra egin duelako, gainerako elementuak iteratzailearen bidez eskuragarri daude oraindik.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratzailearen elementu bakoitzari funtzio erorikoa aplikatzen dion iteratzaile-metodoa, lehenengo errorean gelditu eta errore hori itzultzen duena.
    ///
    ///
    /// Hau ere pentsa daiteke [`for_each()`]-ren forma erorkorra dela edo [`try_fold()`]-en estaturik gabeko bertsioa dela.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Zirkuitulaburra izan du, beraz, gainerako elementuak iteratzailean daude oraindik:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Elementu guztiak metagailu batean tolesten ditu eragiketa bat eginez, azken emaitza itzuliz.
    ///
    /// `fold()` bi argumentu hartzen ditu: hasierako balioa eta itxiera bi argumenturekin: 'accumulator' bat eta elementu bat.
    /// Itxierak metagailuak hurrengo iteraziorako izan beharko lukeen balioa itzultzen du.
    ///
    /// Hasierako balioa metagailuak lehen deian izango duen balioa da.
    ///
    /// Itxigailuaren elementu guztiei itxiera hori aplikatu ondoren, `fold()`-k metagailua itzultzen du.
    ///
    /// Eragiketa horri batzuetan 'reduce' edo 'inject' deitzen zaio.
    ///
    /// Tolestea erabilgarria da zerbaiten bilduma duzunean eta hortik balio bakarra sortu nahi baduzu.
    ///
    /// Note: `fold()`, eta iteratzaile osoa zeharkatzen duten antzeko metodoak, agian ez dira amaituko iteratzaile infinituentzat, nahiz eta traits-n emaitza hori denbora mugatuan zehaztu daitekeen.
    ///
    /// Note: [`reduce()`] erabil daiteke lehen elementua hasierako balio gisa erabiltzeko, metagailu mota eta elementu mota berdina bada.
    ///
    /// # Inplementatzaileentzako oharra
    ///
    /// Beste (forward) metodo batzuek lehenetsitako inplementazioak dituzte honi dagokionez, beraz saiatu hau esplizituki ezartzen `for` begizta inplementazio lehenetsia baino zerbait hobea egin dezakeenean.
    ///
    ///
    /// Bereziki, saiatu errepikatzaile hau osatzen duten barne zatietan `fold()` dei hau izaten.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // array-aren elementu guztien batura
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ikus dezagun errepikapenaren urrats bakoitza hemen:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Eta horrela, gure azken emaitza, `6`.
    ///
    /// Iteratzaileak asko erabili ez dituzten pertsonek ohikoa da emaitza bat lortzeko gauza zerrenda batekin `for` begizta erabiltzea.Horiek `fold()`s bihur daitezke:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // begizta:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // berdinak dira
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Elementuak bakar batera murrizten ditu, murrizteko eragiketa behin eta berriz aplikatuz.
    ///
    /// Iteratzailea hutsik badago, [`None`] itzultzen du;bestela, murrizketaren emaitza itzultzen du.
    ///
    /// Gutxienez elementu bat duten iteratzaileentzat, hau [`fold()`] ren berdina da iteratzailearen lehen elementua hasierako balio gisa, ondorengo elementu guztiak bertan tolestuz.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Bilatu gehienezko balioa:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Iteratzailearen elementu bakoitza predikatu batekin bat datorren probatzen du.
    ///
    /// `all()` `true` edo `false` itzultzen duen itxiera hartzen du.Itxigailuaren elementu bakoitzari itxiera hau aplikatzen dio eta denek `true` itzultzen badute, `all()`-k ere egiten du.
    /// Horietako batek `false` itzultzen badu, `false` itzultzen du.
    ///
    /// `all()` zirkuitulaburra da;beste era batera esanda, `false` bat aurkitu bezain laster prozesatzeari utziko dio, zer gertatzen den gertatzen dela ere, emaitza `false` ere izango dela.
    ///
    ///
    /// Iteratzaile huts batek `true` itzultzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Lehenengo `false` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Iteratzailearen elementuren bat predikatu batekin bat datorren probatzen du.
    ///
    /// `any()` `true` edo `false` itzultzen duen itxiera hartzen du.Itxiera hau iteratzailearen elementu bakoitzari aplikatzen dio eta horietako batek `true` itzultzen badu, `any()`-k ere egiten du.
    /// Denek `false` itzultzen badute, `false` itzultzen du.
    ///
    /// `any()` zirkuitulaburra da;beste era batera esanda, `true` bat aurkitu bezain laster prozesatzeari utziko dio, zer gertatzen den gertatzen dela ere, emaitza `true` ere izango dela.
    ///
    ///
    /// Iteratzaile huts batek `false` itzultzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Lehenengo `true` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Predikatu bat betetzen duen iteratzaile baten elementua bilatzen du.
    ///
    /// `find()` `true` edo `false` itzultzen duen itxiera hartzen du.
    /// Itxiera elementu bakoitzari itxiera hori aplikatzen dio eta horietako batek `true` itzultzen badu, `find()`-k [`Some(element)`] itzultzen du.
    /// Denek `false` itzultzen badute, [`None`] itzultzen du.
    ///
    /// `find()` zirkuitulaburra da;beste era batera esanda, itxierak `true` itzultzen duen bezain laster prozesatzeari utziko dio.
    ///
    /// `find()`-k erreferentzia bat hartzen baitu, eta iteratzaile askok erreferentzien gainetik errepikatzen dutenez, egoera nahasgarria izan daiteke, argumentua erreferentzia bikoitza baita.
    ///
    /// Efektu hau beheko adibideetan ikus dezakezu, `&&x`-rekin.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Lehenengo `true` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Kontuan izan `iter.find(f)` `iter.filter(f).next()` ren baliokidea dela.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Funtzioa iteratzailearen elementuei aplikatzen die eta bat ere ez den lehen emaitza ematen du.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()`-ren baliokidea da.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Funtzioa iteratzailearen elementuei aplikatzen die eta lehen benetako emaitza edo lehen errorea itzultzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Elementu bat bilatzen du iteratzaile batean, bere aurkibidea itzuliz.
    ///
    /// `position()` `true` edo `false` itzultzen duen itxiera hartzen du.
    /// Itxiera hau iteratzailearen elementu bakoitzari aplikatzen dio eta haietako batek `true` itzultzen badu, `position()`-k [`Some(index)`] itzultzen du.
    /// Horiek guztiek `false` itzultzen badute, [`None`] itzultzen du.
    ///
    /// `position()` zirkuitulaburra da;beste era batera esanda, `true` aurkitu bezain laster prozesatzeari utziko dio.
    ///
    /// # Gainezkatze portaera
    ///
    /// Metodoak ez du gainezkatzeen aurkako babesik egiten, beraz, bat ez datozen [`usize::MAX`] elementu baino gehiago badaude, emaitza okerra edo panics sortzen du.
    ///
    /// Arazketa baieztapenak gaituta badaude, panic ziurtatuta dago.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izan liteke iteratzaileak bat ez datozen `usize::MAX` elementu baino gehiago baditu.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Lehenengo `true` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Itzulitako indizea iteratzailearen egoeraren araberakoa da
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Eskuinetik iteratzaile batean elementu bat bilatzen du, aurkibidea itzuliz.
    ///
    /// `rposition()` `true` edo `false` itzultzen duen itxiera hartzen du.
    /// Itxigailuaren elementu bakoitzari itxiera hori aplikatzen dio, amaieratik hasita, eta horietako batek `true` itzultzen badu, `rposition()`-k [`Some(index)`] itzultzen du.
    ///
    /// Horiek guztiek `false` itzultzen badute, [`None`] itzultzen du.
    ///
    /// `rposition()` zirkuitulaburra da;beste era batera esanda, `true` aurkitu bezain laster prozesatzeari utziko dio.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Lehenengo `true` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Hemen ez da gainezkatzerik egin behar, `ExactSizeIterator`-k esan nahi baitu elementu kopurua `usize` batean sartzen dela.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Iteratzaile baten gehieneko elementua itzultzen du.
    ///
    /// Hainbat elementu berdinak badira, azken elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Iteratzaile baten gutxieneko elementua itzultzen du.
    ///
    /// Hainbat elementu berdinak badira, lehenengo elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Zehaztutako funtziotik gehienezko balioa ematen duen elementua itzultzen du.
    ///
    ///
    /// Hainbat elementu berdinak badira, azken elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Zehaztutako konparazio funtzioarekiko balio maximoa ematen duen elementua itzultzen du.
    ///
    ///
    /// Hainbat elementu berdinak badira, azken elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Zehaztutako funtziotik gutxieneko balioa ematen duen elementua itzultzen du.
    ///
    ///
    /// Hainbat elementu berdinak badira, lehenengo elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Zehaztutako konparazio funtzioarekiko gutxieneko balioa ematen duen elementua itzultzen du.
    ///
    ///
    /// Hainbat elementu berdinak badira, lehenengo elementua itzultzen da.
    /// Iteratzailea hutsik badago, [`None`] itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Iteratzailearen norabidea alderantzikatzen du.
    ///
    /// Normalean, iteratzaileek ezkerretik eskuinera errepikatzen dute.
    /// `rev()` erabili ondoren, iteratzaile batek eskuinetik ezkerrera errepikatuko du.
    ///
    /// Hau posible da errepikatzaileak amaiera badu, beraz, `rev()`-k [`DoubleEndedIterator`] s-en soilik funtzionatzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Bikoteen errepikatzailea edukiontzi pare bihurtzen du.
    ///
    /// `unzip()` bikotearen errepikatzaile oso bat kontsumitzen du, bi bilduma sortuz: bata bikoteen ezkerreko elementuetatik eta bestea eskuineko elementuetatik.
    ///
    ///
    /// Funtzio hori, nolabait, [`zip`]-ren aurkakoa da.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Bere elementu guztiak kopiatzen dituen iteratzailea sortzen du.
    ///
    /// Hau erabilgarria da `&T` baino gehiagoko errepikagailua duzunean, baina `T` baino gehiagoko errepikatzailea behar duzu.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopiatua .map(|&x| x) bezalakoa da
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// [`Klona`] bere elementu guztiak biltzen dituen iteratzailea sortzen du.
    ///
    /// Hau erabilgarria da `&T` baino gehiagoko errepikagailua duzunean, baina `T` baino gehiagoko errepikatzailea behar duzu.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonatua .map(|&x| x) bezalakoa da, zenbaki osoetarako
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Iteratzaile bat errepikatzen du etengabe.
    ///
    /// [`None`]-en gelditu beharrean, iteratzailea berriro hasiko da hasieratik.Berriro errepikatu ondoren, berriro hasieran hasiko da.Eta berriro ere.
    /// Eta berriro ere.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Iteratzaile baten elementuak batu ditu.
    ///
    /// Elementu bakoitza hartu, elkarrekin gehitu eta emaitza itzultzen du.
    ///
    /// Iteratzaile huts batek motaren zero balioa itzultzen du.
    ///
    /// # Panics
    ///
    /// `sum()` deitzerakoan eta zenbaki oso primitibo bat itzultzerakoan, metodo hau panic egingo da konputazio gainezkapenak eta arazketa baieztapenak gaituta badaude.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteratzaile osoa errepikatzen du, elementu guztiak biderkatuz
    ///
    /// Iteratzaile huts batek motaren balio bakarra itzultzen du.
    ///
    /// # Panics
    ///
    /// `product()` deitzerakoan eta zenbaki oso primitibo bat itzultzen denean, metodoak panic egingo du kalkulu gainezkapenak eta arazketa baieztapenak gaituta badaude.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] honen elementuak beste batekin alderatzen ditu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] honen elementuak beste batekin alderatzen ditu zehaztutako konparazio funtzioarekiko.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] honen elementuak beste batekin alderatzen ditu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) [`Iterator`] honen elementuak beste batekin alderatzen ditu zehaztutako konparazio funtzioarekiko.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [`Iterator`] honen elementuak beste baten berdinak diren zehazten du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Zehazten du [`Iterator`] honen elementuak zehaztutako berdintasun funtzioarekiko beste baten berdinak diren.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Zehazten du [`Iterator`] honen elementuak beste baten parekoak ez diren ala ez.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// [`Iterator`] honen elementuak beste batenak baino [lexicographically](Ord#lexicographical-comparison) gutxiago diren ala ez zehazten du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// [`Iterator`] honen elementuak beste baten [lexicographically](Ord#lexicographical-comparison) gutxiago edo berdinak diren zehazten du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// [`Iterator`] honen elementuak beste batenak baino [lexicographically](Ord#lexicographical-comparison) handiagoak diren zehazten du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// [`Iterator`] honen elementuak [lexicographically](Ord#lexicographical-comparison) beste baten baino handiagoak edo berdinak diren zehazten du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Iteratzaile honen elementuak ordenatuta dauden egiaztatzen du.
    ///
    /// Hau da, `a` elementu bakoitzarentzat eta bere hurrengo `b` elementuarentzat, `a <= b` eduki behar da.Iteratzaileak zehazki zero edo elementu bat ematen badu, `true` itzuliko da.
    ///
    /// Kontuan izan `Self::Item` `PartialOrd` bakarrik bada, baina `Ord` ez bada, goiko definizioak funtzio honek `false` itzultzen duela esan nahi du ondoz ondoko bi elementu konparagarriak ez badira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Egiaztatzen du iteratzaile honen elementuak emandako konparatzaile funtzioaren bidez ordenatuta dauden.
    ///
    /// `PartialOrd::partial_cmp` erabili beharrean, funtzio honek emandako `compare` funtzioa erabiltzen du bi elementuren ordenamendua zehazteko.
    /// Horretaz aparte, [`is_sorted`] ren baliokidea da;Informazio gehiagorako ikusi bere dokumentazioa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Egiaztatzen du iteratzaile honen elementuak emandako gakoa ateratzeko funtzioaren bidez ordenatuta dauden.
    ///
    /// Iteratzailearen elementuak zuzenean alderatu beharrean, funtzio honek elementuen gakoak alderatzen ditu, `f`-k zehazten duen moduan.
    /// Horretaz aparte, [`is_sorted`] ren baliokidea da;Informazio gehiagorako ikusi bere dokumentazioa.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Ikus [TrustedRandomAccess]
    // Ezohiko izena metodoaren ebazpenean izenen arteko talkak ekiditea da. Ikusi #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}