//! Kanpoko iterazio konposagarria.
//!
//! Nolabaiteko bildumarekin aurkitu bazara eta aipatutako bildumako elementuekin eragiketa egin behar baduzu, azkar topatuko duzu 'iterators'.
//! Iteratzaileak oso erabiliak dira Rust kode idiomatikoan, beraz, merezi du haiekin ohitzea.
//!
//! Gehiago azaldu aurretik, hitz egin dezagun nola egituratzen den modulu hau:
//!
//! # Organization
//!
//! Modulu hau motaren arabera antolatzen da neurri handi batean:
//!
//! * [Traits] dira funtsezko zatia: traits hauek definitzen dute zer errepikatzaile mota dauden eta zer egin dezakezun horiekin.traits horien metodoek merezi dute azterketa denbora gehiago jartzea.
//! * [Functions] eman zenbait lagungarri oinarrizko iteratzaile batzuk sortzeko.
//! * [Structs] modulu honetako traits-ko metodo desberdinen itzulera motak izan ohi dira.Normalean `struct` sortzen duen metodoa aztertu nahi duzu, `struct` bera baino.
//! Zergatik xehetasun gehiago nahi izanez gero, ikus '[Iterator ezartzea](#inplementazio-iteratzailea)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Hori da!Goazen iteratzaileetan arakatzen.
//!
//! # Iterator
//!
//! Modulu honen bihotza eta arima [`Iterator`] trait da.[`Iterator`]-ren muina itxura hau du:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iteratzaile batek [`next`] metodo bat dauka, deitzen denean, [`Aukera`]`itzultzen du<Item>`.
//! [`next`] [`Some(Item)`] itzuliko du elementuak dauden bitartean eta behin agortuta, `None` itzuliko du errepikapena amaitu dela adierazteko.
//! Iteratzaile indibidualek iterazioari berrekiteko aukera egin dezakete eta, beraz, [`next`] berriro deitzeak agian noizbait [`Some(Item)`] berriro itzultzen hasi edo agian (adibidez, ikus [`TryIter`]).
//!
//!
//! [`Iterator`]-en definizio osoak beste hainbat metodo ere biltzen ditu, baina lehenetsitako metodoak dira, [`next`]-ren gainean eraikiak, eta, beraz, doan lortuko dituzu.
//!
//! Iteratzaileak konposagarriak dira, eta ohikoa da elkarrekin kateatzea prozesatzeko forma konplexuagoak egiteko.Xehetasun gehiago nahi izanez gero, ikus [Adapters](#adapters) atala.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Hiru errepikapen formak
//!
//! Bilduma batetik iteratzaileak sor ditzaketen hiru metodo komun daude:
//!
//! * `iter()`, horrek `&T` baino gehiagotan errepikatzen du.
//! * `iter_mut()`, horrek `&mut T` baino gehiagotan errepikatzen du.
//! * `into_iter()`, horrek `T` baino gehiagotan errepikatzen du.
//!
//! Liburutegi estandarraren hainbat gauzek hiruren bat edo gehiago ezar ditzakete, hala badagokio.
//!
//! # Iterator ezartzea
//!
//! Iteratzaile propioa sortzeak bi urrats dakartza: `struct` sortzea iteratzailearen egoerari eusteko eta, ondoren, [`Iterator`] ezartzea `struct` horretarako.
//! Horregatik modulu honetan `struct` ugari daude: iteratzaile eta egokitzaile egokitzaile bakoitzeko bat dago.
//!
//! Egin dezagun `Counter` izeneko iteratzailea `1`-tik `5`-ra zenbatzen dena:
//!
//! ```
//! // Lehenik eta behin, egitura:
//!
//! /// Batetik bostera bitarteko iteratzailea
//! struct Counter {
//!     count: usize,
//! }
//!
//! // gure zenbaketa bat hastea nahi dugu, beraz, gehitu dezagun new() metodo bat laguntzeko.
//! // Ez da guztiz beharrezkoa, baina komenigarria da.
//! // Kontuan izan `count` zeroan hasten dugula, ikusiko dugu zergatik `next()`'s inplementazioan behean.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ondoren, `Iterator` inplementatzen dugu gure `Counter` erako:
//!
//! impl Iterator for Counter {
//!     // erabilerarekin zenbatuko dugu
//!     type Item = usize;
//!
//!     // next() beharrezkoa den metodo bakarra da
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Handitu gure kontua.Horregatik zeroan hasi ginen.
//!         self.count += 1;
//!
//!         // Begiratu zenbatzea amaitu dugun edo ez.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Eta orain erabil dezakegu!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] modu honetan deitzea errepikakorra da.Rust-k [`next`] dei dezakeen eraikuntza bat du zure iteratzailean, `None` era iritsi arte.Ikus dezagun hurrengoa.
//!
//! Kontuan izan ere, `Iterator`-k `next` barnera deitzen duten `nth` eta `fold` bezalako metodoen lehenespenezko ezarpena eskaintzen duela.
//! Hala ere, posible da `nth` eta `fold` bezalako metodoen inplementazio pertsonalizatua idaztea, baldin eta iteratzaile batek `next` deitu gabe modu eraginkorragoan kalkula ditzake.
//!
//! # `for` begiztak eta `IntoIterator`
//!
//! Rust-ren `for` begizta sintaxia azukrea da iteratzaileentzat.Hona hemen `for` ren oinarrizko adibidea:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Honek zenbakiak bostetik bostera inprimatuko ditu, bakoitza bere lerroan.Hemen zerbait nabarituko duzu: inoiz ez diogu ezer deitu gure vector-ri iteratzaile bat sortzeko.Zer ematen du?
//!
//! trait bat dago liburutegi estandarrean zerbait iteratzaile bihurtzeko: [`IntoIterator`].
//! trait honek metodo bat du, [`into_iter`], [`IntoIterator`] ezartzen duen gauza iteratzaile bihurtzen duena.
//! Ikus dezagun berriro `for` begizta hori, eta konpiladoreak zertan bihurtzen duen:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust-k azukrea kentzen du:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Lehenik eta behin, `into_iter()` deitzen diogu balioari.Ondoren, itzultzen den iteratzailearekin bat egiten dugu, [`next`] behin eta berriro deituz `None` bat ikusi arte.
//! Une horretan, `break` begizta atera dugu, eta errepikapena amaitu dugu.
//!
//! Hemen badago bit sotil bat: liburutegi estandarrak [`IntoIterator`]-ren inplementazio interesgarria dauka:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Beste modu batera esanda, [`Iterator`] guztiek [`IntoIterator`] inplementatzen dute, beraiek bakarrik itzuliz.Horrek bi gauza esan nahi ditu:
//!
//! 1. [`Iterator`] bat idazten ari bazara, `for` begizta batekin erabil dezakezu.
//! 2. Bilduma bat sortzen ari bazara, horretarako [`IntoIterator`] ezartzeak zure bilduma `for` begiztarekin erabiltzea ahalbidetuko du.
//!
//! # Erreferentzia bidez errepikatuz
//!
//! [`into_iter()`]-k `self` balioz hartzen duenez, bilduma batean errepikatzeko `for` begizta bat erabiliz bilduma hori kontsumitzen da.Sarritan, agian bilduma bat errepikatu nahi duzu kontsumitu gabe.
//! Bilduma askok erreferentzien gaineko iteratzaileak eskaintzen dituzten metodoak eskaintzen dituzte, normalean `iter()` eta `iter_mut()` deitzen direnak hurrenez hurren:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` funtzio honen jabea da oraindik.
//! ```
//!
//! `C` motako bildumak `iter()` ematen badu, normalean `IntoIterator` ere ezartzen du `&C` erako, `iter()` deitzen duen inplementazioarekin.
//! Era berean, `iter_mut()` eskaintzen duen `C` bildumak normalean `IntoIterator` inplementatzen du `&mut C` rentzat `iter_mut()`-n delegatuz.Honek laburpen erosoa ahalbidetzen du:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` bezalakoa
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` bezalakoa
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Bilduma askok `iter()` eskaintzen duten arren, guztiek ez dute `iter_mut()` eskaintzen.
//! Adibidez, [`HashSet<T>`] edo [`HashMap<K, V>`] baten gakoak mutatuz gero, bilduma egoera desegokian jar liteke gakoen hash-ak aldatzen badira, beraz, bilduma hauek `iter()` soilik eskaintzen dute.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] bat hartzen duten eta beste [`Iterator`] bat itzultzen duten funtzioei 'iteratzaile egokitzaileak' deitu ohi zaie, 'egokitzailearen forma bat baita
//! pattern'.
//!
//! Iteratzaile egokitzaile arrunten artean [`map`], [`take`] eta [`filter`] daude.
//! Informazio gehiago lortzeko, ikusi haien dokumentazioa.
//!
//! panics iteratzaile egokitzailea bada, iteratzailea zehaztu gabeko (baina memoria segurua) egoeran egongo da.
//! Egoera hau ere ez dago ziurtatuta Rust bertsioetan berdin mantentzea, beraz, iteratzaile batek izututako balore zehatzetan fidatzea saihestu beharko zenuke.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratzaileak (eta [adapters](#adapters)) iteratzailea * alferrak dira. Horrek esan nahi du iteratzaile bat sortzeak ez duela _do_ asko. Benetan ez da ezer gertatzen [`next`] deitu arte.
//! Batzuetan, nahasmendu iturri bat sortzen da bere bigarren mailako efektuengatik soilik.
//! Adibidez, [`map`] metodoak iteratzen duen elementu bakoitzari itxiera deitzen dio:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Honek ez du inolako baliorik inprimatuko, iteratzailea bakarrik sortu baitugu erabili beharrean.Konpiladoreak jokabide mota honen inguruan ohartaraziko digu:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Bigarren mailako efektuetarako [`map`] idazteko modu idiomatikoa `for` begizta bat erabiltzea edo [`for_each`] metodoari deitzea da:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Iteratzaile bat ebaluatzeko beste modu arrunt bat [`collect`] metodoa erabiltzea da bilduma berri bat ekoizteko.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratzaileek ez dute zertan finituak izan.Adibide gisa, irekitako barrutia iteratzaile infinitua da:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ohikoa da [`take`] iteratzaile egokitzailea erabiltzea infinitu iteratzaile finitu bihurtzeko:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Honek `0` eta `4` zenbakiak inprimatuko ditu, bakoitza bere lerroan.
//!
//! Gogoan izan iteratzaile amaigabeen metodoak, nahiz eta emaitza matematikoan denbora finituan zehaztu daitekeen, agian ez direla amaituko.
//! Zehazki, [`min`] bezalako metodoak, kasu orokorrean iteratzailearen elementu guztiak zeharkatzea eskatzen dutenak, ziurrenik ez dira itzultzaile infinituetarako behar bezala itzuliko.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh ez!Begizta infinitua!
//! // `ones.min()` begizta infinitua eragiten du, beraz, ez gara honaino iritsiko!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;