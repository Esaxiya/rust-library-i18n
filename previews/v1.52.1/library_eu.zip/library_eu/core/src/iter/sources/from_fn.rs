use crate::fmt;

/// Iteratzaile berria sortzen du, non iterazio bakoitzak emandako itxierari `F: FnMut() -> Option<T>` deitzen dion.
///
/// Horrek edozein portaerarekin iteratzaile pertsonalizatua sortzea ahalbidetzen du mota dedikatu bat sortu eta horretarako [`Iterator`] trait ezartzeko sintaxi zehatzagoa erabili gabe.
///
/// Kontuan izan `FromFn` iteratzaileak ez duela itxieraren portaerari buruzko suposiziorik egiten, eta, beraz, modu kontserbadorean ez duela [`FusedIterator`] inplementatzen, edo [`Iterator::size_hint()`] bere `(0, None)` lehenetsitik ez duela gainidazten.
///
///
/// Itxierak kapturak eta ingurunea erabil ditzake iterazioen egoera jarraitzeko.Iteratzailea nola erabiltzen den arabera, itxierako [`move`] gako-hitza zehaztu beharko da.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Dezagun berriro inplementatu [module-level documentation]-etik kontagailu iteratzailea:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Handitu gure kontua.Horregatik zeroan hasi ginen.
///     count += 1;
///
///     // Begiratu zenbatzea amaitu dugun edo ez.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iteratzaile bat, iterazio bakoitzak emandako itxierari `F: FnMut() -> Option<T>` deitzen diona.
///
/// `struct` hau [`iter::from_fn()`] funtzioak sortzen du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}