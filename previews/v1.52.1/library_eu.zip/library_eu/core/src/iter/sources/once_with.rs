use crate::iter::{FusedIterator, TrustedLen};

/// Ematen den itxiera deituz balio bat alferka sortzen duen iteratzailea sortzen du.
///
/// Normalean balio sorgailu bakarra beste iterazio mota batzuetako [`chain()`] batean egokitzeko erabiltzen da.
/// Agian ia dena estaltzen duen errepikatzaile bat duzu, baina aparteko kasu berezi bat behar duzu.
/// Agian iteratzaileetan funtzionatzen duen funtzioa duzu, baina balio bakarra prozesatu behar duzu.
///
/// [`once()`]-k ez bezala, funtzio horrek alferrak sortuko du eskatutako balioa.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::iter;
///
/// // bat da zenbaki bakartiena
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bakarra, hori da lortzen dugun guztia
/// assert_eq!(None, one.next());
/// ```
///
/// Beste iteratzaile batekin kateatzea.
/// Demagun `.foo` direktorioko fitxategi bakoitza errepikatzea nahi dugula, baina baita konfigurazio fitxategia ere,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s iteratzaile batetik PathBufs-en iteratzaile bihurtu behar dugu, beraz, mapa erabiltzen dugu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // orain, gure iteratzailea soilik gure konfigurazio fitxategirako
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kateatu bi iteratzaileak elkarrekin iteratzaile handi batean
/// let files = dirs.chain(config);
///
/// // honek .foo eta .foorc fitxategi guztiak emango dizkigu
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// `A` motako elementu bakarra ematen duen iteratzailea, emandako itxiera `F: FnOnce() -> A` aplikatuz.
///
///
/// `struct` hau [`once_with()`] funtzioak sortzen du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}