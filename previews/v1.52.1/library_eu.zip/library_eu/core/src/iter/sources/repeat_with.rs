use crate::iter::{FusedIterator, TrustedLen};

/// `A` motako elementuak etengabe errepikatzen dituen iteratzaile berria sortzen du emandako itxiera, errepikagailua, `F: FnMut() -> A`.
///
/// `repeat_with()` funtzioak behin eta berriro deitzen dio errepikatzaileari.
///
/// `repeat_with()` bezalako errepikagailu infinituak [`Iterator::take()`] bezalako egokitzaileekin erabili ohi dira, finituak izan daitezen.
///
/// Behar duzun iteratzailearen elementu motak [`Clone`] inplementatzen badu eta iturburuko elementua memorian mantentzea ondo badago, [`repeat()`] funtzioa erabili beharko zenuke.
///
///
/// `repeat_with()`-ek sortutako iteratzailea ez da [`DoubleEndedIterator`].
/// [`DoubleEndedIterator`] itzultzeko `repeat_with()` behar baduzu, ireki GitHub arazoa zure erabilera kasua azalduz.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::iter;
///
/// // Demagun `Clone` ez den edo oraindik memorian eduki nahi ez duten mota baten balioa dugula garestia delako:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // balio jakin bat betirako:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutazioa erabiliz eta mugitua:
///
/// ```rust
/// use std::iter;
///
/// // Zerrotik biren hirugarren potentziara:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... eta orain amaitu dugu
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// `A` motako elementuak etengabe errepikatzen dituen iteratzailea, emandako `F: FnMut() -> A` itxiera aplikatuz.
///
///
/// `struct` hau [`repeat_with()`] funtzioak sortzen du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}