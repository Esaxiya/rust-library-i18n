use crate::{iter::FusedIterator, ops::Try};

/// Etengabe errepikatzen den errepikatzailea.
///
/// X01X hau X002 X02X metodoaren bidez sortzen da.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // zikloaren errepikatzailea hutsa edo infinitua da
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // erabat errepikatu uneko iteratzailea.
        // beharrezkoa da `self.iter` hutsik egon daitekeelako `self.orig` ez dagoenean ere
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // osatu ziklo osoa, ziklatutako iteratzailea hutsik dagoen edo ez jakiteko.
        // goiz itzuli behar dugu iteragailu hutsaren kasuan begizta infinitua saihesteko
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` gainidazketarik ez, `fold`-k ez baitu zentzu handirik `Cycle` rentzat, eta ezin dugu lehenetsia baino hobe egin.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}