use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` duen iteratzailea hurrengo elementuari aukerako erreferentzia bat itzultzen diona.
///
///
/// `struct` hau X002 X 02X metodoaren bidez sortzen da.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Gogoratu begirada bat, bat ere ez bada ere.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable-k gogoratu behar du `.peek()` metodoan Bat ere ikusi ez bada.
// `.peek() hori bermatzen du;.peek();` edo `.peek();.next();`-k azpiko iteratzailea behin bakarrik aurreratzen du.
// Horrek ez du berez errepikatzailea fusionatzen.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// next() balioaren erreferentzia itzultzen du iteratzailea aurreratu gabe.
    ///
    /// [`next`] bezala, balio bat badago, `Some(T)` batean biltzen da.
    /// Baina errepikapena amaitzen bada, `None` itzultzen da.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()`-k erreferentzia bat itzultzen duenez, eta iteratzaile askok erreferentzien gainetik errepikatzen dutenez, itzul daitekeen balioa erreferentzia bikoitza den egoera nahasgarria izan daiteke.
    /// Efektu hau beheko adibideetan ikus dezakezu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future-ra sartzen uzten digu
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iteratzaileak ez du aurrera egiten `peek` hainbat aldiz egiten badugu ere
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Iteratzailea amaitu ondoren, `peek()` ere bada
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// next() balioaren erreferentzia aldakorra itzultzen du iteratzailea aurreratu gabe.
    ///
    /// [`next`] bezala, balio bat badago, `Some(T)` batean biltzen da.
    /// Baina errepikapena amaitzen bada, `None` itzultzen da.
    ///
    /// `peek_mut()`-k erreferentzia bat itzultzen duenez, eta iteratzaile askok erreferentzien gainetik errepikatzen dutenez, itzul daitekeen balioa erreferentzia bikoitza den egoera nahasgarria izan daiteke.
    /// Efektu hau beheko adibideetan ikus dezakezu.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()`-ekin bezala, future-ra ikus dezakegu iteratzailea aurreratu gabe.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Begiratu iteratzailean eta ezarri erreferentzia aldagarriaren atzean dagoen balioa.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Jarri dugun balioa berriro agertzen da iteratzaileak jarraitzen duen heinean.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Kontsumitu eta itzuli iteratzaile honen hurrengo balioa baldintza bat egia bada.
    /// `func`-ek `true` itzultzen badu iteratzaile honen hurrengo balioa lortzeko, kontsumitu eta itzuli.
    /// Bestela, itzuli `None`.
    /// # Examples
    /// Kontsumitu zenbaki bat 0 berdina bada.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Iteratzailearen lehen elementua 0 da;kontsumitu.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Itzulitako hurrengo elementua 1 da, beraz `consume`-k `false` itzuliko du.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` hurrengo elementuaren balioa gordetzen du `expected`-ren berdina ez bada.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Kontsumitu 10 baino gutxiagoko edozein zenbaki.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Kontsumitu 10 baino gutxiagoko zenbaki guztiak
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Itzulitako hurrengo balioa 10 izango da
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // `self.next()` deitu genuenetik, `self.peeked` kontsumitu genuen.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Kontsumitu eta itzuli hurrengo elementua `expected`-ren berdina bada.
    /// # Example
    /// Kontsumitu zenbaki bat 0 berdina bada.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Iteratzailearen lehen elementua 0 da;kontsumitu.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Itzulitako hurrengo elementua 1 da, beraz `consume`-k `false` itzuliko du.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` hurrengo elementuaren balioa gordetzen du `expected`-ren berdina ez bada.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SEGURTASUNA: funtzio segurua birbidaltzea baldintza berdinak dituzten funtzio ez segurura
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}