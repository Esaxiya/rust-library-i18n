Panics uneko haria.

Horri esker, programa bat berehala amaitzen da eta programaren deitzaileari iritzia ematen zaio.
`panic!` erabili behar da programa berreskuraezina den egoerara iristen denean.

Makro hau adibide kodean eta probetan baldintzak aldarrikatzeko modu ezin hobea da.
`panic!` estuki lotuta dago [`Option`][ounwrap] eta [`Result`][runwrap] enumetako `unwrap` metodoarekin.
Bi inplementazioek `panic!` deitzen dute [`None`] edo [`Err`] aldaeretan ezarrita daudenean.

`panic!()` erabiltzerakoan kateen karga zehaztu dezakezu, [`format!`] sintaxia erabiliz eraikia.
Karga hori panic deitzaileari Rust hari injektatzean erabiltzen da, haria panic erabat eraginez.

`std` hook lehenetsiaren portaera, alegia
panic deitu ondoren zuzenean exekutatzen den kodea, mezuaren karga `stderr`-ra inprimatzea da `panic!()` deiaren file/line/column informazioarekin batera.

panic hook gainidatzi dezakezu [`std::panic::set_hook()`] erabiliz.
hook barruan panic bat sar daiteke `&dyn Any + Send` gisa, `&str` edo `String` bat baitu `panic!()` erregularki deitzeko.
Beste mota bateko balioa duen panic ri, [`panic_any`] erabil daiteke.

[`Result`] enum akatsetatik berreskuratzeko irtenbide hobea izaten da `panic!` makroa erabiltzea baino.
Makro hau balio okerrak erabiltzen jarraitzea ekiditeko erabili behar da, hala nola kanpoko iturrietatik abiatuta.
Erroreak maneiatzeari buruzko informazio zehatza [book] n aurkitzen da.

Ikusi [`compile_error!`] makroa ere, konpilazioan zehar akatsak sortzeagatik.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Egungo ezarpena

panics hari nagusia zure hari guztiak amaituko ditu eta programa `101` kodearekin amaituko du.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





