#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Deitzailearen edizioaren arabera `$crate::panic::panic_2015` edo `$crate::panic::panic_2021` hedatzen da.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Bi adierazpen elkarren berdinak direla baieztatzen du ([`PartialEq`] erabiliz).
///
/// panic-n, makro honek adierazpenen balioak inprimatuko ditu arazketa irudikapenekin.
///
///
/// [`assert!`]-k bezala, makro honek bigarren inprimakia du eta bertan panic mezu pertsonalizatua eman daiteke.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Beheko berreskurapenak nahita eginak dira.
                    // Horiek gabe, maileguaren pila-zirrikitua hasieratzen da balioak alderatu aurretik ere, moteltze nabaria lortuz.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Beheko berreskurapenak nahita eginak dira.
                    // Horiek gabe, maileguaren pila-zirrikitua hasieratzen da balioak alderatu aurretik ere, moteltze nabaria lortuz.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Bi esamolde elkarren berdinak ez direla baieztatzen du ([`PartialEq`] erabiliz).
///
/// panic-n, makro honek adierazpenen balioak inprimatuko ditu arazketa irudikapenekin.
///
///
/// [`assert!`]-k bezala, makro honek bigarren inprimakia du eta bertan panic mezu pertsonalizatua eman daiteke.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Beheko berreskurapenak nahita eginak dira.
                    // Horiek gabe, maileguaren pila-zirrikitua hasieratzen da balioak alderatu aurretik ere, moteltze nabaria lortuz.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Beheko berreskurapenak nahita eginak dira.
                    // Horiek gabe, maileguaren pila-zirrikitua hasieratzen da balioak alderatu aurretik ere, moteltze nabaria lortuz.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Adierazpen boolear bat `true` dela exekuzio garaian baieztatzen du.
///
/// Honek [`panic!`] makroa deituko du baldin eta emandako adierazpena exekuzio garaian `true` ra ebaluatu ezin bada.
///
/// [`assert!`]-k bezala, makro honek bigarren bertsio bat ere badu, eta bertan panic mezu pertsonalizatua eman daiteke.
///
/// # Uses
///
/// [`assert!`] ez bezala, `debug_assert!` instrukzioak optimizatuta ez dauden eraikuntzetan soilik gaitzen dira lehenespenez.
/// Optimizatutako eraikuntza batek ez ditu `debug_assert!` instrukzioak exekutatuko, baldin eta `-C debug-assertions` konpiladorera pasatzen ez bada.
/// Horrek `debug_assert!` erabilgarria bihurtzen du bertsioen bertsio batean egoteko garestiegiak diren baina garapenean lagungarriak izan daitezkeen egiaztapenetarako.
/// `debug_assert!` zabaltzearen emaitza beti egiaztatzen da.
///
/// Egiaztatu gabeko baieztapenek egoera koherentean dagoen programa batek martxan jarraitzea ahalbidetzen du, eta horrek ustekabeko ondorioak izan ditzake, baina ez du segurtasunik sortzen, kode seguruan soilik gertatzen den bitartean.
///
/// Baieztapenen errendimendu kostua, ordea, orokorrean ez da neurgarria.
/// [`assert!`] `debug_assert!`-rekin ordezkatzea profilaketa sakona egin ondoren bakarrik sustatzen da eta, are garrantzitsuagoa dena, kode seguruan soilik!
///
/// # Examples
///
/// ```
/// // baieztapen hauetarako panic mezua emandako adierazpenaren balio kordatua da.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // oso funtzio sinplea
/// debug_assert!(some_expensive_computation());
///
/// // baieztatu mezu pertsonalizatu batekin
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Bi adierazpen elkarren berdinak direla baieztatzen du.
///
/// panic-n, makro honek adierazpenen balioak inprimatuko ditu arazketa irudikapenekin.
///
/// [`assert_eq!`] ez bezala, `debug_assert_eq!` instrukzioak optimizatuta ez dauden eraikuntzetan soilik gaitzen dira lehenespenez.
/// Optimizatutako eraikuntza batek ez ditu `debug_assert_eq!` instrukzioak exekutatuko, baldin eta `-C debug-assertions` konpiladorera pasatzen ez bada.
/// Horrek `debug_assert_eq!` erabilgarria bihurtzen du bertsioen bertsio batean egoteko garestiegiak diren baina garapenean lagungarriak izan daitezkeen egiaztapenetarako.
///
/// `debug_assert_eq!` zabaltzearen emaitza beti egiaztatzen da.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Bi esamolde elkarren berdinak ez direla baieztatzen du.
///
/// panic-n, makro honek adierazpenen balioak inprimatuko ditu arazketa irudikapenekin.
///
/// [`assert_ne!`] ez bezala, `debug_assert_ne!` instrukzioak optimizatuta ez dauden eraikuntzetan soilik gaitzen dira lehenespenez.
/// Optimizatutako eraikuntza batek ez ditu `debug_assert_ne!` instrukzioak exekutatuko, baldin eta `-C debug-assertions` konpiladorera pasatzen ez bada.
/// Horrek `debug_assert_ne!` erabilgarria bihurtzen du bertsioen bertsio batean egoteko garestiegiak diren baina garapenean lagungarriak izan daitezkeen egiaztapenetarako.
///
/// `debug_assert_ne!` zabaltzearen emaitza beti egiaztatzen da.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Ematen duen adierazpena emandako ereduetako batekin bat datorren ematen du.
///
/// `match` adierazpen batean bezala, eredua aukeran `if` eta ereduak loturiko izenetara sarbidea duen guardia adierazpenarekin jarrai daiteke.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Emaitza bat desegin edo bere errorea hedatzen du.
///
/// `?` operadorea `try!` ordezkatzeko gehitu da eta horren ordez erabili beharko litzateke.
/// Gainera, `try` hitz gordea da Rust 2018an, beraz, erabili behar baduzu, [raw-identifier syntax][ris] erabili beharko duzu: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` emandako [`Result`]-rekin bat dator.`Ok` aldaeraren kasuan, adierazpenak bildutako balioaren balioa du.
///
/// `Err` aldaeraren kasuan, barne errorea berreskuratzen du.`try!`-k `From` erabiliz bihurketa egiten du.
/// Honek akats espezializatuen eta orokorragoen arteko bihurketa automatikoa eskaintzen du.
/// Lortutako errorea berehala itzultzen da.
///
/// Itzulera goiztiarraren ondorioz, `try!` [`Result`] itzultzen duten funtzioetan bakarrik erabil daiteke.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Errore bizkorrak itzultzeko metodo hobetsia
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Errore bizkorrak itzultzeko aurreko metodoa
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Hau baliokidea da:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Formateatutako datuak buffer batean idazten ditu.
///
/// Makro honek 'writer', formatu katea eta argumentuen zerrenda onartzen ditu.
/// Argudioak zehaztutako formatu katearen arabera formateatuko dira eta emaitza idazleari emango zaio.
/// Idazleak edozein balio izan dezake `write_fmt` metodoarekin;orokorrean hau [`fmt::Write`] edo [`io::Write`] trait-ren inplementazio batetik dator.
/// Makroak `write_fmt` metodoak itzultzen duena itzultzen du;normalean [`fmt::Result`] bat edo [`io::Result`] bat.
///
/// Ikusi [`std::fmt`] formatuaren kate sintaxiari buruzko informazio gehiago lortzeko.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modulu batek `std::fmt::Write` eta `std::io::Write` inporta ditzake eta `write!` dei dezake bata bestea gauzatzen duten objektuetan, objektuek normalean ez baitituzte biak inplementatzen.
///
/// Hala ere, moduluak traits kualifikatua inportatu behar du, haien izenak gatazkarik ez izateko:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt erabiltzen du
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt erabiltzen du
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Makro hau `no_std` konfigurazioetan ere erabil daiteke.
/// `no_std` konfigurazioan osagaien inplementazio xehetasunen arduraduna zara.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Idatzi formateatutako datuak buffer batean, linea berria erantsita.
///
/// Plataforma guztietan, linea berria LINE FEED karakterea (`\n`/`U+000A`) bakarra da (GARAIEN ITZULPEN (`\r`/`U+000D`) gehigarririk gabe).
///
/// Informazio gehiago lortzeko, ikus [`write!`].Formatu-kateen sintaxiari buruzko informazioa lortzeko, ikusi [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modulu batek `std::fmt::Write` eta `std::io::Write` inporta ditzake eta `write!` dei dezake bata bestea gauzatzen duten objektuetan, objektuek normalean ez baitituzte biak inplementatzen.
/// Hala ere, moduluak traits kualifikatua inportatu behar du, haien izenak gatazkarik ez izateko:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt erabiltzen du
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt erabiltzen du
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Iritsi ezin den kodea adierazten du.
///
/// Hau erabilgarria da konpiladoreak kode batzuk heltzen ez diren zehaztu ezin duen bakoitzean.Adibidez:
///
/// * Lotu besoak guardia baldintzekin.
/// * Dinamikoki amaitzen diren begiztak.
/// * Dinamikoki amaitzen diren iteratzaileak.
///
/// Kodea eskuraezina dela zehazten bada, programa berehala amaituko da [`panic!`] batekin.
///
/// Makro honen kontrako segurtasuna [`unreachable_unchecked`] funtzioa da, eta horrek kodea zehazten ez den portaera eragingo du.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Hau beti izango da [`panic!`].
///
/// # Examples
///
/// Partiduen besoak:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // konpilazio errorea iruzkindu ezkero
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-ren inplementazio eskasenetakoa
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Inplementatu gabeko kodea adierazten du "not implemented" mezuarekin izututa.
///
/// Horrek zure kodea mota egiaztatzea ahalbidetzen du, eta hori erabilgarria da guztiak erabiltzeko asmorik ez duten metodo ugari behar dituen trait prototipatzen edo ezartzen ari bazara.
///
/// `unimplemented!` eta [`todo!`]-en arteko aldea da `todo!`-k funtzionalitatea geroago ezartzeko asmoa ematen duen bitartean eta mezua "not yet implemented" dela, `unimplemented!`-k ez du horrelako erreklamaziorik egiten.
/// Bere mezua "not implemented" da.
/// IDE batzuek `todo!` Markatuko dute.
///
/// # Panics
///
/// Hau beti izango da [`panic!`], `unimplemented!` `panic!` en laburpena besterik ez baita mezu zehatz eta finko batekin.
///
/// `panic!`-k bezala, makro honek balio pertsonalizatuak bistaratzeko bigarren inprimakia du.
///
/// # Examples
///
/// Esan trait `Foo` dugula:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// `Foo` inplementatu nahi dugu 'MyStruct' rako, baina arrazoi batzuengatik ez du zentzurik `bar()` funtzioa ezartzeak.
/// `baz()` eta `qux()` oraindik zehaztu beharko da `Foo` gure inplementazioan, baina `unimplemented!` erabil dezakegu haien definizioetan gure kodea konpilatu ahal izateko.
///
/// Oraindik gure programa exekutatzeari utzi nahi diogu ezarri gabeko metodoak lortzen badira.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` a `MyStruct` batek ez du zentzurik, beraz ez dugu inolako logikarik hemen.
/////
///         // Honek "thread 'main' panicked at 'not implemented'" bistaratuko du.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Logika batzuk ditugu hemen, inplementatu gabeko mezu bat gehi dezakegu!gure hutsunea bistaratzeko.
///         // Honek bistaratuko ditu: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Bukatu gabeko kodea adierazten du.
///
/// Hau erabilgarria izan daiteke prototipoak egiten ari bazara eta zure kodearen tipografia egiaztatzea nahi baduzu.
///
/// [`unimplemented!`] eta `todo!`-en arteko aldea da `todo!`-k funtzionalitatea geroago ezartzeko asmoa ematen duen bitartean eta mezua "not yet implemented" dela, `unimplemented!`-k ez du horrelako erreklamaziorik egiten.
/// Bere mezua "not implemented" da.
/// IDE batzuek `todo!` Markatuko dute.
///
/// # Panics
///
/// Hau beti izango da [`panic!`].
///
/// # Examples
///
/// Hona hemen abian diren kode batzuen adibidea.trait `Foo` dugu:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// `Foo` gure mota batean inplementatu nahi dugu, baina `bar()` bakarrik landu nahi dugu lehenik.Gure kodea konpilatu ahal izateko, `baz()` inplementatu behar dugu, beraz `todo!` erabil dezakegu:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // inplementazioa hemen doa
///     }
///
///     fn baz(&self) {
///         // ez gaitezen kezkatu oraingoz baz() ezartzeaz
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // baz() ere ez dugu erabiltzen, beraz ondo dago.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Makro integratuen definizioak.
///
/// Makro propietate gehienak (egonkortasuna, ikusgarritasuna, etab.) Hemengo iturburu kodetik hartuak dira, makro sarrerak irteera bihurtzen dituzten hedapen funtzioak izan ezik, funtzio horiek konpiladoreak ematen ditu.
///
///
pub(crate) mod builtin {

    /// Aurkitutakoan konpilazioak huts egiteak eragiten du emandako errore mezuarekin.
    ///
    /// Makro hau crate-k baldintzazko konpilazio estrategia erabiltzen duenean erabili behar da, okerreko baldintzetarako errore mezu hobeak eskaintzeko.
    ///
    /// Konpilagailu mailako [`panic!`] forma da, baina errorea igortzen du *konpilazioan**exekuzioan* baino.
    ///
    /// # Examples
    ///
    /// Horrelako bi adibide makroak eta `#[cfg]` inguruneak dira.
    ///
    /// Igorri konpilagailuaren errore hobea makro bati balio baliogabeak pasatzen bazaizkio.
    /// Azken branch gabe, konpiladoreak errore bat igorriko luke oraindik, baina akatsaren mezuak ez ditu baliozko bi balioak aipatuko.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Igorri konpiladorearen errorea funtzioetako bat erabilgarri ez badago.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Katea formateatzeko beste makroen parametroak eraikitzen ditu.
    ///
    /// Makro honek funtzionatzen du pasatutako argumentu gehigarri bakoitzeko `{}` duen formatu-kate literala hartuz.
    /// `format_args!` parametro osagarriak prestatzen ditu irteera kate gisa interpretatu daitekeela ziurtatzeko eta argumentuak mota bakarrean kanonizatzen dituela.
    /// [`Display`] trait inplementatzen duen edozein balio `format_args!` era pasa daiteke, [`Debug`] edozein inplementazio `{:?}` batera pasa daiteke formateatze katearen barruan.
    ///
    ///
    /// Makro honek [`fmt::Arguments`] motako balioa sortzen du.Balio hau [`std::fmt`] barruko makroetara pasa daiteke birbideratze erabilgarria egiteko.
    /// Formatuaren beste makro guztiak ([`format!`], [`write!`], [`println!`], etab) honen bidez proxy dira.
    /// `format_args!`, eratorritako makroek ez bezala, muntaketa-esleipenak saihesten ditu.
    ///
    /// `format_args!`-k `format_args!`-k itzultzen duen [`fmt::Arguments`] balioa erabil dezakezu `Debug` eta `Display` testuinguruetan behean ikusten den moduan.
    /// Adibideak `Debug` eta `Display` formatuak gauza bera erakusten ditu: formatu arteko katea `format_args!`-n.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Informazio gehiago lortzeko, ikusi [`std::fmt`] dokumentazioan.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` bezalakoa da, baina azkenean linea berria gehitzen du.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ingurumen aldagai bat ikuskatzen du konpilazio garaian.
    ///
    /// Makro hau izendatutako ingurunearen aldagaiaren balioa zabalduko da konpilazio garaian, `&'static str` motako adierazpena emanez.
    ///
    ///
    /// Inguruneko aldagaia zehazten ez bada, konpilazio errore bat igorriko da.
    /// Konpilazio errore bat igortzeko, erabili [`option_env!`] makroa horren ordez.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Akats mezua pertsonaliza dezakezu katea bigarren parametro gisa pasatuz:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` ingurumen aldagaia zehazten ez bada, errore hau jasoko duzu:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Aukeran ingurune aldagai bat ikuskatzen du konpilazio garaian.
    ///
    /// Ingurumen aldagaia konpilazio garaian badago, hau `Option<&'static str>` motako adierazpenera zabalduko da, ingurunearen aldagaiaren balioaren `Some` balioa duena.
    /// Inguruneko aldagaia ez badago, `None`-ra zabalduko da.
    /// Ikusi [`Option<T>`][Option] mota honi buruzko informazio gehiago lortzeko.
    ///
    /// Konpilazio denborako errore bat ez da inoiz igortzen makro hau erabiltzean inguruneko aldagaia presente dagoen edo ez.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Identifikatzaileak identifikatzaile bakarrean kateatzen ditu.
    ///
    /// Makro honek komaz bereizitako edozein identifikatzaile hartzen ditu, eta guztiak kateatzen ditu, identifikatzaile berria den adierazpena emanez.
    /// Kontuan izan higieneak makro honek ezin dituela aldagai lokalak harrapatu.
    /// Gainera, arau orokor gisa, makroak elementu, adierazpen edo adierazpen posizioan soilik onartzen dira.
    /// Horrek esan nahi du makro hau lehendik dauden aldagaiak, funtzioak edo moduluak eta abar aipatzeko erabil dezakezula, ezin duzula berria definitu horrekin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (berria, dibertigarria, izena) { }//modu honetan ezin da erabili!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Literalak katearen zati estatikoan zatitzen ditu.
    ///
    /// Makro honek komaz bereizitako literal kopurua hartzen du, ezkerretik eskuinera kateatutako literal guztiak adierazten dituen `&'static str` motako adierazpena emanez.
    ///
    ///
    /// Zenbaki osoak eta puntu mugikorreko literalak kateatzen dira kateatzeko.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Deitu den lerro zenbakira zabaltzen da.
    ///
    /// [`column!`] eta [`file!`]-rekin, makro hauek arazketa informazioa eskaintzen diete garatzaileei iturburuaren kokapenari buruz.
    ///
    /// Zabaldutako adierazpenak `u32` mota du eta 1 oinarrituta dago, beraz, fitxategi bakoitzeko lehen lerroak 1era balio du, bigarrenak 2ra, etab.
    /// Hori bat dator konpilatzaile arrunten edo editore ezagunen errore-mezuekin.
    /// Itzulitako lerroa *ez da nahitaez*`line!` deialdiaren beraren lerroa, baizik eta `line!` makroaren deialdira iritsi den lehen makro deia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Deitu zen zutabe zenbakira zabaltzen da.
    ///
    /// [`line!`] eta [`file!`]-rekin, makro hauek arazketa informazioa eskaintzen diete garatzaileei iturburuaren kokapenari buruz.
    ///
    /// Zabaldutako adierazpenak `u32` mota du eta 1 oinarrituta dago, beraz lerro bakoitzeko lehenengo zutabeak 1era balio du, bigarrenak 2ra, etab.
    /// Hori bat dator konpilatzaile arrunten edo editore ezagunen errore-mezuekin.
    /// Itzulitako zutabea *ez da nahitaez*`column!` deiaren beraren lerroa, baizik eta `column!` makroaren deialdira iritsi den lehen makro deia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Deitu den fitxategi izenera zabaltzen da.
    ///
    /// [`line!`] eta [`column!`]-rekin, makro hauek arazketa informazioa eskaintzen diete garatzaileei iturburuaren kokapenari buruz.
    ///
    /// Zabaldutako adierazpenak `&'static str` mota du, eta itzulitako fitxategia ez da `file!` makroaren deialdia bera, baizik eta `file!` makroaren deialdira iritsi den lehen makro deia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Bere argudioak estutzen ditu.
    ///
    /// Makro honek `&'static str` motako adierazpena emango du, hau da, makroari pasatutako tokens guztien sailkapena.
    /// Ez da murrizketarik jartzen makro deiaren beraren sintaxian.
    ///
    /// Kontuan izan Sarrerako tokens sarreraren emaitzak future-n alda daitezkeela.Kontuz ibili beharko zenuke irteeran oinarritzen bazara.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 kodetutako fitxategia sartzen du kate gisa.
    ///
    /// Fitxategia uneko fitxategiaren aldean dago (moduluak nola aurkitzen diren antzera).
    /// Emandako bidea plataforma zehatz batean interpretatzen da konpilazio garaian.
    /// Beraz, adibidez, `\` barra atzerakoiak dituen Windows bidea duen deialdia ez litzateke behar bezala konpilatuko Unix-n.
    ///
    ///
    /// Makro honek fitxategiaren edukia den `&'static str` motako adierazpena emango du.
    ///
    /// # Examples
    ///
    /// Demagun direktorio berean bi fitxategi daudela eduki hauekin:
    ///
    /// 'spanish.in' fitxategia:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fitxategia:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' konpilatu eta ondorioz bitarra exekutatzean "adiós" inprimatuko da.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Fitxategi bat barne hartzen du byte array baten erreferentzia gisa.
    ///
    /// Fitxategia uneko fitxategiaren aldean dago (moduluak nola aurkitzen diren antzera).
    /// Emandako bidea plataforma zehatz batean interpretatzen da konpilazio garaian.
    /// Beraz, adibidez, `\` barra atzerakoiak dituen Windows bidea duen deialdia ez litzateke behar bezala konpilatuko Unix-n.
    ///
    ///
    /// Makro honek fitxategiaren edukia den `&'static [u8; N]` motako adierazpena emango du.
    ///
    /// # Examples
    ///
    /// Demagun direktorio berean bi fitxategi daudela eduki hauekin:
    ///
    /// 'spanish.in' fitxategia:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fitxategia:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' konpilatu eta ondorioz bitarra exekutatzean "adiós" inprimatuko da.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Uneko moduluaren bidea adierazten duen kate batera zabaltzen da.
    ///
    /// Uneko moduluaren bidea crate root-era itzultzeko moduen hierarkia dela pentsa daiteke.
    /// Itzulitako bidearen lehen osagaia orain konpilatzen ari den crate izena da.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Konfigurazio banderen konbinazio boolearrak ebaluatzen ditu konpilazio-garaian.
    ///
    /// `#[cfg]` atributuaz gain, makro hau konfigurazio banderen adierazpen boolearra ebaluatzeko aukera ematen du.
    /// Horrek maiz bikoiztutako kodea sortzen du.
    ///
    /// Makro honi emandako sintaxia [`cfg`] atributuaren sintaxi bera da.
    ///
    /// `cfg!`, `#[cfg]`-k ez bezala, ez du koderik kentzen eta egia edo gezurra dela bakarrik ebaluatzen du.
    /// Adibidez, if/else adierazpeneko bloke guztiek baliozkoak izan behar dute `cfg!` baldintzetarako erabiltzen denean, `cfg!` ebaluatzen ari dena kontuan hartu gabe.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Fitxategi bat testuinguruaren arabera adierazpen edo elementu gisa analizatzen du.
    ///
    /// Fitxategia uneko fitxategiaren aldean dago (moduluak nola aurkitzen diren antzera).Emandako bidea plataforma zehatz batean interpretatzen da konpilazio garaian.
    /// Beraz, adibidez, `\` barra atzerakoiak dituen Windows bidea duen deialdia ez litzateke behar bezala konpilatuko Unix-n.
    ///
    /// Makro hau erabiltzea ideia txarra izan ohi da, izan ere, fitxategia adierazpen gisa analizatzen bada, inguruko kodean higienikoki kokatuko da.
    /// Honek aldagaiak edo funtzioak fitxategiak espero zituena desberdinak izan daitezke, uneko fitxategian izen bera duten aldagaiak edo funtzioak badaude.
    ///
    ///
    /// # Examples
    ///
    /// Demagun direktorio berean bi fitxategi daudela eduki hauekin:
    ///
    /// 'monkeys.in' fitxategia:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' fitxategia:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' konpilatu eta ondorioz bitarra exekutatzean "🙈🙊🙉🙈🙊🙉" inprimatuko da.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Adierazpen boolear bat `true` dela exekuzio garaian baieztatzen du.
    ///
    /// Honek [`panic!`] makroa deituko du baldin eta emandako adierazpena exekuzio garaian `true` ra ebaluatu ezin bada.
    ///
    /// # Uses
    ///
    /// Baieztapenak beti arazten eta askatzen diren bertsioetan egiaztatzen dira eta ezin dira desgaitu.
    /// Ikusi [`debug_assert!`] bertsio lehenetsietan gaituta ez dauden baieztapenak.
    ///
    /// Kode ez segurua `assert!`-n oinarrituta egon daiteke exekuzio garaiko aldaerak indarrean jartzeko, baldin eta urratzen bada segurtasunik eza sor dezakete.
    ///
    /// `assert!`-ren beste erabilera-kasu batzuen artean, exekuzio-denbora aldaezinak kode seguruan (horien urraketak ezin du segurtasunik eragin) probatzea eta betearaztea.
    ///
    ///
    /// # Pertsonalizatutako mezuak
    ///
    /// Makro honek bigarren inprimakia du, non panic mezu pertsonalizatua eman daiteke formateatzeko argumentuekin edo gabe.
    /// Ikus [`std::fmt`] inprimaki honen sintaxia.
    /// Formatu argumentu gisa erabilitako esamoldeak baieztapenak huts egiten badu soilik ebaluatuko dira.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // baieztapen hauetarako panic mezua emandako adierazpenaren balio kordatua da.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // oso funtzio sinplea
    ///
    /// assert!(some_computation());
    ///
    /// // baieztatu mezu pertsonalizatu batekin
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Lineako muntaia.
    ///
    /// Irakurri [unstable book] erabilera.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM estiloko lineako muntaia.
    ///
    /// Irakurri [unstable book] erabilera.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modulu mailako lineako muntaia.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Inprimaketak tokens pasatu dira irteera estandarrera.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Beste makro batzuk arazteko erabilitako trazaduraren funtzionalitatea gaitzen edo desgaitzen du.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro eratorriak aplikatzeko erabilitako makroa.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funtzio bati aplikatutako atributu makroa proba unitario bihurtzeko.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Funtzio bati aplikatutako atributu makroa erreferentziako proba bihurtzeko.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` eta `#[bench]` makroen inplementazio xehetasuna.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Estatiko bati aplikatutako atributu makroa esleitzaile global gisa erregistratzeko.
    ///
    /// Ikus [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ere.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Pasatutako bidea eskuragarria bada aplikatzen zaion elementua gordetzen du eta bestela kentzen du.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Aplikatutako kode zatiko `#[cfg]` eta `#[cfg_attr]` atributu guztiak zabaltzen ditu.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ez erabili `rustc` konpilatzailearen ezarpenaren xehetasun ezegonkorra.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ez erabili `rustc` konpilatzailearen ezarpenaren xehetasun ezegonkorra.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}