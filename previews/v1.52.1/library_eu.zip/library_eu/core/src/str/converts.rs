//! Byte zatitik `str` bat sortzeko moduak.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Byte zati bat kate zati bihurtzen du.
///
/// ([`&str`]) kate zati bat ([`u8`]) bytez osatuta dago eta ([`&[u8]`][byteslice]) byte zati bat bytez osatuta dago, beraz, funtzio hau bien artean bihurtzen da.
/// Byte zati guztiak ez dira baliozko kate zatiak, hala ere: [`&str`]-k UTF-8 baliozkoa izatea eskatzen du.
/// `from_utf8()` byteek UTF-8 balio dutela egiaztatzen du eta gero bihurketa egiten du.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Byte zatiak UTF-8 balio duela ziurtatzen baduzu eta ez baduzu baliozko egiaztapenaren gaineko gasturik jasan nahi, funtzio honen bertsio segurua da, [`from_utf8_unchecked`], portaera bera duena baina egiaztapena saltzen duena.
///
///
/// `String` beharrean `String` behar baduzu, kontuan hartu [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// `[u8; N]` bat pila daitekeenez eta [`&[u8]`][byteslice] bat har dezakezunez, funtzio hau pila esleitutako katea izateko modu bat da.Honen adibide bat beheko adibideen atalean dago.
///
/// [byteslice]: slice
///
/// # Errors
///
/// `Err` itzultzen du xerra UTF-8 ez bada, emandako xerra zergatik ez den UTF-8 azaltzen duen deskribapenarekin.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::str;
///
/// // byte batzuk, vector batean
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Jakin badakigu byte hauek baliozkoak direla, beraz, erabili `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Okerreko byte-ak:
///
/// ```
/// use std::str;
///
/// // byte baliogabe batzuk, vector batean
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Itzuli daitezkeen errore moten xehetasun gehiago ikusteko [`Utf8Error`] dokumentuak ikusi.
///
/// "stack allocated string" bat:
///
/// ```
/// use std::str;
///
/// // byte batzuk, pilak esleitutako array batean
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Jakin badakigu byte hauek baliozkoak direla, beraz, erabili `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURTASUNA: Balidazioa besterik ez da egin.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Byte-zati alda daitekeen kate alda daiteke.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" vector aldagarri gisa
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Byte hauek baliozkoak direnez, `unwrap()` erabil dezakegu
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Okerreko byte-ak:
///
/// ```
/// use std::str;
///
/// // vector aldakorreko byte baliogabe batzuk
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Itzuli daitezkeen errore moten xehetasun gehiago ikusteko [`Utf8Error`] dokumentuak ikusi.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURTASUNA: Balidazioa besterik ez da egin.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Byte zati bat kate zati bihurtzen du kateak baliozko UTF-8 duela egiaztatu gabe.
///
/// Informazio gehiagorako, ikusi bertsio segurua, [`from_utf8`].
///
/// # Safety
///
/// Funtzio hau ez da segurua, ez baitu egiaztatzen hari igaritako byteek UTF-8 balio dutenik.
/// Muga hau urratzen bada, zehaztu gabeko portaera sortzen da, gainerako Rust-k suposatzen baitu [`&str`] s UTF-8 baliozkoak direla.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::str;
///
/// // byte batzuk, vector batean
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEGURTASUNA: deitzaileak `v` byteek UTF-8 balio dutela bermatu behar du.
    // Era berean, `&str` eta `&[u8]` diseinu bera edukitzeaz gain oinarritzen da.
    unsafe { mem::transmute(v) }
}

/// Byte zati bat kate zati bihurtzen du kateak baliozko UTF-8 duela egiaztatu gabe;bertsio aldakorra.
///
///
/// Informazio gehiagorako ikusi [`from_utf8_unchecked()`] bertsio aldaezina.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEGURTASUNA: deitzaileak `v` byteek bermatu behar dute
    // baliozko UTF-8 dira, beraz, `*mut str`-ra igortzea segurua da.
    // Era berean, erakuslearen desreferentzia segurua da, erakusle hori idazketetarako balio duela bermatzen den erreferentzia batetik datorrelako.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}