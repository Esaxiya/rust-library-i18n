//! Katea Pattern APIa.
//!
//! Eredu APIak kate bidez bilaketak egitean eredu desberdinak erabiltzeko mekanismo generikoa eskaintzen du.
//!
//! Xehetasun gehiago lortzeko, ikusi traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] eta [`DoubleEndedSearcher`].
//!
//! API hau ezegonkorra bada ere, [`str`] motako API egonkorren bidez azaltzen da.
//!
//! # Examples
//!
//! [`Pattern`] [implemented][pattern-impls] da API egonkorrean [`&str`][`str`], [`char`], [`char`] zatiak eta `FnMut(char) -> bool` ezartzen duten funtzioak eta itxierak.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char eredua
//! assert_eq!(s.find('n'), Some(2));
//! // karaktereen xerra
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // itxiera eredua
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Kate eredu bat.
///
/// `Pattern<'a>` batek adierazten du ezarpen mota [`&'a str`][str] batean bilatzeko kate eredu gisa erabil daitekeela.
///
/// Adibidez, `'a'` eta `"aa"` bai X003 katean `1` indizean bat etorriko liratekeen ereduak dira.
///
/// trait-k berak lotutako [`Searcher`] motaren eraikitzaile gisa funtzionatzen du, eta horrek katea batean ereduaren agerraldiak aurkitzeko benetako lana egiten du.
///
///
/// Eredu motaren arabera, [`str::find`] eta [`str::contains`] bezalako metodoen portaera alda daiteke.
/// Beheko taulan jokabide horietako batzuk deskribatzen dira.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Eredu honen bilatzaile elkartua
    type Searcher: Searcher<'a>;

    /// Bilatutako erlazionatutako bilatzailea `self` eta `haystack`-tik eraikitzen du.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Egiaztatzen du eredua biltegiko edozein lekutan bat datorren
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Egiaztatu eredua belar zuloaren aurrealdean bat datorren egiaztatzen du
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Egiaztatu eredua belar-atzeko aldean bat datorren egiaztatzen du
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Eredua haystackaren aurrealdetik kentzen du, bat badator.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SEGURTASUNA: `Searcher`-k balio duen indizeak itzultzen ditu.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Eredua haystack-aren atzealdetik kentzen du, bat badator.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SEGURTASUNA: `Searcher`-k balio duen indizeak itzultzen ditu.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] edo [`ReverseSearcher::next_back()`] deitzearen emaitza.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// `haystack[a..b]`-n ereduaren parekatze bat aurkitu dela adierazten du.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` ereduaren balizko bat etortzeari uko egin zaiola adierazten du.
    ///
    /// Kontuan izan `Reject` bat baino gehiago egon daitezkeela bi `Match`en artean, ez dago baldintza bakarrean konbinatzeko.
    ///
    ///
    Reject(usize, usize),
    /// Belar-biltegiaren byte bakoitza bisitatu dela adierazten du, errepikapena amaituz.
    ///
    Done,
}

/// Kate eredu baten bilatzailea.
///
/// trait honek kate baten aurreko (left)-tik hasita eredu baten gainjarri gabeko partidak bilatzeko metodoak eskaintzen ditu.
///
/// [`Pattern`] trait-ren lotutako `Searcher` motek inplementatuko dute.
///
/// trait ez da segurua markatzen, [`next()`][Searcher::next] metodoek itzultzen dituzten indizeak behar bezala behar baitira biltegian utf8 baliozko mugetan egoteko.
/// Horri esker, trait honen kontsumitzaileek belarra moztu dezakete exekuzio garaiko kontrolik gabe.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter bilatu nahi den azpiko katea lortzeko
    ///
    /// Beti itzuliko da [`&str`][str] bera.
    fn haystack(&self) -> &'a str;

    /// Hurrengo bilaketa-urratsa aurrealdetik hasita egiten du.
    ///
    /// - [`Match(a, b)`][SearchStep::Match] ematen du `haystack[a..b]` ereduarekin bat badator.
    /// - [`Reject(a, b)`][SearchStep::Reject] itzultzen du `haystack[a..b]` ereduarekin bat etorri ezin bada, partzialki ere.
    /// - [`Done`][SearchStep::Done] itzultzen du biltegiaren byte bakoitza bisitatu bada.
    ///
    /// [`Done`][SearchStep::Done] arteko [`Match`][SearchStep::Match] eta [`Reject`][SearchStep::Reject] balioen korronteak ondoko indize barrutiak edukiko ditu, gainjartzen ez direnak, haystack osoa estaltzen dutenak eta utf8 mugak finkatzen dituztenak.
    ///
    ///
    /// [`Match`][SearchStep::Match] emaitzak bat datorren eredu osoa eduki behar du, hala ere, [`Reject`][SearchStep::Reject] emaitzak aldameneko zati askotan banatu daitezke.Bi barrutiek zero luzera izan dezakete.
    ///
    /// Adibide gisa, `"aaa"` patroiak eta `"cbaaaaab"` biltegirak korrontea sor dezakete
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Hurrengo [`Match`][SearchStep::Match] emaitza aurkitzen du.Ikus [`next()`][Searcher::next].
    ///
    /// [`next()`][Searcher::next]-k ez bezala, ez dago bermatutako honen eta [`next_reject`][Searcher::next_reject]-ren barrutiak gainjarriko direnik.
    /// Honek `(start_match, end_match)` itzuliko du, non start_match partida hasten deneko aurkibidea den eta end_match partida amaitu ondoren aurkibidea den.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Hurrengo [`Reject`][SearchStep::Reject] emaitza aurkitzen du.Ikus [`next()`][Searcher::next] eta [`next_match()`][Searcher::next_match].
    ///
    /// [`next()`][Searcher::next]-k ez bezala, ez dago bermatutako honen eta [`next_match`][Searcher::next_match]-ren barrutiak gainjarriko direnik.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Kate eredu baten alderantzizko bilatzailea.
///
/// trait honek kate baten atzeko (right)-tik hasita eredu baten gainjarri gabeko partidak bilatzeko metodoak eskaintzen ditu.
///
/// [`Pattern`] trait-ren lotutako [`Searcher`] motek inplementatuko dute ereduak atzeko aldetik bilatzea onartzen badu.
///
///
/// trait honek itzultzen dituen indize barrutiak ez dira alderantzizko bilaketa aurreratuarekin bat etorri behar.
///
/// trait hau ez dela segurua dela eta, ikusi trait [`Searcher`] guraso.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Atzetik hasita hurrengo bilaketa-urratsa egiten du.
    ///
    /// - [`Match(a, b)`][SearchStep::Match] ematen du `haystack[a..b]` ereduarekin bat badator.
    /// - [`Reject(a, b)`][SearchStep::Reject] itzultzen du `haystack[a..b]` ereduarekin bat etorri ezin bada, partzialki ere.
    /// - [`Done`][SearchStep::Done] itzultzen du biltegiaren byte bakoitza bisitatu bada
    ///
    /// [`Done`][SearchStep::Done] arteko [`Match`][SearchStep::Match] eta [`Reject`][SearchStep::Reject] balioen korronteak ondoko indize barrutiak edukiko ditu, gainjartzen ez direnak, haystack osoa estaltzen dutenak eta utf8 mugak finkatzen dituztenak.
    ///
    ///
    /// [`Match`][SearchStep::Match] emaitzak bat datorren eredu osoa eduki behar du, hala ere, [`Reject`][SearchStep::Reject] emaitzak aldameneko zati askotan banatu daitezke.Bi barrutiek zero luzera izan dezakete.
    ///
    /// Adibide gisa, `"aaa"` patroiak eta `"cbaaaaab"` biltegirak `[Reject(7, 8), Match(4, 7), Reject(1, 4), korrontea sor dezakete. Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Hurrengo [`Match`][SearchStep::Match] emaitza aurkitzen du.
    /// Ikus [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Hurrengo [`Reject`][SearchStep::Reject] emaitza aurkitzen du.
    /// Ikus [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// trait markatzailea [`ReverseSearcher`] [`DoubleEndedIterator`] inplementazio baterako erabil daitekeela adierazteko.
///
/// Horretarako, [`Searcher`] eta [`ReverseSearcher`] aplikazioek baldintza hauek bete behar dituzte:
///
/// - `next()`-ren emaitza guztiek alderantzizko ordenan `next_back()`-ren emaitzen berdina izan behar dute.
/// - `next()` eta `next_back()`-k balio-tarte baten bi muturretan jokatu behar dute, hau da, ezin dute "walk past each other".
///
/// # Examples
///
/// `char::Searcher` `DoubleEndedSearcher` bat da, [`char`] bilatzeak aldi berean begiratzea bakarrik eskatzen baitu, bi muturretatik berdin jokatzen baita.
///
/// `(&str)::Searcher` ez da `DoubleEndedSearcher` bat, `"aaa"` biltegiko `"aa"` eredua `"[aa]a"` edo `"a[aa]"` bezalakoa delako, zein aldetatik bilatzen den kontuan hartuta.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl char
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` rentzako lotutako mota.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // segurtasun aldaezina: `finger`/`finger_back` baliozko utf8 byte indizea izan behar da `haystack`-en. Aldaera hau *hautsi daiteke* next_match eta next_match_back barruan, hala ere, hatzekin atera behar dute baliozko kode puntuen mugetan.
    //
    //
    /// `finger` Aurrera egindako bilaketaren uneko byte indizea da.
    /// Imajinatu bere indizean byte aurretik dagoela, alegia
    /// `haystack[finger]` Aurrera bilaketak egitean ikuskatu behar dugun zatiaren lehen byta da
    ///
    finger: usize,
    /// `finger_back` alderantzizko bilaketaren uneko byte indizea da.
    /// Imajinatu bere indizean byte-ren ondoren badagoela, alegia
    /// haystack [finger_back, 1] da aurrerantz bilaketan zehar ikuskatu behar dugun zatiaren azken byta (eta, beraz, next_back()) deitzerakoan ikuskatu behar den lehen byta.
    ///
    finger_back: usize,
    /// Bilatzen ari den pertsonaia
    needle: char,

    // segurtasun aldaezina: `utf8_size`-k 5 baino txikiagoa izan behar du
    /// `needle` byte kopurua hartzen du utf8 kodetuta dagoenean.
    utf8_size: usize,
    /// `needle` ren utf8 kodetutako kopia
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SEGURTASUNA: 1-4 `get_unchecked` segurtasuna bermatzen du
        // 1. `self.finger` eta `self.finger_back` unicode mugetan mantentzen dira (aldaezina da)
        // 2. `self.finger >= 0` 0-tik hasi eta handitu baino ez baita egiten
        // 3. `self.finger < self.finger_back` zeren bestela `iter` karak `SearchStep::Done` itzuliko luke
        // 4.
        // `self.finger` haystack amaitu baino lehen dator `self.finger_back` amaieran hasten delako eta gutxitzen delako
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // gehitu uneko karakterearen byte desplazamendua utf-8 gisa berriro kodifikatu gabe
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // lortu lastoa topatutako azken pertsonaiaren ondoren
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 kodetutako orratzaren azken byta SEGURTASUNA: `utf8_size < 5` hori aldaezina dugu
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Hatz berria aurkitu dugun bytearen aurkibidea da, gehi bat, pertsonaiaren azken bytearena egin baitugu.
                //
                // Kontuan izan horrek ez duela beti hatz bat ematen UTF8 mugan.
                // *Karaktere hau* aurkitu ez bagenu agian 3 byteko edo 4 byteko karaktere baten azken ez den byte batera indexatuta egongo gara.
                // Ezin dugu hurrengo hasierako baliozko hasierako bytera salto egin, ꁁ (U + A041 YI SILABA PA) bezalako karaktere batek, utf-8 `EA 81 81`-k hirugarrenaren bila aritzerakoan, beti, bigarren byta aurkitu dezagun.
                //
                //
                // Hala ere, guztiz ondo dago.
                // self.finger UTF8 mugan dagoen aldaezina dugun arren, aldaera hori ez da metodo honen barruan oinarritzen (CharSearcher::next()) n oinarritzen da.
                //
                // Kate honen amaierara iristen garenean edo zerbait aurkitzen dugunean bakarrik irtengo gara metodo honetatik.Zerbait aurkitzen dugunean `finger` UTF8 muga ezarriko da.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ez dut ezer aurkitu, irten
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // utzi next_reject-ek inplementazio lehenetsia erabiltzen Searcher trait-tik
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SEGURTASUNA: ikusi goiko next() ren iruzkina
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // kendu uneko karakterearen byte desplazamendua utf-8 gisa berriro kodifikatu gabe
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // lortu belar-bilketa baina bilatutako azken pertsonaia barne
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 kodetutako orratzaren azken byta SEGURTASUNA: `utf8_size < 5` hori aldaezina dugu
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // self.finger-ek konpentsatutako zati bat bilatu dugu, self.finger gehitu jatorrizko indizea berreskuratzeko
                //
                let index = self.finger + index;
                // memrchr-k aurkitu nahi dugun bytearen aurkibidea itzuliko du.
                // ASCII karaktere baten kasuan, hau da, hain zuzen ere, gure hatz berria izatea nahi badugu ("after" alderantzizko iterazioaren paradigman aurkitutako karakterea).
                //
                // Multibyte karaktereetarako ASCII baino byte gehiagoren kopurua jaitsi behar dugu
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mugitu hatza aurkitutako karakterearen aurretik (hau da, hasierako aurkibidean)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Hemen ezin dugu finger_back=index, tamaina + 1 erabili.
                // Tamaina desberdinetako karaktere baten azken karakterea (edo beste karaktere baten erdiko byta) aurkitzen badugu, hatz_atzera `index`-ra jaitsi behar dugu.
                // Horrek, era berean, `finger_back`-k mugan ez egoteko aukera du, baina hori ondo dago funtzio honetatik mugatik irten edo haystack-a guztiz bilatu denean.
                //
                //
                // Next_match-ek ez bezala, honek ez du utf-8-n errepikatutako byteen arazorik, azken byta bilatzen ari garelako, eta alderantzizko bilaketan soilik aurki dezakegulako azken byta.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ez dut ezer aurkitu, irten
                return None;
            }
        }
    }

    // utzi next_reject_back-ek inplementazio lehenetsia erabiltzen Searcher trait-tik
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// [`char`] jakin baten berdinak diren karaktereak bilatzen ditu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq biltzeko inplikazioa
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Konparatu barneko byte xerra iteratzailearen luzerak uneko karaktereen luzera aurkitzeko
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Konparatu barneko byte xerra iteratzailearen luzerak uneko karaktereen luzera aurkitzeko
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[Char]-entzako inplikazioa
/////////////////////////////////////////////////////////////////////////////

// Todo: Aldatu/Kendu esanahiaren anbiguotasunagatik.

/// `<&[char] as Pattern<'a>>::Searcher`-erako mota elkartua.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Xerran dauden [`karaktere] edozeinen berdinak diren karaktereak bilatzen ditu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F inplikazioa: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` rentzako lotutako mota.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Emandako predikatuarekin bat datozen [`char`]-ak bilatzen ditu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Inpl.&&str
/////////////////////////////////////////////////////////////////////////////

/// `&str` inplikatuko delegatuak.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Inpl. &str-rako
/////////////////////////////////////////////////////////////////////////////

/// Azpikatearen bilaketa ez esleitzea.
///
/// `""` eredua maneiatuko du karaktere muga bakoitzean partida hutsak itzultzen dituela.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Egiaztatu eredua belar zuloaren aurrealdean bat datorren egiaztatzen du.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Eredua haystackaren aurrealdetik kentzen du, bat badator.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SEGURTASUNA: aurrizkia existitzen dela egiaztatu berri da.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Egiaztatu eredua belar-atzeko aldean bat datorren egiaztatzen du.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Eredua haystack-aren atzealdetik kentzen du, bat badator.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SEGURTASUNA: atzizkia existitzen dela egiaztatu berri da.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Bi norabideko azpikaten bilatzailea
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher`-erako mota elkartua.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // orratz hutsak karaktere guztiak baztertzen ditu eta haien arteko kate huts guztiak bat dator
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher-ek karaktereen mugetan banatzen diren baliozko *Match* indizeak sortzen ditu, betiere bat etortzea zuzena bada eta haystack eta orratza baliozkoak diren UTF-8 *Algoritmoaren* errefusak edozein indizetan erori daitezke, baina eskuz joango gara hurrengo karakterearen mugara. , utf-8 seguruak izan daitezen.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // joan hurrengo karaktere mugara
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // idatzi `true` eta `false` kasuak konpiladoreak bi kasuak bereizita espezializatzera bultzatzeko.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // joan hurrengo karaktere mugara
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // idatzi `true` eta `false`, `next_match` bezala
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Bi noranzkoetako katearen bilaketa algoritmoaren barne egoera.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// faktorizazio kritikoaren indizea
    crit_pos: usize,
    /// alderantzizko orratzaren faktorizazio kritikoaren indizea
    crit_pos_back: usize,
    period: usize,
    /// `byteset` luzapena da (ez da bi norabideko algoritmoaren parte);
    /// 64 bit-eko "fingerprint" bat da, `j` multzo bakoitzeko bit bakoitzari orratzan dagoen (byte eta 63)==j dagokiona.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// aurkibidea orratz sartu aurretik jada bat egin dugun
    memory: usize,
    /// aurkibidea orratz sartu eta ondoren dagoeneko bat egin dugu
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Hemen gertatzen denaren azalpen bereziki irakurgarria Crochemore eta Rytter-en "Text Algorithms" liburuan, 13. kap.
        // Zehazki ikusi "Algorithm CP" ren kodea orrialdean.
        // 323.
        //
        // Gertatzen ari dena da orratzaren faktorizazio kritikoa dugula (u, v), eta u zehaztu nahi dugu ea&v [.. periodoa] atzizkia den.
        // Bada, "Algorithm CP1" erabiltzen dugu.
        // Bestela "Algorithm CP2" erabiltzen dugu, orratzaren aldia handia denean optimizatuta dagoena.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // epe laburreko kasua-epea zehatza da kalkulatu faktorizazio kritiko bereizia alderantzizko orratzerako x=u 'v' non | v '|<period(x).
            //
            // Hori azkartzen da dagoeneko ezagutzen den aldiarekin.
            // Kontuan izan x= "acba" bezalako kasu bat zehatz-mehatz aitzinera jo daitekeela (crit_pos=1, period=3) alderantzizko gutxi gorabeherako aldiarekin (critic_pos=2, period=2).
            // Emandako alderantzizko faktorizazioa erabiltzen dugu baina aldi zehatza mantentzen dugu.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // aldi luzeko kasua-benetako aldiaren hurbilketa dugu eta ez dugu memorizaziorik erabiltzen.
            //
            //
            // Gutxi gorabeherako epea max(|u|, |v|) + 1 beheko mugarekin.
            // Faktorizazio kritikoa eraginkorra da aurrera nahiz atzerako bilaketetarako erabiltzeko.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Epea luzea dela adierazteko balio manikorra
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Bi noranzkoaren ideia nagusietako bat da orratza bi erditan faktorizatzen dugula, (u, v), eta ha biltegian v bilatzen saiatzen hasten garela ezkerretik eskuinera eskaneatuz.
    // V bat badator, uarekin bat egiten saiatuko gara eskuinetik ezkerrera eskaneatuz.
    // Desoreka bat topatzen dugunean noraino salto egin dezakegun oinarritzen da (u, v) orratzaren faktorizazio kritikoa dela.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` erabiltzen du kurtsore gisa
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Egiaztatu posizioan bilatzeko tokia dugula + orratz_azkenak ezin duela gainezka egin zatiak isize barrutiaren arabera mugatuta daudela suposatzen badugu.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Saltatu bizkor gure azpikatearekin zerikusirik ez duten zati handien bidez
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Ikusi orratzaren eskuineko partea bat datorren
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Ikusi orratzaren ezkerraldea bat datorren
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Partida bat aurkitu dugu!
            let match_pos = self.position;

            // Note: gehitu self.period needle.len() ordez, partida gainjarriak izateko
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ezarri needle.len(), self.period gisa gainjarritako partidetarako
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()`-eko ideiak jarraitzen ditu.
    //
    // Definizioak simetrikoak dira, period(x) = period(reverse(x)) eta local_period(u, v) = local_period(reverse(v), reverse(u)), beraz (u, v) faktorizazio kritikoa bada, (reverse(v) ere bada, reverse(u)).
    //
    //
    // Alderantzizko kasuan x=u 'v' faktorizazio kritikoa kalkulatu dugu (`crit_pos_back` eremua).| U | behar dugu<period(x) aurrerako kasuan eta, beraz, | v '|<period(x) alderantzizkoa.
    //
    // Biltegian alderantzizko bilaketa egiteko, alderantzizko biltegian zehar bilatuko dugu alderantzizko orratzarekin, lehenengo u 'eta gero v' bat datozenekin.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` erabiltzen du kurtsore gisa-`next()` eta `next_back()` independenteak izan daitezen.
        //
        let old_end = self.end;
        'search: loop {
            // Egiaztatu azkenean bilatzeko tartea badugula, needle.len() biltegiratuko da toki gehiago ez dagoenean, baina zatien luzera mugak direla eta ezin du inoiz itzulera osoa biltegira eraman.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Saltatu bizkor gure azpikatearekin zerikusirik ez duten zati handien bidez
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Ikusi orratzaren ezkerraldea bat datorren
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Ikusi orratzaren eskuineko partea bat datorren
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Partida bat aurkitu dugu!
            let match_pos = self.end - needle.len();
            // Note: azpi self.period ordez needle.len() ordez jokoak gainjarriak izateko
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Kalkulatu `arr` ren atzizki maximoa.
    //
    // Atzizki maximoa `arr`-ren faktore kritiko posible bat (u, v) da.
    //
    // Buelta ematen du (`i`, `p`) non `i` v-ren hasierako indizea den eta `p` v-ren periodoa den.
    //
    // `order_greater` orden lexikoa `<` edo `>` den zehazten du.
    // Bi aginduak kalkulatu behar dira-`i` handiena duen ordenatzeak faktorizazio kritikoa ematen du.
    //
    //
    // Epe luzeko kasuetarako, ondorioz lortutako epea ez da zehatza (laburregia da).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Paperean i-rekin bat dator
        let mut right = 1; // Paperean j-i dagokio
        let mut offset = 0; // Paperean k-rekin bat dator, baina 0-tik hasita
        // 0 oinarritutako indexazioarekin bat etortzeko.
        let mut period = 1; // Paperean p-ri dagokio

        while let Some(&a) = arr.get(right + offset) {
            // `left` sarrerak izango dira `right` dagoenean.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Atzizkia txikiagoa da, puntua aurrizki osoa da orain arte.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Aurreratu uneko aldia errepikatuz.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Atzizkia handiagoa da, hasi berriro uneko kokapenetik.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Kalkulatu `arr` alderantzizko atzizki maximoa.
    //
    // Atzizki maximoa `arr`-ren faktore kritiko posible bat (u ', v') da.
    //
    // `i` ematen du non `i` v 'hasierako indizea den, atzeko aldetik;
    // berehala itzultzen da `known_period` aldia iristen denean.
    //
    // `order_greater` orden lexikoa `<` edo `>` den zehazten du.
    // Bi aginduak kalkulatu behar dira-`i` handiena duen ordenatzeak faktorizazio kritikoa ematen du.
    //
    //
    // Epe luzeko kasuetarako, ondorioz lortutako epea ez da zehatza (laburregia da).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Paperean i-rekin bat dator
        let mut right = 1; // Paperean j-i dagokio
        let mut offset = 0; // Paperean k-rekin bat dator, baina 0-tik hasita
        // 0 oinarritutako indexazioarekin bat etortzeko.
        let mut period = 1; // Paperean p-ri dagokio
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Atzizkia txikiagoa da, puntua aurrizki osoa da orain arte.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Aurreratu uneko aldia errepikatuz.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Atzizkia handiagoa da, hasi berriro uneko kokapenetik.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy-k algoritmoari ez datozen partidak ahalik eta azkarren saltatzeko edo Errefusak nahiko azkar igortzen dituen moduan lan egiteko aukera ematen dio.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Saltatu tarteak parekatzeko ahalik eta azkarren
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Igorri errefusak aldizka
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}