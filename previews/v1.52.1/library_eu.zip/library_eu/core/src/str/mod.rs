//! Soken manipulazioa.
//!
//! Xehetasun gehiagorako, ikusi [`std::str`] modulua.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. mugetatik kanpo
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. hasi <=amaitu
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. pertsonaiaren muga
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // pertsonaia aurkitu
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` len baino txikiagoa izan behar du eta char muga
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self`-ren luzera ematen du.
    ///
    /// Luzera hau byteetan dago, ez [`char`] edo grafemetan.
    /// Beste modu batera esanda, agian ez da gizakiak katearen luzera jotzen duena.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` ematen du `self`-k zero byteko luzera badu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Egiaztatzen du `index`-garren byta UTF-8 kode puntuen sekuentziako edo katearen amaierako lehen byta dela.
    ///
    ///
    /// Katearen hasiera eta amaiera (`index== self.len()`) mugak direla jotzen denean.
    ///
    /// `false` ematen du `index` `self.len()` baino handiagoa bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老`-ren hasiera
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö`-ren bigarren byta
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老`-ren hirugarren byta
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 eta len beti daude ondo.
        // Probatu 0 esplizituki, egiaztapena erraz optimizatzeko eta kasu horretarako kateen datuak irakurtzen saltatzeko.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Hau bit bitaren baliokidea da: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Kate zati bat byte zati bihurtzen du.
    /// Byte-xerra berriro kate-xerra bihurtzeko, erabili [`from_utf8`] funtzioa.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SEGURTASUNA: konst soinua diseinu bereko bi mota transmutatzen ditugulako
        unsafe { mem::transmute(self) }
    }

    /// Katea alda daitekeen zati bat byte alda daitekeen zati bat bihurtzen du.
    ///
    /// # Safety
    ///
    /// Deitzaileak zatiaren edukia UTF-8 baliozkoa dela ziurtatu behar du mailegua amaitu eta azpiko `str` erabili aurretik.
    ///
    ///
    /// Edukia baliozkoa ez duen `str` erabiltzea UTF-8 erabiltzea zehaztu gabeko portaera da.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SEGURTASUNA: `&str`-tik `&[u8]`-ra igotzea segurua da `str`-tik aurrera
        // `&[u8]`-ren diseinu bera du (libstd-ek bakarrik egin dezake berme hau).
        // Erakuslearen desreferentzia segurua da, idazketetarako baliozkoa den bermatutako erreferentzia aldagarri batetik datorrelako.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Kate zati bat erakusle gordin bihurtzen du.
    ///
    /// Kate zatiak byte zati bat direnez, erakusle gordinak [`u8`] seinalatzen du.
    /// Erakusle honek kate zatiaren lehen byta seinalatuko du.
    ///
    /// Deitzaileak ziurtatu behar du itzultzen den erakuslea inoiz idatzita ez dagoela.
    /// Kate-zatiaren edukia mutatu behar baduzu, erabili [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Alda daitekeen kate zati bat erakusle gordin bihurtzen du.
    ///
    /// Kate zatiak byte zati bat direnez, erakusle gordinak [`u8`] seinalatzen du.
    /// Erakusle honek kate zatiaren lehen byta seinalatuko du.
    ///
    /// Zure erantzukizuna da ziurtatzea kateen zatiak UTF-8 baliozkoa izateko moduan soilik aldatzen direla ziurtatzea.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` azpiatala itzultzen du.
    ///
    /// Hau da `str` indexatzeko alternatiba ez izutzeko aukera.
    /// [`None`] itzultzen du indexazio eragiketa baliokidea panic egingo lukeen bakoitzean.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // UTF-8 sekuentzia mugetan ez dauden indizeak
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // mugetatik kanpo
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` azpiatal aldakorra itzultzen du.
    ///
    /// Hau da `str` indexatzeko alternatiba ez izutzeko aukera.
    /// [`None`] itzultzen du indexazio eragiketa baliokidea panic egingo lukeen bakoitzean.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // luzera zuzena
    /// assert!(v.get_mut(0..5).is_some());
    /// // mugetatik kanpo
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Egiaztatu gabeko `str` azpiatala itzultzen du.
    ///
    /// Hau da `str` indexatzeko alternatiba kontrolik gabea.
    ///
    /// # Safety
    ///
    /// Funtzio horretako deitzaileek erantzuten dute baldintza hauek betetzen direla:
    ///
    /// * Hasierako indizeak ez du amaierako indizea gainditu behar;
    /// * Indizeek jatorrizko zatiaren mugen barruan egon behar dute;
    /// * Indizeek UTF-8 sekuentzia mugetan egon behar dute.
    ///
    /// Hori egin ezean, itzulitako kate zatiak memoria baliogabea aipa dezake edo `str` motak komunikatutako aldaerak urratu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SEGURTASUNA: deitzaileak `get_unchecked`-rako segurtasun kontratua onartu behar du;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str`-ren azpiatal aldakor eta kontrolagabea itzultzen du.
    ///
    /// Hau da `str` indexatzeko alternatiba kontrolik gabea.
    ///
    /// # Safety
    ///
    /// Funtzio horretako deitzaileek erantzuten dute baldintza hauek betetzen direla:
    ///
    /// * Hasierako indizeak ez du amaierako indizea gainditu behar;
    /// * Indizeek jatorrizko zatiaren mugen barruan egon behar dute;
    /// * Indizeek UTF-8 sekuentzia mugetan egon behar dute.
    ///
    /// Hori egin ezean, itzulitako kate zatiak memoria baliogabea aipa dezake edo `str` motak komunikatutako aldaerak urratu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SEGURTASUNA: deitzaileak `get_unchecked_mut`-rako segurtasun kontratua onartu behar du;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Kate zati bat sortzen du beste kate zati batetik, segurtasun kontrolak alde batera utzita.
    ///
    /// Hau ez da orokorrean gomendagarria, erabili kontuz!Alternatiba segurua lortzeko, ikusi [`str`] eta [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Xerra berri hau `begin`-tik `end`-ra doa, `begin` barne baina `end` kenduta.
    ///
    /// Horren ordez alda daitekeen kate zati bat lortzeko, ikusi [`slice_mut_unchecked`] metodoa.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Funtzio horretako deitzaileek hiru aldez aurreko baldintzak betetzen direla erantzuten dute:
    ///
    /// * `begin` ez du `end` baino handiagoa izan behar.
    /// * `begin` eta `end` kate zatiaren barruan byte posizioak izan behar dira.
    /// * `begin` eta `end` UTF-8 sekuentzia mugetan egon behar da.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SEGURTASUNA: deitzaileak `get_unchecked`-rako segurtasun kontratua onartu behar du;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Kate zati bat sortzen du beste kate zati batetik, segurtasun kontrolak alde batera utzita.
    /// Hau ez da orokorrean gomendagarria, erabili kontuz!Alternatiba segurua lortzeko, ikusi [`str`] eta [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Xerra berri hau `begin`-tik `end`-ra doa, `begin` barne baina `end` kenduta.
    ///
    /// Kate ordezkaezin bat lortzeko, ikusi [`slice_unchecked`] metodoa.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Funtzio horretako deitzaileek hiru aldez aurreko baldintzak betetzen direla erantzuten dute:
    ///
    /// * `begin` ez du `end` baino handiagoa izan behar.
    /// * `begin` eta `end` kate zatiaren barruan byte posizioak izan behar dira.
    /// * `begin` eta `end` UTF-8 sekuentzia mugetan egon behar da.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SEGURTASUNA: deitzaileak `get_unchecked_mut`-rako segurtasun kontratua onartu behar du;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Banatu kate zati bat bitan indize batean.
    ///
    /// Argumentuak, `mid`, kate hasierako byte konpentsazioa izan beharko luke.
    /// UTF-8 kode puntu baten mugan ere egon behar du.
    ///
    /// Itzulitako bi zatiak kate zatiaren hasieratik `mid`-ra doaz eta `mid`-tik kate zatiaren amaierara.
    ///
    /// Katea alda daitezkeen zatiak lortzeko, ikusi [`split_at_mut`] metodoa.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics `mid` ez bada UTF-8 kode puntuen mugan edo kate zatiaren azken kodearen puntua amaituta badago.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary indizea [0,= .len()]
        if self.is_char_boundary(mid) {
            // SEGURTASUNA: egiaztatu besterik ez duzu `mid` karaktere mugan dagoela.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Banatu alda daitekeen kate zati bat bitan indize batean.
    ///
    /// Argumentuak, `mid`, kate hasierako byte konpentsazioa izan beharko luke.
    /// UTF-8 kode puntu baten mugan ere egon behar du.
    ///
    /// Itzulitako bi zatiak kate zatiaren hasieratik `mid`-ra doaz eta `mid`-tik kate zatiaren amaierara.
    ///
    /// Aldaezinak diren kate zatiak lortzeko, ikusi [`split_at`] metodoa.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics `mid` ez bada UTF-8 kode puntuen mugan edo kate zatiaren azken kodearen puntua amaituta badago.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary indizea [0,= .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SEGURTASUNA: egiaztatu besterik ez duzu `mid` karaktere mugan dagoela.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Iteratzaile bat itzultzen du kate zati baten [`char`] s-en gainean.
    ///
    /// Kate-zati bat UTF-8 balioz osatuta dagoenez, [`char`] bidez kate-zati baten bidez errepika dezakegu.
    /// Metodo honek iteratzaile hori itzultzen du.
    ///
    /// Garrantzitsua da gogoratzea [`char`]-k Unicode Scalar balioa adierazten duela eta agian ez datozela bat 'character' zer den zure ideiarekin.
    ///
    /// Baliteke grafema multzoen gaineko errepikapena benetan nahi duzuna izatea.
    /// Funtzionalitate hau Rust-ren liburutegi estandarrak ez du eskaintzen, egiaztatu crates.io ordez.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Gogoratu, baliteke [`char`] pertsonaiak ez datozela bat pertsonaiekin duzun intuizioarekin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ez 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Iteratzaile bat itzultzen du kate zati baten [`char`] s eta horien posizioen gainean.
    ///
    /// Kate-zati bat UTF-8 balioz osatuta dagoenez, [`char`] bidez kate-zati baten bidez errepika dezakegu.
    /// Metodo honek bi [`char`] horien iteratzailea itzultzen du, baita haien byteko posizioak ere.
    ///
    /// Iteratzaileak tupluak ematen ditu.Posizioa lehenengoa da, [`char`] bigarrena.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Gogoratu, baliteke [`char`] pertsonaiak ez datozela bat pertsonaiekin duzun intuizioarekin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ez (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // kontuan hartu 3 hemen, azken pertsonaiak bi byte hartu zituen
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Kate baten zatiaren byteen gaineko iteratzailea.
    ///
    /// Kate zati bat byte sekuentziaz osatuta dagoenez, kate zati bat byte bidez errepika dezakegu.
    /// Metodo honek iteratzaile hori itzultzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Kate zati bat zuriunearen arabera zatitzen du.
    ///
    /// Itzultzaileak itzultzen du jatorrizko kate zatiaren azpi-zatiak diren kate zatiak itzuliko ditu, edozein zuriune kopuruarekin bereizita.
    ///
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    /// ASCII zuriuneetan soilik zatitu nahi baduzu, erabili [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Era guztietako zuriuneak hartzen dira kontuan:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Kate zati bat ASCII zuriunearen arabera zatitzen du.
    ///
    /// Itzultzaileak itzultzen du jatorrizko kate zatiaren azpi-zatiak diren kate zatiak itzuliko dituena, ASCII zuriune kopuruarekin bereizita.
    ///
    ///
    /// Unicode `Whitespace` bidez zatitzeko, erabili [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII espazio mota guztiak hartzen dira kontuan:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Kate baten lerroen gaineko iteratzailea, kate zatiak bezala.
    ///
    /// Lerroak (`\n`) linea berriarekin edo (`\r\n`) lineako jarioarekin itzulgunearekin amaitzen dira.
    ///
    /// Azken lerroko amaiera hautazkoa da.
    /// Azken lerro amaierarekin amaitzen den kate batek kate berdin berdinaren lerro berdinak itzuliko ditu azken lerro amaiera gabe.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Azken lerro amaiera ez da beharrezkoa:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Kate baten lerroen gaineko iteratzailea.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// `u16`-ren iteratzailea itzultzen du UTF-16 gisa kodetutako katearen gainean.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// `true` itzultzen du emandako eredua kate zati horren azpi-zati batekin bat badator.
    ///
    /// `false` itzultzen du hala ez bada.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// `true` ematen du emandako eredua kate zatiaren aurrizkiarekin bat badator.
    ///
    /// `false` itzultzen du hala ez bada.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// `true` ematen du emandako eredua kate zati horren atzizkiarekin bat badator.
    ///
    /// `false` itzultzen du hala ez bada.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Ereduarekin bat datorren kate zatiaren lehen karakterearen byte indizea ematen du.
    ///
    /// [`None`] itzultzen du eredua bat ez badator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Eredu konplexuagoak punturik gabeko estiloa eta itxiturak erabiliz:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Eredua ez aurkitzea:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Kate-zatiko eredu horren eskuineko muturreko lehen karakterearen byte indizea ematen du.
    ///
    /// [`None`] itzultzen du eredua bat ez badator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Eredu konplexuagoak itxierarekin:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Eredua ez aurkitzea:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Kate zati horren azpikaten gaineko iteratzailea, eredu batekin bat datozen karaktereak bereizita.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzultzaile itzulia [`DoubleEndedIterator`] izango da, ereduak alderantzizko bilaketa ahalbidetzen badu eta forward/reverse bilaketak elementu berak ematen baditu.
    /// Hori egia da, adibidez, [`char`] kasuan, baina ez `&str` kasuan.
    ///
    /// Ereduak alderantzizko bilaketa egitea ahalbidetzen badu baina emaitzak aurrerantz egindako bilaketa desberdinak izan daitezke, [`rsplit`] metodoa erabil daiteke.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Eredua karaktere zati bat bada, banatu karaktereetako edozein agerraldi bakoitzean:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Kate batek bereizle mugakide ugari baditu, irteeran kate hutsak lortuko dituzu:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Bereizle atxikiak kate hutsarekin bereizten dira.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Kate baten hasieran edo amaieran bereizleak kate hutsen ondoan daude.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Kate hutsa bereizle gisa erabiltzen denean, katearen karaktere guztiak bereizten ditu, katearen hasierarekin eta amaierarekin batera.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Bereizle mugakideek portaera harrigarria sor dezakete zuriunea bereizle gisa erabiltzen denean.Kode hau zuzena da:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_-k ematen dizu:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Erabili [`split_whitespace`] portaera horretarako.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Kate zati horren azpikaten gaineko iteratzailea, eredu batekin bat datozen karaktereak bereizita.
    /// `split`-ek `split_inclusive`-ek sortutako iteratzailetik desberdina da bat datorren zatia azpikatearen amaitzaile gisa uzten duena.
    ///
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Katearen azken elementua bat badator, elementu hori aurreko azpikatearen amaitutzat hartuko da.
    /// Azpi-kate hori iteratzaileak itzultzen duen azken elementua izango da.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Emandako kate zatiaren azpikaten gaineko iteratzailea, eredu batekin bat datozen eta alderantzizko ordenan emandako karaktereak bereizita.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako iteratzaileak ereduak alderantzizko bilaketa onartzea eskatzen du, eta [`DoubleEndedIterator`] izango da forward/reverse bilaketak elementu berak ematen baditu.
    ///
    ///
    /// Aurretik errepikatzeko, [`split`] metodoa erabil daiteke.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Emandako kate zatiaren azpikaten gaineko iteratzailea, eredu batekin bat datozen karaktereak bereizita.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ren baliokidea, amaierako azpikatea hutsik badago saltatzen dela salbu.
    ///
    /// [`split`]: str::split
    ///
    /// Metodo hau eredu baten bidez _terminated_ baino kate datuetarako erabil daiteke.
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzultzaile itzulia [`DoubleEndedIterator`] izango da, ereduak alderantzizko bilaketa ahalbidetzen badu eta forward/reverse bilaketak elementu berak ematen baditu.
    /// Hori egia da, adibidez, [`char`] kasuan, baina ez `&str` kasuan.
    ///
    /// Ereduak alderantzizko bilaketa egitea ahalbidetzen badu baina emaitzak aurrerantz egindako bilaketa desberdinak izan daitezke, [`rsplit_terminator`] metodoa erabil daiteke.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self`-ren azpikaten gaineko iteratzailea, eredu batekin bat datozen eta alderantzizko ordenan emandako karaktereak bereizita.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ren baliokidea, amaierako azpikatea hutsik badago saltatzen dela salbu.
    ///
    /// [`split`]: str::split
    ///
    /// Metodo hau eredu baten bidez _terminated_ baino kate datuetarako erabil daiteke.
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako iteratzaileak ereduak alderantzizko bilaketa onartzea eskatzen du, eta amaiera bikoitza izango du forward/reverse bilaketak elementu berak ematen baditu.
    ///
    ///
    /// Aurretik errepikatzeko, [`split_terminator`] metodoa erabil daiteke.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Emandako kate zatiaren azpikaten gaineko iteratzailea, eredu batek bereizita, gehienez `n` elementu itzultzera mugatuta dago.
    ///
    /// `n` azpikateak itzultzen badira, azken azpikateak (`n`th azpikateak) kateko gainerakoa edukiko du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako errepikatzaileak ez du amaiera bikoitza izango, ez baita eraginkorra onartzen.
    ///
    /// Ereduak alderantzizko bilaketa ahalbidetzen badu, [`rsplitn`] metodoa erabil daiteke.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Kate zati horren azpikateen gaineko iteratzailea, eredu batez bereizita, katea amaitzetik hasita, gehienez `n` elementu itzultzera mugatuta dago.
    ///
    ///
    /// `n` azpikateak itzultzen badira, azken azpikateak (`n`th azpikateak) kateko gainerakoa edukiko du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako errepikatzaileak ez du amaiera bikoitza izango, ez baita eraginkorra onartzen.
    ///
    /// Aurrealdetik zatitzeko, [`splitn`] metodoa erabil daiteke.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Katea banatzen du zehaztutako mugatzailearen lehen agerpenean eta aurrizkia itzultzen du mugatzailearen aurretik eta atzizkia mugatzailearen ondoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Katea banatzen du zehaztutako mugatzailearen azken agerraldian eta aurrizkia itzultzen du mugatzailearen aurretik eta atzizkia mugatzailearen ondoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Emandako kate zatiaren barruan eredu baten disjuntura-partiduen gaineko iteratzailea.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzultzaile itzulia [`DoubleEndedIterator`] izango da, ereduak alderantzizko bilaketa ahalbidetzen badu eta forward/reverse bilaketak elementu berak ematen baditu.
    /// Hori egia da, adibidez, [`char`] kasuan, baina ez `&str` kasuan.
    ///
    /// Ereduak alderantzizko bilaketa egitea ahalbidetzen badu baina emaitzak aurrerantz egindako bilaketa desberdinak izan daitezke, [`rmatches`] metodoa erabil daiteke.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Kate zati horren barruan eredu baten arteko lotura disjuntuen iteratzailea, alderantzizko ordenan eman da.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako iteratzaileak ereduak alderantzizko bilaketa onartzea eskatzen du, eta [`DoubleEndedIterator`] izango da forward/reverse bilaketak elementu berak ematen baditu.
    ///
    ///
    /// Aurretik errepikatzeko, [`matches`] metodoa erabil daiteke.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Kate zati horren barruan eredu baten arteko lotura disjuntuen gaineko iteratzailea eta baita partida hasten den indizea ere.
    ///
    /// Gainjartzen diren `pat` X-ren partiduetarako, lehenengo partiduari dagozkion indizeak soilik itzultzen dira.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzultzaile itzulia [`DoubleEndedIterator`] izango da, ereduak alderantzizko bilaketa ahalbidetzen badu eta forward/reverse bilaketak elementu berak ematen baditu.
    /// Hori egia da, adibidez, [`char`] kasuan, baina ez `&str` kasuan.
    ///
    /// Ereduak alderantzizko bilaketa egitea ahalbidetzen badu baina emaitzak aurrerantz egindako bilaketa desberdinak izan daitezke, [`rmatch_indices`] metodoa erabil daiteke.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // lehenengo `aba` bakarra
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` barruko eredu baten disjuntura-partiduen gaineko iteratzailea alderantzizko ordenan eman da partidaren indizearekin batera.
    ///
    /// Gainjartzen diren `pat` X-ren partidetarako, azken partiduari dagozkion indizeak soilik itzultzen dira.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratzaileen portaera
    ///
    /// Itzulitako iteratzaileak ereduak alderantzizko bilaketa onartzea eskatzen du, eta [`DoubleEndedIterator`] izango da forward/reverse bilaketak elementu berak ematen baditu.
    ///
    ///
    /// Aurretik errepikatzeko, [`match_indices`] metodoa erabil daiteke.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // azken `aba` bakarrik
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Kate zati bat itzultzen du espazio zuri nagusia eta amaierakoa kenduta.
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Kate zati bat itzultzen du puntako zuriunea kenduta.
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// `start` testuinguru horretan byte kate horren lehen posizioa esan nahi du;ingelesa edo errusiera bezalako ezker-eskuin hizkuntza batentzat, hau ezkerraldea izango da, eta eskuinetik ezkerrera arabiera edo hebreera bezalako hizkuntzen kasuan, hau izango da eskuinaldea.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Kate zati bat itzultzen du amaierako zuriunea kenduta.
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// `end` testuinguru honetan byte kate horren azken posizioa esan nahi du;ingelesa edo errusiera bezalako ezker-eskuin hizkuntza baterako, hau eskuineko aldea izango da, eta eskuinera-ezkerrera arabiera edo hebreera bezalako hizkuntzetarako, ezkerreko aldea.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Kate zati bat itzultzen du puntako zuriunea kenduta.
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// 'Left' testuinguru horretan byte kate horren lehen posizioa esan nahi du;arabiera edo hebreera bezalako hizkuntza batentzat "eskuinetik ezkerrera" baino "ezkerretik eskuinera" baino, hau _right_ aldea izango da, ez ezkerra.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Kate zati bat itzultzen du amaierako zuriunea kenduta.
    ///
    /// 'Whitespace' Unicode Derived Core `White_Space` propietatearen baldintzen arabera definitzen da.
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// 'Right' testuinguru honetan byte kate horren azken posizioa esan nahi du;arabiarra edo hebreera bezalako hizkuntza batentzat "eskuinetik ezkerrera" baino "ezkerretik eskuinera" baino, hau _left_ aldea izango da, ez eskuina.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Eredu batekin bat datozen aurrizki eta atzizki guztiak dituen kate zati bat ematen du.
    ///
    /// [pattern] [`char`] bat izan daiteke, [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Gogoratu ezagutzen den lehen partida, zuzendu behean bada
            // azken partida desberdina da
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURTASUNA: `Searcher`-k balio duen indizeak itzultzen ditu.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Eredu batekin bat datozen aurrizki guztiak dituen kate zati bat itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// `start` testuinguru horretan byte kate horren lehen posizioa esan nahi du;ingelesa edo errusiera bezalako ezker-eskuin hizkuntza batentzat, hau ezkerraldea izango da, eta eskuinetik ezkerrera arabiera edo hebreera bezalako hizkuntzen kasuan, hau izango da eskuinaldea.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SEGURTASUNA: `Searcher`-k balio duen indizeak itzultzen ditu.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Katea zati bat ematen du aurrizkia kenduta.
    ///
    /// Katea `prefix` ereduarekin hasten bada, azpikateak itzultzen du aurrizkiaren ondoren, `Some` bilduta.
    /// `trim_start_matches`-k ez bezala, metodo honek aurrizkia zehazki behin kentzen du.
    ///
    /// Katea `prefix`-rekin hasten ez bada, `None` itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Atzizkia kenduta duen kate zati bat ematen du.
    ///
    /// Katea `suffix` ereduarekin amaitzen bada, azpikatea atzizkiaren aurretik itzultzen du, `Some` bilduta.
    /// `trim_end_matches`-k ez bezala, metodo honek atzizkia zehazki behin kentzen du.
    ///
    /// Katea `suffix`-rekin amaitzen ez bada, `None` itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Eredu batekin bat datozen atzizki guztiak dituen kate zati bat itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// `end` testuinguru honetan byte kate horren azken posizioa esan nahi du;ingelesa edo errusiera bezalako ezker-eskuin hizkuntza baterako, hau eskuineko aldea izango da, eta eskuinera-ezkerrera arabiera edo hebreera bezalako hizkuntzetarako, ezkerreko aldea.
    ///
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURTASUNA: `Searcher`-k balio duen indizeak itzultzen ditu.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Eredu batekin bat datozen aurrizki guztiak dituen kate zati bat itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// 'Left' testuinguru horretan byte kate horren lehen posizioa esan nahi du;arabiera edo hebreera bezalako hizkuntza batentzat "eskuinetik ezkerrera" baino "ezkerretik eskuinera" baino, hau _right_ aldea izango da, ez ezkerra.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Eredu batekin bat datozen atzizki guztiak dituen kate zati bat itzultzen du.
    ///
    /// [pattern] `&str`, [`char`], [`char`] zati bat edo karaktere bat datorren ala ez zehazten duen funtzioa edo itxiera izan daiteke.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Testuaren noranzkotasuna
    ///
    /// Kate bat byte sekuentzia da.
    /// 'Right' testuinguru honetan byte kate horren azken posizioa esan nahi du;arabiarra edo hebreera bezalako hizkuntza batentzat "eskuinetik ezkerrera" baino "ezkerretik eskuinera" baino, hau _left_ aldea izango da, ez eskuina.
    ///
    ///
    /// # Examples
    ///
    /// Eredu sinpleak:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Eredu konplexuagoa, itxiera erabiliz:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Kate mota hori beste mota batean analizatzen du.
    ///
    /// `parse` oso orokorra denez, motak ondorioztatzeko arazoak sor ditzake.
    /// Honela, `parse` da 'turbofish' izenarekin ezagutzen den sintaxia maitasunez ikusiko duzun bakanetako bat: `::<>`.
    ///
    /// Honek inferentzia algoritmoa zehazki zein motatan aztertzen saiatzen ari zaren ulertzen laguntzen du.
    ///
    /// `parse` [`FromStr`] trait inplementatzen duen edozein motatan azter daiteke.
    ///

    /// # Errors
    ///
    /// [`Err`] itzuliko du kate zati hori nahi duzun motan aztertzea posible ez bada.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// 'turbofish' erabiltzea `four` ohartarazi beharrean:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Analizatu ezean:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kate honetako karaktere guztiak ASCII barrutian dauden egiaztatzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Byte bakoitza karaktere gisa har dezakegu hemen: multibyte karaktere guztiak ascii barrutian ez dagoen byte batekin hasten dira, beraz, bertan geldituko gara jada.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Bi kateek ASCII maiuskulak eta minuskulak bereizten ez dituztela egiaztatzen du.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` bezalakoa, baina aldi baterakoak esleitu eta kopiatu gabe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Kate hau ASCII maiuskulako baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Maiuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SEGURTASUNA: segurua diseinua bera duten bi mota transmutatzen ditugulako.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Kate hau ASCII minuskula baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Minuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SEGURTASUNA: segurua diseinua bera duten bi mota transmutatzen ditugulako.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Itzuli `self` karaktere bakoitzari ihes egiten dion iteratzailea [`char::escape_debug`]-rekin.
    ///
    ///
    /// Note: katea hasten duten grafema hedatutako kodepuntuek soilik ihes egingo dute.
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Itzuli `self` karaktere bakoitzari ihes egiten dion iteratzailea [`char::escape_default`]-rekin.
    ///
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Itzuli `self` karaktere bakoitzari ihes egiten dion iteratzailea [`char::escape_unicode`]-rekin.
    ///
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Str huts bat sortzen du
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Huts aldakor bat sortzen du
    #[inline]
    fn default() -> Self {
        // SEGURTASUNA: kate hutsak UTF-8 balio du.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Fn mota izendagarria eta klonagarria
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SEGURTASUNA: ez da segurua
        unsafe { from_utf8_unchecked(bytes) }
    };
}