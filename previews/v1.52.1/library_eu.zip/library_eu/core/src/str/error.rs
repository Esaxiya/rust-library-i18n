//! utf8 errore mota definitzen du.

use crate::fmt;

/// [`u8`] ren sekuentzia kate gisa interpretatzen saiatzean gerta daitezkeen akatsak.
///
/// Horregatik, `from_utf8` funtzio eta metodoen [[String]] eta [`&str`] s-ren metodoak errore hau erabiltzen du, adibidez.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Errore mota honen metodoak `String::from_utf8_lossy`-ren antzeko funtzionaltasunak sortzeko erabil daitezke memoria memoria esleitu gabe:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Emandako katearen indizea baliozko UTF-8 egiaztatu den arte ematen du.
    ///
    /// `from_utf8(&input[..index])`-k `Ok(_)` itzuliko lukeen gehieneko indizea da.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::str;
    ///
    /// // byte baliogabe batzuk, vector batean
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error itzultzen du
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // bigarren byteak ez du balio hemen
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Hutsegiteari buruzko informazio gehiago eskaintzen du:
    ///
    /// * `None`: sarreraren amaiera ustekabean iritsi zen.
    ///   `self.valid_up_to()` sarrera amaieratik 1 eta 3 byte da.
    ///   Byte korronte bat (hala nola fitxategi bat edo sareko socket bat) modu inkrementalean deskodetzen ari bada, baliozko `char` bat izan daiteke, UTF-8 byte sekuentzia zati ugari dituena.
    ///
    ///
    /// * `Some(len)`: ustekabeko byte bat aurkitu zen.
    ///   Emandako luzera `valid_up_to()`-k emandako indizean hasten den byte baliogabearen sekuentzia da.
    ///   Deskodetzea sekuentzia horren ondoren berriro hasi beharko litzateke ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] txertatu ondoren) galera deskodetuz gero.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// `bool` [`from_str`] erabiliz analizatzean errore bat gertatu da
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}