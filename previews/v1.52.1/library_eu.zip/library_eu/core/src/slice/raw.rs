//! Doako funtzioak `&[T]` eta `&mut [T]` sortzeko.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Xerra bat osatzen du erakusle batetik eta luzera batetik.
///
/// `len` argumentua **elementu** kopurua da, ez byte kopurua.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `data` [valid] izan behar du `len * mem::size_of::<T>()` byte askotan irakurtzeko, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
///
///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.Ikusi [below](#incorrect-usage) adibide bat gaizki kontutan hartzen ez duen adibidea lortzeko.
///     * `data` nuluak eta lerrokatuta egon behar dute zero luzerako zatietan.
///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
///
/// * `data` `len` ondoz ondoko `T` motako hasierako balioak seinalatu behar ditu.
///
/// * Itzulitako zatiak aipatzen duen memoria ez da mutatu behar `'a` bizitzan zehar, `UnsafeCell` baten barruan izan ezik.
///
/// * Xerraren `len * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
///
/// # Caveat
///
/// Itzulitako zatiaren iraupena bere erabileratik ondorioztatzen da.
/// Ustekabeko erabilera okerra ekiditeko, testuinguruan segurua den edozein iturritako bizitzarekin lotzea gomendatzen da, esate baterako, laguntza-funtzio bat eskainiz zatiaren ostalariaren balioaren iraupena hartuz edo oharpen esplizituaren bidez.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // erakutsi zati bakarra elementu bakarrerako
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Erabilera okerra
///
/// `join_slices` funtzio hau **ez da ona** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Goiko baieztapenak `fst` eta `snd` mugak direla ziurtatzen du, baina baliteke _different allocated objects_ barruan edukitzea, kasu horretan xerra sortzea definitu gabeko portaera da.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` eta `b` esleitutako objektu desberdinak dira ...
///     let a = 42;
///     let b = 27;
///     // ... baina hala ere, oroimenean elkarren ondoan ager daitezke: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURTASUNA: deitzaileak `from_raw_parts`-rako segurtasun kontratua onartu behar du.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`]-ren funtzionalitate bera betetzen du, zati aldakorra itzultzen den salbu.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `data` [valid] izan behar du irakurtzeko eta idazteko `len * mem::size_of::<T>()` byte askotan, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
///
///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.
///     * `data` nuluak eta lerrokatuta egon behar dute zero luzerako zatietan.
///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
///
///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
///
/// * `data` `len` ondoz ondoko `T` motako hasierako balioak seinalatu behar ditu.
///
/// * Itzulitako zatiak aipatzen duen memoria ezin da sartu beste edozein erakusleren bidez (ez da itzultzen duen balioetik eratorria) `'a` bizitzan zehar.
///   Irakurtzeko zein idazteko sarbideak debekatuta daude.
///
/// * Xerraren `len * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURTASUNA: deitzaileak `from_raw_parts_mut`-rako segurtasun kontratua onartu behar du.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T-ren erreferentzia 1 luzerako xerra bihurtzen du (kopiatu gabe).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T-ren erreferentzia 1 luzerako xerra bihurtzen du (kopiatu gabe).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}