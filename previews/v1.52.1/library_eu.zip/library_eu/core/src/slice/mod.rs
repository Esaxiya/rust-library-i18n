// ignore-tidy-filelength

//! Xerren kudeaketa eta manipulazioa.
//!
//! Xehetasun gehiagorako ikusi [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust memchr inplementazio hutsa, rust-memchr-etik hartua
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Funtzio hau publikoa da, ez baitago beste modurik probatzeko unitateak.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Xerrako elementu kopurua itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEGURTASUNA: konst soinua luzera eremua usize gisa transmititzen dugulako (izan behar du)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURTASUNA: segurua da `&[T]` eta `FatPtr<T>` diseinu bera dutelako.
            // `std`-k soilik eman dezake berme hori.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ordeztu `crate::ptr::metadata(self)`-rekin hori egonkorra denean.
            // Idazten ari garen honetan honek "Const-stable functions can only call other const-stable functions" errorea eragiten du.
            //

            // SEGURTASUNA: `PtrRepr` sindikatutik balioa sartzea segurua da * const T
            // eta PtrComponents<T>memoria diseinu berdinak dituzte.
            // std k bakarrik egin dezake berme hori.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// `true` ematen du zatiak 0 luzera badu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Xerraren lehen elementua itzultzen du edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Erakusle aldakorra zatiaren lehen elementura itzultzen du edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Xerraren lehenengo elementuak eta gainerako elementuak itzultzen ditu edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Xerraren lehenengo elementuak eta gainerako elementuak itzultzen ditu edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Xaflaren azken elementuak eta gainerako elementuak itzultzen ditu edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Xaflaren azken elementuak eta gainerako elementuak itzultzen ditu edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Xerraren azken elementua itzultzen du edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Erakusle aldagarri bat zatiko azken elementura itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Indize motaren arabera elementu edo azpiatal baten erreferentzia itzultzen du.
    ///
    /// - Posizio bat ematen bazaio, posizio horretan dagoen elementuaren erreferentzia itzultzen du edo `None` mugetatik kanpo badago.
    ///
    /// - Barrutia ematen bada, barruti horri dagokion azpiatala itzultzen du edo `None` mugetatik kanpo badago.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Indize motaren arabera (ikus [`get`]) edo `None` elementu baten edo azpizlatuaren erreferentzia aldakorra itzultzen du indizea mugetatik kanpo badago.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Elementu edo azpiatal baten erreferentzia itzultzen du, mugen egiaztapena egin gabe.
    ///
    /// Alternatiba segurua lortzeko, ikusi [`get`].
    ///
    /// # Safety
    ///
    /// Metodo hau mugaz kanpoko indizearekin deitzea *[portaera zehaztu gabea]* da, ondorioz erreferentzia erabiltzen ez bada ere.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURTASUNA: deitzaileak `get_unchecked`-rako segurtasun baldintza gehienak bete behar ditu;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Elementu edo azpisail baten erreferentzia aldakorra itzultzen du, mugen egiaztapena egin gabe.
    ///
    /// Alternatiba segurua lortzeko, ikusi [`get_mut`].
    ///
    /// # Safety
    ///
    /// Metodo hau mugaz kanpoko indizearekin deitzea *[portaera zehaztu gabea]* da, ondorioz erreferentzia erabiltzen ez bada ere.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURTASUNA: deitzaileak `get_unchecked_mut`-rako segurtasun baldintzak bete behar ditu;
        // xerra ezin da erreferentziarik egin, `self` erreferentzia segurua delako.
        // Itzulitako erakuslea segurua da, `SliceIndex`-ren inplementazioek hori ziurtatu behar baitute.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Erakusle gordin bat zatiaren bufferrera itzultzen du.
    ///
    /// Deitzaileak ziurtatu behar du zatiak funtzio honek itzultzen duen erakuslea gainditzen duela, edo bestela zaborra seinalatzen amaituko du.
    ///
    /// Deitzaileak ere ziurtatu behar du (non-transitively) erakusleak seinalatzen duen memoria ez dela inoiz idazten (`UnsafeCell` baten barruan izan ezik) erakusle hau edo hortik eratorritako edozein erakusle erabiliz.
    /// Xerraren edukia mutatu behar baduzu, erabili [`as_mut_ptr`].
    ///
    /// Xerra honek aipatzen duen edukiontzia aldatzeak bufferra berriro esleitzea eragin dezake, eta horrek erakusle baliogabeak ere bihurtuko lituzke.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Seguru ez dagoen erakusle aldakorra zatiaren bufferrera itzultzen du.
    ///
    /// Deitzaileak ziurtatu behar du zatiak funtzio honek itzultzen duen erakuslea gainditzen duela, edo bestela zaborra seinalatzen amaituko du.
    ///
    /// Xerra honek aipatzen duen edukiontzia aldatzeak bufferra berriro esleitzea eragin dezake, eta horrek erakusle baliogabeak ere bihurtuko lituzke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Xaflaren bi erakusle gordinak itzultzen ditu.
    ///
    /// Itzulitako barrutia erdi irekita dago, hau da, amaierako erakusleak xerraren azken elementua *pasatzen du* pasatzen du.
    /// Horrela, xerra huts bat bi erakusle berdinen bidez irudikatzen da, eta bi erakusleen arteko aldeak zatiaren tamaina adierazten du.
    ///
    /// Ikusi [`as_ptr`] erakusle hauek erabiltzearen inguruko abisuak lortzeko.Amaierako erakusleak arreta berezia eskatzen du, zatian ez baitu balio duen elementurik seinalatzen.
    ///
    /// Funtzio hau baliagarria da memoriako elementu ugari aipatzeko bi erakusle erabiltzen dituzten interfaze arrotzekin elkarreragiteko, C++ -en ohikoa den bezala.
    ///
    ///
    /// Elementu bateko erakusleak xerra honetako elementu bati erreferentzia egiten dion egiaztatzeko ere erabilgarria izan daiteke:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEGURTASUNA: Hemen dagoen `add` segurua da, izan ere:
        //
        //   - Bi erakusleak objektu beraren parte dira, objektuaren ondotik zuzenean seinalatzeak ere balio baitu.
        //
        //   - Xerraren tamaina ez da inoiz isize::MAX byte baino handiagoa, hemen adierazi bezala:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Ez dago inolako bilgarririk inplikatuta, zatiak ez baitira helbide espazioaren amaieratik pasatzen.
        //
        // Ikusi pointer::add dokumentazioa.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Segurtasunik gabeko bi erakusle aldaezinak zatian zehar itzultzen ditu.
    ///
    /// Itzulitako barrutia erdi irekita dago, hau da, amaierako erakusleak xerraren azken elementua *pasatzen du* pasatzen du.
    /// Horrela, xerra huts bat bi erakusle berdinen bidez irudikatzen da, eta bi erakusleen arteko aldeak zatiaren tamaina adierazten du.
    ///
    /// Ikusi [`as_mut_ptr`] erakusle hauek erabiltzearen inguruko abisuak lortzeko.
    /// Amaierako erakusleak arreta berezia eskatzen du, zatian ez baitu balio duen elementurik seinalatzen.
    ///
    /// Funtzio hau baliagarria da memoriako elementu ugari aipatzeko bi erakusle erabiltzen dituzten interfaze arrotzekin elkarreragiteko, C++ -en ohikoa den bezala.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEGURTASUNA: Ikus goiko as_ptr_range() zergatik dagoen segurua `add` hemen.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Xerran bi elementu trukatzen ditu.
    ///
    /// # Arguments
    ///
    /// * a, Lehenengo elementuaren aurkibidea
    /// * b, bigarren elementuaren indizea
    ///
    /// # Panics
    ///
    /// Panics `a` edo `b` mugetatik kanpo badaude.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ezin ditut bi mailegu aldakor hartu vector batetik, beraz erabili erakusle gordinak.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEGURTASUNA: `pa` eta `pb` erreferentzia aldakor eta erreferente seguruetatik sortu dira
        // zatian dauden elementuei eta, beraz, baliozkoak eta lerrokatuak direla bermatuta dago.
        // Kontuan izan `a` eta `b` atzean dauden elementuak atzitzea egiaztatuta dagoela eta mugetatik kanpo dagoenean panic egingo dela.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Xerran dauden elementuen ordena alderantzikatzen du bere lekuan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Mota oso txikietan, norberak bide normalean irakurtzen dituen guztiak txarto funtzionatzen dute.
        // Hobeto egin dezakegu, lerrokatu gabeko load/store eraginkorra izanez gero, zati handiagoa kargatuz eta erregistroa alderantzikatuz.
        //

        // Egokiena LLVM-k hau egingo luke guretzat, guk baino hobeto daki lerrokatu gabeko irakurketak eraginkorrak diren ala ez (ARM bertsio desberdinen artean aldatzen denez, adibidez) eta zein izango litzatekeen zatirik onena.
        // Zoritxarrez, LLVM 4.0 (2017-05)-rekin begizta bakarrik desegiten du, beraz, guk geuk egin behar dugu.
        // (Hipotesia: alderantzizkoa kezkagarria da, aldeak modu desberdinean lerroka baitaitezke-izango da, luzera bakoitia denean-beraz, ez dago aurrea eta postludiorik igortzeko erdian guztiz lerrokatutako SIMD erabiltzeko.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Erabil ezazu llvm.bswap berezkoa u8ak alderantzikatzeko usize batean
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEGURTASUNA: Hemen egiaztatu beharreko hainbat gauza daude:
                //
                // - Kontuan izan `chunk` 4 edo 8 dela goiko cfg egiaztapena dela eta.Beraz, `chunk - 1` positiboa da.
                // - `i` indizearekin indexatzea ondo dago begizta kontrolak bermatzen duen moduan
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` indizearekin indexatzea ondo dago:
                //   - `i + chunk > 0` hutsala da egia.
                //   - Begiztaren egiaztapenak bermatzen du:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, beraz, kenketak ez du gainezka egiten.
                // - `read_unaligned` eta `write_unaligned` deiak ondo daude:
                //   - `pa` puntuak `i` indizean `i < ln / 2 - (chunk - 1)` (ikus goian) eta `pb` puntuak `ln - i - chunk` indizean, beraz, biak gutxienez `chunk` byte asko daude `self` amaieratik urrun.
                //
                //   - Hasierako edozein memoriak `usize` balio du.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Erabili biratu 16-tik X16X batean u16ak alderantzikatzeko
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEGURTASUNA: lerrokatu gabeko u32 bat irakur daiteke `i` tik `i + 1 < ln` bada
                // (eta, jakina, `i < ln`), elementu bakoitza 2 byte delako eta 4 irakurtzen ari garelako.
                //
                // `i + chunk - 1 < ln / 2` # baldintza bitartean
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // 2rekin zatitutako luzera baino txikiagoa denez, mugetan egon behar du.
                //
                // Horrek esan nahi du `0 < i + chunk <= ln` baldintza beti errespetatzen dela, `pb` erakuslea segurtasunez erabil daitekeela ziurtatuz.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEGURTASUNA: `i` zatiaren luzeraren erdia baino txikiagoa da
            // `i` eta `ln - i - 1` sartzea segurua da (`i` 0-tik hasten da eta ez da `ln / 2 - 1` baino urrunago joango).
            // Ondorioz, `pa` eta `pb` erakusleak baliozkoak eta lerrokatuak dira eta irakurri eta idatz daitezke.
            //
            //
            unsafe {
                // Swap segurua mugak saihesteko swap seguruan egiaztatzeko.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Iteratzailearen zati bat itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Balio bakoitza aldatzea ahalbidetzen duen iteratzailea ematen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// X001 luzerako windows ondoko guztien gaineko iteratzailea ematen du.
    /// windows gainjartzen da.
    /// Xerra `size` baino laburragoa bada, iteratzaileak ez du baliorik ematen.
    ///
    /// # Panics
    ///
    /// Panics `size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Xerra `size` baino laburragoa bada:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak zatiak dira eta ez dira gainjartzen.`chunk_size`-k zatiaren luzera banatzen ez badu, azken zatiak ez du `chunk_size` luzera izango.
    ///
    /// Ikusi [`chunks_exact`] errepikatzaile honen aldaera bat, beti zehazki `chunk_size` elementuen zatiak itzultzen dituena eta [`rchunks`] iteratzaile berarentzat baina zatiaren amaieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak alda daitezkeen zatiak dira, eta ez dira gainjartzen.`chunk_size`-k zatiaren luzera banatzen ez badu, azken zatiak ez du `chunk_size` luzera izango.
    ///
    /// Ikusi [`chunks_exact_mut`] errepikatzaile honen aldaera bat, beti zehazki `chunk_size` elementuen zatiak itzultzen dituena eta [`rchunks_mut`] iteratzaile berarentzat baina zatiaren amaieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak zatiak dira eta ez dira gainjartzen.
    /// `chunk_size`-k zatiaren luzera banatzen ez badu, azkeneko `chunk_size-1` elementuak kenduko dira eta iteratzailearen `remainder` funtziotik berreskura daitezke.
    ///
    ///
    /// Zati bakoitzak zehazki `chunk_size` elementuak dituenez, konpiladoreak askotan emaitza hobea optimiza dezake [`chunks`] ren kasuan baino.
    ///
    /// Ikusi [`chunks`] iteratzaile honen aldaera bat, gainerakoa zati txikiago gisa itzultzen duena eta [`rchunks_exact`] iteratzaile berarentzat baina zatiaren amaieran hasita.
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak alda daitezkeen zatiak dira, eta ez dira gainjartzen.
    /// `chunk_size`-k zatiaren luzera banatzen ez badu, azkeneko `chunk_size-1` elementuak kenduko dira eta iteratzailearen `into_remainder` funtziotik berreskura daitezke.
    ///
    ///
    /// Zati bakoitzak zehazki `chunk_size` elementuak dituela eta, konpiladoreak askotan emaitza hobea optimiza dezake [`chunks_mut`] ren kasuan baino.
    ///
    /// Ikusi [`chunks_mut`] iteratzaile honen aldaera bat, gainerakoa zati txikiago gisa itzultzen duena eta [`rchunks_exact_mut`] iteratzaile berarentzat baina zatiaren amaieran hasita.
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Xerra `N` elementuen matrize zatitan zatitzen du, hondarrik ez dagoela suposatuz.
    ///
    ///
    /// # Safety
    ///
    /// Hau noiz bakarrik deitu daiteke
    /// - Xerra zehatz-mehatz zatitzen da `N` elementuko zatietan (`self.len() % N == 0`) ere ezagutzen da.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEGURTASUNA: 1 elementuko zatiek ez dute inoiz hondarrik izaten
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEGURTASUNA: (6) zatiaren luzera 3ren multiploa da
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Hauek ez lirateke onuragarriak:
    /// // utzi zatiak: &[[_;5]]= slice.as_chunks_unchecked()//Xerra luzera ez da 5 letren zatiaren multiploa:&[[_;0]]= slice.as_chunks_unchecked()//Zero luzera zatiak ez dira inoiz onartzen
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURTASUNA: gure aurre-baldintza da hori deitzeko behar dena
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURTASUNA: `new_len * N` elementuen zati bat bota dugu
        // `new_len` `N` elementu zati asko zati bat.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Xerra zatitzen du `N` elementuen matrize zatitan, zatiaren hasieran hasita, eta `N` baino luzera txikiagoa duen gainerako zatian.
    ///
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEGURTASUNA: dagoeneko zero izutzen ginen eta eraikuntzak bermatzen zuen
        // azpiatalaren luzera N-ren multiploa dela
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Xerra zatitzen du `N` elementuen matrize zatitan, zatiaren amaieran hasita, eta gainerako zatitxo bat `N` baino gutxiagoko luzera duena.
    ///
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEGURTASUNA: dagoeneko zero izutzen ginen eta eraikuntzak bermatzen zuen
        // azpiatalaren luzera N-ren multiploa dela
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Xerraren `N` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak array erreferentziak dira eta ez dira gainjartzen.
    /// `N`-k zatiaren luzera banatzen ez badu, azkeneko `N-1` elementuak kenduko dira eta iteratzailearen `remainder` funtziotik berreskura daitezke.
    ///
    ///
    /// Metodo hau [`chunks_exact`]-ren baliokide generikoa da.
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Xerra `N` elementuen matrize zatitan zatitzen du, hondarrik ez dagoela suposatuz.
    ///
    ///
    /// # Safety
    ///
    /// Hau noiz bakarrik deitu daiteke
    /// - Xerra zehatz-mehatz zatitzen da `N` elementuko zatietan (`self.len() % N == 0`) ere ezagutzen da.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEGURTASUNA: 1 elementuko zatiek ez dute inoiz hondarrik izaten
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEGURTASUNA: (6) zatiaren luzera 3ren multiploa da
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Hauek ez lirateke onuragarriak:
    /// // utzi zatiak: &[[_;5]]= slice.as_chunks_unchecked_mut()//Xerra luzera ez da 5 letren zatiaren multiploa:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zero luzera zatiak ez dira inoiz onartzen
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURTASUNA: gure aurre-baldintza da hori deitzeko behar dena
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURTASUNA: `new_len * N` elementuen zati bat bota dugu
        // `new_len` `N` elementu zati asko zati bat.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Xerra zatitzen du `N` elementuen matrize zatitan, zatiaren hasieran hasita, eta `N` baino luzera txikiagoa duen gainerako zatian.
    ///
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEGURTASUNA: dagoeneko zero izutzen ginen eta eraikuntzak bermatzen zuen
        // azpiatalaren luzera N-ren multiploa dela
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Xerra zatitzen du `N` elementuen matrize zatitan, zatiaren amaieran hasita, eta gainerako zatitxo bat `N` baino gutxiagoko luzera duena.
    ///
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEGURTASUNA: dagoeneko zero izutzen ginen eta eraikuntzak bermatzen zuen
        // azpiatalaren luzera N-ren multiploa dela
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Xerraren `N` elementuen errepikatzailea itzultzen du aldi berean, zatiaren hasieran hasita.
    ///
    /// Puskak array erreferentzia aldakorrak dira eta ez dira gainjartzen.
    /// `N`-k zatiaren luzera banatzen ez badu, azkeneko `N-1` elementuak kenduko dira eta iteratzailearen `into_remainder` funtziotik berreskura daitezke.
    ///
    ///
    /// Metodo hau [`chunks_exact_mut`]-ren baliokide generikoa da.
    ///
    /// # Panics
    ///
    /// Panics `N` bada 0. Egiaztapen hau konpilazio denbora errore batera aldatuko da ziurrenik metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Xerra baten `N` elementuen windows gainjarritako errepikakorra itzultzen du, zatiaren hasieran hasita.
    ///
    ///
    /// Hau da [`windows`]-ren baliokide generikoa.
    ///
    /// `N` zatiaren tamaina baino handiagoa bada, ez du windows itzuliko.
    ///
    /// # Panics
    ///
    /// Panics `N` 0 bada.
    /// Egiaztapen hau ziurrenik konpilazioko denbora akats batera aldatuko da metodo hau egonkortu aurretik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren amaieran hasita.
    ///
    /// Puskak zatiak dira eta ez dira gainjartzen.`chunk_size`-k zatiaren luzera banatzen ez badu, azken zatiak ez du `chunk_size` luzera izango.
    ///
    /// Ikusi [`rchunks_exact`] errepikatzaile honen aldaera bat, beti zehazki `chunk_size` elementuen zatiak itzultzen dituena eta [`chunks`] iteratzaile berarentzat baina zatiaren hasieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren amaieran hasita.
    ///
    /// Puskak alda daitezkeen zatiak dira, eta ez dira gainjartzen.`chunk_size`-k zatiaren luzera banatzen ez badu, azken zatiak ez du `chunk_size` luzera izango.
    ///
    /// Ikusi [`rchunks_exact_mut`] iteratzaile honen aldaera bat, beti zehazki `chunk_size` elementuen zatiak itzultzen dituena eta [`chunks_mut`] iteratzaile berarentzat baina zatiaren hasieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren amaieran hasita.
    ///
    /// Puskak zatiak dira eta ez dira gainjartzen.
    /// `chunk_size`-k zatiaren luzera banatzen ez badu, azkeneko `chunk_size-1` elementuak kenduko dira eta iteratzailearen `remainder` funtziotik berreskura daitezke.
    ///
    /// Zati bakoitzak zehazki `chunk_size` elementuak dituenez, konpiladoreak askotan emaitza hobea optimiza dezake [`chunks`] ren kasuan baino.
    ///
    /// Ikusi [`rchunks`] iteratzaile honen aldaera bat, gainerakoa zati txikiago gisa itzultzen duena eta [`chunks_exact`] iteratzaile berarentzat baina zatiaren hasieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Xerraren `chunk_size` elementuen errepikatzailea itzultzen du aldi berean, zatiaren amaieran hasita.
    ///
    /// Puskak alda daitezkeen zatiak dira, eta ez dira gainjartzen.
    /// `chunk_size`-k zatiaren luzera banatzen ez badu, azkeneko `chunk_size-1` elementuak kenduko dira eta iteratzailearen `into_remainder` funtziotik berreskura daitezke.
    ///
    /// Zati bakoitzak zehazki `chunk_size` elementuak dituela eta, konpiladoreak askotan emaitza hobea optimiza dezake [`chunks_mut`] ren kasuan baino.
    ///
    /// Ikusi [`rchunks_mut`] iteratzaile honen aldaera bat, gainerakoa zati txikiago gisa itzultzen duena eta [`chunks_exact_mut`] iteratzaile berarentzat baina zatiaren hasieran hasita.
    ///
    ///
    /// # Panics
    ///
    /// Panics `chunk_size` 0 bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Xerra gainetik errepikatzen duen elementua errepikatzen du, bata bestearentzat bereizteko predikatua erabiliz.
    ///
    /// Predikatua beraien atzetik dauden bi elementuri deitzen zaio, esan nahi du predikatua `slice[0]` eta `slice[1]` telefonoetan deitzen dela, gero `slice[1]` eta `slice[2]` telefonoetan eta abar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Metodo hau erabil daiteke sailkatutako azpisailak ateratzeko:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Xedapenaren gaineko iteratzailea itzultzen du gainjarri ez diren elementuen aldagai aldagarriak sortuz predikatua erabiliz bereizteko.
    ///
    /// Predikatua beraien atzetik dauden bi elementuri deitzen zaio, esan nahi du predikatua `slice[0]` eta `slice[1]` telefonoetan deitzen dela, gero `slice[1]` eta `slice[2]` telefonoetan eta abar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Metodo hau erabil daiteke sailkatutako azpisailak ateratzeko:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Xerra bat bitan banatzen du indize batean.
    ///
    /// Lehenengoan `[0, mid)`-eko indize guztiak egongo dira (`mid` indizea bera kenduta) eta bigarrenean `[mid, len)`-eko indize guztiak (`len` indizea bera kenduta).
    ///
    ///
    /// # Panics
    ///
    /// Panics `mid > len` bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEGURTASUNA: `[ptr; mid]` eta `[mid; len]` `self` barruan daude
        // `from_raw_parts_mut`-ren eskakizunak betetzen ditu.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Alda daitekeen zati bat bitan banatzen du indize batean.
    ///
    /// Lehenengoan `[0, mid)`-eko indize guztiak egongo dira (`mid` indizea bera kenduta) eta bigarrenean `[mid, len)`-eko indize guztiak (`len` indizea bera kenduta).
    ///
    ///
    /// # Panics
    ///
    /// Panics `mid > len` bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEGURTASUNA: `[ptr; mid]` eta `[mid; len]` `self` barruan daude
        // `from_raw_parts_mut`-ren eskakizunak betetzen ditu.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Xerra bat bitan banatzen du indize batean, mugen egiaztapena egin gabe.
    ///
    /// Lehenengoan `[0, mid)`-eko indize guztiak egongo dira (`mid` indizea bera kenduta) eta bigarrenean `[mid, len)`-eko indize guztiak (`len` indizea bera kenduta).
    ///
    ///
    /// Alternatiba segurua lortzeko [`split_at`] ikusi.
    ///
    /// # Safety
    ///
    /// Metodo hau mugaz kanpoko indizearekin deitzea *[portaera zehaztu gabea]* da, ondorioz erreferentzia erabiltzen ez bada ere.Deitzaileak `0 <= mid <= self.len()` ziurtatu behar du.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEGURTASUNA: Deitzaileak `0 <= mid <= self.len()` hori egiaztatu behar du
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Alda daitekeen zati bat bitan banatzen du indize batean, mugen kontrolik egin gabe.
    ///
    /// Lehenengoan `[0, mid)`-eko indize guztiak egongo dira (`mid` indizea bera kenduta) eta bigarrenean `[mid, len)`-eko indize guztiak (`len` indizea bera kenduta).
    ///
    ///
    /// Alternatiba segurua lortzeko [`split_at_mut`] ikusi.
    ///
    /// # Safety
    ///
    /// Metodo hau mugaz kanpoko indizearekin deitzea *[portaera zehaztu gabea]* da, ondorioz erreferentzia erabiltzen ez bada ere.Deitzaileak `0 <= mid <= self.len()` ziurtatu behar du.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEGURTASUNA: Deitzaileak `0 <= mid <= self.len()` hori egiaztatu behar du.
        //
        // `[ptr; mid]` eta `[mid; len]` ez dira gainjartzen, beraz, ondo alda daiteke erreferentzia itzultzea.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Iteratzailea itzultzen du `pred`-rekin bat datozen elementuen bidez banatutako azpiatalen gainean.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Lehenengo elementua parekatuz gero, zati huts bat izango da iteratzaileak itzultzen duen lehen elementua.
    /// Era berean, zatiko azken elementua bat badator, zati huts bat izango da iteratzaileak itzultzen duen azken elementua:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Bat datozen bi elementu zuzenean aldamenean badaude, xerra huts bat egongo da bien artean:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Iteratzailea itzultzen du `pred`-rekin bat datozen elementuek bereizitako azpiatal aldakorren gainean.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Iteratzailea itzultzen du `pred`-rekin bat datozen elementuen bidez banatutako azpiatalen gainean.
    /// Elementu parekatua aurreko azpiatalaren amaieran dago amaitzaile gisa.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Xerraren azken elementua bat badator, elementu hori aurreko zatiaren amaieratzat hartuko da.
    ///
    /// Xerra hori iteratzaileak itzultzen duen azken elementua izango da.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Iteratzailea itzultzen du `pred`-rekin bat datozen elementuek bereizitako azpiatal aldakorren gainean.
    /// Elementu parekatua aurreko azpiatalean dago amaitzaile gisa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred`-rekin bat datozen elementuek bereizitako azpiatalen gaineko iteratzailea itzultzen du, zatiaren amaieran hasi eta atzerantz lan eginez.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()`-rekin gertatzen den moduan, lehenengo edo azken elementua bat badator, zati huts bat iteratzaileak itzultzen duen lehen (edo azken) elementua izango da.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred`-rekin bat datozen elementuek bereizitako azpiatal aldakorren gaineko iteratzailea itzultzen du, zatiaren amaieran hasi eta atzerantz lan eginez.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred`-rekin bat datozen elementuen bidez bereizitako azpiatalen gaineko iteratzailea ematen du, gehienez `n` elementu itzultzera mugatuta.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// Itzulitako azken elementuak, baldin badago, zatiaren gainerakoa edukiko du.
    ///
    /// # Examples
    ///
    /// Inprimatu zatitutako zatiak behin 3rekin zatitzen diren zenbakien bidez (hau da, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred`-rekin bat datozen elementuen bidez bereizitako azpiatalen gaineko iteratzailea ematen du, gehienez `n` elementu itzultzera mugatuta.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// Itzulitako azken elementuak, baldin badago, zatiaren gainerakoa edukiko du.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// `pred`-rekin bat datozen elementuen bidez bereizitako azpiatalen gaineko iteratzailea itzultzen du gehienez `n` elementu itzultzera mugatuta.
    /// Hau zatiaren amaieran hasten da eta atzera egiten du lan.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// Itzulitako azken elementuak, baldin badago, zatiaren gainerakoa edukiko du.
    ///
    /// # Examples
    ///
    /// Inprimatu zatitutako zatia behin, amaieratik hasita, 3rekin zatitzen diren zenbakien bidez (hau da, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// `pred`-rekin bat datozen elementuen bidez bereizitako azpiatalen gaineko iteratzailea itzultzen du gehienez `n` elementu itzultzera mugatuta.
    /// Hau zatiaren amaieran hasten da eta atzera egiten du lan.
    /// Bat datorren elementua ez dago azpisailetan.
    ///
    /// Itzulitako azken elementuak, baldin badago, zatiaren gainerakoa edukiko du.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// `true` ematen du zatiak emandako balioa duen elementu bat baldin badu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// `&T` bat ez baduzu, `&U` bat besterik ez bada, hala nola `T: Borrow<U>` (adibidez
    /// `Katea: maileguan hartu<str>`), `iter().any` erabil dezakezu:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` zati
    /// assert!(v.iter().any(|e| e == "hello")); // bilatu `&str`-rekin
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `true` ematen du `needle` zatiaren aurrizkia bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Beti itzultzen du `true` `needle` xerra hutsa bada:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `true` ematen du `needle` zatiaren atzizkia bada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Beti itzultzen du `true` `needle` xerra hutsa bada:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Azpitala itzultzen du aurrizkia kenduta.
    ///
    /// Xerra `prefix`-rekin hasten bada, azpizerra itzultzen da aurrizkiaren ondoren, `Some`-n bilduta.
    /// `prefix` hutsik badago, jatorrizko xerra itzuliko da.
    ///
    /// Xerra `prefix`-rekin hasten ez bada, `None` itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Funtzio honek berriro idatzi beharko du SlicePattern sofistikatuagoa denean.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Atzizki bat itzultzen duen azpitala itzultzen du.
    ///
    /// Xerra `suffix`-rekin amaitzen bada, azpizerra itzultzen da atzizkiaren aurretik, `Some`-n bilduta.
    /// `suffix` hutsik badago, jatorrizko xerra itzuliko da.
    ///
    /// Xerra `suffix`-rekin amaitzen ez bada, `None` itzultzen da.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Funtzio honek berriro idatzi beharko du SlicePattern sofistikatuagoa denean.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Bitarrek ordenatutako xerra honetan bilatzen du elementu jakin bat bilatzeko.
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.
    /// Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    ///
    /// Ikus [`binary_search_by`], [`binary_search_by_key`] eta [`partition_point`] ere.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Lau elementuz osatutako multzoa bilatzen du.
    /// Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Elementu bat sailkatutako vector batean txertatu nahi baduzu, ordenatzeko ordena mantenduz:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Bitarrek ordenatutako xerra hau konparazio funtzio batekin bilatzen du.
    ///
    /// Konparazio funtzioak azpiko zatiaren ordenazio ordenarekin bat datorren ordena ezarri beharko luke, bere argumentua `Less`, `Equal` edo `Greater` nahi den xedea den adierazten duen eskaera kodea itzultzeko.
    ///
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    /// Ikus [`binary_search`], [`binary_search_by_key`] eta [`partition_point`] ere.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Lau elementuz osatutako multzoa bilatzen du.Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEGURTASUNA: deia seguru egiten dute aldaezin hauek:
            // - `mid >= 0`
            // - `mid < size`: `mid` `[left; right)` mugatuta dago.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // if/else kontrol-fluxua bat etortzea baino gehiago erabiltzearen arrazoia bat-etortzeak alderaketa eragiketak berriro antolatzen dituelako da, hau da, oso sentikorra da.
            //
            // Hau da x86 asm u8 rako: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Bitarrek ordenatutako xerra hau bilatzeko gako erauzketa funtzio batekin bilatzen du.
    ///
    /// Xerra teklaren arabera ordenatuta dagoela suposatzen du, adibidez [`sort_by_key`]-rekin tekla erauzketa funtzio bera erabiliz.
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.
    /// Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    ///
    /// Ikus [`binary_search`], [`binary_search_by`] eta [`partition_point`] ere.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Lau elementuren multzoa bilatzen du bigarren elementuen arabera sailkatutako bikote zatitan.
    /// Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links onartzen da `slice::sort_by_key` crate `alloc`-n dagoen bezala, eta, beraz, oraindik ez da existitzen `core` eraikitzerakoan.
    //
    // esteka downstream crate: #74481.Primitivak libstd (#73423) n soilik dokumentatzen direnez, horrek ez du inoiz lotura hautsirik sortzen praktikan.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Xerra ordenatzen du, baina baliteke elementu berdinen ordena ez gordetzea.
    ///
    /// Mota hau ezegonkorra da (elementu berdinak berrantolatu ditzake), lekuan bertan (hau da, ez du esleitzen) eta *O*(*n*\*log(* n*)) kasurik txarrena da).
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa Orson Peters-en [pattern-defeating quicksort][pdqsort]-n oinarritzen da, ausazko bizkortasunaren batez besteko kasu azkarra eta pisu handieneko kasurik azkarrena konbinatzen dituena, zenbait eredu dituzten zatietan denbora lineala lortuz.
    /// Zenbait ausazko erabilera erabiltzen du endekatutako kasuak ekiditeko, baina seed finkoarekin beti portaera determinista eskaintzeko.
    ///
    /// Normalean sailkapen egonkorra baino azkarragoa da, kasu berezi batzuetan izan ezik, adibidez, xerra kateatutako hainbat ordenatutako sekuentziek osatzen dutenean.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Xerra konparazio funtzio batekin ordenatzen du, baina baliteke elementu berdinen ordena ez gordetzea.
    ///
    /// Mota hau ezegonkorra da (elementu berdinak berrantolatu ditzake), lekuan bertan (hau da, ez du esleitzen) eta *O*(*n*\*log(* n*)) kasurik txarrena da).
    ///
    /// Konparazio funtzioak zatiko elementuen ordenamendu osoa zehaztu behar du.Ordena osoa ez bada, elementuen ordena zehaztu gabe dago.Ordena ordena osoa da (`a`, `b` eta `c` guztientzat):
    ///
    /// * totala eta antisimetrikoa: `a < b`, `a == b` edo `a > b` bat zehazki egia da, eta
    /// * iragankorrak, `a < b` eta `b < c`-k `a < c` dakar.Gauza bera gertatu behar da `==` eta `>` kasuan.
    ///
    /// Adibidez, [`f64`]-k [`Ord`] inplementatzen ez duen bitartean `NaN != NaN` delako, `partial_cmp` erabil dezakegu gure ordenatzeko funtzio gisa zatiak `NaN` bat ez duela dakigunean.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa Orson Peters-en [pattern-defeating quicksort][pdqsort]-n oinarritzen da, ausazko bizkortasunaren batez besteko kasu azkarra eta pisu handieneko kasurik azkarrena konbinatzen dituena, zenbait eredu dituzten zatietan denbora lineala lortuz.
    /// Zenbait ausazko erabilera erabiltzen du endekatutako kasuak ekiditeko, baina seed finkoarekin beti portaera determinista eskaintzeko.
    ///
    /// Normalean sailkapen egonkorra baino azkarragoa da, kasu berezi batzuetan izan ezik, adibidez, xerra kateatutako hainbat ordenatutako sekuentziek osatzen dutenean.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // alderantzizko sailkapena
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Xerra tekla erauzteko funtzioarekin ordenatzen du, baina baliteke elementu berdinen ordena ez gordetzea.
    ///
    /// Ordena hau ezegonkorra da (elementu berdinak berrantolatu ditzake), lekuan bertan (hau da, ez du esleitzen) eta *O*(m\* * n *\* log(*n*)) kasurik txarrena, tekla funtzioa *O* denean (*m*).
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa Orson Peters-en [pattern-defeating quicksort][pdqsort]-n oinarritzen da, ausazko bizkortasunaren batez besteko kasu azkarra eta pisu handieneko kasurik azkarrena konbinatzen dituena, zenbait eredu dituzten zatietan denbora lineala lortuz.
    /// Zenbait ausazko erabilera erabiltzen du endekatutako kasuak ekiditeko, baina seed finkoarekin beti portaera determinista eskaintzeko.
    ///
    /// Deitzeko gako estrategia dela eta, litekeena da [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) baino motelagoa izatea gako funtzioa garestia den kasuetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Berrantolatu xerra, `index` elementua azken sailkapenean kokatuta egon dadin.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Berrantolatu xerra funtzio konparatzaile batekin, `index` elementua bere azken kokapenean kokatuta egon dadin.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Ordenatu xerra tekla erauzteko funtzioarekin, `index` elementua azken kokapen ordenatuan egon dadin.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Berrantolatu xerra, `index` elementua azken sailkapenean kokatuta egon dadin.
    ///
    /// Berrordenatze honek `i < index` posizioko edozein balio `j > index` posizioko edozein balio baino txikiagoa edo berdina izango den propietate osagarria du.
    /// Gainera, berrantolaketa hau ezegonkorra da (hots
    /// edozein elementu berdinen kopurua `index` posizioan ama daiteke), bere lekuan (hots
    /// ez du esleitzen), eta *O*(*n*) kasurik okerrena.
    /// Funtzio hau "kth element" izenarekin ere ezagutzen da beste liburutegi batzuetan.
    /// Honako balio hauen hirukotea itzultzen du: emandako indizearen bat baino elementu guztiak gutxiago, emandako indizearen balioa eta emandako indizearen bat baino elementu guztiak handiagoak.
    ///
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [`sort_unstable`] rako erabilitako algoritmo bizkor bereko hautaketa bizkorreko zatian oinarritzen da.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics `index >= len()` denean, hau da, beti panics xerra hutsetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Bilatu mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Xerra honako hauetako bat izango dela ziurtatzen dugu, zehaztutako indizea ordenatzeko moduan oinarrituta.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Berrantolatu xerra funtzio konparatzaile batekin, `index` elementua bere azken kokapenean kokatuta egon dadin.
    ///
    /// Berrordenatze honek `i < index` posizioko edozein balio `j > index` posizio bateko edozein balio baino txikiagoa edo berdina izango da konparazio funtzioa erabiliz.
    /// Gainera, berrantolaketa hau ezegonkorra da (hau da, elementu berdinen kopuru guztiak `index` posizioan amaituko du), lekuan bertan (hau da, ez du esleitzen) eta *O*(*n*) kasurik txarrena da.
    /// Funtzio hau "kth element" izenarekin ere ezagutzen da beste liburutegi batzuetan.
    /// Honako balio hauen hirukotea itzultzen du: emandako indizearen bat baino elementu guztiak gutxiago, emandako indizearen balioa eta emandako indize horretakoa baino elementu guztiak handiagoak, emandako konparazio funtzioa erabiliz.
    ///
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [`sort_unstable`] rako erabilitako algoritmo bizkor bereko hautaketa bizkorreko zatian oinarritzen da.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics `index >= len()` denean, hau da, beti panics xerra hutsetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Bilatu mediana xerra beheranzko ordenan ordenatuta egongo balitz bezala.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Xerra honako hauetako bat izango dela ziurtatzen dugu, zehaztutako indizea ordenatzeko moduan oinarrituta.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ordenatu xerra tekla erauzteko funtzioarekin, `index` elementua azken kokapen ordenatuan egon dadin.
    ///
    /// Berrordenatze honek `i < index` posizioko edozein balio `j > index` posizioko edozein balio baino txikiagoa edo berdina izango da gakoa ateratzeko funtzioa erabiliz.
    /// Gainera, berrantolaketa hau ezegonkorra da (hau da, elementu berdinen kopuru guztiak `index` posizioan amaituko du), lekuan bertan (hau da, ez du esleitzen) eta *O*(*n*) kasurik txarrena da.
    /// Funtzio hau "kth element" izenarekin ere ezagutzen da beste liburutegi batzuetan.
    /// Honako balio hauen hirukotea itzultzen du: emandako indizearen bat baino elementu gutxiago, emandako indizearen balioa eta emandako indizearen bat baino elementu guztiak handiagoak, emandako gako erauzketa funtzioa erabiliz.
    ///
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [`sort_unstable`] rako erabilitako algoritmo bizkor bereko hautaketa bizkorreko zatian oinarritzen da.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics `index >= len()` denean, hau da, beti panics xerra hutsetan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Itzuli mediana matrizea balio absolutuaren arabera ordenatuko balitz bezala.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Xerra honako hauetako bat izango dela ziurtatzen dugu, zehaztutako indizea ordenatzeko moduan oinarrituta.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Ondoz ondoko errepikatutako elementu guztiak zatiaren amaierara eramaten ditu [`PartialEq`] trait inplementazioaren arabera.
    ///
    ///
    /// Bi xerra itzultzen ditu.Lehenengoak ez du jarraian errepikatutako elementurik.
    /// Bigarrenean bikoiztu guztiak daude zehaztutako ordenarik gabe.
    ///
    /// Xerra ordenatuta badago, itzulitako lehen zatiak ez du bikoizturik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Berdintasun erlazio jakin bat betetzen duen zatiaren amaierara eramaten ditu ondoz ondoko elementu guztiak izan ezik.
    ///
    /// Bi xerra itzultzen ditu.Lehenengoak ez du jarraian errepikatutako elementurik.
    /// Bigarrenean bikoiztu guztiak daude zehaztutako ordenarik gabe.
    ///
    /// `same_bucket` funtzioak zatitik bi elementutarako erreferentziak igarotzen ditu eta elementuak berdinak diren ala ez zehaztu behar du.
    /// Elementuak zatian duten ordenaren kontrako ordenan igarotzen dira; beraz, `same_bucket(a, b)` `true` itzultzen bada, `a` zatiaren amaieran mugitzen da.
    ///
    ///
    /// Xerra ordenatuta badago, itzulitako lehen zatiak ez du bikoizturik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` erreferentzia alda dezakegun arren, ezin ditugu aldaketa * arbitrarioak egin.`same_bucket` deiak panic izan litezke, beraz, xerra uneoro baliozko egoera dagoela ziurtatu behar dugu.
        //
        // Hori kudeatzeko modua swapak erabiliz da;elementu guztien gainetik errepikatzen dugu, joan ahala trukatuz, amaieran gorde nahi ditugun elementuak aurrealdean egon daitezen eta baztertu nahi ditugunak atzeko aldean egon daitezen.
        // Xerra zatitu dezakegu.
        // Eragiketa hau `O(n)` da oraindik.
        //
        // Adibidez: egoera honetan hasten gara, non `r`-k "hurrengo" adierazten duen
        // irakurri "eta `w`-k" hurrengo_idatzi 'adierazten du.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] bere buruarekin konparatuz [w-1], hau ez da bikoiztua, beraz self[r] eta self[w] trukatzen ditugu (efekturik ez=r==w) eta gero r eta w gehitzen ditugu, honela utzita:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] norberaren [w-1] alderatuz gero, balio hori bikoiztua da, beraz `r` gehitzen dugu baina beste guztia aldatu gabe uzten dugu:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] bere buruarekin konparatuz [w-1], hau ez da bikoiztua, beraz trukatu self[r] eta self[w] eta aurreratu r eta w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ez da bikoiztua, errepikatu:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Bikoiztua, advance r. End xerra.Zatitu w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEGURTASUNA: `while` baldintzak `next_read` eta `next_write` bermatzen ditu
        // `len` baino gutxiago dira, beraz `self` barruan daude.
        // `prev_ptr_write` `ptr_write` aurretik elementu bat seinalatzen du, baina `next_write` 1etik hasten da, beraz, `prev_ptr_write` ez da inoiz 0 baino txikiagoa eta zatiaren barruan dago.
        // Honek `ptr_read`, `prev_ptr_write` eta `ptr_write` desferentziatzeko eta `ptr.add(next_read)`, `ptr.add(next_write - 1)` eta `prev_ptr_write.offset(1)` erabiltzeko baldintzak betetzen ditu.
        //
        //
        // `next_write` gehitzen da gehienez ere behin begizta bakoitzean, hau da, ez da elementurik saltatzen trukatu behar denean.
        //
        // `ptr_read` eta `prev_ptr_write`-k ez dute inoiz elementu bera seinalatzen.Hori beharrezkoa da `&mut *ptr_read`, `&mut* prev_ptr_write` segurua izan dadin.
        // Azalpena `next_read >= next_write` beti egia dela da, beraz `next_read > next_write - 1` ere bai.
        //
        //
        //
        //
        //
        unsafe {
            // Saihestu mugen kontrolak erakusle gordinak erabiliz.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Gako berera ebazten duten zatiaren amaierara eramaten ditu ondoz ondoko elementu guztiak izan ezik.
    ///
    ///
    /// Bi xerra itzultzen ditu.Lehenengoak ez du jarraian errepikatutako elementurik.
    /// Bigarrenean bikoiztu guztiak daude zehaztutako ordenarik gabe.
    ///
    /// Xerra ordenatuta badago, itzulitako lehen zatiak ez du bikoizturik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Xerra bere lekuan biratzen du, zatiaren lehen `mid` elementuak amaieraraino mugitzen diren bitartean azken `self.len() - mid` elementuak aurrealdera mugitzen diren bitartean.
    /// `rotate_left` deitu ondoren, aurretik `mid` aurkibideko elementua zatiko lehen elementua bihurtuko da.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da `mid` zatiaren luzera baino handiagoa bada.Kontuan izan `mid == self.len()`-k _not_ panic egiten duela eta operazio gabeko biraketa dela.
    ///
    /// # Complexity
    ///
    /// Lineala hartzen du (`self.len()`) denboran.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Azpi-xerra biratzea:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEGURTASUNA: `[p.add(mid) - mid, p.add(mid) + k)` barrutia hutsala da
        // irakurtzeko eta idazteko balio du, `ptr_rotate`-k eskatzen duen moduan.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Xerra bere lekuan biratzen du, zatiaren lehen `self.len() - k` elementuak amaieraraino mugitzen diren bitartean azken `k` elementuak aurrealdera mugitzen diren bitartean.
    /// `rotate_right` deitu ondoren, aurretik `self.len() - k` aurkibideko elementua zatiko lehen elementua bihurtuko da.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da `k` zatiaren luzera baino handiagoa bada.Kontuan izan `k == self.len()`-k _not_ panic egiten duela eta operazio gabeko biraketa dela.
    ///
    /// # Complexity
    ///
    /// Lineala hartzen du (`self.len()`) denboran.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Biratu azpiluze bat:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEGURTASUNA: `[p.add(mid) - mid, p.add(mid) + k)` barrutia hutsala da
        // irakurtzeko eta idazteko balio du, `ptr_rotate`-k eskatzen duen moduan.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `self` elementuekin betetzen du `value` klonatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` betetzen ditu itxiera behin eta berriz deituz itzultzen diren elementuekin.
    ///
    /// Metodo honek itxiera bat erabiltzen du balio berriak sortzeko.[`Clone`] balio jakin bat nahiago baduzu, erabili [`fill`].
    /// [`Default`] trait balioak sortzeko erabili nahi baduzu, [`Default::default`] pasa dezakezu argumentu gisa.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src`-tik `self`-ra elementuak kopiatzen ditu.
    ///
    /// `src`-ren luzerak `self`-ren berdina izan behar du.
    ///
    /// `T`-k `Copy` inplementatzen badu, errendimendu handiagoa izan dezake [`copy_from_slice`] erabiltzea.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da bi zatiek luzera desberdinak badituzte.
    ///
    /// # Examples
    ///
    /// Bi elementu klonatzea xerra batetik bestera:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Xerrek luzera bera izan behar dutenez, iturburuko xerra lau elementuetatik bitan zatitzen dugu.
    /// // panic izango da hau egiten ez badugu.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust-k aplikatzen du esparru jakin bateko datu jakin bati buruzko erreferentzia aldaezinik ez duen erreferentzia aldagarri bakarra egon daitekeela.
    /// Hori dela eta, `clone_from_slice` xerra bakarrean erabiltzen saiatzeak konpilazio porrota eragingo du:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Horren inguruan lan egiteko, [`split_at_mut`] erabil dezakegu xerra batetik bi azpiatal desberdin sortzeko:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// `src`-tik `self`-ra elementu guztiak kopiatzen ditu memcpy erabiliz.
    ///
    /// `src`-ren luzerak `self`-ren berdina izan behar du.
    ///
    /// `T`-k `Copy` inplementatzen ez badu, erabili [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da bi zatiek luzera desberdinak badituzte.
    ///
    /// # Examples
    ///
    /// Xerra batetik beste bi elementu kopiatzea:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Xerrek luzera bera izan behar dutenez, iturburuko xerra lau elementuetatik bitan zatitzen dugu.
    /// // panic izango da hau egiten ez badugu.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust-k aplikatzen du esparru jakin bateko datu jakin bati buruzko erreferentzia aldaezinik ez duen erreferentzia aldagarri bakarra egon daitekeela.
    /// Hori dela eta, `copy_from_slice` xerra bakarrean erabiltzen saiatzeak konpilazio porrota eragingo du:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Horren inguruan lan egiteko, [`split_at_mut`] erabil dezakegu xerra batetik bi azpiatal desberdin sortzeko:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic kode bidea funtzio hotz batean jarri da deiaren gunea ez lehertzeko.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEGURTASUNA: `self` balio du `self.len()` elementuek definizioz eta `src`-k
        // luzera bera duela egiaztatu da.
        // Xerra ezin da gainjarri erreferentzia aldaezinak esklusiboak direlako.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Xerraren zati batetik berezko beste zati batera kopiatzen ditu elementuak, memmove erabiliz.
    ///
    /// `src` kopiatzeko `self` barruan dagoen barrutia da.
    /// `dest` kopiatzeko `self` barrutiaren hasierako indizea da, `src` ren luzera bera izango duena.
    /// Bi barrutiak gainjarri daitezke.
    /// Bi barrutien muturrek `self.len()` baino txikiagoa edo berdina izan behar dute.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da, tarteak zatiaren amaiera gainditzen badu edo `src` ren amaiera hasiera baino lehen badago.
    ///
    ///
    /// # Examples
    ///
    /// Lau byte kopiatzea zati batean:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEGURTASUNA: `ptr::copy` baldintzak goian egiaztatu dira,
        // `ptr::add`-rako bezala.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self`-ko elementu guztiak `other`-koekin trukatzen ditu.
    ///
    /// `other`-ren luzerak `self`-ren berdina izan behar du.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da bi zatiek luzera desberdinak badituzte.
    ///
    /// # Example
    ///
    /// Bi elementu xerratan trukatzea:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust-k datu jakin bati buruzko erreferentzia aldagarri bakarra egon daitekeela bermatzen du esparru jakin batean.
    ///
    /// Hori dela eta, `swap_with_slice` xerra bakarrean erabiltzen saiatzeak konpilazio porrota eragingo du:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Horren inguruan lan egiteko, [`split_at_mut`] erabil dezakegu xerra batetik aldagarriak diren bi azpi-xerrak sortzeko:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEGURTASUNA: `self` balio du `self.len()` elementuek definizioz eta `src`-k
        // luzera bera duela egiaztatu da.
        // Xerra ezin da gainjarri erreferentzia aldaezinak esklusiboak direlako.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Erdiaren eta amaierako zatiaren luzerak `align_to{,_mut}`-en kalkulatzeko funtzioa.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest`-i buruz egingo duguna da irudikatzea zer `U` multiplo jar dezakegun`T` kopuru txikienean.
        //
        // Eta zenbat `T` behar ditugu horrelako "multiple" bakoitzeko.
        //
        // Demagun adibidez T=u8 U=u16.Ondoren, 1 U 2 Ts-tan jar dezakegu.Sinplea.
        // Orain, kontuan hartu, adibidez, size_of: :<T>=16, tamaina_ren::<U>=24.</u>
        // 2 Us jar ditzakegu `rest` zatian 3 Ts bakoitzaren ordez.
        // Pixka bat zailagoa.
        //
        // Hau kalkulatzeko formula hau da:
        //
        // Gu= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Zabaldu eta sinplifikatu:
        //
        // Gu=tamaina_ren: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Zorionez, hori guztia etengabe ebaluatzen denez ... errendimenduak ez du axola!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein-en algoritmoa Oraindik `const fn` hau egin beharko genuke (eta hala egiten badugu algoritmo errekurtsibora itzuli), hau guztia garatzeko llvm-n oinarritzea delako ... bueno, deserosoa egiten zait.
            //
            //

            // SEGURTASUNA: `a` eta `b` zero ez diren balioak direla egiaztatzen da.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // kendu 2ren faktore guztiak b-tik
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEGURTASUNA: `b` zero ez dela egiaztatzen da.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ezagutza horrekin armatuta, zenbat `U` egokitu ditzakegu aurki ditzakegu!
        let us_len = self.len() / ts * us;
        // Eta zenbat `T` egongo dira amaierako zatian!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmititu xerra beste mota bateko xerra batera, moten lerrokatzea mantentzen dela ziurtatuz.
    ///
    /// Metodo honek xerra hiru zatitan bereizten ditu: aurrizkia, mota berri baten erdiko xerra behar bezala lerrokatuta eta xerra atzizkia.
    /// Metodoak erdiko zatiak mota jakin baterako eta sarrerako zatiak ahalik eta luzera handiena izan dezake, baina zure algoritmoaren errendimendua soilik horren araberakoa izan behar da, ez horren zuzentasuna.
    ///
    /// Sarrerako datu guztiak aurrizki edo atzizki xerra gisa itzultzea zilegi da.
    ///
    /// Metodo honek ez du helbururik `T` sarrerako elementuak edo `U` irteerako elementuak zero tamainakoak direnean eta jatorrizko xerra itzuliko dute ezer zatitu gabe.
    ///
    /// # Safety
    ///
    /// Metodo hau, funtsean, `transmute` bat da itzultzen den erdiko zatian dauden elementuei dagokienez, beraz, `transmute::<T, U>`-ri dagozkion ohiko oharpen guztiak ere hemen aplikatzen dira.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Kontuan izan funtzio hau gehienak etengabe ebaluatuko direla,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maneiatu ZSTak bereziki, hau da, ez itzazu batere maneiatu.
            return (self, &[], &[]);
        }

        // Lehenik eta behin, aurkitu zer puntutan banatzen dugun lehenengo eta bigarren zatiaren artean.
        // Erraza ptr.align_offset-rekin.
        let ptr = self.as_ptr();
        // SEGURTASUNA: Ikusi `align_to_mut` metodoa segurtasun iruzkin zehatza lortzeko.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEGURTASUNA: orain `rest` behin betiko lerrokatuta dago, beraz behean dagoen `from_raw_parts` ondo dago,
            // deitzaileak `T`-era `U`-era segurtasunez transmuta dezakegula bermatzen baitu.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmititu xerra beste mota bateko xerra batera, moten lerrokatzea mantentzen dela ziurtatuz.
    ///
    /// Metodo honek xerra hiru zatitan bereizten ditu: aurrizkia, mota berri baten erdiko xerra behar bezala lerrokatuta eta xerra atzizkia.
    /// Metodoak erdiko zatiak mota jakin baterako eta sarrerako zatiak ahalik eta luzera handiena izan dezake, baina zure algoritmoaren errendimendua soilik horren araberakoa izan behar da, ez horren zuzentasuna.
    ///
    /// Sarrerako datu guztiak aurrizki edo atzizki xerra gisa itzultzea zilegi da.
    ///
    /// Metodo honek ez du helbururik `T` sarrerako elementuak edo `U` irteerako elementuak zero tamainakoak direnean eta jatorrizko xerra itzuliko dute ezer zatitu gabe.
    ///
    /// # Safety
    ///
    /// Metodo hau, funtsean, `transmute` bat da itzultzen den erdiko zatian dauden elementuei dagokienez, beraz, `transmute::<T, U>`-ri dagozkion ohiko oharpen guztiak ere hemen aplikatzen dira.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Kontuan izan funtzio hau gehienak etengabe ebaluatuko direla,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maneiatu ZSTak bereziki, hau da, ez itzazu batere maneiatu.
            return (self, &mut [], &mut []);
        }

        // Lehenik eta behin, aurkitu zer puntutan banatzen dugun lehenengo eta bigarren zatiaren artean.
        // Erraza ptr.align_offset-rekin.
        let ptr = self.as_ptr();
        // SEGURTASUNA: Hemen Urako lerrokatutako erakusleak erabiliko ditugula ziurtatzen ari gara
        // gainerako metodoa.Hori erakusle bat&[T]-ra U-ra zuzendutako lerrokadurarekin pasatuz egiten da.
        // `crate::ptr::align_offset` deitzen zaio zuzen lerrokatutako eta baliozko `ptr` erakuslearekin (`self` erreferentzia batetik dator) eta bi potentzia duen tamainarekin (U-rako lerrokaduratik datorrenez), bere segurtasun-mugak betez.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ezin dugu `rest` berriro erabili ondoren, horrek bere aliasa `mut_ptr` baliogabetuko luke!SEGURTASUNA: ikusi `align_to` ren iruzkinak.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Xerra honetako elementuak ordenatuta dauden egiaztatzen du.
    ///
    /// Hau da, `a` elementu bakoitzarentzat eta bere hurrengo `b` elementuarentzat, `a <= b` eduki behar da.Xerra zehazki zero edo elementu bat ematen badu, `true` itzuliko da.
    ///
    /// Kontuan izan `Self::Item` `PartialOrd` bakarrik bada, baina `Ord` ez bada, goiko definizioak funtzio honek `false` itzultzen duela esan nahi du ondoz ondoko bi elementu konparagarriak ez badira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Xerra honetako elementuak emandako konparatzaile funtzioaren bidez ordenatuta dauden egiaztatzen du.
    ///
    /// `PartialOrd::partial_cmp` erabili beharrean, funtzio honek emandako `compare` funtzioa erabiltzen du bi elementuren ordenamendua zehazteko.
    /// Horretaz aparte, [`is_sorted`] ren baliokidea da;Informazio gehiagorako ikusi bere dokumentazioa.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Xerra honetako elementuak emandako gako erauzketa funtzioaren bidez ordenatuta dauden egiaztatzen du.
    ///
    /// Xerraren elementuak zuzenean alderatu beharrean, funtzio honek elementuen teklak alderatzen ditu, `f`-k zehazten duen moduan.
    /// Horretaz aparte, [`is_sorted`] ren baliokidea da;Informazio gehiagorako ikusi bere dokumentazioa.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Partizioaren puntuaren indizea ematen du emandako predikatuaren arabera (bigarren partizioaren lehen elementuaren indizea).
    ///
    /// Xerra emandako predikatuaren arabera zatituta dagoela suposatzen da.
    /// Horrek esan nahi du predikatuak egia itzultzen duen elementu guztiak zatiaren hasieran daudela eta predikatuak faltsuak ematen dituen elementu guztiak amaieran daudela.
    ///
    /// Adibidez, [7, 15, 3, 5, 4, 12, 6] x% 2!=0 predikatuaren azpian banatuta dago (zenbaki bakoiti guztiak hasieran daude, guztiak bukaeran).
    ///
    /// Xerra hau banatuta ez badago, itzulitako emaitza zehaztu gabe dago eta ez du zentzurik, metodo honek bilaketa bitarra egiten baitu.
    ///
    /// Ikus [`binary_search`], [`binary_search_by`] eta [`binary_search_by_key`] ere.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEGURTASUNA: `left < right` denean, `left <= mid < right`.
            // Beraz, `left` beti handitzen da eta `right` beti gutxitzen da, eta horietako bat hautatzen da.Bi kasuetan `left <= right` pozik dago.Beraz, `left < right` urrats batean bada, `left <= right` hurrengo urratsean konforme egongo da.
            //
            // Beraz, `left != right` betiere, `0 <= left < right <= len` pozik dago eta kasu honetan `0 <= mid < len` ere betetzen bada.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Luzera berdinean zatitu behar ditugu esplizituki
        // optimizatzaileak mugen egiaztapena ezabatzea errazteko.
        // Baina ezin da fidatu, espezializazio esplizitua dugu T: Kopiatzeko.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Xerra huts bat sortzen du.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Xerra huts aldakor bat sortzen du.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Xerratan dauden ereduak, gaur egun, `strip_prefix` eta `strip_suffix`-ek soilik erabiltzen dituzte.
/// future puntu batean, espero dugu `core::str::Pattern` (hau idazteko unean `str`-ra mugatuta dagoena) xerretara orokortzea eta, ondoren, trait hori ordezkatu edo ezabatu egingo da.
///
pub trait SlicePattern {
    /// Bat datorren zatiaren elementu mota.
    type Item;

    /// Gaur egun, `SlicePattern` kontsumitzaileek zati bat behar dute.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}