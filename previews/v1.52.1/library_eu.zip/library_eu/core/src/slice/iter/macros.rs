//! Xerra iteratzaileek erabilitako makroak.

// Is_empty eta len sartzeak errendimendu desberdintasun handia eragiten du
macro_rules! is_empty {
    // ZST iteratzaile baten luzera kodetzeko modua, honek ZST eta ZST ez direnentzat balio du.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Mugen egiaztapen batzuk kentzeko (ikus `position`), luzera ustekabeko modu batean kalkulatuko dugu.
// (`Codegen/slice-position-limits-check` probatuta.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // batzuetan segurtasunik gabeko bloke baten barruan erabiltzen gara

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ honek `unchecked_sub` erabiltzen du, biltzearen araberakoa baita ZST xerra iteratzaile luzeen luzera adierazteko.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Badakigu `start <= end`, beraz, sinatuta aurre egin behar duen `offset_from` baino hobeto egin dezakeela.
            // Hemen bandera egokiak ezarrita, LLVMri esan diezaiokegu, horrek mugen kontrolak kentzen laguntzen du.
            // SEGURTASUNA: aldakorra den motaren arabera, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM-ri ere erakusleak motaren tamainako multiplo zehatz batez bereizita daudela esanez, `len() == 0` `start == end`-ra `(end - start) < size`-ren ordez optimiza dezake.
            //
            // SEGURTASUNA: mota aldakorraren arabera, erakusleak lerrokatuta daude
            //         haien arteko distantziak puntaren tamainako multiploa izan behar du
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` eta `IterMut` iteratzaileen definizio partekatua
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Lehenengo elementua itzultzen du eta iteratzailearen hasiera 1 aurrera mugitzen du.
        // Errendimendua asko hobetzen du txertatutako funtzio batekin alderatuta.
        // Iteratzaileak ez du hutsik egon behar.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Azken elementua itzultzen du eta iteratzailearen amaiera 1 mugitzen du atzerantz.
        // Errendimendua asko hobetzen du txertatutako funtzio batekin alderatuta.
        // Iteratzaileak ez du hutsik egon behar.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Iteratzailea txikitzen du T ZST denean, iteratzailearen amaiera `n`-rekin atzerantz mugituz.
        // `n` ez du `self.len()` baino handiagoa izan behar.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Laguntzailearen funtzioa iteratzailetik xerra bat sortzeko.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SEGURTASUNA: iteratzailea erakuslea duen xerra batetik sortu zen
                // `self.ptr` eta luzera `len!(self)`.
                // Horrek bermatzen du `from_raw_parts` ren aurrebaldintza guztiak betetzen direla.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Laguntzailearen funtzioa iteratzailearen hasiera `offset` elementuak aurrera eramateko, hasiera zaharra itzuliz.
            //
            // Ez da segurua, desplazamenduak ez baitu `self.len()` baino handiagoa izan behar.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SEGURTASUNA: deitzaileak `offset` `self.len()` baino handiagoa ez dela bermatzen du,
                    // beraz, erakusle berri hau `self` barruan dago eta, beraz, nulua ez dela bermatuko da.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Laguntzailearen funtzioa iteratzailearen amaiera `offset` elementuekin atzerantz mugitzeko, amaiera berria itzultzeko.
            //
            // Ez da segurua, desplazamenduak ez baitu `self.len()` baino handiagoa izan behar.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SEGURTASUNA: deitzaileak `offset` `self.len()` baino handiagoa ez dela bermatzen du,
                    // horrek bermatzen du `isize` bat gainezka ez egitea.
                    // Gainera, lortutako erakuslea `slice`-ren mugetan dago, `offset`-erako beste baldintzak betetzen dituena.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // zatiekin inplementa liteke, baina horrek mugen kontrolak ekiditen ditu

                // SEGURTASUNA: `assume` deiak seguruak dira zatiaren hasierako erakuslea denetik
                // baliogabeak izan behar dira, eta ZST ez diren zatiek bukaerako erakuslea ere izan behar dute.
                // `next_unchecked!` rako deia segurua da, lehenik eta behin errepikatzailea hutsik dagoen egiaztatzen baitugu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iteratzaile hau hutsik dago orain.
                    if mem::size_of::<T>() == 0 {
                        // Horrela egin behar dugu, `ptr` agian ez da inoiz 0 izango, baina `end` izan daiteke (biltzearen ondorioz).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SEGURTASUNA: amaiera ezin da 0 izan, T ez bada ZST, ptr 0 ez delako eta amaiera>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SEGURTASUNA: mugetan gaude.`post_inc_start`-k gauza egokia egiten du ZSTetarako ere.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            // Gainera, `assume`-k mugen egiaztapena ekiditen du.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SEGURTASUNA: begizta aldaezinaren arabera mugetan egongo garela ziurtatzen dugu:
                        // `i >= n` denean, `self.next()`-k `None` itzultzen du eta begizta hausten da.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` erabiltzen duen lehenetsitako inplementazioa gainidatziko dugu, inplementazio sinple honek LLVM IR gutxiago sortzen duelako eta konpilatzen azkarragoa delako.
            // Gainera, `assume`-k mugen egiaztapena ekiditen du.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SEGURTASUNA: `i` `n` baino txikiagoa izan behar da `n`-n hasten denetik
                        // eta gutxitzen ari da.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SEGURTASUNA: deitzaileak `i`-ren mugan dagoela bermatu behar du
                // azpiko xerra, beraz, `i`-k ezin du `isize` gainezka egin, eta itzultzen diren erreferentziek zatiaren elementu bati erreferentzia egiten diotela ziurtatzen da eta, beraz, baliozkoak direla ziurtatzen da.
                //
                // Kontuan izan ere, deitzaileak ere bermatzen duela ez gaituela berriro deitu indize berarekin eta azpisala honetara sartuko diren beste metodo batzuk ez direla deitzen, beraz, baliozko da itzulitako erreferentzia aldakorra izan dadin
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // zatiekin inplementa liteke, baina horrek mugen kontrolak ekiditen ditu

                // SEGURTASUNA: `assume` deiak seguruak dira, zatiaren hasierako erakusleak nulua izan behar du,
                // eta ZST ez diren gaineko zatiek bukaerako erakuslea ere ez dute izan behar.
                // `next_back_unchecked!` rako deia segurua da, lehenik eta behin errepikatzailea hutsik dagoen egiaztatzen baitugu.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iteratzaile hau hutsik dago orain.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SEGURTASUNA: mugetan gaude.`pre_dec_end`-k gauza egokia egiten du ZSTetarako ere.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}