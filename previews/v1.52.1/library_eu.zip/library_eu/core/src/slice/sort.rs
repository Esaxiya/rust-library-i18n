//! Xerren sailkapena
//!
//! Modulu honek Orson Peters-en ereduak garaitzeko quicksort oinarritutako ordenatze algoritmo bat du, hemen argitaratua: <https://github.com/orlp/pdqsort>
//!
//!
//! Ordenaketa ezegonkorra libcore-rekin bateragarria da, ez baitu memoria esleitzen, gure ordenatze inplementazio egonkorrak ez bezala.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Erortzen denean, `src`-tik `dest`-ra kopiatzen dira.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEGURTASUNA: laguntzaile klasea da.
        //          Mesedez, kontsultatu zuzena den erabilera.
        //          Hots, ziurtatu behar da `src` eta `dst` ez direla gainjartzen `ptr::copy_nonoverlapping`-k eskatzen duen moduan.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Lehenengo elementua eskuinera desplazatzen du elementu handiagoa edo berdina topatu arte.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURTASUNA: beheko segurtasunik gabeko eragiketak egiaztapen loturarik gabe indexatzea dakar (`get_unchecked` eta `get_unchecked_mut`)
    // eta memoria (`ptr::copy_nonoverlapping`) kopiatzea.
    //
    // a.Indexazioa:
    //  1. Arrayaren tamaina>=2ra egiaztatu dugu.
    //  2. Egingo dugun indexazio guztia {0 <= index < len} artekoa da gehienez ere.
    //
    // b.Memoriaren kopia
    //  1. Baliagarriak direla bermatzen duten erreferentzien inguruko erakusleak lortzen ari gara.
    //  2. Ezin dira gainjarri xaflaren desberdintasun indizeak erakusteko.
    //     Hots, `i` eta `i-1`.
    //  3. Xerra behar bezala lerrokatuta badago, elementuak behar bezala lerrokatuta daude.
    //     Deitzailearen ardura da xerra behar bezala lerrokatuta dagoela ziurtatzea.
    //
    // Ikusi beheko iruzkinak xehetasun gehiagorako.
    unsafe {
        // Lehenengo bi elementuak desordenatuta badaude ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Irakurri lehen elementua pilatutako esleitutako aldagai batean.
            // panics ondorengo konparazio-eragiketa eginez gero, `hole` erori egingo da eta automatikoki elementua berriro zatian idatziko du.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mugitu `i`-th elementua leku bat ezkerrera, horrela zuloa eskuinera aldatuz.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` erortzen da eta horrela `tmp` kopiatzen du `v`-ko gainerako zuloan.
        }
    }
}

/// Azken elementua ezkerrera desplazatzen du elementu txikiagoa edo berdina topatu arte.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURTASUNA: beheko segurtasunik gabeko eragiketak egiaztapen loturarik gabe indexatzea dakar (`get_unchecked` eta `get_unchecked_mut`)
    // eta memoria (`ptr::copy_nonoverlapping`) kopiatzea.
    //
    // a.Indexazioa:
    //  1. Arrayaren tamaina>=2ra egiaztatu dugu.
    //  2. Egingo dugun indexazio guztia `0 <= index < len-1` artekoa da gehienez ere.
    //
    // b.Memoriaren kopia
    //  1. Baliagarriak direla bermatzen duten erreferentzien inguruko erakusleak lortzen ari gara.
    //  2. Ezin dira gainjarri xaflaren desberdintasun indizeak erakusteko.
    //     Hots, `i` eta `i+1`.
    //  3. Xerra behar bezala lerrokatuta badago, elementuak behar bezala lerrokatuta daude.
    //     Deitzailearen ardura da xerra behar bezala lerrokatuta dagoela ziurtatzea.
    //
    // Ikusi beheko iruzkinak xehetasun gehiagorako.
    unsafe {
        // Azken bi elementuak desordenatuta badaude ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Irakurri azken elementua pilatutako esleitutako aldagai batean.
            // panics ondorengo konparazio-eragiketa eginez gero, `hole` erori egingo da eta automatikoki elementua berriro zatian idatziko du.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mugitu `i`-garren elementua eskuinera, horrela zuloa ezkerrera aldatuz.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` erortzen da eta horrela `tmp` kopiatzen du `v`-ko gainerako zuloan.
        }
    }
}

/// Partzialki zati bat ordenatzen du ordenaz kanpoko hainbat elementu aldatuz.
///
/// `true` ematen du xerra amaieran ordenatuta badago.Funtzio hau *O*(*n*) da kasurik okerrena.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Aldatu egingo diren ordenaz kanpoko bikoteen gehieneko kopurua.
    const MAX_STEPS: usize = 5;
    // Xerra hau baino laburragoa bada, ez aldatu elementurik.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEGURTASUNA: dagoeneko lotura egiaztapena `i < len`-ekin esplizituki egin genuen.
        // Ondorengo gure indexazio guztia `0 <= index < len` tartean dago
        unsafe {
            // Bilatu ondoko ordenaz kanpoko elementuen hurrengo bikotea.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Bukatu al dugu?
        if i == len {
            return true;
        }

        // Ez aldatu elementuak array motzetan, horrek errendimendu kostua du.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Trukatu aurkitutako elementu bikotea.Horrek orden egokian jartzen ditu.
        v.swap(i - 1, i);

        // Aldatu elementu txikiena ezkerrera.
        shift_tail(&mut v[..i], is_less);
        // Aldatu elementu handiagoa eskuinera.
        shift_head(&mut v[i..], is_less);
    }

    // Ez dut xerra urrats kopuru mugatuan ordenatzea lortu.
    false
}

/// Xerra bat ordenatzen du txertatze ordenaren bidez, hau da,*O*(*n*^ 2) kasurik okerrena.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` ordenatzen du heapsort erabiliz, eta horrek *O*(*n*\*log(* n*)) kasurik txarrena bermatzen du.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Pila bitar honek `parent >= child` aldaezina errespetatzen du.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node`-ko umeak:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Aukeratu haur nagusia.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Gelditu aldaezina `node`-n mantentzen bada.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Trukatu `node` haur handiagoarekin, egin urrats bat beherantz eta jarraitu bahetzen.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Eraiki piloa denbora linealean.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Atera gehieneko elementuak pilatik.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partizioak `v` `pivot` baino txikiagoak diren elementuetan, eta ondoren `pivot` baino handiagoak edo berdinak diren elementuak.
///
///
/// `pivot` baino elementu txikiagoak ematen ditu.
///
/// Partizionamendua blokez bloke egiten da adarkatze eragiketen kostua minimizatzeko.
/// Ideia hau [BlockQuicksort][pdf] paperean aurkezten da.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Bloke tipiko bateko elementu kopurua.
    const BLOCK: usize = 128;

    // Partizio algoritmoak urrats hauek errepikatzen ditu amaitu arte:
    //
    // 1. Trazatu bloke bat ezkerreko aldetik pibotearen handiagoak edo berdinak diren elementuak identifikatzeko.
    // 2. Trazatu bloke bat eskuinaldetik pibota baino txikiagoak diren elementuak identifikatzeko.
    // 3. Trukatu identifikatutako elementuak ezkerreko eta eskuineko aldearen artean.
    //
    // Elementu bloke baterako aldagai hauek gordetzen ditugu:
    //
    // 1. `block` - Blokeko elementu kopurua.
    // 2. `start` - Hasi erakuslea `offsets` array-ra.
    // 3. `end` - Amaitu erakuslea `offsets` array-ra.
    // 4. `konpentsazioak, blokeko ordenaz kanpoko elementuen indizeak.

    // Ezkerreko uneko blokea (`l`-tik `l.add(block_l)`)-ra.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Uneko blokea eskuinaldean (`r.sub(block_r)` to `r`)-tik aurrera.
    // SEGURTASUNA: .add() dokumentazioan zehazki aipatzen da `vec.as_ptr().add(vec.len())` beti segurua dela '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLAak lortzen ditugunean, saiatu `min(v.len(), 2 * BLOCK) `luzerako array bat sortzen
    // `BLOCK` luzerako neurri finkoen bi array baino gehiago.Baliteke VLAak cache-eraginkorragoak izatea.

    // `l` (inclusive) eta `r` (exclusive) erakusleen arteko elementu kopurua itzultzen du.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Blokez bloke partizioarekin amaitu dugu `l` eta `r` oso hurbil daudenean.
        // Ondoren, adabaki batzuk egiten ditugu tartean geratzen diren elementuak zatitzeko.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Gainerako elementu kopurua (oraindik ez da pibotarekin alderatzen).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Doitu blokeen neurriak ezkerreko eta eskuineko blokeak gainjarri ez daitezen, baina guztiz lerrokatuta geratzen den gainerako hutsunea estaltzeko.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Aztarna `block_l` elementuak ezkerreko aldetik.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEGURTASUNA: beheko segurtasunik gabeko eragiketek `offset` erabiltzea dakarte.
                //         Funtzioak eskatzen dituen baldintzen arabera, hauek betetzen ditugu:
                //         1. `offsets_l` pila esleituta dago eta, beraz, esleitutako objektu bereizitzat hartzen da.
                //         2. `is_less` funtzioak `bool` itzultzen du.
                //            `bool` bat igotzeak ez du inoiz `isize` gainezka egingo.
                //         3. `block_l` `<= BLOCK` izango dela bermatu dugu.
                //            Gainera, `end_l` hasieran `offsets_`-ren hasierako erakusleari ezarri zitzaion pila aldarrikatu zen.
                //            Beraz, badakigu kasurik okerrenean ere (`is_less` ren dei guztiak faltsuak direla), gehienez ere byte bateko amaiera gaindituko dugula.
                //        Hemen segurtasunik gabeko beste eragiketa bat `elem` ez erreferentziatzea da.
                //        Hala ere, `elem` hasieran erakuslea izan zen beti baliozkoa den zatiari.
                unsafe {
                    // Adar gabeko konparazioa.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traza itzazu `block_r` elementuak eskuinaldetik.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEGURTASUNA: beheko segurtasunik gabeko eragiketek `offset` erabiltzea dakarte.
                //         Funtzioak eskatzen dituen baldintzen arabera, hauek betetzen ditugu:
                //         1. `offsets_r` pila esleituta dago eta, beraz, esleitutako objektu bereizitzat hartzen da.
                //         2. `is_less` funtzioak `bool` itzultzen du.
                //            `bool` bat igotzeak ez du inoiz `isize` gainezka egingo.
                //         3. `block_r` `<= BLOCK` izango dela bermatu dugu.
                //            Gainera, `end_r` hasieran `offsets_`-ren hasierako erakusleari ezarri zitzaion pila aldarrikatu zen.
                //            Horrela, badakigu kasurik okerrenean ere (`is_less` ren dei guztiak egia itzultzen direla) gehienez ere byte bateko amaiera gaindituko dugula.
                //        Hemen segurtasunik gabeko beste eragiketa bat `elem` ez erreferentziatzea da.
                //        Hala ere, hasieran `elem` `1 *sizeof(T)` amaieratik pasatzen zen eta `1* sizeof(T)`-ek gutxitzen dugu sartu aurretik.
                //        Gainera, `block_r` `BLOCK` baino txikiagoa zela baieztatu zen eta, beraz, `elem` ek zatiaren hasierara seinalatuko zuen gehienez.
                unsafe {
                    // Adar gabeko konparazioa.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Ezkerreko eta eskuineko aldearen artean aldatzeko ordenaz kanpoko elementuen kopurua.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Une horretan bikote bat trukatu beharrean, eraginkorragoa da permutazio ziklikoa egitea.
            // Hau ez da trukatzearen parekoa, baina antzeko emaitza sortzen du memoria eragiketa gutxiago erabiliz.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ezkerreko blokeko ordenaz kanpoko elementu guztiak mugitu ziren.Joan hurrengo blokera.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Eskuineko blokeko ordenaz kanpoko elementu guztiak mugitu ziren.Joan aurreko blokera.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Orain geratzen den guztia gehienez bloke bat da (ezkerra edo eskuina) mugitu beharreko ordenaz kanpoko elementuekin.
    // Gainerako elementuak beren blokearen bukaerara mugitu daitezke.
    //

    if start_l < end_l {
        // Ezkerreko blokea geratzen da.
        // Mugitu gainerako ordenaz kanpoko elementuak eskuin muturrera.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Eskuineko blokea geratzen da.
        // Mugitu gainerako ordenaz kanpoko elementuak ezkerrera.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Beste ezer egiteko, amaitu dugu.
        width(v.as_mut_ptr(), l)
    }
}

/// Partizioak `v` `v[pivot]` baino txikiagoak diren elementuetan, eta ondoren `v[pivot]` baino handiagoak edo berdinak diren elementuak.
///
///
/// Honako tupla itzultzen du:
///
/// 1. `v[pivot]` baino elementu txikiagoa.
/// 2. Egia da `v` lehendik partizionatuta baldin badago.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Jarri pibota zatiaren hasieran.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Irakurri pibota eraginkortasunerako pilatutako esleitutako aldagai batean.
        // panics ondorengo konparazio eragiketa eginez gero, pibota automatikoki idatziko da zatian.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Bilatu ordenaz kanpoko elementuen lehen bikotea.
        let mut l = 0;
        let mut r = v.len();

        // SEGURTASUNA: beheko segurtasun ezak array bat indexatzea dakar.
        // Lehenengoari dagokionez: dagoeneko hemen egiten ditugu mugak egiaztatzen `l < r`-rekin.
        // Bigarrenerako: hasieran `l == 0` eta `r == v.len()` ditugu eta indexazio eragiketa guztietan `l < r` hori egiaztatu dugu.
        //                     Hemendik aurrera jakin badakigu `r`-k gutxienez `r == l` izan behar duela lehenengotik baliozkoa zela frogatuta.
        unsafe {
            // Bilatu lehen elementua pibotearen handiagoa edo berdina.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Aurkitu pibota baino txikiagoa den azken elementua.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` eremutik atera eta pibota (hau da, pilak esleitutako aldagaia) jatorriz zegoen zatian berriro idazten du.
        // Urrats hau funtsezkoa da segurtasuna bermatzeko!
        //
    };

    // Jarri pibota bi partizioen artean.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partizioak `v` `v[pivot]` bezalako elementuetan eta ondoren `v[pivot]` baino handiagoak diren elementuetan.
///
/// Pibotearen berdina den elementu kopurua itzultzen du.
/// Suposatzen da `v`-k ez dituela pibota baino elementu txikiagoak.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Jarri pibota zatiaren hasieran.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Irakurri pibota eraginkortasunerako pilatutako esleitutako aldagai batean.
    // panics ondorengo konparazio eragiketa eginez gero, pibota automatikoki idatziko da zatian.
    // SEGURTASUNA: Hemen dagoen erakusleak balio du xerra baten erreferentziatik lortzen delako.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Orain zatitu xerra.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEGURTASUNA: beheko segurtasun ezak array bat indexatzea dakar.
        // Lehenengoari dagokionez: dagoeneko hemen egiten ditugu mugak egiaztatzen `l < r`-rekin.
        // Bigarrenerako: hasieran `l == 0` eta `r == v.len()` ditugu eta indexazio eragiketa guztietan `l < r` hori egiaztatu dugu.
        //                     Hemendik aurrera jakin badakigu `r`-k gutxienez `r == l` izan behar duela lehenengotik baliozkoa zela frogatuta.
        unsafe {
            // Bilatu lehen elementua pibota baino handiagoa.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Bilatu pibotearen berdina den azken elementua.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Bukatu al dugu?
            if l >= r {
                break;
            }

            // Trukatu aurkitutako ordenatutako elementuen bikotea.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Pibotearen pareko `l` elementuak aurkitu ditugu.Gehitu 1 pibota bera kontuan izateko.
    l + 1

    // `_pivot_guard` eremutik atera eta pibota (hau da, pilak esleitutako aldagaia) jatorriz zegoen zatian berriro idazten du.
    // Urrats hau funtsezkoa da segurtasuna bermatzeko!
}

/// Elementu batzuk barreiatzen ditu bizkorreko partizio desorekatuak sor ditzaketen ereduak hautsi nahian.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsagliaren "Xorshift RNGs" paperetik ateratako zenbaki sorgailua.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Hartu ausazko zenbakiak modulu zenbaki hau.
        // Zenbakia `usize`-ra egokitzen da, `len` ez baita `isize::MAX` baino handiagoa.
        let modulus = len.next_power_of_two();

        // Pibota hautagai batzuk aurkibide horretatik gertu egongo dira.Goazen ausaz.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Sortu ausazko zenbaki modulo bat `len`.
            // Hala ere, kostu handiko eragiketak ekiditeko bi potentzia modulu hartzen ditugu lehenik, eta gero `len` murriztu `[0, len - 1]` barrutira egokitu arte.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` baino txikiagoa dela ziurtatzen da.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v`-ko pibota aukeratzen du eta aurkibidea eta `true` itzultzen ditu xerra seguruenik ordenatuta badago.
///
/// Baliteke `v`-ko elementuak prozesuan berrantolatzea.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Batez besteko metodoa aukeratzeko gutxieneko luzera.
    // Xerra laburragoek hiru bitarteko metodo sinplea erabiltzen dute.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Funtzio honetan egin daitezkeen gehieneko swap kopurua.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Pibota aukeratuko dugun gertu hiru indize.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Indizeak ordenatzerakoan burutuko ditugun swap kopurua zenbatzen du.
    let mut swaps = 0;

    if len >= 8 {
        // Trukatzen ditu indizeak `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Trukatzen ditu indizeak `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]`-ren mediana aurkitzen du eta aurkibidea `a`-n gordetzen du.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Bilatu mediana `a`, `b` eta `c` auzoetan.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Bilatu mediana `a`, `b` eta `c` artean.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Gehienezko swap kopurua egin da.
        // Xerra beheranzkoa edo gehienbat beherakorra da, beraz alderantzikatzeak ziurrenik azkarrago ordenatzen lagunduko du.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` errekurtsiboki ordenatzen du.
///
/// Xerra jatorrizko arrayean aurrekaria bazuen, `pred` gisa zehazten da.
///
/// `limit` `heapsort`-era aldatu aurretik baimendutako partizio desorekatuen kopurua da.
/// Zero bada, funtzio hori berehala aldatuko da pisu handira.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Luzera horretako zatiak txertatzeko ordenaren bidez ordenatuko dira.
    const MAX_INSERTION: usize = 20;

    // Egia da azken partizionamendua arrazoiz orekatua izan balitz.
    let mut was_balanced = true;
    // Egia da azken partizioak elementuak nahastu ez baditu (xerra partizionatuta zegoen dagoeneko).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Xerra oso laburrak txertatzeko ordenaren bidez ordenatzen dira.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pibota aukera txar gehiegi egin badira, besterik gabe, erori zaitez hots batera, `O(n * log(n))` kasurik txarrena bermatzeko.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Azken partizionamendua desorekatu bada, saiatu zatian ereduak hausten inguruan elementu batzuk nahastuz.
        // Zorionez, oraingoan pibota hobea aukeratuko dugu.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Aukeratu pibota eta saiatu xerra dagoeneko ordenatuta dagoen ala ez asmatzen.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Azken partizionamendua dezente orekatuta egon bada eta elementuak nahastu ez baditu, eta pibota aukeratzeak iragartzen badu xerra litekeena da ordenatuta ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Saiatu ordenaz kanpoko hainbat elementu identifikatzen eta posizio zuzenak aldatzen.
            // Xerra erabat ordenatuta amaitzen bada, amaitu dugu.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Aukeratutako pibota aurrekoaren berdina bada, orduan zatiko elementurik txikiena da.
        // Zatitu xerra pibota berdineko eta handiagoak diren elementuetan.
        // Kasu hau zatiak elementu bikoiztu asko dituenean jo ohi da.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jarraitu pibota baino elementu handiagoak ordenatzen.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Xerra zatitu.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Zatitu xerra `left`, `pivot` eta `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Errepikatu alde laburrera soilik dei errekurtsiboen kopurua gutxitzeko eta pilatzeko leku gutxiago kontsumitzeko.
        // Ondoren, jarraitu alde luzeagoarekin (isatsaren errekurtsioaren antzekoa da).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` ordenatzen du ereduak gainditzen dituen azkarra erabiliz, hau da,*O*(*n*\*log(* n*)) kasurik okerrena.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ordenatzeak ez du portaera esanguratsurik zero tamainako motetan.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Mugatu partizio desorekatuen kopurua `floor(log2(len)) + 1`-ra.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Luzera horretako zatien kasuan, seguru asko azkarrago ordenatuko dituzu.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Aukeratu pibota
        let (pivot, _) = choose_pivot(v, is_less);

        // Aukeratutako pibota aurrekoaren berdina bada, orduan zatiko elementurik txikiena da.
        // Zatitu xerra pibota berdineko eta handiagoak diren elementuetan.
        // Kasu hau zatiak elementu bikoiztu asko dituenean jo ohi da.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Gure indizea gainditu badugu, orduan onak gara.
                if mid > index {
                    return;
                }

                // Bestela, jarraitu pibota baino elementu handiagoak ordenatzen.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Zatitu xerra `left`, `pivot` eta `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Mid==indizea bada, amaitu egin dugu, partition()-k bermatu baitu mid ondorengo elementu guztiak mid baino handiagoak edo berdinak direla.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ordenatzeak ez du portaera esanguratsurik zero tamainako motetan.Ez egin ezer.
    } else if index == v.len() - 1 {
        // Bilatu max elementua eta jarri arrayaren azken posizioan.
        // Hemen libre dugu `unwrap()` erabiltzea, badakigu v-k hutsik egon behar ez duela.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Bilatu min elementua eta jarri arrayaren lehen posizioan.
        // Hemen libre dugu `unwrap()` erabiltzea, badakigu v-k hutsik egon behar ez duela.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}