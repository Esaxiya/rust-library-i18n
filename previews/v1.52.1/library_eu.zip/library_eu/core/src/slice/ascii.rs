//! Operazioak ASCII `[u8]`-n.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Xerra honetako byte guztiak ASCII barrutian dauden egiaztatzen du.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Bi zatitan ASCII maiuskulak eta minuskulak bereizten ez dituztela egiaztatzen du.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` bezalakoa, baina aldi baterakoak esleitu eta kopiatu gabe.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Xerra hau bere ASCII maiuskulako baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Maiuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Xerra hau ASCII minuskula baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Minuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` ematen du `v` hitzaren edozein byte ez bada (>=128).
/// `../str/mod.rs`-tik ateratakoa, utf8 baliozkotzerako antzeko zerbait egiten duena.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ASCII proba optimizatua, aldi baterako erabilerarako eragiketak erabiliko dituena, byte bakoitzeko eragiketak egin beharrean (ahal denean).
///
/// Hemen erabiltzen dugun algoritmoa nahiko erraza da.`s` laburregia bada, byte bakoitza egiaztatu eta horrekin amaitu beharko dugu.Bestela:
///
/// - Irakurri lehen hitza lerrokatu gabeko kargarekin.
/// - Lerrokatu erakuslea, irakurri ondorengo hitzak lerrokatutako kargekin amaitu arte.
/// - Irakurri `s`-ren azken `usize`-k lerrokatu gabeko kargarekin.
///
/// Karga horietako batek `contains_nonascii` (above)-k egia itzultzen duen zerbait sortzen badu, orduan badakigu erantzuna faltsua dela.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Hitzez aldi baterako inplementazioarekin ezer irabaziko ez bagenu, erori berriro eskala begizta batera.
    //
    // `size_of::<usize>()` `usize` rako nahikoa lerrokatzea ez den arkitekturetarako ere egiten dugu hori, edge kasu bitxia delako.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Beti irakurtzen dugu lehen hitza lerrokatu gabe, hau da, `align_offset` da
    // 0, berriro irakurriko genuke lerrokatutako irakurketarako balio bera berriro.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEGURTASUNA: `len < USIZE_SIZE` goian egiaztatzen dugu.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Goian egiaztatu dugu, modu inplizitu samarrean.
    // Kontuan izan `offset_to_aligned` `align_offset` edo `USIZE_SIZE` dela, biak goian esplizituki egiaztatuta daudela.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEGURTASUNA: word_ptr irakurtzeko erabiltzen dugun ptr (behar bezala lerrokatuta) erabilera da
    // zatiaren erdiko puska.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr`-ren byte indizea da, begizta amaierako kontroletarako erabiltzen dena.
    let mut byte_pos = offset_to_aligned;

    // Paranoia lerrokadurari buruz egiaztatu, lerrokatu gabeko karga pila bat egitera goazelako.
    // Praktikan, hori ezinezkoa izan beharko litzateke `align_offset`-n akatsen bat kenduta.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Irakurri ondorengo hitzak azken lerrokatutako hitza arte, beranduago lerrokatutako azken hitza berez utziz gero buztana egiaztatzeko, buztana beti `usize` bat dela ziurtatzeko branch `byte_pos == len` gehigarriraino.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Egiaztatu irakurketa mugan dagoela
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Eta `byte_pos`-i buruzko gure usteak betetzen direla.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEGURTASUNA: Badakigu `word_ptr` behar bezala lerrokatuta dagoela
        // `align_offset`), eta badakigu nahikoa byte ditugula `word_ptr` eta bukaeraren artean
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEGURTASUNA: `byte_pos <= len - USIZE_SIZE` hori ezagutzen dugu, horrek esan nahi du
        // `add` honen ondoren, `word_ptr` gehienez ere amaiera-amaiera izango da.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanitate egiaztapena `usize` bakarra geratzen dela ziurtatzeko.
    // Hori gure begizta baldintzak bermatu beharko luke.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEGURTASUNA: hau hasieran egiaztatzen dugun `len >= USIZE_SIZE`-en oinarritzen da.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}