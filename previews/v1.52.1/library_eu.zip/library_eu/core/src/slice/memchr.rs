// Jatorrizko inplementazioa rust-memchr-etik hartua.
// Copyright 2015 Andrew Gallant, bluss eta Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Erabili mozketa.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// X00X ematen du X01X-k zero byte baldin badu.
///
/// From *Matters Computational*, J. Arndt:
///
/// "Ideia da byte bakoitzari bat kentzea eta gero mailegua esanguratsuenera hedatu den byte bilatzea.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `x` byte-rekin bat datorren lehen indizea ematen du `text`-n.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Xerra txikietarako bide azkarra
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Bilatu byteko balio bakarra, `usize` bi hitz irakurrita aldi berean.
    //
    // Zatitu `text` hiru zatitan
    // - hasierako zatirik lerrokatu gabe, testuan lehen hitza lerrokatuta duen helbidearen aurretik
    // - gorputza, eskaneatu 2 hitz aldi bakoitzean
    // - geratzen den azken zatia, <2 hitzen tamaina

    // bilatu lerrokatutako mugara arte
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // bilatu testuaren gorputza
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEGURTASUNA: bitartean predikatuak gutxienez 2 * usize_byteko distantzia bermatzen du
        // zatiaren desplazamendua eta bukaeraren artean.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // hautsi pareko byte bat badago
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Bilatu byta gorputzaren begizta gelditu den puntuaren ondoren.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `x` bytearekin bat datorren azken indizea ematen du `text`-n.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Bilatu byteko balio bakarra, `usize` bi hitz irakurrita aldi berean.
    //
    // Zatitu `text` hiru zatitan:
    // - buztana lerrokatu gabe, testuko azken hitza lerrokatuta dagoenaren ondoren,
    // - gorputza, bi hitz eskaneatuta aldi berean,
    // - geratzen diren lehen byteek, <2 hitz tamaina.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Aurrizki eta atzizkiaren luzera lortzeko besterik ez dugu deitzen.
        // Erdian beti bi zati prozesatzen ditugu aldi berean.
        // SEGURTASUNA: `[u8]`-ra `[usize]`-ra aldatzea segurua da, `align_to`-k kudeatzen dituen tamaina desberdintasunak izan ezik.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Bilatu testuaren gorputza, ziurtatu min_aligned_offset gurutzatzen ez dugula.
    // desplazamendua beti lerrokatuta dago, beraz `>` probatzea nahikoa da eta gainezka egitea ekiditen du.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SEGURTASUNA: desplazamendua len, suffix.len() hasten da, beti baino handiagoa bada
        // min_aligned_offset (prefix.len()) gainerako distantzia gutxienez 2 * chunk_byte da.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Hautsi pareko byte bat badago.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Aurki ezazu byta gorputzaren begizta gelditu den puntuaren aurretik.
    text[..offset].iter().rposition(|elt| *elt == x)
}