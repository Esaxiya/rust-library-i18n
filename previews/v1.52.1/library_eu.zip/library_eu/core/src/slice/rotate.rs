// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` barrutia biratzen du, `mid` elementua lehen elementua bihurtzeko.Era berdinean, `left` barrutiko elementuak ezkerrera edo `right` elementuak eskuinera biratzen ditu.
///
/// # Safety
///
/// Zehaztutako barrutiak irakurtzeko eta idazteko balio du.
///
/// # Algorithm
///
/// 1 algoritmoa `left + right`-ren balio txikietarako edo `T` handietarako erabiltzen da.
/// Elementuak azken posizioetara aldatzen dira banan-banan `mid - left`-tik hasi eta `right` pausoak aurrera eginez `left + right` modulua, hala nola aldi baterako bakarra behar da.
/// Azkenean, `mid - left` era helduko gara.
/// Hala ere, `gcd(left + right, right)` 1 ez bada, goiko urratsak elementuen gainetik saltatzen dira.
/// Adibidez:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Zorionez, amaitutako elementuen artean saltatutako elementuen kopurua beti berdina da, beraz, hasierako posizioa konpentsatu eta txanda gehiago egin ditzakegu (txanda kopurua `gcd(left + right, right)` value) da.
///
/// Azken emaitza da elementu guztiak behin eta behin amaitzen direla.
///
/// 2 algoritmoa erabiltzen da `left + right` handia bada baina `min(left, right)` nahikoa txikia da pila buffer batean sartzeko.
/// `min(left, right)` elementuak bufferrera kopiatzen dira, `memmove` besteei aplikatzen zaie eta bufferrekoak berriro sortu ziren jatorrizkoaren kontrako zulora.
///
/// Bektorizatu daitezkeen algoritmoek aurreko hau gainditzen dute `left + right` nahikoa handia izatean.
/// 1. algoritmoa bektoreztatu daiteke txanda asko eginez eta aldi berean txanda asko eginez, baina batez beste txanda gutxi daude `left + right` izugarria izan arte, eta txanda bakarraren kasurik txarrena beti hor dago.
/// Horren ordez, 3. algoritmoak `min(left, right)` elementuen behin eta berriz trukatzea erabiltzen du biratzeko arazo txikiagoa utzi arte.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` denean trukaketa ezkerretik gertatzen da.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. beheko algoritmoek huts egin dezakete kasu horiek egiaztatzen ez badira
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // 1 algoritmoaren mikrobenchmarkek adierazten dute ausazko txanden batez besteko errendimendua hobea dela `left + right == 32` inguru arte, baina kasurik txarreneko errendimendua 16 inguruan ere hausten da.
            // 24 aukeratu zuten bide ertain gisa.
            // `T` ren tamaina 4 `usize` baino handiagoa bada, algoritmo honek beste algoritmo batzuk ere gainditzen ditu.
            //
            //
            let x = unsafe { mid.sub(left) };
            // lehen itzuliaren hasiera
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` eskuz aurretik aurki daiteke `gcd(left + right, right)` kalkulatuz, baina azkarragoa da gcda bigarren mailako efektu gisa kalkulatzen duen begizta bat egitea, ondoren gainerako zatiak eginez
            //
            //
            let mut gcd = right;
            // erreferenteek agerian uzten dute azkarragoa dela aldi baterako aldatzea aldi baterako behin behin irakurri beharrean, atzera kopiatzea eta behin-behineko hori azkenean idaztea.
            // Agian hori aldi baterako trukatzeak edo ordezteak memoria helbide bakarra erabiltzen du begiztan bi kudeatu beharrean.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` inkrementatu beharrean eta mugetatik kanpo dagoen egiaztatu beharrean, hurrengo gehikuntzan `i` mugetatik kanpo joango den egiaztatuko dugu.
                // Honek erakusleak edo `usize` biltzea ekiditen du.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // lehen itzuliaren amaiera
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // baldintza honek hemen egon behar du `left + right >= 15` bada
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // amaitu puska biribil gehiagorekin
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ez da zero tamainako mota, beraz, ondo dago bere tamainaz banatzea.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 `[T; 0]` hemen T-rako behar bezala lerrokatuta dagoela ziurtatzeko da
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Badago algoritmo honen azken trukaketa non egongo litzatekeen aurkitzea eta trukea egitea, algoritmo hau egiten ari den bezalako alboko zatiak trukatu ordez, azken zati hori erabiliz trukatzea, baina modu hau azkarragoa da.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 3. algoritmoa, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}