//! Datuak memorian kokatzen dituzten datuak lotzen dituzten motak.
//!
//! Batzuetan erabilgarria da mugitzen ez direla ziurtatuta duten objektuak edukitzea, memorian kokatzea aldatzen ez den zentzuan eta, beraz, fidatu daitezkeela.
//! Eszenatoki horren adibide nagusia egitura autoerreferentzialak eraikitzea izango litzateke, objektu bat erakusleak beregana mugitzeak baliogabetuko baitu, eta horrek definitu gabeko portaera sor dezake.
//!
//! Maila altuan, [`Pin<P>`]-k `P` edozein erakusle motako puntuak memorian kokapen egonkorra duela ziurtatzen du, hau da, ezin da beste leku batera mugitu eta bere memoria ezin da banatu banandu arte.Puntua "pinned" dela esaten dugu.Gauzak sotilago bihurtzen dira ainguratutako datuekin lotzen diren motak eztabaidatzerakoan;[see below](#projections-and-structural-pinning) xehetasun gehiagorako.
//!
//! Berez, Rust-ko mota guztiak mugigarriak dira.
//! Rust-k mota guztietako balioaren bidez pasatzea ahalbidetzen du, eta erakusle adimendun mota arruntek, hala nola [`Box<T>`] eta `&mut T`, dauzkaten balioak ordezkatu eta mugitzea ahalbidetzen dute: [`Box<T>`] batetik atera zaitezke edo [`mem::swap`] erabil dezakezu.
//! [`Pin<P>`] `P` motako erakuslea biltzen du, beraz [`Pin`]`<`[`Box`] `<T>>`erregularra bezalako funtzioak ditu
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`jaregiten da, baita bere edukia ere, eta memoria geratzen da
//!
//! deslokatu.Era berean, ["Pin"] "<&mut T>` `&mut T` bezalakoa da.Hala ere, [`Pin<P>`]-k ez die bezeroei [`Box<T>`] edo `&mut T` bat ainguratutako datuei lortzen uzten, horrek esan nahi du ezin dituzula [`mem::swap`] bezalako eragiketak erabili:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` behar du, baina ezin dugu lortu.
//!     // Trabatuta gaude, ezin dugu erreferentzia horien edukia trukatu.
//!     // `Pin::get_unchecked_mut` erabil genezake, baina hori ez da segurua arrazoi batengatik:
//!     // ez dugu baimenik erabiltzen `Pin`-etik gauzak ateratzeko.
//! }
//! ```
//!
//! Errepikatu beharra dago [`Pin<P>`]-k *ez duela* aldatzen Rust konpilatzaile batek mota guztiak mugikorrak direla kontuan hartuta.[`mem::swap`] deigarria izaten jarraitzen du edozein `T`.Horren ordez, [`Pin<P>`]-k eragotzi egiten du *balio* batzuk ([`Pin<P>`]-n bildutako erakusleek seinalatutakoak) mugitzea, haietan `&mut T` behar duten metodoei ([`mem::swap`] bezala) deitzea ezinezkoa baita.
//!
//! [`Pin<P>`] edozein erakusle mota `P` biltzeko erabil daiteke, eta, horrela, [`Deref`] eta [`DerefMut`] ekin elkarreragiten du.[`Pin<P>`] bat, non `P: Deref` "`P`-style pointer" gisa hartu behar den ainguratutako `P::Target` batentzat, beraz, [`Pin ']` <`[` Box`]<T>>`T` ainguratutako jabea da eta [`Pin`] `<` [`Rc`]`<T>>`ainguratutako `T` erreferentziazko erakuslea da.
//! Zuzentasuna lortzeko, [`Pin<P>`] [`Deref`] eta [`DerefMut`] inplementazioetan oinarritzen da, beraien `self` parametrotik ez ateratzeko, eta inoiz erakusle bat ainguratutako datuetara itzultzeko ainguratutako erakusle bati deitzen zaionean.
//!
//! # `Unpin`
//!
//! Mota asko libreki mugitzen dira beti, ainguratuta daudenean ere, ez baitute konfiantza helbide egonkorra edukitzean.Honek oinarrizko mota guztiak ([`bool`], [`i32`] eta erreferentziak, esaterako) eta mota horietakoak soilik diren motak barne hartzen ditu.Ainguratzea axola ez zaien motek [`Unpin`] auto-trait ezartzen dute eta horrek [`Pin<P>`] ren eragina bertan behera uzten du.
//! `T: Unpin` rentzat, [`Pin`]`<`[`Box`] `<T>>`eta [`Box<T>`] berdin funtzionatzen dute, [`Pin`] `<&mut T>` eta `&mut T`-ek bezala.
//!
//! Kontuan izan ainguratzeak eta [`Unpin`]-k `P::Target` motako puntuan soilik eragiten dutela, ez [`Pin<P>`]-n bildutako `P` motako erakuslearengan.Adibidez, [`Box<T>`] [`Unpin`] izan edo ez, ez du eraginik [`Pin`]`<`[`Box`] `-ren portaeran.<T>>`(hemen, `T` da apuntatutako mota).
//!
//! # Adibidez: egitura autoerreferentziala
//!
//! `Pin<T>`-ekin lotutako bermeak eta aukerak azaltzeko xehetasun gehiagotan sartu aurretik, nola erabil litekeen adibide batzuk aztertuko ditugu.
//! Anima zaitez [skip to where the theoretical discussion continues](#drop-guarantee)-ra.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Hau egitura autoerreferentziala da, xerra eremuak datu eremura seinalatzen baitu.
//! // Ezin diogu konpilatzaileari horren berri eman erreferentzia normal batekin, eredu hau ezin baita ohiko mailegu arauekin deskribatu.
//! //
//! // Horren ordez, erakusle gordin bat erabiltzen dugu, nahiz eta ezagutzen ez den nulua izan, badakigu katea seinalatzen ari dela.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Funtzioa itzultzerakoan datuak mugitzen ez direla ziurtatzeko, objektuaren bizitza osoan egongo den lekuan kokatuko dugu, eta bertara sartzeko modu bakarra hari erakusle bat izango litzateke.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // erakuslea datuak bere lekuan daudenean bakarrik sortzen dugu; bestela, hasi aurretik ere mugitu egingo da
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // badakigu hori segurua dela, eremu bat aldatzeak ez baitu egitura osoa mugitzen
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Erakusleak kokapen zuzena seinalatu beharko luke, egitura mugitu ez den bitartean.
//! //
//! // Bitartean, libre gara erakuslea mugitzeko.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Gure motak Unpin inplementatzen ez duenez, honek huts egingo du konpilatzean:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Adibidez: bi aldiz loturiko zerrenda intrusiboa
//!
//! Bi aldiz loturiko zerrenda intrusibo batean, bildumak ez du memoria elementuei berari esleitzen.
//! Esleipena bezeroek kontrolatzen dute, eta elementuak bilduma baino motzago bizi den pila marko batean bizi daitezke.
//!
//! Lan hau egiteko, elementu guztiek zerrendako aurrekoaren eta ondorengoaren erakusleak dituzte.Elementuak ainguratuta daudenean soilik gehitu daitezke, elementuak inguruan mugitzeak erakusleak baliogabetuko lituzkeelako.Gainera, loturiko zerrendako elementu baten [`Drop`] inplementazioak aurrekoaren eta ondorengoaren erakusleak lotuko ditu bere burua zerrendatik kentzeko.
//!
//! Funtsezkoa, [`drop`] deitzen zaionean oinarritzea lortu behar dugu.Elementu bat [`drop`] deitu gabe banatu edo bestela baliogabetu ahal izango balitz, ondoko elementuetatik datozen erakusleak baliogabeak bihurtuko lirateke, eta horrek datu egitura hautsiko luke.
//!
//! Hori dela eta, ainguratzea [`drop`] lotutako berme batekin dator.
//!
//! # `Drop` guarantee
//!
//! Ainguratzearen helburua memorian datu batzuk jartzean oinarritzea da.
//! Hau funtzionatzeko, datuak mugitzeaz gain, mugatuta dago;datuak gordetzeko erabilitako memoria deslokalizatzea, berriro erabiltzea edo bestela baliogabetzea ere mugatuta dago.
//! Konkretuki, ainguratutako datuetarako aldaezina mantendu behar duzu *bere memoria ez dela baliogabetuko edo berriro erabiliko, ainguratzen denetik [`drop`]* deitzen zaion arte.[`drop`] itzultzen denean edo panics behin bakarrik, memoria berriro erabil daiteke.
//!
//! Memoria "invalidated" izan daiteke deslokalizazio bidez, baina baita [`Some(v)`] bat [`None`] ordezkatuz edo [`Vec::set_len`]-ra "kill"-ra deituz vector bateko zenbait elementu.Erabil daiteke [`ptr::write`] erabiliz gainidazteko, suntsitzaileari deitu gabe.Hau guztia ez da onartzen ainguratutako datuetarako [`drop`] deitu gabe.
//!
//! Hau da, hain zuzen ere, aurreko ataleko estekatutako zerrenda intrusiboak behar bezala funtzionatu behar duen bermea.
//!
//! Kontuan izan berme honek ez duela esan nahi memoria isurtzen ez denik.Oraindik guztiz ondo dago [`drop`] deitzea ainguratutako elementu bati (adibidez, [`mem::forget`] deitu dezakezu [`Pin ']` <`[` Box`])<T>>`).Bi aldiz lotuta dagoen zerrendaren adibidean, elementu hori zerrendan geratuko litzateke.Hala ere, ezin duzu biltegiratzea askatu edo berrerabili *[`drop`]* telefonora deitu gabe.
//!
//! # `Drop` implementation
//!
//! Zure motak pinning-a erabiltzen badu (goiko bi adibideak, esaterako), kontuz ibili behar duzu [`Drop`] ezartzerakoan.[`drop`] funtzioak `&mut self` hartzen du, baina horri *deitzen zaio, nahiz eta zure mota lehenago itsatsita egon*.Konpiladoreak [`Pin::get_unchecked_mut`] automatikoki deituko balu bezala da.
//!
//! Honek ezin du sekula arazorik sortu kode seguruetan, ainguratzean oinarritzen den mota bat ezartzeak kode segurua eskatzen baitu, baina kontuan izan zure motan ainguratzea erabiltzea erabakitzen duzula (adibidez, [`Pin`]`<&Self-en eragiketa batzuk ezarriz>`edo [`Pin`] `<&mut Self>`) ondorioak ditu [`Drop`] inplementazioan ere: zure motako elementu bat ainguratu izan balitz, [`Drop`] tratatu behar duzu inplizituki [`Pin ']` <&mut gisa hartuta Auto> `.
//!
//!
//! Adibidez, `Drop` honela ezar dezakezu:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ondo dago, badakigulako balio hori ez dela inoiz berriro erabiltzen jaitsi ondoren.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Benetako jario kodea hona doa.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` funtzioak [`drop`]* * izan beharko lukeen mota du; beraz, horrek ziurtatzen du ez duzula ustekabean `self`/`this` erabiltzen ainguratzearekin gatazkan dagoen moduan.
//!
//! Gainera, zure mota `#[repr(packed)]` bada, konpiladoreak automatikoki mugituko ditu eremuak, askatu ahal izateko.Baliteke hori nahiko lerrokatuta dauden eremuetarako ere.Ondorioz, ezin duzu `#[repr(packed)]` motarekin pinning-a erabili.
//!
//! # Proiekzioak eta Egitura Pinning
//!
//! Ainguratutako egiturekin lan egitean, galdera sortzen da nola sar daitekeen egitura horretako eremuetara [`Pin ']` <&mut Struct> `besterik hartzen duen metodoan.
//! Ohiko ikuspegia [`Pin`]`<&mut Struct>`eremuko erreferentzia bihurtzen duten laguntza-metodoak idaztea da (*proiekzioak* deiturikoak), baina zer motatakoa izan behar du erreferentzia horrek?[`Pin ']` <&mut Field> `edo `&mut Field` da?
//! Galdera bera sortzen da `enum` baten eremuekin, eta baita container/wrapper motak kontuan hartuta ere, hala nola [`Vec<T>`], [`Box<T>`] edo [`RefCell<T>`].
//! (Galdera hau erreferentzia aldakorrei eta partekatuei dagokie, erreferentzia aldakorren kasu ohikoena hemen erabiltzen dugu ilustraziorako).
//!
//! Bihurtzen da datuen egituraren egileak erabakitzen duela eremu jakin bateko orratzezko proiekzioa [`Pin`]`<&mut Struct>`[`Pin`] `<&mut Field>` bihurtzen den ala ez erabakitzea `&mut Field`.Badira zenbait muga, eta murriztapen garrantzitsuena *koherentzia* da:
//! eremu guztiak *bai* ainguratutako erreferentzia batera proiektatu daitezke,*bai* proiekzioa zati gisa kenduta egon daiteke.
//! Biak eremu bererako egiten badira, ziurrenik ez da ona izango!
//!
//! Datu-egitura baten egile gisa, "propagates" eremu horri ainguratzen zaion edo ez erabaki behar duzu.
//! Hedatzen den pinningari "structural" ere deitzen zaio, motaren egiturari jarraitzen diolako.
//! Ondorengo azpiataletan, bi aukeretarako egin beharreko gogoetak deskribatuko ditugu.
//!
//! ## Pinning *ez da* egiturazkoa `field` rentzat
//!
//! Kontrako intuitiboa dirudi ainguratutako egitura baten eremua ainguratuta ez egotea, baina hori da aukerarik errazena: [`Pin ']` <&mut Field> `inoiz sortzen ez bada, ezer ezin da gaizki joan!Beraz, eremu batzuek egiturazko aingurarik ez dutela erabakitzen baduzu, ziurtatu behar duzuna da inoiz ez duzula eremu horri erreferentziarik itsatsirik sortzen.
//!
//! Egiturazko aingurarik gabeko eremuek proiekzio metodo bat izan dezakete, [`Pin ']` <&mut Struct> `&mut Field` bihurtzen duena:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Hori ondo dago, `field` ez baita inoiz ainguratuta jotzen.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Baliteke `impl Unpin for Struct`*ere*`field` mota [`Unpin`] ez bada ere.Mota horrek ainguratzeari buruz pentsatzen duena ez da garrantzitsua [[Pin]] `<&mut Field>` inoiz sortzen ez denean.
//!
//! ## *Pinning* egiturazkoa da `field` rentzat
//!
//! Beste aukera ainguratzea "structural" dela `field` rentzat erabakitzea da, hau da, egitura ainguratuta badago, hori ere eremua da.
//!
//! Horrek [`Pin`]`<&mut Field>`sortzen duen proiekzioa idazteko aukera ematen du, eta, beraz, eremua ainguratuta dagoela ikusiko dugu:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ondo dago `field` `self` dagoenean ainguratuta dagoelako.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Hala ere, egiturazko pinningak baldintza gehigarri batzuk ditu:
//!
//! 1. Egiturak [`Unpin`] izan behar du egiturazko eremu guztiak [`Unpin`] badira.Hau lehenetsia da, baina [`Unpin`] trait segurua da, beraz, egituraren egilea zure ardura da *ez*`impl<T> Unpin for Struct<T>` bezalako zerbait gehitzea.
//! (Kontuan izan proiekzio eragiketa bat gehitzeak kode ez-segurua behar duela; beraz, [`Unpin`] trait segurua izateak ez du hautsi "ez segurua" erabiltzen baduzu hauetaz kezkatu behar duzun printzipioa.)
//! 2. Egituraren suntsitzaileak ez ditu egiturazko eremuak bere argumentutik atera behar.Hau da [previous section][drop-impl]-en planteatu zen puntu zehatza: `drop`-k `&mut self` hartzen du, baina egitura (eta, beraz, bere eremuak) aurretik ainguratuta egon zitekeen.
//!     [`Drop`] inplementazioaren barruan eremu bat mugitzen ez duzula bermatu behar duzu.
//!     Bereziki, lehen azaldu bezala, horrek esan nahi du zure egiturak *ez*`#[repr(packed)]` izan behar duela.
//!     Ikusi atal hori [`drop`] idazteko nola konpiladoreak ainguraketa ustekabean hautsi ez dezan.
//! 3. [`Drop` guarantee][drop-guarantee] mantentzen duzula ziurtatu behar duzu:
//!     zure egitura ainguratuta dagoenean, edukia duen memoria ez da gainidatzi edo banatu edukiaren suntsitzaileei deitu gabe.
//!     Hori zaila izan daiteke, [`VecDeque<T>`]-k frogatu duenez: [`VecDeque<T>`]-aren suntsitzaileak elementu guztiei [`drop`] deitzea huts egin dezake panics suntsitzaileetako bat baldin bada.Horrek [`Drop`] bermea urratzen du, suntsitzaileak deitu gabe elementuak birkokatzea ekar baitezake.([`VecDeque<T>`]-k ez du pinning proiekziorik, beraz, horrek ez du soinurik sortzen.)
//! 4. Ez duzu eskaini zure mota ainguratuta datuak egiturazko eremuetatik ateratzea ekar dezakeen beste eragiketarik.Adibidez, egiturak [`Option<T>`] bat badu eta `fn(Pin<&mut Struct<T>>) -> Option<T>` motarekin "hartu" moduko eragiketa bat badago, eragiketa hori `T` bat ainguratutako `Struct<T>` batetik ateratzeko erabil daiteke-horrek esan nahi du ainguratzea ezin dela egiturazkoa izan hau duen eremuan datuak.
//!
//!     Datuak ainguratutako motatik ateratzearen adibide konplexuago bat lortzeko, pentsa ezazu [`RefCell<T>`]-k `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` metodorik bazuen.
//!     Ondoren, honako hau egin genezake:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Hau hondamendia da. Horrek esan nahi du lehenik [`RefCell<T>`] ren edukia aingura dezakegula (`RefCell::get_pin_mut` erabiliz) eta gero eduki hori mugitu dezakegula gero lortu dugun erreferentzia aldagarria erabiliz.
//!
//! ## Examples
//!
//! [`Vec<T>`] bezalako mota baterako, bi aukerak (egiturazko pinning edo ez) zentzuzkoak dira.
//! Egiturazko ainguraketa duen [`Vec<T>`] batek `get_pin`/`get_pin_mut` metodoak izan ditzake elementuen erreferentziak ainguratuta lortzeko.Hala ere, ezin zuen *baimendu*[`pop`][Vec::pop] ainguratutako [`Vec<T>`] bati deitzea, horrek (egituraz ainguratutako) edukia mugituko lukeelako!Ezingo luke [`push`][Vec::push] baimendu, edukia birkokatu eta horrela edukia ere mugi dezake.
//!
//! Egiturazko aingurarik gabeko [`Vec<T>`] batek `impl<T> Unpin for Vec<T>` izan dezake, edukia inoiz ez baita ainguratzen eta [`Vec<T>`] bera ere ondo mugitzen baita.
//! Une horretan pinningak ez du inolako eraginik vector-n.
//!
//! Liburutegi estandarrean, erakusle motek, oro har, ez dute egiturazko pinningik eta, beraz, ez dute pinning proiekziorik eskaintzen.Horregatik, `Box<T>: Unpin`-k `T` guztientzat balio du.
//! Zentzuzkoa da erakusle mota hau egitea, `Box<T>` mugitzeak ez baitu `T` mugitzen: [`Box<T>`] askatasun osoz mugitu daiteke (`Unpin` ere deitu) nahiz eta `T` ez den.Izan ere, baita [`Pin`]`<`[`Box`] `<T>>`eta [`Pin`] `<&mut T>` beti [`Unpin`] dira beraiek, arrazoi beragatik: haien edukia (`T`) ainguratuta dago, baina erakusleak beraiek mugi daitezke ainguratutako datuak mugitu gabe.
//! [`Box<T>`] zein [`Pin`]`<`[`Box`] `-entzako<T>>`, edukia ainguratuta dagoen ala ez erabat independentea da erakuslea ainguratuta dagoen ala ez, hau da, ainguratzea *ez* egiturazkoa da.
//!
//! [`Future`] konbinatzailea ezartzerakoan, normalean futures habiarentzako egiturazko ainguraketa beharko duzu, [`poll`] deitzeko haiei buruzko erreferentzia itsatsiak lortu behar baitituzu.
//! Zure konbinadoreak ainguratu behar ez den beste daturen bat baldin badituzu, eremu horiek egiturazkoak ez izan daitezen eta, beraz, askatasunez sar zaitezke erreferentzia aldakor batekin, baita [`Pin`]`<&mut Self>`duzunean ere (esaterako zure [`poll`] inplementazioan bezala).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Ainguratutako erakuslea.
///
/// Hau erakusle moduko baten inguruan biltzen da eta horrek "pin" erakusleari bere balioa bere lekuan jartzen dio, erakusle horrek aipatzen duen balioa mugitzea eragozten du [`Unpin`] inplementatzen ez badu behintzat.
///
///
/// *Ikusi [`pin` module] dokumentazioa ainguratzearen inguruko azalpenetarako.*
///
/// [`pin` module]: self
///
// Note: beheko `Clone` deribatuak ezintasuna eragiten du inplementatzea posible den heinean
// `Clone` erreferentzia aldaezinak lortzeko.
// Ikus <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> xehetasun gehiagorako.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ondorengo inplementazioak ez dira eratorriak sendotasun arazoak ekiditeko.
// `&self.pointer` Ez da fidagarria izan trait inplementazioetarako eskuragarria.
//
// Ikus <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> xehetasun gehiagorako.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Eraiki `Pin<P>` berria erakuslearen inguruan [`Unpin`] inplementatzen duen mota bateko datu batzuetara.
    ///
    /// `Pin::new_unchecked` ez bezala, metodo hau segurua da, `P` erakusleak [`Unpin`] motari erreferentzia egiten diolako, eta horrek ainguratzeko bermeak bertan behera uzten ditu.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEGURTASUNA: seinalatutako balioa `Unpin` da eta, beraz, ez du eskakizunik
        // pinning inguruan.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// `Pin<P>` hau azaltzen du azpiko erakuslea itzuliz.
    ///
    /// Horrek eskatzen du `Pin` honen datuak [`Unpin`] izatea, horrela desblokeatzen ditugun aldaera alboratuak alde batera utzi ahal izateko.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Eraiki `Pin<P>` berria `Unpin` inplementa dezaketen edo ez mota bateko datu batzuen erreferentziaren inguruan.
    ///
    /// `pointer` `Unpin` motari erreferentzia egiten bazaio, `Pin::new` erabili beharko litzateke horren ordez.
    ///
    /// # Safety
    ///
    /// Eraikitzaile hau ez da segurua, ezin baitugu bermatu `pointer`-k adierazitako datuak ainguratuta daudela, hau da, datuak ez direla mugituko edo biltegiratzea baliogabetu egingo da erortzen diren arte.
    /// Eraikitako `Pin<P>`-k `P`-ri seinalatutako datuak ainguratzen direla bermatzen ez badu, API kontratua urratzen du eta zehaztu gabeko portaera sor dezake (safe) eragiketetan.
    ///
    /// Metodo hau erabiliz,`P::Deref` eta `P::DerefMut` inplementazioei buruzko promise egiten ari zara, existitzen badira.
    /// Garrantzitsuena, ez dira `self` argumentuetatik atera behar: `Pin::as_mut` eta `Pin::as_ref` ek `DerefMut::deref_mut` eta `Deref::deref`*deituko dituzte ainguratutako erakuslearen* gainean eta espero dute metodo horiek ainguratutako aldaerak mantentzea.
    /// Gainera, metodo honi deituz gero `P` erreferentzia desoreferentziak berriro ez direla aterako;bereziki, ezin da `&mut P::Target` bat lortu eta gero erreferentzia horretatik atera ([`mem::swap`] adibidez erabiliz).
    ///
    ///
    /// Adibidez, `Pin::new_unchecked` batera deitzea `&'a mut T` batera ez da segurua, izan ere, `'a` emandako bizitza osorako ainguratzeko gai zaren bitartean, ez duzu kontrolik `'a` amaitutakoan ainguratuta mantentzen den ala ez kontrolatzeko:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Horrek esan nahi du `a` puntua inoiz ezin dela mugitu.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` ren helbidea `b` pila-zirrikitutik aldatu da, beraz, `a` mugitu egin da aurrez ainguratu dugun arren!Pinning API kontratua urratu dugu.
    /////
    /// }
    /// ```
    ///
    /// Balioak, behin ainguratuta, betirako ainguratuta egon behar du (bere motak `Unpin` inplementatzen ez badu behintzat).
    ///
    /// Era berean, `Pin::new_unchecked` `Rc<T>` batera deitzea ez da segurua, ezarpenak egon baitaitezke aingura murrizketen mende ez dauden datu berdinetarako:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Horrek esan nahi du puntua inoiz ezin dela mugitu.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Orain, `x` erreferentzia bakarra izango balitz, goian ainguratutako datuen erreferentzia aldakorra dugu, aurreko adibidean ikusi dugun moduan mugitzeko erabil genezakeena.
    ///     // Pinning API kontratua urratu dugu.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ainguratutako erakusle honetatik ainguratutako erreferentzia partekatua lortzen du.
    ///
    /// Hau metodo generikoa da `&Pin<Pointer<T>>`-tik `Pin<&T>`-ra joateko.
    /// Segurua da, `Pin::new_unchecked` kontratuaren zati gisa, puntua ezin baita mugitu `Pin<Pointer<T>>` sortu ondoren.
    ///
    /// "Malicious" `Pointer::Deref`-ren inplementazioak `Pin::new_unchecked`-ren kontratuak ere baztertzen ditu.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEGURTASUNA: ikusi funtzio honi buruzko dokumentazioa
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// `Pin<P>` hau azaltzen du azpiko erakuslea itzuliz.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua.Funtzio horri deitu ondoren `P` erakuslea ainguratuta tratatzen jarraituko duzula bermatu behar duzu, `Pin` motako aldaerak berretsi ahal izateko.
    /// Emaitza lortzen duen `P` erabiltzen duen kodeak API kontratuaren urraketa den aldaera aldakorrak mantentzen jarraitzen badu eta zehaztu gabeko portaera sor dezake gero (safe) eragiketetan.
    ///
    ///
    /// Azpiko datuak [`Unpin`] badira, [`Pin::into_inner`] erabili behar da horren ordez.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ainguratutako erakusle honetatik ateratako erreferentzia aldagarri bat lortzen du.
    ///
    /// Hau metodo generikoa da `&mut Pin<Pointer<T>>`-tik `Pin<&mut T>`-ra joateko.
    /// Segurua da, `Pin::new_unchecked` kontratuaren zati gisa, puntua ezin baita mugitu `Pin<Pointer<T>>` sortu ondoren.
    ///
    /// "Malicious" `Pointer::DerefMut`-ren inplementazioak `Pin::new_unchecked`-ren kontratuak ere baztertzen ditu.
    ///
    /// Metodo hau erabilgarria da ainguratutako mota kontsumitzen duten funtzioetara dei ugari egitean.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // Zerbait egin
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` kontsumitzen du, beraz, berriro hartu `Pin<&mut Self>` `as_mut` bidez.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEGURTASUNA: ikusi funtzio honi buruzko dokumentazioa
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Ainguratutako erreferentziaren atzean dagoen memoriari balio berria esleitzen dio.
    ///
    /// Horrek ainguratutako datuak gainidazten ditu, baina ondo dago: suntsitzailea gainidatzi baino lehen exekutatzen da, beraz, ez da inolako bermerik urratzen.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Pin berria eraikitzen du barruko balioa mapatuta.
    ///
    /// Adibidez, zerbaiten eremu baten `Pin` bat lortu nahi baduzu, erabil dezakezu eremu hori kode lerro batean sartzeko.
    /// Hala ere, "pinning projections" horiekin hainbat gotcha daude;
    /// ikusi [`pin` module] dokumentazioa gai horri buruzko xehetasun gehiagorako.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua.
    /// Itzuli dituzun datuak ez direla mugituko bermatu behar duzu argumentuaren balioa mugitzen ez den bitartean (adibidez, balio horretako eremuetako bat delako), eta, gainera, ez duzula ateratzen zuk jasotako argumentutik barruko funtzioa.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEGURTASUNA: `new_unchecked` ren segurtasun kontratuak izan behar du
        // deitzaileak onartzen du.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Pin batetik partekatutako erreferentzia lortzen du.
    ///
    /// Hau segurua da, ezin baita erreferentzia partekatu batetik atera.
    /// Badirudi hemen barneko aldagarritasunarekin arazoren bat dagoela: egia esan, * posible da `T` `&RefCell<T>` batetik ateratzea.
    /// Hala ere, hori ez da arazoa, `Pin<&T>` datu berdinak seinalatzen ez dituen bitartean eta `RefCell<T>`-k ez du uzten bere edukiaren erreferentzia orratzik sortzen.
    ///
    /// ["pinning projections"]-en eztabaida ikusi xehetasun gehiagorako.
    ///
    /// Note: `Pin`-k `Deref` ere ezartzen du helburuan, barneko balioa atzitzeko erabil daitekeena.
    /// Hala eta guztiz ere, `Deref`-k `Pin`-ren mailegua hartu arte bizi den erreferentzia besterik ez du ematen, ez `Pin`-ren bizitza osoan.
    /// Metodo honi esker, `Pin` jatorrizko `Pin` ren bizitza berdina duen erreferentzia bihurtzea da.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// `Pin<&mut T>` hau bizitza bereko `Pin<&T>` bihurtzen du.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// `Pin` honen datuen erreferentzia aldakorra lortzen du.
    ///
    /// Honek `Pin` honen datuak `Unpin` izatea eskatzen du.
    ///
    /// Note: `Pin`-k `DerefMut` ere ezartzen du datuetan, barneko balioa atzitzeko erabil daitekeena.
    /// Hala eta guztiz ere, `DerefMut`-k `Pin`-ren mailegua hartu arte bizi den erreferentzia besterik ez du ematen, ez `Pin`-ren bizitza osoan.
    ///
    /// Metodo honi esker, `Pin` jatorrizko `Pin` ren bizitza berdina duen erreferentzia bihurtzea da.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// `Pin` honen datuen erreferentzia aldakorra lortzen du.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua.
    /// Funtzio honi deitzen diozunean jasotzen dituzun erreferentzia aldakorreko datuak inoiz ez dituzula mugituko bermatu behar duzu, `Pin` motako aldaezinak berretsi ahal izateko.
    ///
    ///
    /// Azpiko datuak `Unpin` badira, `Pin::get_mut` erabili behar da horren ordez.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Eraiki pin berria barruko balioa mapatuta.
    ///
    /// Adibidez, zerbaiten eremu baten `Pin` bat lortu nahi baduzu, erabil dezakezu eremu hori kode lerro batean sartzeko.
    /// Hala ere, "pinning projections" horiekin hainbat gotcha daude;
    /// ikusi [`pin` module] dokumentazioa gai horri buruzko xehetasun gehiagorako.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua.
    /// Itzuli dituzun datuak ez direla mugituko bermatu behar duzu argumentuaren balioa mugitzen ez den bitartean (adibidez, balio horretako eremuetako bat delako), eta, gainera, ez duzula ateratzen zuk jasotako argumentutik barruko funtzioa.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEGURTASUNA: deitzailea arduratzen da ez mugitzeaz
        // balioa erreferentzia honetatik kanpo.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEGURTASUNA: `this`-ren balioa ez duela ziurtatzen da
        // lekuz aldatu da, `new_unchecked` ra dei hau segurua da.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Lortu erreferentzia estatiko batetik ainguratutako erreferentzia.
    ///
    /// Hau segurua da, `T` maileguan hartzen baita `'static` bizitza osoan, inoiz amaitzen ez dena.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEGURTASUNA: 'mailegu estatikoak datuak ez direla bermatuko du
        // moved/invalidated erortzen den arte (inoiz ez dena).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Lortu ainguratutako erreferentzia aldagarri bat erreferentzia estatiko aldagarri batetik.
    ///
    /// Hau segurua da, `T` maileguan hartzen baita `'static` bizitza osoan, inoiz amaitzen ez dena.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEGURTASUNA: 'mailegu estatikoak datuak ez direla bermatuko du
        // moved/invalidated erortzen den arte (inoiz ez dena).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: horrek esan nahi du behartzea ahalbidetzen duen `CoerceUnsized` edozein impl
// `Deref<Target=impl !Unpin>` inplikatzen duen mota batek `Deref<Target=Unpin>` inplikatzen duen mota bat ez da onuragarria.
// Halako inplementazio bat ez litzateke segurua beste arrazoi batzuengatik, beraz, beraz, kontuz ibili behar dugu inplikazio horiek std-ra lehorreratzen ez uztea.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}