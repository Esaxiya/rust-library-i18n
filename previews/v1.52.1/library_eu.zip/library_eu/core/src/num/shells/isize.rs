//! Erakuslearen tamaina duen zenbaki oso motako konstanteak.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Kode berriak lotutako konstanteak zuzenean erabili behar ditu primitibo motan.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }