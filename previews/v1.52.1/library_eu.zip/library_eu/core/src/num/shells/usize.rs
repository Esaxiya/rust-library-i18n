//! Erakuslearen tamaina sinatu gabeko zenbaki oso motaren konstanteak.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Kode berriak lotutako konstanteak zuzenean erabili behar ditu primitibo motan.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }