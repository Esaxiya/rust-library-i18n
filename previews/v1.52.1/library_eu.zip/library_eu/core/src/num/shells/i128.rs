//! 128 biteko sinatutako zenbaki oso motaren konstanteak.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Kode berriak lotutako konstanteak zuzenean erabili behar ditu primitibo motan.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }