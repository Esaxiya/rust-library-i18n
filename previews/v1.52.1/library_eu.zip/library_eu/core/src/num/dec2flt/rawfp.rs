//! IEEE 754 karroza positiboetan bit-jolasa.Zenbaki negatiboak ez dira eta ez dira manipulatu behar.
//! Puntu mugikorreko zenbaki arruntek errepresentazio kanonikoa dute (frac, exp), hala nola balioa 2 <sup>exp</sup> * da (1 + sum(frac[N-i] / 2<sup>i</sup>)) non N bit kopurua den.
//!
//! Subnormalak zertxobait desberdinak eta bitxiak dira, baina printzipio bera aplikatzen da.
//!
//! Hemen, ordea, (sig, k) gisa adierazten dugu f positiboarekin, hala nola balioa f * dela
//! 2 <sup>e</sup> ."hidden bit" esplizitua egiteaz gain, honek berretzailea aldatzen du mantisa shift deritzonaren bidez.
//!
//! Beste modu batera esanda, normalean karrozak (1) gisa idazten dira baina hemen (2) gisa idazten dira:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1)**irudikapen zatikatua** eta (2)**irudikapen integrala** deitzen diogu.
//!
//! Modulu honetako funtzio askok zenbaki normalak bakarrik kudeatzen dituzte.Dec2flt errutinek modu kontserbadorean unibertsalki zuzena den bide geldoa hartzen dute (M algoritmoa) zenbaki oso txikietan eta oso handietan.
//! Algoritmo horrek next_float() bakarrik behar du, azpinormalak eta zeroak kudeatzen dituena.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait laguntzailea, funtsean `f32` eta `f64`-en bihurketa kode guztiak bikoiztea saihesteko.
///
/// Ikusi guraso moduluko dokumentuaren iruzkina zergatik den beharrezkoa.
///
/// **Inoiz** ez al da beste mota batzuetarako inplementatu behar edo dec2flt modulutik kanpo erabili.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` eta `from_bits`-ek erabilitako mota.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Zenbaki oso baten transmutazio gordina egiten du.
    fn to_bits(self) -> Self::Bits;

    /// Zenbaki oso batetik transmutazio gordin bat egiten du.
    fn from_bits(v: Self::Bits) -> Self;

    /// Zenbaki horretan sartzen den kategoria itzultzen du.
    fn classify(self) -> FpCategory;

    /// Mantisa, berretzailea eta zeinua zenbaki osoak ematen ditu.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Karroza deskodetzen du.
    fn unpack(self) -> Unpacked;

    /// Zehazki irudika daitekeen zenbaki oso txiki batetik ateratzen dira.
    /// Panic zenbaki osoa ezin bada irudikatu, modulu honetako beste kodeak ziurtatzen du hori inoiz ez gertatzea.
    fn from_int(x: u64) -> Self;

    /// 10 <sup>e</sup> balioa lortzen du aurrez kalkulatutako taulatik.
    /// Panics `e >= CEIL_LOG5_OF_MAX_SIG` rentzat.
    fn short_fast_pow10(e: usize) -> Self;

    /// Izenak dioena.
    /// Errazagoa da kode gogorra intrintsektuekin malabareak egitea eta LLVM konstantea tolestea espero izatea baino.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Sarreren zifra hamartarren gaineko lotura kontserbadorea gainezkatzea edo zero edo
    /// azpinormalak.Ziurrenik gehienezko balio normalaren erakusle hamartarra, hortik datorkio izena.
    const MAX_NORMAL_DIGITS: usize;

    /// Zenbaki hamartarrik esanguratsuenak leku hau baino balio handiagoa duenean, zalantzarik gabe infinitua biribilduko da kopurua.
    ///
    const INF_CUTOFF: i64;

    /// Zenbaki hamartarrik esanguratsuenak hau baino leku balio txikiagoa duenean, kopurua zeroera biribilduko da.
    ///
    const ZERO_CUTOFF: i64;

    /// Erakuslearen bit kopurua.
    const EXP_BITS: u8;

    /// Adierazitako bit kopurua,*ezkutuko bit* barne.
    const SIG_BITS: u8;

    /// Esanahiaren bit kopurua,*ezkutatutako bit-a* kenduta.
    const EXPLICIT_SIG_BITS: u8;

    /// Zatikako irudikapenean gehienezko legezko adierazlea.
    const MAX_EXP: i16;

    /// Zatikako irudikapenean gutxieneko legezko erakuslea, azpinormalak kenduta.
    const MIN_EXP: i16;

    /// `MAX_EXP` irudikapen integralerako, hau da, txanda aplikatuta.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodetua (hau da, desplazamendu-alborapenarekin)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` irudikapen integralerako, hau da, txanda aplikatuta.
    const MIN_EXP_INT: i16;

    /// Irudikapen integralean gehienezko esanahi normalizatua.
    const MAX_SIG: u64;

    /// Irudikapen integralean gutxieneko esanahi normalizatua.
    const MIN_SIG: u64;
}

// Gehienbat #34344-en irtenbide bat da.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantisa, berretzailea eta zeinua zenbaki osoak ematen ditu.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Osagaien alborapena + mantisa desplazamendua
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ez dago ziur `as` plataforma guztietan ondo biribiltzen den ala ez.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantisa, berretzailea eta zeinua zenbaki osoak ematen ditu.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Osagaien alborapena + mantisa desplazamendua
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ez dago ziur `as` plataforma guztietan ondo biribiltzen den ala ez.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` bat makina mugikorrik hurbilenera bihurtzen du.
/// Ez ditu emaitza subnormalak kudeatzen.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 biteko bit da, beraz, xe-k 63 mantisa-aldaketa du
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Biratu 64 biteko esanahia eta T::SIG_BITS bitetara erdibidean.
/// Ez du esponentearen gainezkatzea kudeatzen.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Egokitu mantisa-aldaketa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Zenbaki normalizatuetarako `RawFloat::unpack()`-ren alderantzizkoa.
/// Panics esanahia edo berretzailea zenbaki normalizatuetarako balio ez badute.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Kendu ezkutuko bit-a
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Doitu berretzailea berretzaileen alborapenaren eta mantisaren desplazamendurako
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Utzi zeinu bitea 0 ("+")-ra, gure zenbakiak positiboak dira
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Eraiki azpinormal bat.0ko mantisa onartzen da eta zero eraikitzen du.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodetutako erakuslea 0 da, zeinu bitea 0 da, beraz bitak berriro interpretatu besterik ez dugu.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Gutxi gorabehera Fp duen bignum bat.0.5 ULP barruan biribiltzen da berdinketa erdiarekin.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` indizea baino lehen bit guztiak mozten ditugu, hau da, eskuinera `start` kopuruarekin aldatzen dugu eskuinera, beraz, hau ere behar dugun erakuslea da.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Biribilduko (half-to-even) bit moztuen arabera.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Argumentua baino puntu mugikorreko zenbakirik handiena aurkitzen du.
/// Ez ditu azpi-normalak, zeroak edo berretzaileen azpialdeak maneiatzen.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Aurkitu argumentuarena baino puntu mugikorreko zenbakirik txikiena.
// Eragiketa hau asea da, hau da, next_float(inf) ==inf.
// Modulu honetako kode gehienek ez bezala, funtzio honek zero, azpinormalak eta infinituak kudeatzen ditu.
// Hala ere, hemengo beste kode guztiak bezala, ez du NaN eta zenbaki negatiboak lantzen.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Egia izateko oso ona dirudi, baina funtzionatzen du.
        // 0.0 zero zero hitz gisa kodetuta dago.Subnormalak 0x000m ... m dira eta m mantisa den.
        // Bereziki, subnormal txikiena 0x0 ... 01 da eta handiena 0x000F ... F da.
        // Zenbaki normal txikiena 0x0010 ... 0 da, beraz, izkinako kasu honek ere funtzionatzen du.
        // Gehikuntzak mantisa gainezka egiten badu, eramateko bitak berretzailea handitzen du nahi dugun moduan, eta mantissa bitak zero bihurtzen dira.
        // Ezkutuko bit konbentzioa dela eta, hori ere nahi dugu!
        // Azkenean, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}