//! Metodo bihurtzeko zentzu handirik ez duten bignumetarako erabilgarritasun funtzioak.

// FIXME Modulu honen izena pixka bat penagarria da, beste modulu batzuek ere `core::num` inportatzen baitute.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Probatu `ones_place` baino bit gutxiago esanguratsuak mozteak 0.5 ULP baino errore erlatibo txikiagoa, berdina edo handiagoa duen adierazten duen.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Gainerako bit guztiak zero badira,= 0.5 ULP da, bestela> 0.5 Bit gehiago ez badago (half_bit==0), behean ere Berdin itzuliko da.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Zenbaki hamartarrak bakarrik dituen ASCII katea `u64` bihurtzen du.
///
/// Ez du gainezkatzerik edo karaktere baliogaberik egiaztatzen, beraz, deitzaileak kontuz ibiltzen ez bada, emaitza okerra da eta panic izan daiteke (`unsafe` ez da izango).
/// Gainera, kate hutsak zero gisa tratatzen dira.
/// Funtzio hau badago
///
/// 1. `FromStr` `&[u8]`-en erabiltzeak `from_utf8_unchecked` eskatzen du, txarra da eta
/// 2. `integral.parse()` eta `fractional.parse()`-en emaitzak bateratzea funtzio hau baino zailagoa da.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII digituko kate bat bignum bihurtzen du.
///
/// `from_str_unchecked` bezala, funtzio hau analizatzailean oinarritzen da zifrak ez direnak ezabatzeko.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Bignum bat 64 bit osoko zenbaki osora biltzen du.Panics kopurua handiegia bada.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Bit sorta ateratzen du.

/// 0 indizea bit esanguratsuena da eta barrutia erdi irekita dago ohi bezala.
/// Panics itzuliko motan sartzen diren baino bit gehiago ateratzeko eskatzen bazaio.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}