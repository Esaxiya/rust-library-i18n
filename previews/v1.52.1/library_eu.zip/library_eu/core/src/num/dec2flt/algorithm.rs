//! Papereko hainbat algoritmo.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp-ko esanahi eta bit kopurua
const P: u32 = 64;

// Erakusle *guztientzat* hurbilketarik onena gordetzen dugu, beraz, "h" aldagaia eta lotutako baldintzak alde batera utzi daitezke.
// Honek pare bat kilobyte espazio errendimendua negoziatzen du.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Arkitektura gehienetan, puntu mugikorreko eragiketek bit tamaina esplizitua dute, beraz, kalkuluaren zehaztasuna eragiketa bakoitzeko zehazten da.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86-n, x87 FPU mugikorreko eragiketetarako erabiltzen da SSE/SSE2 luzapenak eskuragarri ez badaude.
// x87 FPU-k 80 bit-eko zehaztasunarekin funtzionatzen du lehenespenez, eta horrek esan nahi du eragiketak 80 bit-etara biribilduko direla biribiltze bikoitza gertatuz balioak azkenean honela irudikatzen direnean
//
// 32/64 bit mugikorreko balioak.Hori gainditzeko, FPU kontrol hitza ezar daiteke kalkuluak nahi den zehaztasunean egiteko.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU kontrol hitzaren jatorrizko balioa gordetzeko erabiltzen den egitura, egitura erortzen denean berrezarri ahal izateko.
    ///
    ///
    /// x87 FPU 16 biteko erregistroa da, eta honako eremuak hauek dira:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Eremu guztietako dokumentazioa IA-32 Architectures Software Developer's Manual (1. liburukian) eskuragarri dago.
    ///
    /// Honako kode honetarako garrantzitsua den eremu bakarra PC da, Zehaztasun kontrola.
    /// Eremu honek FPU-k egindako eragiketen zehaztasuna zehazten du.
    /// Honako hau ezar daiteke:
    ///  - 0b00, zehaztasun bakarra, hau da, 32 bit
    ///  - 0b10, zehaztasun bikoitza, hau da, 64 bit
    ///  - 0b11, zehaztasun hedatu bikoitza, hau da, 80 bit (egoera lehenetsia) 0b01 balioa gordeta dago eta ez da erabili behar.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEGURTASUNA: `fldcw` instrukzioa ikuskatu da, ondo funtzionatu ahal izateko
        // edozein `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ATT sintaxia erabiltzen ari gara LLVM 8 eta LLVM 9 onartzeko.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPUren zehaztasun eremua `T` gisa ezartzen du eta `FPUControlWord` itzultzen du.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Kalkulatu `T` rentzat egokia den Zehaztasun Kontrol eremuko balioa.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // lehenespenez, 80 bit
        };

        // Lortu kontrol hitzaren jatorrizko balioa geroago leheneratzeko, `FPUControlWord` egitura jaitsi denean SEGURTASUNA: `fnstcw` instrukzioa ikuskatu da edozein `u16`-rekin ondo funtzionatu ahal izateko.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ATT sintaxia erabiltzen ari gara LLVM 8 eta LLVM 9 onartzeko.
                options(att_syntax, nostack),
            )
        }

        // Ezarri kontrol hitza nahi duzun zehaztasunera.
        // Hori lortzen da zehaztasun zaharra maskaratuz (8 eta 9 bitak, 0x300) eta goian kalkulatutako zehaztasun bandarekin ordezkatuz.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophonen bide azkarra makinaren tamainako zenbaki osoak eta karrozak erabiliz.
///
/// Hau funtzio bereizi batean ateratzen da, bignum bat eraiki aurretik saia dadin.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Balio zehatza MAX_SIG-rekin konparatzen dugu amaieran gertu, hau errefusazio azkar eta merkea besterik ez da (eta gainontzeko kodea askatzen du gainezkapenaz kezkatzeko).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Bide azkarra aritmetika bit kopuru zuzenera biribilduta egotearen araberakoa da tarteko biribildu gabe.
    // x86-n (SSE edo SSE2 gabe) horretarako beharrezkoa da x87 FPU pilaren zehaztasuna aldatzea, zuzenean 64/32 bitera biribiltzeko.
    // `set_precision` funtzioak ezarpena eskatzen duten arkitekturetan zehaztasuna ezartzeaz arduratzen da egoera globala aldatuz (x87 FPUren kontrol hitza bezala).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // E <0 kasua ezin da beste adar era tolestu.
    // Potentzia negatiboek binarioen zati frakzionala errepikatzen dute, biribilduak, eta horrek azken emaitzan akats errealak (eta tarteka nahiko esanguratsuak!) Eragiten ditu.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Bellerophon algoritmoa zenbakizko analisi ez-hutsala bidez justifikatutako kode hutsala da.
///
/// "F" biribiltzen du 64 biteko esanahia duen flotagailu batera eta `10^e`-ren hurbilketa onenarekin biderkatzen du (puntu mugikorreko formatu berean).Askotan nahikoa da emaitza zuzena lortzeko.
/// Hala ere, emaitza ondoko (ordinary) bi karrozen arteko erdibidetik gertu dagoenean, bi hurbilketa biderkatzearen biribiltze errore konposatuak emaitza bit batzuekin itzal dezake.
/// Hori gertatzen denean, R algoritmo errepikakorrak konpontzen ditu.
///
/// "close to halfway" esku-uhindua paperean egindako zenbakizko analisiaren bidez zehazten da.
/// Clinger-en hitzetan:
///
/// > Slop, bit esanguratsueneko unitateetan adierazita, akatsaren muga inklusiboa da
/// > f * 10 ^ e-ra hurbiltzeko puntu mugikorreko kalkuluan pilatutakoa.(Slop da
/// > ez da benetako errorearen muga, baina z eta hurbilketaren arteko aldea mugatzen du
/// > p garrantzi bitak erabiltzen dituen hurbilketarik onena.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) kasuak fast_path()-n daude
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Aldapa nahikoa al da n bitetara biribiltzean aldatzeko?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algoritmo errepikakorra, `f * 10^e`-ko puntu mugikorreko hurbilketa hobetzen duena.
///
/// Errepikapen bakoitzak unitate bat lortzen du azken tokian, eta horrek noski izugarrizko denbora behar du `z0` apur bat desaktibatuta badago.
/// Zorionez, Bellerophon-en ordezko gisa erabiltzen denean, hasierako hurbilketa gehienez ULP batek desaktibatzen du.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Bilatu zenbaki oso positiboak `x`, `y`, esaterako `x / y` `(f *10^e) / (m* 2^k)` dela.
        // Honek `e` eta `k` seinaleei aurre egitea saihesteaz gain, `10^e` eta `2^k`-en ohiko biren indarra ere ezabatzen dugu zenbakiak txikiagoak izan daitezen.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Hau modu txarrean idazten da, gure bignumek ez baitute zenbaki negatiboak onartzen, beraz, balio absolutua + zeinuaren informazioa erabiltzen dugu.
        // M_digits-ekin biderkatzeak ezin du gainezka egin.
        // `x` edo `y` nahikoa handiak badira gainezkatzeaz kezkatu behar dugula, orduan ere nahikoa handiak dira `make_ratio`-k zatikia 2 ^ 64 edo gehiagoko faktorea murrizteko.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ez duzu x gehiago behar, gorde clone() bat.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Oraindik y behar duzu, egin kopia bat.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` eta `y = m` emanda, `f` sarrerako zifra hamartarrak ohi bezala adierazten dutenez eta `m` puntu mugikorreko hurbilketaren esanahia denez, `x / y` erlazioa `(f *10^e) / (m* 2^k)` ren berdina izan dadila, biek duten potentzia biek komunean izan dezaketena.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, zatikia biren potentzia batekin murrizten dugula izan ezik.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Honek ezin du gainezka egin, `e` positiboa eta `k` negatiboa behar dituelako, hau da, 1etik oso gertu dauden balioetarako bakarrik gerta daiteke, hau da, `e` eta `k` nahiko txikiak izango dira.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Hau ere ezin da gainezka egin, ikusi goian.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), berriro ere bi potentzia komunekin murriztuz.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Kontzeptualki, M algoritmoa da hamartarra float bihurtzeko modurik errazena.
///
/// `f * 10^e`-ren berdina den erlazioa osatzen dugu eta, ondoren, bi potentziak botatzen ditugu baliozko karroza esangura eman arte.
/// `k` berretzaile bitarra zenbatzailea edo izendatzailea bi bider biderkatu dugun kopurua da, hau da, uneoro `f *10^e` berdin `(u / v)* 2^k` da.
/// Esanahia jakin dugunean, zatiketaren gainerakoa ikuskatuz biribildu besterik ez dugu egin behar, laguntzaile funtzioetan behean egiten dena.
///
///
/// Algoritmo hau oso motela da, `quick_start()`-n deskribatutako optimizazioarekin ere.
/// Hala ere, gainezkatze, azpisarrera eta emaitza subnormaletarako egokitzeko algoritmoen artean errazena da.
/// Ezarpen honek Bellerophon eta R algoritmoa larritzen direnean hartzen du bere gain.
/// Azpikoa eta gainezkatzea hautematea erraza da: erlazioa oraindik ez da barrutiko esanahia, baina minimum/maximum erakuslea iritsi da.
/// Gainezkatzearen kasuan infinitua itzultzen dugu.
///
/// Azpiegitura eta azpinormalak maneiatzea zailagoa da.
/// Arazo handi bat da, gutxieneko berretzailearekin, oraindik ere proportzioa handiegia izan litekeela esanahia lortzeko.
/// underflow() xehetasunetarako ikusi.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME optimizazio posiblea: orokortu big_to_fp, fp_to_float(big_to_fp(u))-ren baliokidea hemen egin ahal izateko, biribiltze bikoitzik gabe soilik.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Gutxieneko berretzailean gelditu behar dugu, `k < T::MIN_EXP_INT` arte itxaron ezkero, bi faktore desaktibatuta egongo ginateke.
            // Zoritxarrez, horrek esan nahi du gutxieneko erakuslea duten zenbaki normalak kasu bereziak jarri behar ditugula.
            // FIXME-k formulazio dotoreagoa aurkitzen du, baina exekutatu `tiny-pow10` proba benetan zuzena dela ziurtatzeko!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Algoritmoaren M iterazio gehienak saltatzen ditu bitaren luzera egiaztatuta.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitaren luzera oinarrizko bi logaritmoaren estimazioa da, eta log(u / v) = log(u), log(v).
    // Estimazioa gehienez 1 desaktibatuta dago, baina beti gutxi balioesten da; beraz, log(u) eta log(v)-en erroreak zeinu berekoak dira eta baliogabetzen dira (biak handiak badira).
    // Beraz, log(u / v)-ren errorea bat ere bada.
    // u/v barrutiko esanahia duen xede-erlazioa da.Beraz, gure amaiera baldintza log2(u / v) da bit esanguratsua eta plus/minus bat izatea.
    // FIXME Bigarren bitari erreparatuz gero, estimazioa hobe daiteke eta zatiketa gehiago saihestu.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Azpiegitura edo subnormala.Utzi funtzio nagusiari.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Gainezkatzea.Utzi funtzio nagusiari.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratioa ez da barrutiko esanahia eta gutxieneko berretzailearekin; beraz, gehiegizko bitak biribildu eta horren arabera egokitu behar dugu.
    // Benetako balioa orain itxura hau du:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rem bidez ordezkatuta)
    //
    // Hori dela eta, biribildutako bitak!= 0.5 ULP direnean, beren kabuz erabakitzen dute biribiltzea.
    // Berdinak direnean eta gainerakoa zero ez denean, balioa biribildu behar da.
    // Bit biribilduak 1/2 direnean eta gainerakoa zero denean, egoera berdindua dugu.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Biribildu arrunta, zatiketa baten gainerakoan oinarrituta biribildu behar izateak nahastuta.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}