//! `f64` zehaztasun bikoitzeko puntu mugikor motako espezifikoak.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Matematikoki esanguratsuak diren zenbakiak `consts` azpimoduluan ematen dira.
//!
//! Modulu honetan zuzenean definitutako konstanteei dagokienez (`consts` azpimoduluan definitutakoetatik bereizita), kode berriak `f64` motan zuzenean definitutako lotutako konstanteak erabili beharko lituzke.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64`-ren barne irudikapenaren erradix edo oinarria.
/// Erabili [`f64::RADIX`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // aurreikusitako bidea
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// 2. oinarrian zifra esanguratsuen kopurua.
/// Erabili [`f64::MANTISSA_DIGITS`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // aurreikusitako bidea
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// 10. oinarrian gutxi gorabehera zifra esanguratsuen kopurua.
/// Erabili [`f64::DIGITS`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // aurreikusitako bidea
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] balioa `f64` rentzat.
/// Erabili [`f64::EPSILON`] horren ordez.
///
/// Hau da `1.0` eta hurrengo zenbaki adierazgarri handienaren arteko aldea.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // aurreikusitako bidea
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// `f64` balio finitu txikiena.
/// Erabili [`f64::MIN`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // aurreikusitako bidea
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// `f64` balio normal positibo txikiena.
/// Erabili [`f64::MIN_POSITIVE`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // aurreikusitako bidea
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// `f64` balio finitu handiena.
/// Erabili [`f64::MAX`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // aurreikusitako bidea
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// 2 berretzailearen ahalik eta gutxieneko potentzia normala baino handiagoa.
/// Erabili [`f64::MIN_EXP`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // aurreikusitako bidea
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// 2 berretzaileren gehienezko potentzia.
/// Erabili [`f64::MAX_EXP`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // aurreikusitako bidea
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// 10 berretzaileren gutxieneko potentzia normala.
/// Erabili [`f64::MIN_10_EXP`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // aurreikusitako bidea
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// 10 berretzaileren gehienezko potentzia.
/// Erabili [`f64::MAX_10_EXP`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // aurreikusitako bidea
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Ez da (NaN) zenbakia.
/// Erabili [`f64::NAN`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // aurreikusitako bidea
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Erabili [`f64::INFINITY`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // aurreikusitako bidea
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Infinity negatiboa (−∞).
/// Erabili [`f64::NEG_INFINITY`] horren ordez.
///
/// # Examples
///
/// ```rust
/// // modu zaharkitua
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // aurreikusitako bidea
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Oinarrizko konstante matematikoak.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ordezkatu cmath-eko konstante matematikoekin.

    /// Arkimedesen (π) konstantea
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Zirkulu osoko (τ) konstantea
    ///
    /// 2π-ren berdina.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Eulerren (e) zenbakia
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64`-ren barne irudikapenaren erradix edo oinarria.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// 2. oinarrian zifra esanguratsuen kopurua.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// 10. oinarrian gutxi gorabehera zifra esanguratsuen kopurua.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] balioa `f64` rentzat.
    ///
    /// Hau da `1.0` eta hurrengo zenbaki adierazgarri handienaren arteko aldea.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// `f64` balio finitu txikiena.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// `f64` balio normal positibo txikiena.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// `f64` balio finitu handiena.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// 2 berretzailearen ahalik eta gutxieneko potentzia normala baino handiagoa.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// 2 berretzaileren gehienezko potentzia.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// 10 berretzaileren gutxieneko potentzia normala.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// 10 berretzaileren gehienezko potentzia.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Ez da (NaN) zenbakia.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Infinity negatiboa (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// `true` ematen du balio hau `NaN` bada.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` libcore-n publikoki ez dago erabilgarri eramangarritasunaren inguruko kezkak direla eta, beraz, inplementazio hau barneko erabilera pribaturako da.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// `true` ematen du balio hori infinitu positiboa edo infinitu negatiboa bada, eta `false` bestela.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` ematen du zenbaki hori ez bada infinitua eta ez `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ez dago NaN bereiz maneiatzeko beharrik: norbera NaN bada, alderaketa ez da egia, nahi bezala.
        //
        self.abs_private() < Self::INFINITY
    }

    /// `true` ematen du zenbakia [subnormal] bada.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` eta `min` arteko balioak subnormalak dira.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// `true` ematen du zenbakia ez bada zero, infinitua, [subnormal] edo `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` eta `min` arteko balioak subnormalak dira.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Zenbakiaren puntu mugikorreko kategoria itzultzen du.
    /// Propietate bakarra probatuko bada, orokorrean azkarragoa da predikatu espezifikoa erabiltzea horren ordez.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `true` ematen du `self`-ek zeinu positiboa badu, `+0.0` barne, `NaN`-k zeinu bit positiboa eta infinitu positiboa.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// `true` ematen du `self`-k zeinu negatiboa badu, `-0.0` barne, `NaN` zeinu negatibo bitarekin eta infinitu negatiboarekin.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Zenbaki baten (inverse) elkarrekikoa hartzen du, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Radianak gradu bihurtzen ditu.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Hemen dagoen zatiketa behar bezala biribilduta dago 180/π-ren benetako balioari dagokionez.
        // (Hau f32-rekin desberdina da, konstante bat erabili behar baita emaitza behar bezala biribildua izan dadin.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Graduak radian bihurtzen ditu.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Bi zenbaki gehienez itzultzen du.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Argudioetako bat NaN bada, beste argumentua itzuliko da.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Bi zenbakien gutxienekoa ematen du.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Argudioetako bat NaN bada, beste argumentua itzuliko da.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Biratu zero aldera eta edozein zenbaki oso primitibo bihurtzen da, balioa finitua dela eta mota horretara egokitzen dela suposatuz.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Balioak honakoa izan behar du:
    ///
    /// * Ez izan `NaN`
    /// * Ez izan infinitua
    /// * Izan itzultzeko moduko `Int` motan, bere zati zatiduna moztu ondoren
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SEGURTASUNA: deitzaileak `FloatToInt::to_int_unchecked`-rako segurtasun kontratua onartu behar du.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmutazio gordina `u64`-ra.
    ///
    /// Une honetan `transmute::<f64, u64>(self)` ren berdina da plataforma guztietan.
    ///
    /// Ikusi `from_bits` eragiketa honen eramangarritasunari buruzko eztabaida (ia ez dago arazorik).
    ///
    /// Kontuan izan funtzio hau `as` casting-ekiko bereizten dela, hau da,*zenbakizko* balioa gordetzen saiatzen da, eta ez bitreko balioa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ez da galdaketa!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SEGURTASUNA: `u64` datu mota arrunta da, beraz, beti transmuta dezakegu
        unsafe { mem::transmute(self) }
    }

    /// Transmutazio gordina `u64`-tik.
    ///
    /// Une honetan `transmute::<u64, f64>(v)` ren berdina da plataforma guztietan.
    /// Bi arrazoi direla eta, oso eramangarria dela ematen du.
    ///
    /// * Mugikorrek eta Ints-ek endianness bera dute onartutako plataforma guztietan.
    /// * IEEE-754-k karrozen bit-diseinua zehazten du.
    ///
    /// Hala ere, ohartarazpen bat dago: 2008ko IEEE-754 bertsioaren aurretik, NaN seinaleztapen bitak nola interpretatu ez zen benetan zehaztu.
    /// Plataforma gehienek (batez ere x86 eta ARM) azkenean 2008an estandarizatutako interpretazioa aukeratu zuten, baina batzuk ez (batez ere MIPS).
    /// Ondorioz, MIPS-en seinaleztapen NaN guztiak Na00 isilak dira x86-n, eta alderantziz.
    ///
    /// Inplementazio honek seinaleztapen-plataforma gurutzatua mantentzen saiatu beharrean, bit zehatzak gordetzea hobesten du.
    /// Horrek esan nahi du NaNetan kodetutako edozein karga gorde egingo dela, nahiz eta metodo honen emaitza x86 makina batetik MIPS baterara sarera bidali.
    ///
    ///
    /// Metodo honen emaitzak horiek sortu zituen arkitektura berak bakarrik manipulatzen baditu, orduan ez dago eramangarritasunik.
    ///
    /// Sarrera NaN ez bada, orduan ez dago eramangarritasunik.
    ///
    /// Seinaleztapen-gaitasuna axola ez bazaizu (oso litekeena), orduan ez dago eramangarritasunik.
    ///
    /// Kontuan izan funtzio hau `as` casting-ekiko bereizten dela, hau da,*zenbakizko* balioa gordetzen saiatzen da, eta ez bitreko balioa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SEGURTASUNA: `u64` datu mota arrunta da, hortik beti transmuta gaitezke
        // Badirudi sNaN-rekin segurtasun arazoak gainditu egin zirela!Aupa!
        unsafe { mem::transmute(v) }
    }

    /// Itzuli puntu mugikorreko zenbaki honen memoriaren irudikapena byte array gisa, big-endian (network) byte ordenan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Itzuli puntu mugikorreko zenbaki honen memoria irudikapena byte array gisa endian txikiko byte ordenan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Itzuli puntu mugikorreko zenbaki honen memoria irudikapena byte array gisa, bertako byte ordenan.
    ///
    /// Helburuko plataformaren jatorrizko endia erabiltzen denez, kode eramangarriak [`to_be_bytes`] edo [`to_le_bytes`] erabili beharko lituzke, behar bezala.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Itzuli puntu mugikorreko zenbaki honen memoria irudikapena byte array gisa, bertako byte ordenan.
    ///
    ///
    /// [`to_ne_bytes`] hau baino hobea izan behar da ahal den guztietan.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SEGURTASUNA: `f64` datu mota arrunta da, beraz, beti transmuta dezakegu
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Sortu puntu mugikorreko balioa bere irudikapenetik byte array gisa endian handian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Sortu puntu mugikorreko balioa bere irudikapenetik byte array gisa endian txikian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Sortu puntu mugikorreko balioa, bertako endian jatorrizko endian byte array gisa duen irudikapenetik.
    ///
    /// Helburuko plataformaren jatorrizko indarra erabiltzen denez, kode eramangarriak [`from_be_bytes`] edo [`from_le_bytes`] erabili nahi ditu, behar bezala.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Norberaren eta beste balio batzuen arteko ordenaketa itzultzen du.
    /// Puntu mugikorreko zenbakien arteko konparazio partzial estandarra ez bezala, konparazio honek beti sortzen du IEEE 754 (2008 berrikuspena) puntu mugikorreko estandarrean zehaztutako totalOrder predikatuaren arabera.
    /// Balioak orden honetan daude ordenatuta:
    /// - NaN lasai negatiboa
    /// - Seinale negatiboa NaN
    /// - Infinitu negatiboa
    /// - Zenbaki negatiboak
    /// - Zenbaki subnormal negatiboak
    /// - Zero negatiboa
    /// - Zero positiboa
    /// - Zenbaki subnormal positiboak
    /// - Zenbaki positiboak
    /// - Mugagabe positiboa
    /// - NaN seinaleztapen positiboa
    /// - NaN lasai positiboa
    ///
    /// Kontuan izan funtzio hau ez datorrela bat beti `f64`-ren [`PartialOrd`] eta [`PartialEq`] inplementazioekin.Bereziki, zero negatiboa eta positiboa berdinak dira, `total_cmp` ek, berriz, ez.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Ezezkoen kasuan, irauli bit guztiak zeinua izan ezik bi osagarri osoen antzeko diseinua lortzeko
        //
        // Zergatik funtzionatzen du honek?IEEE 754 karrozak hiru eremu ditu:
        // Zeinu bitea, berretzailea eta mantisa.Erakusle eta mantisa eremuen multzoak bere bitaren ordena magnitudea definitzen den zenbakizko magnitudearen berdina den propietatea dute.
        // Magnitudea normalean ez da NaN balioetan definitzen, baina IEEE 754 totalOrderrek NaN balioak definitzen ditu bitaren ordenari jarraitzeko.Honek dokumentuaren iruzkinean azaldutako ordena dakar.
        // Hala ere, magnitudearen irudikapena berdina da zenbaki negatibo eta positiboetan-zeinuaren bit bakarra da desberdina.
        // Flotagailuak sinatutako zenbaki osoak erraz alderatzeko, berretzailea eta mantisa bitak irauli behar ditugu zenbaki negatiboen kasuan.
        // Zenbakiak "two's complement" inprimakira modu eraginkorrean bihurtzen ditugu.
        //
        // Iraulketa egiteko, maskara bat eta XOR horren aurka eraikitzen ditugu.
        // Adarrik gabe kalkulatzen dugu "all-ones except for the sign bit" maskara bat sinadura negatiboko balioetatik abiatuta: eskuinera aldatzearen zeinuak zenbaki osoa luzatzen du, beraz "fill" maskara zeinu bitekin bihurtzen dugu eta gero sinatu gabeko bihurtzen dugu zero bit bat gehiago bultzatzeko.
        //
        // Balio positiboen gainean, maskara zero guztiak dira, beraz, ez-eragiketa da.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Balio bat tarte jakin batera mugatu NaN ez bada.
    ///
    /// `max` ematen du `self` `max` baino handiagoa bada eta `min` `self` `min` baino txikiagoa bada.
    /// Bestela, honek `self` itzultzen du.
    ///
    /// Kontuan izan funtzio honek NaN itzultzen duela hasierako balioa NaN ere bada.
    ///
    /// # Panics
    ///
    /// Panics `min > max`, `min` NaN bada edo `max` NaN bada.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}