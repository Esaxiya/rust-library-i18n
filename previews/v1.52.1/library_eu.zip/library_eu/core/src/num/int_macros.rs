macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Mota oso honek adieraz dezakeen balio txikiena.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Mota oso honek adieraz dezakeen balio handiena.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Mota oso honen tamaina bitetan.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Oinarri jakin bateko kate zati bat zenbaki oso bihurtzen du.
        ///
        /// Katea aukerako `+` edo `-` ikurra izango dela espero da eta ondoren digituak.
        /// Zuriune nagusiek eta amaierakoek akats bat adierazten dute.
        /// Zenbakiak karaktere horien azpimultzoa dira, `radix` ren arabera:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Funtzio hau panics `radix` 2 eta 36 bitarteko tartean ez badago.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self`-ren irudikapen bitarrean daudenen kopurua ematen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self`-ren irudikapen bitarreko zero kopurua itzultzen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self`-ren irudikapen bitarreko zero puntuen kopurua ematen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self`-ren irudikapen bitarreko amaierako zeroen kopurua ematen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self`-ren irudikapen bitarreko puntakoen kopurua ematen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self`-ren irudikapen bitarrean amaitutakoen kopurua itzultzen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Bitak ezkerrerantz zehazten ditu `n` kopuru zehatz batez, moztutako bitak emaitza osokoaren amaierara bilduz.
        ///
        ///
        /// Kontuan izan hau ez dela `<<` aldatze operadorearen eragiketa bera!
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Bitak eskuinera zehazten du `n` kopuru zehatz batez, moztutako bitak emaitza osoko zenbaki hasierara bilduz.
        ///
        ///
        /// Kontuan izan hau ez dela `>>` aldatze operadorearen eragiketa bera!
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Zenbaki osoaren byte ordena alderantzikatzen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// utzi m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Zenbaki osoaren bit ordena alderantzikatzen du.
        /// Bit esanguratsuena bit esanguratsuena bihurtzen da, bigarren bit esanguratsuena bit esanguratsuena den bigarren bit bihurtzen da, etab.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// utzi m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Zenbaki oso bat endian handitik helburuko endianotasunera bihurtzen du.
        ///
        /// Endian handian hau ez da op.Endian txikian byteak trukatzen dira.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg bada (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } bestela {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Zenbaki oso bat endian txikitik helburuko endianotasunera bihurtzen du.
        ///
        /// Endian txikian hau ez da op.Endian handian byteak trukatzen dira.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg bada (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } bestela {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` big endian bihurtzen du helburuaren endiannessetik.
        ///
        /// Endian handian hau ez da op.Endian txikian byteak trukatzen dira.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg bada (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } bestela { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ala ez izatea?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` bihurtzen du xede endianetik endian txikira.
        ///
        /// Endian txikian hau ez da op.Endian handian byteak trukatzen dira.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg bada (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } bestela { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Zenbaki osoaren gaineko egiaztapena.
        /// `self + rhs` kalkulatzen du, `None` itzuliz gainezkatzea gertatu bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Markatu gabeko zenbaki osoaren batuketa.`self + rhs` kalkulatzen du, gainezkatzea ezin dela suposatu.
        /// Honek zehaztu gabeko portaera sortzen du
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SEGURTASUNA: deitzaileak `unchecked_add`-rako segurtasun kontratua onartu behar du.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Zenbaki osoen kenketa egiaztatu da.
        /// `self - rhs` kalkulatzen du, `None` itzuliz gainezkatzea gertatu bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Markatu gabeko zenbaki osoaren kenketa.`self - rhs` kalkulatzen du, gainezkatzea ezin dela suposatu.
        /// Honek zehaztu gabeko portaera sortzen du
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SEGURTASUNA: deitzaileak `unchecked_sub`-rako segurtasun kontratua onartu behar du.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Zenbaki osoen biderkadura egiaztatu da.
        /// `self * rhs` kalkulatzen du, `None` itzuliz gainezkatzea gertatu bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Zenbaki osoen biderkadura egiaztatu gabea.`self * rhs` kalkulatzen du, gainezkatzea ezin dela suposatu.
        /// Honek zehaztu gabeko portaera sortzen du
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SEGURTASUNA: deitzaileak `unchecked_mul`-rako segurtasun kontratua onartu behar du.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Zenbaki osoen zatiketa egiaztatu da.
        /// `self / rhs` kalkulatzen du, `None` itzuliz `rhs == 0` edo zatiketak gainezka egiten badu.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEGURTASUNA: div by zero eta INT_MIN arabera goian egiaztatu dira
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Zatiketa euklidearra egiaztatu da.
        /// `self.div_euclid(rhs)` kalkulatzen du, `None` itzuliz `rhs == 0` edo zatiketak gainezka egiten badu.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Zenbaki osoaren hondarra egiaztatu da.
        /// `self % rhs` kalkulatzen du, `None` itzuliz `rhs == 0` edo zatiketak gainezka egiten badu.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEGURTASUNA: div by zero eta INT_MIN arabera goian egiaztatu dira
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Gainerako euklidearra egiaztatu dugu.
        /// `self.rem_euclid(rhs)` kalkulatzen du, `None` itzuliz `rhs == 0` edo zatiketak gainezka egiten badu.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Ezeztapen egiaztatua.
        /// `-self` kalkulatzen du, `None` itzuliz `self == MIN` bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ezkerreko txanda egiaztatu da.
        /// `self << rhs` kalkulatzen du, `None` itzuliz `rhs` `self`-ko bit kopurua baino handiagoa edo berdina bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Txanda eskuinean egiaztatu da.
        /// `self >> rhs` kalkulatzen du, `None` itzuliz `rhs` `self`-ko bit kopurua baino handiagoa edo berdina bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Balio absolutua egiaztatu da.
        /// `self.abs()` kalkulatzen du, `None` itzuliz `self == MIN` bada.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Probabilitate egiaztatua.
        /// `self.pow(exp)` kalkulatzen du, `None` itzuliz gainezkatzea gertatu bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp!=0 denez, azkenean exp 1 izan behar da.
            // Tratatu erakuslearen azken bitarekin bereizita, gero oinarria laukizuzena ez baita beharrezkoa eta alferrikako gainezka sor dezakeelako.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Osoko zenbaki osagarria.
        /// `self + rhs` kalkulatzen du, gainezka egin beharrean zenbakizko mugetan saturatuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Zenbaki osoaren kenketa.
        /// `self - rhs` kalkulatzen du, gainezka egin beharrean zenbakizko mugetan saturatuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Zenbaki oso ezeztapena.
        /// `-self` kalkulatzen du, `MAX` itzuliz `self == MIN` bada gainezka egin beharrean.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Balio absolutua asetzea.
        /// `self.abs()` kalkulatzen du, `MAX` itzuliz `self == MIN` bada gainezka egin beharrean.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Zenbaki oso biderkadura saturatua.
        /// `self * rhs` kalkulatzen du, gainezka egin beharrean zenbakizko mugetan saturatuz.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Zenbaki osoen hobekuntza saturatua.
        /// `self.pow(exp)` kalkulatzen du, gainezka egin beharrean zenbakizko mugetan saturatuz.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) gehigarria biltzea.
        /// `self + rhs` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) kenketa biltzea.
        /// `self - rhs` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) biderketa biltzea.
        /// `self * rhs` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) zatiketa biltzea.`self / rhs` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// Bilketa hori gerta daitekeen kasu bakarra da sinatutako mota batean `MIN / -1` zatitzen denean (non `MIN` da motaren gutxieneko balio negatiboa);hau `-MIN` ren baliokidea da, balio positiboa motan handiegia irudikatzeko.
        /// Halako batean, funtzio honek `MIN` bera itzultzen du.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Zatiketa euklidearra biltzea.
        /// `self.div_euclid(rhs)` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// Biltzea `MIN / -1`-n sinatutako mota batean bakarrik gertatuko da (`MIN` motaren gutxieneko balio negatiboa denean).
        /// Hau `-MIN` ren baliokidea da, balio positiboa motan handiegia irudikatzeko.
        /// Kasu honetan, metodo honek `MIN` bera itzultzen du.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) hondarra biltzea.`self % rhs` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// Ingurumen hori ez da inoiz matematikoki gertatzen;inplementazioko objektuek `x % y` baliogabea bihurtzen dute `MIN / -1` rentzat sinatutako mota batean (non `MIN` gutxieneko balio negatiboa den).
        ///
        /// Halako batean, funtzio honek `0` itzultzen du.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Euklidear hondarra biltzeko.`self.rem_euclid(rhs)` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// Biltzea `MIN % -1`-n sinatutako mota batean bakarrik gertatuko da (`MIN` motaren gutxieneko balio negatiboa denean).
        /// Kasu honetan, metodo honek 0 itzultzen du.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) ezeztapena biltzea.`-self` kalkulatzen du, motaren mugan bilduta.
        ///
        /// Bilketa hori gerta daitekeen kasu bakarra da sinatutako mota batean `MIN` ukatzen denean (`MIN` motaren gutxieneko balio negatiboa denean);hau balio positiboa da motan irudikatzeko handiegia.
        /// Halako batean, funtzio honek `MIN` bera itzultzen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-ren bit-bit gabeko shift-ezkerrera;`self << mask(rhs)` ematen du, non `mask`-k ordena handiko `rhs` bit guztiak kenduko lituzkeen aldaketak motaren bit zabalera gainditzea eragingo lukeen.
        ///
        /// Kontuan izan hau ez dela biratu ezkerrera;biltzeko shift-ezkerraren RHS motako barrutira mugatzen da, LHS-etik aldatutako bitak beste muturrera itzultzea baino.
        ///
        /// Zenbaki oso primitiboek [`rotate_left`](Self::rotate_left) funtzioa inplementatzen dute, eta hori nahi duzun hori izan daiteke.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SEGURTASUNA: motako bit tamaina maskaratzeak ez dugula aldatzen ziurtatzen du
            // mugetatik kanpo
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-ren bit-bit gabeko shift-eskuinera;`self >> mask(rhs)` ematen du, non `mask`-k ordena handiko `rhs` bit guztiak kenduko lituzkeen aldaketak motaren bit zabalera gainditzea eragingo lukeen.
        ///
        /// Kontuan izan hau ez dela biraketa-eskuinaren berdina;biltzeko shift-eskuineko RHS motako barrutira mugatzen da, LHS-etik aldatutako bitak beste muturrera itzuli beharrean.
        ///
        /// Zenbaki oso primitiboek [`rotate_right`](Self::rotate_right) funtzioa inplementatzen dute, eta hori nahi duzun hori izan daiteke.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SEGURTASUNA: motako bit tamaina maskaratzeak ez dugula aldatzen ziurtatzen du
            // mugetatik kanpo
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) balio absolutua biltzea.`self.abs()` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// Bilketa hori gerta daitekeen kasu bakarra motarako gutxieneko balio negatiboaren balio absolutua hartzen denean da;hau balio positiboa da motan irudikatzeko handiegia.
        /// Halako batean, funtzio honek `MIN` bera itzultzen du.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// `self` ren balio absolutua kalkulatzen du inolako bildurik edo izutu gabe.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) potentziala biltzea.
        /// `self.pow(exp)` kalkulatzen du, motaren mugan inguratuz.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 denez, azkenean exp 1 izan behar da.
            // Tratatu erakuslearen azken bitarekin bereizita, gero oinarria laukizuzena ez baita beharrezkoa eta alferrikako gainezka sor dezakeelako.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` kalkulatzen du
        ///
        /// Gehikuntzaren tupla boolear batekin batera itzultzen du gainezkatze aritmetikoa gertatuko den ala ez adierazten duena.
        /// Gainezkapen bat gertatuko balitz itzulitako balioa itzuliko da.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` kalkulatzen ditu
        ///
        /// Kenketaren tupla boolear batekin batera itzultzen du gainezkatze aritmetikoa gertatuko den ala ez adierazten duena.
        /// Gainezkapen bat gertatuko balitz itzulitako balioa itzuliko da.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` eta `rhs` biderkadura kalkulatzen du.
        ///
        /// Biderketaren tupla boolear batekin batera itzultzen du gainezkatze aritmetikoa gertatuko den ala ez adierazten duena.
        /// Gainezkapen bat gertatuko balitz itzulitako balioa itzuliko da.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, egia));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Zatitzailea kalkulatzen du `self` `rhs` ekin zatitzen denean.
        ///
        /// Zatitzailearen tupla boolear batekin batera itzultzen du gainezkatze aritmetikoa gertatuko den ala ez adierazten duena.
        /// Gainezkapen bat gertatuko balitz, norbera itzuliko da.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// `self.div_euclid(rhs)` zatiketa euklidearreko zatidura kalkulatzen du.
        ///
        /// Zatitzailearen tupla boolear batekin batera itzultzen du gainezkatze aritmetikoa gertatuko den ala ez adierazten duena.
        /// Gainezkapena gertatuko balitz, `self` itzuliko da.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Gainerakoa kalkulatzen du `self` `rhs` ekin zatitzen denean.
        ///
        /// Gainerako tupla itzultzen du boolear batekin banatu ondoren gainezkatze aritmetikoa gertatuko den ala ez adieraziz.
        /// Gainezkapena gertatuko balitz, 0 itzuliko da.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Gainezka dagoen euklidear hondarra.`self.rem_euclid(rhs)` kalkulatzen du.
        ///
        /// Gainerako tupla itzultzen du boolear batekin banatu ondoren gainezkatze aritmetikoa gertatuko den ala ez adieraziz.
        /// Gainezkapena gertatuko balitz, 0 itzuliko da.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Bere burua ezeztatzen du, gainezka, gutxieneko balioaren berdina bada.
        ///
        /// Autoaren bertsio ezeztatuaren tupla itzultzen du gainezkapen bat gertatu den ala ez adierazten duen boolear batekin.
        /// `self` gutxieneko balioa bada (adibidez, `i32::MIN` `i32` motako balioetarako), orduan gutxieneko balioa berriro itzuliko da eta `true` itzuliko da gainezkatze bat gertatzen denean.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` bitek utzitako autoak aldatzen ditu.
        ///
        /// Aldatutako auto bertsioaren tupla itzultzen du boolear batekin batera desplazamendu balioa bit kopurua baino handiagoa edo berdina zen ala ez adierazten duena.
        /// Desplazamendu balioa handiegia bada, orduan (N-1) maskaratuko da balioa, non N bit kopurua den, eta balio hori desplazamendua egiteko erabiltzen da.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, egia));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` bit aldatzen du.
        ///
        /// Aldatutako auto bertsioaren tupla itzultzen du boolear batekin batera desplazamendu balioa bit kopurua baino handiagoa edo berdina zen ala ez adierazten duena.
        /// Desplazamendu balioa handiegia bada, orduan (N-1) maskaratuko da balioa, non N bit kopurua den, eta balio hori desplazamendua egiteko erabiltzen da.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, egia));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self`-ren balio absolutua kalkulatzen du.
        ///
        /// Autoaren bertsio absolutuaren tupla itzultzen du gainezkapen bat gertatu den ala ez adierazten duen boolear batekin.
        /// Norbera bada gutxieneko balioa
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// orduan gutxieneko balioa berriro itzuliko da eta egia itzuliko da gainezkatze bat gertatzen denean.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Norbera `exp`-ren potentziara igotzen da, karratuz adierazpenaren bidez.
        ///
        /// Potentzialaren tupla itzultzen du bool batekin batera gainezkapen bat gertatu den ala ez adierazten duena.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, egia));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Overflowing_mul-en emaitzak gordetzeko marratu-tartea.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 denez, azkenean exp 1 izan behar da.
            // Tratatu erakuslearen azken bitarekin bereizita, gero oinarria laukizuzena ez baita beharrezkoa eta alferrikako gainezka sor dezakeelako.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Norbera `exp`-ren potentziara igotzen da, karratuz adierazpenaren bidez.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 denez, azkenean exp 1 izan behar da.
            // Tratatu erakuslearen azken bitarekin bereizita, gero oinarria laukizuzena ez baita beharrezkoa eta alferrikako gainezka sor dezakeelako.
            //
            //
            acc * base
        }

        /// `self`-en `rhs`-en zatiketa euklidearreko zatidura kalkulatzen du.
        ///
        /// Honek `n` zenbaki osoa kalkulatzen du `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs`-rekin.
        ///
        ///
        /// Beste modu batera esanda, emaitza `self / rhs` da `n` zenbaki osora biribildua, `self >= n * rhs`.
        /// `self > 0` bada, zero biribilaren berdina da (lehenetsia Rust-n);
        /// `self < 0` bada, hau +/-infiniturantz biribilaren berdina da.
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada edo zatiketak gainezka egiten badu.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// utzi b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)`-ren hondar ez negatibo txikiena kalkulatzen du.
        ///
        /// Hau zatiketa algoritmo euklidearrak balu bezala egiten da-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` eta `0 <= r < abs(rhs)` emandakoak.
        ///
        ///
        /// # Panics
        ///
        /// Funtzio hau panic izango da `rhs` 0 bada edo zatiketak gainezka egiten badu.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// utzi b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self`-ren balio absolutua kalkulatzen du.
        ///
        /// # Gainezkatze portaera
        ///
        /// - Ren balio absolutua
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ezin da gisa gisa irudikatu
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// eta kalkulatzen saiatzeak gainezka eragingo du.
        /// Horrek esan nahi du arazketa moduan kodeak panic aktibatuko duela kasu honetan eta kode optimizatua itzuliko dela
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic rik gabe.
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Kontuan izan goiko#[inline]-ak kenketaren gainezkatze-semantika txertatzen ari garen crate-ren araberakoa dela esan nahi duela.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self`-ren ikurra adierazten duen zenbaki bat ematen du.
        ///
        ///  - `0` zenbakia zero bada
        ///  - `1` kopurua positiboa bada
        ///  - `-1` kopurua negatiboa bada
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// `true` ematen du `self` positiboa bada eta `false` zenbakia zero edo negatiboa bada.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// `true` ematen du `self` negatiboa bada eta `false` zenbakia zero edo positiboa bada.
        ///
        ///
        /// # Examples
        ///
        /// Oinarrizko erabilera:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Itzuli zenbaki oso honen memoria irudikapena byte-array gisa, big-endian (network) byte-ordenan.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Itzuli zenbaki oso honen memoria irudikapena byte array gisa endian txikiko byte ordenan.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Itzuli zenbaki oso honen memoria irudikapena byte array gisa jatorrizko byte ordenan.
        ///
        /// Helburuko plataformaren jatorrizko endia erabiltzen denez, kode eramangarriak [`to_be_bytes`] edo [`to_le_bytes`] erabili beharko lituzke, behar bezala.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, cfg bada (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } bestela {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEGURTASUNA: konst soinua zenbaki osoak datu mota arrunt arruntak direlako beti ahal dugulako
        // transmute itzazu byteen matrizeetara
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SEGURTASUNA: zenbaki osoak datu mota arruntak dira, beraz, beti transmuta ditzakegu
            // byte-matrizeak
            unsafe { mem::transmute(self) }
        }

        /// Itzuli zenbaki oso honen memoria irudikapena byte array gisa jatorrizko byte ordenan.
        ///
        ///
        /// [`to_ne_bytes`] hau baino hobea izan behar da ahal den guztietan.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, cfg bada (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } bestela {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SEGURTASUNA: zenbaki osoak datu mota arruntak dira, beraz, beti transmuta ditzakegu
            // byte-matrizeak
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Sortu balio oso bat bere irudikapenetik byte array gisa endian handian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// erabili std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sarrera=atsedena;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Sortu balio oso bat bere irudikapenetik byte array gisa endian txikian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// erabili std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sarrera=atsedena;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Sortu zenbaki oso bat bere memoria irudikapenetik byte array gisa jatorrizko endiannessean.
        ///
        /// Helburuko plataformaren jatorrizko indarra erabiltzen denez, kode eramangarriak [`from_be_bytes`] edo [`from_le_bytes`] erabili nahi ditu, behar bezala.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } bestela {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// erabili std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sarrera=atsedena;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEGURTASUNA: konst soinua zenbaki osoak datu mota arrunt arruntak direlako beti ahal dugulako
        // transmutatu haiei
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SEGURTASUNA: zenbaki osoak datu mota arruntak dira, beraz, beti transmuta dezakegu
            unsafe { mem::transmute(bytes) }
        }

        /// Kode berriak erabiltzea nahiago du
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Mota oso honek adieraz dezakeen balio txikiena ematen du.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Kode berriak erabiltzea nahiago du
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Mota oso honek adieraz dezakeen balio handiena ematen du.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}