//! Berretzailea kalkulatzailea.

/// `k_0` aurkitzen du, hala nola `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Hau `k = ceil(log_10 (mant * 2^exp))` gutxi gorabehera erabiltzen da;
/// benetako `k` `k_0` edo `k_0+1` da.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits mant> 0 bada
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) beraz, honek beti gutxiesten du (edo zehatza da), baina ez da asko.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}