//! Puntu mugikorreko balioa zati banatan eta errore barrutietan deskodetzen du.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Sinatutako balio finitu deskodetua, hala nola:
///
/// - Jatorrizko balioa `mant * 2^exp`-ren berdina da.
///
/// - `(mant - minus)*2^exp`-tik `(mant + plus)* 2^exp`-ra bitarteko zenbaki orok jatorrizko balioa lortuko du.
/// Barrutia barne dago `inclusive` `true` denean bakarrik.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantisa eskalatua.
    pub mant: u64,
    /// Errorearen tarte txikiagoa.
    pub minus: u64,
    /// Goiko errore tartea.
    pub plus: u64,
    /// 2. oinarrian partekatutako erakuslea.
    pub exp: i16,
    /// Egia da errore-barrutia barne denean.
    ///
    /// IEEE 754n, hori egia da jatorrizko mantisa parekoa zenean.
    pub inclusive: bool,
}

/// Sinatu gabeko balioa deskodetu da.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinituak, positiboak edo negatiboak.
    Infinite,
    /// Zero, positiboa edo negatiboa.
    Zero,
    /// Zenbaki finituak gehiago deskodetutako eremuekin.
    Finite(Decoded),
}

/// "Dekodifikatu" d daitekeen puntu mugikorreko mota.
pub trait DecodableFloat: RawFloat + Copy {
    /// Balio normalizatu positibo minimoa.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Zeinu bat (negatiboa denean egia) eta `FullDecoded` balioa ematen ditu emandako puntu mugikorreko zenbakitik.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // bizilagunak: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode erakuslea beti gordetzen du, beraz mantisa azpinormaletarako eskalatzen da.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // bizilagunak: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // non maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // bizilagunak: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}