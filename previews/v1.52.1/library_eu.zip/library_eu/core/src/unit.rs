use crate::iter::FromIterator;

/// Iteratzaile batetik unitateko elementu guztiak bakarrean biltzen ditu.
///
/// Hau erabilgarriagoa da goi mailako abstrakzioekin konbinatuta, adibidez, `Result<(), E>` batera biltzea, erroreak soilik axola zaizkizunean:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}