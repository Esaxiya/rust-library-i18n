#![stable(feature = "core_hint", since = "1.27.0")]

//! Kodea nola igorri edo optimizatu behar den eragiten duen konpiladoreari buruzko aholkuak.
//! Aholkuak konpilatzeko denbora edo exekuzio denbora izan daitezke.

use crate::intrinsics;

/// Konpilatzaileari jakinarazten dio kodeko puntu hau ezin dela iritsi, optimizazio gehiago ahalbidetuz.
///
/// # Safety
///
/// Funtzio honetara iristea guztiz definitu gabeko portaera da * (UB).Bereziki, konpiladoreak suposatzen du UB guztiak ez direla inoiz gertatu behar eta, beraz, `unreachable_unchecked()` ra deitzera iristen diren adar guztiak ezabatuko ditu.
///
/// UBren instantzia guztiak bezala, hipotesi hau okerra dela frogatzen bada, hau da, `unreachable_unchecked()` deia kontrol-fluxu posible guztien artean heltzen bada, konpiladoreak optimizazio estrategia okerra aplikatuko du, eta, batzuetan, itxuraz loturarik gabeko kodea ere hondatu dezake, arazketak arazteko.
///
///
/// Erabili funtzio hau kodeak inoiz deituko ez duela frogatzen duzunean.
/// Bestela, pentsa ezazu [`unreachable!`] makroa erabiltzea, optimizazioak onartzen ez dituena baina exekutatzerakoan panic egingo duena.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` beti positiboa da (ez zero), beraz, `checked_div`-k ez du inoiz `None` itzuliko.
/////
///     // Hori dela eta, beste branch ezin da iritsi.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEGURTASUNA: `intrinsics::unreachable` ren segurtasun kontratua behar da
    // deitzaileak berretsi.
    unsafe { intrinsics::unreachable() }
}

/// Makina bat instrukzio igortzen ditu prozesadoreari lan-itxaroten duen biribilgunean ("biratze blokeoa") exekutatzen ari dela adierazteko.
///
/// Spin-loop seinalea jasotzean prozesadoreak bere portaera optimiza dezake, adibidez, energia aurreztuz edo hyper hariez aldatuz.
///
/// Funtzio hau [`thread::yield_now`] sistemaren antolatzaileari zuzenean ematen dionaren desberdina da, `spin_loop`-k ez du sistema eragilearekin elkarreragiten.
///
/// `spin_loop` ren ohiko erabilera kasu bat sinkronizazio primitiboetan CAS begizta batean biratutako mugimendu baikorra ezartzea da.
/// Lehentasuna alderantzikatzea bezalako arazoak ekiditeko, biziki gomendatzen da biraketa-begiztak iterazio kopuru finitu bat amaitu ondoren eta blokeo-dei egokia egin ondoren.
///
///
/// **Oharra**: spin-loop aholkuak jasotzea onartzen ez duten plataformetan funtzio honek ez du batere ezer egiten.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Hariek koordinatzeko erabiliko duten balio atomiko partekatua
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Atzeko planoan, azkenean, balioa ezarriko dugu
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Egin lan batzuk eta egin bizia balioa
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Gure oraingo harira itzulita, balioa ezarri arte itxarongo dugu
/// while !live.load(Ordering::Acquire) {
///     // Biratze-begizta itxaroten ari garen PUZaren iradokizuna da, baina ziurrenik ez oso denbora luzez
/////
///     hint::spin_loop();
/// }
///
/// // Balioa orain ezarrita dago
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEGURTASUNA: `cfg` attr-ek x86 helburuetan soilik exekutatzen dugula ziurtatzen du.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEGURTASUNA: `cfg` attr-ek x86_64 helburuetan soilik exekutatzen dugula ziurtatzen du.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEGURTASUNA: `cfg` attr-ek aarch64 helburuetan soilik exekutatzen dugula ziurtatzen du.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEGURTASUNA: `cfg` attr-ek hau bermatzen du besoen helburuetan soilik exekutatzen dugula
            // v6 funtziorako laguntzarekin.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Konpiladoreari * __ iradokitzen dion identitate funtzioa `black_box`-ek egin dezakeenari buruz gehien ezkorra izateko.
///
/// [`std::convert::identity`] ez bezala, Rust konpilatzaileari `black_box`-k Rust kodea baimenduta duen edozein baliozko modutan erabil dezakeela deitzen duen kodean definitu gabeko portaera sartu gabe.
///
/// Propietate horri esker, `black_box` erabilgarria da zenbait optimizazio nahi ez diren kodea idazteko, esate baterako, erreferentziak.
///
/// Kontuan izan, ordea, `black_box` "best-effort" oinarrian soilik ematen dela (eta soilik eman daiteke).Optimizazioak blokea ditzakeen neurriak aldatu egin daitezke erabilitako plataformaren eta kode-gen backendaren arabera.
/// Programek ezin dute `black_box`-n oinarritu *zuzentasuna* inolaz ere.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Argumentua "use"-era behar dugu nolabait LLVM-k ezin du barneratu, eta hori onartzen duten helburuetan linearen muntaia baliatu dezakegu horretarako.
    // LLVM-k lineako muntaiari buruz egiten duen interpretazioa da, kutxa beltza dela.
    // Hau ez da inplementazio handiena ziurrenik nahi duguna baino gehiago optimizatzen baitu, baina orain arte nahikoa ona da.
    //
    //

    #[cfg(not(miri))] // Hau aholku bat besterik ez da, beraz Miri saltatzea ondo dago.
    // SEGURTASUNA: lineako muntaia ez-operatiboa da.
    unsafe {
        // FIXME: Ezin da `asm!` erabili, MIPS eta bestelako arkitekturak onartzen ez dituelako.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}