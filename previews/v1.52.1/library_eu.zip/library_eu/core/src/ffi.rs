#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Atzerriko funtzio interfazearen (FFI) loturekin lotutako utilitateak.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// C's `void` motaren baliokidea [pointer] gisa erabiltzen denean.
///
/// Funtsean, `*const c_void` C's `const void*`-ren baliokidea da eta `*mut c_void` C's `void*`-ren baliokidea.
/// Hori bai, hau ez da C's `void` itzulera motaren berdina, hau da, Rust-ren `()` mota.
///
/// FFIko tipo opakoen erakusleak modelatzeko, `extern type` egonkortu arte, gomendatzen da newtype biltzailea erabiltzea byte hutsen array baten inguruan.
///
/// [Nomicon] ikusi xehetasunak lortzeko.
///
/// `std::os::raw::c_void` erabil liteke Rust konpilatzaile zaharra 1.1.0 ra arte onartzea nahi badute.
/// Rust 1.30.0 ondoren, definizio honekin berriro esportatu zen.
/// Informazio gehiagorako, irakurri [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// Oharra: LLVM-k erakusle mota hutsa eta malloc() bezalako luzapen funtzioen arabera ezagutu dezan, LLVM bit kodean i8 * gisa irudikatu behar dugu.
// Hemen erabilitako enum-ak ziurtatzen du eta "raw" motaren erabilera okerra saihesten du aldaera pribatuak soilik edukita.
// Bi aldaera behar ditugu, konpiladoreak repr atributuaz kexatzen delako bestela eta gutxienez aldaera bat behar dugulako, bestela, enum-a biztanlerik gabe egongo litzateke eta erakusle horiek gutxienez erreferentziatzea UB izango litzatekeelako.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` baten oinarrizko inplementazioa.
// Izena WIP da, oraingoz `VaListImpl` erabiliz.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` baino aldaezina denez, `VaListImpl<'f>` objektu bakoitza definitzen den funtzioaren eskualdeari lotuta dago
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` baten ABI inplementazioa.
/// Ikusi [AArch64 Procedure Call Standard] xehetasun gehiago lortzeko.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` baten ABI inplementazioa.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` baten ABI inplementazioa.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` batentzako bilgarria
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bihurtu `VaListImpl` C0 `va_list`-rekin bitarra den `VaList` bihurtzeko.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bihurtu `VaListImpl` C0 `va_list`-rekin bitarra den `VaList` bihurtzeko.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait interfaze publikoetan erabili behar da, hala ere, trait bera ez da modulu honetatik kanpo erabili behar.
// Erabiltzaileei trait mota berri baterako ezartzeko baimena emateak (horrela va_arg intrintsekoa mota berri batean erabiltzea ahalbidetuz) litekeena da zehaztu gabeko portaera eragitea.
//
// FIXME(dlrobertson): VaArgSafe trait interfaze publiko batean erabiltzeko baina beste nonbait ezin dela erabili ziurtatzeko, trait publikoa modulu pribatu baten barruan egon behar da.
// Behin RFC 2145 ezarri ondoren hori hobetzea aztertu.
//
//
//
//
mod sealed_trait {
    /// Trait honek baimendutako motak [super::VaListImpl::arg]-rekin erabiltzeko aukera ematen du.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Aurreratu hurrengo arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SEGURTASUNA: deitzaileak `va_arg`-rako segurtasun kontratua onartu behar du.
        unsafe { va_arg(self) }
    }

    /// `va_list` uneko kokapenean kopiatzen du.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SEGURTASUNA: deitzaileak `va_end`-rako segurtasun kontratua onartu behar du.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SEGURTASUNA: `MaybeUninit`-era idazten dugu, beraz hasieratu egiten da eta `assume_init` legezkoa da
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: honek `va_end` deitu beharko luke, baina ez dago modu garbirik
        // bermatu `drop` bere deitzailean beti txertatzen dela, beraz `va_end` ri zuzenean deituko litzaioke dagokion `va_copy` funtzio beretik.
        // `man va_end` C-k hori eskatzen duela dio eta LLVM-k funtsean C semantikari jarraitzen dio, beraz, ziurtatu behar dugu `va_end` beti `va_copy`-ren funtzio beretik deitzen dela.
        //
        // Xehetasun gehiagorako, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Honek oraingoz funtzionatzen du, `va_end` uneko LLVM helburu guztietan ez dagoelako inolako operaziorik.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Suntsitu `ap` arglist-a `va_start` edo `va_copy`-rekin hasieratu ondoren.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// `src` arglistaren uneko kokapena kopiatzen du `dst` arglistera.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `T` motako argumentu bat kargatzen du `va_list` `ap`-tik eta `ap` argumentua puntuatzen du.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}