//! `Clone` trait "inplizituki kopiatu" ezin diren motetarako.
//!
//! Rust-n, mota sinple batzuk "implicitly copyable" dira eta horiek esleitzen dituzunean edo argumentu gisa pasatzean, hartzaileak kopia bat lortuko du, jatorrizko balioa bere horretan utziz.
//! Mota hauek ez dute kopiatzeko esleipenik behar eta ez dute finalizatzailerik (hau da, ez dute jabetzako kutxarik edo [`Drop`] inplementaziorik), beraz, konpiladoreak merkeak eta seguruak dira kopiatzeko.
//!
//! Beste motetarako kopiak esplizituki egin behar dira, [`Clone`] trait inplementatuz eta [`clone`] metodoari deituz.
//!
//! [`clone`]: Clone::clone
//!
//! Oinarrizko erabilera adibidea:
//!
//! ```
//! let s = String::new(); // Kate motak Klona inplementatzen du
//! let copy = s.clone(); // beraz, klona dezakegu
//! ```
//!
//! Clone trait erraz inplementatzeko, `#[derive(Clone)]` ere erabil dezakezu.Adibidez:
//!
//! ```
//! #[derive(Clone)] // Clone trait gehitzen diogu Morpheus struct-i
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // eta orain klonatu dezakegu!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Objektu bat esplizituki bikoizteko gaitasuna lortzeko trait arrunta.
///
/// [`Copy`]-etik bereizten da [`Copy`] horretan inplizitua eta oso merkea den bitartean, `Clone` beti esplizitua da eta garestia izan daiteke edo ez.
/// Ezaugarri horiek betearazteko, Rust-k ez du [`Copy`] berriro ezartzea baimentzen, baina `Clone` berriro ezartzeko eta kode arbitrarioa exekutatu dezakezu.
///
/// `Clone` [`Copy`] baino orokorragoa denez, [`Copy`] ere `Clone` ere egin dezakezu.
///
/// ## Derivable
///
/// trait hau `#[derive]`-rekin erabil daiteke eremu guztiak `Clone` badira.[`Clone`]-ren `derive`d inplementazioak [`clone`] deiak egiten ditu eremu bakoitzean.
///
/// [`clone`]: Clone::clone
///
/// Egitura generiko baterako, `#[derive]`-k `Clone` inplementatzen du baldintzapean parametro generikoetan `Clone` lotua gehituz.
///
/// ```
/// // `derive` irakurtzeko klona inplementatzen du<T>T klona denean.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Nola ezar dezaket `Clone`?
///
/// [`Copy`] diren motek `Clone` inplementazio hutsala izan beharko lukete.Formalago:
/// `T: Copy`, `x: T` eta `y: &T` badira, `let x = y.clone();` `let x = *y;` ren baliokidea da.
/// Eskuzko inplementazioek kontuz ibili beharko lukete aldaezin hori mantentzeko;hala ere, segurtasunik gabeko kodea ez da horretaz fidatu behar memoriaren segurtasuna bermatzeko.
///
/// Adibide bat funtzio erakuslea duen egitura generikoa da.Kasu honetan, `Clone` ren inplementazioa ezin da `deribatu`d, baina honela gauzatu daiteke:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Inplementatzaile osagarriak
///
/// [implementors listed below][impls] az gain, mota hauek `Clone` ere ezartzen dute:
///
/// * Funtzio elementu motak (hau da, funtzio bakoitzerako definitutako mota desberdinak)
/// * Funtzio erakusle motak (adibidez, `fn() -> i32`)
/// * Matrize motak, tamaina guztietarako, elementu motak `Clone` ere inplementatzen badu (adibidez, `[i32; 123456]`)
/// * Tuple motak, osagai bakoitzak `Clone` ere inplementatzen badu (adibidez, `()`, `(i32, bool)`)
/// * Itxiera motak, ingurunetik baliorik hartzen ez badute edo harrapatutako balio guztiek `Clone` beraiek ezartzen badute.
///   Kontuan izan erreferentzia partekatuaren bidez harrapatutako aldagaiek `Clone` inplementatzen dutela beti (erreferenteak ez badu ere), aldiz, aldagai diren erreferentzien bidez harrapatutako aldagaiek ez dute inoiz `Clone` gauzatzen.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Balioaren kopia itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str inplementatzen du Klona
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Kopia-esleipena egiten du `source`-tik.
    ///
    /// `a.clone_from(&b)` funtzionaltasunean `a = b.clone()` ren baliokidea da, baina gainidatz daiteke `a` baliabideak berrerabiltzeko beharrezkoak ez diren esleipenak ekiditeko.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Eraman makroa trait `Clone` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): egitura hauek#[derive]-k soilik erabiltzen ditu mota bateko osagai guztiek Klonatzea edo Kopiatzea inplementatzen dutela baieztatzeko.
//
//
// Egitura hauek ez dira inoiz erabiltzailearen kodean agertu behar.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone`-ren inplementazioak mota primitiboetarako.
///
/// Rust-n deskribatu ezin diren inplementazioak `traits::SelectionContext::copy_clone_conditions()`-n inplementatzen dira `rustc_trait_selection`-n.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Partekatutako erreferentziak klona daitezke, baina alda daitezkeen erreferentziak *ezin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Partekatutako erreferentziak klona daitezke, baina alda daitezkeen erreferentziak *ezin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}