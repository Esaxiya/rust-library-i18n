//! Panic laguntza libcore-rako
//!
//! Liburutegi nagusiak ezin du izua definitu, baina izua * deklaratzen du.
//! Horrek esan nahi du libcore-ren barruko funtzioak panic-ri onartzen zaizkiela, baina erabilgarria izateko goranzko crate-k izua definitu behar du libcore erabiltzeko.
//! Izutzeko uneko interfazea hau da:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definizio honek edozein mezu orokorrekin izua hartzea ahalbidetzen du, baina ez du `Box<Any>` balioarekin huts egitea onartzen.
//! (`PanicInfo`-k `&(dyn Any + Send)` bat besterik ez du, eta horretarako `PanicInfo: : internal_constructor` atalean balio okerra betetzen dugu.) Horren arrazoia libcore-k ez du baimenik ematen.
//!
//!
//! Modulu honek izutzeko beste zenbait funtzio ditu, baina hauek konpiladorerako beharrezkoak diren lang elementuak dira.panics guztiak funtzio honen bidez bideratzen dira.
//! Benetako sinboloa `#[panic_handler]` atributuaren bidez deklaratzen da.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore-ren `panic!` makroaren azpiko inplementazioa formaturik erabiltzen ez denean.
#[cold]
// inoiz ez sartu lerroan panic_immediate_abort salbu eta dei guneetan kode puztea ahalik eta gehien saihesteko
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // codegen-ek behar du panic-i gainezkapenean eta beste `Assert` MIR terminatzaileei
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Erabili Arguments::new_v1 format_args-en ordez! ("{}", Expr) tamainaren gainkarga murrizteko.
    // The format_args!makroak str-en Display trait erabiltzen du expr idazteko, Formatter::pad deitzen duena, kate mozketa eta betegarria egokitu behar dituena (hemen bat ere erabiltzen ez bada ere).
    //
    // Arguments::new_v1 erabiltzeak konpiladoreak Formatter::pad irteerako bitarretik kanpo uztea baimendu dezake, kilobyte batzuk aurreztuz.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // beharrezkoa da konst-ebaluatutako panics-rentzat
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // codegen-ek behar du panic rako OOB array/slice sarbidean
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Libcore-ren `panic!` makroaren azpiko inplementazioa formatua erabiltzen denean.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OHARRA Funtzio honek ez du inoiz FFI muga zeharkatzen;`#[panic_handler]` funtziora konpontzen den Rust-Rust deia da.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEGURTASUNA: `panic_impl` Rust kode seguruan definitzen da eta, beraz, segurua da deitzea.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` eta `assert_ne!` makroentzako barne funtzioa
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}