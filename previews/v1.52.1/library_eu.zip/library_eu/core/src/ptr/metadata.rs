#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Seinalatutako edozein motatako erakuslearen metadatu mota eskaintzen du.
///
/// # Erakuslearen metadatuak
///
/// Rust-n dauden erakusle mota gordinak eta erreferentzia motak bi zatiz osatuta daudela pentsa daiteke:
/// balioaren memoria helbidea eta metadatu batzuk biltzen dituen datu erakuslea.
///
/// Tamaina estatikoko motetarako (`Sized` traits ezartzen dutenak) eta baita `extern` motetarako ere, erakusleak "finak" direla esaten da: metadatuak zero tamainakoak dira eta bere mota `()` da.
///
///
/// [dynamically-sized types][dst]-rako erakusleak "zabalak" edo "lodiak" direla esan ohi da, zero tamainako metadatuak dituzte:
///
/// * Azken eremua DST-a duten egituretarako, metadatuak azken eremuko metadatuak dira
/// * `str` motarako, metadatuak byteetako luzera da `usize` gisa
/// * `[T]` bezalako xerra motetarako, metadatuak elementuen luzera da `usize` gisa
/// * `dyn SomeTrait` bezalako trait objektuetan, metadatuak [`DynMetadata<Self>`][DynMetadata] dira (adibidez, `DynMetadata<dyn SomeTrait>`)
///
/// future-n, Rust lengoaiak erakusle metadatu desberdinak dituzten mota berriak irabazi ditzake.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// trait honen puntua `Metadata` lotutako mota da, hau da, `()` edo `usize` edo `DynMetadata<_>` goian deskribatu den moduan.
/// Automatikoki inplementatzen da mota guztietarako.
/// Testuinguru generikoan inplementatuta dagoela suposa daiteke, dagokion loturarik gabe ere.
///
/// # Usage
///
/// Erakusle gordinak datu helbidera eta metadatuen osagaietara deskonposatu daitezke [`to_raw_parts`] metodoarekin.
///
/// Bestela, metadatuak bakarrik atera daitezke [`metadata`] funtzioarekin.
/// Erreferentzia bat [`metadata`]-ra pasa daiteke eta inplizituki behartu.
///
/// (possibly-wide) erakuslea berriro jarri daiteke bere helbidetik eta metadatuetatik [`from_raw_parts`] edo [`from_raw_parts_mut`] bidez.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Metadatuen erakusle mota eta `Self` erreferentzietan.
    #[lang = "metadata_type"]
    // NOTE: Mantendu trait bounds `static_assert_expected_bounds_for_metadata`-n
    //
    // `library/core/src/ptr/metadata.rs`-n hemen daudenekin sinkronizatuta:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// trait ezizena hau inplementatzen duten moten erakusleak "argalak" dira.
///
/// Honek estatikoki "Tamaina" motak eta `extern` motak barne hartzen ditu.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ez egonkortu hau trait ezizenak hizkuntzan egonkorrak izan aurretik?
pub trait Thin = Pointee<Metadata = ()>;

/// Ateratu erakuslearen metadatuen osagaia.
///
/// `*mut T`, `&T` edo `&mut T` motako balioak zuzenean pasa daitezke funtzio honetara `* const T`-era behartuta inplizituki.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEGURTASUNA: `PtrRepr` sindikatutik balioa sartzea segurua da * const T
    // eta PtrComponents<T>memoria diseinu berdinak dituzte.
    // std k bakarrik egin dezake berme hori.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// (possibly-wide) erakusle gordina osatzen du datu helbide eta metadatuetatik.
///
/// Funtzio hau segurua da, baina itzultzen den erakuslea ez da nahitaez desbideratzeko segurua.
/// Xafletarako, ikusi [`slice::from_raw_parts`] dokumentazioa segurtasun baldintzak lortzeko.
/// trait objektuetan, metadatuek erakusle batetik atera behar dute azpian ezabatutako mota berera.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEGURTASUNA: `PtrRepr` sindikatutik balioa sartzea segurua da * const T
    // eta PtrComponents<T>memoria diseinu berdinak dituzte.
    // std k bakarrik egin dezake berme hori.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] ren funtzionalitate bera betetzen du, salbu `*mut` erakusle gordina itzultzen dela, `* const` erakusle gordinaren aldean.
///
///
/// Ikusi [`from_raw_parts`] dokumentazioa xehetasun gehiagorako.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEGURTASUNA: `PtrRepr` sindikatutik balioa sartzea segurua da * const T
    // eta PtrComponents<T>memoria diseinu berdinak dituzte.
    // std k bakarrik egin dezake berme hori.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Eskuzko inplementazioa beharrezkoa da `T: Copy` lotua ekiditeko.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Eskuzko inplementazioa beharrezkoa da `T: Clone` lotua ekiditeko.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait objektu mota baten metadatuak.
///
/// trait objektu baten barruan gordetako hormigoizko mota manipulatzeko beharrezko informazio guztia adierazten duen vtable (dei birtualen taula) baterako erakuslea da.
/// Vtable-a, batez ere, dauka:
///
/// * motaren tamaina
/// * mota lerrokatzea
/// * erakuslearen motako `drop_in_place` inplikazioarentzako (datu arruntetarako ez-op izan daiteke)
/// * trait mota inplementatzeko metodo guztiei buruzko erakusleak
///
/// Kontuan izan lehenengo hirurak bereziak direla, edozein trait objektu esleitu, utzi eta berriro banatzeko beharrezkoak direlako.
///
/// Posible da egitura hau `dyn` trait objektu bat ez den (adibidez, `DynMetadata<u64>`) motako parametro batekin izendatzea baina ez egitura horren balio esanguratsua lortzeko.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Taula guztien aurrizki arrunta.Ondoren, funtzio erakusleak daude trait metodoetarako.
///
/// `DynMetadata::size_of` etab. Inplementazio pribatuko xehetasunak.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Vtable honekin lotutako motaren tamaina itzultzen du.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Vtable honekin lotutako motaren lerrokadura ematen du.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Tamaina eta lerrokadura batera itzultzen ditu `Layout` gisa
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEGURTASUNA: konpiladoreak taula hau igorri zuen hormigoizko Rust motarako
        // ezagunak dira baliozko diseinua duela.`Layout::for_value`-ren arrazoibide bera.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` mugak saihesteko beharrezko eskuliburua.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}