use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Bilgarri ez den `*mut T` gordinaren inguruko bilgailua bilgarri horren jabea erreferentearen jabea dela adierazten duen.
/// Erabilgarria `Box<T>`, `Vec<T>`, `String` eta `HashMap<K, V>` bezalako abstrakzioak eraikitzeko.
///
/// `*mut T`-k ez bezala, `Unique<T>`-k "as if" jokatzen du, `T`-ren instantzia zen.
/// `Send`/`Sync` ezartzen du `T` `Send`/`Sync` bada.
/// `T`-ren instantzia batek espero dezakeen aliasing sendoaren bermea ere badakar:
/// erakuslearen erreferentea ez da aldatu behar bere jabe izateko bide bakarra izan gabe.
///
/// `Unique` zure helburuetarako erabiltzea zuzena den ala ez badakizu, pentsa ezazu semantika ahulagoa duen `NonNull` erabiltzea.
///
///
/// `*mut T`-k ez bezala, erakusleak ez-nulua izan behar du beti, nahiz eta erakuslea inoiz ez den erreferentziarik egiten.
/// Hau da, enumek debekatutako balio hori diskriminatzaile gisa erabil dezaten-`Option<Unique<T>>`-k `Unique<T>`-ren tamaina bera du.
/// Hala ere, erakusleak oraindik zintzilik egon daiteke erreferentziarik egiten ez bada.
///
/// `*mut T` ez bezala, `Unique<T>` `T` baino kobariantea da.
/// Hori beti zuzena izan beharko da Unique-en aliasing eskakizunak betetzen dituzten edozein motatako.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: markatzaile horrek ez du bariantzan ondoriorik, baina beharrezkoa da
    // Dropck-ek logikoki `T` baten jabea garela ulertzeko.
    //
    // Xehetasunak lortzeko, ikus:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` erakusleak `Send` dira, baldin eta `T` `Send` bada erreferentzia egiten duten datuak aliasik ez daudelako.
/// Kontuan izan aliasing aldaera hori ez duela indarrean mota-sistemak;`Unique` erabiltzen duen abstrakzioak indarrean jarri behar du.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` erakusleak `Sync` dira, baldin eta `T` `Sync` bada erreferentzia egiten duten datuak aliasik ez daudelako.
/// Kontuan izan aliasing aldaera hori ez duela indarrean mota-sistemak;`Unique` erabiltzen duen abstrakzioak indarrean jarri behar du.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Zintzilik dagoen baina ondo lerrokatuta dagoen `Unique` berria sortzen du.
    ///
    /// Hau erabilgarria da `Vec::new`-k egiten duen bezala alferki esleitzen dituzten motak hasieratzeko.
    ///
    /// Kontuan izan erakuslearen balioak balizko erakusle bat ordezkatu dezakeela `T` batentzat, hau da, ez da "not yet initialized" sentinela balio gisa erabili behar.
    /// Alferki esleitzen dituzten motek hasieraren jarraipena beste bide batzuekin egin behar dute.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURTASUNA: mem::align_of()-k baliozko eta nulua ez den erakuslea itzultzen du.The
        // new_unchecked() deitzeko baldintzak errespetatzen dira.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` berria sortzen du.
    ///
    /// # Safety
    ///
    /// `ptr` ez-nulua izan behar du.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURTASUNA: deitzaileak `ptr` ez-nulua dela bermatu behar du.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `Unique` berria sortzen du `ptr` nulua ez bada.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURTASUNA: erakuslea dagoeneko egiaztatu da eta ez da nulua.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Azpiko `*mut` erakuslea eskuratzen du.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Edukia aipatzen du.
    ///
    /// Lortutako bizitzak norberari lotua dago, beraz, honek "as if" jokatzen du, benetan maileguan hartzen ari den T-ren instantzia izan zen.
    /// (unbound) bizitza luzeagoa behar bada, erabili `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        unsafe { &*self.as_ptr() }
    }

    /// Edukiak elkarri erreferentzia egiten dio.
    ///
    /// Lortutako bizitzak norberari lotua dago, beraz, honek "as if" jokatzen du, benetan maileguan hartzen ari den T-ren instantzia izan zen.
    /// (unbound) bizitza luzeagoa behar bada, erabili `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia alda daitekeen baldintzak.
        unsafe { &mut *self.as_ptr() }
    }

    /// Beste mota bateko erakusleari igortzen dio.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEGURTASUNA: Unique::new_unchecked()-k berezitasun eta behar berri bat sortzen du
        // emandako erakuslea nulua ez izateko.
        // Norbera erakusle gisa pasatzen ari garenez, ezin da nulua izan.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURTASUNA: alda daitekeen erreferentzia bat ezin da nulua izan
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}