use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` baina ez-nulua eta kobariantea.
///
/// Erakusle gordinak erabiliz datu egiturak eraikitzerakoan erabili beharreko gauza zuzena izaten da hau, baina azkenean erabiltzea arriskutsuagoa da propietate osagarriengatik.Ez bazaude ziur `NonNull<T>` erabili behar duzun ala ez, erabili `*mut T`!
///
/// `*mut T` ez bezala, erakusleak ez-nulua izan behar du beti, nahiz eta erakuslea inoiz ez den erreferentziarik egiten.Hau da, enumek debekatutako balio hori diskriminatzaile gisa erabil dezaten-`Option<NonNull<T>>`-k `* mut T`-ren tamaina bera du.
/// Hala ere, erakusleak oraindik zintzilik egon daiteke erreferentziarik egiten ez bada.
///
/// `*mut T` ez bezala, `NonNull<T>` aukeratu zen `T` baino gehiago kobariantzeko.Horrek ahalbidetzen du `NonNull<T>` erabiltzea kobariantza motak eraikitzerakoan, baina kobarianteak izan behar ez lukeen mota batean erabiltzen badira sentikortasunik ez izateko arriskua dakar.
/// (Kontrako aukera egin da `*mut T` rentzat, nahiz eta teknikoki ez-segurua funtzio seguruak deitzean soilik sor daitekeen.)
///
/// Kobariantzia zuzena da abstrakzio seguru gehienetarako, hala nola `Box`, `Rc`, `Arc`, `Vec` eta `LinkedList`.Hori gertatzen da Rust-ren XOR partekatutako arau aldakor normalak jarraitzen dituen API publikoa eskaintzen dutelako.
///
/// Zure mota segurtasunez ezin bada kopariantza izan, aldaezina emateko eremu osagarriren bat duela ziurtatu behar duzu.Sarritan eremu hau [`PhantomData`] mota izango da `PhantomData<Cell<T>>` edo `PhantomData<&'a mut T>` bezalakoa.
///
/// Kontuan izan `NonNull<T>`-k `From` instantzia bat duela `&T`-rako.Hala ere, horrek ez du aldatzen erreferentzia partekatu baten bidez (erakusketatik eratorritako erakuslea) mutatzea zehaztu gabeko portaera denik, mutazioa [`UnsafeCell<T>`] baten barruan gertatzen ez bada.Gauza bera gertatzen da erreferentzia partekatu batetik aldagarriak diren erreferentziak sortzeko.
///
/// `From` instantzia hau `UnsafeCell<T>` gabe erabiltzen duzunean, zure erantzukizuna da `as_mut` inoiz deitzen ez dela eta `as_ptr` ez dela inoiz mutaziorako erabiltzen ziurtatzea.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` erakusleak ez dira `Send`, aipatzen dituzten datuak aliasatuak izan daitezkeelako.
// Oharra, inplementazio hau ez da beharrezkoa, baina errore mezu hobeak eman beharko lituzke.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` erakusleak ez dira `Sync`, aipatzen dituzten datuak aliasatuak izan daitezkeelako.
// Oharra, inplementazio hau ez da beharrezkoa, baina errore mezu hobeak eman beharko lituzke.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Zintzilik dagoen baina ondo lerrokatuta dagoen `NonNull` berria sortzen du.
    ///
    /// Hau erabilgarria da `Vec::new`-k egiten duen bezala alferki esleitzen dituzten motak hasieratzeko.
    ///
    /// Kontuan izan erakuslearen balioak balizko erakusle bat ordezkatu dezakeela `T` batentzat, hau da, ez da "not yet initialized" sentinela balio gisa erabili behar.
    /// Alferki esleitzen dituzten motek hasieraren jarraipena beste bide batzuekin egin behar dute.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURTASUNA: mem::align_of()-k zero ez den erabilpen bat itzultzen du, gero botatzen dena
        // bati * mut T.
        // Hori dela eta, `ptr` ez da nulua eta new_unchecked() deitzeko baldintzak errespetatzen dira.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Balioaren erreferentzia partekatuak itzultzen ditu.[`as_ref`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Balioaren erreferentzia bakarra ematen du.[`as_mut`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Partekatutako konpartsa ikusteko [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` berria sortzen du.
    ///
    /// # Safety
    ///
    /// `ptr` ez-nulua izan behar du.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURTASUNA: deitzaileak `ptr` ez-nulua dela bermatu behar du.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `NonNull` berria sortzen du `ptr` nulua ez bada.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURTASUNA: erakuslea dagoeneko egiaztatuta dago eta ez da nulua
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] ren funtzionalitate bera betetzen du, `NonNull` erakuslea itzultzen dela salbu, `*const` erakusle gordinaren aurrean.
    ///
    ///
    /// Ikusi [`std::ptr::from_raw_parts`] dokumentazioa xehetasun gehiagorako.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEGURTASUNA: `ptr::from::raw_parts_mut`-ren emaitza ez da nulua `data_address` delako.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Deskonposatu erakusle bat (agian zabala) helbidea eta metadatuen osagaietan.
    ///
    /// Erakuslea geroago [`NonNull::from_raw_parts`]-rekin berreraiki daiteke.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Azpiko `*mut` erakuslea eskuratzen du.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Balioaren erreferentzia partekatua itzultzen du.Balioa hasierarik gabe egon badaiteke, [`as_uninit_ref`] erabili behar da horren ordez.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Erakusleak hasierako `T` instantzia seinalatu behar du.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    /// (Hasieratzen ari den zatia oraindik ez dago erabat erabakita, baina hala izan arte, ikuspegi seguru bakarra benetan hasieratuta daudela ziurtatzea da.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        unsafe { &*self.as_ptr() }
    }

    /// Balioaren erreferentzia bakarra ematen du.Balioa hasierarik gabe egon badaiteke, [`as_uninit_mut`] erabili behar da horren ordez.
    ///
    /// Partekatutako konpartsa ikusteko [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Erakusleak hasierako `T` instantzia seinalatu behar du.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    /// (Hasieratzen ari den zatia oraindik ez dago erabat erabakita, baina hala izan arte, ikuspegi seguru bakarra benetan hasieratuta daudela ziurtatzea da.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia alda daitekeen baldintzak.
        unsafe { &mut *self.as_ptr() }
    }

    /// Beste mota bateko erakusleari igortzen dio.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEGURTASUNA: `self` nahitaez nulua ez den `NonNull` erakuslea da
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Erakusle fin batetik eta luzera batetik xerra gordin ez-nulua sortzen du.
    ///
    /// `len` argumentua **elementu** kopurua da, ez byte kopurua.
    ///
    /// Funtzio hau segurua da, baina itzulerako balioa erreferentziatzea ez da segurua.
    /// Ikusi [`slice::from_raw_parts`] ren dokumentazioa zatien segurtasun baldintzak lortzeko.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // sortu xerra erakuslea lehen elementura erakuslearekin hasten zarenean
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Kontuan izan adibide honek artifizialki metodo honen erabilera erakusten duela, baina `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEGURTASUNA: `data` nahitaez nulua ez den `NonNull` erakuslea da
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Xerra gordinik gabeko zatiaren luzera itzultzen du.
    ///
    /// Itzulitako balioa **elementu** kopurua da, ez byte kopurua.
    ///
    /// Funtzio hau segurua da, nahiz eta zatirik gordin ez-nulua xerra batera ezin den erreferentziatu, erakusleak ez duelako baliozko helbiderik.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Erakusle ez nulua itzultzen du zatiaren bufferrera.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEGURTASUNA: Badakigu `self` ez dela nulua.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Erakusle gordin bat zatiaren bufferrera itzultzen du.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Partekatutako erreferentzia bat hasierarik gabeko baloreen zati bati ematen dio.[`as_ref`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak [valid] izan behar du `ptr.len() * mem::size_of::<T>()` byte askotan irakurtzeko, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
    ///
    ///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
    ///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.
    ///
    ///     * Erakusleak lerrokatuta egon behar du zero luzerako zatietan ere.
    ///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
    ///
    ///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
    ///
    /// * Xerraren `ptr.len() * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
    ///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// Ikus [`slice::from_raw_parts`] ere.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEGURTASUNA: deitzaileak `as_uninit_slice`-rako segurtasun kontratua onartu behar du.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Inizializatu gabeko baloreen zatiari erreferentzia bakarra ematen dio.[`as_mut`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Partekatutako konpartsa ikusteko [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, hau guztia egia dela ziurtatu behar duzu:
    ///
    /// * Erakusleak [valid] izan behar du irakurtzeko eta idazteko `ptr.len() * mem::size_of::<T>()` byte askotan, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
    ///
    ///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
    ///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.
    ///
    ///     * Erakusleak lerrokatuta egon behar du zero luzerako zatietan ere.
    ///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
    ///
    ///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
    ///
    /// * Xerraren `ptr.len() * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
    ///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// Ikus [`slice::from_raw_parts_mut`] ere.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Hau segurua da, `memory` irakurtzeko eta idazteko balio duelako `memory.len()` byte askotan.
    /// // Kontuan izan `memory.as_mut()` deitzea hemen ez dela onartzen, edukia hasierarik gabe egon daitekeelako.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEGURTASUNA: deitzaileak `as_uninit_slice_mut`-rako segurtasun kontratua onartu behar du.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Erakusle gordina elementu edo azpisail batera itzultzen du, mugen egiaztapena egin gabe.
    ///
    /// Metodo honi mugaz kanpoko indizearekin edo `self` erreferentzializatzerik ez dagoenean deitzea *[zehaztu gabeko portaera]* da, nahiz eta ondorioz erakuslea erabiltzen ez den.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEGURTASUNA: deitzaileak `self` erreferentziazina dela eta `index` mugagabea dela ziurtatzen du.
        // Ondorioz, lortutako erakuslea ezin da NULL izan.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEGURTASUNA: Erakusle bakarra ezin da nulua izan, beraz, baldintzak
        // new_unchecked() errespetatzen dira.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURTASUNA: alda daitekeen erreferentzia bat ezin da nulua izan.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEGURTASUNA: Erreferentzia bat ezin da nulua izan, beraz, baldintzak
        // new_unchecked() errespetatzen dira.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}