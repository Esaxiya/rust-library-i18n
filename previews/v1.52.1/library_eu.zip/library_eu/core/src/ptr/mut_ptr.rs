use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// `true` ematen du erakuslea nulua bada.
    ///
    /// Kontuan hartu tamaina gabeko formek erakusle nulu ugari dituztela, datu gordinen erakuslea soilik hartzen baita kontuan, ez haien luzera, taula, etab.
    /// Hori dela eta, baliteke nuluak diren bi erakusleek elkarren arteko berdinak ez izatea.
    ///
    /// ## Konportuen ebaluazioan portaera
    ///
    /// Funtzio hau const ebaluazioan erabiltzen denean, `false` itzul dezake exekuzio garaian nuluak diren erakusleentzat.
    /// Zehazki, memoria batzuetarako erakuslea bere mugetatik haratago konpentsatzen denean, ondorioz, erakuslea nulua izan dadin, funtzioak `false` itzuliko du.
    ///
    /// CTFEk ez du modurik memoria horren posizio absolutua ezagutzeko, beraz ezin dugu jakin erakuslea nulua den edo ez.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Konparatu aktore baten bidez erakusle mehe batekin, beraz, erakusle lodiek "data" zatia soilik kontuan hartzen dute.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Beste mota bateko erakusleari igortzen dio.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Deskonposatu erakusle bat (agian zabala) helbidea eta metadatuen osagaietan.
    ///
    /// Erakuslea [`from_raw_parts_mut`]-rekin berregin daiteke.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// `None` itzultzen du erakuslea nulua bada edo, bestela, `Some`-n bildutako balioaren erreferentzia partekatua ematen du.Balioa hasierarik gabe egon badaiteke, horren ordez [`as_uninit_ref`] erabili behar da.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Erakusleak hasierako `T` instantzia seinalatu behar du.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    /// (Hasieratzen ari den zatia oraindik ez dago erabat erabakita, baina hala izan arte, ikuspegi seguru bakarra benetan hasieratuta daudela ziurtatzea da.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Egiaztatu gabeko bertsioa
    ///
    /// Ziur bazaude erakuslea ezin dela inoiz nulua izan eta `&T` itzultzen duen `as_ref_unchecked` moduren bat bilatzen ari bazara `Option<&T>` ordez, jakin erakuslea zuzenean desferentzia dezakezula.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEGURTASUNA: deitzaileak `self` batentzat balio duela ziurtatu behar du
        // erreferentzia nulua ez bada.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// `None` ematen du erakuslea nulua bada edo, bestela, `Some`-n bildutako balioaren erreferentzia partekatua ematen du.
    /// [`as_ref`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Erakusle batetik desplazamendua kalkulatzen du.
    ///
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Baldintza hauetakoren bat urratzen bada, emaitza zehaztu gabeko portaera da:
    ///
    /// * Hasierako erakusleak eta ondorioz lortutako erakusleak esleitutako objektu beraren amaieraren muga edo byte bat izan behar dute.
    /// Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// * Kalkulatutako desplazamenduak,**bytetan**, ezin du `isize` gainezka egin.
    ///
    /// * Desplazamendua mugetan egoteak ezin du "wrapping around" helbide-espazioan oinarritu.Hau da, zehaztasun infinituaren batura,**byteetan**, erabilpen batean sartu behar da.
    ///
    /// Konpiladorea eta liburutegi estandarra, orokorrean, esleipenek inoiz ez duten tamaina bezainbeste lortzen saiatzen dira.
    /// Adibidez, `Vec` eta `Box` ek ziurtatzen dute inoiz ez dituztela `isize::MAX` byte baino gehiago esleitzen, beraz, `vec.as_ptr().add(vec.len())` beti da segurua.
    ///
    /// Plataforma gehienek funtsean ezin dute esleipen hori eraiki.
    /// Adibidez, 64 bit-eko plataforma ezagun batek ezin du inoiz 2 <sup>63</sup> byteko eskaerarik egin orri-taulako mugen ondorioz edo helbide-espazioa zatituta dagoelako.
    /// Hala ere, 32 biteko eta 16 biteko zenbait plataformek `isize::MAX` byte baino gehiagoko eskaera behar bezala egin dezakete Helbide Fisikoaren Luzapena bezalako gauzekin.
    ///
    /// Honela, esleitzaileetatik edo memoria mapatutako fitxategietatik zuzenean eskuratutako memoria * * handiegia izan daiteke * funtzio honekin kudeatzeko.
    ///
    /// Demagun horren ordez [`wrapping_offset`] erabiltzea murrizketa horiek asetzeko zailak badira.
    /// Metodo honen abantaila bakarra konpiladorearen optimizazio oldarkorragoak ahalbidetzen ditu.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `offset`-rako segurtasun kontratua onartu behar du.
        // Lortutako erakusleak idazketetarako balio du, deitzaileak `self` ren esleitutako objektu bera seinalatzen duela bermatu behar baitu.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Erakuslearen desplazamendua kalkulatzen du biltzeko aritmetika erabiliz.
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Eragiketa hori bera beti da segurua, baina ez da lortzen den erakuslea erabiltzea.
    ///
    /// Lortutako erakusleak `self`-k seinalatzen duen esleitutako objektu berari atxikita jarraitzen du.
    /// Baliteke *ez* erabiltzea esleitutako beste objektu batera sartzeko.Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// Beste modu batera esanda, `let z = x.wrapping_offset((y as isize) - (x as isize))`-k *ez* du `z` `y`-ren berdina bihurtzen, nahiz eta suposatzen dugun `T` `1` tamaina duela eta gainezkapenik ez dagoela: `z` oraindik `x` objektuari atxikita dagoela eta erreferentziarik gabeko jokabidea dela `x` eta `y` puntua esleitutako objektu berean.
    ///
    /// [`offset`]-rekin alderatuta, metodo honek, funtsean, esleitutako objektu berdinean egoteko eskakizuna atzeratzen du: [`offset`] berehalako portaera zehaztu gabea da objektuen mugak zeharkatzean;`wrapping_offset`-k erakuslea sortzen du, baina zehaztu gabeko portaera dakar, erakusleari lotzen zaion objektuaren mugetatik kanpo dagoenean erreferentzia bat ezabatzen bada.
    /// [`offset`] hobeto optimiza daiteke eta, beraz, hobe da errendimenduari dagokionez.
    ///
    /// Atzeratutako egiaztapenak erreferentziarik gabeko erakuslearen balioa soilik hartzen du kontuan, ez azken emaitza kalkulatzerakoan erabilitako bitarteko balioak.
    /// Adibidez, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` beti `x` bezalakoa da.Beste modu batera esanda, esleitutako objektua utzi eta gero berriro sartzea baimenduta dago.
    ///
    /// Objektuen mugak zeharkatu behar badituzu, bota erakuslea zenbaki oso batera eta egin aritmetika bertan.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // Iteratu erakusle gordina erabiliz bi elementuren zatitan
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEGURTASUNA: `arith_offset` berezkoak ez du deitzeko ezinbesteko baldintzarik.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// `None` ematen du erakuslea nulua bada edo, bestela, `Some`-n bildutako balioaren erreferentzia bakarra ematen du.Balioa hasierarik gabe egon badaiteke, horren ordez [`as_uninit_mut`] erabili behar da.
    ///
    /// Partekatutako konpartsa ikusteko [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Erakusleak hasierako `T` instantzia seinalatu behar du.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    /// (Hasieratzen ari den zatia oraindik ez dago erabat erabakita, baina hala izan arte, ikuspegi seguru bakarra benetan hasieratuta daudela ziurtatzea da.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Inprimatuko du: "[4, 2, 3]".
    /// ```
    ///
    /// # Egiaztatu gabeko bertsioa
    ///
    /// Ziur bazaude erakuslea ezin dela inoiz nulua izan eta `&mut T` itzultzen duen `as_mut_unchecked` moduren bat bilatzen ari bazara `Option<&mut T>` ordez, jakin erakuslea zuzenean desferentzia dezakezula.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Inprimatuko du: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SEGURTASUNA: deitzaileak `self`-rako balio duela bermatu behar du
        // erreferentzia aldakorra nulua ez bada.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// `None` ematen du erakuslea nulua bada edo, bestela, `Some`-n bildutako balioaren erreferentzia bakarra ematen du.
    /// [`as_mut`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Partekatutako konpartsa ikusteko [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak behar bezala lerrokatuta egon behar du.
    ///
    /// * "dereferencable" izan behar du [the module documentation]-n definitutako zentzuan.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `self` guztiak betetzen dituela bermatu behar du
        // erreferentzia egiteko baldintzak.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Bi erakusleek berdinak direla ziurtatzen du.
    ///
    /// Exekutatzean funtzio honek `self == other` bezala jokatzen du.
    /// Hala ere, zenbait testuingurutan (adibidez, konpilazio-denboraren ebaluazioa), ez da beti posible bi erakusleren berdintasuna zehaztea, beraz, funtzio horrek `false` modu itzelean itzul dezake gerora benetan berdinak diren erakusleentzat.
    ///
    /// Baina `true` itzultzen duenean, erakusleak berdinak direla ziurtatzen da.
    ///
    /// Funtzio hau [`guaranteed_ne`] ren ispilua da, baina ez alderantzizkoa.Bi funtzioek `false` itzultzen duten erakusleen konparazioak daude.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Itzulitako balioa konpilatzailearen bertsioaren arabera alda daiteke eta segurua ez den kodeek funtzio honen emaitzetan ez dute konfiantzarik izango.
    /// Funtzio hau errendimendua optimizatzeko soilik erabiltzea gomendatzen da, funtzio honen `false` faltsuak itzultzen dituzten balioak emaitzari eragiten ez diotenean, errendimendua baizik.
    /// Ez da aztertu metodo hau erabiltzeak exekuzio-denboran eta konpilazio-denboran kodea desberdin jokatzeko.
    /// Metodo hau ez da erabili behar desberdintasun horiek sartzeko eta, gainera, ez da egonkortu behar arazo hau hobeto ulertu aurretik.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Bi erakusle desberdina dela ziurtatuta dagoen ala ez itzultzen du.
    ///
    /// Exekutatzean funtzio honek `self != other` bezala jokatzen du.
    /// Hala ere, testuinguru batzuetan (adibidez, konpilazio-denboraren ebaluazioa), ez da beti posible bi erakusleren desberdintasuna zehaztea, beraz, funtzio honek `false` modu itzelean itzul dezake, gero desberdina izan daitekeen erakusleentzat.
    ///
    /// Baina `true` itzultzen duenean, erakusleak desorekak direla ziurtatzen da.
    ///
    /// Funtzio hau [`guaranteed_eq`] ren ispilua da, baina ez alderantzizkoa.Bi funtzioek `false` itzultzen duten erakusleen konparazioak daude.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Itzulitako balioa konpilatzailearen bertsioaren arabera alda daiteke eta segurua ez den kodeek funtzio honen emaitzetan ez dute konfiantzarik izango.
    /// Funtzio hau errendimendua optimizatzeko soilik erabiltzea gomendatzen da, funtzio honen `false` faltsuak itzultzen dituzten balioak emaitzari eragiten ez diotenean, errendimendua baizik.
    /// Ez da aztertu metodo hau erabiltzeak exekuzio-denboran eta konpilazio-denboran kodea desberdin jokatzeko.
    /// Metodo hau ez da erabili behar desberdintasun horiek sartzeko eta, gainera, ez da egonkortu behar arazo hau hobeto ulertu aurretik.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Bi erakusleren arteko distantzia kalkulatzen du.Itzulitako balioa T unitateetan dago: byteko distantzia `mem::size_of::<T>()` ekin zatitzen da.
    ///
    /// Funtzio hau [`offset`]-ren alderantzizkoa da.
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Baldintza hauetakoren bat urratzen bada, emaitza zehaztu gabeko portaera da:
    ///
    /// * Hasierako erakusleak eta beste erakusleak mugatuta egon behar dute edo esleitutako objektu beraren amaierako byte bat izan behar dute.
    /// Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// * Bi erakusleak *objektu beraren erakusle batetik* eratorriak izan behar dira.
    ///   (Ikus beheko adibide bat.)
    ///
    /// * Erakusleen arteko distantziak, bytetan, `T` tamainaren multiplo zehatza izan behar du.
    ///
    /// * Erakusleen arteko distantziak,**bytetan**, ezin du `isize` gainezka egin.
    ///
    /// * Mugan dagoen distantziak ezin du "wrapping around" helbide-espazioan oinarritu.
    ///
    /// Rust motak ez dira inoiz `isize::MAX` baino handiagoak eta Rust esleipenak ez dira inoiz helbide espazioan biltzen, beraz, edozein Rust motako `T` motako balio batzuetako bi erakusleek azken bi baldintzak beteko dituzte.
    ///
    /// Liburutegi estandarrak, oro har, bermatzen du esleipenek inoiz ez dutela desplazamendua kezkatzen duten tamaina lortzen.
    /// Adibidez, `Vec`-k eta `Box`-k inoiz ez dutela `isize::MAX` byte baino gehiago esleitzen ziurtatzen dute, beraz, `ptr_into_vec.offset_from(vec.as_ptr())`-k beti betetzen ditu azken bi baldintzak.
    ///
    /// Plataforma gehienek, funtsean, ezin dute hain esleipen handirik eraiki.
    /// Adibidez, 64 bit-eko plataforma ezagun batek ezin du inoiz 2 <sup>63</sup> byteko eskaerarik egin orri-taulako mugen ondorioz edo helbide-espazioa zatituta dagoelako.
    /// Hala ere, 32 biteko eta 16 biteko zenbait plataformek `isize::MAX` byte baino gehiagoko eskaera behar bezala egin dezakete Helbide Fisikoaren Luzapena bezalako gauzekin.
    /// Honela, esleitzaileetatik edo memoria mapatutako fitxategietatik zuzenean eskuratutako memoria * * handiegia izan daiteke * funtzio honekin kudeatzeko.
    /// (Kontuan izan [`offset`] eta [`add`]-k ere antzeko muga dutela eta, beraz, ezin direla hain esleipen handietan erabili.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Funtzio hau panics bada `T` Zero-Tamaina motako ("ZST") bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Erabilera okerra*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Egin ptr2_other ptr2-ren "alias" bat, baina ptr1-tik eratorria.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ptr2_other eta ptr2 erakusleetatik objektu desberdinetara eratortzen direnez, haien desplazamendua kalkulatzea portaera definitu gabea da, helbide bera seinalatzen duten arren!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Zehaztu gabeko portaera
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `offset_from`-rako segurtasun kontratua onartu behar du.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Erakuslearen desplazamendua kalkulatzen du (`.offset(count as isize)`)-rako komenigarritasuna.
    ///
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Baldintza hauetakoren bat urratzen bada, emaitza zehaztu gabeko portaera da:
    ///
    /// * Hasierako erakusleak eta ondorioz lortutako erakusleak esleitutako objektu beraren amaieraren muga edo byte bat izan behar dute.
    /// Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// * Kalkulatutako desplazamenduak,**bytetan**, ezin du `isize` gainezka egin.
    ///
    /// * Desplazamenduak mugetan egoteak ezin du "wrapping around" helbideko espazioan oinarritu.Hau da, zehaztasun infinituaren baturak `usize` batean sartu behar du.
    ///
    /// Konpiladorea eta liburutegi estandarra, orokorrean, esleipenek inoiz ez duten tamaina bezainbeste lortzen saiatzen dira.
    /// Adibidez, `Vec` eta `Box` ek ziurtatzen dute inoiz ez dituztela `isize::MAX` byte baino gehiago esleitzen, beraz, `vec.as_ptr().add(vec.len())` beti da segurua.
    ///
    /// Plataforma gehienek funtsean ezin dute esleipen hori eraiki.
    /// Adibidez, 64 bit-eko plataforma ezagun batek ezin du inoiz 2 <sup>63</sup> byteko eskaerarik egin orri-taulako mugen ondorioz edo helbide-espazioa zatituta dagoelako.
    /// Hala ere, 32 biteko eta 16 biteko zenbait plataformek `isize::MAX` byte baino gehiagoko eskaera behar bezala egin dezakete Helbide Fisikoaren Luzapena bezalako gauzekin.
    ///
    /// Honela, esleitzaileetatik edo memoria mapatutako fitxategietatik zuzenean eskuratutako memoria * * handiegia izan daiteke * funtzio honekin kudeatzeko.
    ///
    /// Demagun horren ordez [`wrapping_add`] erabiltzea murrizketa horiek asetzeko zailak badira.
    /// Metodo honen abantaila bakarra konpiladorearen optimizazio oldarkorragoak ahalbidetzen ditu.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `offset`-rako segurtasun kontratua onartu behar du.
        unsafe { self.offset(count as isize) }
    }

    /// Erakusle baten desplazamendua kalkulatzen du (`.offset-en erosotasuna ((isize).wrapping_neg())`) gisa zenbatu.
    ///
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Baldintza hauetakoren bat urratzen bada, emaitza zehaztu gabeko portaera da:
    ///
    /// * Hasierako erakusleak eta ondorioz lortutako erakusleak esleitutako objektu beraren amaieraren muga edo byte bat izan behar dute.
    /// Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// * Kalkulatutako desplazamenduak ezin du `isize::MAX`**byte** baino gehiago izan.
    ///
    /// * Desplazamendua mugetan egoteak ezin du "wrapping around" helbide-espazioan oinarritu.Hau da, zehaztasun infinituaren baturak usize batean sartu behar du.
    ///
    /// Konpiladorea eta liburutegi estandarra, orokorrean, esleipenek inoiz ez duten tamaina bezainbeste lortzen saiatzen dira.
    /// Adibidez, `Vec` eta `Box` ek ziurtatzen dute inoiz ez dituztela `isize::MAX` byte baino gehiago esleitzen, beraz, `vec.as_ptr().add(vec.len()).sub(vec.len())` beti da segurua.
    ///
    /// Plataforma gehienek funtsean ezin dute esleipen hori eraiki.
    /// Adibidez, 64 bit-eko plataforma ezagun batek ezin du inoiz 2 <sup>63</sup> byteko eskaerarik egin orri-taulako mugen ondorioz edo helbide-espazioa zatituta dagoelako.
    /// Hala ere, 32 biteko eta 16 biteko zenbait plataformek `isize::MAX` byte baino gehiagoko eskaera behar bezala egin dezakete Helbide Fisikoaren Luzapena bezalako gauzekin.
    ///
    /// Honela, esleitzaileetatik edo memoria mapatutako fitxategietatik zuzenean eskuratutako memoria * * handiegia izan daiteke * funtzio honekin kudeatzeko.
    ///
    /// Demagun horren ordez [`wrapping_sub`] erabiltzea murrizketa horiek asetzeko zailak badira.
    /// Metodo honen abantaila bakarra konpiladorearen optimizazio oldarkorragoak ahalbidetzen ditu.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `offset`-rako segurtasun kontratua onartu behar du.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Erakuslearen desplazamendua kalkulatzen du biltzeko aritmetika erabiliz.
    /// (`.wrapping_offset(count as isize)`) rako erosotasuna
    ///
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Eragiketa hori bera beti da segurua, baina ez da lortzen den erakuslea erabiltzea.
    ///
    /// Lortutako erakusleak `self`-k seinalatzen duen esleitutako objektu berari atxikita jarraitzen du.
    /// Baliteke *ez* erabiltzea esleitutako beste objektu batera sartzeko.Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// Beste modu batera esanda, `let z = x.wrapping_add((y as usize) - (x as usize))`-k *ez* du `z` `y`-ren berdina bihurtzen, nahiz eta suposatzen dugun `T` `1` tamaina duela eta gainezkapenik ez dagoela: `z` oraindik `x` objektuari atxikita dagoela eta erreferentziarik gabeko jokabidea dela `x` eta `y` puntua esleitutako objektu berera.
    ///
    /// [`add`]-rekin alderatuta, metodo honek, funtsean, esleitutako objektu berdinean egoteko eskakizuna atzeratzen du: [`add`] berehalako portaera zehaztu gabea da objektuen mugak zeharkatzean;`wrapping_add`-k erakuslea sortzen du, baina zehaztu gabeko portaera dakar, erakusleari lotzen zaion objektuaren mugetatik kanpo dagoenean erreferentzia bat ezabatzen bada.
    /// [`add`] hobeto optimiza daiteke eta, beraz, hobe da errendimenduari dagokionez.
    ///
    /// Atzeratutako egiaztapenak erreferentziarik gabeko erakuslearen balioa soilik hartzen du kontuan, ez azken emaitza kalkulatzerakoan erabilitako bitarteko balioak.
    /// Adibidez, `x.wrapping_add(o).wrapping_sub(o)` beti `x` bezalakoa da.Beste modu batera esanda, esleitutako objektua utzi eta gero berriro sartzea baimenduta dago.
    ///
    /// Objektuen mugak zeharkatu behar badituzu, bota erakuslea zenbaki oso batera eta egin aritmetika bertan.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // Iteratu erakusle gordina erabiliz bi elementuren zatitan
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Begizta honek "1, 3, 5, " inprimatzen du
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Erakuslearen desplazamendua kalkulatzen du biltzeko aritmetika erabiliz.
    /// (`.wrapping_offset-erako erosotasuna ((isize).wrapping_neg())`) gisa kontatu
    ///
    /// `count` T unitateetan dago;Adibidez, 3ko `count` batek `3 * size_of::<T>()` byteko erakuslearen desplazamendua adierazten du.
    ///
    /// # Safety
    ///
    /// Eragiketa hori bera beti da segurua, baina ez da lortzen den erakuslea erabiltzea.
    ///
    /// Lortutako erakusleak `self`-k seinalatzen duen esleitutako objektu berari atxikita jarraitzen du.
    /// Baliteke *ez* erabiltzea esleitutako beste objektu batera sartzeko.Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
    ///
    /// Beste era batera esanda, `let z = x.wrapping_sub((x as usize) - (y as usize))`-k *ez* du `z` `y`-ren berdina bihurtzen, nahiz eta suposatzen dugun `T`-k `1` tamaina duela eta gainezkapenik ez dagoela: `z` oraindik `x` objektuari atxikita dagoela, eta erreferentziarik gabeko portaera zehaztu gabe `x` eta `y` puntua esleitutako objektu berera.
    ///
    /// [`sub`]-rekin alderatuta, metodo honek, funtsean, esleitutako objektu berdinean egoteko eskakizuna atzeratzen du: [`sub`] berehalako portaera zehaztu gabea da objektuen mugak zeharkatzean;`wrapping_sub`-k erakuslea sortzen du, baina zehaztu gabeko portaera dakar, erakusleari lotzen zaion objektuaren mugetatik kanpo dagoenean erreferentzia ezabatzen bada.
    /// [`sub`] hobeto optimiza daiteke eta, beraz, hobe da errendimenduari dagokionez.
    ///
    /// Atzeratutako egiaztapenak erreferentziarik gabeko erakuslearen balioa soilik hartzen du kontuan, ez azken emaitza kalkulatzerakoan erabilitako bitarteko balioak.
    /// Adibidez, `x.wrapping_add(o).wrapping_sub(o)` beti `x` bezalakoa da.Beste modu batera esanda, esleitutako objektua utzi eta gero berriro sartzea baimenduta dago.
    ///
    /// Objektuen mugak zeharkatu behar badituzu, bota erakuslea zenbaki oso batera eta egin aritmetika bertan.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // Iteratu erakusle gordin bat erabiliz (backwards) bi elementuren gehikuntzetan
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Begizta honek "5, 3, 1, " inprimatzen du
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Erakuslearen balioa `ptr` gisa ezartzen du.
    ///
    /// `self` tamaina gabeko mota bateko erakuslea (fat) bada, eragiketa honek erakuslearen zatian bakarrik eragingo du, eta tamaina motako (thin) erakusleek, aldiz, zeregin sinple baten efektu bera dute.
    ///
    /// Lortutako erakusleak `val`-ren jatorria izango du, hau da, gantz-erakusle batentzat, eragiketa hau semantikoki `val`-ren datu-erakuslearen balioa baina `self`-ren metadatuak dituen gantz-erakusle berria sortzea bezalakoa da.
    ///
    ///
    /// # Examples
    ///
    /// Funtzio hau batez ere gantz izan daitezkeen erakusleetan byte jakintsuen erakuslearen aritmetika baimentzeko erabilgarria da:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // "3" inprimatuko du
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SEGURTASUNA: erakusle mehea bada, eragiketa berdinak dira
        // zeregin soil batera.
        // Erakusle gantzaren kasuan, egungo gantzaren erakuslearen diseinua inplementatzean, erakusle horren lehen eremua beti da datuen erakuslea, eta hori ere esleitzen da.
        //
        unsafe { *thin = val };
        self
    }

    /// `self`-ren balioa irakurtzen du mugitu gabe.
    /// Honek memoria `self`-n aldatu gabe uzten du.
    ///
    /// Ikusi [`ptr::read`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak ``-rako segurtasun kontratua onartu behar du.
        unsafe { read(self) }
    }

    /// `self`-ren balioaren irakurketa aldakorra egiten du mugitu gabe.Honek memoria `self`-n aldatu gabe uzten du.
    ///
    /// Eragiketa lurrunkorrek I/O memorian jarduteko xedea dute, eta ziurtatuta dago konpiladoreak ez dituela berreskuratuko edo berriro antolatuko beste eragiketa lurrunkorren artean.
    ///
    ///
    /// Ikusi [`ptr::read_volatile`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `read_volatile`-rako segurtasun kontratua onartu behar du.
        unsafe { read_volatile(self) }
    }

    /// `self`-ren balioa irakurtzen du mugitu gabe.
    /// Honek memoria `self`-n aldatu gabe uzten du.
    ///
    /// `read` ez bezala, erakuslea lerrokatu gabe egon daiteke.
    ///
    /// Ikusi [`ptr::read_unaligned`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `read_unaligned`-rako segurtasun kontratua onartu behar du.
        unsafe { read_unaligned(self) }
    }

    /// `count * size_of<T>` byte-ak `self`-tik `dest`-ra kopiatzen ditu.
    /// Iturburua eta helmuga gainjarri daitezke.
    ///
    /// NOTE: honek [`ptr::copy`]-ren *argumentu ordena* bera du.
    ///
    /// Ikusi [`ptr::copy`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `copy`-rako segurtasun kontratua onartu behar du.
        unsafe { copy(self, dest, count) }
    }

    /// `count * size_of<T>` byte-ak `self`-tik `dest`-ra kopiatzen ditu.
    /// Baliteke iturburua eta helmuga *ez* gainjartzea.
    ///
    /// NOTE: honek [`ptr::copy_nonoverlapping`]-ren *argumentu ordena* bera du.
    ///
    /// Ikusi [`ptr::copy_nonoverlapping`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `copy_nonoverlapping`-rako segurtasun kontratua onartu behar du.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `count * size_of<T>` byte-ak `src`-tik `self`-ra kopiatzen ditu.
    /// Iturburua eta helmuga gainjarri daitezke.
    ///
    /// NOTE: honek [`ptr::copy`]-ren *aurkako* argumentu ordena du.
    ///
    /// Ikusi [`ptr::copy`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `copy`-rako segurtasun kontratua onartu behar du.
        unsafe { copy(src, self, count) }
    }

    /// `count * size_of<T>` byte-ak `src`-tik `self`-ra kopiatzen ditu.
    /// Baliteke iturburua eta helmuga *ez* gainjartzea.
    ///
    /// NOTE: honek [`ptr::copy_nonoverlapping`]-ren *aurkako* argumentu ordena du.
    ///
    /// Ikusi [`ptr::copy_nonoverlapping`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `copy_nonoverlapping`-rako segurtasun kontratua onartu behar du.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Puntuko balioaren suntsitzailea (baldin badago) exekutatzen du.
    ///
    /// Ikusi [`ptr::drop_in_place`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SEGURTASUNA: deitzaileak `drop_in_place`-rako segurtasun kontratua onartu behar du.
        unsafe { drop_in_place(self) }
    }

    /// Emandako balioarekin memoriaren kokapen bat gainidazten du balio zaharra irakurri edo bota gabe.
    ///
    ///
    /// Ikusi [`ptr::write`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `write`-rako segurtasun kontratua onartu behar du.
        unsafe { write(self, val) }
    }

    /// Memetset-a zehaztutako erakusleari deitzen dio, `count * size_of::<T>()` memoria byte ezarriz `self`-tik `val`-ra hasita.
    ///
    ///
    /// Ikusi [`ptr::write_bytes`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `write_bytes`-rako segurtasun kontratua onartu behar du.
        unsafe { write_bytes(self, val, count) }
    }

    /// Emandako balioarekin memoriaren kokapenaren idazketa lurrunkorra egiten du balio zaharra irakurri edo erori gabe.
    ///
    /// Eragiketa lurrunkorrek I/O memorian jarduteko xedea dute, eta ziurtatuta dago konpiladoreak ez dituela berreskuratuko edo berriro antolatuko beste eragiketa lurrunkorren artean.
    ///
    ///
    /// Ikusi [`ptr::write_volatile`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `write_volatile`-rako segurtasun kontratua onartu behar du.
        unsafe { write_volatile(self, val) }
    }

    /// Emandako balioarekin memoriaren kokapen bat gainidazten du balio zaharra irakurri edo bota gabe.
    ///
    ///
    /// `write` ez bezala, erakuslea lerrokatu gabe egon daiteke.
    ///
    /// Ikusi [`ptr::write_unaligned`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `write_unaligned`-rako segurtasun kontratua onartu behar du.
        unsafe { write_unaligned(self, val) }
    }

    /// `self`-ren balioa `src`-rekin ordezkatzen du, eta balio zaharra itzultzen du, bai jaitsi gabe.
    ///
    ///
    /// Ikusi [`ptr::replace`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `replace`-rako segurtasun kontratua onartu behar du.
        unsafe { replace(self, src) }
    }

    /// Balioak mota bereko bi kokapen aldagarritan trukatzen ditu, biak desinizializatu gabe.
    /// Gainjarri daitezke, bestela baliokidea den `mem::swap` ez bezala.
    ///
    /// Ikusi [`ptr::swap`] segurtasun arazoak eta adibideak lortzeko.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SEGURTASUNA: deitzaileak `swap`-rako segurtasun kontratua onartu behar du.
        unsafe { swap(self, with) }
    }

    /// Erakusleari aplikatu beharreko desplazamendua kalkulatzen du `align`-ra lerrokatuta egon dadin.
    ///
    /// Erakuslea lerrokatzea posible ez bada, inplementazioak `usize::MAX` itzultzen du.
    /// Zilegi da inplementazioak *beti*`usize::MAX` itzultzea.
    /// Zure algoritmoaren errendimendua hemengo konpentsazio erabilgarria lortzearen araberakoa izan daiteke, ez horren zuzentasuna.
    ///
    /// Desplazamendua `T` elementu kopuruetan adierazten da, eta ez byteetan.Itzulitako balioa `wrapping_add` metodoarekin erabil daiteke.
    ///
    /// Ez dago inolako bermerik erakuslea konpentsatzeak erakusleak seinalatzen duen esleipena gainezka egingo duenik edo gaindituko ez duenik.
    ///
    /// Deitzailearen esku dago itzulitako konpentsazioa lerrokatzea ez den beste termino guztietan zuzena dela ziurtatzea.
    ///
    /// # Panics
    ///
    /// panics funtzioa `align` bi potentzia ez bada.
    ///
    /// # Examples
    ///
    /// Aldameneko `u8` `u16` gisa sartzea
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // erakuslea `offset` bidez lerroka daitekeen bitartean, esleipenetik kanpora seinalatuko luke
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEGURTASUNA: `align` goiko 2 potentzia dela egiaztatu da
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Xerra gordinaren luzera itzultzen du.
    ///
    /// Itzulitako balioa **elementu** kopurua da, ez byte kopurua.
    ///
    /// Funtzio hau segurua da, nahiz eta xerra gordinak xerra erreferentzia batera bota ezin izan, erakuslea nulua edo lerrokatu gabea delako.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURTASUNA: segurua da `*const [T]` eta `FatPtr<T>` diseinu bera dutelako.
            // `std`-k soilik eman dezake berme hori.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Erakusle gordin bat zatiaren bufferrera itzultzen du.
    ///
    /// Hau `self` `*mut T`-ra igortzearen baliokidea da, baina mota gehiago segurua da.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Erakusle gordina elementu edo azpisail batera itzultzen du, mugen egiaztapena egin gabe.
    ///
    /// Metodo honi mugaz kanpoko indizearekin edo `self` erreferentzializatzerik ez dagoenean deitzea *[zehaztu gabeko portaera]* da, nahiz eta ondorioz erakuslea erabiltzen ez den.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEGURTASUNA: deitzaileak `self` erreferentziazina dela eta `index` mugagabea dela ziurtatzen du.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// `None` itzultzen du erakuslea nulua bada edo, bestela, partekatutako zatitxo bat itzultzen du `Some` bildutako balioari.
    /// [`as_ref`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Aldagai aldakorrari dagokionez, ikus [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak [valid] izan behar du `ptr.len() * mem::size_of::<T>()` byte askotan irakurtzeko, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
    ///
    ///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
    ///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.
    ///
    ///     * Erakusleak lerrokatuta egon behar du zero luzerako zatietan ere.
    ///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
    ///
    ///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
    ///
    /// * Xerraren `ptr.len() * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
    ///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memoria ez da mutatu behar (`UnsafeCell` barruan izan ezik).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// Ikus [`slice::from_raw_parts`][] ere.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURTASUNA: deitzaileak `as_uninit_slice`-rako segurtasun kontratua onartu behar du.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// `None` itzultzen du erakuslea nulua bada edo, bestela, zati bakarra itzultzen du `Some`-n bildutako balioari.
    /// [`as_mut`]-rekin alderatuta, horrek ez du balio hasieratu beharrik.
    ///
    /// Partekatutako konpartsa ikusteko [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Metodo honi deitzerakoan, ziurtatu behar duzu *bai* erakuslea NULL *dela* hau guztia egia dela:
    ///
    /// * Erakusleak [valid] izan behar du irakurtzeko eta idazteko `ptr.len() * mem::size_of::<T>()` byte askotan, eta behar bezala lerrokatuta egon behar du.Horrek bereziki esan nahi du:
    ///
    ///     * Xerra honen memoria barrutia esleitutako objektu bakar baten barruan egon behar da!
    ///       Xerra ezin da sekula esleitutako objektu anitzetan zehar hedatu.
    ///
    ///     * Erakusleak lerrokatuta egon behar du zero luzerako zatietan ere.
    ///     Horren arrazoi bat da enum diseinuaren optimizazioak erreferentziak (edozein luzeretako zatiak barne) lerrokatuta egotea eta nuluak ez izatea beste datu batzuetatik bereizteko.
    ///
    ///     X001 erabiliz zero luzerako xerretarako `data` gisa erabil daitekeen erakuslea lor dezakezu.
    ///
    /// * Xerraren `ptr.len() * mem::size_of::<T>()` tamaina osoa ez da `isize::MAX` baino handiagoa izan behar.
    ///   Ikusi [`pointer::offset`] ren segurtasun dokumentazioa.
    ///
    /// * Rust ren aliasing arauak betearazi behar dituzu, itzulitako `'a` bizitzan nahitaez aukeratzen baita eta ez du zertan datuen benetako bizitza islatzen.
    ///   Bereziki, bizitza osoan zehar, erakusleak seinalatzen duen memorian ezingo da beste edozein erakusleren bidez sartu (irakurri edo idatzi).
    ///
    /// Hori aplikatzen da metodo honen emaitza erabiltzen ez bada ere!
    ///
    /// Ikus [`slice::from_raw_parts_mut`][] ere.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURTASUNA: deitzaileak `as_uninit_slice_mut`-rako segurtasun kontratua onartu behar du.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Erakusleentzako berdintasuna
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}