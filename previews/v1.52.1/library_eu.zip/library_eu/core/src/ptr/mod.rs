//! Eskuz kudeatu memoria erakusle gordinen bidez.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Modulu honetako funtzio askok erakusle gordinak argumentu gisa hartzen dituzte eta haietatik irakurtzen edo idazten dute.Hau segurua izan dadin, erakusle hauek *baliozkoak* izan behar dute.
//! Erakusle batek balio duen ala ez erabiltzen den (irakurtzeko edo idazteko) eragiketaren eta sartzen den memoriaren neurriaren (hau da, zenbat byte dira read/written) araberakoa da.
//! Funtzio gehienek `*mut T` eta `* const T` erabiltzen dituzte balio bakarra lortzeko, kasu horretan dokumentazioak tamaina alde batera uzten du eta inplizituki `size_of::<T>()` byte direla suposatzen du.
//!
//! Baliagarritasunerako arau zehatzak oraindik ez daude zehaztuta.Une honetan ematen diren bermeak oso minimoak dira:
//!
//! * [null] erakuslea * ez da inoiz baliozkoa, ezta [size zero][zst] sarbideetarako ere.
//! * Erakuslea baliozkoa izan dadin, beharrezkoa da, baina ez da beti nahikoa, erakuslea *erreferentziazina* izatea: erakuslearen hasierako tamainako memoria tarteak esleitutako objektu bakar baten mugen barruan egon behar du.
//!
//! Kontuan izan Rust-n (stack-allocated) aldagai bakoitza esleitutako objektu bereizitzat hartzen dela.
//! * [size zero][zst]-ren eragiketetarako ere, erakusleak ez du banatutako memoriara seinalatu behar, hau da, banaketak bistaratzen ditu erakusleak zero tamainako eragiketetarako ere.
//! Hala ere, zero ez den zenbaki oso bat *literal* erakusle batera igortzeak balio du zero tamainako sarbideetarako, nahiz eta memoria batzuk helbide horretan egon eta banatu.
//! Hau zure esleitzaile propioa idazteari dagokio: zero tamainako objektuak esleitzea ez da oso gogorra.
//! Zero tamainako sarbideetarako balio duen erakuslea lortzeko modu kanonikoa [`NonNull::dangling`] da.
//! * Modulu honetako funtzioek egindako sarbide guztiak *ez-atomikoak* dira harien artean sinkronizatzeko erabiltzen den [atomic operations] zentzuan.
//! Horrek esan nahi du portaera definitu gabea dela hari desberdinetatik kokapen berera bi sarbide aldiberekoak egitea, sarbide biak memoriatik irakurtzen ez badira behintzat.
//! Kontuan izan honek [`read_volatile`] eta [`write_volatile`] esplizituki biltzen dituela: sarbide lurrunkorrak ezin dira hari arteko sinkronizaziorako erabili.
//! * Erakusle bati erreferentzia igortzearen emaitza baliozkoa da azpiko objektua zuzenean dagoenean eta memoria berera sartzeko erreferentziarik (erakusle gordinak soilik) erabiltzen ez den bitartean.
//!
//! Axioma hauek, erakuslearen aritmetika egiteko [`offset`] arretaz erabiltzearekin batera, nahikoa dira seguruak ez diren kodeetan gauza erabilgarri asko behar bezala ezartzeko.
//! Berme sendoagoak emango dira azkenean, [aliasing] arauak zehazten ari baitira.
//! Informazio gehiagorako, ikusi [book] eta [undefined behavior][ub]-ri eskainitako erreferentziako atala.
//!
//! ## Alignment
//!
//! Goian definitutako baliozko erakusle gordinak ez daude zertan behar bezala lerrokatuta (non "proper" lerrokatzea puntu motak definitzen duen, hau da, `*const T` `mem::align_of::<T>()`-rekin lerrokatuta egon behar da).
//! Hala ere, funtzio gehienek beren argumentuak behar bezala lerrokatuta egotea eskatzen dute eta baldintza hori esplizituki adieraziko dute dokumentazioan.
//! Honen salbuespen aipagarriak dira [`read_unaligned`] eta [`write_unaligned`].
//!
//! Funtzio batek lerrokatze egokia behar duenean, sarbideak 0 tamaina badu ere, hau da, memoria benetan ukitzen ez bada ere.Demagun [`NonNull::dangling`] erabiltzea horrelakoetan.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Puntuko balioaren suntsitzailea (baldin badago) exekutatzen du.
///
/// Semantikoki [`ptr::read`] deitzearen eta emaitza baztertzearen parekoa da, baina abantaila hauek ditu:
///
/// * * Beharrezkoa da `drop_in_place` erabiltzea tamaina gabeko motak trait objektuak uzteko, ezin baitira pilara irakurri eta normalean jaitsi.
///
/// * Optimizatzailearentzat errazagoa da [`ptr::read`] bidez egitea eskuz esleitutako memoria (adibidez, `Box`/`Rc`/`Vec` ren inplementazioetan) uztean, konpiladoreak ez baitu frogatu behar kopia ezabatzeko soinua dela.
///
///
/// * [pinned] datuak uzteko erabil daiteke `T` `repr(packed)` ez denean (ainguratutako datuak ezin dira mugitu erori aurretik).
///
/// Lerrokatu gabeko balioak ezin dira bere lekuan erori, lehenik [`ptr::read_unaligned`] erabiliz kokatutako lerrokadura batera kopiatu behar dira.Paketatutako egituretarako, mugimendu hau automatikoki egiten du konpiladoreak.
/// Horrek esan nahi du paketatutako egituren eremuak ez direla tokian bertan uzten.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `to_drop` irakurtzeko zein idazteko [valid] izan behar du.
///
/// * `to_drop` behar bezala lerrokatuta egon behar du.
///
/// * `to_drop` puntuak balioa jaregiteko balio behar du, eta horrek esan nahi du aldaera osagarriak mantendu behar dituela, hau motaren araberakoa da.
///
/// Gainera, `T` [`Copy`] ez bada, `drop_in_place` deitu ondoren apuntatutako balioa erabiltzeak zehaztu gabeko portaera sor dezake.Kontuan izan `*to_drop = foo` erabilera gisa kontatzen dela, balioa berriro jaistea eragingo duelako.
/// [`write()`] erabil daiteke datuak gainidazteko, bertan behera uztea eragin gabe.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kendu azken elementua vector batetik eskuz:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Lortu erakusle gordin bat `v`-ko azken elementuraino.
///     let ptr = &mut v[1] as *mut _;
///     // Laburtu `v` azken elementua ez erortzeko.
///     // Hori egiten dugu lehenik eta behin, arazoak ekiditeko panics azpitik dagoen `drop_in_place`.
///     v.set_len(1);
///     // `drop_in_place` deirik egin gabe, azken elementua ez litzateke sekula botako, eta kudeatzen duen memoria filtratuko litzateke.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Ziurtatu azkeneko elementua bota dela.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Kontuan izan konpiladoreak kopia hau automatikoki egiten duela paketatutako egiturak uztean, hau da, normalean ez duzu horrelako arazoez kezkatu behar `drop_in_place` eskuz deitzen ez baduzu.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Hemen kodea ez du axola, hau konpiladorearen benetako kola eraginez ordezkatzen da.
    //

    // SEGURTASUNA: ikusi goiko iruzkina
    unsafe { drop_in_place(to_drop) }
}

/// Erakusle gordin nulua sortzen du.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Erakusle gordin aldakor nulua sortzen du.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Eskuzko inplementazioa beharrezkoa da `T: Clone` lotua ekiditeko.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Eskuzko inplementazioa beharrezkoa da `T: Copy` lotua ekiditeko.
impl<T> Copy for FatPtr<T> {}

/// Xerra gordin bat osatzen du erakusle batetik eta luzera batetik.
///
/// `len` argumentua **elementu** kopurua da, ez byte kopurua.
///
/// Funtzio hau segurua da, baina benetan itzultzeko balioa erabiltzea ez da segurua.
/// Ikusi [`slice::from_raw_parts`] ren dokumentazioa zatien segurtasun baldintzak lortzeko.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // sortu xerra erakuslea lehen elementura erakuslearekin hasten zarenean
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEGURTASUNA: `Repr` sindikatutik balioa sartzea segurua da * const [T] geroztik
        //
        // eta FatPtr-ek memoria diseinu berdinak dituzte.std k bakarrik egin dezake berme hori.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// [`slice_from_raw_parts`]-ren funtzionalitate bera betetzen du, alda daitekeen zatitxo gordina itzultzen dela salbu, zati aldaezin gordinaren aurrean.
///
///
/// Ikusi [`slice_from_raw_parts`] dokumentazioa xehetasun gehiagorako.
///
/// Funtzio hau segurua da, baina benetan itzultzeko balioa erabiltzea ez da segurua.
/// Ikusi [`slice::from_raw_parts_mut`] ren dokumentazioa zatien segurtasun baldintzak lortzeko.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // esleitu balio bat zatiko indize batean
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEGURTASUNA: `Repr` sindikatutik balioak atzitzea segurua da * mut [T] geroztik
        // eta FatPtr-ek memoria diseinu berdinak dituzte
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Balioak mota bereko bi kokapen aldagarritan trukatzen ditu, biak desinizializatu gabe.
///
/// Baina hurrengo bi salbuespenetarako, funtzio hau [`mem::swap`] ren semantikoki baliokidea da:
///
///
/// * Erreferentziaren ordez erakusle gordinetan funtzionatzen du.
/// Erreferentziak eskuragarri daudenean, [`mem::swap`] hobetsi beharko litzateke.
///
/// * Seinalatutako bi balioak gainjarri daitezke.
/// Balioak gainjartzen badira, `x`-ren memoriaren eskualde gainjarria erabiliko da.
/// Hori frogatzen da beheko bigarren adibidean.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `x` eta `y` biek [valid] izan behar dute irakurtzeko zein idazteko.
///
/// * `x` eta `y` biak behar bezala lerrokatuta egon behar dute.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleek NULL ez direnak eta behar bezala lerrokatuta egon behar dutela.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Gainjartzen ez diren bi eskualde trukatzea:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // hau `array[0..2]` da
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // hau `array[2..4]` da
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Bi eskualde gainjarri trukatzea:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // hau `array[0..3]` da
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // hau `array[1..4]` da
///
/// unsafe {
///     ptr::swap(x, y);
///     // Xerraren `1..3` indizeak `x` eta `y` arteko gainjartzen dira.
///     // Emaitza arrazoiak `[2, 3]` izatea lortuko lukete, beraz, `0..3` indizeak `[1, 2, 3]` dira (`y` `swap` baino lehenagokoa da);edo `[0, 1]` izan daitezen, `1..4` indizeak `[0, 1, 2]` izan daitezen (`x` `swap` baino lehenago bat datozenak).
/////
///     // Ezarpen hau azken aukera hau egiteko definitzen da.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Eman gure buruari lan egiteko hutsune batzuk.
    // Ez dugu zertxobait kezkatu behar: `MaybeUninit`-k ez du ezer egiten erortzean.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Egin trukea SEGURTASUNA: deitzaileak `x` eta `y` idazketetarako baliozkoak direla eta behar bezala lerrokatuta daudela bermatu behar du.
    // `tmp` ezin da `x` edo `y` gainjarri, `tmp` pilan esleitutako objektu bereizi gisa besterik ez delako jarri.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` eta `y` gainjarri daitezke
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `count * size_of::<T>()` byte-ak trukatzen ditu memoriaren bi eskualdeen artean `x` eta `y`-tik hasita.
/// Bi eskualdeek *ez* gainjarri behar dute.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `x` eta `y` biek [valid] izan behar dute `count-en irakurri eta idazteko *
///   tamaina_ren: :<T>() `byte.
///
/// * `x` eta `y` biak behar bezala lerrokatuta egon behar dute.
///
/// * `x`-n hasten den memoriaren eskualdea `count tamaina batekin *
///   tamaina_ren: :<T>() `byteek *ez dute* gainjarri behar tamaina bereko `y`-tik hasitako memoriaren eskualdearekin.
///
/// Kontuan izan modu eraginkorrean kopiatutako tamaina (`count * size_of: :<T>()`) `0` da, erakusleek NULL ez direnak eta behar bezala lerrokatuta egon behar dute.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEGURTASUNA: deitzaileak `x` eta `y` direla ziurtatu behar du
    // idazketetarako baliozkoa eta behar bezala lerrokatuta.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Beheko blokearen optimizazioa baino txikiagoak diren motetarako, trukatu zuzenean kodegen ezkorra saihesteko.
    //
    if mem::size_of::<T>() < 32 {
        // SEGURTASUNA: deitzaileak `x` eta `y` baliozkoak direla bermatu behar du
        // idazketetarako, behar bezala lerrokatuta eta ez gainjartzeko.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEGURTASUNA: deitzaileak `swap_nonoverlapping`-rako segurtasun kontratua onartu behar du.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Hemen planteamendua da simd erabiltzea x&y modu eraginkorrean trukatzeko.
    // Probak agerian uzten du 32 byte edo 64 byte aldi berean trukatzea dela eraginkorrena Intel Haswell E prozesadoreentzat.
    // LLVM optimizatzeko gai da egitura bati #[repr(simd)] ematen badiogu, nahiz eta egitura hori zuzenean erabiltzen ez dugun.
    //
    //
    // FIXME repr(simd) hautsita emscripten eta redox-en
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Begira ezazu x&y bidez, kopia itzazu `Block` aldi bakoitzean Optimizatzaileak begizta guztiz desegin beharko luke mota gehienetarako NB
    // Ezin dugu for begizta erabili `range` impl-ek `mem::swap` errekurtsiboki deitzen baitu
    //
    let mut i = 0;
    while i + block_size <= len {
        // Sortu hasierarik gabeko memoria hutsune gisa. `t` deklaratzeak pila lerrokatzea saihesten du begizta hau erabiltzen ez denean
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEGURTASUNA: `i < len` gisa eta deitzaileak `x` eta `y` baliozkoak direla bermatu behar du.
        // `len` byteetarako, `x + i` eta `y + i` baliozko helbideak izan behar dira, eta horrek `add` rentzako segurtasun kontratua betetzen du.
        //
        // Halaber, deitzaileak `x` eta `y` baliozkoak direla bermatu behar du idazketetarako, behar bezala lerrokatuta egoteko eta ez gainjartzeko, eta horrek `copy_nonoverlapping` ren segurtasun kontratua betetzen du.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Trukatu x&y byte bloke bat, t aldi baterako buffer gisa erabiliz. Hau SIMD eragiketa eraginkorretan optimizatu beharko litzateke eskuragarri dagoen tokian.
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Trukatu gainerako byte guztiak
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEGURTASUNA: ikusi aurreko segurtasun iruzkina.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src` mugitzen du `dst` zorrotzera, aurreko `dst` balioa itzuliz.
///
/// Ez da balio bat ere ez jaisten.
///
/// Funtzio hau [`mem::replace`] ren semantikoki baliokidea da erreferentzien ordez erakusle gordinetan funtzionatzen duela izan ezik.
/// Erreferentziak eskuragarri daudenean, [`mem::replace`] hobetsi beharko litzateke.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `dst` irakurtzeko zein idazteko [valid] izan behar du.
///
/// * `dst` behar bezala lerrokatuta egon behar du.
///
/// * `dst` `T` motako behar bezala hasierako balioa seinalatu behar du.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` efektu bera izango luke segurtasunik gabeko blokea eskatu gabe.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEGURTASUNA: deitzaileak `dst` izateko balio duela ziurtatu behar du
    // erreferentzia aldakor batera igorri (idazkeretarako balio du, lerrokatu, hasieratu) eta ezin da `src` gainjarri `dst`-k esleitutako objektu desberdin bat seinalatu behar baitu.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ezin da gainjarri
    }
    src
}

/// `src`-ren balioa irakurtzen du mugitu gabe.Honek memoria `src`-n aldatu gabe uzten du.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `src` irakurtzeko [valid] izan behar du.
///
/// * `src` behar bezala lerrokatuta egon behar du.Erabili [`read_unaligned`] hala ez bada.
///
/// * `src` `T` motako behar bezala hasierako balioa seinalatu behar du.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] eskuz inplementatu:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Sortu bitaren balioaren kopia `a`-n `tmp`-n.
///         let tmp = ptr::read(a);
///
///         // Puntu honetatik irteteak (esplizituki itzuliz edo panics-ri funtzio bati deituz) `tmp`-en balioa jaistea eragingo luke `a`-k balio bera aipatzen duen bitartean.
///         // Horrek zehaztu gabeko portaera sor dezake `T` `Copy` ez bada.
/////
/////
///
///         // Sortu bitaren balioaren kopia `b`-n `a`-n.
///         // Hori segurua da, alda daitezkeen erreferentziek ezin dutelako ezizenik sortu
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Goian bezala, hemendik irteteak zehaztu gabeko portaera sor dezake, balio bera aipatzen baita `a` eta `b`.
/////
///
///         // Mugitu `tmp` `b`-ra.
///         ptr::write(b, tmp);
///
///         // `tmp` mugitu egin da (`write` bere bigarren argumentuaren jabe da), beraz, ez da ezer inplizituki botatzen hemen.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Itzulitako Balioaren jabetza
///
/// `read` `T` ren bit-kopia sortzen du, `T` [`Copy`] den ala ez kontuan hartu gabe.
/// `T` [`Copy`] ez bada, itzultzen den balioa eta `*src`-ren balioa erabiliz gero, memoriaren segurtasuna urratu daiteke.
/// Kontuan izan `*src` ri esleitzea erabilera gisa kontatzen dela, `* src`-n balioa jaisten saiatuko delako.
///
/// [`write()`] erabil daiteke datuak gainidazteko, bertan behera uztea eragin gabe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` orain `s`-ren azpiko memoria bera seinalatzen du.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2` ri esleitzeak jatorrizko balioa jaistea eragiten du.
///     // Puntu honetatik harago, `s` ez da gehiago erabili behar, azpiko memoria askatu baita.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s` ri esleitzeak balio zaharra berriro jaistea eragingo luke, zehaztu gabeko portaera sortuz.
/////
///     // s= String::from("bar");//ERROREA
///
///     // `ptr::write` balio bat gainidazteko erabil daiteke hura erori gabe.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURTASUNA: deitzaileak `src` irakurketetarako balio duela bermatu behar du.
    // `src` Ezin da `tmp` gainjarri `tmp` pilan esleitutako objektu bereizi gisa jarri delako.
    //
    //
    // Gainera, balio egokia duen `tmp`-n idatzi dugunez, behar bezala hasieratuta egongo dela ziurtatzen da.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// `src`-ren balioa irakurtzen du mugitu gabe.Honek memoria `src`-n aldatu gabe uzten du.
///
/// [`read`] ez bezala, `read_unaligned` lerrokatu gabeko erakusleekin funtzionatzen du.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `src` irakurtzeko [valid] izan behar du.
///
/// * `src` `T` motako behar bezala hasierako balioa seinalatu behar du.
///
/// [`read`]-k bezala, `read_unaligned`-k `T`-ren kopia bit bat sortzen du, `T` [`Copy`] den ala ez kontuan hartu gabe.
/// `T` ez bada [`Copy`], itzulitako balioa zein `*src`-ren balioa erabiliz [violate memory safety][read-ownership] erabil daiteke.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela izan behar.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` egituren gainean
///
/// Gaur egun ezinezkoa da egitura paketatu gabeko lerrokatu gabeko eremuetarako erakusleak gordinik sortzea.
///
/// `&packed.unaligned as *const FieldType` bezalako adierazpen batekin `unaligned` egit eremu batera erakusle gordina sortzen saiatzeak lerrokatu gabeko erreferentzia tarteko bat sortzen du hori erakusle gordin bihurtu aurretik.
///
/// Erreferentzia hori aldi baterako eta berehala igortzeak ez du inolako garrantzirik, konpiladoreak beti espero baitu erreferentziak behar bezala lerrokatuta egotea.
/// Ondorioz, `&packed.unaligned as *const FieldType` erabiltzeak berehalako* definitu gabeko portaera * eragiten du zure programan.
///
/// Zer ez egin eta hau `read_unaligned`-rekin erlazionatzen denaren adibidea da:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hemen lerrokatuta ez dagoen 32 biteko zenbaki oso baten helbidea hartzen saiatzen gara.
///     let unaligned =
///         // Lerrokatu gabeko aldi baterako erreferentzia sortzen da eta horrek portaera definitu gabea eragiten du, erreferentzia erabiltzen den edo ez kontuan hartu gabe.
/////
///         &packed.unaligned
///         // Erakusle gordin batera igotzeak ez du laguntzen;akatsa jadanik gertatu zen.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Hala ere, `packed.unaligned`-rekin lerrokatu gabeko eremuak zuzenean sartzea segurua da.
///
///
///
///
///
///
// FIXME: Eguneratu dokumentuak RFC #2582 eta lagunen emaitzen arabera.
/// # Examples
///
/// Irakurri erabileren balio bat byte buffer batetik:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURTASUNA: deitzaileak `src` irakurketetarako balio duela bermatu behar du.
    // `src` Ezin da `tmp` gainjarri `tmp` pilan esleitutako objektu bereizi gisa jarri delako.
    //
    //
    // Gainera, balio egokia duen `tmp`-n idatzi dugunez, behar bezala hasieratuta egongo dela ziurtatzen da.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Emandako balioarekin memoriaren kokapen bat gainidazten du balio zaharra irakurri edo bota gabe.
///
/// `write` ez du `dst` ren edukia askatzen.
/// Hau segurua da, baina esleipenak edo baliabideak ihes egin ditzake, beraz, kontuz ibili behar da eroritako objektu bat ez idazteko.
///
///
/// Gainera, ez du `src` erortzen.Semantikoki, `src` `dst`-k adierazten duen kokapenera eramaten da.
///
/// Hau egokia da hasierarik gabeko memoria hasieratzeko edo aurretik [`read`]-tik sortutako memoria gainidazteko.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `dst` [valid] izan behar du idazketetarako.
///
/// * `dst` behar bezala lerrokatuta egon behar du.Erabili [`write_unaligned`] hala ez bada.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] eskuz inplementatu:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Sortu bitaren balioaren kopia `a`-n `tmp`-n.
///         let tmp = ptr::read(a);
///
///         // Puntu honetatik irteteak (esplizituki itzuliz edo panics-ri funtzio bati deituz) `tmp`-en balioa jaistea eragingo luke `a`-k balio bera aipatzen duen bitartean.
///         // Horrek zehaztu gabeko portaera sor dezake `T` `Copy` ez bada.
/////
/////
///
///         // Sortu bitaren balioaren kopia `b`-n `a`-n.
///         // Hori segurua da, alda daitezkeen erreferentziek ezin dutelako ezizenik sortu
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Goian bezala, hemendik irteteak zehaztu gabeko portaera sor dezake, balio bera aipatzen baita `a` eta `b`.
/////
///
///         // Mugitu `tmp` `b`-ra.
///         ptr::write(b, tmp);
///
///         // `tmp` mugitu egin da (`write` bere bigarren argumentuaren jabe da), beraz, ez da ezer inplizituki botatzen hemen.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Intrintsekoei zuzenean deitzen diegu sortutako kodean funtzio deiak ekiditeko `intrinsics::copy_nonoverlapping` biltzeko funtzioa baita.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEGURTASUNA: deitzaileak `dst` idazketetarako balio duela bermatu behar du.
    // `dst` Ezin da `src` gainjarri, deitzaileak `dst` ra sarbide aldakorra duelako `src` funtzio honen jabea den bitartean.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Emandako balioarekin memoriaren kokapen bat gainidazten du balio zaharra irakurri edo bota gabe.
///
/// [`write()`] ez bezala, erakuslea lerrokatu gabe egon daiteke.
///
/// `write_unaligned` ez du `dst` ren edukia askatzen.Hau segurua da, baina esleipenak edo baliabideak ihes egin ditzake, beraz, kontuz ibili behar da eroritako objektu bat ez idazteko.
///
/// Gainera, ez du `src` erortzen.Semantikoki, `src` `dst`-k adierazten duen kokapenera eramaten da.
///
/// Hau egokia da hasierarik gabeko memoria hasieratzeko edo aurretik [`read_unaligned`]-rekin irakurritako memoria gainidazteko.
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `dst` [valid] izan behar du idazketetarako.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela izan behar.
///
/// [valid]: self#safety
///
/// ## `packed` egituren gainean
///
/// Gaur egun ezinezkoa da egitura paketatu gabeko lerrokatu gabeko eremuetarako erakusleak gordinik sortzea.
///
/// `&packed.unaligned as *const FieldType` bezalako adierazpen batekin `unaligned` egit eremu batera erakusle gordina sortzen saiatzeak lerrokatu gabeko erreferentzia tarteko bat sortzen du hori erakusle gordin bihurtu aurretik.
///
/// Erreferentzia hori aldi baterako eta berehala igortzeak ez du inolako garrantzirik, konpiladoreak beti espero baitu erreferentziak behar bezala lerrokatuta egotea.
/// Ondorioz, `&packed.unaligned as *const FieldType` erabiltzeak berehalako* definitu gabeko portaera * eragiten du zure programan.
///
/// Zer ez egin eta `write_unaligned`-rekin duen loturaren adibidea da:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hemen lerrokatuta ez dagoen 32 biteko zenbaki oso baten helbidea hartzen saiatzen gara.
///     let unaligned =
///         // Lerrokatu gabeko aldi baterako erreferentzia sortzen da eta horrek portaera definitu gabea eragiten du, erreferentzia erabiltzen den edo ez kontuan hartu gabe.
/////
///         &mut packed.unaligned
///         // Erakusle gordin batera igotzeak ez du laguntzen;akatsa jadanik gertatu zen.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Hala ere, `packed.unaligned`-rekin lerrokatu gabeko eremuak zuzenean sartzea segurua da.
///
///
///
///
///
///
///
///
///
// FIXME: Eguneratu dokumentuak RFC #2582 eta lagunen emaitzen arabera.
/// # Examples
///
/// Idatzi usize balio bat byte buffer batean:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEGURTASUNA: deitzaileak `dst` idazketetarako balio duela bermatu behar du.
    // `dst` Ezin da `src` gainjarri, deitzaileak `dst` ra sarbide aldakorra duelako `src` funtzio honen jabea den bitartean.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Berezkoari zuzenean deitzen diogu sortutako kodean funtzio deiak ekiditeko.
        intrinsics::forget(src);
    }
}

/// `src`-ren balioaren irakurketa aldakorra egiten du mugitu gabe.Honek memoria `src`-n aldatu gabe uzten du.
///
/// Eragiketa lurrunkorrek I/O memorian jarduteko xedea dute, eta ziurtatuta dago konpiladoreak ez dituela berreskuratuko edo berriro antolatuko beste eragiketa lurrunkorren artean.
///
/// # Notes
///
/// Rust-k ez du gaur egun zorrozki eta formalki zehaztutako memoria eredurik, beraz, "volatile"-k hemen esan nahi duenaren semantika zehatza aldatu egin daiteke denboran zehar.
/// Hori esanda, semantika ia beti [C11's definition of volatile][c11]-ren antzekoa izango da.
///
/// Konpiladoreak ez luke memoria aldakorreko eragiketen ordena erlatiboa edo kopurua aldatu behar.
/// Hala ere, zero tamainako moten memoria eragiketa aldakorrak (adibidez, zero tamainako mota bat `read_volatile`-era pasatzen badira) ez dira bistak eta ez ikusi egin daiteke.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `src` irakurtzeko [valid] izan behar du.
///
/// * `src` behar bezala lerrokatuta egon behar du.
///
/// * `src` `T` motako behar bezala hasierako balioa seinalatu behar du.
///
/// [`read`]-k bezala, `read_volatile`-k `T`-ren kopia bit bat sortzen du, `T` [`Copy`] den ala ez kontuan hartu gabe.
/// `T` ez bada [`Copy`], itzulitako balioa zein `*src`-ren balioa erabiliz [violate memory safety][read-ownership] erabil daiteke.
/// Hala eta guztiz ere, [ez 'Kopiatu] motak memoria lurrunkorrean gordetzea ia ez da zuzena.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// C-n bezala, eragiketa bat lurrunkorra izateak ez du inolako loturarik hari anitzetatik aldi berean sartzea dakarten galderetan.Sarbide lurrunkorrek atomikorik gabeko sarbideen antzera jokatzen dute alde horretatik.
///
/// Bereziki, `read_volatile` baten eta kokapen berdinean idazteko edozein eragiketen arteko lasterketa zehaztu gabeko portaera da.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ez izutzen kodegen inpaktua txikiagoa izan dadin.
        abort();
    }
    // SEGURTASUNA: deitzaileak `volatile_load`-rako segurtasun kontratua onartu behar du.
    unsafe { intrinsics::volatile_load(src) }
}

/// Emandako balioarekin memoriaren kokapenaren idazketa lurrunkorra egiten du balio zaharra irakurri edo erori gabe.
///
/// Eragiketa lurrunkorrek I/O memorian jarduteko xedea dute, eta ziurtatuta dago konpiladoreak ez dituela berreskuratuko edo berriro antolatuko beste eragiketa lurrunkorren artean.
///
/// `write_volatile` ez du `dst` ren edukia askatzen.Hau segurua da, baina esleipenak edo baliabideak ihes egin ditzake, beraz, kontuz ibili behar da eroritako objektu bat ez idazteko.
///
/// Gainera, ez du `src` erortzen.Semantikoki, `src` `dst`-k adierazten duen kokapenera eramaten da.
///
/// # Notes
///
/// Rust-k ez du gaur egun zorrozki eta formalki zehaztutako memoria eredurik, beraz, "volatile"-k hemen esan nahi duenaren semantika zehatza aldatu egin daiteke denboran zehar.
/// Hori esanda, semantika ia beti [C11's definition of volatile][c11]-ren antzekoa izango da.
///
/// Konpiladoreak ez luke memoria aldakorreko eragiketen ordena erlatiboa edo kopurua aldatu behar.
/// Hala ere, zero tamainako moten memoria eragiketa aldakorrak (adibidez, zero tamainako mota bat `write_volatile`-era pasatzen badira) ez dira bistak eta ez ikusi egin daiteke.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `dst` [valid] izan behar du idazketetarako.
///
/// * `dst` behar bezala lerrokatuta egon behar du.
///
/// Kontuan izan `T`-k `0` tamaina badu ere, erakusleak NULL ez dela eta behar bezala lerrokatuta egon behar duela.
///
/// [valid]: self#safety
///
/// C-n bezala, eragiketa bat lurrunkorra izateak ez du inolako loturarik hari anitzetatik aldi berean sartzea dakarten galderetan.Sarbide lurrunkorrek atomikorik gabeko sarbideen antzera jokatzen dute alde horretatik.
///
/// Bereziki, `write_volatile` baten eta beste edozein eragiketen arteko lasterketa (irakurtzea edo idaztea) kokapen berean zehaztu gabeko portaera da.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ez izutzen kodegen inpaktua txikiagoa izan dadin.
        abort();
    }
    // SEGURTASUNA: deitzaileak `volatile_store`-rako segurtasun kontratua onartu behar du.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Lerrokatu erakuslea `p`.
///
/// Kalkulatu `p` erakusleari aplikatu behar zaion desplazamendua (`stride` urratsaren elementuen arabera) `p` erakuslea `a`-ra lerrokatuta egon dadin.
///
/// Note: Ezarpen hau arretaz egokitu da panic ez izateko.UB da horretarako panic.
/// Hemen egin daitekeen benetako aldaketa bakarra `INV_TABLE_MOD_16` eta lotutako konstanteen aldaketa da.
///
/// Noizbait bi-potentzia ez den `a`-ekin berezkoari deitzea posible izatea erabakitzen badugu, zuhurragoa izango da inplementazio inozo batera aldatzea aldaketa hori egokitzeko egokitzen saiatzea baino.
///
///
/// Edozein zalantza@nagisa helbidera jo behar da.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Intrintseko hauen erabilera zuzenak kodegena nabarmen hobetzen du opt mailan <=
    // 1, non eragiketa hauen metodoaren bertsioak ez dauden.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Kalkulatu `x` moduluaren `m` moduluaren alderantzizko modulazio biderkatzailea.
    ///
    /// Ezarpen hau `align_offset`-era egokituta dago eta honako baldintza hauek ditu:
    ///
    /// * `m` bi-boterea da;
    /// * `x < m`; (`x ≥ m` bada, pasa `x % m` ordez)
    ///
    /// Funtzio hau ezartzea ez da panic.Inoiz.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Alderantzizko taula modular biderkatzailea modulua 2⁴=16.
        ///
        /// Kontuan izan, taula honek ez dituela alderantzizkoa ez den balioak (hau da, `0⁻¹ mod 16`, `2⁻¹ mod 16`, etab.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` xede duen modulua.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURTASUNA: `m`-k bi potentzia izan behar du, beraz zero ez dena.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // "up" errepikatzen dugu formula hau erabiliz:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // 2²ⁿ ≥ m arte.Ondoren, nahi dugun `m` era murriztu dezakegu emaitza `mod m` hartuta.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Kontuan izan hemen biltzeko eragiketak nahita erabiltzen ditugula-jatorrizko formulak, adibidez, `mod n` kenketa erabiltzen du.
                // Guztiz ondo dago `mod usize::MAX` egitea, baina azkenean `mod n` emaitza hartzen dugulako.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURTASUNA: `a` biren potentzia da, beraz, ez da zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kasua `-p (mod a)` bidez sinpleago kalkula daiteke, baina hori eginez gero LLVMk `lea` bezalako argibideak hautatzeko gaitasuna galarazten du.Horren ordez kalkulatzen dugu
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // horrek eragiketak banatzen ditu kargaren inguruan, baina `and` nahikoa ezkortuz LLVMk ezagutzen dituen optimizazio desberdinak erabili ahal izateko.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Dagoeneko lerrokatuta.Bai!
        return 0;
    } else if stride == 0 {
        // Erakuslea lerrokatuta ez badago eta elementua zero tamainakoa bada, orduan ez du elementu kopuru batek inoiz lerrokatuko erakuslea.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEGURTASUNA: a biren potentzia da, beraz, zero ez dena.stride==0 kasu gainetik maneiatzen da.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEGURTASUNA: gcdpow-k goi-muga du, gehienez ere, usize bateko bit kopurua.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEGURTASUNA: gcd beti 1 edo handiagoa da.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch honek kongruentzia-ekuazio lineal hau ebazten du:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hona hemen erakuslearen balioa, `s`, `T`-ren urratsa, `o` desplazamendua `T`-n eta `a`, eskatutako lerrokadura.
        //
        // `g = gcd(a, s)`-rekin eta `p` `g`-rekin ere zatigarria dela baieztatzen duen aurreko baldintzarekin, `a' = a/g`, `s' = s/g`, `p' = p/g` adieraz ditzakegu, orduan hau baliokidea bihurtzen da:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Lehenengo terminoa "the relative alignment of `p` to `a`" da (`g` zatituta), bigarren terminoa "how does incrementing `p` by `s` bytes change the relative alignment of `p`" da (berriro `g` zatituta).
        //
        // `g` bidez zatitzea beharrezkoa da alderantziz ongi osatua egon dadin `a` eta `s` ez badira koprimarrak.
        //
        // Gainera, irtenbide honek sortzen duen emaitza ez da "minimal", beraz, beharrezkoa da emaitza `o mod lcm(s, a)` hartzea.`lcm(s, a)` ordezka dezakegu `a'` batekin.
        //
        //
        //
        //
        //

        // SEGURTASUNA: `gcdpow`-k goi-muga ez du `a`-ko amaierako 0-bit kopurua baino handiagoa.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEGURTASUNA: `a2` zero ez da.`a` `gcdpow` arabera aldatzeak ezin du ezarritako bitetako bat aldatu
        // `a`-n (horietako bat zehazki).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEGURTASUNA: `gcdpow`-k goi-muga ez du `a`-ko amaierako 0-bit kopurua baino handiagoa.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEGURTASUNA: `gcdpow`-k goiko muga ez du 0 bit-eko amaierako kopurua baino handiagoa
        // `a`.
        // Gainera, kenketak ezin du gainezka egin, `a2 = a >> gcdpow` beti `(p % a) >> gcdpow` baino zorrotzagoa izango baita.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEGURTASUNA: `a2` bi potentzia da, goian frogatu den bezala.`s2` `a2` baino txikiagoa da
        // `(s % a) >> gcdpow` `a >> gcdpow` baino txikiagoa delako.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ezin da batere lerrokatu.
    usize::MAX
}

/// Berdintasunerako erakusle gordinak alderatzen ditu.
///
/// `==` operadorea erabiltzearen berdina da, baina ez da hain generikoa:
/// argudioek `*const T` erakusle gordinak izan behar dute, ez `PartialEq` inplementatzen duen ezer.
///
/// Honek `&T` erreferentziak (inplizituki `*const T`-era behartzen dituenak) bere helbidearen arabera alderatzeko balio dutenak alderatu beharrean (hau da, `PartialEq for &T` inplementazioak egiten duena) konparatzeko erabil daiteke.
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Xerra ere luzeraren arabera alderatzen da (koipe erakusleak):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits ere inplementatzen dira alderatuta:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Erakusleek helbide berdinak dituzte.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objektuek helbide berdinak dituzte, baina `Trait`-k inplementazio desberdinak ditu.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Erreferentzia `*const u8` bihurtuz helbideen arabera alderatzen da.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash erakusle gordin bat.
///
/// Honek `&T` erreferentzia bat (hau da, `*const T`-era inplizituki behartzen duena) bere hasierarako erabil dezake, adierazten duen balioaren ordez (hau da, `Hash for &T` inplementazioak egiten duena).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funtzio erakusleentzako inplikazioak
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Erabilera gisa tarteko galdaketa beharrezkoa da AVRrako
                // beraz, iturburu-funtzioaren erakuslearen helbide-espazioa azken funtzioaren erakuslean gordeko da.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Erabilera gisa tarteko galdaketa beharrezkoa da AVRrako
                // beraz, iturburu-funtzioaren erakuslearen helbide-espazioa azken funtzioaren erakuslean gordeko da.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ez dago funtzio aldakorrik 0 parametrorekin
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Sortu `const` erakusle gordina leku batera, tarteko erreferentziarik sortu gabe.
///
/// `&`/`&mut`-rekin erreferentzia sortzea erakuslea behar bezala lerrokatuta badago eta hasieratutako datuak seinalatzen baditu soilik onartzen da.
/// Baldintza horiek betetzen ez diren kasuetarako, erakusle gordinak erabili behar dira.
/// Hala ere, `&expr as *const _`-k erreferentzia bat sortzen du erakusle gordin batera bota aurretik, eta erreferentzia hori gainerako erreferentzia guztien arau berberen mende dago.
///
/// Makro honek erakusle gordin bat sor dezake * erreferentziarik sortu gabe.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` lerrokatu gabeko erreferentzia bat sortuko luke, eta horrela definitu gabeko jokabidea izango litzateke!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Sortu `mut` erakusle gordina leku batera, tarteko erreferentziarik sortu gabe.
///
/// `&`/`&mut`-rekin erreferentzia sortzea erakuslea behar bezala lerrokatuta badago eta hasieratutako datuak seinalatzen baditu soilik onartzen da.
/// Baldintza horiek betetzen ez diren kasuetarako, erakusle gordinak erabili behar dira.
/// Hala ere, `&mut expr as *mut _`-k erreferentzia bat sortzen du erakusle gordin batera bota aurretik, eta erreferentzia hori gainerako erreferentzia guztien arau berberen mende dago.
///
/// Makro honek erakusle gordin bat sor dezake * erreferentziarik sortu gabe.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` lerrokatu gabeko erreferentzia bat sortuko luke, eta horrela definitu gabeko jokabidea izango litzateke!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` erreferentzia sortu beharrean eremua kopiatzera behartzen du.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}