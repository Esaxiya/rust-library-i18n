//! inplikatzeko {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-k izan dezakeen baliozko kode puntu altuena.
    ///
    /// `char` [Unicode Scalar Value] bat da, hau da, [Code Point] da, baina tarte jakin bateko bakarrak dira.
    /// `MAX` baliozko [Unicode Scalar Value] balio duen kode puntu altuena da.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () Unicoden erabiltzen da deskodetze errorea adierazteko.
    ///
    /// Adibidez, gaizki osatutako UTF-8 byte [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-i ematean gerta daiteke.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` eta `str` metodoen Unicode zatiek oinarritzen duten [Unicode](http://www.unicode.org/) bertsioa.
    ///
    /// Unicoderen bertsio berriak aldizka kaleratzen dira eta, ondoren, Unicoderen araberako liburutegi estandarraren metodo guztiak eguneratzen dira.
    /// Beraz, `char` eta `str` metodo batzuen portaera eta konstante horren balioa denboran zehar aldatzen dira.
    /// Hau ez da aldaketa haustzat jotzen.
    ///
    /// Bertsioen zenbaketa eskema [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-n azaltzen da.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// UTF-16 kodetutako kode puntuen gaineko iteratzailea sortzen du `iter`-n, parekatutako ordezko ordezkoak "Err" gisa itzultzen ditu.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Galera-deskodetzailea lor daiteke `Err` emaitzak ordezko karakterearekin ordezkatuz:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` bat `char` bihurtzen du.
    ///
    /// Kontuan izan `char` guztiak baliozkoak direla [`u32`] s-rekin eta honekin batera bota daitezkeela
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Hala ere, alderantzizkoa ez da egia: baliozko [`u32`] guztiak ez dira baliozko`char`s.
    /// `from_u32()` `None` itzuliko du sarrerak `char` baterako baliozko balio ez badu.
    ///
    /// Egiaztapen hauek baztertzen dituen funtzio honen bertsio segurua lortzeko, ikusi [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` itzultzea sarrera `char` baliozkoa ez denean:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32` `char` bihurtzen du, baliozkotasuna alde batera utzita.
    ///
    /// Kontuan izan `char` guztiak baliozkoak direla [`u32`] s-rekin eta honekin batera bota daitezkeela
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Hala ere, alderantzizkoa ez da egia: baliozko [`u32`] guztiak ez dira baliozko`char`s.
    /// `from_u32_unchecked()` honek ez dio jaramonik egingo eta itsu-itsuan `char`-ra botako du, baliteke baliogabea sortuz.
    ///
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua, `char` balio baliogabeak sor ditzakeelako.
    ///
    /// Funtzio honen bertsio segurua lortzeko, ikusi [`from_u32`] funtzioa.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SEGURTASUNA: deitzaileak segurtasun kontratua onartu beharko du.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Emandako erradixteko digitu bat `char` bihurtzen du.
    ///
    /// Hemen 'radix' bati batzuetan 'base' ere deitzen zaio.
    /// Bi erradikzio batek zenbaki bitarra, hamarreko erradikoa, hamartarra eta hamaseiko erradikzioa, hamaseitarra, adierazten ditu balio komun batzuk emateko.
    ///
    /// Erradio arbitrarioak onartzen dira.
    ///
    /// `from_digit()` `None` itzuliko du sarrera emandako erradikoko zifra bat ez bada.
    ///
    /// # Panics
    ///
    /// Panics 36 baino handiagoa den erradixea ematen bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 11. hamartarra 16. oinarrian zifra bakarra da
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` itzultzea sarrera digitu bat ez denean:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Erradix handia igarotzean, panic eragiten da:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` bat emandako erradikoko zifra bat den egiaztatzen du.
    ///
    /// Hemen 'radix' bati batzuetan 'base' ere deitzen zaio.
    /// Bi erradikzio batek zenbaki bitarra, hamarreko erradikoa, hamartarra eta hamaseiko erradikzioa, hamaseitarra, adierazten ditu balio komun batzuk emateko.
    ///
    /// Erradio arbitrarioak onartzen dira.
    ///
    /// [`is_numeric()`]-rekin alderatuta, funtzio honek `0-9`, `a-z` eta `A-Z` karaktereak soilik ezagutzen ditu.
    ///
    /// 'Digit' karaktere hauek soilik definitzen da:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' hobeto ulertzeko, ikusi [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics 36 baino handiagoa den erradixea ematen bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Erradix handia igarotzean, panic eragiten da:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` bat emandako erradikoko zifra bihurtzen du.
    ///
    /// Hemen 'radix' bati batzuetan 'base' ere deitzen zaio.
    /// Bi erradikzio batek zenbaki bitarra, hamarreko erradikoa, hamartarra eta hamaseiko erradikzioa, hamaseitarra, adierazten ditu balio komun batzuk emateko.
    ///
    /// Erradio arbitrarioak onartzen dira.
    ///
    /// 'Digit' karaktere hauek soilik definitzen da:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `None` ematen du `char`-k emandako erradikoko zifrarik aipatzen ez badu.
    ///
    /// # Panics
    ///
    /// Panics 36 baino handiagoa den erradixea ematen bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Zenbakirik gabeko zenbakia pasatzeak huts egin du:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Erradix handia igarotzean, panic eragiten da:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kodea hemen zatitzen da `radix` konstantea eta 10 edo txikiagoa den kasuetan exekuzio abiadura hobetzeko
        //
        let val = if likely(radix <= 10) {
            // Zenbakia ez bada, radix baino zenbaki handiagoa sortuko da.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Pertsonaia baten Unicode ihes hamaseitarra `char`s gisa ematen duen iteratzailea ematen du.
    ///
    /// Honek `\u{NNNNNN}` formako Rust sintaxia duten karaktereak ihes egingo ditu, non `NNNNNN` irudikapen hamaseitarra den.
    ///
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1-ek ziurtatzen du c==0-rako kodeak zenbaki bat inprimatu behar dela kalkulatzen duela eta (berdina da)(31, 32) azpialdea saihesten duela.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // hamaseigarren zifra esanguratsuenaren indizea
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug`-ren bertsio hedatua, nahi izanez gero, Grapheme Extended kodepuntuetatik ihes egitea ahalbidetzen duena.
    /// Horrek kate baten hasieran daudenean markarik gabeko tarteak bezalako karaktereak hobeto formateatzea ahalbidetzen digu.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Pertsonaia baten ihes-kodea literala ematen duen iteratzailea itzultzen du `char`s gisa.
    ///
    /// Honek `Debug` edo `char`-ren `Debug` inplementazioen antzeko karaktereak ihes egingo ditu.
    ///
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Pertsonaia baten ihes-kodea literala ematen duen iteratzailea itzultzen du `char`s gisa.
    ///
    /// Lehenetsia hainbat hizkuntzatan legezkoak diren literalak sortzeko alderantziz aukeratzen da, C++ 11 eta antzeko C familiako hizkuntzak barne.
    /// Arau zehatzak hauek dira:
    ///
    /// * Fitxa `\t` gisa ihes egiten da.
    /// * Garraioaren itzulera `\r` gisa ihes egiten da.
    /// * Linea jarioa `\n` gisa ihes egiten da.
    /// * Aurrekontu bakarra `\'` gisa ihes egiten da.
    /// * Komatxo bikoitza `\"` gisa ihes egiten da.
    /// * Atzera barra barra `\\` gisa ihes egiten da.
    /// * `0x20` "inprimatzeko ASCII" barrutiko edozein karaktere ez da ihes egiten.
    /// * Beste karaktere guztiei Unicode ihes hamaseitarrak ematen zaizkie;ikusi [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// `char` honek behar lukeen byte kopurua ematen du UTF-8 kodetuta badago.
    ///
    /// Byte kopuru hori 1 eta 4 artekoa da beti, biak barne.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` motak bere edukia UTF-8 dela bermatzen du, eta, beraz, kode puntu bakoitza `char` gisa `&str` berean irudikatuko balitz hartuko lukeen luzera alderatu dezakegu:
    ///
    ///
    /// ```
    /// // karaktere gisa
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // biak hiru byte gisa irudika daitezke
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str gisa, bi hauek UTF-8 kodetuta daude
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // guztira sei byte hartzen dituztela ikus dezakegu ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str bezala
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// `char` honek UTF-16 kodetuta egongo balitz beharko lukeen 16 biteko kode unitate kopurua ematen du.
    ///
    ///
    /// Ikusi [`len_utf8()`] dokumentazioa kontzeptu honen inguruko azalpen gehiago lortzeko.
    /// Funtzio hau ispilu bat da, baina UTF-16 rentzat UTF-8 rentzat ordez.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Karaktere hau UTF-8 gisa kodetzen du emandako byte bufferrean, eta, ondoren, kodetutako karakterea duen bufferraren azpizerra itzultzen du.
    ///
    ///
    /// # Panics
    ///
    /// Panics bufferra nahikoa handia ez bada.
    /// Lau luzera duen buffer bat nahikoa da `char` edozein kodetzeko.
    ///
    /// # Examples
    ///
    /// Bi adibide horietan, 'ß'-k bi byte behar ditu kodetzeko.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Txikiegia den buffer bat:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SEGURTASUNA: `char` ez da ordezko bat, beraz, baliozko UTF-8 da.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Karaktere hau UTF-16 gisa kodetzen du emandako `u16` bufferrean, eta, ondoren, kodetutako karakterea duen bufferraren azpizerra itzultzen du.
    ///
    ///
    /// # Panics
    ///
    /// Panics bufferra nahikoa handia ez bada.
    /// 2. luzerako bufferra nahikoa da edozein `char` kodetzeko.
    ///
    /// # Examples
    ///
    /// Bi adibide horietan, '𝕊'-k bi `u16` hartzen ditu kodetzeko.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Txikiegia den buffer bat:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// `true` ematen du `char` honek `Alphabetic` propietatea badu.
    ///
    /// `Alphabetic` [Unicode Standard] ren 4. kapituluan (Karaktereen propietateak) deskribatzen da eta [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-n zehazten da.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // maitasuna gauza asko dira, baina ez da alfabetikoa
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// `true` ematen du `char` honek `Lowercase` propietatea badu.
    ///
    /// `Lowercase` [Unicode Standard] ren 4. kapituluan (Karaktereen propietateak) deskribatzen da eta [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-n zehazten da.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Txinako idazkera eta puntuazio ez dute maiuskularik eta beraz, beraz:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// `true` ematen du `char` honek `Uppercase` propietatea badu.
    ///
    /// `Uppercase` [Unicode Standard] ren 4. kapituluan (Karaktereen propietateak) deskribatzen da eta [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-n zehazten da.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Txinako idazkera eta puntuazio ez dute maiuskularik eta beraz, beraz:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// `true` ematen du `char` honek `White_Space` propietatea badu.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-n zehazten da.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // hautsi gabeko espazioa
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` ematen du `char` honek [`is_alphabetic()`] edo [`is_numeric()`] betetzen baditu.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` ematen du `char` honek kontrol-kodeen kategoria orokorra badu.
    ///
    /// Kontrol-kodeak (`Cc` kategoria orokorra duten kode-puntuak) [Unicode Standard] ren 4. kapituluan (Karaktereen Propietateak) deskribatzen dira eta [Unicode Character Database][ucd] [`UnicodeData.txt`]-n zehazten dira.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // U + 009C, KATEAREN Bukaera
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// `true` ematen du `char` honek `Grapheme_Extend` propietatea badu.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] n deskribatzen da eta [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] n zehazten da.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` ematen du `char` honek zenbakien kategoria orokorretako bat baldin badu.
    ///
    /// Zenbakien kategoria orokorrak (`Nd` zifra hamartarretarako, `Nl` letra moduko zenbakizko karaktereetarako eta `No` beste zenbakizko karaktereetarako) [Unicode Character Database][ucd] [`UnicodeData.txt`]-n zehazten dira.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// `char` honen letra xeheko mapak bat edo gehiago ematen dituen iteratzailea ematen du
    /// `char`s.
    ///
    /// `char` honek minuskulako maparik ez badu, iteratzaileak `char` bera emango du.
    ///
    /// `char` honek [Unicode Character Database][ucd] [`UnicodeData.txt`]-k emandako banakako minuskulen mapak baditu, iteratzaileak `char` hori ematen du.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// `char` honek gogoeta bereziak behar baditu (adibidez, `char` anitz) iteratzaileak [`SpecialCasing.txt`]-k emandako`char` (k) ematen du.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Eragiketa honek baldintzarik gabeko mapaketa egiten du neurrira egin gabe.Hau da, bihurketa testuinguruaren eta hizkuntzaren independentea da.
    ///
    /// [Unicode Standard]-n, 4. kapituluak (Karaktereen propietateak) kasu mapak orokorrean aztertzen ditu eta 3. kapituluak (Conformance)-k kasu bihurtzeko algoritmo lehenetsia.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Batzuetan emaitza pertsonaia bat baino gehiago izaten da:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Maiuskulak eta minuskulak ez dituzten karaktereak bere kabuz bihurtzen dira.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// `char` honen letra maiuskula bat edo gehiago gisa ematen duen iteratzailea ematen du
    /// `char`s.
    ///
    /// `char` honek maiuskulen maparik ez badu, iteratzaileak `char` bera emango du.
    ///
    /// `char` honek [Unicode Character Database][ucd] [`UnicodeData.txt`]-k emandako maiuskulazko bat-bateko mapaketa bat badu, iteratzaileak `char` hori ematen du.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// `char` honek gogoeta bereziak behar baditu (adibidez, `char` anitz) iteratzaileak [`SpecialCasing.txt`]-k emandako`char` (k) ematen du.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Eragiketa honek baldintzarik gabeko mapaketa egiten du neurrira egin gabe.Hau da, bihurketa testuinguruaren eta hizkuntzaren independentea da.
    ///
    /// [Unicode Standard]-n, 4. kapituluak (Karaktereen propietateak) kasu mapak orokorrean aztertzen ditu eta 3. kapituluak (Conformance)-k kasu bihurtzeko algoritmo lehenetsia.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Iteratzaile gisa:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` zuzenean erabiliz:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Biak baliokide dira:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` erabiliz:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Batzuetan emaitza pertsonaia bat baino gehiago izaten da:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Maiuskulak eta minuskulak ez dituzten karaktereak bere kabuz bihurtzen dira.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Oharra lokalari buruz
    ///
    /// Turkieraz, latinez 'i'-ren baliokideak bost forma ditu bi ordez:
    ///
    /// * 'Dotless': I/ı, batzuetan ï idatzita
    /// * 'Dotted': İ/i
    ///
    /// Kontuan izan 'i' puntuz minuskulaz latinaren berdina dela.Hori dela eta:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Hemen `upper_i`-ren balioa testuaren hizkuntzan oinarritzen da: `en-US`-en baldin bagara, `"I"` izan beharko luke, baina `tr_TR`-en badaude, `"İ"` izan beharko luke.
    /// `to_uppercase()` ez du hori kontuan hartzen, eta beraz:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// hizkuntzen artean mantentzen da.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Balioa ASCII barrutian dagoen egiaztatzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Balioaren kopia egiten du ASCII maiuskularen baliokidetzan.
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa maiuskulaz idazteko, erabili [`make_ascii_uppercase()`].
    ///
    /// ASCII ez diren ASCII karaktereez maiuskulaz idazteko, erabili [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Balioaren kopia egiten du bere minuskula ASCII baliokidetzan.
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa minuskulatzeko, erabili [`make_ascii_lowercase()`].
    ///
    /// ASCII karaktere minuskulak ASCII ez diren karaktereez gain, erabili [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Bi balio ASCII maiuskulak eta minuskulak bereizten ez dituztela egiaztatzen du.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ren baliokidea.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Mota hau bere ASCII maiuskulako baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Maiuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Mota hau bere ASCII minuskula baliokide bihurtzen du bere lekuan.
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Minuskulako balio berri bat itzultzeko lehendik zegoena aldatu gabe, erabili [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Balioa ASCII karaktere alfabetikoa den egiaztatzen du:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', edo
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Egiaztatzen du balioa ASCII maiuskulazkoa den:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Balioa ASCII minuskulako karakterea den egiaztatzen du:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Balioa ASCII karaktere alfanumerikoa den egiaztatzen du:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', edo
    /// - U + 0061 'a' ..=U + 007A 'z', edo
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Balioa ASCII digitu hamartarra den egiaztatzen du:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Egiaztatzen du balioa ASCII zenbaki hamaseitarra den:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', edo
    /// - U + 0041 'A' ..=U + 0046 'F', edo
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Balioa ASCII puntuazio karakterea den egiaztatzen du:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, edo
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, edo
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, edo
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Balioa ASCII karaktere grafikoa den egiaztatzen du:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Balioa ASCII zuriune-karakterea den egiaztatzen du:
    /// U + 0020 ESPAZIOA, U + 0009 FITXA HORIZONTALA, U + 000A LERROAREN AURRERAPENA, U + 000C FORMAREN ALIMENTAZIOA edo U + 000D GARRANTZIAREN ITZULERA.
    ///
    /// Rust-k WhatWG Infra Standard-en [definition of ASCII whitespace][infra-aw] erabiltzen du.Erabilera zabalean beste hainbat definizio daude.
    /// Adibidez, [the POSIX locale][pct]-k U + 000B TABULA BERTIKALA eta goiko karaktere guztiak biltzen ditu, baina - zehaztapen beretik beretik- [Bourne shell-en "field splitting" arau lehenetsiak][bfs]*bakarrik hartzen du* ESPAZIOA, TAULA HORIZONTALA eta LINE FEED espazio zuri gisa.
    ///
    ///
    /// Lehendik dagoen fitxategi formatua prozesatuko duen programa bat idazten ari bazara, egiaztatu funtzio hori erabili aurretik formatu horren zuriuneen definizioa zein den.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Balioa ASCII kontrol-karakterea den egiaztatzen du:
    /// U + 0000 NUL ..=U + 001F UNITATE SEPARATOR, edo U + 007F DELETE.
    /// Kontuan izan ASCII zuriuneetako karaktere gehienak kontroleko karaktereak direla, baina SPACE ez.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// u32 balio gordin bat UTF-8 gisa kodetzen du emandako byte bufferrean, eta, ondoren, kodetutako karakterea duen bufferraren azpizerra itzultzen du.
///
///
/// `char::encode_utf8` ez bezala, metodo honek ordezko barrutiko kodepuntuak ere maneiatzen ditu.
/// (Ordezko barrutian `char` sortzea UB da.) Emaitza [generalized UTF-8] baliozkoa da baina ez UTF-8 baliozkoa.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics bufferra nahikoa handia ez bada.
/// Lau luzera duen buffer bat nahikoa da `char` edozein kodetzeko.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// u32 balio gordin bat UTF-16 gisa kodetzen du emandako `u16` bufferrean, eta, ondoren, kodetutako karakterea duen bufferraren azpizerra itzultzen du.
///
///
/// `char::encode_utf16` ez bezala, metodo honek ordezko barrutiko kodepuntuak ere maneiatzen ditu.
/// (Ordezko barrutian `char` sortzea UB da.)
///
/// # Panics
///
/// Panics bufferra nahikoa handia ez bada.
/// 2. luzerako bufferra nahikoa da edozein `char` kodetzeko.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SEGURTASUNA: beso bakoitzak idazteko adina bit dauden ala ez egiaztatzen du
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP erortzen da
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Hegazkin osagarriak ordezko bihurtzen dira.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}