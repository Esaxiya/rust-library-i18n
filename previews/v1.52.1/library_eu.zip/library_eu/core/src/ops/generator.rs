use crate::marker::Unpin;
use crate::pin::Pin;

/// Sorgailuaren berrekitearen emaitza.
///
/// Enumero hau `Generator::resume` metodoaren bidez itzultzen da eta sorgailu baten itzulera balizko balioak adierazten ditu.
/// Gaur egun (`Yielded`) eteteko puntu bati edo (`Complete`) amaiera puntu bati dagokio.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Balio batekin esekitako sorgailua.
    ///
    /// Egoera horrek sorgailu bat eten egin dela adierazten du eta normalean `yield` instrukzio bati dagokio.
    /// Aldaera honetan emandako balioa `yield`-ri pasatutako adierazpenari dagokio eta sorgailuek ematen duten bakoitzean balioa eman dezakete.
    ///
    ///
    Yielded(Y),

    /// Sorgailua itzultzeko balioarekin osatu da.
    ///
    /// Egoera honek adierazten du sorgailu batek emandako balioarekin exekuzioa amaitu duela.
    /// Sorgailu batek `Complete` itzuli duenean programatzailearen akatstzat hartzen da `resume` berriro deitzea.
    ///
    Complete(R),
}

/// trait integratutako sorgailu motek inplementatuta.
///
/// Sorgailuak, koroutinak ere deitu ohi direnak, gaur egun hizkuntza esperimentaleko ezaugarriak dira Rust-n.
/// [RFC 2033] sorgailuetan gehituta gaur egun async/await sintaxirako eraikuntza-bloke bat eskaini nahi da, baina iteratzaileentzako eta beste primitibo batzuentzako definizio ergonomikoa ere hedatuko da.
///
///
/// Sorgailuen sintaxia eta semantika ezegonkorrak dira eta RFC gehiago beharko dute egonkortzeko.Une honetan, ordea, sintaxia itxiera modukoa da:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Sorgailuen dokumentazio gehiago aurki daiteke liburu ezegonkorrean.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Sorgailu honek ematen duen balio mota.
    ///
    /// Lotutako mota hau `yield` adierazpenari dagokio eta sorgailu bat ematen den bakoitzean itzultzeko baimena ematen duten balioak.
    ///
    /// Adibidez, iteratzaile-sorgailu batek mota hau `T` izenarekin izango luke, mota errepikatzen delarik.
    ///
    type Yield;

    /// Sorgailu honek ematen duen balio mota.
    ///
    /// Hau Sorgailu batetik `return` instrukzio batekin itzultzen den motari dagokio edo inplizituki sorgailuaren literalaren azken adierazpen gisa.
    /// Adibidez, futures-k `Result<T, E>` gisa erabiliko luke future osatua adierazten baitu.
    ///
    ///
    type Return;

    /// Sorgailu honen exekuzioa berrekiten du.
    ///
    /// Funtzio honek sorgailuaren exekuzioa berrekingo du edo exekutatzen hasiko da dagoeneko ez bada.
    /// Dei hau sorgailuaren azken eteteko puntura itzuliko da, azken `yield`-rekin exekuzioa berreskuratuz.
    /// Sorgailuak errenditzen edo itzultzen duen arte exekutatzen jarraituko du. Une horretan funtzio hori itzuliko da.
    ///
    /// # Itzuli balioa
    ///
    /// Funtzio honetatik itzulitako `GeneratorState` enum-ak sorgailua itzultzerakoan zein egoeratan dagoen adierazten du.
    /// `Yielded` aldaera itzultzen bada, sorgailuak esekidura puntu bat lortu du eta balio bat eman da.
    /// Egoera horretako sorgailuak beranduago berreskuratzeko erabilgarri daude.
    ///
    /// `Complete` itzultzen bada, sorgailuak emandako balioarekin amaitu du.Baliogabea da sorgailua berriro berrabiaraztea.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izan daiteke `Complete` aldaera lehenago itzuli ondoren deitzen bada.
    /// Hizkuntzako literal sorgailuak panic-ri `Complete` ondoren berrabiaraztean bermatuta dauden arren, hori ez dago bermatuta `Generator` trait-ren inplementazio guztietarako.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}