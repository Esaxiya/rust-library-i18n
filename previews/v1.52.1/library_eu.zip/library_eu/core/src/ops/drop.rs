/// Kode pertsonalizatua suntsitzailearen barruan.
///
/// Baliorik behar ez denean, Rust-k "destructor" exekutatuko du balio horretan.
/// Balio bat gehiago behar ez den modurik arruntena eremutik kanpora ateratzen denean da.Baliteke suntsitzaileek beste egoera batzuetan exekutatzea, baina hemen adibideen esparruan zentratuko gara.
/// Beste kasu horietako batzuk ezagutzeko, ikusi [the reference] atala suntsitzaileei buruz.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Suntsitzaile honek bi osagai ditu:
/// - Balio horretarako `Drop::drop` ra deitzea, `Drop` trait berezi hori bere motarako ezartzen bada.
/// - Automatikoki sortutako "drop glue"-k balio horretako eremu guztietako suntsitzaileei modu errekurtsiboan deitzen dio.
///
/// Rust-k eremu guztietako suntsitzaileei automatikoki deitzen dienez, kasu gehienetan ez duzu `Drop` inplementatu beharrik.
/// Baina zenbait kasutan erabilgarria da, adibidez, baliabide bat zuzenean kudeatzen duten motetarako.
/// Baliabide hori memoria izan daiteke, fitxategi deskribatzaile bat izan daiteke, sareko socket bat izan daiteke.
/// Mota horretako balioa jada erabiliko ez denean, "clean up" bere baliabidea memoria askatuz edo fitxategia edo socket-a itxiz.
/// Hau suntsitzaile baten lana da eta, beraz, `Drop::drop`-en lana.
///
/// ## Examples
///
/// Suntsitzaileak martxan ikusteko, ikus dezagun programa hau:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust-k lehenik `Drop::drop` deituko du `_x` erako eta gero `_x.one` eta `_x.two`, hau da, hau exekutatzeak inprimatuko du
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// `Drop`-ren inplementazioa `HasTwoDrop`-entzat kentzen badugu ere, bere eremuetako suntsitzaileei deitzen zaie.
/// Horrek eragingo luke
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ezin duzu `Drop::drop`-ri deitu
///
/// `Drop::drop` balio bat garbitzeko erabiltzen denez, baliteke metodoa deitu ondoren balio hori erabiltzea arriskutsua izatea.
/// `Drop::drop`-ek bere sarreraren jabetza hartzen ez duenez, Rust-k erabilera okerra saihesten du `Drop::drop` zuzenean deitzea ez uzteko.
///
/// Beste modu batera esanda, goiko adibidean `Drop::drop` ri esplizituki deitzen saiatuz gero, konpiladorearen errore bat lortuko zenuke.
///
/// Balio baten suntsitzaileari esplizituki deitu nahi badiozu, [`mem::drop`] erabil daiteke horren ordez.
///
/// [`mem::drop`]: drop
///
/// ## Jaregin eskaera
///
/// Gure bi `HasDrop` etatik zein jaisten da lehenik, ordea?Egituretarako, aldarrikatzen duten ordena bera da: lehenik `one`, gero `two`.
/// Hau zeure burua probatu nahi baduzu, goiko `HasDrop` alda dezakezu datu batzuk edukitzeko, zenbaki oso bat bezalakoa, eta gero X002 barruan `println!` erabil dezakezu.
/// Jokabide hori hizkuntzak bermatzen du.
///
/// Egituretan ez bezala, aldagai lokalak alderantzizko ordenan jaisten dira:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Honek inprimatuko du
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Mesedez, ikusi [the reference] arau osoak ikusteko.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` eta `Drop` esklusiboak dira
///
/// Ezin dituzu [`Copy`] eta `Drop` inplementatu mota berean.`Copy` diren motak inplizituki bikoizten ditu konpiladoreak, oso zaila da noiz eta noiz eta noiz exekutatuko diren suntsitzaileak aurreikustea.
///
/// Horrela, mota hauek ezin dituzte suntsitzaileak izan.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Mota honetako suntsitzailea exekutatzen du.
    ///
    /// Metodo honi inplizituki deitzen zaio balioa eremutik kanpo dagoenean, eta ezin zaio esplizituki deitu ([E0040] konpilatzailearen errorea da).
    /// Hala ere, prelude-eko [`mem::drop`] funtzioa argumentuaren `Drop` inplementaziora deitzeko erabil daiteke.
    ///
    /// Metodo honi deitu zaionean, `self` oraindik ez da banatu.
    /// Hori metodoa amaitu ondoren gertatzen da.
    /// Hori ez balitz, `self` erreferentzia zintzilikaria izango litzateke.
    ///
    /// # Panics
    ///
    /// [`panic!`] batek `drop` deituko duela ohartzen denez, `drop` inplementazio bateko edozein [`panic!`] bertan behera geldituko da.
    ///
    /// Kontuan izan panics hori bada ere, balioa jaitsi egin dela;
    /// ez duzu `drop` berriro deitzea eragin behar.
    /// Hau normalean automatikoki kudeatzen du konpiladoreak, baina segurtasunik gabeko kodea erabiltzean, nahi gabe gerta daiteke batzuetan, batez ere [`ptr::drop_in_place`] erabiltzean.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}