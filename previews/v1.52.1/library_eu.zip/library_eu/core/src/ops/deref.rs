/// `*v` bezalako desreferentziazio aldagaitz eragiketetarako erabiltzen da.
///
/// (unary) `*` operadorearekin testuinguru aldaezinetan erreferentziazko eragiketak egiteko erabiltzeaz gain, `Deref` inplizituki erabiltzen du konpiladoreak egoera askotan.
/// Mekanismo horri ['`Deref` coercion'][more] deitzen zaio.
/// Testuinguru aldakorretan, [`DerefMut`] erabiltzen da.
///
/// Erakusle adimendunentzako `Deref` ezartzeak atzean dauden datuak atzitzea eroso bihurtzen du, horregatik inplementatzen dute `Deref`.
/// Bestalde, `Deref` eta [`DerefMut`]-i buruzko arauak erakusle adimendunak hartzeko bereziki diseinatu dira.
/// Hori dela eta,**`Deref` erakusle adimendunetarako soilik ezarri beharko litzateke** nahasmena ekiditeko.
///
/// Antzeko arrazoiengatik,**trait honek ez luke inoiz huts egin behar**.Desferentziatzerakoan huts egitea oso nahasgarria izan daiteke `Deref` modu inplizituan deitzen denean.
///
/// # `Deref` behartzeari buruzko informazio gehiago
///
/// `T`-k `Deref<Target = U>` inplementatzen badu eta `x` `T` motako balioa bada, orduan:
///
/// * Testuinguru aldaezinetan, `*x` (non `T` ez baita erreferentzia ezta erakusle gordina) `* Deref::deref(&x)` ren baliokidea da.
/// * `&T` motako balioak `&U` motako balioetara behartzen dira
/// * `T` inplizituki ezartzen ditu `U` motako (immutable) metodo guztiak.
///
/// Xehetasun gehiago lortzeko, bisitatu [the chapter in *The Rust Programming Language*][book] eta [the dereference operator][ref-deref-op], [method resolution] eta [type coercions] erreferentzia atalak.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Eremu bakarra duen egitura, egitura desdeferentziatuz eskuragarria dena.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Emaitza mota ezabatu ondoren.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Balioa desberdintzen du.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Aldaketen erreferentziazko eragiketetarako erabiltzen da, `*v = 1;`-n bezala.
///
/// Testu aldakorreko (unary) `*` operadorearekin desferentziatzeko eragiketa esplizituak egiteko erabiltzeaz gain, `DerefMut` inplizituki erabiltzen du konpiladoreak inguruabar askotan.
/// Mekanismo horri ['`Deref` coercion'][more] deitzen zaio.
/// Testuinguru aldaezinetan, [`Deref`] erabiltzen da.
///
/// Erakusle adimendunentzako `DerefMut` ezartzeak haien atzean dauden datuak mutatzea komenigarria da, horregatik inplementatzen dute `DerefMut`.
/// Bestalde, [`Deref`] eta `DerefMut`-i buruzko arauak erakusle adimendunak hartzeko bereziki diseinatu dira.
/// Hori dela eta,**`DerefMut` erakusle adimendunetarako soilik ezarri beharko litzateke**, nahasmena ekiditeko.
///
/// Antzeko arrazoiengatik,**trait honek ez luke inoiz huts egin behar**.Desferentziatzerakoan huts egitea oso nahasgarria izan daiteke `DerefMut` modu inplizituan deitzen denean.
///
/// # `Deref` behartzeari buruzko informazio gehiago
///
/// `T`-k `DerefMut<Target = U>` inplementatzen badu eta `x` `T` motako balioa bada, orduan:
///
/// * Testuinguru aldaezinetan, `*x` (non `T` ez baita erreferentzia ezta erakusle gordina) `* DerefMut::deref_mut(&mut x)` ren baliokidea da.
/// * `&mut T` motako balioak `&mut U` motako balioetara behartzen dira
/// * `T` inplizituki ezartzen ditu `U` motako (mutable) metodo guztiak.
///
/// Xehetasun gehiago lortzeko, bisitatu [the chapter in *The Rust Programming Language*][book] eta [the dereference operator][ref-deref-op], [method resolution] eta [type coercions] erreferentzia atalak.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Eremu bakarra duen egitura, egitura desdeferentziatuz alda daitekeena.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Alde batera eta bestera balioari erreferentzia egiten dio.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` funtziorik gabe egitura metodo hartzaile gisa erabil daitekeela adierazten du.
///
/// `Box<T>`, `Rc<T>`, `&T` eta `Pin<P>` bezalako stdlib erakusle motek inplementatzen dute hori.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}