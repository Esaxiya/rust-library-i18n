/// `?` operadorearen portaera pertsonalizatzeko trait.
///
/// `Try` inplementatzen duen mota success/failure dikotomiaren arabera ikusteko modu kanonikoa du.
/// trait honi esker arrakasta edo porrotaren balioak lehendik dagoen instantzia batetik ateratzea eta instantzia berri bat sortzea arrakasta edo porrotaren balio batetik abiatuta.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Balio horren mota arrakastatsutzat jotzen denean.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Balio honen mota huts egin duen moduan ikustean.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" operadorea aplikatzen du.`Ok(t)` itzultzeak exekuzioak normaltasunez jarraitu behar duela esan nahi du eta `?` ren emaitza `t` balioa da.
    /// `Err(e)` itzultzeak esan nahi du exekuzioak branch behar duen `catch` barneko barneraino edo funtziotik itzuli behar duela.
    ///
    /// `Err(e)` emaitza lortzen bada, `e` balioa "wrapped" izango da inguratzen duen esparruaren itzulera motan (horrek berak `Try` ezarri behar du).
    ///
    /// Zehazki, `X::from_error(From::from(e))` balioa itzultzen da, non `X` itxitura-funtzioaren itzulera mota den.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Itzuli errore-balio bat emaitza konposatua eraikitzeko.
    /// Adibidez, `Result::Err(x)` eta `Result::from_error(x)` baliokideak dira.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Itzuli OK balio bat emaitza konposatua eraikitzeko.
    /// Adibidez, `Result::Ok(x)` eta `Result::from_ok(x)` baliokideak dira.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}