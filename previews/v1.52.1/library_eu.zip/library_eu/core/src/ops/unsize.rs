use crate::marker::Unsize;

/// Trait adierazten duen bat erakuslea edo bilgailua dela, puntuazioan tamaina desegin daiteke.
///
/// [DST coercion RFC][dst-coerce] eta [the nomicon entry on coercion][nomicon-coerce] ikus xehetasun gehiago lortzeko.
///
/// Erakusle mota integratuetan, `T`-ko erakusleek `U`-era bideratuko dituzte `T: Unsize<U>` bada, erakusle mehe batetik erakusle lodira bihurtuz.
///
/// Mota pertsonalizatuetarako, hemen behartzea `Foo<T>`-tik `Foo<U>`-ra behartuz funtzionatzen du, baldin eta `CoerceUnsized<Foo<U>> for Foo<T>`-ren inplikazioa badago.
/// Aplikazio hori `Foo<T>`-k `T`-ko datu fantasmagorikoak ez diren eremu bakarra badu bakarrik idatz daiteke.
/// Eremu horren mota `Bar<T>` bada, `CoerceUnsized<Bar<U>> for Bar<T>` ren inplementazioa egon behar da.
/// Koercioak `Bar<T>` eremua `Bar<U>` era behartuz funtzionatuko du eta gainerako eremuak `Foo<T>`-tik betez `Foo<U>` sortzeko.
/// Horrek modu eraginkorrean erakusle eremu batera zulatuko du eta hori behartuko du.
///
/// Orokorrean, erakusle adimendunetarako `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` inplementatuko duzu, aukerako `?Sized` batekin loturik `T` bera.
/// `T` zuzenean `Cell<T>` eta `RefCell<T>` bezalako txertatzen dituzten bilgarri motetarako, `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` zuzenean inplementa dezakezu.
///
/// Honek `Cell<Box<T>>` bezalako motako beharketak funtzionatuko ditu.
///
/// [`Unsize`][unsize] erakusleen atzean badaude DSTetara behartu daitezkeen motak markatzeko erabiltzen da.Konpiladoreak automatikoki ezartzen du.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Hau objektuen segurtasunerako erabiltzen da, metodo baten hargailu mota bidali daitekeela egiaztatzeko.
///
/// trait aplikazioaren adibide bat:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}