/// Hartzaile aldaezina hartzen duen deiaren operadorearen bertsioa.
///
/// `Fn` instantziei behin eta berriz dei dakieke mutazio egoerarik gabe.
///
/// *trait (`Fn`) hau ez da [function pointers] (`fn`)-rekin nahastu behar.*
///
/// `Fn` automatikoki inplementatzen da harrapatutako aldagaiei erreferentzia aldaezinak bakarrik hartzen dizkieten edo inolako ezer ere harrapatzen ez duten itxierek, baita (safe) [function pointers]-k ere (oharpen batzuekin, ikusi dokumentazioa xehetasun gehiagorako).
///
/// Gainera, `Fn` ezartzen duen edozein `F` motarako, `&F`-k `Fn` ere ezartzen du.
///
/// [`FnMut`] eta [`FnOnce`] bai `Fn`-ren gaineko erretratuak direnez, `Fn` edozein instantzia erabil daiteke parametro gisa, [`FnMut`] edo [`FnOnce`] espero da.
///
/// Erabili `Fn` lotura gisa funtzio moduko parametro bat onartu nahi duzunean eta behin eta berriz eta mutazio egoerarik gabe deitu behar duzunean (adibidez, aldi berean deitzean).
/// Baldintza zorrotzik behar ez baduzu, erabili [`FnMut`] edo [`FnOnce`] muga gisa.
///
/// Ikusi [chapter on closures in *The Rust Programming Language*][book] gaia gai honi buruzko informazio gehiago lortzeko.
///
/// Aipatzekoa da `Fn` traits-ren sintaxi berezia ere (adibidez
/// `Fn(usize, bool) -> erabili ').Honen xehetasun teknikoetan interesa dutenek [the relevant section in the *Rustonomicon*][nomicon] erreferentzia egin dezakete.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Itxiera deitzea
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametroa erabiliz
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // beraz, regex-k `&str: !FnMut` horretan fidatu daiteke
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Dei eragiketa egiten du.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Hartzaile aldaezina hartzen duen deiaren operadorearen bertsioa.
///
/// `FnMut` instantziei behin eta berriz dei dakieke eta egoera mutatua izan daiteke.
///
/// `FnMut` automatikoki ezartzen da harrapatutako aldagaien erreferentzia aldakorrak hartzen dituzten itxierak, baita [`Fn`] inplementatzen duten mota guztiak ere, adibidez, (safe) [function pointers] (`FnMut` [`Fn`] ren supererretratua baita).
/// Gainera, `FnMut` ezartzen duen edozein `F` motarako, `&mut F`-k `FnMut` ere ezartzen du.
///
/// [`FnOnce`] `FnMut`-ren supererretratua denez, `FnMut`-ren edozein instantzia erabil daiteke [`FnOnce`] espero denean eta [`Fn`] `FnMut`-ren azpierretratua denez, [`Fn`]-ren edozein instantzia `FnMut` espero denean erabil daiteke.
///
/// Erabili `FnMut` lotura gisa funtzio moduko parametro bat onartu nahi duzunean eta behin eta berriz deitu behar diozun bitartean, egoera mutatzeko aukera ematen duen bitartean.
/// Parametroak egoera mutatzea nahi ez baduzu, erabili [`Fn`] lotura gisa;behin eta berriz deitu behar ez baduzu, erabili [`FnOnce`].
///
/// Ikusi [chapter on closures in *The Rust Programming Language*][book] gaia gai honi buruzko informazio gehiago lortzeko.
///
/// Aipatzekoa da `Fn` traits-ren sintaxi berezia ere (adibidez
/// `Fn(usize, bool) -> erabili ').Honen xehetasun teknikoetan interesa dutenek [the relevant section in the *Rustonomicon*][nomicon] erreferentzia egin dezakete.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Alde batera harrapatzeko itxiera deitzea
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametroa erabiliz
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // beraz, regex-k `&str: !FnMut` horretan fidatu daiteke
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Dei eragiketa egiten du.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Balio osoko hargailua hartzen duen deiaren operadorearen bertsioa.
///
/// `FnOnce`-ren instantzia deitu daiteke, baina baliteke behin baino gehiagotan deigarriak ez izatea.Hori dela eta, mota bati buruz ezagutzen den gauza bakarra `FnOnce` inplementatzen badu, behin bakarrik deitu daiteke.
///
/// `FnOnce` automatikoki ezartzen da harrapatutako aldagaiak kontsumitzen dituzten itxierak, baita [`FnMut`] inplementatzen duten mota guztiak ere, adibidez, (safe) [function pointers] (`FnOnce` [`FnMut`] supererretratua baita).
///
///
/// Bai [`Fn`] eta [`FnMut`] `FnOnce`-ren azpi-ezaugarriak direnez, [`Fn`] edo [`FnMut`]-ren edozein instantzia erabil daiteke `FnOnce` bat espero denean.
///
/// Erabili `FnOnce` lotura gisa funtzio moduko parametro bat onartu nahi duzunean eta behin bakarrik deitu behar zaionean.
/// Parametroari behin eta berriz deitu behar badiozu, erabili [`FnMut`] lotura gisa;egoera mutatzeko ere behar baduzu, erabili [`Fn`].
///
/// Ikusi [chapter on closures in *The Rust Programming Language*][book] gaia gai honi buruzko informazio gehiago lortzeko.
///
/// Aipatzekoa da `Fn` traits-ren sintaxi berezia ere (adibidez
/// `Fn(usize, bool) -> erabili ').Honen xehetasun teknikoetan interesa dutenek [the relevant section in the *Rustonomicon*][nomicon] erreferentzia egin dezakete.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametroa erabiliz
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` harrapatutako aldagaiak kontsumitzen ditu, beraz ezin da behin baino gehiagotan exekutatu.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` berriro deitzen saiatzeak `use of moved value` errorea sortuko du `func` rentzat.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ezin da une honetan deitu
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // beraz, regex-k `&str: !FnMut` horretan fidatu daiteke
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Deitutako operadorea ondoren itzuli den mota.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Dei eragiketa egiten du.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}