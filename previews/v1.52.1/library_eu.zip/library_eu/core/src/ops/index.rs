/// (`container[index]`) indexatzeko eragiketak testuinguru aldaezinetan erabiltzeko.
///
/// `container[index]` benetan azukre sintaktikoa da `*container.index(index)` rentzat, baina balio aldaezin gisa erabiltzen denean bakarrik.
/// Aldagarria den balioa eskatzen bada, [`IndexMut`] erabiltzen da horren ordez.
/// Honek `let value = v[index]` bezalako gauza politak onartzen ditu `value` motak [`Copy`] inplementatzen badu.
///
/// # Examples
///
/// Ondorengo adibideak `Index` inplementatzen du irakurtzeko soilik den `NucleotideCount` edukiontzian, indize sintaxiarekin zenbaketa indibidualak berreskuratzeko aukera emanez.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Itzulitako mota indexatu ondoren.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// (`container[index]`) indexazio eragiketa egiten du.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Testu aldakorreko (`container[index]`) eragiketak indexatzeko erabiltzen da.
///
/// `container[index]` benetan azukre sintaktikoa da `*container.index_mut(index)` rentzat, baina balio aldagarri gisa erabiltzen denean bakarrik.
/// Balio aldaezina eskatzen bada, [`Index`] trait erabiltzen da horren ordez.
/// Honek `v[index] = value` bezalako gauza politak ahalbidetzen ditu.
///
/// # Examples
///
/// Bi alde dituen `Balance` egituraren ezarpen oso sinplea, non bakoitza modu aldakorrean eta aldaezinean indexatu daitekeen.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Kasu honetan, `balance[Side::Right]` azukrea da `*balance.index(Side::Right)` rentzat,*`balance[Side::Right]` * irakurtzen ari baikara soilik idazten.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Hala ere, kasu honetan `balance[Side::Left]` azukrea da `*balance.index_mut(Side::Left)` rentzat, `balance[Side::Left]` idazten ari garelako.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Indize aldakorreko (`container[index]`) eragiketa egiten du.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}