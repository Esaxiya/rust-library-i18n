//! Gainkargatzeko operadoreak.
//!
//! traits hauek ezartzeak zenbait operadore gainkargatzeko aukera ematen du.
//!
//! traits horietako batzuk prelude-k inportatzen ditu, beraz, Rust programa guztietan daude eskuragarri.traits-ek babestutako operadoreak soilik karga daitezke.
//! Adibidez, (`+`) gehigarri operadorea [`Add`] trait bidez gainkarga daiteke, baina (`=`) esleipen operadoreak trait babesik ez duenez, ez dago bere semantika gainkargatzeko modurik.
//! Gainera, modulu honek ez du operadore berriak sortzeko inolako mekanismorik eskaintzen.
//! Ezaugarririk gabeko gainkarga edo operadore pertsonalizatuak behar badira, makro edo konpilagailuen pluginetara begiratu beharko zenuke Rust-ren sintaxia zabaltzeko.
//!
//! traits operadorearen inplementazioak ez dira harrigarriak izan behar beren testuinguruetan, betiko esanahiak eta [operator precedence] kontuan izanik.
//! Adibidez, [`Mul`] ezartzerakoan, eragiketak nolabaiteko antzekotasuna izan behar du biderketarekin (eta asoziatibitatea bezalako espero diren propietateak partekatu).
//!
//! Kontuan izan `&&` eta `||` operadoreek zirkuitulaburra dutela, hau da, bigarren operandoa emaitzari laguntzen badio soilik ebaluatzen dutela.traits-k portaera hori ez duenez aplikatzen, `&&` eta `||` ez dira onartzen gainkargagarri diren operadore gisa.
//!
//! Operadore askok beren operandoak balioaren arabera hartzen dituzte.Eraikitako motekin lotutako testuinguru ez generikoetan, normalean ez da arazoa izaten.
//! Hala ere, operadore horiek kode generikoan erabiltzeak arreta pixka bat behar du balioak berrerabili behar badira operadoreek kontsumitzen uztearekin alderatuta.Aukera bat noizean behin [`clone`] erabiltzea da.
//! Beste aukera bat erreferentzia operadore inplementazio osagarriak eskaintzen dituzten motetan oinarritzea da.
//! Adibidez, erabiltzaileak definitutako `T` motak gehitzea onartzen duela ustez, ideia ona da bai `T` bai `&T` traits [`Add<T>`][`Add`] eta [`Add<&T>`][`Add`] inplementatzea, beharrezko klonaziorik gabeko kode generikoa idatzi ahal izateko.
//!
//!
//! # Examples
//!
//! Adibide honek [`Add`] eta [`Sub`] inplementatzen dituen `Point` egitura sortzen du eta, ondoren, bi `Puntu` batu eta kentzen direla erakusten du.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Ikusi trait bakoitzaren dokumentazioa adibide inplementazio baterako.
//!
//! [`Fn`], [`FnMut`] eta [`FnOnce`] traits funtzioak bezala dei daitezkeen moten arabera inplementatzen dira.Kontuan izan [`Fn`]-k `&self` hartzen duela, [`FnMut`]-k `&mut self`-a eta [`FnOnce`]-k `self`-a.
//! Hauek instantzia batean dei daitezkeen hiru metodo motari dagozkie: erreferentzia-deia, erreferentzia alda daitekeen deia eta balio-deia.
//! traits hauen erabilerarik ohikoena funtzioak edo itxierak argumentu gisa hartzen dituzten goi mailako funtzioen muga gisa jardutea da.
//!
//! [`Fn`] parametro gisa hartuta:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] parametro gisa hartuta:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] parametro gisa hartuta:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` harrapatutako aldagaiak kontsumitzen ditu, beraz ezin da behin baino gehiagotan exekutatu
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` berriro deitzen saiatzeak `use of moved value` errorea sortuko du `func` rentzat
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ezin da une honetan deitu
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;