//! traits primitiboak eta moten oinarrizko propietateak adierazten dituzten motak.
//!
//! Rust motak hainbat modu erabilgarritan sailka daitezke beren berezko propietateen arabera.
//! Sailkapen hauek traits gisa irudikatzen dira.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Hari mugen artean transferi daitezkeen motak.
///
/// trait hau automatikoki ezartzen da konpiladoreak egokia dela erabakitzen duenean.
///
/// `Bidali` motako adibide bat [`rc::Rc`][`Rc`] erreferentzia-zenbaketa erakuslea da.
/// Bi hari erreferentzia-zenbatu balio bera adierazten duten [`Rc`] klonatzen saiatzen badira, erreferentzia-kopurua aldi berean eguneratzen saiatuko dira, hau da, [undefined behavior][ub], [`Rc`]-k ez dituelako eragiketa atomikoak erabiltzen.
///
/// Bere lehengusu [`sync::Arc`][arc] ak eragiketa atomikoak erabiltzen ditu (gainkarga batzuk sortzen ditu) eta, beraz, `Send` da.
///
/// Ikus [the Nomicon](../../nomicon/send-and-sync.html) xehetasun gehiagorako.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Konpilazio garaian ezagutzen den tamaina konstantea duten motak.
///
/// Mota parametro guztiek `Sized`-ren lotura inplizitua dute.`?Sized` sintaxi berezia erabil daiteke lotura hori kentzeko egokia ez bada.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//errorea: tamaina ez dago [i32]-rako inplementatuta
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Salbuespen bakarra trait baten `Self` mota inplizitua da.
/// trait batek ez du `Sized` lotura inplizitua, hau bateraezina baita [trait objektu] objektuekin. Definizioz, trait-k inplementatzaile posible guztiekin lan egin behar du eta, beraz, edozein tamainakoa izan daiteke.
///
///
/// Rust-k `Sized` trait batera lotzen utziko dizun arren, ezin izango duzu erabili geroago trait objektu bat osatzeko:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // utzi y: &dyn Bar= &Impl;//errorea: trait `Bar` ezin da objektu bihurtu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Lehenetsia, adibidez, `[T]: !Default` ebaluagarria izatea eskatzen duena
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" izan daitezkeen motak tamaina dinamikoko motarako.
///
/// Adibidez, `[i8; 2]` tamainako array motak `Unsize<[i8]>` eta `Unsize<dyn fmt::Debug>` inplementatzen ditu.
///
/// `Unsize` ren inplementazio guztiak automatikoki ematen ditu konpiladoreak.
///
/// `Unsize` honetarako gauzatzen da:
///
/// - `[T; N]` `Unsize<[T]>` da
/// - `T` `Unsize<dyn Trait>` da `T: Trait` denean
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` da baldin eta:
///   - `T: Unsize<U>`
///   - Foo egitura da
///   - `Foo`-ren azken eremuak bakarrik du `T`-rekin lotutako motarik
///   - `T` ez da beste edozein eremuren motaren zati
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo`-ren azken eremuak `Bar<T>` mota badu
///
/// `Unsize` [`ops::CoerceUnsized`]-rekin batera erabiltzen da "user-defined" edukiontziek [`Rc`] bezalako edukiontziek tamaina dinamikoko motak izan ditzaten.
/// [DST coercion RFC][RFC982] eta [the nomicon entry on coercion][nomicon-coerce] ikus xehetasun gehiago lortzeko.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait derrigorrezkoa ereduen partidetan erabiltzen diren konstanteetarako.
///
/// `PartialEq` eratortzen duen edozein motak automatikoki inplementatzen du trait hau,*motako parametroek `Eq` ezartzen duten ala ez*.
///
/// `const` elementu batek trait hau inplementatzen ez duen motaren bat baldin badu, orduan mota horrek bai (1.)-k ez du `PartialEq` inplementatzen (horrek esan nahi du konstanteak ez duela konparazio metodo hori emango, kode belaunaldiak suposatzen duela eskuragarri dagoela) edo (2.)-ek *berea inplementatzen du*`PartialEq`-ren bertsioa (suposatzen dugu ez datorrela bat egiturazko berdintasunaren alderaketarekin).
///
///
/// Goiko bi eszenatokietako batean, eredu bat datorren konstante horren erabilera baztertzen dugu.
///
/// Ikus atributuetan oinarritutako diseinutik trait honetara migratzera bultzatu zuten [structural match RFC][RFC1445] eta [issue 63438].
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait derrigorrezkoa ereduen partidetan erabiltzen diren konstanteetarako.
///
/// `Eq` eratortzen duen edozein motak automatikoki inplementatzen du trait hau,*motako parametroek `Eq` ezartzen duten ala ez*.
///
/// Hau gure sistema motako muga baten inguruan lan egiteko hack bat da.
///
/// # Background
///
/// Eredu-partidetan erabilitako const motek `#[derive(PartialEq, Eq)]` atributua izan dezaten eskatu nahi dugu.
///
/// Mundu idealago batean, eskakizun hori egiaztatu ahal izango dugu emandako motak `StructuralPartialEq` trait *eta*`Eq` trait ezartzen dituela egiaztatuta.
/// Hala ere,* ** `derive(PartialEq, Eq)` duten ADTak izan ditzakezu, eta konpiladoreak onartzea nahi dugun kasu bat izan daiteke, eta, hala ere, konstantearen motak huts egiten du `Eq` ezartzeko.
///
/// Hots, horrelako kasu bat:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Goiko kodearen arazoa da `Wrap<fn(&())>` k ez duela `PartialEq` inplementatzen, ezta `Eq` ere, `for <'a> fn(&'a _)` does not implement those traits.) delako
///
/// Hori dela eta, ezin dugu `StructuralPartialEq` eta `Eq` hutsaren egiaztapen inozoetan oinarritu.
///
/// Honen inguruan lan egiteko hack gisa, bi bakoitzak (`#[derive(PartialEq)]` eta `#[derive(Eq)]`) eratorritako injektatutako traits bereiziak erabiltzen ditugu eta biak egiturazko bat-etortze egiaztapenaren parte direla egiaztatzen dugu.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Balioak bikoiztu daitezkeen motak bit kopiatuz soilik.
///
/// Berez, lotura aldakorrek 'mugitu semantika' dute.Beste hitz batzutan:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y`-ra aldatu da eta, beraz, ezin da erabili
///
/// // println! ("{: ?}", x);//errorea: mugitutako balioa erabiltzea
/// ```
///
/// Hala ere, mota batek `Copy` inplementatzen badu, 'kopiatu semantika' du:
///
/// ```
/// // `Copy` inplementazio bat atera dezakegu.
/// // `Clone` beharrezkoa da ere, `Copy`-ren supererretratua baita.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` ren kopia da
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Garrantzitsua da aipatzea bi adibide hauetan, desberdintasun bakarra zereginaren ondoren `x`-ra sartzeko baimena duzula.
/// Kanpaiaren azpian, kopiak zein mugimenduak bitak memorian kopiatzea eragin dezakete, nahiz eta batzuetan optimizatu egiten den.
///
/// ## Nola ezar dezaket `Copy`?
///
/// Zure motan `Copy` ezartzeko bi modu daude.Errazena `derive` erabiltzea da:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` eta `Clone` ere eskuz ezar ditzakezu:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Bien artean alde txikia dago: `derive` estrategiak `Copy` lotua jarriko du motako parametroetan, beti nahi ez dena.
///
/// ## Zein da `Copy` eta `Clone` arteko aldea?
///
/// Kopiak modu inplizituan gertatzen dira, adibidez `y = x` esleipenaren zati gisa.`Copy` ren portaera ez da gainkargagarria;beti da kopia bit-jakintsua.
///
/// Klonazioa ekintza esplizitua da, `x.clone()`.[`Clone`] ezartzeak balioak segurtasunez bikoizteko beharrezko motako edozein portaera eman dezake.
/// Adibidez, [`Clone`] [`String`]-rako inplementazioak seinalatutako katearen bufferra kopiatu behar du pilan.
/// [`String`] balioen bit bitako kopia sinpleak erakuslea kopiatzea besterik ez luke, lerroan beherantz doan bikoitza lortuz.
/// Hori dela eta, [`String`] [`Clone`] da baina ez `Copy`.
///
/// [`Clone`] `Copy`-ren supererretratua da, beraz, `Copy` denak [`Clone`] ere ezarri behar du.
/// Mota bat `Copy` bada, [`Clone`] inplementazioak `*self` bakarrik itzuli behar du (ikusi goiko adibidea).
///
/// ## Noiz izan daiteke nire mota `Copy`?
///
/// Mota batek `Copy` ezar dezake bere osagai guztiek `Copy` ezartzen badute.Adibidez, egitura hau `Copy` izan daiteke:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Egitura bat `Copy` izan daiteke, eta [`i32`] `Copy` da, beraz `Point` `Copy` izateko eskubidea da.
/// Aitzitik, kontuan hartu
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` egiturak ezin du `Copy` inplementatu, [`Vec<T>`] ez baita `Copy`.`Copy` inplementazio bat lortzen saiatzen bagara, errore bat jasoko dugu:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Partekatutako (`&T`) erreferentziak ere `Copy` dira, beraz, mota bat `Copy` izan daiteke, nahiz eta * `Copy` ez diren `T` motako erreferentzia partekatuak eduki.
/// Demagun honako egitura hau, `Copy` inplementa dezakeena, "Kopiatu" ez duen `PointList` motaren gaineko *partekatutako erreferentzia* baitu goitik:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Noiz * ezin da nire mota `Copy` izan?
///
/// Mota batzuk ezin dira segurtasunez kopiatu.Adibidez, `&mut T` kopiatzeak aliatutako erreferentzia aldagarri bat sortuko luke.
/// [`String`] kopiatzeak [`String`] bufferra kudeatzeko erantzukizuna bikoiztuko luke, doako bikoitza lortuz.
///
/// Azken kasua orokortuz, [`Drop`] inplementatzen duen edozein motak ezin du `Copy` izan, baliabide batzuk kudeatzen baititu bere [`size_of::<T>`] byteez gain.
///
/// `Kopiatu 'datuak ez dituen egitura edo enum batean `Copy` ezartzen saiatzen bazara, [E0204] errorea lortuko duzu.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Noiz *nire* motak `Copy` izan behar du?
///
/// Orokorrean, zure _can_ motak `Copy` ezartzen badu, hala beharko luke.
/// Gogoan izan, ordea, `Copy` ezartzea zure motako API publikoaren parte dela.
/// Mota future-n "Kopiatu" ez bada, zuhurra izan daiteke `Copy` inplementazioa orain ez betetzea, API aldaketa haustea ekiditeko.
///
/// ## Inplementatzaile osagarriak
///
/// [implementors listed below][impls] az gain, mota hauek `Copy` ere ezartzen dute:
///
/// * Funtzio elementu motak (hau da, funtzio bakoitzerako definitutako mota desberdinak)
/// * Funtzio erakusle motak (adibidez, `fn() -> i32`)
/// * Array motak, tamaina guztietarako, elementu motak `Copy` ere inplementatzen badu (adibidez, `[i32; 123456]`)
/// * Tuple motak, osagai bakoitzak `Copy` ere inplementatzen badu (adibidez, `()`, `(i32, bool)`)
/// * Itxiera motak, ingurunetik baliorik hartzen ez badute edo harrapatutako balio guztiek `Copy` beraiek ezartzen badute.
///   Kontuan izan erreferentzia partekatuaren bidez harrapatutako aldagaiek `Copy` inplementatzen dutela beti (erreferenteak ez badu ere), aldiz, aldagai diren erreferentzien bidez harrapatutako aldagaiek ez dute inoiz `Copy` gauzatzen.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Horrek `Copy` inplementatzen ez duen mota bat kopiatzea ahalbidetzen du pozik ez dauden bizitza mugak direla eta (`A<'_>` kopiatzea `A<'static>: Copy` eta `A<'_>: Clone` soilik denean).
// Atributu hau oraingoz hemen daukagu, dagoeneko liburutegi estandarrean existitzen diren `Copy`-en espezializazio ugari daudelako, eta portaera hori segurtasunez izateko modurik ez dagoelako oraintxe bertan.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Eraman makroa trait `Copy` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Hari artean erreferentziak partekatzea segurua den motak.
///
/// trait hau automatikoki ezartzen da konpiladoreak egokia dela erabakitzen duenean.
///
/// Definizio zehatza hau da: `T` mota [`Sync`] da eta `&T` [`Send`] bada bakarrik.
/// Beste modu batera esanda, [undefined behavior][ub] (datu lasterketak barne) aukerarik ez badago `&T` erreferentziak harien artean pasatzean.
///
/// Espero zitekeen moduan, [`u8`] eta [`f64`] bezalako mota primitiboak denak [`Sync`] dira, eta, hala ere, horiek dituzten agregatu mota soilak dira, tupluak, egiturak eta enumak bezalakoak.
/// [`Sync`] oinarrizko moten adibide gehiago `&T` bezalako "immutable" motak eta herentziazko aldakortasun sinplea dutenak, hala nola [`Box<T>`][box], [`Vec<T>`][vec] eta beste bilduma mota gehienak.
///
/// (Parametro generikoek [`Sync`] izan behar dute edukiontzia [`Sync`] izan dadin.)
///
/// Definizioaren ondorio harrigarria da `&mut T` `Sync` dela (`T` `Sync` bada) nahiz eta horrek sinkronizatu gabeko mutazioa eman dezakeela.
/// Trikimailua da erreferentzia partekatu baten atzean dagoen erreferentzia aldakorra (hau da, `& &mut T`) irakurtzeko soilik bihurtzen dela, `& &T` bat balitz bezala.
/// Beraz, ez dago datu lasterketa arriskurik.
///
/// `Sync` ez diren motak haririk gabeko segurtasunean "interior mutability" dutenak dira, hala nola [`Cell`][cell] eta [`RefCell`][refcell].
/// Mota hauek beren edukia mutatzea ahalbidetzen dute erreferentzia aldaezin eta partekatu baten bidez.
/// Adibidez `set` metodoan [`Cell<T>`][cell] metodoak `&self` hartzen du, beraz [`&Cell<T>`][cell] erreferentzia partekatua bakarrik eskatzen du.
/// Metodoak ez du sinkronizaziorik egiten, beraz [`Cell`][cell] ezin da `Sync` izan.
///
/// `Sync` ez den beste adibide bat [`Rc`][rc] erreferentzia-zenbaketa erakuslea da.
/// Edozein erreferentzia [`&Rc<T>`][rc] emanda, [`Rc<T>`][rc] berri bat klona dezakezu, erreferentzia kontuak modu ez atomikoan aldatuz.
///
/// Haririk gabeko barruko aldagarritasuna behar duen kasuetarako, Rust-k [atomic data types] eskaintzen du, baita [`sync::Mutex`][mutex] eta [`sync::RwLock`][rwlock] bidezko blokeo esplizitua ere.
/// Mota hauek bermatzen dute edozein mutaziok ezin duela datu lasterketarik eragin, beraz motak `Sync` dira.
/// Era berean, [`sync::Arc`][arc]-k haririk gabeko [`Rc`][rc]-ren analogikoa eskaintzen du.
///
/// Barruko aldakortasuna duten edozein motek [`cell::UnsafeCell`][unsafecell] biltzailea erabili behar dute value(s) inguruan, erreferentzia partekatu baten bidez alda daitekeena.
/// Hori egin ezean [undefined behavior][ub] da.
/// Adibidez, [`transmute`][transmute] `&T`-tik `&mut T`-ra jotzea baliogabea da.
///
/// Ikus [the Nomicon][nomicon-send-and-sync] `Sync`-i buruzko xehetasun gehiago lortzeko.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Behin `rustc_on_unimplemented` oharrak gehitzeko laguntza beta bertsioan, eta itxiera bat baldintza katean dagoen ala ez egiaztatzeko luzatu da, luzatu (#48534) gisa:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" duten `T` bat duten gauzak markatzeko erabiltzen den zero tamainako mota.
///
/// Zure motari `PhantomData<T>` eremua gehitzeak konpiladoreari esaten dio zure motak `T` motako balioa gordetzen duela bezala jokatzen duela, benetan ez den arren.
/// Informazio hori segurtasun propietate batzuk kalkulatzerakoan erabiltzen da.
///
/// `PhantomData<T>` nola erabili jakiteko azalpen sakonagoa lortzeko, ikus [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Ohar lazgarria 👻👻👻
///
/// Biek izen beldurgarriak dituzten arren, `PhantomData` eta "fantasma motak" erlazionatuta daude, baina ez dira berdinak.Fantasma motaren parametroa sekula erabiltzen ez den motako parametroa da.
/// Rust-n, horrek askotan konpiladorea kexatzen du eta konponbidea "dummy" erabilera `PhantomData` bidez gehitzea da.
///
/// # Examples
///
/// ## Erabili gabeko bizitzako parametroak
///
/// Agian, `PhantomData`-ren erabilera kasu ohikoena erabili gabeko bizitzako parametroa duen egitura da, normalean segurtasunik gabeko kode batzuen zati gisa.
/// Adibidez, hona hemen `Slice` egitura bat, `*const T` motako bi erakusleak dituena, ustez matrize batera nonbait seinalatzen duena:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Asmoa da azpiko datuek `'a` bizitza osorako soilik balio izatea, beraz, `Slice`-k ez du `'a` bizirik iraun behar.
/// Hala ere, asmo hori ez da kodean adierazten, ez baitago `'a` bizitzako erabilerarik eta, beraz, ez dago argi zein daturi aplikatzen zaien.
/// Hau zuzendu dezakegu konpiladoreari *jokatzeko esanez*`Slice` egiturak `&'a T` erreferentzia bat balu bezala:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Honek, aldi berean, `T: 'a` oharra eskatzen du, `T`-en erreferentzia guztiak `'a` osoan zehar baliozkoak direla adieraziz.
///
/// `Slice` hasieratzerakoan `PhantomData` balioa eman besterik ez duzu `phantom` eremurako:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Erabilitako motaren parametroak
///
/// Batzuetan gertatzen da erabili gabeko motako parametroak dituztela, egitura bat "tied" zein datu mota den adierazten duten arren, datu horiek egituran bertan aurkitzen ez diren arren.
/// Hona hemen [FFI]-rekin sortzen den adibidea.
/// Atzerriko interfazeak `*mut ()` motako heldulekuak erabiltzen ditu mota desberdinetako Rust balioak aipatzeko.
/// Rust motaren jarraipena egiten dugu heldulekua biltzen duen struct `ExternalResource` egituran fantasma mota parametroa erabiliz.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Jabetza eta jaitsiera egiaztapena
///
/// `PhantomData<T>` motako eremua gehitzeak zure motak `T` motako datuak dituela adierazten du.Horrek esan nahi du zure mota jaisten denean `T` motako instantzia bat edo gehiago eror daitezkeela.
/// Horrek eragina du Rust konpilatzailearen [drop check] analisian.
///
/// Zure egitura, egia esan,*`T` motako datuen* jabe ez bada, hobe da erreferentzia mota bat erabiltzea, `PhantomData<&'a T>` (ideally) edo `PhantomData<*const T>` bezalakoak (bizitza osorik aplikatzen ez bada), jabetza ez adierazteko.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Konpilatzailearen barneko trait enum diskriminatzaile mota adierazteko erabiltzen da.
///
/// trait hau automatikoki inplementatzen da mota guztietarako eta ez dio inolako bermerik gehitzen [`mem::Discriminant`]-ri.
/// **Definitu gabeko portaera** da `DiscriminantKind::Discriminant` eta `mem::Discriminant` artean transmutatzea.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Diskriminatzailearen mota, `mem::Discriminant`-k eskatzen duen trait bounds bete behar duena.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Konpiladorearen barneko trait mota batek barnean `UnsafeCell` duen ala ez zehazteko erabiltzen da, baina ez indirekzio baten bidez.
///
/// Horrek eragiten du, adibidez, mota horretako `static` irakurtzeko soilik den memoria estatikoan edo idazteko memoria estatikoan jartzen den.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Ainguratu ondoren segurtasunez mugi daitezkeen motak.
///
/// Rust-k berak ez du mota mugiezinen noziorik eta mugimenduak (adibidez, esleipen bidez edo [`mem::replace`]) beti seguruak direla uste du.
///
/// [`Pin`][Pin] mota erabiltzen da mota sisteman mugimenduak ekiditeko.[`Pin<P<T>>`][Pin] bilgailuan bildutako `P<T>` erakusleak ezin dira atera.
/// Ikusi [`pin` module] dokumentazioa ainguratzeari buruzko informazio gehiago lortzeko.
///
/// `Unpin` trait `T`-erako ezartzeak mota ainguratzeko murrizketak altxatzen ditu eta, ondoren, `T` [`Pin<P<T>>`][Pin]-tik ateratzea ahalbidetzen du [`mem::replace`] bezalako funtzioekin.
///
///
/// `Unpin` ez du inolako ondoriorik ainguratutako datuetan.
/// Bereziki, [`mem::replace`]-k pozik mugitzen ditu `!Unpin` datuak (edozein `&mut T`-rekin funtzionatzen du, ez `T: Unpin` denean bakarrik).
/// Hala ere, ezin duzu [`mem::replace`] erabili [`Pin<P<T>>`][Pin] batean bildutako datuetan, ezin duzu horretarako behar duzun `&mut T` eskuratu, eta *hori* da sistema honek funtzionatzen duena.
///
/// Beraz, hau, adibidez, `Unpin` inplementatzen duten motetan bakarrik egin daiteke:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` deitzeko erreferentzia aldagarri bat behar dugu.
/// // Erreferentzia hori (implicitly) erabiliz lor dezakegu `Pin::deref_mut` deituz, baina hori posible da `String`-k `Unpin` inplementatzen duelako.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait hau ia mota guztietarako ezartzen da automatikoki.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` inplementatzen ez duen marka mota.
///
/// Mota batek `PhantomPinned` badu, lehenespenez ez du `Unpin` inplementatuko.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy`-ren inplementazioak mota primitiboetarako.
///
/// Rust-n deskribatu ezin diren inplementazioak `traits::SelectionContext::copy_clone_conditions()`-n inplementatzen dira `rustc_trait_selection`-n.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Partekatutako erreferentziak kopiatu daitezke, baina alda daitezkeen erreferentziak *ezin*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}