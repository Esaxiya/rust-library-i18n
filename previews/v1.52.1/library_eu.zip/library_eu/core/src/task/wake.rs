#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` batek zeregin exekutore baten inplementatzaileak [`Waker`] bat sortzea ahalbidetzen du esnatze portaera pertsonalizatua eskaintzen duena.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Datu erakusle batek eta X001ren portaera pertsonalizatzen duen [virtual function pointer table (vtable)][vtable] batek osatzen dute.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Datu erakuslea, exekutoreak eskatzen duen moduan datu arbitrarioak gordetzeko erabil daitekeena.
    /// Adibidez
    /// zereginarekin erlazionatutako `Arc` baterako mota ezabatutako erakuslea.
    /// Eremu honen balioa lehen parametro gisa vtable-ren parte diren funtzio guztietara pasatzen da.
    ///
    data: *const (),
    /// Waker honen portaera pertsonalizatzen duen funtzio birtualeko erakuslearen taula.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// `RawWaker` berria sortzen du emandako `data` erakuslea eta `vtable`.
    ///
    /// `data` erakuslea datu arbitrarioak gordetzeko erabil daiteke exekutoreak eskatzen duen moduan.Adibidez
    /// zereginarekin erlazionatutako `Arc` baterako mota ezabatutako erakuslea.
    /// Erakusle honen balioa lehen parametro gisa `vtable`-ren parte diren funtzio guztietara igaroko da.
    ///
    /// `vtable`-k X002-tik sortutako `Waker` baten portaera pertsonalizatzen du.
    /// `Waker`-eko eragiketa bakoitzeko, azpiko `RawWaker`-en `vtable`-en lotutako funtzioari deituko zaio.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// (vtable) funtzio birtualaren erakusle taula, [`RawWaker`] baten portaera zehazten duena.
///
/// Vtable barruko funtzio guztietara pasatutako erakuslea [`RawWaker`] objektu itxiko `data` erakuslea da.
///
/// Egitura honen barruko funtzioak [`RawWaker`] inplementazioaren barnetik behar bezala eraikitako [`RawWaker`] objektuaren `data` erakusleari deitzeko soilik daude pentsatuta.
/// Edozein funtzioetako bat `data` erakuslea erabiliz deitzeak zehaztu gabeko portaera eragingo du.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Funtzio honi [`RawWaker`] klonatzen denean deituko zaio, adibidez [`RawWaker`] gordetzen den [`Waker`] klonatzen denean.
    ///
    /// Funtzio hau ezartzeak [`RawWaker`] baten instantzia gehigarri honetarako eta lotutako zereginetarako beharrezkoak diren baliabide guztiak gorde behar ditu.
    /// `wake` emaitzarekin [`RawWaker`] deitzeak jatorrizko [`RawWaker`]-k esnatuko zuen zeregin beraren esnatzea eragin beharko luke.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Funtzio horri `wake` [`Waker`]-en deitzen denean deituko zaio.
    /// [`RawWaker`] honi lotutako zeregina esnatu behar du.
    ///
    /// Funtzio hau ezartzeak ziurtatu behar du [`RawWaker`] instantzia honekin eta lotutako zereginarekin lotutako baliabideak askatzen dituela.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Funtzio horri `wake_by_ref` [`Waker`]-en deitzen denean deituko zaio.
    /// [`RawWaker`] honi lotutako zeregina esnatu behar du.
    ///
    /// Funtzio hau `wake` ren antzekoa da, baina ez du emandako datu erakuslea kontsumitu behar.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Funtzio honi [`RawWaker`] erortzen denean deitzen zaio.
    ///
    /// Funtzio hau ezartzeak ziurtatu behar du [`RawWaker`] instantzia honekin eta lotutako zereginarekin lotutako baliabideak askatzen dituela.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// `RawWakerVTable` berria sortzen du emandako `clone`, `wake`, `wake_by_ref` eta `drop` funtzioetatik abiatuta.
    ///
    /// # `clone`
    ///
    /// Funtzio honi [`RawWaker`] klonatzen denean deituko zaio, adibidez [`RawWaker`] gordetzen den [`Waker`] klonatzen denean.
    ///
    /// Funtzio hau ezartzeak [`RawWaker`] baten instantzia gehigarri honetarako eta lotutako zereginetarako beharrezkoak diren baliabide guztiak gorde behar ditu.
    /// `wake` emaitzarekin [`RawWaker`] deitzeak jatorrizko [`RawWaker`]-k esnatuko zuen zeregin beraren esnatzea eragin beharko luke.
    ///
    /// # `wake`
    ///
    /// Funtzio horri `wake` [`Waker`]-en deitzen denean deituko zaio.
    /// [`RawWaker`] honi lotutako zeregina esnatu behar du.
    ///
    /// Funtzio hau ezartzeak ziurtatu behar du [`RawWaker`] instantzia honekin eta lotutako zereginarekin lotutako baliabideak askatzen dituela.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Funtzio horri `wake_by_ref` [`Waker`]-en deitzen denean deituko zaio.
    /// [`RawWaker`] honi lotutako zeregina esnatu behar du.
    ///
    /// Funtzio hau `wake` ren antzekoa da, baina ez du emandako datu erakuslea kontsumitu behar.
    ///
    /// # `drop`
    ///
    /// Funtzio honi [`RawWaker`] erortzen denean deitzen zaio.
    ///
    /// Funtzio hau ezartzeak ziurtatu behar du [`RawWaker`] instantzia honekin eta lotutako zereginarekin lotutako baliabideak askatzen dituela.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Zeregin asinkrono baten `Context`.
///
/// Gaur egun, `Context`-k uneko zeregina pizteko erabil dezakeen `&Waker`-era sartzeko balio du.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ziurtatu future-froga dugula bariantza aldaketen aurka, bizitza aldaezina izatera behartuz (argumentu-posizioko bizitzak kontrajarriak dira, itzulerako posizioko bizitzak, berriz, kobarianteak dira).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Sortu `Context` berria `&Waker` batetik.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Uneko zereginerako `Waker` erreferentzia itzultzen du.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` zeregin bat esnatzeko heldulekua da exekutatzaileari exekutatzeko prest dagoela jakinaraziz.
///
/// Helduleku honek [`RawWaker`] instantzia bat biltzen du, exekutorearen esnatze portaera zehazten duena.
///
///
/// [`Clone`], [`Send`] eta [`Sync`] ezartzen ditu.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Esnatu `Waker` honi lotutako zeregina.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Benetako esnatze deia funtzio birtualeko dei baten bidez delegatzen da exekutoreak definitzen duen inplementaziora.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ez deitu `drop` ri-waker `wake`-k kontsumituko du.
        crate::mem::forget(self);

        // SEGURTASUNA: hau segurua da, `Waker::from_raw` baita bide bakarra
        // `wake` eta `data` hasieratzeko erabiltzaileak `RawWaker` ren kontratua onartzen dela aitortu behar duela.
        //
        unsafe { (wake)(data) };
    }

    /// Esnatu `Waker` honi lotutako zeregina `Waker` kontsumitu gabe.
    ///
    /// Hau `wake` ren antzekoa da, baina baliteke zertxobait eraginkorragoa izatea jabetzako `Waker` eskuragarri dagoen kasuetan.
    /// Metodo hau `waker.clone().wake()` deitzea baino hobea izan behar da.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Benetako esnatze deia funtzio birtualeko dei baten bidez delegatzen da exekutoreak definitzen duen inplementaziora.
        //

        // SEGURTASUNA: ikusi `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true` itzultzen du `Waker` honek eta beste `Waker` batek zeregin bera esnatu badute.
    ///
    /// Funtzio hau ahalik eta ahaleginen arabera funtzionatzen du eta gezurrezkoa izan daiteke `Waker-ek zeregin bera esnatuko lukeenean ere.
    /// Hala ere, funtzio honek `true` itzultzen badu, `Waker`-ek zeregin bera esnatuko duela ziurtatuko da.
    ///
    /// Funtzio hau optimizatzeko erabiltzen da batez ere.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// `Waker` berria sortzen du [`RawWaker`]-tik.
    ///
    /// Itzulitako `Waker` ren portaera zehaztu gabe dago [[RawWaker`] eta [`RawWakerVTable`] dokumentazioetan zehaztutako kontratua onartzen ez bada.
    ///
    /// Beraz, metodo hau ez da segurua.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEGURTASUNA: hau segurua da, `Waker::from_raw` baita bide bakarra
            // `clone` eta `data` hasieratzeko erabiltzaileak [`RawWaker`] ren kontratua onartzen dela aitortu behar duela.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEGURTASUNA: hau segurua da, `Waker::from_raw` baita bide bakarra
        // `drop` eta `data` hasieratzeko erabiltzaileak `RawWaker` ren kontratua onartzen dela aitortu behar duela.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}