//! Panic laguntza liburutegi estandarrean.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic bati buruzko informazioa eskaintzen duen egitura.
///
/// `PanicInfo` egitura [`set_hook`] funtzioak ezarritako panic hook batera pasatzen da.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic-rekin lotutako karga itzultzen du.
    ///
    /// Hau normalean, baina ez beti, `&'static str` edo [`String`] izango da.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate-eko `panic!` makroa (ez `std`-ekoa) formateatze kate batekin eta argumentu osagarri batzuekin erabiltzen bada, mezu hori [`fmt::write`]-rekin adibidez erabiltzeko prest egongo da.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// panic jatorria duen kokapenari buruzko informazioa itzultzen du, eskuragarri badago.
    ///
    /// Gaur egun metodo honek [`Some`] itzuliko du beti, baina hori alda daiteke future bertsioetan.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Hau aldatzen bada batzuetan Bat ere ez itzultzeko,
        // aurre egin kasu horri std::panicking::default_hook eta std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ezin dugu downcast_ref: :<String>() hemen
        // String ez dago libcore-n erabilgarri!
        // Karga erabilgarria da `std::panic!` argumentu anitzekin deitzen denean String bat, baina kasu horretan mezua ere eskuragarri dago.
        //

        self.location.fmt(formatter)
    }
}

/// panic baten kokapenari buruzko informazioa duen egitura.
///
/// Egitura hau [`PanicInfo::location()`]-k sortu du.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Berdintasunaren eta ordenazioaren alderaketak fitxategian, lerroan eta gero zutabearen lehentasunean egiten dira.
/// Fitxategiak kate gisa konparatzen dira, ez `Path`, ustekabeak izan daitezkeenak.
/// Ikusi [`Kokapena: : fitxategia`] dokumentazioa eztabaida gehiagorako.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Funtzio honen deitzailearen jatorrizko kokapena itzultzen du.
    /// Funtzio horren deitzailea ohartarazten bada, bere deiaren kokapena itzuliko da, eta horrela jarraituko du pilak jarraipena egin ez duen funtzio gorputz bateko lehen deira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Deitzen zaion [`Location`] itzultzen du.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// [`Location`] bat ematen du funtzio honen definizioaren barnetik.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // Jarraipenik gabeko funtzio bera beste kokapen batean exekutatzeak emaitza bera ematen digu
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // jarraipenaren funtzioa beste kokapen batean exekutatzeak beste balio bat sortzen du
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic jatorria duen iturburu fitxategiaren izena itzultzen du.
    ///
    /// # `&str`, ez `&Path`
    ///
    /// Itzulitako izenak konpilazio sistemako iturburu bide bati egiten dio erreferentzia, baina ez du balio hau zuzenean `&Path` gisa adierazteko.
    /// Konpilatutako kodea edukia eskaintzen duen sistemak baino `Path` inplementazio ezberdineko beste sistema batean exekutatu daiteke eta liburutegi honek ez du "host path" motarik.
    ///
    /// Jokabide harrigarriena "the same" fitxategia moduluko sistemako bide anitzen bidez eskuratzean gertatzen da (normalean `#[path = "..."]` atributua edo antzekoa erabiliz), eta horrek kode berdina dirudienak funtzio horretatik balio desberdinak itzultzea eragin dezake.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Balio hau ez da egokia `Path::new` edo antzeko eraikitzaileei pasatzeko ostalari plataforma eta xede plataforma desberdinak direnean.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic jatorria duen lerro zenbakia itzultzen du.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic jatorria duen zutabea itzultzen du.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd-k erabiltzen duen barne trait libstd-tik datuak `panic_unwind`-ra eta beste panic exekuzioetara pasatzeko.
/// Ez da laster egonkortzeko asmorik, ez erabili.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Jabetu edukien jabetza osoa.
    /// Itzulera mota benetan `Box<dyn Any + Send>` da, baina ezin dugu `Box` libcore-n erabili.
    ///
    /// Metodo honi deitu ondoren, `self`-n balio lehenetsi fintzi batzuk baino ez dira geratzen.
    /// Metodo honi bi aldiz deitzea edo metodo honi deitu ondoren `get` deitzea akatsa da.
    ///
    /// Argudioa maileguan hartu da, panic exekuzio denborak (`__rust_start_panic`)-k `dyn BoxMeUp` mailegatutakoa soilik lortzen duelako.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Edukiak maileguan hartu.
    fn get(&mut self) -> &(dyn Any + Send);
}