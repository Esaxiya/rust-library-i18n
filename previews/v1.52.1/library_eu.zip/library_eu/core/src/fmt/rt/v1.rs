//! Ifmt!-Ek erabiltzen duen barne modulua da hau.exekutatzeko denbora.Egitura hauek matrize estatikoetara igortzen dira formatu kateak aldez aurretik konpilatzeko.
//!
//! Definizio hauek `ct` baliokideen antzekoak dira, baina desberdinak dira estatikoki esleitu daitezkeelako eta exekuziorako zertxobait optimizatuta daude.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Formatu zuzentarauaren zati gisa eska daitezkeen lerrokatze posibleak.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Edukiak ezkerretara lerrokatuta egon behar direla adierazten du.
    Left,
    /// Edukiak eskuinera lerrokatuta egon behar direla adierazten du.
    Right,
    /// Edukiak erdiraino lerrokatuta egon behar direla adierazten du.
    Center,
    /// Ez da lerrokadurarik eskatu.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) eta [precision](https://doc.rust-lang.org/std/fmt/#precision) zehaztzaileek erabiltzen dute.
#[derive(Copy, Clone)]
pub enum Count {
    /// Zenbaki literal batekin zehaztutako balioa gordetzen du
    Is(usize),
    /// `$` eta `*` sintaxiak erabiliz zehaztuta, aurkibidea `args` n gordetzen du
    Param(usize),
    /// Zehaztu gabea
    Implied,
}