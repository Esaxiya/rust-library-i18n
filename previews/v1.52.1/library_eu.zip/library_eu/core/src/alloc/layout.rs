use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Funtzio hau leku bakarrean erabiltzen bada eta bere inplementazioa txertatu daitekeen arren, aurreko saiakerek rustc moteldu egin zuten:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Memoria bloke baten diseinua.
///
/// `Layout`-ren instantzia batek memoriaren diseinu jakin bat deskribatzen du.
/// `Layout` bat sortzen duzu esleitzaile bati emateko sarrera gisa.
///
/// Diseinu guztiek tamaina eta bi potentzia lerrokatuta dituzte.
///
/// (Kontuan izan diseinuek ez dutela * tamaina nulua izan beharrik, `GlobalAlloc`-k memoria eskaera guztiak tamaina zero ez izatea eskatzen duen arren.
/// Deitzaile batek ziurtatu behar du horrelako baldintzak betetzen direla, baldintza lasaiagoak dituzten esleitzaile espezifikoak erabili edo `Allocator` interfaze arinagoa erabili.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // eskatutako memoria blokearen tamaina, byteetan neurtuta.
    size_: usize,

    // eskatutako memoria blokearen lerrokatzea, byteetan neurtuta.
    // hori beti bi-potentzia dela ziurtatzen dugu, `posix_memalign` bezalako APIek hala eskatzen dutelako eta Layout konstruktoreei inposatzea arrazoizko muga delako.
    //
    //
    // (Hala ere, ez dugu modu analogikoan `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) behar
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// `Layout` bat sortzen du `size` eta `align` jakin batzuetatik abiatuta, edo `LayoutError` itzultzen du baldintza hauetakoren bat betetzen ez bada:
    ///
    /// * `align` ez du zero izan behar,
    ///
    /// * `align` bi potentzia izan behar du,
    ///
    /// * `size`, `align`-ren multiplo hurbilenera biribiltzen denean, ez da gainezka egin behar (hau da, balio biribilak `usize::MAX`-ren berdina edo txikiagoa izan behar du).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (biren potentziak lerrokatzea dakar!=0.)

        // Tamaina biribildua hau da:
        //   size_rounded_up=(tamaina + lerrokatu, 1)&! (lerrokatu, 1);
        //
        // Goitik dakigu lerrokatze hori!=0.
        // Gehitzea (lerrokatu, 1) gainezka egiten ez bada, ondo biribiltzea ondo egongo da.
        //
        // Aldiz,&-masking-ekin! (Align, 1) ordena baxuko bitak bakarrik kenduko ditu.
        // Beraz, baturarekin gainezkapena gertatzen bada,&-maskarak ezin du nahikoa kendu gainezkatze hori desegiteko.
        //
        //
        // Goian aipatzen da batuketaren gainezkatzea egiaztatzea beharrezkoa eta nahikoa dela.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEGURTASUNA: `from_size_align_unchecked` baldintzak izan dira
        // goian egiaztatu da.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Diseinu bat sortzen du, egiaztapen guztiak saihestuz.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua, ez baititu [`Layout::from_size_align`]-ren aurrebaldintzak egiaztatzen.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURTASUNA: deitzaileak `align` zero baino handiagoa dela ziurtatu behar du.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Diseinu honetako memoria bloke baterako bytetako gutxieneko tamaina.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Diseinu honetako memoria bloke baterako gutxieneko lerrokadura.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// X001 motako balioa edukitzeko egokia den `Layout` eraikitzen du.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEGURTASUNA: lerrokatzea Rust-k bermatzen du bi potentzia izateko
        // tamaina + lerrokatze konbinazioa bermatuta dago gure helbide espazioan sartzeko.
        // Ondorioz, erabili kontrolik gabeko eraikitzailea hemen, panics duten kodea nahikoa ondo optimizatuta ez badago txertatzeko.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-erako babes egitura esleitzeko erabil daitekeen erregistroa deskribatzen duen diseinua sortzen du (trait edo xerra bezalako tamaina gabeko beste mota bat izan daiteke).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURTASUNA: ikusi arrazoibidea `new` n zergatik erabiltzen den aldaera ez segurua
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-erako babes egitura esleitzeko erabil daitekeen erregistroa deskribatzen duen diseinua sortzen du (trait edo xerra bezalako tamaina gabeko beste mota bat izan daiteke).
    ///
    /// # Safety
    ///
    /// Funtzio hau deitzeko segurua da baldintza hauek betetzen badira:
    ///
    /// - `T` `Sized` bada, funtzio hau deitzeko segurua da beti.
    /// - `T` tamaina gabeko buztana hau bada:
    ///     - [slice] bat, xerra buztanaren luzerak zenbaki oso bat izan behar du eta * balio osoaren tamaina (buztana luzera dinamikoa + tamaina estatikoa aurrizkia) `isize`-n sartu behar da.
    ///     - [trait object] bat, orduan erakuslearen vtable zatiak tamaina gabeko kohesio baten bidez eskuratutako `T` motarako balio duen vtable bat seinalatu behar du eta * balio osoaren tamaina (buztana luzera dinamikoa + tamaina estatikoa aurrizkia) `isize`-n sartu behar da.
    ///
    ///     - (unstable) [extern type] bat, orduan funtzio hau deitzeko segurua da beti, baina panic edo bestela okerreko balioa itzul dezake, kanpoko motaren diseinua ez baita ezagutzen.
    ///     [`Layout::for_value`]-ren portaera bera da kanpoko motako buztana aipatzerakoan.
    ///     - bestela, modu kontserbadorean ez da onartzen funtzio horri deitzea.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEGURTASUNA: funtzio horien aurrebaldintzak deitzailearengana pasatzen ditugu
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURTASUNA: ikusi arrazoibidea `new` n zergatik erabiltzen den aldaera ez segurua
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Diseinu honetarako zintzilik dagoen baina ondo lerrokatuta dagoen `NonNull` bat sortzen du.
    ///
    /// Kontuan izan erakuslearen balioak balizko erakusle bat izan daitekeela, hau da, ez da "not yet initialized" sentinela balio gisa erabili behar.
    /// Alferki esleitzen dituzten motek hasieraren jarraipena beste bide batzuekin egin behar dute.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEGURTASUNA: lerrokatzea zero ez dela bermatuko da
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` ren diseinu bereko balioa eduki dezakeen erregistroa deskribatzen duen diseinua sortzen du, baina `align` lerrokadurara lerrokatuta dago (byteetan neurtuta).
    ///
    ///
    /// `self`-k agindutako lerrokadura betetzen badu, `self` itzultzen du.
    ///
    /// Kontuan izan metodo honek tamaina orokorrari ez diola betegarria gehitzen, itzulitako diseinuak beste lerrokadura bat duen ala ez kontuan hartu gabe.
    /// Beste modu batera esanda, `K`-k 16 tamaina badu, `K.align_to(32)`-k *oraindik* 16 tamaina izango du.
    ///
    /// Errore bat ematen du `self.size()` eta emandako `align` konbinazioak [`Layout::from_size_align`] zerrendatutako baldintzak urratzen baditu.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// `self` ondoren sartu behar dugun betegarria itzultzen du helbide honek `align` (byteetan neurtuta) beteko duela ziurtatzeko.
    ///
    /// Adibidez, `self.size()` 9 bada, `self.padding_needed_for(4)`-k 3 itzultzen du, hori delako 4 lerrokatutako helbidea lortzeko behar den betegarriaren gutxieneko byte kopurua (dagokion memoria blokea 4 lerrokatutako helbidean hasten dela suposatuz).
    ///
    ///
    /// Funtzio honen itzultzeak ez du esanahirik `align` bi-potentzia ez bada.
    ///
    /// Kontuan izan itzultzen den balioaren erabilgarritasunak `align` hasierako helbidearen lerrokatzea baino txikiagoa edo berdina izatea eskatzen duela esleitutako memoria bloke osorako.Murrizketa hori asetzeko modu bat `align <= self.align()` ziurtatzea da.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Balio biribildua hau da:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // eta gero betegarrien aldea itzuliko dugu: `len_rounded_up - len`.
        //
        // Aritmetika modularra erabiltzen dugu zehar:
        //
        // 1. align ziurtatuta dago> 0 izango dela eta, beraz, align 1 balio du beti.
        //
        // 2.
        // `len + align - 1` gehienez `align - 1` gainezka daiteke, beraz, `!(align - 1)`-rekin&-maskarak gainezkatzearen kasuan `len_rounded_up` bera 0 izango dela ziurtatuko du.
        //
        //    Horrela itzulitako betegarriak, `len`-ra gehitzen denean, 0 ematen du, `align` lerrokadura modu hutsean betetzen duena.
        //
        // (Noski, aurreko tamainako tamaina eta betegarria gainezka duten memoria blokeak esleitzen saiatzeak esleitzaileak errore bat izan beharko luke hala ere).
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Diseinua sortzen du diseinu horren tamaina diseinuaren lerrokaduraren multiplo batera biribilduz.
    ///
    ///
    /// Hau `padding_needed_for`-ren emaitza diseinuaren uneko tamainari gehitzearen baliokidea da.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Honek ezin du gainezka egin.Diseinuaren aldaezina aipatuz:
        // > `size`, `align` ren multiplo hurbilenera biribiltzen denean,
        // > ez du gainezka egin behar (hau da, biribildutako balioa
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self`-ren `n` instantziaren erregistroa deskribatzen duen diseinua sortzen du, betegarri kopuru egokiarekin bakoitzaren artean instantzia bakoitzari eskatutako tamaina eta lerrokadura ematen zaiola ziurtatzeko.
    /// Arrakastatsua bada, `(k, offs)` itzultzen du, non `k` array-aren diseinua den eta `offs` array-aren elementu bakoitzaren hasieraren arteko distantzia.
    ///
    /// Aritmetika gainezkatzean, `LayoutError` itzultzen du.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Honek ezin du gainezka egin.Diseinuaren aldaezina aipatuz:
        // > `size`, `align` ren multiplo hurbilenera biribiltzen denean,
        // > ez du gainezka egin behar (hau da, biribildutako balioa
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEGURTASUNA: self.align dagoeneko ezaguna da baliozkoa eta alloc_size izan da
        // betea dagoeneko.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` ren erregistroa deskribatzen duen diseinua sortzen du eta ondoren `next`-koa, beharrezko betegarriak barne, `next` behar bezala lerrokatuta egongo dela ziurtatzeko, baina *betiko betegarririk ez*.
    ///
    /// C irudikapenaren `repr(C)` diseinuarekin bat etortzeko, diseinua eremu guztiekin zabaldu ondoren `pad_to_align` deitu beharko zenuke.
    /// (Ez dago 0Rust irudikapenaren diseinu lehenetsia `repr(Rust)`, as it is unspecified.) bat etortzeko modurik
    ///
    /// Kontuan izan, lortutako diseinuaren lerrokadura `self` eta `next` ren gehienekoa izango dela, bi zatien lerrokatzea ziurtatzeko.
    ///
    /// `Ok((k, offset))` itzultzen du, non `k` kateatutako erregistroaren diseinua den eta `offset` kokapen erlatiboa, byteetan, kateatutako erregistroan txertatutako `next` aren hasieraren hasieran (erregistroa bera 0 desplazamenduan hasten dela suposatuz).
    ///
    ///
    /// Aritmetika gainezkatzean, `LayoutError` itzultzen du.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` egitura baten diseinua eta eremuen desplazamenduak bere eremuen diseinutik kalkulatzeko:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Gogoratu `pad_to_align`-rekin amaitzea!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // probatu funtzionatzen duela
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self`-ren `n` instantziaren erregistroa deskribatzen duen diseinua sortzen du, instantzia bakoitzaren artean betegarririk gabe.
    ///
    /// Kontuan izan, `repeat`-ek ez bezala, `repeat_packed`-k ez duela bermatzen `self`-ren behin eta berriz errepikatzen diren kasuak behar bezala lerrokatuko direnik, `self`-ren instantzia jakin bat behar bezala lerrokatuta badago ere.
    /// Beste modu batera esanda, `repeat_packed`-k itzultzen duen diseinua array bat esleitzeko erabiltzen bada, ez dago ziurtatuta arrayko elementu guztiak lerrokatuta egongo direnik.
    ///
    /// Aritmetika gainezkatzean, `LayoutError` itzultzen du.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self`-ren erregistroa deskribatzen duen diseinua sortzen du eta ondoren `next`-ek biren arteko betegarri gehigarririk gabe.
    /// Betegarririk sartzen ez denez, `next`-ren lerrokadurak ez du garrantzirik eta ez da *batere* sartzen emaitza horren diseinuan.
    ///
    ///
    /// Aritmetika gainezkatzean, `LayoutError` itzultzen du.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` baten erregistroa deskribatzen duen diseinua sortzen du.
    ///
    /// Aritmetika gainezkatzean, `LayoutError` itzultzen du.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` edo beste `Layout` eraikitzaile bati emandako parametroek ez dituzte dokumentatutako mugak betetzen.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (hau behar dugu trait error downstream impl)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}