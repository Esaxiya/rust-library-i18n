//! Memoria esleitzeko APIak

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` erroreak esleitutako hutsegite bat adierazten du baliabideak agortzearen edo zerbait okerraren ondorioz izan daitekeena, emandako sarrera argumentuak esleitzaile honekin konbinatzean.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (hau behar dugu trait error downstream impl)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` inplementazio batek [`Layout`][] bidez deskribatutako datu bloke arbitrarioak banatu, hazi, txikitu eta banatu ditzake.
///
/// `Allocator` ZSTetan, erreferentzietan edo erakusle adimendunetan inplementatzeko diseinatuta dago, `MyAlloc([u8; N])` bezalako esleitzaile bat edukitzea ezin baita mugitu, erakusleak esleitutako memoriara eguneratu gabe.
///
/// [`GlobalAlloc`][] ez bezala, zero tamainako esleipenak onartzen dira `Allocator`-n.
/// Azpiko esleitzaile batek hau onartzen ez badu (jemalloc bezala) edo erakusle nulua itzultzen badu (adibidez, `libc::malloc`), inplementazioak harrapatu behar du.
///
/// ### Une honetan esleitutako memoria
///
/// Metodo batzuek memoria bloke bat *esleitu* behar da esleitzaile baten bidez.Horrek esan nahi du:
///
/// * memoria bloke horren hasierako helbidea aurretik [`allocate`], [`grow`] edo [`shrink`]-k itzuli zuen eta
///
/// * memoria blokea ez da gerora birkokatu, non blokeak zuzenean banatzen diren [`deallocate`]-ra pasatuz edo `Ok` itzultzen duen [`grow`] edo [`shrink`]-ra pasatuz aldatu ziren.
///
/// `grow` edo `shrink` `Err` itzuli badute, gainditutako erakusleak baliozko izaten jarraitzen du.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memoria egokitzea
///
/// Metodo batzuek diseinua *memoria* bloke batera egokitzea eskatzen dute.
/// "fit" rako diseinurako memoria bloke batek esan nahi duena da (edo baliokidetasunez, memoria bloke batek "fit" rako diseinua) esan nahi du baldintza hauek bete behar direla:
///
/// * Blokea [`layout.align()`] ren lerrokadura berdinarekin esleitu behar da eta
///
/// * Emandako [`layout.size()`] ak `min ..= max` tartean sartu behar du, non:
///   - `min` blokea esleitzeko erabili den diseinuaren tamaina da eta
///   - `max` [`allocate`], [`grow`] edo [`shrink`]-tik itzulitako azken benetako tamaina da.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Esleitzaile batetik itzultzen diren memoria blokeek baliozko memoria seinalatu behar dute eta beren baliozkotasuna mantendu instantzia eta bere klon guztiak erori arte.
///
/// * banatzailea klonatzeak edo mugitzeak ez ditu baliogabetu behar esleitzaile honetatik bueltan dauden memoria blokeak.Klonatutako esleitzaile batek esleitzaile berbera izan behar du eta
///
/// * memoria blokea den edozein erakusle [*currently allocated*] den esleitzailearen beste edozein metodoetara pasa daiteke.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Memoria bloke bat esleitzen saiatzen da.
    ///
    /// Arrakastatsua denean, [`NonNull<[u8]>`][NonNull] tamaina eta lerrokadura bermeekin bat datorren [`NonNull<[u8]>`][NonNull] itzultzen du.
    ///
    /// Itzulitako blokeak `layout.size()`-k zehaztutakoa baino tamaina handiagoa izan dezake eta edukia hasieratuta eduki dezake edo ez.
    ///
    /// # Errors
    ///
    /// `Err` itzultzeak adierazten du memoria agortuta dagoela edo `layout` k ez dituela esleitzailearen tamaina edo lerrokatze mugak betetzen.
    ///
    /// Inplementazioak `Err` itzultzea gomendatzen zaie memoria agortzeagatik izutu edo bertan behera utzi beharrean, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` bezala jokatzen du, baina itzulitako memoria zero hasierakoa dela ere ziurtatzen du.
    ///
    /// # Errors
    ///
    /// `Err` itzultzeak adierazten du memoria agortuta dagoela edo `layout` k ez dituela esleitzailearen tamaina edo lerrokatze mugak betetzen.
    ///
    /// Inplementazioak `Err` itzultzea gomendatzen zaie memoria agortzeagatik izutu edo bertan behera utzi beharrean, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEGURTASUNA: `alloc`-k baliozko memoria bloke bat itzultzen du
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr`-ek aipatzen duen memoria banatzen du.
    ///
    /// # Safety
    ///
    /// * `ptr` [*currently allocated*] memoria bloke bat adierazi behar du esleitzaile honen bidez, eta
    /// * `layout` memoria bloke hori [*fit*] behar du.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Memoria blokea zabaltzen saiatzen da.
    ///
    /// Erakuslea eta esleitutako memoriaren benetako tamaina dituen [`NonNull<[u8]>`][NonNull] berria ematen du.Erakuslea egokia da `new_layout`-k deskribatutako datuak gordetzeko.
    /// Hori lortzeko, esleitzaileak `ptr`-k aipatzen duen esleipena diseinu berrira egokitzeko luzatu dezake.
    ///
    /// Honek `Ok` itzultzen badu, `ptr`-k aipatzen duen memoria blokearen jabetza esleitzaile honetara transferitu da.
    /// Baliteke memoria askatu edo ez izatea, eta erabilgarritzat jo beharko litzateke metodo honen itzulketaren balioaren bidez berriro deitzaileari transferitu ezean.
    ///
    /// Metodo honek `Err` itzultzen badu, memoria blokearen jabetza ez da esleitzaile honetara transferitu eta memoria blokearen edukia ez da aldatu.
    ///
    /// # Safety
    ///
    /// * `ptr` [*currently allocated*] memoria bloke bat adierazi behar du esleitzaile honen bidez.
    /// * `old_layout` memoria bloke hori [*fit*] behar du (`new_layout` argumentuak ez du zertan egokitu).
    /// * `new_layout.size()` `old_layout.size()` baino handiagoa edo berdina izan behar du.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` itzultzen du diseinu berriak esleitzailearen tamainaren eta lerrokaduraren murriztapenak betetzen ez baditu edo, bestela, hazteak huts egiten badu.
    ///
    /// Inplementazioak `Err` itzultzea gomendatzen zaie memoria agortzeagatik izutu edo bertan behera utzi beharrean, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURTASUNA: `new_layout.size()`-ek baino handiagoa edo berdina izan behar duelako
        // `old_layout.size()`, memoriaren esleipen zaharrak zein berriak baliozkoak dira `old_layout.size()` byteetarako irakurri eta idazteko.
        // Gainera, esleipen zaharra oraindik banatuta ez zegoenez, ezin da `new_ptr` gainjarri.
        // Horrela, `copy_nonoverlapping` rako deia segurua da.
        // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` bezala jokatzen du, baina, gainera, eduki berriak zeroan ezartzen direla ziurtatzen du itzuli aurretik.
    ///
    /// Memoria blokeak honako edukia izango du deia egin ondoren
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` byte-ak jatorrizko esleipenetik gordetzen dira.
    ///   * `old_layout.size()..old_size` byte-ak mantendu edo zeroan jarriko dira, esleitzailearen inplementazioaren arabera.
    ///   `old_size` `grow_zeroed` deiaren aurreko memoria blokearen tamaina aipatzen da, jatorriz esleitu zenean eskatutako tamaina baino handiagoa izan daiteke.
    ///   * `old_size..new_size` byte-ak zeroan jartzen dira.`new_size` `grow_zeroed` deiak itzultzen duen memoria blokearen tamainari dagokio.
    ///
    /// # Safety
    ///
    /// * `ptr` [*currently allocated*] memoria bloke bat adierazi behar du esleitzaile honen bidez.
    /// * `old_layout` memoria bloke hori [*fit*] behar du (`new_layout` argumentuak ez du zertan egokitu).
    /// * `new_layout.size()` `old_layout.size()` baino handiagoa edo berdina izan behar du.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` itzultzen du diseinu berriak esleitzailearen tamainaren eta lerrokaduraren murriztapenak betetzen ez baditu edo, bestela, hazteak huts egiten badu.
    ///
    /// Inplementazioak `Err` itzultzea gomendatzen zaie memoria agortzeagatik izutu edo bertan behera utzi beharrean, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEGURTASUNA: `new_layout.size()`-ek baino handiagoa edo berdina izan behar duelako
        // `old_layout.size()`, memoriaren esleipen zaharrak zein berriak baliozkoak dira `old_layout.size()` byteetarako irakurri eta idazteko.
        // Gainera, esleipen zaharra oraindik banatuta ez zegoenez, ezin da `new_ptr` gainjarri.
        // Horrela, `copy_nonoverlapping` rako deia segurua da.
        // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Memoria blokea txikitzen saiatzen da.
    ///
    /// Erakuslea eta esleitutako memoriaren benetako tamaina dituen [`NonNull<[u8]>`][NonNull] berria ematen du.Erakuslea egokia da `new_layout`-k deskribatutako datuak gordetzeko.
    /// Hori lortzeko, esleitzaileak `ptr`-k aipatzen duen esleipena txikitu dezake diseinu berrira egokitzeko.
    ///
    /// Honek `Ok` itzultzen badu, `ptr`-k aipatzen duen memoria blokearen jabetza esleitzaile honetara transferitu da.
    /// Baliteke memoria askatu edo ez izatea, eta erabilgarritzat jo beharko litzateke metodo honen itzulketaren balioaren bidez berriro deitzaileari transferitu ezean.
    ///
    /// Metodo honek `Err` itzultzen badu, memoria blokearen jabetza ez da esleitzaile honetara transferitu eta memoria blokearen edukia ez da aldatu.
    ///
    /// # Safety
    ///
    /// * `ptr` [*currently allocated*] memoria bloke bat adierazi behar du esleitzaile honen bidez.
    /// * `old_layout` memoria bloke hori [*fit*] behar du (`new_layout` argumentuak ez du zertan egokitu).
    /// * `new_layout.size()` `old_layout.size()` baino txikiagoa edo berdina izan behar du.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` itzultzen du diseinu berriak esleitzailearen tamainaren eta lerrokaduraren murriztapenak betetzen ez baditu edo bestela txikitzeak huts egiten badu.
    ///
    /// Inplementazioak `Err` itzultzea gomendatzen zaie memoria agortzeagatik izutu edo bertan behera utzi beharrean, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURTASUNA: `new_layout.size()` baino txikiagoa edo berdina izan behar delako
        // `old_layout.size()`, memoriaren esleipen zaharrak zein berriak baliozkoak dira `new_layout.size()` byteetarako irakurri eta idazteko.
        // Gainera, esleipen zaharra oraindik banatuta ez zegoenez, ezin da `new_ptr` gainjarri.
        // Horrela, `copy_nonoverlapping` rako deia segurua da.
        // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// "by reference" egokitzaile bat sortzen du `Allocator`-ren instantzia honetarako.
    ///
    /// Itzulitako egokitzaileak `Allocator` ere inplementatzen du eta hori maileguan hartuko du.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEGURTASUNA: deitzaileak segurtasun kontratua onartu beharko du
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURTASUNA: deitzaileak segurtasun kontratua onartu beharko du
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURTASUNA: deitzaileak segurtasun kontratua onartu beharko du
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURTASUNA: deitzaileak segurtasun kontratua onartu beharko du
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}