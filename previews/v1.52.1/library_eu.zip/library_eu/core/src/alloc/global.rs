use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// `#[global_allocator]` atributuaren bidez liburutegi estandarraren lehenetsi gisa erregistratu daitekeen memoria banatzailea.
///
/// Metodo batzuek memoria bloke bat *esleitu* behar da esleitzaile baten bidez.Horrek esan nahi du:
///
/// * memoria bloke horren hasierako helbidea aurreko dei batek `alloc` bezalako esleipen metodo batera itzuli zuen eta
///
/// * memoria blokea ez da gerora banatu, non blokeak banatu egiten diren `dealloc` bezalako deslokalizazio metodo batera pasatuz edo erakusle ez-nulua itzultzen duen birkokapen metodo batera pasatuz.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait `unsafe` trait da hainbat arrazoirengatik, eta inplementatzaileek kontratu hauetara atxikitzen direla ziurtatu behar dute:
///
/// * Definitu gabeko portaera da esleitzaile orokorrak desegiten badira.Murrizketa hau future-en kendu daiteke, baina gaur egun funtzio hauetako edozein panic memoriak segurtasunik eza ekar dezake.
///
/// * `Layout` kontsultek eta orokorrean kalkuluek zuzenak izan behar dute.trait honetako deitzaileek metodo bakoitzean definitutako kontratuetan oinarritzea baimentzen dute eta inplementatzaileek kontratu horiek egiazkoak direla ziurtatu behar dute.
///
/// * Agian ez zara benetan gertatzen ari diren esleipenetan oinarrituko, nahiz eta iturburuan muntaketa esplizituak egon.
/// Optimizatzaileak erabat ezabatu edo pilara mugi ditzakeen erabilerarik gabeko esleipenak hauteman ditzake eta, beraz, ez du inoiz esleitzailea deitu.
/// Optimizatzaileak esleipena hutsezina dela pentsa dezake, beraz esleitzailearen hutsegiteengatik huts egiten zuen kodigoak bat-batean funtziona dezake, optimizatzaileak esleipenaren beharraren inguruan lan egiten baitzuen.
/// Zehatzago esanda, honako kode adibidea ez da egokia, zure esleitzaile pertsonalizatuak zenbat esleipen gertatu diren kontatzea baimendu ala ez.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Kontuan izan goian aipatutako optimizazioak ez direla aplika daitezkeen optimizazio bakarrak.Baliteke, oro har, ez dituzula konfiantzazko muntaketetan oinarrituko programaren portaera aldatu gabe kentzen badira.
///   Esleipenak gertatu edo ez programaren portaeraren zati bat ez bada ere, esleipenak inprimatuz edo albo-efektuak izanez gero jarraipena egiten duen esleitzaile baten bidez antzeman liteke.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Esleitu memoria emandako `layout`-k deskribatutako moduan.
    ///
    /// Erakusle bat esleitu berri den memoriara itzultzen du, edo nulua esleipenaren porrota adierazteko.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua, zehaztu gabeko portaera sor daitekeelako deitzaileak `layout` zero ez den tamaina duela ziurtatzen ez badu.
    ///
    /// (Luzapenen azpitratuek portaeraren muga zehatzagoak eman ditzakete, adibidez, zentinelaren helbidea edo erakusle nulua bermatu zero tamainako esleipen eskaerari erantzunez).
    ///
    /// Esleitutako memoria blokea hasieratu daiteke edo ez.
    ///
    /// # Errors
    ///
    /// Erakusle nulua itzultzeak adierazten du memoria agortuta dagoela edo `layout`-ek ez dituela esleitzaile honen tamaina edo lerrokatze mugak betetzen.
    ///
    /// Inplementazioak animatu beharrean memoria agortzeagatik bueltan itzultzea gomendatzen da, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Banatu memoria blokea emandako `ptr` erakuslearen emandako `layout`-rekin.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua, zehaztu gabeko portaera sor daitekeelako deitzaileak honako hauek guztiak ziurtatzen ez baditu:
    ///
    ///
    /// * `ptr` esleitzaile honen bidez esleitutako memoria bloke bat adierazi behar du,
    ///
    /// * `layout` memoria bloke hori esleitzeko erabili zen diseinu bera izan behar du.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// `alloc` bezala jokatzen du, baina edukia itzuli aurretik ere zeroan ezartzen dela ziurtatzen du.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua `alloc` aren arrazoi berdinengatik.
    /// Hala ere, esleitutako memoria blokea hasierakoa izango dela bermatuta dago.
    ///
    /// # Errors
    ///
    /// Erakusle nulua itzultzeak adierazten du memoria agortuta dagoela edo `layout` k ez dituela esleitzailearen tamaina edo lerrokatze mugak betetzen, `alloc` n bezala.
    ///
    /// Esleipen akats baten aurrean konputazioa abortatu nahi duten bezeroei X001 funtziora deitzera animatu behar dira `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURTASUNA: deitzaileak `alloc` ren segurtasun kontratua onartu beharko du.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEGURTASUNA: esleipenak arrakasta izan zuenez, eskualdea `ptr`-tik aurrera
            // `size` tamainakoa da idazketetarako balio duela.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Txikitu edo handitu memoria bloke bat emandako `new_size`-ra.
    /// Blokea emandako `ptr` erakusleak eta `layout`-k deskribatzen dute.
    ///
    /// Horrek erakusle ez-nulua itzultzen badu, `ptr`-k aipatzen duen memoria blokearen jabetza esleitzaile honetara transferitu da.
    /// Memoria birkokatu egin daiteke edo ez da erabilgarritzat jo (metodo honen itzulketaren balioaren bidez berriro deitzaileari transferitu ez bazaio, noski).
    /// Memoria bloke berria `layout`-rekin esleitzen da, baina `size` `new_size`-era eguneratuta.
    /// Diseinu berri hau `dealloc`-rekin memoria bloke berria banatzerakoan erabili behar da.
    /// Memoria bloke berriaren `0..min(layout.size(), new_size) `barrutiak jatorrizko blokearen balio berak izango dituela ziurtatzen da.
    ///
    /// Metodo hau nulua bada, memoria blokearen jabetza ez da esleitzaile honetara transferitu eta memoria blokearen edukia ez da aldatu.
    ///
    /// # Safety
    ///
    /// Funtzio hau ez da segurua, zehaztu gabeko portaera sor daitekeelako deitzaileak honako hauek guztiak ziurtatzen ez baditu:
    ///
    /// * `ptr` esleitzaile honen bidez esleitu behar da,
    ///
    /// * `layout` memoria bloke hori esleitzeko erabili zen diseinu bera izan behar du,
    ///
    /// * `new_size` zero baino handiagoa izan behar du.
    ///
    /// * `new_size`, `layout.align()`-ren multiplo hurbilenera biribildutakoan ezin da gainezka egin (hau da, balio biribilduak `usize::MAX` baino txikiagoa izan behar du).
    ///
    /// (Luzapenen azpitratuek portaeraren muga zehatzagoak eman ditzakete, adibidez, zentinelaren helbidea edo erakusle nulua bermatu zero tamainako esleipen eskaerari erantzunez).
    ///
    /// # Errors
    ///
    /// Null itzultzen du diseinu berriak esleitzailearen tamainako eta lerrokadurako mugak betetzen ez baditu edo bestela birkokatzeak huts egiten badu.
    ///
    /// Inplementazioak animatu egiten dira memoria agortzeagatik itzultzea izutzea edo bertan behera uztea baino, baina ez da baldintza zorrotza.
    /// (Zehazki: * legezkoa da trait hau memoria agortzean abortatzen duen jatorrizko esleipen liburutegi baten gainean ezartzea.)
    ///
    /// Birkokapen akats baten aurrean kalkulua bertan behera utzi nahi duten bezeroei X001 funtziora deitzea gomendatzen zaie `panic!` edo antzekoa zuzenean deitu beharrean.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEGURTASUNA: deitzaileak `new_size` gailuak gainezka egiten ez duela ziurtatu behar du.
        // `layout.align()` `Layout` batetik dator eta, beraz, baliozkoa dela ziurtatzen da.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURTASUNA: deitzaileak `new_layout` zero baino handiagoa dela ziurtatu behar du.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEGURTASUNA: aurrez esleitutako blokeak ezin du esleitu berri den blokea gainjarri.
            // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}