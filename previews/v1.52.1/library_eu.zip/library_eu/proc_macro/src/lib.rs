//! Makro egileentzako laguntza liburutegia makro berriak definitzerakoan.
//!
//! Banaketa estandarrak eskaintzen duen liburutegi honek prozeduraz definitutako makro definizioen interfazeetan kontsumitutako motak eskaintzen ditu, hala nola funtzio moduko `#[proc_macro]` makroak, `#[proc_macro_attribute]` makro atributuak eta pertsonalizatutako atributuak eratorritako atributuak "#[proc_macro_derive]".
//!
//!
//! Ikusi [the book] gehiago lortzeko.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro unean martxan dagoen programarako eskuragarri jarri den zehazten du.
///
/// Proc_macro crate prozedura makroak inplementatzean soilik erabiltzeko pentsatuta dago.crate panic honetako funtzio guztiak prozedurazko makro batetik kanpora deitzen badira, esate baterako, build script edo unitate probatik edo Rust bitar arruntetik.
///
/// Erabilera makroak eta makroak ez diren kasuetarako onartzen dituzten Rust liburutegiak kontuan hartuta, `proc_macro::is_available()` ek izua ez duen modua eskaintzen du proc_macro APIa erabiltzeko behar den azpiegitura gaur egun eskuragarri dagoen ala ez hautemateko.
/// Egia ematen du prozedura makro baten barnetik deitzen bada, faltsua beste edozein binatik deituz gero.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// crate honek ematen duen mota nagusia, tokens korronte abstraktua irudikatzen duena edo, zehazkiago, token zuhaitzen sekuentzia.
/// Mota honek interfazeak eskaintzen ditu token zuhaitz horien gainean errepikatzeko eta, alderantziz, token zuhaitz batzuk korronte bakar batean biltzeko.
///
///
/// Hau da `#[proc_macro]`, `#[proc_macro_attribute]` eta `#[proc_macro_derive]` definizioen sarrera eta irteera.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Errorea `TokenStream::from_str`-tik itzuli da.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token zuhaitzik ez duen `TokenStream` huts bat itzultzen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// `TokenStream` hau hutsik dagoen egiaztatzen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Katea tokens sartu eta tokens horiek token korronte batean analizatzen saiatzen da.
/// Baliteke huts egitea hainbat arrazoirengatik, adibidez, kateak hizkuntzan existitzen ez diren mugatzaile desorekatuak edo karaktereak baldin baditu.
///
/// Analizatutako korrontean dauden tokens guztiek `Span::call_site()` tarteak lortzen dituzte.
///
/// NOTE: akats batzuek panics sor dezakete `LexError` itzuli beharrean.Akats horiek gero "LexError" bihurtzeko eskubidea gordetzen dugu.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token korrontea inprimatzen du galerarik gabeko bihur daitekeen kate gisa berriro token korronte berera (moduluko zabalerak), baliteke `TokenTree: : Group` `Delimiter::None` mugatzaileekin eta zenbaki literal negatiboekin izan ezik.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token inprimatzen du arazketarako egokia den inprimakian.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// token zuhaitz bakarra duen token korrontea sortzen du.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// token zuhaitz ugari biltzen ditu korronte bakarrean.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token korronteetan "flattening" eragiketa batek token zuhaitzak biltzen ditu token korronte anitzetatik korronte bakar batean.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Erabil ezazu optimizatutako if/when inplementazio posible bat.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` motako inplementazio publikoko xehetasunak, hala nola, iteratzaileak.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iteratzailea "TokenStream" en "TokenTree" ren inguruan.
    /// Errepikapena "shallow" da. Adibidez, errepikatzailea ez da talde mugatuetan errepikatzen, eta talde osoak token zuhaitz gisa itzultzen ditu.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tokens arbitrarioa onartzen du eta sarrera deskribatzen duen `TokenStream` batean zabaltzen da.
/// Adibidez, `quote!(a + b)`-k adierazpen bat sortuko du, ebaluatzerakoan `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Kotizazioa `$`-rekin egiten da, eta hurrengo identitate bakarra kotatu gabeko termino gisa hartuta funtzionatzen du.
/// `$` bera aipatzeko, erabili `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Iturburu kodearen eskualdea, makro hedapen informazioarekin batera.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `Diagnostic` berria sortzen du emandako `message` arekin `self` tartean.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Makro definizio gunean konpontzen den tartea.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Uneko makro prozesalaren deiaren tartea.
    /// Tarte honekin sortutako identifikatzaileak makro-deien kokalekuan (dei-gunearen higienea) zuzenean idatzita egongo balira bezala konponduko dira eta makro-deien gunean beste kode batzuk ere aipa ditzakete.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` higienea adierazten duen tarte bat, eta batzuetan makro definizio gunean (aldagai lokalak, etiketak, `$crate`) konpontzen dena eta batzuetan makro deien gunean (gainerako guztia) konpontzen dena.
    ///
    /// Tarte kokapena dei-gunetik hartzen da.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Tarte honek zuzentzen duen jatorrizko fitxategia.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// tokens-ren `Span` aurreko makro hedapenean `self`-tik sortu zen, halakorik balego.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` sortu zen jatorrizko iturburu kodearen tartea.
    /// `Span` hau beste makro hedapen batzuetatik sortu ez bada, bueltan dagoen balioa `*self` ren berdina da.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Hasierako line/column iturburu fitxategian lortzen du tarte honetarako.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Tarte honetako iturburuko fitxategian line/column amaiera lortzen du.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` eta `other` biltzen dituen tarte berria sortzen du.
    ///
    /// `None` ematen du `self` eta `other` fitxategi desberdinetakoak badira.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Tarte berri bat sortzen du line/column-ren line/column informazio berarekin, baina sinboloak `other`-en balitz bezala ebazten dituena.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Tarte berri bat sortzen du `self` izenaren bereizmen portaera berarekin baina `other` line/column informazioarekin.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Tarteekin alderatzen da berdinak diren ikusteko.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Iturri-testua itzultzen du tartearen atzean.
    /// Honek jatorrizko iturburu kodea gordetzen du, tarteak eta iruzkinak barne.
    /// Emaitza itzultzen du iturria benetako iturburu kodearekin bat badator.
    ///
    /// Note: Makro baten emaitza ikusgarria tokens-n bakarrik oinarritu behar da eta ez iturburu testu honetan.
    ///
    /// Funtzio horren emaitza diagnostikoetarako soilik erabiltzeko ahalegin onena da.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Arazoak inprimatzeko tartea arazteko egokia den moduan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` baten hasiera edo amaiera adierazten duen lerro-zutabe bikotea.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Tartea (inclusive) abiarazten edo amaitzen den iturburu fitxategiko 1 indexatutako lerroa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0 indexatutako zutabea (UTF-8 karaktereetan) tarteak (inclusive) hasi edo amaitzen duen iturburuko fitxategian.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// `Span` jakin baten iturburu fitxategia.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Iturburu fitxategi honetarako bidea lortzen du.
    ///
    /// ### Note
    /// `SourceFile` honi lotutako kode-tartea kanpoko makro batek sortu badu, makro hau, agian ez da fitxategi-sistemako benetako bidea izango.
    /// Erabili [`is_real`] egiaztatzeko.
    ///
    /// Kontuan izan ere, `is_real` `true` itzultzen badu ere, `--remap-path-prefix` komando lerroan pasatzen bada, emandako bideak agian ez du balio izango.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` itzultzen du iturburu fitxategi hau benetako iturburu fitxategia bada eta kanpoko makroaren hedapen batek sortua ez bada.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Hau hack bat da tartekatze tarteak inplementatu arte eta kanpoko makroetan sortutako tarteetarako benetako iturburu fitxategiak izan ditzakegu.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token bakar bat edo token zuhaitzen mugatutako sekuentzia (adibidez, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token korrontea parentesi mugatzaileez inguratuta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikatzaile bat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Puntuazio karaktere bakarra (`+`, `,`, `$`, etab.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// (`'a'`) karaktere literala, (`"hello"`) katea, (`2.3`) zenbakia, etab.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Zuhaitz honen hedapena itzultzen du, jasotako token edo mugatutako korronte baten `span` metodoari delegatuz.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// token * horretarako soilik konfiguratzen du tartea.
    ///
    /// Kontuan izan, token hau `Group` bada, metodo honek ez duela barne tokens bakoitzaren tartea konfiguratuko, honek aldaera bakoitzaren `set_span` metodoan delegatuko du.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token zuhaitza arazteko komenigarria den inprimatzen du.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Horietako bakoitzak egitura motako izena du eratorritako arazketan, beraz, ez zaitez arduratu indirekzio geruza gehiagorekin
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token zuhaitza galerarik gabeko bihur daitekeen kate gisa inprimatzen du token zuhaitz berera (moduluko zabalerak), baliteke `TokenTree: : Group` `Delimiter::None` mugatzaileekin eta zenbakizko literal negatiboekin izan ezik.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token korronte mugatua.
///
/// `Group`-k barnean `TokenStream` bat du, `Delimiter`-ek inguratuta duena.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token zuhaitzen sekuentzia nola mugatzen den deskribatzen du.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Mugatzaile inplizitua, adibidez, "macro variable" `$var` batetik datozen tokens inguruan ager daitekeena.
    /// Garrantzitsua da operadorearen lehentasunak gordetzea `$var * 3` bezalako kasuetan `$var` `1 + 2` denean.
    /// Baliteke mugatzaile inplizituek token korronte baten joan-etorrian bizirik jarraitzea kate baten bidez.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// `Group` berria sortzen du emandako mugatzailearekin eta token korrontearekin.
    ///
    /// Eraikitzaile honek `Span::call_site()` gisa ezarriko du talde honen tartea.
    /// Tartea aldatzeko beheko `set_span` metodoa erabil dezakezu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// `Group` honen mugatzailea itzultzen du
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// `Group` honetan mugatuta dauden tokens-ren `TokenStream` itzultzen du.
    ///
    /// Kontuan izan itzultzen den token korronteak ez duela goian bueltatutako mugatzailea barne.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// token korronte honen mugatzaileen tartea itzultzen du, `Group` osoa hartzen duena.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Talde honen hasierako mugatzailea seinalatzen duen tartea itzultzen du.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Talde honen itxiera mugatzailea seinalatzen duen tartea itzultzen du.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// `Taldeko` mugatzaileen tartea konfiguratzen du, baina ez bere barne tokens.
    ///
    /// Metodo honek **ez du** ezarriko talde honek barne hartzen dituen barne tokens guztien hedapena, baizik eta tokens mugatzailearen `Group` mailan bakarrik ezarriko du.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Taldeak galerarik gabe bihur daitezkeen kate gisa inprimatzen ditu talde berdinera (moduluko tarteak), baliteke `TokenTree: : Group` `Delimiter::None` mugatzaileekin izan ezik.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` `+`, `-` edo `#` bezalako puntuazio puntu bakarra da.
///
/// `+=` bezalako karaktere anitzeko operadoreak `Punct`-ren bi instantzia gisa irudikatzen dira `Spacing` forma desberdinak itzultzen diren moduan.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` bati berehala beste `Punct` bat etortzen zaion edo beste token edo zuriune bat jarraitzen duen.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// Adibidez, `+` `Alone` da `+ =`, `+ident` edo `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// Adibidez, `+` `Joint` da `+=` edo `'#`.
    /// Gainera, `'` aurrekontu bakarra identifikatzaileekin batu daiteke bizitza osoko `'ident` osatzeko.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// `Punct` berria sortzen du emandako karakteretik eta tartetik abiatuta.
    /// `ch` argumentuak hizkuntzak onartzen duen puntuazio-baliozko karakterea izan behar du, bestela funtzioak panic izango du.
    ///
    /// Itzulitako `Punct`-k `Span::call_site()` tarte lehenetsia izango du, beheko `set_span` metodoarekin gehiago konfigura daitekeena.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Puntuazio-karaktere honen balioa `char` gisa ematen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Puntuazio-karaktere honen tartea itzultzen du, token korrontean berehala beste `Punct` bat ote dagoen adierazten duen, beraz, karaktere anitzeko (`Joint`) operadore batean konbinatu daitezke, edo beste token edo (`Alone`) espazio zuri bat jarraituz, operadoreak zalantzarik ez du amaitu zen.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Puntuazio karakterearen tartea itzultzen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguratu puntuazio karaktere honen tartea.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Puntuazio karakterea inolako galerarik gabe bihur daitekeen karaktere berean inprimatzen duen kate gisa inprimatzen du.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) identifikatzailea.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// `Ident` berria sortzen du emandako `string` arekin eta zehaztutako `span` arekin.
    /// `string` argumentuak hizkuntzak onartzen duen baliozko identifikatzailea izan behar du (hitz gakoak barne, adibidez, `self` edo `fn`).Bestela, funtzioak panic izango du.
    ///
    /// Kontuan izan `span`-k, gaur egun rustc-n, identifikatzaile horren higiene informazioa konfiguratzen duela.
    ///
    /// Une honetatik aurrera, `Span::call_site()`-k "call-site" higienea berariaz hautatzen du, hau da, tarte honekin sortutako identifikatzaileak makro-deiaren kokapenean zuzenean idatzita egongo balira bezala konponduko dira, eta makro-deiaren gunean beste kodea haiek ere bai.
    ///
    ///
    /// Geroxeago `Span::def_site()` bezalako tarteek "definition-site" higienea aukeratzea ahalbidetuko dute, hau da, tarte horrekin sortutako identifikatzaileak makro definizioaren kokapenean ebatziko dira eta makro deien gunean beste kode batzuk ezin izango dira aipatu.
    ///
    /// Gaur egun higieneak duen garrantzia dela eta, eraikitzaile honek, beste tokens ez bezala, `Span` bat behar du eraikuntzan zehazteko.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` bezala, baina (`r#ident`) identifikatzaile gordina sortzen du.
    /// `string` argumentua hizkuntzak onartzen duen baliozko identifikatzailea da (gako-hitzak barne, adibidez, `fn`).
    /// Bide-segmentuetan erabil daitezkeen hitz gakoak (adibidez
    /// `self`, "super") ez dira onartzen eta panic eragingo du.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// `Ident` honen tartea itzultzen du, [`to_string`](Self::to_string)-k itzultzen duen kate osoa biltzen duena.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// `Ident` honen hedadura konfiguratzen du, higiene testuingurua aldatuz.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Identifikatzailea galerarik gabe bihur daitekeen kate gisa inprimatzen du berriro identifikatzaile berean.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// (`"hello"`) kate literala, (`b"hello"`) byte katea, (`'a'`) karakterea, (`b'a'`) byte karakterea, zenbaki oso edo mugikorreko zenbakia atzizkiarekin edo gabe (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` eta `false` bezalako literal boolearrak ez dira hemen sartzen, `Ident`s dira.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Zenbaki oso atzizkidun literal berria sortzen du zehaztutako balioarekin.
        ///
        /// Funtzio honek `1u32` bezalako zenbaki oso bat sortuko du, zehaztutako zenbaki osoa token-ren lehenengo zatia da eta integrala amaieran atzizkia ere bada.
        /// Zenbaki negatiboetatik sortutako literalek agian ez dute biziraupenik izango `TokenStream` edo kateetan zehar eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
        ///
        ///
        /// Metodo honen bidez sortutako letrek `Span::call_site()` tartea dute lehenespenez, beheko `set_span` metodoarekin konfigura daitekeena.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Konfiguratu gabeko zenbaki oso berri bat sortzen du zehaztutako balioarekin.
        ///
        /// Funtzio honek `1` bezalako zenbaki oso bat sortuko du, zehaztutako zenbaki osoa token-ren lehen zatia izanik.
        /// token honetan ez da atzizkirik zehazten, hau da, `Literal::i8_unsuffixed(1)` bezalako deiak `Literal::u32_unsuffixed(1)` ren parekoak dira.
        /// Zenbaki negatiboetatik sortutako letrek agian ez dituzte `TokenStream` edo kateen bidez egindako itzulipurdikak iraungo eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
        ///
        ///
        /// Metodo honen bidez sortutako letrek `Span::call_site()` tartea dute lehenespenez, beheko `set_span` metodoarekin konfigura daitekeena.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Konfiguratu gabeko puntu mugikorreko literal berria sortzen du.
    ///
    /// Eraikitzaile hau `Literal::i8_unsuffixed` bezalakoen antzekoa da, non float-aren balioa zuzenean token-ra igortzen den baina ez da atzizkirik erabiltzen, beraz, konpilagailuan `f64` bat geroago ondoriozta daiteke.
    ///
    /// Zenbaki negatiboetatik sortutako letrek agian ez dituzte `TokenStream` edo kateen bidez egindako itzulipurdikak iraungo eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
    ///
    /// # Panics
    ///
    /// Funtzio honek zehaztutako mugikorra finitua izatea eskatzen du, adibidez infinitua bada edo NaN funtzio hau panic izango da.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Puntu mugikorreko atzizki literal berri bat sortzen du.
    ///
    /// Eraikitzaile honek `1.0f32` bezalako literala sortuko du, zehaztutako balioa token-ren aurreko zatia eta `f32` token-ren atzizkia izanik.
    /// token hau beti konpilatzailean `f32` dela ondorioztatuko da.
    /// Zenbaki negatiboetatik sortutako letrek agian ez dituzte `TokenStream` edo kateen bidez egindako itzulipurdikak iraungo eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
    ///
    ///
    /// # Panics
    ///
    /// Funtzio honek zehaztutako mugikorra finitua izatea eskatzen du, adibidez infinitua bada edo NaN funtzio hau panic izango da.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Konfiguratu gabeko puntu mugikorreko literal berria sortzen du.
    ///
    /// Eraikitzaile hau `Literal::i8_unsuffixed` bezalakoen antzekoa da, non float-aren balioa zuzenean token-ra igortzen den baina ez da atzizkirik erabiltzen, beraz, konpilagailuan `f64` bat geroago ondoriozta daiteke.
    ///
    /// Zenbaki negatiboetatik sortutako letrek agian ez dituzte `TokenStream` edo kateen bidez egindako itzulipurdikak iraungo eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
    ///
    /// # Panics
    ///
    /// Funtzio honek zehaztutako mugikorra finitua izatea eskatzen du, adibidez infinitua bada edo NaN funtzio hau panic izango da.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Puntu mugikorreko atzizki literal berri bat sortzen du.
    ///
    /// Eraikitzaile honek `1.0f64` bezalako literala sortuko du, zehaztutako balioa token-ren aurreko zatia eta `f64` token-ren atzizkia izanik.
    /// token hau beti konpilatzailean `f64` dela ondorioztatuko da.
    /// Zenbaki negatiboetatik sortutako letrek agian ez dituzte `TokenStream` edo kateen bidez egindako itzulipurdikak iraungo eta bi tokens (`-` eta literal positiboa) bitan zatitu daitezke.
    ///
    ///
    /// # Panics
    ///
    /// Funtzio honek zehaztutako mugikorra finitua izatea eskatzen du, adibidez infinitua bada edo NaN funtzio hau panic izango da.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Kate literala.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Pertsonaia literala.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte katea literala.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Literal hau biltzen duen tartea itzultzen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Literal honi lotutako tartea konfiguratzen du.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` azpimultzoa den `self.span()` azpimultzoa ematen du `range` barrutiko iturburuko byteekin soilik.
    /// `None` itzultzen du nahi zen tartea `self` ren mugetatik kanpo badago.
    ///
    // FIXME(SergioBenitez): egiaztatu byte sorta iturburuaren UTF-8 mugan hasi eta amaitzen dela.
    // bestela, litekeena da panic beste nonbait sortzea iturburuko testua inprimatzean.
    // FIXME(SergioBenitez): erabiltzaileak ez du `self.span()`-k zertan mapatzen duen jakiteko modurik, beraz metodo hau itsu-itsuan soilik deitu daiteke.
    // Adibidez, `to_string()` karakterearentzako `to_string()` "'\u{63}'" itzultzen du;erabiltzaileak ez du jakiterik iturburuko testua 'c' zen edo '\u{63}' zen.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` ren antzeko zerbait, baina `Bound<&T>` rentzat.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Oharra, zubiak `to_string` bakarrik ematen du, `fmt::Display` inplementatu horretan oinarrituta (bien arteko ohiko harremanaren alderantzizkoa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Literala galerarik gabe bihur daitekeen kate gisa inprimatzen du literal berean (puntu mugikorreko literalen biribilketa posible izan ezik).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ingurumen aldagaietarako sarbide jarraitua.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Berreskuratu ingurune aldagai bat eta gehitu dependentzia informazioa sortzeko.
    /// Konpilatzailea exekutatzen duen sistema eraikitzaileak jakingo du konpilazioan zehar aldagaia atzitu dela, eta aldagai horren balioa aldatzen denean eraikuntza berriro exekutatu ahal izango du.
    ///
    /// Menpekotasunaren jarraipena egiteaz gain, funtzio honek liburutegi estandarraren `env::var` ren baliokidea izan beharko luke, argumentuak UTF-8 izan behar duela izan ezik.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}