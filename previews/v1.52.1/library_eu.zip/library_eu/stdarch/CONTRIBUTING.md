# Stdarch-i laguntzen

`stdarch` crate ekarpenak onartzeko baino gehiago dago!Lehenik eta behin biltegia ikusi eta probak gainditzen dituzula ziurtatu nahi duzu:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`<your-target-arch>` `rustup`-k erabilitako helburu hirukoitza denean, adibidez `x86_x64-unknown-linux-gnu` (aurreko `nightly-` edo antzekorik gabe).
Gogoratu ere biltegi honek Rust gaueko kanala behar duela!
Aurreko probek, egia esan, gaueko rust zure sistemako lehenetsia izatea eskatzen dute, `rustup default nightly` erabiltzen dutenak ezartzeko (eta `rustup default stable` itzultzeko).

Aurreko urratsetako batek funtzionatzen ez badu, [please let us know][new]!

Aurrerantzean [find an issue][issues] lagun dezakezu, batzuk aukeratu ditugu [`help wanted`][help] eta [`impl-period`][impl] etiketekin, bereziki laguntza erabil dezaketenak. 
Baliteke [#40][vendor] interesatzea gehien, x86-n berezko saltzaile guztiak ezarriz.Zenbaki horrek nondik hasi jakiteko aholku onak ditu!

Galdera orokorrak badituzu, jar zaitez libre [join us on gitter][gitter]-ra eta galdetu inguruan!Anima zaitez@BurntSushi edo@alexcrichton galderekin ping egitera.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Nola idatzi adibideak stdarch berezkoentzat

Badira funtzio batzuk gaitu behar direnak berezko funtzionamendua ondo funtziona dezan eta adibidea `cargo test --doc`-k soilik exekutatu behar du funtzioak CPUak onartzen duenean.

Ondorioz, `rustdoc`-k sortzen duen `fn main` lehenetsiak ez du funtzionatuko (kasu gehienetan).
Demagun honako hau gida gisa erabiltzea zure adibideak espero bezala funtzionatzen duela ziurtatzeko.

```rust
/// # // Cfg_target_feature behar dugu adibidea bakarrik dela ziurtatzeko
/// # // `cargo test --doc`-k exekutatzen du PUZak funtzioa onartzen duenean
/// # #![feature(cfg_target_feature)]
/// # // Berezkoak funtziona dezan target_feature behar dugu
/// # #![feature(target_feature)]
/// #
/// # // rustdoc-ek lehenespenez `extern crate stdarch` erabiltzen du, baina
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Benetako funtzio nagusia
/// # fn main() {
/// #     // Exekutatu hau `<target feature>` onartzen bada
/// #     cfg_feature_a gaituta badago! ("<target feature>"){
/// #         // Sortu `worker` funtzioa, xede funtzioa baldin bada bakarrik exekutatuko dena
/// #         // onartzen da eta ziurtatu zure langilearentzako `target_feature` gaituta dagoela
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ez segurua fn worker() {
/// // Idatzi hemen zure adibidea.Berezko funtzio bereziek hemen funtzionatuko dute!Zoaz basati!
///
/// #         }
///
/// #         ez segurua { worker(); }
/// #     }
/// # }
```

Aurreko sintaxi batzuk ezagunak ez badira, [Rust Book]-ren [Documentation as tests] atalak `rustdoc` sintaxia nahiko ondo deskribatzen du.
Beti bezala, lasai [join us on gitter][gitter]-ra eta galdetu iezaiguzu arazorik izanez gero, eta eskerrik asko `stdarch`-ren dokumentazioa hobetzen laguntzeagatik!

# Probak egiteko jarraibide alternatiboak

Probak egiteko, normalean `ci/run.sh` erabiltzea gomendatzen da.
Hala ere, agian ez zaizu funtzionatuko, adibidez, Windows zerbitzuan bazaude.

Kasu horretan, Kode sortzea probatzeko `cargo +nightly test` eta `cargo +nightly test --release -p core_arch` exekutatzera itzul zaitezke.
Kontuan izan hauetarako gaueko tresna-kateak instalatu behar direla eta `rustc`-k zure xede hirukoitza eta haren PUZaren berri izan behar duela.
Bereziki `TARGET` ingurumenaren aldagaia `ci/run.sh` rentzat egingo zenukeen moduan ezarri behar duzu.
Gainera `RUSTCFLAGS` ezarri behar duzu (`C` behar da) helburu ezaugarriak adierazteko, adibidez `RUSTCFLAGS="-C -target-features=+avx2"`.
`-C -target-cpu=native` ere ezar dezakezu "just" zure uneko CPUarekin garatzen ari bazara.

Ohar zaitez argibide alternatibo hauek erabiltzen dituzunean, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], adibidez
instrukzioa sortzeko probek huts egin dezakete desmuntagailuak beste modu batean izendatu dituelako, adibidez
`vaesenc` sor ditzake `aesenc` argibideen ordez, berdin jokatu arren.
Argibide hauek normalean egingo liratekeenak baino proba gutxiago exekutatzen dituzte, beraz, ez zaitez harritu azkenean tira-eskaera egitean akats batzuk ager daitezkeela hemen estaltzen ez diren probetarako.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






