use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Gure `#[assert_instr]` oharrei esateko erabiltzen dira berezko simd guztiak beren kodegena probatzeko, batzuk `#[target_feature]`-n baliokiderik ez duen `-Ctarget-feature=+unimplemented-simd128` estra baten atzean daudelako.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}