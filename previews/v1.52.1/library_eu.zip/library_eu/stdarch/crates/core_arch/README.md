`core::arch` - Rust-ren oinarrizko liburutegiaren arkitektura bereziak
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` moduluak arkitekturaren menpeko berezkoak (adibidez, SIMD) ezartzen ditu.

# Usage 

`core::arch` eskuragarri dago `libcore`-ren zati gisa eta `libstd`-k berriro esportatzen du.Nahiago duzu `core::arch` edo `std::arch` bidez erabiltzea crate honen bidez baino.
Ezaugarri ezegonkorrak gaueko Rust zerbitzuan eskuragarri egon ohi dira `feature(stdsimd)` bidez.

0crate honen bidez `core::arch` erabiltzeak gaueko Rust behar du, eta maiz apur dezake (eta egiten du).crate honen bidez erabiltzea pentsatu beharko zenukeen kasu bakarrak hauek dira:

* `core::arch` berriro konpilatu behar baduzu, adibidez, `libcore`/`libstd` rako gaituta ez dauden helburu-ezaugarri jakin batzuekin gaituta.
Note: estandarra ez den xede baterako berriro konpilatu behar baduzu, nahiago baduzu `xargo` erabiltzea eta berriro egoki `libcore`/`libstd` konpilatzea crate hau erabili beharrean.
  
* Rust funtzio ezegonkorren atzean ere erabilgarri ez dauden zenbait funtzio erabiliz.Hauek gutxieneko neurriak izaten saiatzen gara.
Ezaugarri hauetako batzuk erabili behar badituzu, ireki arazo bat, gaueko Rust-n azal ditzagun eta hortik erabil ditzazun.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` batez ere MIT lizentziaren eta Apache Lizentziaren (2.0 bertsioa) baldintzekin banatzen da, BSD moduko lizentzia batzuek estaltzen dituzten zatiekin.

Xehetasunak ikusteko, ikusi LICENSE-APACHE eta LICENSE-MIT.

# Contribution

Esplizituki kontrakoa adierazi ezean, 0Apache-2.0 lizentzian zehaztutako 0Apache-2.0 lizentzian zuk nahita aurkeztutako ekarpenek lizentzia bikoitza izango dute aurreko moduan, inolako baldintza edo baldintza gehigarririk gabe.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












