//! Pagpatuman sa Rust panics pinaagi sa proseso sa pag-abort
//!
//! Kung gitandi sa pagpatuman pinaagi sa pag-unwind, kini nga crate labi ka * simple!Giingon na, kini dili ingon ka daghan nga gamit, apan dinhi moadto!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ang payload ug shim sa may kalabutan nga abort sa nahisgutan nga platform.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // tawagi ang std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Sa Windows, gamita ang mekanismo nga __fastfail nga piho nga processor.Sa Windows 8 ug sa ulahi, matapos na dayon niini ang proseso nga wala`y pagpadagan bisan unsang mga handler sa eksepsyon nga in-proseso.
            // Sa mga naunang bersyon sa Windows, ang kini nga han-ay sa mga panudlo pagaatiman ingon usa ka paglapas sa pag-access, nga tapuson ang proseso apan dili kinahanglan nga laktawan ang tanan nga mga handler sa eksepsyon.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: kini mao ang sama nga implementasyon sama sa `abort_internal` ni libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Kini ... usa ka gamay nga katingad-an.Ang tl; dr;mao nga kini gikinahanglan sa pagsumpay sa husto nga paagi, ang mga na nga katin-awan mao ang sa ubos.
//
// Karon usab ang mga binary nga libcore/libstd nga gipadala namon ang tanan gitipon sa `-C panic=unwind`.Kini mao ang gibuhat aron sa pagsiguro nga ang mga binaries mga maximally compatible uban sa ingon nga sa daghan nga mga sitwasyon nga ingon sa sa mahimo.
// tighipos sa, Apan, nagkinahanglan sa usa ka "personality function" alang sa tanan nga mga gimbuhaton tinigum, hinipos sa `-C panic=unwind`.Kini nga personalidad function ang hardcoded sa simbolo `rust_eh_personality` ug ang gihubit sa `eh_personality` lang nga butang.
//
// So...
// nganong dili lang nagpaila nga ang lang item dinhi?Maayong pangutana!Ang paagi sa panic runtimes nasumpay sa mao ang tinuod nga usa ka gamay nga malalangon sa nga sila "sort of" sa crate tindahan sa tighipos, apan lamang sa aktuwal nga nalambigit kon lain nga dili tinuod nga nalambigit.
//
// Nagtapos kini nga nagpasabot nga parehas nga kining crate ug ang panic_unwind crate mahimong makita sa tindahan sa crate nga tagtipon, ug kung parehas nga gipasabut ang item nga `eh_personality` lang pagkahuman naigo kini sa usa ka sayup.
//
// Aron sa pagdumala niini sa mga tighipos lamang nagkinahanglan sa `eh_personality` gihubit kon ang panic Runtime nga nalambigit sa mao ang pagbadbad sa lanot nga Runtime, ug kon dili kini dili gikinahanglan nga gihubit (katungod sa ingon).
// Hinuon, sa kini nga kaso, gipasabut ra sa librarya kini nga simbolo busa adunay labing menos pipila ka personalidad sa bisan diin.
//
// Sa tinuud kini nga simbolo gipasabut ra aron maka-wire hangtod sa libcore/libstd binaries, apan dili gyud kini tawgon tungod kay wala gyud kami mag-link sa usa ka wala`y hunong nga runtime.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Sa x86_64-pc-tamboanan-gnu atong gamiton ang atong kaugalingon nga personalidad function nga mga panginahanglan sa pagbalik `ExceptionContinueSearch` ingon kita nga moagi sa tanan nga atong mga bayanan.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Susama sa ibabaw, kini kaangay sa `eh_catch_typeinfo` lang butang nga gigamit lamang sa Emscripten karon.
    //
    // Tungod kay ang panics dili makamugna mga eksepsyon ug mga langyaw nga eksepsyon sa pagkakaron UB nga adunay -C panic=abort (bisan kung mahimo`g mapaubus kini), ang bisan unsang mga tawag nga catch_unwind dili gyud magamit kini nga typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Gitawag kini nga duha sa among mga startup nga mga butang sa i686-pc-windows-gnu, apan dili nila kinahanglan buhaton bisan unsa busa ang mga lawas nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}