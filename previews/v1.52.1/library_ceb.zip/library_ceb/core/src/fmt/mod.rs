//! Utilities alang sa formatting ug pag-imprenta kuldas.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Posibleng mga pag-align nga gibalik sa `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Timailhan nga ang mga sulud kinahanglan nga makahanay sa wala.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Timailhan nga sulod kinahanglan nga tuo-ilaray.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Timailhan nga ang mga sulud kinahanglan ipahiangay sa sentro.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Ang tipo nga gibalik sa mga pamaagi sa formatter.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Ang matang sayop nga mibalik gikan sa formatting sa usa ka mensahe ngadto sa usa ka sapa.
///
/// matang Kini nga wala mosuporta sa transmission sa usa ka sayop sa uban nga kay sa nga nahitabo sa usa ka sayop.
/// Sa bisan unsa nga dugang nga impormasyon kinahanglan nga gihan-ay nga gipasa pinaagi sa pipila ka mga laing paagi.
///
/// Ang usa ka hinungdanon nga butang nga hinumdoman mao nga ang tipo nga `fmt::Error` dili dapat maglibug sa [`std::io::Error`] o [`std::error::Error`], nga mahimo usab nimo adunay kasangkaran.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Usa ka trait alang sa pagsulat o pag-format sa pagdawat sa mga buffer o sapa sa Unicode.
///
/// Kini nga trait lamang modawat UTF-8-encoded data ug dili [flushable].
/// Kung gusto nimo lang dawaton ang Unicode ug dili nimo kinahanglan ang flushing, kinahanglan nimo ipatuman kini nga trait;
/// kung dili kinahanglan nimo ipatuman ang [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Misulat sa usa ka hilo nga ad-ad sa magsusulat niini, pagbalik kon mipuli sa isulat.
    ///
    /// Kini nga pamaagi lamang molampos kon ang bug-os nga hilo ad-ad sa malampuson nga nahisulat, ug kini nga pamaagi dili mobalik hangtud ang tanang data nga gisulat o sa usa ka sayop mahitabo.
    ///
    ///
    /// # Errors
    ///
    /// function Kini nga mobalik sa usa ka pananglitan sa [`Error`] sa kasaypanan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Nagsulat usa ka [`char`] sa kini nga magsusulat, giuli kung nagmalampuson ang pagsulat.
    ///
    /// Ang usa ka [`char`] mahimong ma-encode ingon labaw pa sa usa ka byte.
    /// Kini nga pamaagi lamang molampos kon ang bug-os nga Byte han-ay nga malampuson nahisulat, ug kini nga pamaagi dili mobalik hangtud ang tanang data nga gisulat o sa usa ka sayop mahitabo.
    ///
    ///
    /// # Errors
    ///
    /// function Kini nga mobalik sa usa ka pananglitan sa [`Error`] sa kasaypanan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Pandikit alang sa paggamit sa [`write!`] macro nga adunay mga nagpatuman sa kini nga trait.
    ///
    /// Kini nga pamaagi kinahanglan nga sa kinatibuk-dili ikapangaliyupo sa kamut, apan hinoon pinaagi sa [`write!`] macro sa iyang kaugalingon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Pag-configure alang sa pag-format.
///
/// Usa ka `Formatter` nagrepresentar sa nagkalain-laing mga mga kapilian nga may kalabutan sa formatting.
/// Users dili magtukod `Formatter`s direkta;sa usa ka mutable paghisgot sa usa miagi ngadto sa `fmt` pamaagi sa tanan nga formatting traits, sama sa [`Debug`] ug [`Display`].
///
///
/// Aron makigsulti sa usa ka `Formatter`, tawagan nimo ang lainlaing mga pamaagi aron mabag-o ang lainlaing mga kapilian nga may kalabotan sa pag-format.
/// Alang sa mga panig-ingnan, palihog tan-awa ang dokumento sa mga pamaagi nga gihubit sa `Formatter` sa ubos.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argumento mao ang esensya sa usa ka optimized partially apply formatting function, nga katumbas sa `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// magtukod Kini nga nagrepresentar sa mga generic "argument" nga gikuha sa Xprintf pamilya sa gimbuhaton.Kini naglakip og usa ka function sa format sa gihatag nga bili.
/// Sa pagtipon sa panahon nga kini misiguro nga ang function ug sa bili sa mga husto nga matang, ug unya kining magtukod gigamit sa canonicalize argumento sa usa ka matang.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Gagarantiyahan niini ang us aka stable nga kantidad alang sa function pointer nga adunay kalabotan sa indices/counts sa inprastraktura sa pag-format.
//
// Mubo nga sulat nga ang usa ka function gihubit ingon nga dili husto nga ingon sa mga gimbuhaton kanunay gitumbok unnamed_addr sa kasamtangan nga pagpaubos sa LLVM IRI, mao ang ilang mga address dili giisip importante sa LLVM ug sa ingon ang as_usize cast unta miscompiled.
//
// Sa pagpraktis, dili gyud kami tawagan as_usize sa dili usad nga adunay sulud nga datos (ingon usa ka butang nga static nga henerasyon sa mga pag-format nga argumento), busa kini usa ra ka dugang nga pagsusi.
//
// Panguna namon nga gusto nga masiguro nga ang function pointer sa `USIZE_MARKER` adunay address nga katugbang *ra* sa mga gimbuhaton nga gikuha usab ang `&usize` ingon ilang una nga lantugi.
// Ang read_volatile dinhi nagsiguro nga kita luwas nga andam gikan sa usa ka usize gikan sa milabay paghisgot ug nga address kini dili punto sa usa ka non-usize pagkuha function.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // KALuwas-an: ang ptr usa ka pakisayran
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // KALUWASAN: luwas ang `mem::transmute(x)` tungod kay
        //     1. `&'b T` nagabantay sa tibuok kinabuhi naggikan kini sa `'b` (aron dili sa usa ka walay kinutuban nga kinabuhi)
        //     2.
        //     `&'b T` ug ang `&'b Opaque` adunay parehas nga layout sa panumduman (kung ang `T` mao ang `Sized`, ingon ania dinhi) luwas ang `mem::transmute(f)` sanglit ang `fn(&T, &mut Formatter<'_>) -> Result` ug `fn(&Opaque, &mut Formatter<'_>) -> Result` adunay parehas nga ABI (basta ang `T` mao ang `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SAFETY: Ang `formatter` uma mao ang lamang sa USIZE_MARKER kon
            // ang bili mao ang usa ka usize, mao nga kini mao ang luwas
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// bandera nga anaa sa v1 format sa format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Kung gigamit ang format_args! () Macro, gigamit kini nga pag-andar aron makahimo ang istruktura sa Mga Argumento.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Gigamit kini nga pag-andar aron mahibal-an ang mga dili sumbanan nga mga parameter sa pag-format.
    /// Ang `pieces` gubat kinahanglan nga sa labing menos ingon sa kadugayon nga `fmt` sa pagtukod sa usa ka balido nga argumento nga gambalay.
    /// Ingon usab, bisan unsang `Count` sulud sa `fmt` nga `CountIsParam` o `CountIsNextParam` kinahanglan magtudlo sa usa ka argumento nga gihimo uban ang `argumentusize`.
    ///
    /// Bisan pa, ang dili pagbuhat niini dili hinungdan nga dili malig-on, apan ibaliwala ang dili balido.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Nagbanabana nga ang gitas-on sa pormat.
    ///
    /// Kini gituyo aron gamiton alang sa paghimo sa inisyal `String` kapasidad diha nga ang paggamit `format!`.
    /// Note: kini mao ni ang ubos-ubos ni sa ibabaw nga ginapos.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Kon ang format hilo magsugod uban sa usa ka argumento, dili preallocate bisan unsa, gawas kon ang gitas-on sa mga tipik mao ang mahinungdanon.
            //
            //
            0
        } else {
            // Adunay pipila nga mga lantugi, busa ang bisan unsang dugang nga pagduso nga ibalhin ang linya.
            //
            // Aron malikayan kana, "pre-doubling" kami ang kapasidad dinhi.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Ang kini nga istruktura nagrepresentar sa usa ka luwas nga pagkasunod bersyon sa usa ka format string ug ang mga argumento.
/// Dili kini mahimo sa oras nga pag-undang tungod kay dili kini luwas nga mahimo, busa wala gihatag ang mga magtutukod ug pribado ang mga uma aron malikayan ang pagbag-o.
///
///
/// Ang [`format_args!`] macro nga luwas nga paghimo sa usa ka pananglitan sa gambalay niini.
/// macro Ang matuod sa format hilo sa pagtipon-panahon aron sa paggamit sa [`write()`] ug [`format()`] gimbuhaton mahimong luwas nga gihimo.
///
/// Inyong magamit sa `Arguments<'a>` nga [`format_args!`] mobalik sa `Debug` ug `Display` konteksto sama sa nakita sa ubos.
/// Ang panig-ingnan usab sa nagpakita nga `Debug` ug `Display` format sa sama nga butang: ang gidugang format hilo sa `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Pag-format sa mga piraso sa hilo aron ma-print.
    pieces: &'a [&'static str],

    // Placeholder supakon, o `None` kon ang tanan supakon mga default (sama sa "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dinamikong mga argumento alang sa ot, nga interleaved sa mga piraso sa hilo.
    // (Ang matag lantugi giuna sa usa ka piraso nga pisi.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Sa pagkuha sa mga nakahan-ay hilo, kon kini walay mga argumento nga format.
    ///
    /// Kini mahimong gamiton sa paglikay sa mga alokasyon sa labing gamay nga kaso.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` kinahanglan format sa output sa usa ka programmer-atubang, debugging konteksto.
///
/// Kasagaran, kinahanglan ikaw lang `derive` sa usa ka `Debug` pagpatuman.
///
/// Kung gigamit sa alternatibong format specifier `#?`, ang output medyo naimprinta.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Kini nga trait mahimong magamit sa `#[derive]` kung ang tanan nga mga uma ipatuman ang `Debug`.
/// Sa diha nga `derive`d alang sa structs, kini gamiton sa ngalan sa `struct`, unya `{`, unya sa usa ka comma-gilain sa listahan sa mga ngalan sa matag kapatagan ug `Debug` bili, unya `}`.
/// Alang sa `enum`s, gamiton niini ang ngalan sa lahi ug, kung magamit, `(`, pagkahuman ang mga kantidad nga `Debug` sa mga uma, pagkahuman `)`.
///
/// # Stability
///
/// Nakuha `Debug` format dili lig-on, ug sa ingon mag-usab uban sa future Rust bersiyon.
/// Dugang pa, `Debug` implementar sa mga matang nga gihatag sa sumbanan nga librarya (`libstd`, `libcore`, `liballoc`, ug uban pa) dili lig-on, ug mahimo usab-usab uban sa future Rust bersiyon.
///
///
/// # Examples
///
/// Naghatag usa ka pagpatuman:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Kamut sa pagpatuman:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Adunay usa ka gidaghanon sa mga katabang mga pamaagi sa [`Formatter`] magtukod sa pagtabang kaninyo uban sa manwal implementar, sama sa [`debug_struct`].
///
/// `Debug` mga pagpatuman gamit ang bisan unsang `derive` o ang debug builder API sa [`Formatter`] suportahan ang medyo pag-print gamit ang alternatibong bandila: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Maayo nga pag-imprinta nga adunay `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Ilain ang module sa reexport sa macro `Debug` gikan prelude gawas sa trait `Debug`.
pub(crate) mod macros {
    /// Kuha macro pagmugna sa usa ka impl sa trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format trait alang sa usa ka walay sulod nga format, `{}`.
///
/// `Display` mao ang susama sa [`Debug`], apan `Display` alang user-atubang sa output, ug sa ingon dili mahimong nakuha.
///
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// - Implementar `Display` sa usa ka matang:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Ang `Octal` trait kinahanglan i-format ang output niini ingon usa ka numero sa base-8.
///
/// Kay karaang gipirmahan integers (`i8` sa `i128`, ug `isize`), negatibo nga mga hiyas nga nakahan-ay ingon nga ang duha ka ni katimbang representasyon.
///
///
/// Ang laing bandila, `#`, midugang ang usa ka `0o` sa atubangan sa output.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic paggamit sa `i32`:
///
/// ```
/// let x = 42; // Ang 42 mao ang '52' sa octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Pagpatuman sa `Octal` sa usa ka lahi:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // delegado sa pagpatuman sa i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Ang `Binary` trait kinahanglan i-format ang output ingon usa ka numero sa binary.
///
/// Alang sa una nga gipirmahan nga integer ([`i8`] hangtod [`i128`], ug [`isize`]), ang mga negatibo nga kantidad gi-format ingon nga representasyon sa komplemento sa duha.
///
///
/// Ang laing bandila, `#`, midugang ang usa ka `0b` sa atubangan sa output.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic paggamit sa [`i32`]:
///
/// ```
/// let x = 42; // Ang 42 mao ang '101010' sa binary
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Pagpatuman sa `Binary` sa usa ka lahi:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // delegado sa pagpatuman sa i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Ang `LowerHex` trait kinahanglan format sa iyang output ingon sa usa ka gidaghanon sa hexadecimal, uban sa `a` pinaagi `f` sa ubos nga kaso.
///
/// Kay karaang gipirmahan integers (`i8` sa `i128`, ug `isize`), negatibo nga mga hiyas nga nakahan-ay ingon nga ang duha ka ni katimbang representasyon.
///
///
/// Ang laing bandila, `#`, midugang ang usa ka `0x` sa atubangan sa output.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic paggamit sa `i32`:
///
/// ```
/// let x = 42; // 42 mao ang '2a' sa hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// - Implementar `LowerHex` sa usa ka matang:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // delegado sa pagpatuman sa i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Ang `UpperHex` trait kinahanglan i-format ang output niini ingon usa ka numero sa hexadecimal, nga adunay `A` hangtod `F` sa taas nga kaso.
///
/// Kay karaang gipirmahan integers (`i8` sa `i128`, ug `isize`), negatibo nga mga hiyas nga nakahan-ay ingon nga ang duha ka ni katimbang representasyon.
///
///
/// Ang laing bandila, `#`, midugang ang usa ka `0x` sa atubangan sa output.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basic paggamit sa `i32`:
///
/// ```
/// let x = 42; // 42 mao ang '2A' sa hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// - Implementar `UpperHex` sa usa ka matang:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // delegado sa pagpatuman sa i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Ang `Pointer` trait kinahanglan format sa iyang output ingon sa usa ka lokasyon sa panumduman.
/// Kini kasagarang gipakita ingon hexadecimal.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Panguna nga gamit sa `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // naghimo kini usa ka butang sama sa '0x7f06092ac6d0'
/// ```
///
/// Pagpatuman sa `Pointer` sa usa ka lahi:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // paggamit `as` sa kinabig ngadto sa usa ka `*const T`, nga nagpatuman point shot, nga atong gamiton
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Ang `LowerExp` trait kinahanglan format sa iyang output sa siyentipikanhong nota sa usa ka ubos nga-kaso `e`.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Panguna nga gamit sa `f64`:
///
/// ```
/// let x = 42.0; // 42.0 mao '4.2e1' sa siyentipikanhong nota
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Pagpatuman sa `LowerExp` sa usa ka lahi:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delegado sa pagpatuman sa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Ang `UpperExp` trait kinahanglan format sa iyang output sa siyentipikanhong nota sa usa ka ibabaw nga-kaso `E`.
///
/// Alang sa dugang nga impormasyon sa formatters, tan-awa ang [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Panguna nga gamit sa `f64`:
///
/// ```
/// let x = 42.0; // 42.0 mao '4.2E1' sa siyentipikanhong nota
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Pagpatuman sa `UpperExp` sa usa ka lahi:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delegado sa pagpatuman sa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// - Format sa bili sa paggamit sa gihatag nga formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Ang pagpaandar sa `write` nagkinahanglan usa ka output stream, ug usa ka `Arguments` nga istruktura nga mahimong iupod sa `format_args!` macro.
///
///
/// Ang argumento nga nakahan-ay sumala sa bungat hilo format ngadto sa output sapa nga gihatag.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Palihug timan-i nga ang paggamit [`write!`] mahimong preferable.Pananglitan:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Kita sa paggamit sa default formatting lantugi alang sa tanan nga mga argumento.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Ang matag detalye nga adunay usa ka katugbang nga argumento nga nag-una sa usa ka piraso sa hilo.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // KALUWASAN: arg ug args.args gikan sa parehas nga Mga Pangatarungan,
                // nga garantiya sa mga indeks mao ang kanunay nga sa sulod sa mga utlanan.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Adunay mahimong usa lamang ka trailing hilo piraso sa wala.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SAFETY: ARG ug ARG moabut gikan sa samang argumento,
    // nga garantiya sa mga indeks mao ang kanunay nga sa sulod sa mga utlanan.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Kinuha ang husto nga argumento
    debug_assert!(arg.position < args.len());
    // SAFETY: ARG ug ARG moabut gikan sa samang argumento,
    // nga gigarantiyahan ang indeks niini kanunay naa sa sulod sa mga utlanan.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Unya sa pagkatinuod buhaton sa pipila ka mga pag-imprinta
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // KALUWASAN: Ang cnt ug args naggikan sa parehas nga Mga Pangatarungan,
            // nga garantiya nga kini nga indeks kanunay naa sa sulod sa mga utlanan.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding pagkahuman sa katapusan sa usa ka butang.Gibalik sa `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Isulat kini nga padding sa post.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Gusto namon kini usbon
            buf: wrap(self.buf),

            // Ug tipigi kini
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Magtatabang mga pamaagi nga gigamit alang sa padding ug pagproseso sa formatting mga argumento nga ang tanan nga formatting traits makahimo sa paggamit sa.
    //

    /// Naghimo sa husto nga padding alang sa usa ka integer nga gipagawas na sa usa ka str
    /// str kinahanglan dili * naglangkob sa mga ilhanan alang sa integer, nga dugang pa sa niini nga pamaagi.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, kon ang orihinal nga integer mao sa bisan positibo o zero.
    /// * prefix, kon ang '#' kinaiya (Alternate) ang gitagana, kini mao ang prefix nga gibutang sa atubangan sa gidaghanon.
    ///
    /// * buf, ang Byte gubat nga ang gidaghanon nga format ngadto sa
    ///
    /// function Kini husto asoy alang sa mga bandera nga gihatag ingon man ang minimum nga gilapdon.
    /// Dili kini magtagad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Kita kinahanglan nga sa pagtangtang "-" gikan sa gidaghanon output.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Misulat sa ilhanan kon kini anaa, ug unya ang prefix kon kini gihangyo
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Ang `width` nga uma labi pa sa usa ka `min-width` parameter sa kini nga punto.
        match self.width {
            // Kung wala'y minimum nga mga kinahanglanon sa gitas-on mahimo ra namon isulat ang mga byte.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Susihon kung sobra na kita sa minimum nga gilapdon, kung ingon niana mahimo usab naton isulat ang mga byte.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Ang timaan ug unahan una sa padding kung ang gipuno nga karakter dili zero
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Kay kon dili, ang timaan ug unahan moadto pagkahuman sa padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// function Kini nagkinahanglan sa usa ka hilo ad-ad ug mobuga kini ngadto sa internal nga buffer human sa pagpadapat sa mga may kalabutan formatting kabugangan bungat.
    /// Ang mga bandila nga giila alang sa mga kinatibuk-ang lubid mao ang:
    ///
    /// * ang gilapdon, ang minimum nga gilapdon sa unsay mobuga
    /// * fill/align - unsa ang ibuga ug kung asa kini ibuga kung kinahanglan nga butangan og pisi ang gihatag nga pisi
    /// * katukma, ang maximum gitas-on sa mobuga, ang hilo nga truncated kon kini mao ang na kay gitas-on niini nga
    ///
    /// Labing hinungdan nga kini nga kalihokan wala magtagad sa mga parameter nga `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Siguruha nga adunay usa ka tulin nga dalan sa atubangan
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Ang `precision` kapatagan mahimong hubaron ingon nga usa ka `max-width` alang sa hilo nga format.
        //
        let s = if let Some(max) = self.precision {
            // Kon ang atong hilo mao na nga ang tukma, nan kita kinahanglan nga adunay truncation.
            // Apan sa ubang mga bandera nga sama sa `fill`, `width` ug `align` kinahanglan molihok ingon nga sa kanunay.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Dili mapamatud-an sa LLVM dinhi nga ang `..i` dili panic `&s[..i]`, apan nahibal-an namon nga dili kini mahimo panic.
                // Paggamit `get` + `unwrap_or` aron malikayan ang `unsafe` ug kung dili ayaw pagbutang bisan unsang code nga may kalabotan sa panic dinhi.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Ang `width` nga uma labi pa sa usa ka `min-width` parameter sa kini nga punto.
        match self.width {
            // Kon kita sa ilalum sa maximum gitas-on, ug walay mga kinahanglanon minimum nga gitas-on, nan kita lang emit sa hilo
            //
            None => self.buf.write_str(s),
            // Kon kita sa ilalum sa maximum gilapdon, check kon kita sa minimum nga gilapdon, kon mao kini ingon ka sayon sa lang emitting sa pisi.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Kon kita sa ilalum sa mga maximum ug sa minimum gilapdon, unya pun-on sa mga minimum gilapdon sa mga bungat hilo + pipila paglaray, pagtalay.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Isulat ang pre-padding ug mobalik sa sinulat nga post-padding.
    /// Callers mao ang responsable alang sa pagsiguro post-padding nahisulat human ang butang nga nga miinat.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Gikuha ang mga bahin nga gi-format ug gigamit ang padding.
    /// Nga nangagpas nga ang caller na nga gihubad nga mga bahin sa gikinahanglan tukma, aron nga `self.precision` mahimong panumbalinga.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // alang sa zero padding nga nahibalo sa pag-sign, gihatagan namon una ang karatula ug pamatasan nga ingon wala kami pirma gikan sa sinugdanan.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ang usa ka timaan kanunay nga una
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // tangtanga ang karatula gikan sa gi-format nga mga bahin
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // nahibiling mga bahin adto pinaagi sa ordinaryo nga padding proseso.
            let len = formatted.len();
            let ret = if width <= len {
                // walay padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // mao kini ang komon nga kaso ug kita sa usa ka laktod nga paagi
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // KALUWAS: Gigamit kini alang sa `flt2dec::Part::Num` ug `flt2dec::Part::Copy`.
            // Kini luwas sa paggamit alang sa `flt2dec::Part::Num` kay ang matag char `c` mao ang tali sa `b'0'` ug `b'9'`, nga nagpasabot `s` balido UTF-8.
            // Kini usab tingali luwas diha sa buhat sa paggamit sa alang sa `flt2dec::Part::Copy(buf)` sukad `buf` kinahanglan nga patag ASCII, apan kini posible nga alang sa usa ka tawo sa nahitabo sa usa ka dili maayo nga bili alang sa `buf` ngadto sa `flt2dec::to_shortest_str` tungod kay kini mao ang usa ka publiko nga function.
            //
            // FIXME: Tinoa kon kini moresulta sa UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zeroes
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Nagsulat pipila nga datos sa nagpahiping buffer nga sulud sa sulud niining formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Kini mao ang katumbas sa:
    ///         // isulat! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Gisulat ang pila ka pormat nga kasayuran sa kini nga pananglitan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Mga bandera alang sa pag-format
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Kinaiya nga gigamit ingon nga 'fill' sa matag higayon nga adunay paglaray, pagtalay.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Gitakda namon ang pag-align sa tuo sa ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flag nga nagpakita kung unsang porma sa paghanay ang gihangyo.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Optionally bungat integer gilapdon nga ang output kinahanglan nga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Kung nakadawat kami usa ka gilapdon, gigamit namon kini
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Kay kon dili kita mobuhat sa bisan unsa nga espesyal nga
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optionally bungat katukma sa numerawo matang.
    /// Sa laing bahin, ang maximum gilapdon alang sa mga matang sa hilo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Kon kita nakadawat sa usa ka tukma, kita mogamit niini.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Kay kon dili, gibutang namon ang 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Pagtino kung gitino ang bandila nga `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Motino kon ang `-` bandila nga bungat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Ikaw gusto sa usa ka minus nga ilhanan?Adunay usa!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Pagtino kung gitino ang bandila nga `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Pagtino kung gitino ang bandila nga `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // atong ibaliwala mga kapilian sa formatter ni.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Desisyoni kon unsay publiko API gusto kita sa niining duha ka mga bandila.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Nagmugna sa usa ka [`DebugStruct`] magtutukod gidisenyo aron sa pagtabang sa uban sa paglalang sa [`fmt::Debug`] implementar alang sa structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Nagmugna sa usa ka `DebugTuple` magtutukod gidisenyo aron sa pagtabang sa uban sa paglalang sa `fmt::Debug` implementar alang sa tuple structs.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Naghimo usa ka magtutukod nga `DebugList` nga gilaraw aron matabangan ang paghimo sa mga pagpatuman sa `fmt::Debug` alang sa sama sa lista nga mga istruktura.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Naghimo usa ka magtutukod nga `DebugSet` nga gilaraw aron matabangan sa paghimo sa mga pagpatuman sa `fmt::Debug` alang sa mga istruktura nga sama sa gitakda.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Sa niini nga mas komplikado nga panig-ingnan, atong gamiton [`format_args!`] ug `.debug_set()` sa pagtukod sa usa ka listahan sa mga duwa bukton:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Naghimo usa ka magtutukod nga `DebugMap` nga gilaraw aron matabangan ang paghimo sa mga pagpatuman sa `fmt::Debug` alang sa mga istruktura nga sama sa mapa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementar sa sa sa kinauyokan formatting traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Kon char mga panginahanglan makaikyas, flush backlog sa ingon sa halayo ug isulat, lain Skip
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Ang laing bandila na pagtratar sa LowerHex nga specialist nga kini nagpasabot kon sa prefix sa 0x.
        // Kita sa paggamit sa kini sa pagtrabaho sa ba o dili ngadto sa zero-extend, ug unya walay kondisyon gibutang kini sa pagkuha sa mga prefix.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Pagpatuman sa Display/Debug alang sa mga nagkalain-laing matang sa kinauyokan

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Ang RefCell ang mutably hinulaman aron kita dili motan-aw sa iyang bili dinhi.
                // Ipakita hinoon ang usa ka placeholder.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Kung gipaabut nimo nga ang mga pagsulay dinhi, tan-awa hinoon sa core/tests/fmt.rs file, kini labi ka kadali kaysa paghimo sa tanan nga mga istruktura nga rt::Piece dinhi.
//
// Adunay usab mga pagsulay sa paggahin crate, alang sa mga nanginahanglan nga paggahin.