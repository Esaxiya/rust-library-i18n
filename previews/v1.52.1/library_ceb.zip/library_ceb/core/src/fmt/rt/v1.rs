//! Kini mao ang usa ka internal nga module nga gigamit sa mga ifmt!runtime.Ang kini nga mga istruktura gipagawas sa mga static arrays aron maandam ang mga pisi sa format sa wala pa ang panahon.
//!
//! Kini nga mga depinisyon susama sa ilang `ct` katumbas, apan lahi sa nga kini nga mga mahimo nga sa urong gigahin ug gamay optimized alang sa Runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Posible nga mga paghan-ay nga mahimong mapangayo ingon usa ka bahin sa usa ka direktiba sa pag-format.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Timailhan nga ang mga sulud kinahanglan nga makahanay sa wala.
    Left,
    /// Timailhan nga sulod kinahanglan nga tuo-ilaray.
    Right,
    /// Timailhan nga ang mga sulud kinahanglan ipahiangay sa sentro.
    Center,
    /// Walay pagpahiangay gihangyo.
    Unknown,
}

/// Gigamit pinaagi sa [width](https://doc.rust-lang.org/std/fmt/#width) ug [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Gitino sa usa ka literal nga numero, gitipig ang kantidad
    Is(usize),
    /// Bungat sa paggamit `$` ug `*` syntaxes, tindahan sa index ngadto sa `args`
    Param(usize),
    /// Wala gitudlo
    Implied,
}