// ignore-tidy-filelength

//! Pagdumala sa tipik ug pagmaniobra.
//!
//! Alang sa dugang nga mga detalye tan-awa ang [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ang puro nga rust memchr nga pagpatuman, gikuha gikan sa rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Kini nga kalihokan publiko ra tungod kay wala`y uban pa nga paagi sa heapsort sa pagsulay sa yunit.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Gibalik ang gidaghanon sa mga elemento sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // KALUWASAN: nag-ayo ang tunog tungod kay gibalhin namon ang taas nga natad ingon usa ka usize (nga kinahanglan gyud)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: kini mao ang luwas tungod kay `&[T]` ug `FatPtr<T>` makabaton sa sama nga layout.
            // Lamang `std` makahimo niini nga garantiya.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Pag-ilis sa `crate::ptr::metadata(self)` kung kana stable.
            // Ingon sa kini nga sinulat niini nga maoy hinungdan sa usa ka "Const-stable functions can only call other const-stable functions" sayop.
            //

            // KALUWASAN: Ang pag-access sa kantidad gikan sa `PtrRepr` nga unyon luwas na tungod sa * const T
            // ug mga PtrComponent<T>adunay parehas nga mga layout sa memorya.
            // Ang std ra ang makahimo niini nga garantiya.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Mobalik `true` kon ang ad-ad sa usa ka gitas-on sa 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Gibalik ang una nga elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gibalik ang usa ka mutable pointer sa unang elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gibalik ang una ug tanan nga nahabilin nga mga elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gibalik ang una ug tanan nga nahabilin nga mga elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gibalik ang katapusan ug tanan nga nahabilin nga mga elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Gibalik ang katapusan ug tanan nga nahabilin nga mga elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Gibalik ang katapusang elemento sa hiwa, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Mobalik sa usa ka mutable pointer sa katapusang aytem diha sa ad-ad.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Mobalik usa ka pakisayran sa usa ka elemento o subslice depende sa lahi sa indeks.
    ///
    /// - Kung hatagan usa ka posisyon, ibalik ang usa ka pakisayran sa elemento sa kana nga posisyon o `None` kung wala sa utlanan.
    ///
    /// - Kon gihatag sa usa ka range, mobalik ang subslice nga katumbas sa laing, o `None` kon gikan sa mga utlanan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Mobalik sa usa ka mabalhin nga pakisayran sa usa ka elemento o subslice depende sa lahi sa indeks (tan-awa ang [`get`]) o `None` kung ang indeks wala sa utlanan.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Nagbalik usa ka pakisayran sa usa ka elemento o subslice, nga wala gihimo ang pagsusi sa utlanan.
    ///
    /// Alang sa usa ka luwas nga kapilian tan-awa ang [`get`].
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini nga pamaagi uban sa usa ka out-of-utlanan index mao ang *[dili tino ang kinaiya]* bisan kon ang resulta paghisgot wala gigamit.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // KALUWASAN: kinahanglan nga ipadayon sa nanawag ang kadaghanan sa mga kinahanglanon sa kahilwasan alang sa `get_unchecked`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Nagbalik usa ka mabalhin nga pakisayran sa usa ka elemento o subslice, nga wala gihimo ang pagsusi sa mga utlanan.
    ///
    /// Alang sa usa ka luwas nga kapilian tan-awa ang [`get_mut`].
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini nga pamaagi uban sa usa ka out-of-utlanan index mao ang *[dili tino ang kinaiya]* bisan kon ang resulta paghisgot wala gigamit.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: ang caller kinahanglan pagtuboy sa mga kinahanglanon sa kaluwasan alang sa `get_unchecked_mut`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Mobalik usa ka hilaw nga pahimangno sa buffer sa hiwa.
    ///
    /// Kinahanglan nga sigurohon sa nanawag nga ang slice mas taas og kinabuhi ang pointer nga mobalik kini nga function, o kung dili matapos kini nga magtudlo sa basura.
    ///
    /// Kinahanglan usab nga masiguro sa nanawag nga ang panumduman nga gitudlo sa pointer (non-transitively) nga wala gyud gisulat (gawas sa sulud sa usa ka `UnsafeCell`) nga gigamit kini nga pointer o bisan unsang pointer nga nakuha gikan niini.
    /// Kung kinahanglan nimo nga mutate ang sulud sa hiwa, gamita ang [`as_mut_ptr`].
    ///
    /// Ang pagbag-o sa sulud nga gi-refer sa kini nga hiwa mahimo nga hinungdan nga maibutang ang buffer niini, diin mahimo usab nga kini dili husto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Mobalik sa usa ka luwas mutable pointer sa buffer sa ad-ad sa.
    ///
    /// Kinahanglan nga sigurohon sa nanawag nga ang slice mas taas og kinabuhi ang pointer nga mobalik kini nga function, o kung dili matapos kini nga magtudlo sa basura.
    ///
    /// Ang pagbag-o sa sulud nga gi-refer sa kini nga hiwa mahimo nga hinungdan nga maibutang ang buffer niini, diin mahimo usab nga kini dili husto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Gibalik ang duha nga hilaw nga mga panudlo nga naglangkob sa hiwa.
    ///
    /// Ang naibalik nga sakup tunga-tunga nga ablihan, nga nagpasabut nga ang mga punto sa pagtapos sa punto *usa ka nangagi* ang katapusang elemento sa hiwa.
    /// Niining paagiha, ang usa ka walay sulod nga hiwa girepresenta sa duha nga managsama nga mga panudlo, ug ang pagkalainlain taliwala sa duha nga mga panudlo nagrepresentar sa kadako sa hiwa.
    ///
    /// Tan-awa ang [`as_ptr`] alang sa mga pasidaan sa paggamit niini nga mga tambag.Ang pagtudlo sa katapusan nanginahanglan dugang nga pagbantay, tungod kay wala kini nagpunting sa usa ka balido nga elemento sa hiwa.
    ///
    /// Kapuslan kini nga pag-andar alang sa pakig-uban sa mga langyaw nga interface nga gigamit ang duha nga tudlo aron magtumong sa us aka mga elemento sa memorya, sama sa kasagarang sa C++ .
    ///
    ///
    /// Mahimo usab nga magamit aron masusi kung ang usa ka punto sa usa ka elemento nagpunting sa usa ka elemento sa kini nga hiwa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // KALUWASAN: Ang `add` dinhi luwas, tungod kay:
        //
        //   - Ang parehas nga mga panudlo bahin sa parehas nga butang, tungod kay ang pagtudlo nga diretso nga nakalabay usab ang butang nga giisip usab.
        //
        //   - Ang kadako sa hiwa dili gyud labi ka daghan sa isize::MAX bytes, ingon sa nahisgutan dinhi:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Walay pagputos sa palibot nga nalambigit, ingon sa mga hiwa dili wrap nangagi sa katapusan sa luna address.
        //
        // Tan-awa ang dokumento sa pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Mobalik ang duha ka luwas mutable pointers nga mikabat sa ad-ad.
    ///
    /// Ang naibalik nga sakup tunga-tunga nga ablihan, nga nagpasabut nga ang mga punto sa pagtapos sa punto *usa ka nangagi* ang katapusang elemento sa hiwa.
    /// Niining paagiha, ang usa ka walay sulod nga hiwa girepresenta sa duha nga managsama nga mga panudlo, ug ang pagkalainlain taliwala sa duha nga mga panudlo nagrepresentar sa kadako sa hiwa.
    ///
    /// Tan-awa ang [`as_mut_ptr`] alang sa mga pasidaan sa paggamit niini nga mga tambag.
    /// Ang katapusan pointer nagkinahanglan og dugang nga Pasidaan, ingon nga kini dili itudlo sa usa ka balido nga elemento sa ad-ad.
    ///
    /// Kapuslan kini nga pag-andar alang sa pakig-uban sa mga langyaw nga interface nga gigamit ang duha nga tudlo aron magtumong sa us aka mga elemento sa memorya, sama sa kasagarang sa C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // KALUWASAN: Kitaa ang as_ptr_range() sa taas kung nganong luwas ang `add` dinhi.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ipuli ang duha nga elemento sa hiwa.
    ///
    /// # Arguments
    ///
    /// * a, Ang indeks sa una nga elemento
    /// * b, Ang index sa ikaduhang elemento
    ///
    /// # Panics
    ///
    /// Panics kon `a` o `b` mao ang gikan sa mga utlanan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // dili pagkuha sa duha ka mutable pautang gikan sa usa ka vector, mao nga sa baylo sa paggamit sa hilaw nga mga tambag.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // KALUWASAN: Ang `pa` ug `pb` gihimo gikan sa luwas nga mga mutable referensya ug refer
        // sa mga elemento sa hiwa ug busa gigarantiyahan nga mahimong balido ug nakahanay.
        // Hinumdomi nga ang pag-access sa mga elemento sa luyo sa `a` ug `b` gisusi ug panic kung wala sa mga utlanan.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Gibali ang han-ay sa mga elemento diha sa ad-ad, sa dapit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Alang sa gagmay kaayo nga tipo, ang tanan nga indibidwal magbasa sa naandan nga agianan nga dili maayo ang pagbuhat.
        // Mahimo naton ang labi ka maayo, nga nahatagan episyente nga wala gipahiangay nga load/store, pinaagi sa pagkarga sa labi ka daghang tipak ug pag-usab sa usa ka rehistro.
        //

        // Minithi LLVM ang pagbuhat niini alang kanato, ingon nga kini mas nahibalo kay sa atong buhaton kon wala matumong mabasa ang mga hapsay (sukad nga ang mga kausaban tali sa lain-laing mga bersiyon sa ARM, alang sa panig-ingnan) ug unsa ang labing maayo nga gidak-on chunk nga.
        // Ikasubo, ingon sa LLVM 4.0 (2017-05) kini lamang unrolls sa laang, mao nga kita kinahanglan nga sa pagbuhat niini sa atong mga kaugalingon.
        // (Hypothesis: ang kalisud makahasol tungod kay ang mga kilid mahimo nga lainlain ang paglinya-mahimo, kung ang gitas-on lahi-busa wala'y paagi sa pagpagawas sa una ug pagkahuman aron magamit ang hingpit nga nakahanay nga SIMD sa tunga.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Gamita ang llvm.bswap intrinsic aron balihon ang mga u8 sa usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // KALUWASAN: Adunay daghang mga butang nga susihon dinhi:
                //
                // - Hinumdomi nga ang `chunk` bisan kinsa 4 o 8 tungod sa pagsusi sa CFg sa taas.Mao nga positibo ang `chunk - 1`.
                // - Pag-indeks sa index `i` maayo sama sa garantiya laang check
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Maayo ang pag-indeks uban ang index `ln - i - chunk = ln - (i + chunk)`:
                //   - `i + chunk > 0` hinungdanon kaayo.
                //   - Ang garantiya sa loop nagsiguro:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, sa ingon dili makuha ang ilawom sa ilawom.
                // - Maayo ang mga tawag sa `read_unaligned` ug `write_unaligned`:
                //   - `pa` puntos sa index `i` diin `i < ln / 2 - (chunk - 1)` (tan-awa sa ibabaw) ug `pb` puntos sa index `ln - i - chunk`, mao nga ang duha mao ang labing menos `chunk` sa daghang bytes gikan sa katapusan sa `self`.
                //
                //   - Ang bisan unsang gisugdan nga memorya balido `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Paggamit rotate-by-16 aron balihon ang mga u16 sa usa ka u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // KALUWAS: Ang us aka wala nakapahiangay nga u32 mahimong mabasa gikan sa `i` kung `i + 1 < ln`
                // (ug klaro nga `i < ln`), tungod kay ang matag elemento 2 bytes ug gibasa namon ang 4.
                //
                // `i + chunk - 1 < ln / 2` # samtang kahimtang
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Tungod kay dili kini kaayo sa gitas-on nga gibahin sa 2, nan kinahanglan naa kini sa mga utlanan.
                //
                // Kini usab nagpasabut nga ang kondisyon nga `0 < i + chunk <= ln` kanunay gitahod, nga gisiguro ang `pb` pointer mahimong magamit nga luwas.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // KALUWASAN: Ang `i` mas mubu sa katunga sa gitas-on sa usa ka hiwa nga ingon niana
            // ang pag-access sa `i` ug `ln - i - 1` luwas (ang `i` magsugod sa 0 ug dili na moadto labi pa sa `ln / 2 - 1`).
            // Ang mga sangputanan nga panudlo nga `pa` ug `pb` busa balido ug nakahanay, ug mabasa gikan ug masulat sa.
            //
            //
            unsafe {
                // Luwas swap sa paglikay sa mga utlanan check sa luwas nga swap.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Gibalik ang usa ka iterator sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Nagbalik usa ka iterator nga nagtugot sa pagbag-o sa matag kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Gibalik ang usa ka iterator sa tanan nga kasikbit nga windows nga gitas-on `size`.
    /// Ang windows nagsapaw.
    /// Kung ang hiwa mas mubo kaysa `size`, wala itugyan sa iterator ang mga kantidad.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `size` mao ang 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kon ang ad-ad mao ang mas mubo pa kay sa `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Mobalik sa usa ka iterator sa `chunk_size` mga elemento sa ad-ad sa usa ka panahon, sugod sa sinugdanan sa ad-ad.
    ///
    /// Ang mga tipak mga hiwa ug dili magsapaw.Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon niana ang katapusang tipak dili adunay gitas-on nga `chunk_size`.
    ///
    /// Tan-awa ang [`chunks_exact`] alang sa usa ka lahi sa kini nga iterator nga nagpabalik sa mga tipak kanunay nga eksakto nga `chunk_size` nga mga elemento, ug [`rchunks`] alang sa parehas nga iterator apan nagsugod sa katapusan sa hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Mobalik sa usa ka iterator sa `chunk_size` mga elemento sa ad-ad sa usa ka panahon, sugod sa sinugdanan sa ad-ad.
    ///
    /// Ang mga tipak mga mutable slice, ug dili magsapaw.Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon niana ang katapusang tipak dili adunay gitas-on nga `chunk_size`.
    ///
    /// Tan-awa ang [`chunks_exact_mut`] alang sa usa ka laing porma sa iterator niini nga pagbalik chunks sa kanunay gayud `chunk_size` mga elemento, ug [`rchunks_mut`] alang sa sama nga iterator apan sugod sa katapusan sa mga ad-ad.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Mobalik sa usa ka iterator sa `chunk_size` mga elemento sa ad-ad sa usa ka panahon, sugod sa sinugdanan sa ad-ad.
    ///
    /// Ang mga tipak mga hiwa ug dili magsapaw.
    /// Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `chunk_size-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `remainder` function sa iterator.
    ///
    ///
    /// Tungod sa matag tipak nga adunay eksakto nga `chunk_size` nga mga elemento, ang tagatala kanunay nga ma-optimize ang resulta nga code nga labi ka maayo kaysa sa kaso nga [`chunks`].
    ///
    /// Tan-awa ang [`chunks`] alang sa usa ka lahi sa kini nga iterator nga ibalik usab ang nahabilin ingon usa ka gamay nga tipak, ug [`rchunks_exact`] alang sa parehas nga iterator apan magsugod sa katapusan sa hiwa.
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Mobalik sa usa ka iterator sa `chunk_size` mga elemento sa ad-ad sa usa ka panahon, sugod sa sinugdanan sa ad-ad.
    ///
    /// Ang mga tipak mga mutable slice, ug dili magsapaw.
    /// Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `chunk_size-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `into_remainder` function sa iterator.
    ///
    ///
    /// Tungod sa matag tipak nga adunay eksakto nga `chunk_size` nga mga elemento, ang tagatala kanunay nga ma-optimize ang resulta nga code nga labi ka maayo kaysa sa kaso nga [`chunks_mut`].
    ///
    /// Tan-awa ang [`chunks_mut`] alang sa usa ka lahi sa kini nga iterator nga ibalik usab ang nahabilin ingon usa ka gamay nga tipak, ug [`rchunks_exact_mut`] alang sa parehas nga iterator apan magsugod sa katapusan sa hiwa.
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Gibahinbahin ang hiwa sa usa ka hiwa sa `N`-element arrays, sa paghunahuna nga wala`y nahabilin.
    ///
    ///
    /// # Safety
    ///
    /// Kini mahimong lamang nga gitawag sa diha nga
    /// - ad-ad sa mga magabugha gayud ngadto sa `N`-elemento chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: 1-elemento chunks dili adunay nahibilin
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // KALUWASAN: Ang slice nga gitas-on nga (6) usa ka kadaghan nga 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Kini dili matarong:
    /// // tugoti ang mga tipak: &[[_;5]]= slice.as_chunks_unchecked()//Ang ad-ad gitas-on mao ang dili usa ka daghang mga sa 5 gibuhian chunks:&[[_;0]]= slice.as_chunks_unchecked()//Zero-ang gitas-on chunks wala na gayod tugoti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KALUWASAN: Ang among precondition mao gyud ang kinahanglan aron kini tawgon
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KALUWAS: Gisalibay namon ang usa ka slice sa `new_len * N` nga mga elemento
        // usa ka hiwa nga `new_len` daghang mga elemento sa `N` nga mga tipak.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Magabugha sa ad-ad ngadto sa usa ka ad-ad sa `N`-elemento arrays, sugod sa sinugdanan sa ad-ad, ug ang usa ka salin ad-ad uban sa gitas-on sa hugot nga ubos pa kay sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Kita na nahadlok alang sa zero, ug nagsiguro sa pagtukod
        // nga ang gitas-on sa subslice usa ka kadaghan sa N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Gibahinbahin ang hiwa sa usa ka hiwa nga `N`-element arrays, sugod sa katapusan sa hiwa, ug usa nga nahabilin nga hiwa nga adunay gitas-on nga istrikto mas moubus sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Kita na nahadlok alang sa zero, ug nagsiguro sa pagtukod
        // nga ang gitas-on sa subslice usa ka kadaghan sa N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `N` nga mga elemento sa hiwa sa matag higayon, sugod sa pagsugod sa hiwa.
    ///
    /// Ang mga tipak mga han-ay nga pakisayran ug dili magsapaw.
    /// Kung ang `N` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `N-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `remainder` function sa iterator.
    ///
    ///
    /// Kini nga pamaagi mao ang kasagarang generic nga katumbas sa [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Gibahinbahin ang hiwa sa usa ka hiwa sa `N`-element arrays, sa paghunahuna nga wala`y nahabilin.
    ///
    ///
    /// # Safety
    ///
    /// Kini mahimong lamang nga gitawag sa diha nga
    /// - ad-ad sa mga magabugha gayud ngadto sa `N`-elemento chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: 1-elemento chunks dili adunay nahibilin
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // KALUWASAN: Ang slice nga gitas-on nga (6) usa ka kadaghan nga 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Kini dili matarong:
    /// // tugoti ang mga tipak: &[[_;5]]= slice.as_chunks_unchecked_mut()//Ang gitas-on sa slice dili usa ka kadaghan nga 5 pasagdan ang mga chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zero-ang gitas-on chunks wala na gayod tugoti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KALUWASAN: Ang among precondition mao gyud ang kinahanglan aron kini tawgon
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KALUWAS: Gisalibay namon ang usa ka slice sa `new_len * N` nga mga elemento
        // usa ka hiwa nga `new_len` daghang mga elemento sa `N` nga mga tipak.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Magabugha sa ad-ad ngadto sa usa ka ad-ad sa `N`-elemento arrays, sugod sa sinugdanan sa ad-ad, ug ang usa ka salin ad-ad uban sa gitas-on sa hugot nga ubos pa kay sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Kita na nahadlok alang sa zero, ug nagsiguro sa pagtukod
        // nga ang gitas-on sa subslice usa ka kadaghan sa N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Gibahinbahin ang hiwa sa usa ka hiwa nga `N`-element arrays, sugod sa katapusan sa hiwa, ug usa nga nahabilin nga hiwa nga adunay gitas-on nga istrikto mas moubus sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Kita na nahadlok alang sa zero, ug nagsiguro sa pagtukod
        // nga ang gitas-on sa subslice usa ka kadaghan sa N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `N` nga mga elemento sa hiwa sa matag higayon, sugod sa pagsugod sa hiwa.
    ///
    /// Ang mga tipak mabalhin nga mga pakisayran sa array ug dili magsapaw.
    /// Kung ang `N` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `N-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `into_remainder` function sa iterator.
    ///
    ///
    /// Kini nga pamaagi mao ang kasagarang generic nga katumbas sa [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0. Kini nga tseke tingali mahimo`g mabag-o sa usa ka compile nga sayup sa oras sa wala pa magpadayon ang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Gibalik ang usa ka iterator sa nagsapawan nga windows nga `N` nga mga elemento sa usa ka hiwa, sugod sa pagsugod sa hiwa.
    ///
    ///
    /// Kini ang katumbas nga generic nga katumbas sa [`windows`].
    ///
    /// Kung ang `N` mas daghan kaysa sa gidak-on sa hiwa, ibalik kini nga wala`y windows.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `N` mao ang 0.
    /// Ang kini nga tseke tingali nabag-ohan sa usa ka sayup sa oras nga pagtipon sa wala pa mapahimutang kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `chunk_size` nga mga elemento sa hiwa sa usa ka oras, sugod sa katapusan sa hiwa.
    ///
    /// Ang mga tipak mga hiwa ug dili magsapaw.Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon niana ang katapusang tipak dili adunay gitas-on nga `chunk_size`.
    ///
    /// Tan-awa ang [`rchunks_exact`] alang sa usa ka lahi sa kini nga iterator nga nagpabalik sa mga tipak nga kanunay nga eksakto nga `chunk_size` nga mga elemento, ug [`chunks`] alang sa parehas nga iterator apan nagsugod sa pagsugod sa hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `chunk_size` nga mga elemento sa hiwa sa usa ka oras, sugod sa katapusan sa hiwa.
    ///
    /// Ang mga tipak mga mutable slice, ug dili magsapaw.Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon niana ang katapusang tipak dili adunay gitas-on nga `chunk_size`.
    ///
    /// Tan-awa ang [`rchunks_exact_mut`] alang sa usa ka lahi sa kini nga iterator nga nagpabalik sa mga tipak nga kanunay nga eksakto nga `chunk_size` nga mga elemento, ug [`chunks_mut`] alang sa parehas nga iterator apan nagsugod sa pagsugod sa hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `chunk_size` nga mga elemento sa hiwa sa usa ka oras, sugod sa katapusan sa hiwa.
    ///
    /// Ang mga tipak mga hiwa ug dili magsapaw.
    /// Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `chunk_size-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `remainder` function sa iterator.
    ///
    /// Tungod sa matag tipak nga adunay eksakto nga `chunk_size` nga mga elemento, ang tagatala kanunay nga ma-optimize ang resulta nga code nga labi ka maayo kaysa sa kaso nga [`chunks`].
    ///
    /// Tan-awa ang [`rchunks`] alang sa usa ka lahi sa kini nga iterator nga ibalik usab ang nahabilin ingon usa ka gamay nga tipak, ug [`chunks_exact`] alang sa parehas nga iterator apan magsugod sa pagsugod sa hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Gibalik ang usa ka iterator sa sobra sa `chunk_size` nga mga elemento sa hiwa sa usa ka oras, sugod sa katapusan sa hiwa.
    ///
    /// Ang mga tipak mga mutable slice, ug dili magsapaw.
    /// Kung ang `chunk_size` dili gibahin ang gitas-on sa usa ka hiwa, kung ingon ang katapusan hangtod sa `chunk_size-1` nga mga elemento mawala ug mahimo nga makuha gikan sa `into_remainder` function sa iterator.
    ///
    /// Tungod sa matag tipak nga adunay eksakto nga `chunk_size` nga mga elemento, ang tagatala kanunay nga ma-optimize ang resulta nga code nga labi ka maayo kaysa sa kaso nga [`chunks_mut`].
    ///
    /// Tan-awa ang [`rchunks_mut`] alang sa usa ka lahi sa kini nga iterator nga ibalik usab ang nahabilin ingon usa ka gamay nga tipak, ug [`chunks_exact_mut`] alang sa parehas nga iterator apan magsugod sa pagsugod sa hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon `chunk_size` mao 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Gibalik ang usa ka iterator sa hiwa nga nagprodyus nga dili nagsaput nga mga pagdagan sa mga elemento gamit ang predicate aron mabulag sila.
    ///
    /// Gitawag ang predicate sa duha nga elemento nga nagsunud sa ilang kaugalingon, kini nagpasabut nga ang predicate gitawag sa `slice[0]` ug `slice[1]` dayon sa `slice[1]` ug `slice[2]` ug uban pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mahimo kini nga pamaagi aron makuha ang mga naayos nga mga suskrisyon:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Gibalik ang usa ka iterator sa hiwa nga nagprodyus nga dili nagsapaw nga mga mutable nga pagdagan sa mga elemento gamit ang predicate aron mabulag sila.
    ///
    /// Gitawag ang predicate sa duha nga elemento nga nagsunud sa ilang kaugalingon, kini nagpasabut nga ang predicate gitawag sa `slice[0]` ug `slice[1]` dayon sa `slice[1]` ug `slice[2]` ug uban pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mahimo kini nga pamaagi aron makuha ang mga naayos nga mga suskrisyon:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Gibahin ang usa ka hiwa sa duha sa usa ka indeks.
    ///
    /// Ang una maglangkob sa tanan nga mga indeks gikan sa `[0, mid)` (wala`y labot ang indeks nga `mid` mismo) ug ang ikaduha adunay sulud nga tanan nga mga indeks gikan sa `[mid, len)` (wala`y labot ang indeks nga `len` mismo).
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // KALUWASAN: Ang `[ptr; mid]` ug `[mid; len]` naa sa sulud sa `self`, diin
        // nagtuman sa mga kinahanglanon sa `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Mabahin usa mutable ad-ad ngadto sa duha ka sa usa ka index.
    ///
    /// Ang una maglangkob sa tanan nga mga indeks gikan sa `[0, mid)` (wala`y labot ang indeks nga `mid` mismo) ug ang ikaduha adunay sulud nga tanan nga mga indeks gikan sa `[mid, len)` (wala`y labot ang indeks nga `len` mismo).
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // KALUWASAN: Ang `[ptr; mid]` ug `[mid; len]` naa sa sulud sa `self`, diin
        // nagtuman sa mga kinahanglanon sa `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Gibahin ang usa ka hiwa sa duha sa usa ka indeks, nga wala gihimo ang pag-check sa utlanan.
    ///
    /// Ang una maglangkob sa tanan nga mga indeks gikan sa `[0, mid)` (wala`y labot ang indeks nga `mid` mismo) ug ang ikaduha adunay sulud nga tanan nga mga indeks gikan sa `[mid, len)` (wala`y labot ang indeks nga `len` mismo).
    ///
    ///
    /// Kay sa usa ka luwas nga alternatibo tan-awa ang [`split_at`].
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini nga pamaagi uban sa usa ka out-of-utlanan index mao ang *[dili tino ang kinaiya]* bisan kon ang resulta paghisgot wala gigamit.Kinahanglan nga masiguro sa nanawag nga `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // KALUWASAN: Kinahanglan nga susihon sa nanawag ang `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Gibahin ang usa ka mutable slice sa duha sa usa ka indeks, nga wala gihimo ang pagsusi sa utlanan.
    ///
    /// Ang una maglangkob sa tanan nga mga indeks gikan sa `[0, mid)` (wala`y labot ang indeks nga `mid` mismo) ug ang ikaduha adunay sulud nga tanan nga mga indeks gikan sa `[mid, len)` (wala`y labot ang indeks nga `len` mismo).
    ///
    ///
    /// Alang sa usa ka luwas nga kapilian tan-awa ang [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini nga pamaagi uban sa usa ka out-of-utlanan index mao ang *[dili tino ang kinaiya]* bisan kon ang resulta paghisgot wala gigamit.Kinahanglan nga masiguro sa nanawag nga `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // KALUWASAN: Kinahanglan nga susihon sa nanawag ang `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ug ang `[mid; len]` dili nagsapawan, busa ang pagbalik sa usa ka mabalhin nga pakisayran maayo ra.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Gibalik ang usa ka iterator sa mga subslice nga gibulag sa mga elemento nga parehas sa `pred`.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang nahauna nga elemento gipares, usa ka walay sulod nga hiwa ang una nga butang nga ibalik sa iterator.
    /// Sa susama, kon sa katapusan nga elemento sa sa ad-ad mao ang magkapareha, usa ka walay sulod nga ad-ad mao ang katapusan nga butang mibalik sa iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang duha nga gisukma nga mga elemento direkta nga magkadugtong, usa ka walay sulod nga hiwa ang anaa sa taliwala nila:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Gibalik ang usa ka iterator sa mga mabalhin nga mga subslice nga gibulag sa mga elemento nga parehas sa `pred`.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Gibalik ang usa ka iterator sa mga subslice nga gibulag sa mga elemento nga parehas sa `pred`.
    /// Ang katugbang nga elemento sulud sa katapusan sa miaging subslice ingon usa ka terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang katapusang elemento sa hiwa nga magkatugma, kana nga elemento maisip nga terminator sa naunang hiwa.
    ///
    /// Ang kana nga tipik mao ang katapusang butang nga ibalik sa iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Gibalik ang usa ka iterator sa mga mabalhin nga mga subslice nga gibulag sa mga elemento nga parehas sa `pred`.
    /// Ang katugbang nga elemento adunay sulud sa miaging subslice ingon usa ka terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Gibalik ang usa ka iterator sa mga subslice nga gilain sa mga elemento nga parehas sa `pred`, sugod sa katapusan sa hiwa ug pagtrabaho nga paatras.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sama sa `split()`, kung ang una o ulahi nga elemento nga katugma, ang usa ka walay sulod nga hiwa ang una (o katapusan) nga butang nga ibalik sa iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Mobalik sa usa ka iterator sa mutable subslices mibulag sa mga elemento nga motakdo `pred`, sugod sa katapusan sa mga ad-ad ug nagtrabaho nga paatras.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Mobalik sa usa ka iterator sa subslices mibulag sa mga elemento nga motakdo `pred`, limitado sa pagbalik sa labing `n` mga butang.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// Ang ulahi nga elemento nga gibalik, kung adunay, maglangkob sa nahabilin sa hiwa.
    ///
    /// # Examples
    ///
    /// Isulat ang ad-ad split makausa pinaagi sa mga numero bahinon sa 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Mobalik sa usa ka iterator sa subslices mibulag sa mga elemento nga motakdo `pred`, limitado sa pagbalik sa labing `n` mga butang.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// Ang ulahi nga elemento nga gibalik, kung adunay, maglangkob sa nahabilin sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Gibalik ang usa ka iterator sa mga subslice nga gibulag sa mga elemento nga parehas sa `pred` nga limitado sa pagbalik sa kadaghanan nga mga item nga `n`.
    /// Nagsugod kini sa katapusan sa hiwa ug molihok paatras.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// Ang ulahi nga elemento nga gibalik, kung adunay, maglangkob sa nahabilin sa hiwa.
    ///
    /// # Examples
    ///
    /// Ig-print ang hiwa nga nabahin kausa, sugod gikan sa katapusan, sa mga numero nga dili mabahin sa 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Gibalik ang usa ka iterator sa mga subslice nga gibulag sa mga elemento nga parehas sa `pred` nga limitado sa pagbalik sa kadaghanan nga mga item nga `n`.
    /// Nagsugod kini sa katapusan sa hiwa ug molihok paatras.
    /// Ang nakigtagbo elemento dili anaa sa subslices.
    ///
    /// Ang ulahi nga elemento nga gibalik, kung adunay, maglangkob sa nahabilin sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Mibalik `true` kon ang ad-ad naglakip sa usa ka elemento sa gihatag nga bili.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Kon kamo wala sa usa ka `&T`, apan usa lamang ka `&U` sa ingon nga `T: Borrow<U>` (eg
    /// `String: Paghulam<str>`), Nga imong mahimo sa paggamit sa `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // hiwa sa `String`
    /// assert!(v.iter().any(|e| e == "hello")); // pangitaa sa `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Mibalik `true` kon `needle` mao ang usa ka prefix sa ad-ad.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Kanunay mobalik `true` kon `needle` mao ang usa ka walay sulod nga ad-ad:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Gibalik ang `true` kung ang `needle` us aka suffix sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Kanunay mobalik `true` kon `needle` mao ang usa ka walay sulod nga ad-ad:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Mobalik usa ka subslice nga gitangtang sa unlapi.
    ///
    /// Kung ang slice nagsugod sa `prefix`, ibalik ang subslice pagkahuman sa prefiks, giputos sa `Some`.
    /// Kung ang `prefix` walay sulod, ibalik ra ang orihinal nga hiwa.
    ///
    /// Kung ang hiwa dili magsugod sa `prefix`, ibalik ang `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // function Kini kinahanglan liwaton kon ug sa diha nga SlicePattern mahimong mas sopistikado.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Mobalik sa usa ka subslice sa suffix gikuha.
    ///
    /// Kung ang hiwa natapos sa `suffix`, ibalik ang subslice sa wala pa ang suffix, giputos sa `Some`.
    /// Kung ang `suffix` walay sulod, ibalik ra ang orihinal nga hiwa.
    ///
    /// Kung ang hiwa dili matapos sa `suffix`, ibalik ang `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // function Kini kinahanglan liwaton kon ug sa diha nga SlicePattern mahimong mas sopistikado.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Gipangita sa binary ang kini nga gihusay nga hiwa alang sa usa ka gihatag nga elemento.
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.
    /// Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    ///
    /// Tan-awa usab ang [`binary_search_by`], [`binary_search_by_key`], ug [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nagpangita usa ka serye sa upat nga mga elemento.
    /// Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Kon kamo gusto nga sal-ot sa usa ka butang ngadto sa usa ka lainlainon vector, samtang sa pagmintinar sa matang order:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Gipangita sa binary ang kini nga gilain nga hiwa nga adunay usa ka function sa kumpare
    ///
    /// Ang comparator function kinahanglan pagpatuman sa usa ka order subay sa matang aron sa nahiilalum ad-ad, pagbalik sa usa ka order code nga nagpakita kon sa iyang argumento mao `Less`, `Equal` o `Greater` sa gitinguha nga target.
    ///
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    /// Tan-awa usab ang [`binary_search`], [`binary_search_by_key`], ug [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nagpangita usa ka serye sa upat nga mga elemento.Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // KALuwas-an: ang panawag gihimo nga luwas sa mga mosunud nga nag-imbitar:
            // - `mid >= 0`
            // - `mid < size`: `mid` limitado sa `[left; right)` gigapos.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Ang rason ngano nga kita sa paggamit sa if/else kontrol sa dagan kay sa duwa tungod kay operasyon match reorders pagtandi, nga mao ang perf sensitibo.
            //
            // Kini mao ang x86 Pabiling alang sa u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Duha pagpangita niini nga lainlainon ad-ad sa usa ka yawe nga pagkuha function.
    ///
    /// Nga nangagpas nga ang ad-ad ang lainlainon sa yawe, pananglitan uban [`sort_by_key`] sa paggamit sa sama nga mga yawe nga pagkuha function.
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.
    /// Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    ///
    /// Tan-awa usab ang [`binary_search`], [`binary_search_by`], ug [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nagtan-aw sa usa ka serye sa upat nga mga elemento sa usa ka hiwa nga mga pares nga gihan-ay sa ilang ikaduha nga mga elemento.
    /// Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Gitugotan ang Lint rustdoc::broken_intra_doc_links tungod kay ang `slice::sort_by_key` naa sa crate `alloc`, ug ingon niana wala pa diha sa pagtukod sa `core`.
    //
    // mga sumpay ngadto sa ilog nga crate: #74481.Tungod kay ang mga primitibo gidokumento ra sa libstd (#73423), dili gyud kini mosangput sa nabuak nga mga link sa praktis.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Giihap ang hiwa, apan dili mapreserba ang han-ay sa parehas nga mga elemento.
    ///
    /// Kini nga klase dili malig-on (ie, mahimong ayuhon pag-usab ang managsama nga mga elemento), sa lugar (ie, dili igahin), ug *O*(*n*\*log(* n*)) labing daotan nga kaso.
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gipasukad sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, nga naghiusa sa dali nga average nga kaso sa randomized quicksort uban ang labing dali nga labing daotan nga kaso sa heapsort, samtang ang pagkab-ot sa linear nga oras sa mga hiwa nga adunay piho nga mga sundanan.
    /// Naggamit kini pipila nga pag-randomize aron malikayan ang mga kaso nga naguba, apan adunay usa ka nakapirming seed aron kanunay maghatag deterministikong pamatasan.
    ///
    /// Kini mao ang kasagaran mas paspas kay sa lig-on hagpat, gawas sa pipila ka espesyal nga mga kaso, pananglitan, sa diha nga ang ad-ad naglangkob sa pipila ka mga concatenated lainlainon han-ay.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Giihap ang hiwa nga adunay kalihokan nga kumpare, apan dili mapreserba ang han-ay sa parehas nga mga elemento.
    ///
    /// Kini nga klase dili malig-on (ie, mahimong ayuhon pag-usab ang managsama nga mga elemento), sa lugar (ie, dili igahin), ug *O*(*n*\*log(* n*)) labing daotan nga kaso.
    ///
    /// Ang pag-andar sa kumpare kinahanglan kinahanglan nga ipasabut ang usa ka kinatibuk-an nga pag-order alang sa mga elemento sa hiwa.Kung ang pag-order dili total, ang pagkasunud-sunod sa mga elemento wala matino.Ang usa ka order usa ka kinatibuk-ang han-ay kung kini (alang sa tanan nga `a`, `b` ug `c`):
    ///
    /// * kinatibuk ug antisymmetric: gayud sa usa sa `a < b`, `a == b` o `a > b` tinuod, ug
    /// * Transitive, `a < b` ug `b < c` nagpasabot `a < c`.Ang parehas kinahanglan nga maghupot alang sa parehas nga `==` ug `>`.
    ///
    /// Pananglitan, samtang ang [`f64`] wala ipatuman ang [`Ord`] tungod kay `NaN != NaN`, mahimo namon gamiton ang `partial_cmp` ingon among paglihok sa paghan-ay kung nahibal-an namon nga ang hiwa wala sulud usa ka `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gipasukad sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, nga naghiusa sa dali nga average nga kaso sa randomized quicksort uban ang labing dali nga labing daotan nga kaso sa heapsort, samtang ang pagkab-ot sa linear nga oras sa mga hiwa nga adunay piho nga mga sundanan.
    /// Naggamit kini pipila nga pag-randomize aron malikayan ang mga kaso nga naguba, apan adunay usa ka nakapirming seed aron kanunay maghatag deterministikong pamatasan.
    ///
    /// Kini mao ang kasagaran mas paspas kay sa lig-on hagpat, gawas sa pipila ka espesyal nga mga kaso, pananglitan, sa diha nga ang ad-ad naglangkob sa pipila ka mga concatenated lainlainon han-ay.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // balik nga paghan-ay
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Giihap ang hiwa nga adunay usa ka hinungdan nga pagpaandar sa pagkuha, apan dili mapreserba ang han-ay sa parehas nga mga elemento.
    ///
    /// Kini nga klase dili malig-on (ie, mahimong ayohon pag-usab ang managsama nga mga elemento), sa lugar (ie, dili igahin), ug *O*(m\* * n *\* log(*n*)) labing kadaotan nga kaso, diin ang mahinungdanong pagpaandar mao ang *O*(*m*).
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gipasukad sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, nga naghiusa sa dali nga average nga kaso sa randomized quicksort uban ang labing dali nga labing daotan nga kaso sa heapsort, samtang ang pagkab-ot sa linear nga oras sa mga hiwa nga adunay piho nga mga sundanan.
    /// Naggamit kini pipila nga pag-randomize aron malikayan ang mga kaso nga naguba, apan adunay usa ka nakapirming seed aron kanunay maghatag deterministikong pamatasan.
    ///
    /// Tungod sa hinungdan nga estratehiya sa pagtawag, ang [`sort_unstable_by_key`](#method.sort_unstable_by_key) lagmit nga mas hinay kaysa [`sort_by_cached_key`](#method.sort_by_cached_key) sa mga kaso diin ang hinungdanon nga pagpaandar mahal.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reorder ang ad-ad sa ingon nga ang elemento sa `index` mao ang sa iyang katapusan nga lainlainon posisyon.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Usba pag-usab ang hiwa nga adunay usa ka function sa kumpare nga ang elemento sa `index` naa sa katapusan nga posisyon nga gihan-ay.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reorder sa ad-ad sa usa ka yawe nga pagkuha function sa ingon nga ang elemento sa `index` mao ang sa iyang katapusan nga lainlainon posisyon.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reorder ang ad-ad sa ingon nga ang elemento sa `index` mao ang sa iyang katapusan nga lainlainon posisyon.
    ///
    /// Ang kini nga pag-usab adunay dugang nga kabtangan nga ang bisan unsang kantidad sa posisyon nga `i < index` mas mubu o managsama sa bisan unsang kantidad sa posisyon nga `j > index`.
    /// Dugang pa, kini nga reordering mao ang mabalhinon (ie
    /// sa bisan unsa nga gidaghanon sa mga patas nga mga elemento aron matapos sa sa posisyon `index`), sa-dapit (ie
    /// wala mogahin), ug Oh *(* n *) labing-kaso.
    /// Kini nga pag-andar usab/nailhan nga "kth element" sa uban pang mga librarya.
    /// Kini mobalik sa usa ka triplet sa mosunod nga mga prinsipyo: sa tanan nga mga elemento nga ubos pa kay sa usa diha sa gihatag nga index, ang bili sa gihatag nga index, ug ang tanan nga mga elemento nga labaw pa kay sa usa diha sa gihatag nga index.
    ///
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gibase sa dali nga pagpili nga bahin sa parehas nga quicksort algorithm nga gigamit alang sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kung `index >= len()`, nagpasabut nga kanunay kini panics sa mga walay sulod nga hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Pangitaa ang median
    /// v.select_nth_unstable(2);
    ///
    /// // Kita garantiya lamang sa ad-ad mahimong usa sa mga mosunod nga, base sa paagi nga kita matang mahitungod sa espesipikong index.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Usba pag-usab ang hiwa nga adunay usa ka function sa kumpare nga ang elemento sa `index` naa sa katapusan nga posisyon nga gihan-ay.
    ///
    /// Ang kini nga pag-usab adunay dugang nga kabtangan nga ang bisan unsang kantidad sa posisyon nga `i < index` mas mubu o katumbas sa bisan unsang kantidad sa posisyon nga `j > index` gamit ang pagpaandar sa kumpare.
    /// Dugang pa, kini nga reordering mao ang mabalhinon (ie sa bisan unsa nga gidaghanon sa mga patas nga mga elemento aron matapos sa sa posisyon `index`), sa-dapit (ie wala mogahin), ug Oh *(* n *) labing-kaso.
    /// function Kini nga nailhan usab nga "kth element" sa ubang mga librarya.
    /// Gibalik niini ang usa ka triple sa mga mosunud nga kantidad: tanan nga mga elemento mas mubu sa usa sa gihatag nga indeks, ang kantidad sa gihatag nga indeks, ug tanan nga mga elemento nga labi ka daghan sa usa sa gihatag nga indeks, gamit ang gihatag nga pagpaarang nga kumpare.
    ///
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gibase sa dali nga pagpili nga bahin sa parehas nga quicksort algorithm nga gigamit alang sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kung `index >= len()`, nagpasabut nga kanunay kini panics sa mga walay sulod nga hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Pangitaa ang median ingon nga kon ang mga ad-ad sa mga lainlainon sa nga mikunsad aron.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Kita garantiya lamang sa ad-ad mahimong usa sa mga mosunod nga, base sa paagi nga kita matang mahitungod sa espesipikong index.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorder sa ad-ad sa usa ka yawe nga pagkuha function sa ingon nga ang elemento sa `index` mao ang sa iyang katapusan nga lainlainon posisyon.
    ///
    /// Ang paghan-ay usab kini adunay dugang nga kabtangan nga ang bisan unsang kantidad sa posisyon nga `i < index` mas mubu o managsama sa bisan unsang kantidad sa posisyon nga `j > index` gamit ang panguna nga function sa pagkuha.
    /// Dugang pa, kini nga reordering mao ang mabalhinon (ie sa bisan unsa nga gidaghanon sa mga patas nga mga elemento aron matapos sa sa posisyon `index`), sa-dapit (ie wala mogahin), ug Oh *(* n *) labing-kaso.
    /// function Kini nga nailhan usab nga "kth element" sa ubang mga librarya.
    /// Kini mobalik sa usa ka triplet sa mosunod nga mga prinsipyo: sa tanan nga mga elemento nga ubos pa kay sa usa diha sa gihatag nga index, ang bili sa gihatag nga index, ug ang tanan nga mga elemento nga labaw pa kay sa usa diha sa gihatag nga index, sa paggamit sa gihatag yawe pagkuha function.
    ///
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gibase sa dali nga pagpili nga bahin sa parehas nga quicksort algorithm nga gigamit alang sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kung `index >= len()`, nagpasabut nga kanunay kini panics sa mga walay sulod nga hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Bumalik ang median ingon nga kon ang mga gubat nga lainlainon sumala sa bug-os nga bili.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Kita garantiya lamang sa ad-ad mahimong usa sa mga mosunod nga, base sa paagi nga kita matang mahitungod sa espesipikong index.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Gibalhin ang tanan nga sunod-sunod nga gisubli nga mga elemento sa katapusan sa hiwa sumala sa pagpatuman sa [`PartialEq`] trait.
    ///
    ///
    /// Gibalik ang duha nga mga hiwa.Ang una wala sulud nga nagsunod-sunod nga gisubli nga mga elemento.
    /// Ang ikaduha adunay sulud nga tanan nga mga doble nga wala gipiho nga han-ay.
    ///
    /// Kon ang ad-ad mao ang lainlainon, ang unang mibalik ad-ad naglakip walay doble.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Gibalhin ang tanan apan ang una sa magkasunod nga mga elemento sa katapusan sa hiwa nga nagtagbaw sa usa ka gihatag nga kaangayan sa pagkasama.
    ///
    /// Gibalik ang duha nga mga hiwa.Ang una wala sulud nga nagsunod-sunod nga gisubli nga mga elemento.
    /// Ang ikaduha adunay sulud nga tanan nga mga doble nga wala gipiho nga han-ay.
    ///
    /// Ang `same_bucket` function ang milabay nga mga pakisayran ngadto sa duha ka elemento gikan sa ad-ad ug pagtino kon ang mga elemento itandi managsama.
    /// Ang mga elemento nga miagi sa atbang aron gikan sa ilang han-ay diha sa ad-ad, mao nga kon `same_bucket(a, b)` mobalik `true`, `a` ang mibalhin sa katapusan sa ad-ad.
    ///
    ///
    /// Kon ang ad-ad mao ang lainlainon, ang unang mibalik ad-ad naglakip walay doble.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Bisan tuod kita adunay usa ka mutable paghisgot sa `self`, dili kita makahimo *arbitraryong* kausaban.Ang `same_bucket` tawag makahimo panic, mao nga kita kinahanglan gayud nga masiguro nga ang ad-ad anaa sa usa ka balido nga kahimtang sa tanang panahon.
        //
        // Ang paagi nga kita sa pagdumala kini mao ang pinaagi sa paggamit sa swaps;gisubli namon ang tanan nga mga elemento, nga nagpalit samtang moadto kami aron sa katapusan ang mga elemento nga gusto namon nga ipadayon naa sa atubangan, ug kadtong gusto namon isalikway naa sa likud.
        // Mahimo dayon natunga ang hiwa.
        // Kini nga operasyon mao ang pa `O(n)`.
        //
        // Pananglitan: Nagsugod kami sa kini nga estado, diin ang `r` nagrepresentar sa "sunod
        // basaha ang "ug ang `w` nagrepresentar sa" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ang pagtandi sa self[r] kontra sa kaugalingon [w-1], dili kini usa ka duplicate, busa gibaylo namon ang self[r] ug self[w] (wala`y epekto ingon r==w) ug unya dugangan ang parehas nga r ug w, nga gibilin kami sa:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Pagtandi self[r] batok sa kaugalingon [w-1], kini nga bili mao ang usa ka kopya, mao nga kita dungag `r` apan leave ang tanan mausab:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ang pagtandi sa self[r] kontra sa kaugalingon [w-1], dili kini usa ka duplicate, busa ibaylo ang self[r] ug self[w] ug isulong ang r and w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Dili usa ka madoble, sublion:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Doble, advance r. End nga hiwa.Bahina sa w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // KALUWAS: ang kondisyon nga `while` naggarantiya sa `next_read` ug `next_write`
        // mga ubos pa kay sa `len`, sa ingon anaa sa sulod `self`.
        // `prev_ptr_write` puntos sa usa ka elemento sa atubangan `ptr_write`, apan `next_write` magsugod sa 1, mao nga `prev_ptr_write` dili gayud ubos pa kay sa 0 ug anaa sa sulod sa ad-ad.
        // Natuman niini ang mga kinahanglanon alang sa pagdepensa sa `ptr_read`, `prev_ptr_write` ug `ptr_write`, ug alang sa paggamit sa `ptr.add(next_read)`, `ptr.add(next_write - 1)` ug `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` nadugangan usab labing daghan kausa matag loop nga labing kahulogan nga wala`y elemento nga gilaktawan kung mahimo`g kinahanglan nga ibaylo.
        //
        // `ptr_read` ug `prev_ptr_write` dili gyud magtudlo sa parehas nga elemento.Kini ang gikinahanglan alang sa `&mut *ptr_read`, `&mut* prev_ptr_write` nga mahimong luwas.
        // Ang pagpatin-aw yano nga ang `next_read >= next_write` kanunay tinuod, sa ingon ang `next_read > next_write - 1` usab.
        //
        //
        //
        //
        //
        unsafe {
            // Likayi ang mga ali ug utlanan tseke pinaagi sa paggamit sa hilaw nga mga tambag.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Gibalhin ang tanan apan ang una sa magkasunod nga mga elemento sa katapusan sa hiwa nga molutas sa parehas nga yawe.
    ///
    ///
    /// Gibalik ang duha nga mga hiwa.Ang una wala sulud nga nagsunod-sunod nga gisubli nga mga elemento.
    /// Ang ikaduha adunay sulud nga tanan nga mga doble nga wala gipiho nga han-ay.
    ///
    /// Kon ang ad-ad mao ang lainlainon, ang unang mibalik ad-ad naglakip walay doble.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Gilibut ang hiwa nga dapit sa lugar nga ang mga una nga elemento nga `mid` sa hiwa mobalhin sa katapusan samtang ang katapusan nga mga elemento nga `self.len() - mid` mobalhin sa atubangan.
    /// Human sa pagtawag `rotate_left`, ang elemento sa una sa index `mid` mahimong ang unang elemento sa ad-ad.
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar panic kung ang `mid` mas daghan kaysa sa gitas-on sa usa ka hiwa.Hinumdomi nga ang `mid == self.len()` naghimo sa _not_ panic ug usa ka pagtuyok nga no-op.
    ///
    /// # Complexity
    ///
    /// Nagkinahanglan linear nga (sa `self.len()`) panahon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Nagtuyok sa usa ka subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: Ang laing `[p.add(mid) - mid, p.add(mid) + k)` mao trivially
        // balido alang sa pagbasa ug pagsulat, sama sa gikinahanglan sa `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Gilibut ang hiwa nga dapit sa lugar nga ang mga una nga elemento nga `self.len() - k` sa hiwa mobalhin sa katapusan samtang ang katapusan nga mga elemento nga `k` mobalhin sa atubangan.
    /// Human sa pagtawag `rotate_right`, ang elemento sa una sa index `self.len() - k` mahimong ang unang elemento sa ad-ad.
    ///
    /// # Panics
    ///
    /// function niining panic kon `k` mas labaw pa kay sa gitas-on sa ad-ad.Hinumdomi nga ang `k == self.len()` naghimo sa _not_ panic ug usa ka pagtuyok nga no-op.
    ///
    /// # Complexity
    ///
    /// Nagkinahanglan linear nga (sa `self.len()`) panahon.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Tuyok sa usa ka subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: Ang laing `[p.add(mid) - mid, p.add(mid) + k)` mao trivially
        // balido alang sa pagbasa ug pagsulat, sama sa gikinahanglan sa `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Gipuno ang `self` sa mga elemento pinaagi sa pag-clone sa `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Gipuno ang `self` sa mga elemento nga gibalik pinaagi sa pagtawag sa us aka pagsira kanunay.
    ///
    /// Kini nga pamaagi gigamit sa usa ka pagsira sa paghimo sa bag-ong mga prinsipyo.Kon kung ikaw hinoon [`Clone`] sa usa ka gihatag nga bili, paggamit [`fill`].
    /// Kung gusto nimong gamiton ang [`Default`] trait aron makamugna ang mga kantidad, mahimo nimo mapasa ang [`Default::default`] ingon ang lantugi.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Mga kopya sa mga elemento gikan sa `src` ngadto sa `self`.
    ///
    /// Ang gitas-on sa `src` kinahanglan parehas sa `self`.
    ///
    /// Kung gipatuman sa `T` ang `Copy`, mahimo kini nga labi ka mapuslanon nga mogamit sa [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// function Kini panic kon ang duha ka mga hiwa adunay lain-laing mga gitas-on.
    ///
    /// # Examples
    ///
    /// Pag-clone sa duha nga elemento gikan sa usa ka hiwa ngadto sa lain:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tungod kay ang mga hiwa kinahanglan managsama nga gitas-on, gihiwa namon ang gigikanan nga hiwa gikan sa upat nga mga elemento ngadto sa duha.
    /// // Kini panic kon kita dili sa pagbuhat niini.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Gipatuman sa Rust nga mahimo lamang usa ka mabalhin nga pakisayran nga wala`y pagbag-o nga mga pakisayran sa usa ka piho nga piraso sa datos sa usa ka piho nga kasangkaran.
    /// Tungod niini, ang pagsulay sa paggamit sa `clone_from_slice` sa usa ka hiwa magresulta sa usa ka pagkapakyas sa pagtipon:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aron magtrabaho kini, mahimo namon magamit ang [`split_at_mut`] aron makahimo duha nga managlahi nga mga hiwa gikan sa usa ka hiwa:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Gikopya ang tanan nga mga elemento gikan sa `src` ngadto sa `self`, nga naggamit usa ka memcpy.
    ///
    /// Ang gitas-on sa `src` kinahanglan parehas sa `self`.
    ///
    /// Kon `T` wala pagpatuman `Copy`, sa paggamit sa [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// function Kini panic kon ang duha ka mga hiwa adunay lain-laing mga gitas-on.
    ///
    /// # Examples
    ///
    /// Pagkopya sa duha nga elemento gikan sa usa ka hiwa ngadto sa lain:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tungod kay ang mga hiwa kinahanglan managsama nga gitas-on, gihiwa namon ang gigikanan nga hiwa gikan sa upat nga mga elemento ngadto sa duha.
    /// // Kini panic kon kita dili sa pagbuhat niini.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Gipatuman sa Rust nga mahimo lamang usa ka mabalhin nga pakisayran nga wala`y pagbag-o nga mga pakisayran sa usa ka piho nga piraso sa datos sa usa ka piho nga kasangkaran.
    /// Tungod niini, ang pagsulay sa paggamit sa `copy_from_slice` sa usa ka hiwa magresulta sa usa ka pagkapakyas sa pagtipon:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aron magtrabaho kini, mahimo namon magamit ang [`split_at_mut`] aron makahimo duha nga managlahi nga mga hiwa gikan sa usa ka hiwa:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Ang agianan sa panic code gibutang sa usa ka bugnaw nga pagpaandar aron dili makapamubu ang site sa tawag.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` mao ang balido alang sa `self.len()` elemento sa kahulugan, ug `src` mao
        // gisusi nga adunay parehas nga gitas-on.
        // Ang mga hiwa dili sapaw tungod kay mutable mga pakisayran nga mga exclusive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopya elemento gikan sa usa ka bahin sa ad-ad sa laing bahin sa iyang kaugalingon, sa paggamit sa usa ka memmove.
    ///
    /// `src` mao ang laing sa sulod sa `self` sa pagkopya sa.
    /// `dest` mao ang pagsugod indeks sa sakup sa sulud sa `self` aron makopya, nga adunay parehas nga gitas-on sa `src`.
    /// Ang duha ka mga han-ay mahimo nga magsapaw.
    /// Ang tumoy sa duha ka mga han-ay kinahanglan nga ubos pa kay sa o itanding `self.len()`.
    ///
    /// # Panics
    ///
    /// Kini nga function kabubut panic kon sa bisan hain laing milapas sa katapusan sa ad-ad, o kon sa katapusan sa `src` anaa sa atubangan sa pagsugod.
    ///
    ///
    /// # Examples
    ///
    /// Pagkopya sa upat ka mga byte sa sulud sa usa ka hiwa:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: ang mga kondisyon alang sa `ptr::copy` tanan nga gitan-aw sa ibabaw,
        // ingon nga adunay mga sa `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Gipuli ang tanan nga mga elemento sa `self` sa mga naa sa `other`.
    ///
    /// Ang gitas-on sa `other` kinahanglan nga sa mao usab nga ingon sa `self`.
    ///
    /// # Panics
    ///
    /// function Kini panic kon ang duha ka mga hiwa adunay lain-laing mga gitas-on.
    ///
    /// # Example
    ///
    /// Nagtabla ang duha ka elemento sa tibuok hiwa:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Gipatuman sa Rust nga mahimo ra usa nga mabalhin nga pakisayran sa usa ka partikular nga piraso sa datos sa usa ka piho nga kasangkaran.
    ///
    /// Tungod niini, ang pagsulay sa paggamit sa `swap_with_slice` sa usa ka hiwa magresulta sa usa ka pagkapakyas sa pagtipon:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Aron magamit kini, mahimo namon magamit ang [`split_at_mut`] aron makahimo duha nga managlahi nga mga mutable nga sub-hiwa gikan sa usa ka hiwa:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` mao ang balido alang sa `self.len()` elemento sa kahulugan, ug `src` mao
        // gisusi nga adunay parehas nga gitas-on.
        // Ang mga hiwa dili sapaw tungod kay mutable mga pakisayran nga mga exclusive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Pag-andar aron makalkula ang gitas-on sa tunga ug nagsubay nga hiwa alang sa `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ang buhaton namon bahin sa `rest` mahibal-an kung unsang daghang mga `U ang mahimo naton nga ibutang sa usa ka labing ubus nga numero sa` T`s.
        //
        // Ug pila ka mga `T ang kinahanglan naton alang sa matag ingon nga "multiple".
        //
        // Hunahunaa pananglitan T=u8 U=u16.Pagkahuman mahimo naton ibutang ang 1 U sa 2 Ts.Yano.
        // Karon, ikonsiderar pananglitan ang usa ka kaso diin ang size_of: :<T>=16, size_of::<U>=24.</u>
        // Mahimo namon nga ibutang ang 2 Us sa lugar sa matag 3 Ts sa `rest` nga hiwa.
        // Medyo labi ka komplikado.
        //
        // Pormula sa pagkalkulo mao kini:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Gipadako ug gipayano:
        //
        // Kami=gidak-on sa: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=gidak-on_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Swerte tungod kay ang tanan nga kini mao ang kanunay nga-evaluate ... performance dinhi igsapayan!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Iterative stein's algorithm Kinahanglan pa naton nga buhaton kini nga `const fn` (ug ibalik sa recursive algorithm kung buhaton namon) tungod kay ang pagsalig sa llvm nga mapadayon ang tanan nga kini…maayo, kini naghimo kanako nga dili komportable.
            //
            //

            // SAFETY: `a` ug `b` mga gitan-aw nga mahimong dili-zero mga prinsipyo.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // tangtanga tanan nga hinungdan sa 2 gikan sa b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: `b` ang gisusi nga mahimong dili-zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Gamit ang kini nga kahibalo, makit-an kung pila ka mga `U ang mahimo naton nga angay!
        let us_len = self.len() / ts * us;
        // Ug sa unsa nga paagi sa daghang mga `T`s mahimong sa trailing ad-ad!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Ibalhin ang hiwa sa usa ka hiwa sa uban pang lahi, gisiguro nga ang pagpahiangay sa mga tipo mapadayon.
    ///
    /// Kini nga pamaagi gibahinbahin ang hiwa sa tulo nga managlahi nga mga hiwa: unahan, husto nga nakahanay sa tunga nga hiwa sa usa ka bag-ong tipo, ug ang hiwa sa suffix.
    /// Ang pamaagi mahimong maghimo sa tungatunga nga gihiwa nga labing kadaghan nga mahimo alang sa usa ka gihatag nga tipo ug input nga hiwa, apan ang paghimo ra sa imong algorithm kinahanglan magsalig niana, dili ang kahusto niini.
    ///
    /// Gitugotan kini alang sa tanan nga mga datos sa pag-input nga ibalik ingon usa ka prefiks o hiwa sa suffix.
    ///
    /// Kini nga pamaagi wala`y katuyoan kung kanus-a ang bisan unsang elemento sa pag-input nga `T` o output nga elemento nga `U` wala`y sukod ug ibalik ang orihinal nga hiwa nga wala mabahin bisan unsa.
    ///
    /// # Safety
    ///
    /// Kini nga pamaagi mao ang esensya sa usa ka `transmute` uban sa pagtahod ngadto sa mga elemento sa mibalik tunga-tunga nga ad-ad, sa ingon ang tanan nga mga naandan nga caveats kalabut sa `transmute::<T, U>` usab sa paggamit dinhi.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Hinumdomi nga ang kadaghanan sa kini nga pag-andar kanunay nga masusi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // Labi na nga pagdumala ang mga ZST, nga mao-ayaw gyud pagdumala.
            return (self, &[], &[]);
        }

        // Una, pangitaa kung unsang oras kita nagbulag taliwala sa una ug ika-2 nga hiwa.
        // Sayon uban ang ptr.align_offset.
        let ptr = self.as_ptr();
        // KALUWASAN: Makita ang pamaagi nga `align_to_mut` alang sa detalyado nga komentaryo sa kahilwasan.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // KALUWASAN: Karon ang `rest` siguradong nakahanay, busa ang `from_raw_parts` sa ubos okay,
            // tungod kay ang nagpanawag naggarantiya nga mahimo namon maluwas ang `T` sa `U` nga luwas.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Ibalhin ang hiwa sa usa ka hiwa sa uban pang lahi, gisiguro nga ang pagpahiangay sa mga tipo mapadayon.
    ///
    /// Kini nga pamaagi gibahinbahin ang hiwa sa tulo nga managlahi nga mga hiwa: unahan, husto nga nakahanay sa tunga nga hiwa sa usa ka bag-ong tipo, ug ang hiwa sa suffix.
    /// Ang pamaagi mahimong maghimo sa tungatunga nga gihiwa nga labing kadaghan nga mahimo alang sa usa ka gihatag nga tipo ug input nga hiwa, apan ang paghimo ra sa imong algorithm kinahanglan magsalig niana, dili ang kahusto niini.
    ///
    /// Gitugotan kini alang sa tanan nga mga datos sa pag-input nga ibalik ingon usa ka prefiks o hiwa sa suffix.
    ///
    /// Kini nga pamaagi wala`y katuyoan kung kanus-a ang bisan unsang elemento sa pag-input nga `T` o output nga elemento nga `U` wala`y sukod ug ibalik ang orihinal nga hiwa nga wala mabahin bisan unsa.
    ///
    /// # Safety
    ///
    /// Kini nga pamaagi mao ang esensya sa usa ka `transmute` uban sa pagtahod ngadto sa mga elemento sa mibalik tunga-tunga nga ad-ad, sa ingon ang tanan nga mga naandan nga caveats kalabut sa `transmute::<T, U>` usab sa paggamit dinhi.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Hinumdomi nga ang kadaghanan sa kini nga pag-andar kanunay nga masusi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // Labi na nga pagdumala ang mga ZST, nga mao-ayaw gyud pagdumala.
            return (self, &mut [], &mut []);
        }

        // Una, pangitaa kung unsang oras kita nagbulag taliwala sa una ug ika-2 nga hiwa.
        // Sayon uban ang ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Ania kita pagsiguro atong gamiton ilaray pointers alang sa U alang sa
        // nahabilin sa pamaagi.Gihimo kini pinaagi sa pagpasa sa usa ka pointer sa&[T] nga adunay usa ka paglinya nga gipunting alang sa U.
        // `crate::ptr::align_offset` Gitawag nga adunay tama nga kahanay ug husto nga pointer `ptr` (gikan kini sa usa ka pakisayran sa `self`) ug adunay gidak-on nga usa ka kusog nga duha (tungod kay gikan kini sa paghanay alang sa U), nga nagtagbaw sa mga pagpugong sa kahilwasan.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Dili namon magamit ang `rest` pag-usab pagkahuman niini, kana mahimong kawagtang sa alyas nga `mut_ptr`!KALuwas-an: tan-awa ang mga komentaryo alang sa `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Gisusi kung ang mga elemento sa kini nga hiwa gihan-ay.
    ///
    /// Nga mao, alang sa matag elemento `a` ug sa iyang mosunod nga elemento `b`, `a <= b` kinahanglan nga naghupot.Kung ang hiwa maghatag eksakto nga zero o usa ka elemento, ibalik ang `true`.
    ///
    /// Hinumdomi nga kung ang `Self::Item` `PartialOrd` ra, apan dili `Ord`, ang gipasabut sa kahitas-an nagpasabut nga kini nga pag-andar nagabalik `false` kung ang bisan unsang duha ka sunod-sunod nga mga butang dili ikatanding.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Checks kon ang mga elemento sa ad-ad niining mga lainlainon sa paggamit sa gihatag nga comparator function.
    ///
    /// Imbis nga gamiton ang `PartialOrd::partial_cmp`, gigamit sa kini nga function ang gihatag nga `compare` function aron mahibal-an ang pagkasunud sa duha nga elemento.
    /// Gawas sa nga, kini katumbas sa [`is_sorted`];tan-awa ang iyang mga dokumento alang sa dugang nga impormasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Checks kon ang mga elemento sa ad-ad niining mga lainlainon sa paggamit sa gihatag yawe pagkuha function.
    ///
    /// Imbis nga itandi ang mga elemento sa hiwa nga direkta, kini nga pag-andar gitandi ang mga yawi sa mga elemento, ingon sa gitino sa `f`.
    /// Gawas sa nga, kini katumbas sa [`is_sorted`];tan-awa ang iyang mga dokumento alang sa dugang nga impormasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Gibalik ang indeks sa punto sa pagkabulag sumala sa gihatag nga predicate (ang indeks sa una nga elemento sa ikaduhang pagbulag).
    ///
    /// Ang hiwa giisip nga gibahinbahin sumala sa gihatag nga predicate.
    /// Kini paagi nga ang tanan nga mga elemento nga sa predicate mobalik matuod ang sa pagsugod sa ad-ad, ug sa tanan nga mga elemento nga sa predicate mobalik sa bakak nga mga sa katapusan.
    ///
    /// Pananglitan, [7, 15, 3, 5, 4, 12, 6] mao ang usa ka partisyon sa ilalum sa predicate x% 2!=0 (sa tanan nga mga katingad-numero anaa sa sa pagsugod, ang tanan nga bisan sa katapusan).
    ///
    /// Kung kini nga hiwa wala mabahin, ang gibalik nga sangputanan wala matino ug wala`y hinungdan, tungod kay ang kini nga pamaagi naghimo usa ka klase nga binary search.
    ///
    /// Tan-awa usab ang [`binary_search`], [`binary_search_by`], ug [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // KALUWASAN: Kung `left < right`, `left <= mid < right`.
            // Busa ang `left` kanunay nga nagdugang ug ang `right` kanunay nga mikunhod, ug bisan kinsa sa kanila ang napili.Sa parehas nga kaso ang `left <= right` matagbaw.Busa kung ang `left < right` sa usa ka lakang, ang `left <= right` matagbaw sa sunod nga lakang.
            //
            // Busa basta `left != right`, ang `0 <= left < right <= len` matagbaw ug kung kini nga kaso `0 <= mid < len` matagbaw usab.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Kinahanglan naton nga dayag nga hiwaon sila sa parehas nga gitas-on
        // aron masayon alang sa optimizer nga mag-elide ang mga utlanan sa pagsusi.
        // Apan tungod kay kini dili magsalig sa kita usab adunay usa ka tin-aw nga specialization sa T: Kopyaha.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Naghimo usa ka walay sulod nga hiwa.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Naghimo usa ka mutable nga walay sulod nga hiwa.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Ang mga sumbanan sa mga hiwa, karon, gigamit ra sa `strip_prefix` ug `strip_suffix`.
/// Sa usa ka punto nga future, gilauman namon nga ipasangkad ang `core::str::Pattern` (nga sa oras nga pagsulat gikutuban sa `str`) sa mga hiwa, ug pagkahuman kini nga trait ilisan o wagtangon.
///
pub trait SlicePattern {
    /// Ang tipo sa elemento sa hiwa nga gipares.
    type Item;

    /// Sa pagkakaron, ang mga konsumedor sa `SlicePattern` kinahanglan sa usa ka ad-ad.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}