//! Ang mga operasyon sa ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Gisusi kung ang tanan nga mga byte sa kini nga hiwa naa sa sulud sa ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Gisusi nga ang duha nga mga hiwa usa ka ASCII case-insensitive match.
    ///
    /// Parehas sa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, apan wala paggahin ug pagkopya sa mga temporaryo.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Gikabig kini nga hiwa sa ASCII sa taas nga kaso nga katumbas sa lugar.
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mabalik ang usa ka bag-ong taas nga kantidad nga wala mausab ang naanaa, gamita ang [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Mga kinabig niini nga ad-ad sa iyang ASCII ubos-ubos nga kaso katumbas sa-dapit.
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mabalik ang us aka bag-ong gibug-aton nga kantidad nga dili pagbag-o ang naa na, gamita ang [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Gibalik ang `true` kung adunay bisan unsang byte sa pulong `v` nga nonascii (>=128).
/// Naka-snarf gikan sa `../str/mod.rs`, nga naghimo usa ka butang nga parehas alang sa utf8 validation.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Gi-optimize ang pagsulay sa ASCII nga mogamit sa usize-at-a-time nga operasyon sa baylo nga byte-at-a-time nga operasyon (kung mahimo).
///
/// Ang algorithm nga gigamit namon dinhi yano ra.Kung ang `s` mubo ra kaayo, gisusi ra namon ang matag byte ug nahuman na.Kung dili:
///
/// - Basaha ang una nga pulong nga adunay wala magkatugma nga karga.
/// - Ihan-ay ang pointer, basaha ang mga mosunud nga pulong hangtod matapos sa mga nakahanay nga karga.
/// - Basaha ang katapusang `usize` gikan sa `s` nga adunay wala magkatugma nga karga.
///
/// Kung ang bisan kinsa sa kini nga mga karga nagdala usa ka butang diin ang `contains_nonascii` (above) namalik nga tinuod, nahibal-an namon nga ang tubag sayup.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Kung wala kami makuha nga bisan unsa gikan sa pagpatuman sa pulong sa matag higayon, pagbalik sa usa ka scalar loop.
    //
    // Gihimo usab namon kini alang sa mga arkitektura diin ang `size_of::<usize>()` dili igo nga paghanay alang sa `usize`, tungod kay kini usa ka katingad-an nga kaso nga edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Kanunay namon nga gibasa ang una nga pulong nga dili nakahan-ay, nga nagpasabut nga `align_offset` mao
    // 0, pud atong mabasa sa sama nga bili sa pag-usab alang sa ilaray basahon.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KALUWASAN: Gisusi namon ang `len < USIZE_SIZE` sa taas.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Gisusi namon kini sa taas, medyo implicit.
    // Hinumdomi nga ang `offset_to_aligned` usa ka `align_offset` o `USIZE_SIZE`, parehas nga klarong gisusi sa taas.
    //
    debug_assert!(offset_to_aligned <= len);

    // KALUWASAN: ang pulong nga_ptr mao ang (husto nga pagkahanay) nga gigamit nga ptr nga gigamit aron mabasa ang
    // tungatunga nga tipik sa hiwa.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` mao ang Byte index sa `word_ptr`, nga gigamit alang sa laang katapusan tseke.
    let mut byte_pos = offset_to_aligned;

    // Gisusi sa Paranoia ang bahin sa paghanay, tungod kay maghimo kami usa ka hugpong nga wala managsama nga mga karga.
    // Sa praktis kini kinahanglan nga imposible nga pagdili usa ka bug sa `align_offset` bisan pa.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Basaha ang mga mosunud nga pulong hangtod sa katapusang laray sa pulong, wala`y labot ang katapusang laray nga pulong sa kaugalingon nga himuon sa pagsusi sa ikog sa ulahi, aron maseguro nga ang ikog kanunay usa ka `usize` labing daghan sa sobra nga branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Katinuan pagsusi nga ang mabasa anaa sa mga utlanan
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ug nga ang among mga pangagpas bahin sa `byte_pos` naghupot.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KALUWAS: Nahibal-an namon nga ang `word_ptr` husto nga nakahanay (tungod sa
        // `align_offset`), ug nahibal-an namon nga kami adunay igo nga mga byte taliwala sa `word_ptr` ug katapusan
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // KALUWASAN: Nahibal-an namon nga `byte_pos <= len - USIZE_SIZE`, nga gipasabut kana
        // pagkahuman sa kini nga `add`, ang `word_ptr` mahimong labing usa ka katapusan nga katapusan.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Susihon ang sanity aron maseguro nga adunay na lang usa nga nahabilin nga `usize`.
    // Kini kinahanglan nga gigarantiyahan sa among kahimtang sa loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KALUWASAN: Kini nagsalig sa `len >= USIZE_SIZE`, nga gisusi namon sa pagsugod.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}