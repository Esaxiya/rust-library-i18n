// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rotates sa laing `[mid-left, mid+right)` sa ingon nga ang elemento sa `mid` mahimong ang unang elemento.Parehas, gipatuyok ang mga elemento sa range `left` sa wala o `right` nga mga elemento sa tuo.
///
/// # Safety
///
/// Ang gitumbok nga sakup kinahanglan nga balido alang sa pagbasa ug pagsulat.
///
/// # Algorithm
///
/// Algorithm 1 gigamit alang sa gagmay nga mga hiyas sa `left + right` o alang sa dako nga `T`.
/// Ang mga elemento nga mibalhin sa ilang katapusan nga mga posisyon ang usa sa usa ka panahon sugod sa `mid - left` ug pagpaasdang sa `right` lakang modulo `left + right`, sama nga ang usa ka temporaryo lamang ang gikinahanglan.
/// Sa katapusan, kita moabot balik sa `mid - left`.
/// Bisan pa, kung ang `gcd(left + right, right)` dili 1, ang mga lakang sa taas gilaktawan ang mga elemento.
/// Pananglitan:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Maayo na lang, ang ihap sa mga gilaktawan nga mga elemento taliwala sa nahuman nga mga elemento kanunay managsama, aron mahimo ra namon mapun-an ang among posisyon sa pagsugod ug maghimo daghang mga hugna (ang kinatibuk-ang ihap sa mga hugna mao ang `gcd(left + right, right)` value).
///
/// Ang katapusan nga resulta mao nga ang tanan nga mga elemento mahuman sa makausa ug sa makausa lamang.
///
/// Gigamit ang Algorithm 2 kung ang `left + right` dako apan ang `min(left, right)` gamay nga igo aron mohaum sa usa ka stack buffer.
/// Ang mga elemento nga `min(left, right)` gikopya sa buffer, ang `memmove` gipadapat sa uban pa, ug ang naa sa buffer gibalhin balik sa lungag sa atbang nga bahin diin gikan kini.
///
/// Algorithms nga mahimong vectorized Nalabwan ang mga sa ibabaw sa makausa `left + right` mahimong dako nga igo.
/// Algorithm 1 mahimong vectorized pinaagi sa chunking ug sa pagpahigayon sa daghang mga round sa makausa, apan adunay mga diyutay ra kaayo rounds sa aberids hangtud `left + right` mao ang dakong, ug sa labing kaso sa usa ka single round mao ang kanunay nga didto.
/// Hinuon, gigamit sa algorithm 3 ang gibalikbalik nga pagbaylo sa mga elemento nga `min(left, right)` hangtod nga mahabilin ang usa ka gamay nga problema sa pagtuyok.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// sa diha nga `left < right` ang pagbayloay mahitabo gikan sa wala sa baylo.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ang sa ubos nga mga algorithm mahimong mapakyas kung kini nga mga kaso dili masusi
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Ang Algorithm 1 Microbenchmarks nagpakita nga ang kasagaran nga paghimo alang sa mga random nga pagbag-o labi ka maayo hangtod sa hapit ang `left + right == 32`, apan ang labing ngil-ad nga kaso sa pagguba bisan sa mga 16.
            // Ang 24 napili ingon tunga-tunga nga sukaranan.
            // Kon ang gidak-on sa `T` mao mas dako pa kay sa 4 usize`s, kini nga algorithm usab outperforms sa ubang mga algorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // pagsugod sa first round
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` mahimo nga makaplagan sa atubangan sa kamot pinaagi sa pagkalkulo `gcd(left + right, right)`, apan kini mao ang mas paspas sa pagbuhat sa usa ka laang nga nagtinguha sa gcd ingon sa usa ka kilid epekto, nan sa pagbuhat sa uban nga mga chunk
            //
            //
            let mut gcd = right;
            // Gibutyag sa mga benchmark nga mas dali nga ibaylo ang mga temporaryo hangtod nga mabasa ang usa ka temporaryo nga kausa, pagkopya sa paatras, ug pagkahuman isulat ang temporaryo sa katapusan.
            // Kini mao ang posible nga tungod sa kamatuoran nga ang nagtabla o ilis sa temporaries naggamit lamang sa usa ka handumanan address sa laang sa baylo nga sa nagkinahanglan sa pagdumala sa duha ka.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // imbis nga dugangan ang `i` ug pagkahuman susihon kung naa sa gawas sa mga utlanan, gisusi namon kung ang `i` moadto sa gawas sa mga utlanan sa sunod nga pagdugang.
                // Gipugngan niini ang bisan unsang pagputos sa mga pointers o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // katapusan sa unang round
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // kini nga kondisyon kinahanglan naa dinhi kung `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // paghuman sa chunk uban sa dugang nga rounds
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` dili usa ka zero-size nga klase, busa okay ra nga bahinon pinaagi sa gidak-on niini.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Ang `[T; 0]` dinhi aron maseguro nga kini angayan nga nakahanay alang sa T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Adunay usa ka alternatibo nga paagi sa pagpalit nga gilakip ang pagpangita kung asa ang katapusan nga pagbaylo sa kini nga algorithm, ug ang pagbayloay gamit ang katapusang tipak imbis nga ibaylo ang mga kasikbit nga tipak sama sa gihimo sa kini nga algorithm, apan sa kini nga paagi labi pa kadali.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}