//! Paghiusa sa hiwa
//!
//! Ang kini nga module adunay sulud nga paghan-ay sa algorithm pinahiuyon sa pagdaug sa pattern nga Orson Peters, gipatik sa: <https://github.com/orlp/pdqsort>
//!
//!
//! Nagabukal paglain-lain mao ang compatible sa libcore tungod kay kini wala mogahin sa panumdoman, dili sama sa atong lig-on nga hagpat sa pagpatuman.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kung nahulog, mga kopya gikan sa `src` ngadto sa `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // KALuwas-an: Kini usa ka klase sa helper.
        //          Palihug pagdangup sa paggamit niini alang sa pagkahusto.
        //          Nga mao, ang usa kinahanglan nga ang `src` ug `dst` wala sapaw nga ingon sa gikinahanglan sa `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Gibalhin ang una nga elemento sa tuo hangtod nga makit-an ang us aka labi ka daghan o managsama nga elemento.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ang dili luwas nga operasyon sa ubos naglakip sa pag-indeks nga walay usa ka utlanan check (`get_unchecked` ug `get_unchecked_mut`)
    // ug pagkopya handumanan (`ptr::copy_nonoverlapping`).
    //
    // a.Pag-indeks:
    //  1. Gisusi namon ang kadako sa laray ngadto sa>=2.
    //  2. Ang tanan nga pag-indeks nga among buhaton kanunay taliwala sa {0 <= index < len} labing daghan.
    //
    // b.ulohon nga pagkopya
    //  1. Nakakuha kami mga panudlo sa mga pakisayran nga gigarantiyahan nga mahimong balido.
    //  2. Dili sila mahimong magsapaw tungod kay nakakuha kami mga panudlo sa lainlaing mga indeks sa hiwa.
    //     Nga mao, `i` ug `i-1`.
    //  3. Kung ang hiwa husto nga nakahanay, ang mga elemento husto nga nakahanay.
    //     Katungdanan sa nanawag nga siguraduhon nga ang slice husto nga nakahanay.
    //
    // Kitaa ang mga komento sa ubus alang sa dugang nga detalye.
    unsafe {
        // Kon ang unang duha ka mga elemento mao out-of-order ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Basaha ang unang elemento ngadto sa usa ka pundok-gigahin baryable.
            // Kon ang usa ka mosunod nga pagtandi operasyon panics, `hole` ang na nagatulo ug awtomatikong pagsulat sa elemento balik ngadto sa ad-ad.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Lihok `i`-th nga elemento usa ka lugar sa wala, sa ingon pagbalhin sa lungag sa tuo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` nahulog ug sa ingon gikopya ang `tmp` sa nahabilin nga lungag sa `v`.
        }
    }
}

/// Kabalhinan sa sa katapusan nga elemento sa wala, hangtud nga kini makasugat og usa ka mas gamay o managsama elemento.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ang dili luwas nga operasyon sa ubos naglakip sa pag-indeks nga walay usa ka utlanan check (`get_unchecked` ug `get_unchecked_mut`)
    // ug pagkopya handumanan (`ptr::copy_nonoverlapping`).
    //
    // a.Pag-indeks:
    //  1. Gisusi namon ang gidak-on sa laray sa>=2.
    //  2. Ang tanan nga pag-indeks nga among buhaton kanunay taliwala sa `0 <= index < len-1` labing daghan.
    //
    // b.ulohon nga pagkopya
    //  1. Nakakuha kami mga panudlo sa mga pakisayran nga gigarantiyahan nga mahimong balido.
    //  2. Dili sila mahimong magsapaw tungod kay nakakuha kami mga panudlo sa lainlaing mga indeks sa hiwa.
    //     Nga mao, `i` ug `i+1`.
    //  3. Kung ang hiwa husto nga nakahanay, ang mga elemento husto nga nakahanay.
    //     Katungdanan sa nanawag nga siguraduhon nga ang slice husto nga nakahanay.
    //
    // Kitaa ang mga komento sa ubus alang sa dugang nga detalye.
    unsafe {
        // Kung ang katapusang duha nga mga elemento wala sa han-ay ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Basaha ang katapusang elemento sa usa ka variable nga gigahin nga stack.
            // Kon ang usa ka mosunod nga pagtandi operasyon panics, `hole` ang na nagatulo ug awtomatikong pagsulat sa elemento balik ngadto sa ad-ad.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Ilihok ang `i`-th nga elemento usa ka dapit sa tuo, sa ingon pagbalhin sa lungag sa wala.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` nahulog ug sa ingon gikopya ang `tmp` sa nahabilin nga lungag sa `v`.
        }
    }
}

/// Partially matang sa usa ka ad-ad sa nagbalhin-balhin sa pipila gikan-sa-order elemento sa palibot.
///
/// Gibalik ang `true` kung ang hiwa gihan-ay sa katapusan.Kini nga pag-andar mao ang *O*(*n*) labing kadaotan nga kaso.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximum nga gidaghanon sa mga tapad gikan-sa-order paris nga na mibalhin.
    const MAX_STEPS: usize = 5;
    // Kung ang hiwa mas mubo kaysa niini, ayaw pagbalhin sa bisan unsang mga elemento.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Kita na tin-aw sa gibuhat sa mga utlanan pagsusi sa `i < len`.
        // Ang tanan sa atong sunod-sunod nga pag-index mao ang lamang sa laing `0 <= index < len`
        unsafe {
            // Pangitaa ang sunod nga parisan sa kasikbit nga mga elemento nga wala sa order.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Nahuman na ba kita?
        if i == len {
            return true;
        }

        // Ayaw pagbalhin elemento sa mubo nga arrays, nga adunay usa ka gasto performance.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ipuli ang nakit-an nga pares nga elemento.Kini magsul kanila sa husto nga han-ay.
        v.swap(i - 1, i);

        // Pagbalhin sa gagmay nga elemento sa wala.
        shift_tail(&mut v[..i], is_less);
        // Ipasa ang mas dako nga elemento sa tuo.
        shift_head(&mut v[i..], is_less);
    }

    // Wala ba pagdumala sa matang sa ad-ad sa mga limitado nga gidaghanon sa mga lakang.
    false
}

/// Nag-isa sa usa ka hiwa gamit ang pagsulud nga pagsulud, nga mao ang *O*(*n*^ 2) labing kadaotan nga kaso.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Gisunud ang `v` gamit ang heapsort, nga gigarantiyahan ang *O*(*n*\*log(* n*)) labing grabe nga kaso.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kini nga binun-og nga binary gitahod ang nagpadayon nga `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Mga anak sa `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Pilia ang labi ka daghang bata.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Hunong kung ang invariant naghupot sa `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ipuli ang `node` sa labi ka daghang bata, pagbalhin usa ka lakang, ug pagpadayon sa pag-ayag.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Pagtukod sa mohon sa linear panahon.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop kinatas-an nga mga elemento gikan sa mohon.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Ang mga partisyon nga `v` sa mga elemento nga labi ka gamay kaysa `pivot`, gisundan sa mga elemento nga labi ka daghan o katumbas sa `pivot`.
///
///
/// Gibalik ang numero sa mga elemento nga labi ka gamay sa `pivot`.
///
/// Ang pagbulag gihimo sa block-by-block aron maminusan ang kantidad sa mga operasyon sa sanga.
/// Kini nga ideya nga gipresentar sa [BlockQuicksort][pdf] papel.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Gidaghanon sa mga elemento sa usa ka tipikal nga block.
    const BLOCK: usize = 128;

    // Ang partitioning algorithm nagsubli sa mga mosunod nga lakang hangtod nahuman:
    //
    // 1. Pagsunud sa usa ka bloke gikan sa wala nga kilid aron mahibal-an ang mga elemento nga labi ka daghan o katumbas sa pivot.
    // 2. Pagsunud sa usa ka bloke gikan sa tuo nga kilid aron mahibal-an ang mga elemento nga mas gamay kaysa sa pivot.
    // 3. Exchange ang giila nga mga elemento sa taliwala sa mga wala ug too nga kiliran.
    //
    // Gipadayon namon ang mga mosunud nga variable alang sa usa ka bloke sa mga elemento:
    //
    // 1. `block` - Gidaghan sa mga elemento sa bloke.
    // 2. `start` - Sugdi pointer sa `offsets` gubat.
    // 3. `end` - Pagtapos sa pointer ngadto sa `offsets` array.
    // 4. `offset, Mga indeks sa wala na kaayohan nga mga elemento sulud sa bloke.

    // Ang karon nga bloke sa wala nga kilid (gikan sa `l` hangtod `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ang karon nga bloke sa tuo nga kilid (gikan sa `r.sub(block_r)` to `r`).
    // KALUWASAN: Ang dokumentasyon alang sa .add() piho nga naghisgot nga ang `vec.as_ptr().add(vec.len())` kanunay nga luwas`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kung nakakuha kami mga VLA, sulayi paghimo ang usa ka han-ay sa gitas-on nga `min(v.len(), 2 * BLOCK) `hinoon
    // kaysa sa duha nga gihan-ay nga sukod sa gitas-on nga `BLOCK`.Ang mga VLA mahimong labi ka epektibo sa cache.

    // Mibalik ang gidaghanon sa mga elemento sa taliwala sa mga tambag `l` (inclusive) ug `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Natapos na kami sa pagbulag sa block-by-block kung hapit na magkasuod ang `l` ug `r`.
        // Pagkahuman naghimo kami usa ka buhat nga patch-up aron mabahin ang nahabilin nga mga elemento sa taliwala.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Ang ihap sa nahabilin nga mga elemento (dili gihapon gitandi sa pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ayuhon ang mga gidak-on sa block aron ang wala ug tuo nga bloke dili magsapaw, apan hingpit nga magkahan-ay aron matabunan ang tibuuk nga nahabilin nga gintang.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Pagsunud sa mga elemento sa `block_l` gikan sa wala nga kilid.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAFETY: Ang unsafety operasyon sa ubos naglakip sa sa paggamit sa mga `offset`.
                //         Sumala sa mga kahimtang nga gikinahanglan sa function, makatagbaw kita kanila tungod kay:
                //         1. `offsets_l` gigahin-stack, ug busa giisip nga bulag nga gigahin nga butang.
                //         2. Ang pagpaandar `is_less` mobalik usa ka `bool`.
                //            Ang pag-cast sa `bool` dili gyud mag-awas sa `isize`.
                //         3. Gipaniguro namon nga ang `block_l` mahimong `<= BLOCK`.
                //            Dugang pa, ang `end_l` una nga gitakda sa pagsugod pointer sa `offsets_` nga gideklara sa stack.
                //            Busa, nahibalo kita nga bisan sa labing kaso (sa tanan nga mga pag-ampo sa `is_less` mobalik sa bakak) lamang kita sa labing 1 Byte moagi sa katapusan.
                //        Ang uban pa nga dili malig-on nga operasyon dinhi mao ang pagdepensa sa `elem`.
                //        Bisan pa, ang `elem` mao ang una nga pagsugod nga tudlo sa hiwa nga kanunay nga balido.
                unsafe {
                    // Pagtandi nga walay sanga.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trace `block_r` elemento gikan sa too nga kiliran.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAFETY: Ang unsafety operasyon sa ubos naglakip sa sa paggamit sa mga `offset`.
                //         Sumala sa mga kahimtang nga gikinahanglan sa function, makatagbaw kita kanila tungod kay:
                //         1. `offsets_r` gigahin-stack, ug busa giisip nga bulag nga gigahin nga butang.
                //         2. Ang pagpaandar `is_less` mobalik usa ka `bool`.
                //            Ang pag-cast sa `bool` dili gyud mag-awas sa `isize`.
                //         3. Gagarantiyahan namon nga ang `block_r` mahimong `<= BLOCK`.
                //            Dugang pa, ang `end_r` una nga gitakda sa pagsugod pointer sa `offsets_` nga gideklara sa stack.
                //            Sa ingon, nahibal-an namon nga bisan sa labing grabe nga kaso (tanan nga mga pagsangpit sa `is_less` mobalik nga tinuod) labing daghan ra kita sa 1 byte nga matapos sa katapusan.
                //        Ang uban pa nga dili malig-on nga operasyon dinhi mao ang pagdepensa sa `elem`.
                //        Apan, `elem` sinugdanan `1 *sizeof(T)` milabay nga sa katapusan ug kami decrement kini pinaagi sa `1* sizeof(T)` sa wala pa maka-access niini.
                //        Dugang pa, ang `block_r` gipahayag nga dili moubos sa `BLOCK` ug `elem` busa labi nga magtudlo sa sinugdanan sa hiwa.
                unsafe {
                    // Pagtandi nga walay sanga.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Ang ihap sa mga wala'y kaarang nga elemento aron makapalit taliwala sa wala ug tuo nga kilid.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Imbis nga ibaylo ang us aka pares sa oras, labi ka episyente ang paghimo og cyclic permutation.
            // Dili kini estrikto nga katumbas sa pagbayloay, apan naghimo usa ka parehas nga sangputanan gamit ang labing dyutay nga operasyon sa memorya.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ang tanan nga mga elemento nga wala sa han-ay sa wala nga bloke gibalhin.Pagbalhin sa sunod nga bloke.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Ang tanan nga mga elemento nga wala sa order nga tama nga bloke gibalhin.Pagbalhin sa miaging block.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ang tanan nga patayng lawas karon anaa sa labing sa usa ka block (bisan hain sa wala o sa tuo) uban sa gikan-sa-order elemento nga panginahanglan nga matarug.
    // Ang maong nahibilin nga mga elemento mahimong lamang mibalhin ngadto sa katapusan sa sulod sa ilang mga hut-ong sa.
    //

    if start_l < end_l {
        // Nagpabilin ang wala nga bloke.
        // Mobalhin sa iyang nahibilin nga gikan-sa-order elemento sa layo sa tuo.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Nagpadayon ang tama nga bloke.
        // Igbalhin ang nahabilin nga mga elemento nga wala sa han-ay sa labing wala.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Wala`y laing mahimo, nahuman na kami.
        width(v.as_mut_ptr(), l)
    }
}

/// Ang mga partisyon nga `v` sa mga elemento nga labi ka gamay kaysa `v[pivot]`, gisundan sa mga elemento nga labi ka daghan o katumbas sa `v[pivot]`.
///
///
/// Nagbalik usa ka tuple sa:
///
/// 1. Ang ihap sa mga elemento nga labi ka gamay sa `v[pivot]`.
/// 2. Tinuod kung ang `v` gibahin na.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Ibutang ang pivot sa sinugdanan sa ad-ad.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Basaha ang pivot sa usa ka variable nga gigahin nga stack alang sa pagkaepisyente.
        // Kon ang usa ka mosunod nga pagtandi operasyon panics, ang pivot nga awtomatikong gisulat balik ngadto sa ad-ad.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Pangita-a ang una nga pares nga mga elemento nga wala sa order
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: unsafety sa ubos naglakip sa pag-indeks sa usa ka gubat.
        // Kay sa unang usa: Kita na sa pagbuhat sa mga utlanan sa pagsusi dinhi uban `l < r`.
        // Kay ang ikaduha: sa sinugdanan kita `l == 0` ug `r == v.len()` ug kami gisusi nga `l < r` sa matag operasyon sa pag-indeks.
        //                     Gikan dinhi nahibal-an namon nga ang `r` kinahanglan labing menos `r == l` nga gipakita nga balido gikan sa una.
        unsafe {
            // Pangita-a ang una nga elemento nga labi sa o parehas sa pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pangitaa ang katapusang elemento nga gamay nga ang pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` moadto nga gikan sa kasangkaran ug misulat sa mga pivot (nga mao ang usa ka pundok-gigahin baryable) balik ngadto sa ad-ad diin kini orihinal nga mao ang.
        // Kini nga lakang hinungdanon sa pagsiguro sa kahilwasan!
        //
    };

    // Ibutang ang pivot taliwala sa duha nga partisyon.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Ang mga pagbulag `v` sa mga elemento nga katumbas sa `v[pivot]` nga gisundan sa mga elemento nga labi ka taas sa `v[pivot]`.
///
/// Gibalik ang numero sa mga elemento nga parehas sa pivot.
/// Kini gituohan nga `v` wala naglakip sa mga elemento nga mas gamay kay sa pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ibutang ang pivot sa sinugdanan sa ad-ad.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Basaha ang pivot sa usa ka variable nga gigahin nga stack alang sa pagkaepisyente.
    // Kon ang usa ka mosunod nga pagtandi operasyon panics, ang pivot nga awtomatikong gisulat balik ngadto sa ad-ad.
    // SAFETY: Ang pointer dinhi mao ang balido tungod kay kini nakuha gikan sa usa ka pakisayran ngadto sa usa ka ad-ad.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Karon bahinon sa ad-ad.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: unsafety sa ubos naglakip sa pag-indeks sa usa ka gubat.
        // Kay sa unang usa: Kita na sa pagbuhat sa mga utlanan sa pagsusi dinhi uban `l < r`.
        // Kay ang ikaduha: sa sinugdanan kita `l == 0` ug `r == v.len()` ug kami gisusi nga `l < r` sa matag operasyon sa pag-indeks.
        //                     Gikan dinhi nahibal-an namon nga ang `r` kinahanglan labing menos `r == l` nga gipakita nga balido gikan sa una.
        unsafe {
            // Pangita-a ang una nga elemento nga labi ka daghan kaysa sa pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pagpangita sa katapusang elemento nga katumbas sa pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Nahuman na ba kita?
            if l >= r {
                break;
            }

            // Nagbalhin, nagbaylo ang nakita nga parisan sa gikan-sa-order elemento.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // among nakita nga `l` elemento itanding sa pivot.Idugang 1 ngadto sa asoy alang sa pivot sa iyang kaugalingon.
    l + 1

    // `_pivot_guard` moadto nga gikan sa kasangkaran ug misulat sa mga pivot (nga mao ang usa ka pundok-gigahin baryable) balik ngadto sa ad-ad diin kini orihinal nga mao ang.
    // Kini nga lakang hinungdanon sa pagsiguro sa kahilwasan!
}

/// Ginasabwag ang pipila nga mga elemento sa palibot sa pagsulay nga gubaon ang mga sundanan nga mahimong hinungdan sa dili timbang nga mga partisyon sa quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom number generator gikan sa papel nga "Xorshift RNGs" ni George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Dad-a random numero modulo niini nga gidaghanon.
        // Ang numero mohaum sa `usize` tungod kay ang `len` dili labaw sa `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Ang pila ka mga kandidato sa pivot naa sa duol sa kini nga indeks.I-randomize naton sila.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Og ang usa ka random numero modulo `len`.
            // Bisan pa, aron malikayan ang mahal nga operasyon gipadayon namon kini nga modulo usa ka gahum nga duha, ug pagkahuman maminusan sa `len` hangtod nga mohaum kini sa range nga `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` gigarantiyahan nga mubu sa `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Gipili ang usa ka pivot sa `v` ug gibalik ang indeks ug `true` kung ang hiwa nga lagmit nahan-ay na.
///
/// Ang mga elemento sa `v` mahimong ayohon pag-usab sa proseso.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimum nga gitas-on aron mapili ang median-of-medians nga pamaagi.
    // Ang mga labi ka gagmay nga hiwa naggamit sa yano nga pamaagi nga median-of-three.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximum nga gidaghanon sa mga swap nga mahimo sa kini nga kalihokan.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tulo ka mga indeks sa hapit diin kami mopili usa ka pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Giihap ang kinatibuk-ang ihap sa mga swap nga hapit na namon himuon samtang naghan-ay sa mga indeks.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps lab-a mao nga `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Nagbalhin sa mga indeks aron ang `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Makita ang median nga `v[a - 1], v[a], v[a + 1]` ug gitipig ang indeks sa `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Pagpangita mga median sa mga kasilinganan sa `a`, `b`, ug `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Pangita-a ang medyan taliwala sa `a`, `b`, ug `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Gihimo ang labing kadaghan nga mga swap.
        // Kahigayunan mao ang mga ad-ad mao ang mikunsad o kasagaran nga mikunsad, mao reversing tingali makatabang sa matang niini mas paspas.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Gisunud ang `v` nga recursively.
///
/// Kung ang usa ka hiwa adunay usa ka gisundan sa orihinal nga laray, kini gipiho ingon `pred`.
///
/// `limit` mao ang gidaghanon sa mga gitugotan dili balanse ang partitions sa wala pa-ilis sa `heapsort`.
/// Kung zero, kini nga pagpaandar molihok dayon sa heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ang mga hiwa hangtod sa kini nga gitas-on mahimo`g pagkahan-ay gamit ang pagsulud nga sulud.
    const MAX_INSERTION: usize = 20;

    // Tinuod kon sa katapusan nga pagbahin sa makatarunganon balanse.
    let mut was_balanced = true;
    // Tinuod kung ang katapusang pagbulag wala magbag-o sa mga elemento (ang hiwa nabahin na).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ang mubu kaayo nga mga hiwa gihan-ay gamit ang pagsulud.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kung daghan kaayo nga dili maayo nga mga pagpili sa pivot ang nahimo, yano nga pagbalik sa heapsort aron masiguro ang `O(n * log(n))` labing kadaot nga kaso.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Kon ang katapusan nga pagbahin nga dili balanse ang, sulayi sa paglapas sumbanan sa ad-ad sa shuffling sa pipila elemento sa palibot.
        // Hinaut nga magpili kami usa ka labi ka kaayo nga pang-igbaw sa kini nga oras.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pagpili usa ka pivot ug pagsulay sa pagtag-an kung ang hiwa nahan-ay na.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Kon ang katapusan nga pagbahin sa kahapsay balanse ug wala shuffle mga elemento, ug kon pivot pagpili nagtagna sa ad-ad mao ang lagmit na lainlainon ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Sulayi ang pag-ila sa daghang mga elemento nga wala sa order ug ibalhin kini sa husto nga posisyon.
            // Kung ang hiwa natapos nga hingpit nga gihan-ay, nahuman na kami.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Kung ang gipili nga pivot parehas sa gisundan, nan kini ang pinakagamay nga elemento sa hiwa.
        // Bahina ang hiwa sa mga elemento nga managsama ug mga elemento nga labi ka daghan sa pivot.
        // Kasagaran naigo kini nga kaso kung ang slice adunay sulud nga daghang mga duplicate nga elemento.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Padayon sa paghan-ay sa mga elemento nga labi ka daghan sa pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Bahina ang hiwa.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Tipak sa ad-ad sa `left`, `pivot`, ug `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Pagbalik lang sa mas mubu nga bahin aron maminusan ang kinatibuk-ang ihap sa mga nagbalikbalik nga tawag ug mahurot ang mas gamay nga wanang sa stack.
        // Pagkahuman ipadayon ra ang labi ka taas nga bahin (kini pareho sa recursion sa ikog).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Nasunud ang `v` gamit ang pattern-daog nga quicksort, nga mao ang *O*(*n*\*log(* n*)) labing grabe nga kaso.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ang pagsulud wala makahuluganon nga pamatasan sa mga wala`y gidak-on nga lahi.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limitahan ang gidaghanon sa dili timbang nga mga partisyon sa `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kay hiwa sa sa gitas-on niini nga kini tingali mas paspas sa lamang matang kanila.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pagpili usa ka pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Kung ang gipili nga pivot parehas sa gisundan, nan kini ang pinakagamay nga elemento sa hiwa.
        // Bahina ang hiwa sa mga elemento nga managsama ug mga elemento nga labi ka daghan sa pivot.
        // Kasagaran naigo kini nga kaso kung ang slice adunay sulud nga daghang mga duplicate nga elemento.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kung nakapasar kami sa among indeks, nan maayo kami.
                if mid > index {
                    return;
                }

                // Kung dili, ipadayon ang mga elemento sa paghan-ay nga labi ka daghan sa pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Tipak sa ad-ad sa `left`, `pivot`, ug `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Kon sa tunga-tunga==index, nan kita gibuhat, tungod kay partition() garantiya nga ang tanan nga mga elemento human sa tunga-tunga sa mga labaw pa kay sa o itanding tunga.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ang pagsulud wala makahuluganon nga pamatasan sa mga wala`y gidak-on nga lahi.Pagbuhat sa bisan unsa.
    } else if index == v.len() - 1 {
        // Pagpangita max elemento ug ibutang kini sa katapusan nga posisyon sa array.
        // Kita gawasnon sa paggamit sa `unwrap()` dinhi tungod kay kita nasayud v kinahanglan dili nga walay sulod.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Pangitaa ang min elemento ug ibutang kini sa unang posisyon sa gubat.
        // Kita gawasnon sa paggamit sa `unwrap()` dinhi tungod kay kita nasayud v kinahanglan dili nga walay sulod.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}