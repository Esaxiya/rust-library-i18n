// Orihinal nga pagpatuman gikuha gikan sa rust-memchr.
// Copyright 2015 Andrew Gallant, bluss ug Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Paggamit truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Gibalik ang `true` kung ang `x` adunay sulud nga bisan unsang zero byte.
///
/// Gikan sa *Hinungdanon computational*, J. Arndt:
///
/// "Ang ideya mao nga kunhoran ug usa gikan sa matag usa sa mga bytes ug unya motan-aw alang sa bytes diin ang makahulam propagated sa tanan nga mga dalan ngadto sa labing mahinungdanon nga
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Gibalik ang una nga indeks nga nagtugma sa byte `x` sa `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Paspas nga agianan alang sa gagmay nga mga hiwa
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan alang sa usa ka bili Byte pinaagi sa pagbasa sa duha ka `usize` mga pulong sa usa ka panahon.
    //
    // Bahina ang `text` sa tulo nga bahin
    // - wala matumong unang bahin, sa wala pa ilaray ang unang pulong nga pakigpulong sa teksto
    // - lawas, scan sa 2 mga pulong sa usa ka panahon
    // - ang katapusan nga nahabilin nga bahin, <2 gidak-on sa pulong

    // pagpangita sa usa ka ilaray utlanan
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // pangitaa ang lawas sa teksto
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: predicate sa samtang ang nagpasalig sa usa ka gilay-on sa labing menos 2 * usize_bytes
        // taliwala sa offset ug katapusan sa hiwa.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // paglapas kon adunay usa ka matching Byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Pangitaa ang Byte human sa punto sa lawas laang mihunong.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Gibalik ang katapusang indeks nga nagtugma sa byte `x` sa `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan alang sa usa ka bili Byte pinaagi sa pagbasa sa duha ka `usize` mga pulong sa usa ka panahon.
    //
    // Bahina ang `text` sa tulo nga bahin:
    // - wala matumong ikog, human sa katapusan nga pulong ilaray address sa teksto,
    // - lawas, gi-scan sa 2 nga mga pulong matag higayon,
    // - ang unang nahibilin nga bytes, <2 pulong nga gidak-on.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Gitawag namon kini aron lang makuha ang gitas-on sa unlapi ug igsusulat.
        // Sa kinataliwad-an kanunay namon nga giproseso ang duha nga tipak sa usa ka higayon.
        // KALUWASAN: ang pagbalhin sa `[u8]` sa `[usize]` luwas gawas sa mga kalainan sa gidak-on nga gidumala sa `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Pangitaa ang lawas sa teksto, sa pagsiguro atong buhaton dili krus min_aligned_offset.
    // ang offset kanunay nga nakahanay, busa ang pagsulay ra sa `>` igo na ug naglikay sa posible nga pag-awas.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // KALUWASAN: ang offset magsugod sa len, suffix.len(), basta kini mas daghan kaysa
        // min_aligned_offset (prefix.len()) ang nahabilin nga distansya labing menos 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Paglunga kung adunay usa ka parehas nga byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Pangitaa ang byte sa wala pa ang punto nga mihunong ang loop sa lawas.
    text[..offset].iter().rposition(|elt| *elt == x)
}