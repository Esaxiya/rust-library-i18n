//! Macros nga gigamit sa iterators sa ad-ad.

// Ang pagsulud sa is_empty ug len naghimo sa usa ka dako nga kalainan sa paghimo
macro_rules! is_empty {
    // Ang paagi nga gi-encode namon ang gitas-on sa usa ka ZST iterator, kini molihok alang sa ZST ug dili ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Aron sa pagkuha Isalikway sa pipila utlanan tseke (tan-awa sa `position`), banabanaon kita sa gitas-on sa usa ka medyo wala damha nga paagi.
// (Gisulayan sa `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // gigamit usahay kami sa sulud sa usa ka dili luwas nga bloke

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Gigamit kini nga _cannot_ nga `unchecked_sub` tungod kay nagsalig kami sa pagputos nga magrepresentar sa gitas-on sa taas nga ZST slice iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Nahibal-an namon nga ang `start <= end`, mao nga makahimo labi ka maayo kaysa `offset_from`, nga kinahanglan nga makig-sign in nga gipirmahan.
            // Pinaagi sa pagtakda sa angay nga mga bandila dinhi masulti namon kini sa LLVM, nga makatabang nga makuha ang mga tseke sa mga utlanan.
            // SAFETY: Pinaagi sa matang makanunayon, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Pinaagi sa pagsulti usab LLVM nga ang mga pointers mga apart pinaagi sa usa ka tukma nga daghang sa gidak-on nga matang, kini optimize `len() == 0` ngadto sa `start == end` inay sa `(end - start) < size`.
            //
            // SAFETY: Pinaagi sa matang makanunayon, sa mga igpupunting nga ilaray mao nga ang mga
            //         ang gilay-on sa taliwala nila kinahanglan usa ka kadaghan sa gidak-on sa pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ang gipaambit nga kahulugan sa mga iterator nga `Iter` ug `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Gibalik ang una nga elemento ug gipalihok ang pagsugod sa iterator sa unahan sa 1.
        // Labi nga gipaayo ang paghimo kung ikumpara sa usa ka linya nga gilaraw.
        // Ang iterator kinahanglan dili walay sulod.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Mobalik sa katapusan nga elemento ug nagalihok sa katapusan sa iterator naglakaw sa 1.
        // Labi nga gipaayo ang paghimo kung ikumpara sa usa ka linya nga gilaraw.
        // Ang iterator kinahanglan dili walay sulod.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Gipakubus ang iterator kung ang T usa ka ZST, pinaagi sa pagbalhin sa katapusan sa iterator nga paatras sa `n`.
        // `n` kinahanglan dili molapas sa `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Katabang paglihok alang sa pagmugna sa usa ka ad-ad gikan sa iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KALUWASAN: ang iterator gihimo gikan sa usa ka slice nga adunay pointer
                // `self.ptr` ug ang gitas-on `len!(self)`.
                // Gipasalig niini nga ang tanan nga kinahanglanon alang sa `from_raw_parts` natuman.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ang paglihok sa helper alang sa paglihok sa pagsugod sa iterator sa unahan sa mga elemento nga `offset`, nga gibalik ang daan nga pagsugod.
            //
            // Dili luwas tungod kay ang offset kinahanglan dili molapas sa `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: ang caller garantiya nga `offset` wala molabaw `self.len()`,
                    // busa kini nga bag-ong pointer naa sa sulud sa `self` ug sa ingon gigarantiyahan nga mahimo`g wala`y bili.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ang katabang sa helper alang sa paglihok sa katapusan sa iterator paatras sa mga elemento nga `offset`, nga gibalik ang bag-ong katapusan.
            //
            // Dili luwas tungod kay ang offset kinahanglan dili molapas sa `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: ang caller garantiya nga `offset` wala molabaw `self.len()`,
                    // nga gigarantiyahan sa dili pagsugwak sa usa ka `isize`.
                    // Ingon usab, ang sangputanan nga pointer naa sa mga utlanan nga `slice`, nga nagtuman sa uban pang mga kinahanglanon alang sa `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // mahimong ipatuman sa mga hiwa, apan kini makalikay sa mga pagsusi sa utlanan

                // SAFETY: `assume` tawag luwas sukad pa sa pagsugod pointer sa usa ka ad-ad sa
                // kinahanglan nga dili-null, ug ang mga hiwa sa dili mga ZST kinahanglan usab adunay usa ka dili katapusan nga punoan.
                // Ang tawag sa `next_unchecked!` luwas tungod kay gisusi namon kung wala ba una ang iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ang iterator karon wala`y sulod.
                    if mem::size_of::<T>() == 0 {
                        // Kinahanglan naton kini buhaton sa ingon ingon ang `ptr` mahimong dili gyud 0, apan ang `end` mahimo (tungod sa pagputos).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // KALUWASAN: ang katapusan dili mahimong 0 kung ang T dili ZST tungod kay ang ptr dili 0 ug matapos>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // KALuwas-an: Naa kami sa mga utlanan.Gibuhat sa `post_inc_start` ang tama nga butang bisan alang sa mga ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            // Ingon usab, naglikay ang `assume` sa usa ka tseke nga utlanan.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KALUWASAN: kita gigarantiyahan nga naa sa mga utlanan sa loop invariant:
                        // kung ang `i >= n`, `self.next()` ibalik ang `None` ug ang loop mobuak.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Gisapawan namon ang default nga pagpatuman, nga gigamit ang `try_fold`, tungod kay ang kini nga yano nga pagpatuman makamugna dili kaayo LLVM IR ug mas paspas kini nga matipon.
            // Ingon usab, naglikay ang `assume` sa usa ka tseke nga utlanan.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KALUWASAN: Ang `i` kinahanglan nga mas ubos kaysa `n` tungod kay nagsugod kini sa `n`
                        // ug nagminus ra.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `i` naa sa mga utlanan
                // ang tinuod nga hinungdan sa ad-ad, aron `i` dili magaawas sa usa ka `isize`, ug ang mibalik nga mga pakisayran mao ang garantiya nga nagtumong sa usa ka elemento sa ad-ad ug sa ingon garantiya nga mahimong balido.
                //
                // Hinumdomi usab nga ang nanawag naggarantiya usab nga wala gyud kami tawgan nga adunay parehas nga indeks, ug wala`y uban pang mga pamaagi nga ma-access ang kini nga subslice nga gitawag, busa husto alang sa nabalik nga reperensya nga mabalhin sa kaso sa
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // mahimong ipatuman sa mga hiwa, apan kini makalikay sa mga pagsusi sa utlanan

                // KALUWASAN: luwas ang mga tawag sa `assume` tungod kay kinahanglan nga dili null ang pagsugod sa usa ka tip sa usa ka slice,
                // ug ang mga hiwa sa dili mga ZST kinahanglan usab adunay usa ka dili katapusan nga punoan.
                // Ang tawag sa `next_back_unchecked!` luwas tungod kay gisusi namon kung wala ba una ang iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ang iterator karon wala`y sulod.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KALuwas-an: Naa kami sa mga utlanan.Gibuhat sa `pre_dec_end` ang tama nga butang bisan alang sa mga ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}