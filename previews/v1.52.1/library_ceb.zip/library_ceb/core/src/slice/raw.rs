//! Libre ang mga gimbuhaton aron makahimo `&[T]` ug `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Naghimo usa ka hiwa gikan sa usa ka pointer ug usa ka gitas-on.
///
/// Ang `len` argumento mao ang gidaghanon sa mga **elemento**, dili ang gidaghanon sa mga bytes.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `data` kinahanglan [valid] alang sa mabasa sa `len * mem::size_of::<T>()` sa daghang mga bytes, ug kini kinahanglan nga sa tukmang paagi ilaray.Kini nagpasabot sa partikular:
///
///     * Ang bug-os nga-laing handumanan sa ad-ad kinahanglan nga anaa sa sulod sa usa ka single nga gigahin butang!
///       Hiwa dili gayud dangaw tabok multiple gigahin butang.Tan-awa ang [below](#incorrect-usage) alang sa usa ka panig-ingnan sayop nga dili kini ngadto sa account.
///     * `data` kinahanglan nga non-bili ug ilaray bisan sa zero-ang gitas-on hiwa.
///     Ang usa ka katarungan alang niini mao nga ang mga pag-optimize sa layout sa enum mahimong magsalig sa mga pakisayran (lakip ang mga hiwa sa bisan unsang gitas-on) nga nakahanay ug dili null aron mailhan sila gikan sa ubang mga datos.
///     Mahimo ka makakuha usa ka pointer nga magamit ingon `data` alang sa mga zero-length nga mga hiwa gamit ang [`NonNull::dangling()`].
///
/// * `data` kinahanglan itudlo ang `len` sunod-sunod nga husto nga pasiuna nga mga kantidad sa tipo `T`.
///
/// * Ang panumduman nga girekomenda sa gipabalik nga hiwa kinahanglan dili mutated sa gidugayon sa kinabuhi nga `'a`, gawas sa sulud sa usa ka `UnsafeCell`.
///
/// * Ang kinatibuk-ang gidak-on nga `len * mem::size_of::<T>()` sa hiwa kinahanglan dili labaw sa `isize::MAX`.
///   Tan-awa ang kaluwasan dokumentasyon sa [`pointer::offset`].
///
/// # Caveat
///
/// Ang tibuok kinabuhi alang sa giuli nga hiwa gipahinumdom gikan sa paggamit niini.
/// Aron malikayan ang sulagma sayop nga paggamit, kini nga gisugyot nga ihigot ang mga tibuok kinabuhi sa bisan tinubdan tibuok kinabuhi mao ang luwas diha sa konteksto, sama sa pinaagi sa paghatag sa usa ka katabang function sa pagkuha sa tibuok kinabuhi sa usa ka bili panon alang sa ad-ad, o pinaagi sa tin-aw nga annotation.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // mopakita sa usa ka ad-ad alang sa usa ka elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Dili sakto nga paggamit
///
/// Ang mosunod `join_slices` function mao ang **bati nga** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ang gipahayag sa taas nagsiguro nga ang `fst` ug `snd` magkadugtong, apan mahimo pa usab kini sulud sa sulud sa _different allocated objects_, diin ang paghimo niini nga hiwa dili matino nga kinaiya.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ug `b` lainlaing gigahin nga mga butang ...
///     let a = 42;
///     let b = 27;
///     // ... nga bisan pa nga gibutang sa contiguously sa handumanan: |usa |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Gihimo ang parehas nga pagpaandar ingon [`from_raw_parts`], gawas nga ang usa ka mabalhin nga hiwa ibalik.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `data` kinahanglan [valid] alang sa mga mabasa ug misulat alang sa `len * mem::size_of::<T>()` sa daghang mga bytes, ug kini kinahanglan nga sa tukmang paagi ilaray.Ilabi na kini gipasabut:
///
///     * Ang bug-os nga-laing handumanan sa ad-ad kinahanglan nga anaa sa sulod sa usa ka single nga gigahin butang!
///       Ang mga hiwa dili gyud molapas sa daghang mga gigahin nga mga butang.
///     * `data` kinahanglan nga non-bili ug ilaray bisan sa zero-ang gitas-on hiwa.
///     Ang usa ka katarungan alang niini mao nga ang mga pag-optimize sa layout sa enum mahimong magsalig sa mga pakisayran (lakip ang mga hiwa sa bisan unsang gitas-on) nga nakahanay ug dili null aron mailhan sila gikan sa ubang mga datos.
///
///     Mahimo ka makakuha usa ka pointer nga magamit ingon `data` alang sa mga zero-length nga mga hiwa gamit ang [`NonNull::dangling()`].
///
/// * `data` kinahanglan itudlo ang `len` sunod-sunod nga husto nga pasiuna nga mga kantidad sa tipo `T`.
///
/// * Ang panumduman nga gi-refer sa gipabalik nga hiwa kinahanglan dili ma-access pinaagi sa bisan unsang uban pang pointer (dili makuha gikan sa pagbalik nga kantidad) sa gidugayon sa kinabuhi nga `'a`.
///   Parehas nga gidili ang pag-access sa pagbasa ug pagsulat.
///
/// * Ang kinatibuk-ang gidak-on nga `len * mem::size_of::<T>()` sa hiwa kinahanglan dili labaw sa `isize::MAX`.
///   Tan-awa ang kaluwasan dokumentasyon sa [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Nakabig usa ka pakisayran sa T sa usa ka hiwa nga gitas-on 1 (nga wala`y pagkopya).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Nakabig usa ka pakisayran sa T sa usa ka hiwa nga gitas-on 1 (nga wala`y pagkopya).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}