//! Mga intrinsik sa tag-compiler.
//!
//! Ang katumbas nga mga depinisyon anaa sa `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ang katugbang const implementar sa anaa sa `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: sa bisan unsa nga mga kausaban sa constness sa intrinsics kinahanglan nga gihisgutan sa team pinulongan.
//! Kini naglakip sa mga kausaban diha sa kalig-on sa constness.
//!
//! Aron sa paghimo sa usa ka duna nga magamit sa pagtipon-panahon, sa usa ka panginahanglan sa pagkopya sa pagpatuman gikan sa <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ngadto sa `compiler/rustc_mir/src/interpret/intrinsics.rs` ug makadugang sa usa ka `#[rustc_const_unstable(feature = "foo", issue = "01234")]` sa duna nga.
//!
//!
//! Kung ang usa ka intrinsic gituohan nga magamit gikan sa usa ka `const fn` nga adunay usa ka `rustc_const_stable` nga hiyas, ang kinaiya sa kinaiyanhon kinahanglan nga `rustc_const_stable` usab.
//! Ang ingon nga pagbag-o dili kinahanglan buhaton nga wala`y konsulta sa T-lang, tungod kay nagluto kini usa ka bahin sa sinultian nga dili mahimo`g kopyahon sa code sa gumagamit kung wala ang suporta sa tagatap.
//!
//! # Volatiles
//!
//! Ang mga dali mabag-o nga intrinsik naghatag mga operasyon nga gituyo aron molihok sa memorya nga I/O, nga gigarantiyahan nga dili mabag-o sa pagmando sa tagtipig sa uban pang mga dali nga masulud nga intrinsiko.Tan-awa ang dokumentasyon sa LLVM sa [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ang mga atomic intrinsics naghatag kasagarang operasyon sa atomic sa mga pulong sa makina, nga adunay daghang posible nga paghan-ay sa memorya.Sila mosunod sa sa mao usab nga semantiko ingon C++ 11.Tan-awa ang LLVM dokumento sa [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Usa ka dali nga pag-refresh sa pag-order sa memorya:
//!
//! * Batoni ang, usa ka babag alang sa pagbaton sa usa ka pungpong sa buhok.Sunod-sunod nga mabasa ug misulat sa pagkuha sa dapit human sa babag.
//! * Pag-release, usa ka babag alang sa pagpagawas sa usa ka kandado.Ang nag-una nga pagbasa ug pagsulat mahitabo sa wala pa ang babag.
//! * Ang sunod-sunod nga sunod-sunod, sunud-sunod nga makanunayon nga mga operasyon gigarantiyahan nga mahitabo sa han-ay.Kini mao ang sumbanan nga paagi alang sa pagtrabaho uban sa atomic nga mga matang ug ang katumbas ni Java `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Kini nga mga imports gigamit alang sa pagpayano intra-doc sumpay
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KALUWASAN: tan-awa ang `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, kini nga mga intrinsics pagkuha sa hilaw nga mga tambag tungod kay sila motransporm aliased handumanan, nga mao ang dili balido alang sa bisan hain `&` o `&mut`.
    //

    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa pamaagi nga `compare_exchange` pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon pareho ang `success` ug `failure` nga mga parameter.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa pamaagi nga `compare_exchange` pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon pareho ang `success` ug `failure` nga mga parameter.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa pamaagi nga `compare_exchange` pinaagi sa pagpasa sa [`Ordering::Release`] ingon `success` ug [`Ordering::Relaxed`] ingon ang `failure` nga mga parameter.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon nga ang `success` ug [`Ordering::Acquire`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa mga `success` ug `failure` lantugi.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon nga ang `success` ug [`Ordering::Acquire`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa pamaagi nga `compare_exchange_weak` pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon pareho ang `success` ug `failure` nga mga parameter.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa mga `success` ug `failure` lantugi.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::Release`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon nga ang `success` ug [`Ordering::Acquire`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `compare_exchange_weak` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon pareho ang `success` ug `failure` nga mga parameter.
    ///
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon nga ang `success` ug [`Ordering::Acquire`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tindahan sa usa ka bili kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `old`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `compare_exchange_weak` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon nga ang `success` ug [`Ordering::Relaxed`] ingon sa mga lantugi `failure`.
    /// Pananglitan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Gilulanan ang kasamtangang bili sa pointer.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `load` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon `order`.
    /// Pananglitan, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Gilulanan ang kasamtangang bili sa pointer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `load` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Gilulanan ang kasamtangang bili sa pointer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `load` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Tindahan sa bili sa espesipikong nahimutangan sa panumduman.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `store` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Tindahan sa bili sa espesipikong nahimutangan sa panumduman.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `store` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Tindahan sa bili sa espesipikong nahimutangan sa panumduman.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `store` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Tindahan sa bili sa bungat nahimutangan sa panumduman, pagbalik sa daan nga bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `swap` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon `order`.
    /// Pananglitan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tindahan sa bili sa bungat nahimutangan sa panumduman, pagbalik sa daan nga bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `swap` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tindahan sa bili sa bungat nahimutangan sa panumduman, pagbalik sa daan nga bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `swap` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tindahan sa bili sa bungat nahimutangan sa panumduman, pagbalik sa daan nga bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `swap` nga pamaagi pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon `order`.
    /// Pananglitan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tindahan sa bili sa bungat nahimutangan sa panumduman, pagbalik sa daan nga bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `swap` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_add` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_add` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon `order`.
    /// Pananglitan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_add` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Release`] ingon `order`.
    /// Pananglitan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_add` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_add` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kuhaan sa gikan sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_sub` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuhaan sa gikan sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_sub` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon `order`.
    /// Pananglitan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuhaan sa gikan sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_sub` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuhaan sa gikan sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_sub` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuhaan sa gikan sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_sub` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ug uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_and` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ug uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_and` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ug uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_and` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ug uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa pamaagi nga `fetch_and` pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ug uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_and` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`AtomicBool`] nga tipo pinaagi sa `fetch_nand` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon ang `order`.
    /// Pananglitan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`AtomicBool`] pinaagi sa `fetch_nand` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`AtomicBool`] pinaagi sa `fetch_nand` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`AtomicBool`] pinaagi sa `fetch_nand` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`AtomicBool`] nga tipo pinaagi sa `fetch_nand` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon ang `order`.
    /// Pananglitan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise o uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_or` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_or` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_or` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_or` nga pamaagi pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_or` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_xor` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_xor` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga matang [`atomic`] pinaagi sa `fetch_xor` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_xor` nga pamaagi pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor uban sa kasamtangan nga bili, pagbalik sa miaging bili.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa mga klase nga [`atomic`] pinaagi sa `fetch_xor` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum uban sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] gipirmahan integer matang pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum uban sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_max` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum uban sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] gipirmahan integer matang pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum uban sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_max` nga pamaagi pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum nga adunay karon nga kantidad.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_max` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum nga uban sa sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga uban sa sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] gipirmahan integer matang pinaagi sa `fetch_min` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga uban sa sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Release`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga uban sa sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] gipirmahan integer matang pinaagi sa `fetch_min` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga uban sa sa kasamtangan nga bili sa paggamit sa usa ka gipirmahan pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] nga gipirmahan nga mga integer type pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Relaxed`] ingon `order`.
    /// Pananglitan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum nga adunay karon nga kantidad gamit ang usa nga wala gipirmahan nga pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] unsigned integer nga mga klase pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon `order`.
    /// Pananglitan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga adunay karon nga kantidad gamit ang usa nga wala gipirmahan nga pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] unsigned integer nga mga klase pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon `order`.
    /// Pananglitan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga adunay karon nga kantidad gamit ang usa nga wala gipirmahan nga pagtandi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic`] unsigned integer nga mga klase pinaagi sa `fetch_min` nga pamaagi pinaagi sa pagpasa sa [`Ordering::Release`] ingon `order`.
    /// Pananglitan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga adunay karon nga kantidad gamit ang usa nga wala gipirmahan nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_min` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum nga adunay karon nga kantidad gamit ang usa nga wala gipirmahan nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_min` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Labing kadaghan sa karon nga kantidad gamit ang usa nga wala pa marka nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Labing kadaghan sa karon nga kantidad gamit ang usa nga wala pa marka nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Labing kadaghan sa karon nga kantidad gamit ang usa nga wala pa marka nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::Release`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Labing kadaghan sa karon nga kantidad gamit ang usa nga wala pa marka nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Labing kadaghan sa karon nga kantidad gamit ang usa nga wala pa marka nga pagtandi.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa ibabaw sa mga [`atomic`] Unsigned matang integer pinaagi sa `fetch_max` pamaagi pinaagi sa agi [`Ordering::Relaxed`] ingon sa `order`.
    /// Pananglitan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ang `prefetch` sulod mao ang usa ka timailhan sa sa code generator sa sal-ot sa usa ka prefetch pahamatngon kon gisuportahan;kung dili, kini usa ka no-op.
    /// Prefetches walay epekto sa kinaiya sa mga programa apan mahimo usab sa iyang performance kinaiya.
    ///
    /// Ang `locality` argumento kinahanglan nga usa ka kanunay nga integer ug mao ang usa ka temporal nga lugar specifier gikan (0), walay dapit, sa (3), hilabihan lokal nga Ibutang sa cache.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ang `prefetch` sulod mao ang usa ka timailhan sa sa code generator sa sal-ot sa usa ka prefetch pahamatngon kon gisuportahan;kung dili, kini usa ka no-op.
    /// Prefetches walay epekto sa kinaiya sa mga programa apan mahimo usab sa iyang performance kinaiya.
    ///
    /// Ang `locality` argumento kinahanglan nga usa ka kanunay nga integer ug mao ang usa ka temporal nga lugar specifier gikan (0), walay dapit, sa (3), hilabihan lokal nga Ibutang sa cache.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ang `prefetch` sulod mao ang usa ka timailhan sa sa code generator sa sal-ot sa usa ka prefetch pahamatngon kon gisuportahan;kung dili, kini usa ka no-op.
    /// Prefetches walay epekto sa kinaiya sa mga programa apan mahimo usab sa iyang performance kinaiya.
    ///
    /// Ang `locality` argumento kinahanglan nga usa ka kanunay nga integer ug mao ang usa ka temporal nga lugar specifier gikan (0), walay dapit, sa (3), hilabihan lokal nga Ibutang sa cache.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ang `prefetch` sulod mao ang usa ka timailhan sa sa code generator sa sal-ot sa usa ka prefetch pahamatngon kon gisuportahan;kung dili, kini usa ka no-op.
    /// Prefetches walay epekto sa kinaiya sa mga programa apan mahimo usab sa iyang performance kinaiya.
    ///
    /// Ang `locality` argumento kinahanglan nga usa ka kanunay nga integer ug mao ang usa ka temporal nga lugar specifier gikan (0), walay dapit, sa (3), hilabihan lokal nga Ibutang sa cache.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Usa ka atomic koral.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic::fence`] pinaagi sa pagpasa sa [`Ordering::SeqCst`] ingon ang `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Usa ka atomic koral.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic::fence`] pinaagi sa pagpasa sa [`Ordering::Acquire`] ingon ang `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Usa ka atomic koral.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic::fence`] pinaagi sa pagpasa sa [`Ordering::Release`] ingon ang `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Usa ka atomic koral.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa [`atomic::fence`] pinaagi sa agi [`Ordering::AcqRel`] ingon sa `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Usa ka babag sa panumdoman ra.
    ///
    /// Ang mga pag-access sa memorya dili mahimo`g usab mabag-o sa tibuuk nga babag niini sa tagtipon, apan wala`y gipagawas nga mga panudlo alang niini.
    /// Kini mao ang angay alang sa operasyon sa samang hilo nga mahimong-una, sama sa dihang makig-uban sa handlers signal.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa [`atomic::compiler_fence`] pinaagi sa agi [`Ordering::SeqCst`] ingon sa `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Usa ka babag sa panumdoman ra.
    ///
    /// Ang mga pag-access sa memorya dili mahimo`g usab mabag-o sa tibuuk nga babag niini sa tagtipon, apan wala`y gipagawas nga mga panudlo alang niini.
    /// Kini mao ang angay alang sa operasyon sa samang hilo nga mahimong-una, sama sa dihang makig-uban sa handlers signal.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang anaa sa [`atomic::compiler_fence`] pinaagi sa agi [`Ordering::Acquire`] ingon sa `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Usa ka babag sa panumdoman ra.
    ///
    /// Ang mga pag-access sa memorya dili mahimo`g usab mabag-o sa tibuuk nga babag niini sa tagtipon, apan wala`y gipagawas nga mga panudlo alang niini.
    /// Kini mao ang angay alang sa operasyon sa samang hilo nga mahimong-una, sama sa dihang makig-uban sa handlers signal.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic::compiler_fence`] pinaagi sa pagpasa sa [`Ordering::Release`] ingon ang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Usa ka babag sa panumdoman ra.
    ///
    /// Ang mga pag-access sa memorya dili mahimo`g usab mabag-o sa tibuuk nga babag niini sa tagtipon, apan wala`y gipagawas nga mga panudlo alang niini.
    /// Kini mao ang angay alang sa operasyon sa samang hilo nga mahimong-una, sama sa dihang makig-uban sa handlers signal.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic magamit sa [`atomic::compiler_fence`] pinaagi sa pagpasa sa [`Ordering::AcqRel`] ingon ang `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic sulod nga derives kahulogan niini gikan sa mga hiyas gilakip ngadto sa function.
    ///
    /// Pananglitan, dataflow gamit niini sa inject nagahunong pangangkon aron nga `rustc_peek(potentially_uninitialized)` nga sa tinuod double-check nga dataflow gayod banabanaon nga kini uninitialized sa punto nga sa dagan sa kontrol.
    ///
    ///
    /// Kini nga intrinsic dili angay gamiton sa gawas sa nag-compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Nag-abort sa pagpatuman sa proseso.
    ///
    /// Usa ka dugang nga user-friendly ug lig-on nga bersyon sa operasyon niini mao [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Nagpahibalo sa optimizer nga niini nga punto sa sa code dili makab-ot, nga tungod niana ang dugang pa nga optimizations.
    ///
    /// NB, kini mao ang kaayo sa lain-laing gikan sa `unreachable!()` macro: Dili sama sa macro, nga panics sa diha nga kini gipatay, kini mao ang *dili tino ang kinaiya* sa pagkab-ot code gimarkahan uban sa niini nga function.
    ///
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Nagpahibalo sa optimizer nga usa ka kahimtang mao ang kanunay nga ang tinuod nga.
    /// Kung ang kahimtang sayup, ang pamatasan dili matino.
    ///
    /// Wala`y code nga nahimo alang sa kini nga intrinsic, apan ang optimizer mosulay sa pagpreserba niini (ug ang kondisyon niini) taliwala sa mga pass, nga mahimong makagambala sa pag-optimize sa palibot nga code ug maminusan ang paghimo.
    /// Kini dili kinahanglan nga gamiton kon ang makanunayon mahimong nadiskobrehan sa optimizer sa iyang kaugalingon, o kon kini dili makapahimo sa bisan unsa nga mahinungdanon nga optimizations.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Sugyot sa tighipos nga branch kahimtang mao ang lagmit nga tinuod.
    /// Gibalik ang kantidad nga gipasa niini.
    ///
    /// Bisan unsang paggamit gawas sa mga pahayag nga `if` tingali wala`y epekto.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Sugyot sa tighipos nga branch kahimtang mao ang lagmit nga mahimong sa bakak.
    /// Gibalik ang kantidad nga gipasa niini.
    ///
    /// Bisan unsang paggamit gawas sa mga pahayag nga `if` tingali wala`y epekto.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Nagpatuman sa usa ka breakpoint trap, alang sa pagsusi sa usa ka debugger.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn breakpoint();

    /// Ang gidak-on sa usa ka matang sa bytes.
    ///
    /// Labi ka piho, kini ang offset sa mga byte taliwala sa sunud-sunod nga mga butang nga parehas nga lahi, lakip ang alignment padding.
    ///
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ang minimum nga paglinya sa usa ka lahi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic mao ang [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ang gusto pagpahiangay sa usa ka matang.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ang kadako sa gihisgotan nga kantidad sa mga byte.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ang kinahanglan nga paghan-ay sa gihisgotan nga kantidad.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Nakakuha usa ka static nga hiwa nga pisi nga adunay sulud nga ngalan sa usa ka lahi.
    ///
    /// Ang nagpalig-on nga bersyon sa kini nga intrinsic mao ang [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Nakakuha usa ka tigpaila nga sa tibuuk kalibutan tibuuk sa gipiho nga tipo.
    /// function Kini nga mobalik sa sama nga bili alang sa usa ka matang sa walay pagtagad sa bisan crate kini mihatag sa.
    ///
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Usa ka magbalantay alang sa dili luwas nga gimbuhaton nga dili sa walay katapusan nga gipatay kon `T` mao walay nagpuyo:
    /// Kini nga kabubut-on sa urong sa bisan panic, o pagbuhat sa bisan unsa.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Usa ka magbalantay alang sa dili luwas nga gimbuhaton nga dili sa walay katapusan nga gipatay kon `T` wala motugot zero-Initialization: Kini nga kabubut-on sa urong sa bisan panic, o pagbuhat sa bisan unsa.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn assert_zero_valid<T>();

    /// Usa ka magbalantay alang sa dili luwas nga gimbuhaton nga dili sa walay katapusan nga gipatay kon `T` adunay imbalido gamay sumbanan: Kini nga kabubut-on sa urong sa bisan panic, o pagbuhat sa bisan unsa.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn assert_uninit_valid<T>();

    /// Nakakuha usa ka pakisayran sa usa ka static `Location` nga nagpakita diin kini gitawag.
    ///
    /// Hunahunaa ang paggamit sa [`core::panic::Location::caller`](crate::panic::Location::caller) sa baylo.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Nagpalihok sa usa ka bili gikan sa kasangkaran sa walay nagaagay nga drop glue.
    ///
    /// Naa ra kini alang sa [`mem::forget_unsized`];normal `forget` naggamit `ManuallyDrop` sa baylo.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Gihubad usab ang mga tipik sa usa ka kantidad sa us aka lahi sama sa lain nga lahi.
    ///
    /// Ang parehas nga lahi kinahanglan adunay parehas nga gidak-on.
    /// Ni ang orihinal, ni ang resulta, mahimo nga ang usa ka [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` mao semantically katumbas sa usa ka bitwise lakang sa usa ka matang ngadto sa lain.Gikopya niini ang mga tipik gikan sa gigikanan nga kantidad hangtod sa kantidad nga padulngan, ug hikalimtan ang orihinal.
    /// Kini katumbas sa C's `memcpy` sa ilawom sa hood, sama sa `transmute_copy`.
    ///
    /// Tungod kay `transmute` mao ang usa ka sa-bili operasyon, paglaray, pagtalay sa *transmuted mga prinsipyo sa ilang kaugalingon* dili usa ka kabalaka.
    /// Sama sa bisan unsa nga lain nga mga function, ang tighipos na nagsiguro duha `T` ug `U` husto ilaray.
    /// Apan, sa dihang ilisan nga mga prinsipyo nga *nga punto sa ubang dapit*(sama sa pointers, mga pakisayran, mga kahon ...), ang caller adunay aron sa pagsiguro sa husto nga pagsunod sa mga talinis nga-sa mga prinsipyo.
    ///
    /// `transmute` mao ang **hilabihan** dili luwas.Adunay usa ka halapad nga gidaghanon sa mga paagi sa hinungdan sa [undefined behavior][ub] uban sa niini nga function.Ang `transmute` kinahanglan mao ang hingpit nga katapusan nga paagi.
    ///
    /// Ang [nomicon](../../nomicon/transmutes.html) adunay dugang nga dokumentasyon.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Adunay pipila ka mga butang nga `transmute` mao ang tinuod nga mapuslanon alang sa.
    ///
    /// Milingi sa usa ka pointer ngadto sa usa ka function pointer.Kini mao ang dili * portable sa makina diin function pointers ug data pointers adunay lain-laing gidak-on.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Pagpalugway sa usa ka tibuok kinabuhi, o pagpamubu sa usa ka invariant nga tibuok kinabuhi.Kini tigulang, kaayo luwas Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Dili ba katinoan: daghan gamit sa `transmute` mahimong makab-ot pinaagi sa uban nga mga paagi.
    /// Sa ubos mao ang komon nga mga aplikasyon sa `transmute` nga mahimong mapulihan sa mas luwas nga mga tagik.
    ///
    /// Pagbalhin sa hilaw nga bytes(`&[u8]`) ngadto sa `u32`, `f64`, ug uban pa.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // paggamit `u32::from_ne_bytes` sa baylo
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // o gamiton ang `u32::from_le_bytes` o `u32::from_be_bytes` aron matino ang katapusan
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Gihimo ang usa ka pointer ngadto sa usa ka `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Paggamit hinoon usa ka `as` cast sa baylo
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Milingi sa usa ka `*mut T` ngadto sa usa ka `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gamita ang usa ka reborrow sa baylo
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Milingi sa usa ka `&mut T` ngadto sa usa ka `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Karon, paghiusa sa `as` ug reborrowing, timan-i nga ang kadena sa `as` `as` dili transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Gihimo ang usa ka `&str` nga usa ka `&[u8]`:
    ///
    /// ```
    /// // kini dili mao ang usa ka maayo nga paagi sa pagbuhat niini.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Mahimo ka nga mogamit `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // O, gamit lang usa ka byte string, kung adunay ka kontrol sa literal nga pisi
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Milingi sa usa ka `Vec<&T>` ngadto sa usa ka `Vec<Option<&T>>`.
    ///
    /// Aron sa dalayegon sa sulod nga matang sa mga sulod sa usa ka sudlanan, kamo kinahanglan gayud nga sa pagsiguro nga dili makalapas sa bisan unsa sa invariants sa sudlanan sa.
    /// Kay `Vec`, kini paagi nga ang gidak-on ug pagpahiangay sa mga sulod nga matang nga pagpares.
    /// Ang uban pang mga sulud mahimong magsalig sa kadak-an sa tipo, paghanay, o bisan ang `TypeId`, diin ang pagdala dili mahimo nga wala`y paglapas sa mga invariant sa container.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone sa vector ingon sa atong magamit og usab sila sa ulahi
    /// let v_clone = v_orig.clone();
    ///
    /// // Pinaagi sa paggamit sa tamdon: kini nagsalig sa mga dili piho nga data Layout sa `Vec`, nga mao ang usa ka maayo nga ideya ug hinungdan sa dili tino ang Pamatasan.
    /////
    /// // Bisan pa, kini dili kopya.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Kini ang gisugyot, luwas nga paagi.
    /// // Kini ang pagkopya sa tibuok vector, bisan pa, ngadto sa usa ka bag-o nga gubat.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Kini mao ang husto nga walay-kopya, luwas nga paagi sa "transmuting" usa ka `Vec`, nga walay pagsalig sa layout data.
    /// // Inay sa literal pagtawag `transmute`, sa pagbuhat sa kita sa usa ka pointer cast, apan sa mga termino sa pagkabig sa mga orihinal nga sulod nga matang (`&i32`) sa bag-ong sa usa ka (`Option<&i32>`), kini ang tanan nga sa mao usab nga caveats.
    /////
    /// // Gawas pa sa impormasyon nga gihatag sa ibabaw, usab mokonsulta sa [`from_raw_parts`] dokumento.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME I-update kini kung ang stabil nga vector_into_raw_parts
    ///     // Pagsiguro nga ang mga orihinal vector wala nagpatulo.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Pagpatuman sa `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Daghang mga paagi aron mahimo kini, ug daghang mga problema sa mosunud nga (transmute) nga paagi.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // una: ang transmute dili klase nga luwas;ang tanan nga gisusi niini mao ang T ug
    ///         // U ang parehas nga kadako.
    ///         // Ikaduha, dinhi, ikaw ug duha ka mutable mga pakisayran nagtudlo ngadto sa mao gihapon nga handumanan.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Kini gets Isalikway sa mga problema nga matang sa kaluwasan;`&mut *` ang* lamang *sa paghatag kaninyo sa usa ka `&mut T` gikan sa usa ka `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Apan, ikaw gihapon sa duha ka mutable mga pakisayran nagtudlo ngadto sa mao gihapon nga handumanan.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ingon niini ang gihimo sa standard library.
    /// // Kini mao ang labing maayo nga pamaagi, kon kamo kinahanglan nga sa pagbuhat sa usa ka butang nga sama niini
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Kini karon adunay tulo ka mutable mga pakisayran nagtudlo sa sama nga handumanan.`slice`, ang rvalue ret.0, ug ang rvalue ret.1.
    ///         // `slice` wala gayud gigamit human `let ptr = ...`, ug sa ingon ang usa ka pagtagad niini ingon nga "dead", ug busa, kamo lang duha ka tinuod nga mutable hiwa.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Samtang kini naghimo sa nay const lig-on, kita adunay pipila ka mga batasan code sa const fn
    // mga tseke nga nagpugong sa paggamit niini sa sulud sa `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Mibalik `true` kon ang aktuwal nga matang gihatag ingon `T` nagkinahanglan drop papilit;mobalik `false` kon ang aktuwal nga matang nga gitagana alang sa `T` implementar `Copy`.
    ///
    ///
    /// Kon ang aktuwal nga matang dili nagkinahanglan drop papilit ni galamiton `Copy`, unya sa pagbalik bili sa niini nga function mao ang piho nga.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// NAGTINGUHA ang offset gikan sa usa ka pointer.
    ///
    /// Kini gipatuman ingon nga usa ka duna sa paglikay sa pagkabig sa ug gikan sa usa ka integer, sukad sa pagkakabig nga paglabay sa aliasing impormasyon.
    ///
    /// # Safety
    ///
    /// Parehas ang pagsugod ug sangputanan nga tudlo kinahanglan naa sa mga utlanan o us aka byte nga natapos sa katapusan sa usa ka gigahin nga butang.
    /// Kon bisan hain pointer gikan sa utlanan o aritmetik nagaawas mahitabo unya sa bisan unsa nga dugang nga paggamit sa mibalik bili moresulta sa dili tino ang kinaiya.
    ///
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Gikalkula ang offset gikan sa usa ka pointer, nga mahimo`g pambalot.
    ///
    /// Gipatuman kini ingon usa ka intrinsic aron malikayan ang pag-convert sa ug gikan sa usa ka integer, tungod kay ang pagkakabig nagpugong sa piho nga pag-optimize.
    ///
    /// # Safety
    ///
    /// Dili sama sa `offset` nay, kini nga duna dili mopugong sa mga resulta pointer sa punto ngadto sa o sa usa ka Byte nangagi sa katapusan sa usa ka gigahin nga butang, ug kini wraps sa duha ka ni katimbang aritmetik.
    /// Ang sangputanan nga kantidad dili kinahanglan nga balido aron magamit aron ma-access gyud ang memorya.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Katumbas sa angay nga `llvm.memcpy.p0i8.0i8.*` intrinsic, nga adunay gidak-on nga `count`*`size_of::<T>()` ug usa ka paghanay sa
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ang dali moalisngaw sukaranan gikatakda nga `true`, mao nga kini dili optimized sa gawas kon gidak-on mao nga sama sa zero.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Katumbas sa sa angay nga `llvm.memmove.p0i8.0i8.*` nay, uban sa usa ka gidak-on sa `count* size_of::<T>()` ug usa ka paglaray, pagtalay sa
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ang dali moalisngaw sukaranan gikatakda nga `true`, mao nga kini dili optimized sa gawas kon gidak-on mao nga sama sa zero.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Katumbas sa angay nga `llvm.memset.p0i8.*` intrinsic, nga adunay gidak-on nga `count* size_of::<T>()` ug usa ka paghanay sa `min_align_of::<T>()`.
    ///
    ///
    /// Ang dali moalisngaw sukaranan gikatakda nga `true`, mao nga kini dili optimized sa gawas kon gidak-on mao nga sama sa zero.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Naghimo usa ka pabag-o nga pagkarga gikan sa `src` pointer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Nagbuhat, naghimo sa usa ka dali moalisngaw tindahan sa `dst` pointer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Gihimo sa usa ka dali moalisngaw load gikan sa `src` pointer pointer Ang dili gikinahanglan nga ilaray.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Nagbuhat, naghimo sa usa ka dali moalisngaw tindahan sa `dst` pointer.
    /// Dili kinahanglan nga ipatudlo ang pointer.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Mibalik sa square gamut sa usa ka `f32`
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Mibalik sa square gamut sa usa ka `f64`
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ginbanhaw ang usa ka `f32` ngadto sa usa ka gahum sa integer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ginbanhaw ang usa ka `f64` ngadto sa usa ka gahum sa integer.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Gibalik ang sine sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Gibalik ang sine sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Gibalik ang cosine sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Gibalik ang cosine sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Nagtaas sa usa ka `f32` sa usa ka `f32` nga gahum.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Nagtaas sa usa ka `f64` sa usa ka `f64` nga gahum.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Mibalik ang exponential sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Gibalik ang exponential sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Mibalik 2 gibanhaw sa gahom sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Gibalik ang 2 nga gipataas sa gahum sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Gibalik ang natural nga logarithm sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Mibalik ang natural nga logarítmo sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Mibalik sa base 10 logarítmo sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Mibalik sa base 10 logarítmo sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Mibalik sa base 2 logarítmo sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Gibalik ang base 2 logarithm sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Gibalik ang `a * b + c` alang sa mga kantidad nga `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Gibalik ang `a * b + c` alang sa mga kantidad nga `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Gibalik ang hingpit nga kantidad sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Mibalik ang bug-os nga bili sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Mibalik sa minimum sa duha ka mga mithi `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Mibalik sa minimum sa duha ka mga mithi `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Gibalik ang maximum nga duha nga kantidad nga `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Mibalik sa maximum sa duha ka mga mithi `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Gikopya ang timaan gikan sa `y` hangtod `x` alang sa mga kantidad nga `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Mga kopya ang ilhanan gikan sa `y` ngadto sa `x` alang sa `f64` mga prinsipyo.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Mobalik ang kinadak-ang integer ubos pa kay sa o itanding sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Gibalik ang labing kadaghan nga integer nga mas mubu o katumbas sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Gibalik ang labing gamay nga integer nga labi sa o katumbas sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Gibalik ang labing gamay nga integer nga labi sa o katumbas sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Gibalik ang bahin sa integer sa usa ka `f32`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Mibalik ang integer bahin sa usa ka `f64`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Gibalik ang pinakaduol nga integer sa usa ka `f32`.
    /// Hinaot nga pagpataas sa usa ka eksakto naglutaw-point gawas kon ang argumento mao ang dili usa ka integer.
    pub fn rintf32(x: f32) -> f32;
    /// Mibalik ang labing duol nga integer sa usa ka `f64`.
    /// Hinaot nga pagpataas sa usa ka eksakto naglutaw-point gawas kon ang argumento mao ang dili usa ka integer.
    pub fn rintf64(x: f64) -> f64;

    /// Gibalik ang pinakaduol nga integer sa usa ka `f32`.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Mibalik ang labing duol nga integer sa usa ka `f64`.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Mibalik ang labing duol nga integer sa usa ka `f32`.Rounds katunga-nga-dalan sa mga kaso gikan sa zero.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Mibalik ang labing duol nga integer sa usa ka `f64`.Nagtuyok nga mga half-way nga mga kaso nga layo sa zero.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float Dugang pa nga nagtugot optimizations base sa algebraic lagda.
    /// Mahimo maghunahuna nga ang mga input adunay katapusan.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Pagkuha sa float nga nagtugot sa mga pag-optimize nga nakabase sa mga lagda sa algebraic.
    /// Mahimo maghunahuna nga ang mga input adunay katapusan.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float multiplication nga nagtugot sa mga pag-optimize nga nakabase sa mga lagda sa algebraic.
    /// Mahimo maghunahuna nga ang mga input adunay katapusan.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float division nga nagtugot optimizations base sa algebraic lagda.
    /// Mahimo maghunahuna nga ang mga input adunay katapusan.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ang nahabilin nga float nga nagtugot sa mga pag-optimize pinauyon sa mga lagda sa algebraic.
    /// Mahimo maghunahuna nga ang mga input adunay katapusan.
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Kinabig ni LLVM fptoui/fptosi, nga mahimo nga mobalik undef alang sa mga prinsipyo gikan sa laing
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Molig-on nga ingon sa [`f32::to_int_unchecked`] ug [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Gibalik ang numero sa mga tipik nga gibutang sa usa ka integer type `T`
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `count_ones` pamaagi.
    /// Pananglitan,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Mibalik ang gidaghanon sa mga nag-unang unset tipik (zeroes) sa usa ka matang integer `T`.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `leading_zeros` pamaagi.
    /// Pananglitan,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Usa ka `x` uban sa bili `0` mobalik sa gamay gilapdon sa `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Sama `ctlz`, apan dugang nga-luwas ingon nga kini mobalik `undef` sa diha nga gihatag sa usa ka `x` sa bili `0`.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Mibalik ang gidaghanon sa mga banas unset tipik (zeroes) sa usa ka matang integer `T`.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `trailing_zeros` pamaagi.
    /// Pananglitan,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Usa ka `x` uban sa bili `0` mobalik sa gamay gilapdon sa `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Sama sa `cttz`, apan labi ka dili luwas sa pagbalik sa `undef` kung hatagan usa ka `x` nga adunay kantidad `0`.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Gibag-o ang mga byte sa usa ka integer type `T`.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `swap_bytes` pamaagi.
    /// Pananglitan,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Gibali ang mga tipik sa usa ka matang integer `T`.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `reverse_bits` pamaagi.
    /// Pananglitan,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Gihimo sa gitan-aw integer Dugang pa.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `overflowing_add` pamaagi.
    /// Pananglitan,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Gihimo gisusi integer pagkuha
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `overflowing_sub` pamaagi.
    /// Pananglitan,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Gihimo gisusi integer multiplication
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `overflowing_mul` pamaagi.
    /// Pananglitan,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Naghimo usa ka ensakto nga pagkabahin, nga nagresulta sa wala matino nga kinaiya diin ang `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Nagbuhat, naghimo sa usa ka dili mapugngan division, nga miresulta sa dili tino ang kinaiya diin `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Luwas putos alang sa duna nga kini anaa sa ibabaw sa mga primitives integer pinaagi sa `checked_div` pamaagi.
    /// Pananglitan,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Mibalik sa nahibilin sa usa ka dili mapugngan division, nga miresulta sa dili tino ang kinaiya sa diha nga `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Luwas putos alang sa duna nga kini anaa sa ibabaw sa mga primitives integer pinaagi sa `checked_rem` pamaagi.
    /// Pananglitan,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Gihimo sa usa ka dili mapugngan nga wala pagbalhin, nga miresulta sa dili tino ang kinaiya sa diha nga `y < 0` o `y >= N`, diin A mao ang gilapdon sa T sa mga tipik.
    ///
    ///
    /// Luwas putos alang sa duna nga kini anaa sa ibabaw sa mga primitives integer pinaagi sa `checked_shl` pamaagi.
    /// Pananglitan,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Gihimo sa usa ka dili mapugngan nga too pagbalhin, nga miresulta sa dili tino ang kinaiya sa diha nga `y < 0` o `y >= N`, diin A mao ang gilapdon sa T sa mga tipik.
    ///
    ///
    /// Luwas putos alang sa duna nga kini anaa sa ibabaw sa mga primitives integer pinaagi sa `checked_shr` pamaagi.
    /// Pananglitan,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Mibalik ang resulta sa usa ka dili mapugngan Dugang pa, nga miresulta sa dili tino ang kinaiya sa diha nga `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Mibalik ang resulta sa usa ka dili mapugngan pagkuha, nga miresulta sa dili tino ang kinaiya sa diha nga `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Gibalik ang sangputanan sa usa ka wala masusi nga pagdaghan, nga miresulta sa dili matino nga pamatasan kung `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// sulod Kini nga wala sa usa ka lig-on nga counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Gihimo sa tuyok sa wala.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `rotate_left` pamaagi.
    /// Pananglitan,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Naghimo og tuyok tuyok.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `rotate_right` pamaagi.
    /// Pananglitan,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Mobalik (a + b) mod 2 <sup>N</sup>, diin ang N ang gilapdon sa T sa mga bits.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `wrapping_add` pamaagi.
    /// Pananglitan,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Mobalik (a, b) mod 2 <sup>A,</sup> diin A mao ang gilapdon sa T sa mga tipik.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `wrapping_sub` pamaagi.
    /// Pananglitan,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Mobalik (a * b) mod 2 <sup>N</sup>, diin ang N ang gilapdon sa T sa mga bits.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `wrapping_mul` pamaagi.
    /// Pananglitan,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Gikalkulo ang `a + b`, nakapabusog sa mga utlanan sa numero.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `saturating_add` pamaagi.
    /// Pananglitan,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Kwentahon `a - b`, matumog sa numerawo utlanan.
    ///
    /// Ang normal nga bersyon sa duna nga niini anaa sa ibabaw sa mga primitives integer pinaagi sa `saturating_sub` pamaagi.
    /// Pananglitan,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Gibalik ang kantidad sa diskriminante alang sa variant sa 'v';
    /// kon `T` walay discriminant, mobalik `0`.
    ///
    /// Ang normal nga bersyon sa duna nga kini mao ang [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Pagbalik sa gidaghanon sa mga variants sa matang `T` gitambog ngadto sa usa ka `usize`;
    /// kon `T` walay variants, mobalik `0`.Walay nagpuyo variants ang pagaisipon.
    ///
    /// Ang kinahanglan nga mapalig-on nga bersyon sa kini nga intrinsic mao ang [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Ang Rust's "try catch" konstruksyon nga nagsangpit sa function pointer `try_fn` nga adunay data pointer `data`.
    ///
    /// Ang ikatulo nga lantugi usa ka katungdanan nga gitawag kung adunay usa ka panic nga mahitabo.
    /// Ang kini nga pag-andar nagdala sa data pointer ug usa ka pointer sa target-piho nga butang nga eksepsyon nga nadakup.
    ///
    /// Alang sa dugang impormasyon tan-awa tinubdan sa tighipos sa ingon man sa isda pagpatuman ni std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Mopatugbaw sa usa ka tindahan `!nontemporal` sumala sa LLVM (tan-awa sa ilang mga docs).
    /// Lagmit dili gayud mahimong lig-on.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tan-awa ang dokumentasyon sa `<*const T>::offset_from` alang sa mga detalye.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tan-awa ang dokumentasyon sa `<*const T>::guaranteed_eq` alang sa mga detalye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tan-awa ang dokumentasyon sa `<*const T>::guaranteed_ne` alang sa mga detalye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Paghatag sa oras sa pagtipon.Dili ba nga gitawag sa Runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ang ubang mga gimbuhaton nga gihubit dinhi tungod kay sila aksidenteng na nga anaa sa module niini sa lig-on.
// Kitaa ang <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` usab mahulog ngadto sa kategoriya niini, apan dili kini mahimong giputos tungod sa tseke nga `T` ug `U` makabaton sa sama nga gidak-on.)
//

/// Checks kon `ptr` hustong ilaray uban sa pagtahod ngadto sa `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopya `count *size_of::<T>()` bytes gikan sa `src` ngadto sa `dst`.Ang tinubdan ug destinasyon kinahanglan dili* sapaw.
///
/// Kay rehiyon sa handumanan nga mahimo sapaw, sa paggamit sa [`copy`] sa baylo.
///
/// `copy_nonoverlapping` katumbas sa semantikal sa X's [`memcpy`], apan gipalit ang order sa argumento.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `src` kinahanglan [valid] alang sa mabasa sa `count * size_of::<T>()` bytes.
///
/// * `dst` kinahanglan [valid] alang sa pagsulat sa `count * size_of::<T>()` bytes.
///
/// * Ang parehas nga `src` ug `dst` kinahanglan nga husto nga pagkahan-ay.
///
/// * Ang rehiyon sa handumanan sugod sa `src` uban sa usa ka gidak-on sa `-isip *
///   size_of: :<T>() `Bytes kinahanglan dili * sapaw sa rehiyon sa handumanan sugod sa `dst` uban sa sama nga gidak-on.
///
/// Sama sa [`read`], ang `copy_nonoverlapping` nagmugna usa ka gamay nga kopya sa `T`, dili igsapayan kung ang `T` mao ang [`Copy`].
/// Kung ang `T` dili [`Copy`], nga gigamit *pareho* ang mga kantidad sa rehiyon nga nagsugod sa `*src` ug ang rehiyon nga magsugod sa `* dst` mahimo nga [violate memory safety][read-ownership].
///
///
/// Mubo nga sulat nga bisan kon ang mga epektibo nga gikopya gidak-on (`-isip * size_of: :<T>Ang ()`) mao ang `0`, ang mga panudlo kinahanglan dili NUL ug husto nga nakahanay.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Sa kamut pagpatuman [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Gibalhin ang tanan nga mga elemento sa `src` sa `dst`, gibiyaan nga wala`y sulod ang `src`.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Siguroha nga `dst` adunay igo nga kapasidad sa paghupot sa tanan nga mga `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ang tawag sa offset mao ang kanunay nga luwas tungod kay `Vec` dili mogahin labaw pa kay sa `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` walay pagtulo mga sulod niini.
///         // Gihimo namon kini una, aron malikayan ang mga problema kung adunay us aka butang nga labi ka ubos sa panics.
///         src.set_len(0);
///
///         // Ang duha ka mga rehiyon dili sapaw tungod kay mutable mga pakisayran sa pagbuhat sa dili alyas, ug duha ka lain-laing mga vectors dili iya sa sama nga handumanan.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Gipahibalo ang `dst` nga karon gikuptan ang mga sulud sa `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Buhata kini nga mga tseke sa oras lang sa pagdagan
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Dili pag-panic aron magpadayon nga gamay ang epekto sa codegen.
        abort();
    }*/

    // SAFETY: ang kaluwasan kontrata alang sa `copy_nonoverlapping` kinahanglan
    // gituboy pinaagi sa caller.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Gikopya ang `count * size_of::<T>()` bytes gikan sa `src` hangtod `dst`.Ang tinubdan ug padulnganan mahimong magsapaw.
///
/// Kon ang tinubdan ug destinasyon *dili* sapaw, [`copy_nonoverlapping`] mahimong gamiton sa baylo.
///
/// `copy` katumbas sa semantikal sa X's [`memmove`], apan gipalit ang order sa argumento.
/// Pagkopya mahitabo ingon nga kon ang mga bytes gikopya gikan sa `src` ngadto sa usa ka temporaryo nga gubat ug unya gikopya gikan sa gubat ngadto sa `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `src` kinahanglan [valid] alang sa mabasa sa `count * size_of::<T>()` bytes.
///
/// * `dst` kinahanglan [valid] alang sa pagsulat sa `count * size_of::<T>()` bytes.
///
/// * Ang parehas nga `src` ug `dst` kinahanglan nga husto nga pagkahan-ay.
///
/// Sama sa [`read`], ang `copy` nagmugna usa ka gamay nga kopya sa `T`, dili igsapayan kung ang `T` mao ang [`Copy`].
/// Kon `T` dili [`Copy`], sa paggamit sa duha sa mga mithi sa rehiyon sugod sa `*src` ug sa rehiyon sugod sa `* dst` mahimo [violate memory safety][read-ownership].
///
///
/// Mubo nga sulat nga bisan kon ang mga epektibo nga gikopya gidak-on (`-isip * size_of: :<T>Ang ()`) mao ang `0`, ang mga panudlo kinahanglan dili NUL ug husto nga nakahanay.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Maayo nga paghimo usa ka Rust vector gikan sa usa ka dili luwas nga buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` kinahanglan nga husto nga pagkahan-ay alang sa iyang tipo ug dili zero.
/// /// * `ptr` kinahanglan nga balido alang sa mabasa sa `elts` nagkasikbit nga mga elemento sa matang `T`.
/// /// * Kadtong mga elemento kinahanglan dili gamiton human sa pagtawag niini nga function gawas kon `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: Ang atong pauna nga kundisyon nagsiguro sa tinubdan nga ilaray ug balido,
///     // ug `Vec::with_capacity` nagsiguro nga kita magamit nga luna sa pagsulat kanila.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: gilalang kami niini uban sa niini nga daghan nga kapasidad sa sayo pa,
///     // ug ang miaging `copy` gisugdan ang kini nga mga elemento.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Buhata kini nga mga tseke sa oras lang sa pagdagan
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Dili pag-panic aron magpadayon nga gamay ang epekto sa codegen.
        abort();
    }*/

    // SAFETY: ang kaluwasan kontrata alang sa `copy` kinahanglan gituboy pinaagi sa caller.
    unsafe { copy(src, dst, count) }
}

/// Sets `count * size_of::<T>()` bytes sa handumanan sugod sa `dst` sa `val`.
///
/// `write_bytes` parehas sa C's [`memset`], apan gitakda ang `count * size_of::<T>()` bytes sa `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `dst` kinahanglan [valid] alang sa pagsulat sa `count * size_of::<T>()` bytes.
///
/// * `dst` kinahanglan nga sa tukmang paagi ilaray.
///
/// Ingon kadugangan, kinahanglan nga sigurohon sa nanawag nga ang pagsulat sa `count * size_of::<T>()` bytes sa gihatag nga rehiyon nga panumduman moresulta sa usa ka balido nga kantidad nga `T`.
/// Ang paggamit sa usa ka rehiyon sa panumduman nga gi-type ingon usa ka `T` nga adunay sulud nga dili balido nga kantidad nga `T` dili matino nga pamatasan.
///
/// Mubo nga sulat nga bisan kon ang mga epektibo nga gikopya gidak-on (`-isip * size_of: :<T>()`) Mao `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Pagmugna sa usa ka imbalido bili:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Hungaw ang kaniadto nga gihimo bili pinaagi sa pagpuli sa `Box<T>` uban sa usa ka bili pointer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Niini nga punto, ang paggamit o paghulog sa `v` moresulta sa dili matino nga pamatasan.
/// // drop(v); // ERROR
///
/// // Bisan ang pagtulo sa `v` "uses" niini, ug busa wala matino ang pamatasan.
/// // mem::forget(v); // ERROR
///
/// // Sa tinuud, ang `v` dili balido pinauyon sa sukaranan nga tipo nga mga imbitasyon sa layout, busa ang * bisan unsang operasyon nga paghikap niini dili matino nga kinaiya.
/////
/// // pasagdi ang v2 =v;//SAYOP
///
/// unsafe {
///     // Atong inay gibutang sa usa ka balido nga bili
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Karon ang kahon mao ang lino nga fino nga
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KALUWASAN: ang kontrata sa kahilwasan alang sa `write_bytes` kinahanglan nga ipadayon sa nanawag.
    unsafe { write_bytes(dst, val, count) }
}