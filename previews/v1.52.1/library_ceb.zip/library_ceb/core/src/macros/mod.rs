#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Ekspan sa bisan `$crate::panic::panic_2015` o `$crate::panic::panic_2021` depende sa edisyon sa caller.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Gipahayag nga ang duha nga ekspresyon parehas sa matag usa (gamit ang [`PartialEq`]).
///
/// Sa panic, kini nga macro nga imprinta sa mga mithi sa mga ekspresyon sa ilang debug mga larawan.
///
///
/// Sama [`assert!`], kini nga macro nga adunay usa ka ikaduha nga porma, diin ang usa ka batasan panic mensahe mahimong gihatag.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Tuyo ang mga reborrow sa ubus.
                    // Kon wala kanila, ang pundok luna alang sa makahulam ang initialized bisan sa wala pa ang mga prinsipyo gitandi, padulong ngadto sa usa ka mamatikdan hinay sa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Tuyo ang mga reborrow sa ubus.
                    // Kon wala kanila, ang pundok luna alang sa makahulam ang initialized bisan sa wala pa ang mga prinsipyo gitandi, padulong ngadto sa usa ka mamatikdan hinay sa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Nagpahayag nga ang duha ka mga ekspresyon dili managsama sa usag usa (sa paggamit sa [`PartialEq`]).
///
/// Sa panic, kini nga macro nga imprinta sa mga mithi sa mga ekspresyon sa ilang debug mga larawan.
///
///
/// Sama [`assert!`], kini nga macro nga adunay usa ka ikaduha nga porma, diin ang usa ka batasan panic mensahe mahimong gihatag.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Tuyo ang mga reborrow sa ubus.
                    // Kon wala kanila, ang pundok luna alang sa makahulam ang initialized bisan sa wala pa ang mga prinsipyo gitandi, padulong ngadto sa usa ka mamatikdan hinay sa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Tuyo ang mga reborrow sa ubus.
                    // Kon wala kanila, ang pundok luna alang sa makahulam ang initialized bisan sa wala pa ang mga prinsipyo gitandi, padulong ngadto sa usa ka mamatikdan hinay sa.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Nagpahayag nga ang usa ka boolean ekspresyon mao ang `true` sa Runtime.
///
/// Ipatawag kini ang [`panic!`] macro kung ang gihatag nga ekspresyon dili masusi sa `true` sa oras nga mag-runtime.
///
/// Sama [`assert!`], kini nga macro adunay usab ang usa ka ikaduha nga bersyon, diin ang usa ka batasan panic mensahe mahimong gihatag.
///
/// # Uses
///
/// Dili sama sa [`assert!`], `debug_assert!` mga pahayag makahimo lamang sa non optimized nagtukod pinaagi sa default.
/// Usa ka optimized build dili ipakanaug `debug_assert!` mga pahayag gawas kon `-C debug-assertions` miagi sa tighipos.
/// Kini naghimo sa `debug_assert!` mapuslanon alang sa mga tseke nga mahal kaayo nga maanaa sa usa ka release build apan mahimong makatabang sa panahon sa kalamboan.
/// Ang resulta sa sa pagpuno `debug_assert!` kanunay matang gitan-aw.
///
/// Usa ka dili mapugngan pangangkon nagtugot sa usa ka programa sa usa ka sukwahi nga kahimtang sa pagbantay sa nagdagan, nga unta adunay wala damha nga mga sangputanan apan wala ipaila unsafety samtang nga kini lamang ang mahitabo sa luwas nga code.
///
/// Ang performance gasto sa mga pangangkon, Apan, dili masukod sa kinatibuk-.
/// Ilis [`assert!`] uban sa `debug_assert!` ang sa ingon lamang gidasig human sa bug-os nga profiling, ug labaw sa tanan, lamang diha sa luwas nga code!
///
/// # Examples
///
/// ```
/// // ang panic mensahe alang niini nga mga assertions mao ang stringified bili sa ekspresyon nga gihatag.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // usa ka yano kaayo nga function
/// debug_assert!(some_expensive_computation());
///
/// // ihingusog uban sa usa ka batasan nga mensahe
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Nagpahayag nga ang duha ka mga ekspresyon nga sama sa usag usa.
///
/// Sa panic, kini nga macro nga imprinta sa mga mithi sa mga ekspresyon sa ilang debug mga larawan.
///
/// Dili sama sa [`assert_eq!`], `debug_assert_eq!` mga pahayag makahimo lamang sa non optimized nagtukod pinaagi sa default.
/// Ang usa ka na-optimize nga pagtukod dili magpatuman sa mga pahayag sa `debug_assert_eq!` gawas kung ang `-C debug-assertions` gipasa sa tagtipon.
/// Kini naghimo sa `debug_assert_eq!` mapuslanon alang sa mga tseke nga mahal kaayo nga maanaa sa usa ka release build apan mahimong makatabang sa panahon sa kalamboan.
///
/// Ang sangputanan sa pagpalapad sa `debug_assert_eq!` kanunay nga tipo nga gisusi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Nagpahayag nga ang duha ka mga ekspresyon dili managsama sa usag usa.
///
/// Sa panic, kini nga macro nga imprinta sa mga mithi sa mga ekspresyon sa ilang debug mga larawan.
///
/// Dili sama sa [`assert_ne!`], ang mga pahayag sa `debug_assert_ne!` gipaandar lang sa dili na-optimize nga pagtukod pinaagi sa default.
/// Ang usa ka na-optimize nga pagtukod dili magpatuman sa mga pahayag sa `debug_assert_ne!` gawas kung ang `-C debug-assertions` gipasa sa tagtipon.
/// Kini naghimo sa `debug_assert_ne!` mapuslanon alang sa mga tseke nga mahal kaayo nga maanaa sa usa ka release build apan mahimong makatabang sa panahon sa kalamboan.
///
/// Ang resulta sa sa pagpuno `debug_assert_ne!` kanunay matang gitan-aw.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Mobalik kon ang gihatag nga ekspresyon motakdo sa bisan unsa sa mga gihatag nga mga sumbanan.
///
/// Sama sa usa ka `match` ekspresyon, ang sumbanan mahimong optionally gisundan sa `if` ug sa usa ka magbalantay nga pulong nga adunay access sa mga ngalan nga ginapus sa sumbanan.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps sa usa ka resulta o pagpakatap sayop niini.
///
/// Ang `?` operator gidugang sa pag-ilis `try!` ug kinahanglan nga gamiton sa baylo.
/// Dugang pa, `try` mao ang usa ka gitagana pulong sa Rust 2018, mao nga kon kamo kinahanglan gayud nga sa paggamit niini, ikaw kinahanglan nga gamiton ang [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` motakdo sa gihatag [`Result`].Sa kaso sa mga `Ok` laing, ang ekspresyon ang bili sa mga giputos nga bili.
///
/// Sa kaso sa mga `Err` laing, kini retrieves sa sulod nga sayop.`try!` unya naghimo pagkakabig sa paggamit `From`.
/// Naghatag kini awtomatikong pagkakabig taliwala sa mga espesyalista nga sayup ug labi kadaghan nga mga sayup.
/// Ang resulta sayop Unya diha-diha dayon mibalik.
///
/// Tungod sa sayo nga pagbalik, mahimo magamit ang `try!` sa mga pag-andar nga ibalik ang [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Ang gusto nga pamaagi sa dali pagbalik Kasaypanan
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Ang miaging pamaagi sa dali nga pagbalik sa mga Sayup
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Kini mao ang katumbas sa:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Misulat ay data ngadto sa usa ka buffer.
///
/// Ang kini nga macro nagdawat usa ka 'writer', usa ka format string, ug usa ka lista sa mga argumento.
/// Ang mga pangatarungan ma-format sumala sa gipiho nga pormat nga pormat ug ang sangputanan igapasa sa magsusulat.
/// Ang magsusulat mahimong bisan unsa nga bili sa usa ka `write_fmt` pamaagi;sa kinatibuk kini moabut gikan sa usa ka pagpatuman sa bisan hain sa [`fmt::Write`] o sa [`io::Write`] trait.
/// Ang macro mobalik sa bisan unsa nga sa `write_fmt` pamaagi mobalik;kasagaran usa ka [`fmt::Result`], o usa ka [`io::Result`].
///
/// Tan-awa ang [`std::fmt`] alang sa dugang nga kasayuran bahin sa format string syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Ang usa ka module mahimong maka-import sa parehas nga `std::fmt::Write` ug `std::io::Write` ug tawagan ang `write!` sa mga butang nga nagpatuman bisan kinsa, tungod kay ang mga butang dili sagad nga ipatuman pareho.
///
/// Apan, ang module kinahanglan import sa traits kwalipikado aron ang ilang mga ngalan sa pagbuhat sa dili panagbangi:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // naggamit fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // naggamit io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: macro Kini nga gigamit sa `no_std` setups ingon man.
/// Sa usa ka `no_std` setup mao ang responsable alang sa mga detalye pagpatuman sa mga sangkap kaninyo.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Isulat ay data ngadto sa usa ka buffer, uban sa usa ka newline nagdugang.
///
/// Sa tanan nga mga platform, ang newline mao ang PAGTULUN bahog kinaiya (`\n`/`U+000A`) lamang (walay dugang nga karwahe MOBALIK (`\r`/`U+000D`).
///
/// Alang sa dugang nga impormasyon, tan-awa ang [`write!`].Alang sa impormasyon diha sa format hilo syntax, tan-awa ang [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Ang usa ka module mahimong maka-import sa parehas nga `std::fmt::Write` ug `std::io::Write` ug tawagan ang `write!` sa mga butang nga nagpatuman bisan kinsa, tungod kay ang mga butang dili sagad nga ipatuman pareho.
/// Apan, ang module kinahanglan import sa traits kwalipikado aron ang ilang mga ngalan sa pagbuhat sa dili panagbangi:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // naggamit fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // naggamit io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Gipasabut ang dili maabut nga code.
///
/// Kini mao ang mapuslanon sa bisan unsa nga panahon nga ang tighipos dili pagtino nga ang pipila code mao ang makab-ot.Pananglitan:
///
/// * Ipares ang mga bukton sa mga kahimtang sa mga bantay.
/// * Galong nga maabtikon undang.
/// * Mga Iterator nga dinamiko natapos.
///
/// Kung ang pagpiho nga ang code dili maabut mapamatud-an nga sayup, ang programa dayon matapos sa usa ka [`panic!`].
///
/// Ang luwas counterpart sa macro kini mao ang [`unreachable_unchecked`] function, nga hinungdan sa dili tino ang kinaiya kon ang code ang nakaabot.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Kanunay kini nga [`panic!`].
///
/// # Examples
///
/// Pagpares bukton:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // pagtapok sayup kung gikomentaryo
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // sa usa sa mga labing kabus implementar sa x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Nagpakita unimplemented code pinaagi sa nataranta nga uban sa usa ka mensahe sa "not implemented".
///
/// nagtugot kini sa imong code sa matang-check, nga mao ang mapuslanon kon kamo prototyping o pagpatuman sa usa ka trait nga nagkinahanglan daghang mga pamaagi nga dili kamo plano sa paggamit sa tanan.
///
/// Ang kalainan tali sa `unimplemented!` ug [`todo!`] mao nga samtang `todo!` nagpasabot sa usa ka katuyoan sa pagpatuman sa kagamitan, katuyoan sa ulahi ug ang mensahe mao ang "not yet implemented", `unimplemented!` wala maong mga pangangkon.
/// Ang mensahe niini mao ang "not implemented".
/// Usab sa pipila IDEs magtimaan `todo!` S.
///
/// # Panics
///
/// Kanunay kini nga [`panic!`] tungod kay ang `unimplemented!` usa ka laktod ra nga bayad alang sa `panic!` nga adunay usa ka pirmi, piho nga mensahe.
///
/// Sama sa `panic!`, kini nga macro adunay ikaduha nga porma alang sa pagpakita sa gipasadya nga mga kantidad.
///
/// # Examples
///
/// Isulti kita adunay usa ka trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Gusto namo nga sa pagpatuman sa `Foo` alang sa 'MyStruct', apan sa pipila ka rason lamang kini makahimo sa pagbati aron sa pagpatuman sa `bar()` function.
/// `baz()` ug `qux()` pa kinahanglan nga gihubit diha sa atong pagpatuman sa `Foo`, apan kita sa paggamit sa `unimplemented!` sa ilang mga kahulugan sa pagtugot sa atong code sa pagtipon.
///
/// Kita gusto sa gihapon nga ang atong programa sa stop running kon ang unimplemented pamaagi-ot.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Kini naghimo sa wala may salabutan sa `baz` sa usa ka `MyStruct`, mao nga kita dili katarungan dinhi sa tanan.
/////
///         // Kini ipakita "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Kita adunay pipila ka mga katarungan dinhi, Kita makadugang sa usa ka mensahe ngadto sa unimplemented!aron mapakita ang among pagkulang.
///         // Kini ipakita: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Nagpaila wala mahuman code.
///
/// Kini mahimong mapuslanon kon ikaw prototyping ug lang sa pagtan-aw aron ang imong code typecheck.
///
/// Ang kalainan tali sa [`unimplemented!`] ug `todo!` mao nga samtang `todo!` nagpasabot sa usa ka katuyoan sa pagpatuman sa kagamitan, katuyoan sa ulahi ug ang mensahe mao ang "not yet implemented", `unimplemented!` wala maong mga pangangkon.
/// Ang mensahe niini mao ang "not implemented".
/// Usab sa pipila IDEs magtimaan `todo!` S.
///
/// # Panics
///
/// Kanunay kini nga [`panic!`].
///
/// # Examples
///
/// Ania ang usa ka panig-ingnan sa pipila sa-pag-uswag code.Kita adunay usa ka trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Gusto namo nga sa pagpatuman `Foo` sa usa sa atong mga matang, apan kita usab gusto nga buhat sa matarung `bar()` una.Aron alang sa atong code sa pagtipon, kita kinahanglan sa pagpatuman sa `baz()`, aron kita sa paggamit sa `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // pagpatuman moadto dinhi
///     }
///
///     fn baz(&self) {
///         // dili kita mabalaka bahin sa pagpatuman sa baz() sa karon
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // wala man kami naggamit baz(), busa kini maayo ra.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Mga kahulugan sa mga built-in nga macros.
///
/// Kadaghanan sa mga macro kabtangan (kalig-on, visibility, ug uban pa) gikuha gikan sa source code dinhi, uban sa gawas sa pagpalapad gimbuhaton pag-usab sa macro inputs ngadto sa outputs, ang mga gimbuhaton nga gihatag sa tighipos.
///
///
pub(crate) mod builtin {

    /// Hinungdan nga mapakyas ang panagsama sa gihatag nga mensahe sa sayup kung makit-an.
    ///
    /// macro Kini kinahanglan nga gamiton sa diha nga ang usa ka crate gigamit sa usa ka conditional hinugpong nga pamaagi sa paghatag og mas maayo nga mga mensahe sayop alang sa sayop nga mga kahimtang.
    ///
    /// Kini ang tighipos-level nga porma sa [`panic!`], apan nagpasabwag usa ka sayop sa panahon sa *hinugpong* kay sa sa *Runtime.*
    ///
    /// # Examples
    ///
    /// Duha ka sa maong mga panig-ingnan mao ang mga macros ug `#[cfg]` mga dapit.
    ///
    /// Emit mas maayo nga tighipos sayop kon ang usa ka macro miagi walay pulos nga mga prinsipyo.
    /// Kon wala ang katapusan nga branch, ang tighipos gihapon emit sa usa ka sayop, apan ang mensahe sa sayop ni dili naghisgot sa duha ka balido nga mga prinsipyo.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit tighipos sayop kon ang usa sa usa ka gidaghanon sa mga bahin dili anaa.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nagtukod lantugi alang sa uban nga mga hilo-formatting macros.
    ///
    /// Kini nga macro gimbuhaton pinaagi sa pagkuha sa usa ka formatting hilo literal nga adunay sulod nga `{}` alang sa matag dugang nga argumento milabay.
    /// `format_args!` andam sa dugang nga lantugi aron sa pagsiguro sa output mahimong hubaron sama sa usa ka hilo ug canonicalizes sa mga argumento ngadto sa usa ka ka matang.
    /// Ang bisan unsang kantidad nga nagpatuman sa [`Display`] trait mahimong maipasa sa `format_args!`, maingon nga ang bisan unsang pagpatuman sa [`Debug`] ipasa sa usa ka `{:?}` sulud sa formatting string.
    ///
    ///
    /// macro Kini nga og sa usa ka bili sa matang [`fmt::Arguments`].bili Kini nga milabay sa mga macros sulod sa [`std::fmt`] alang sa pagbuhat sa mapuslanon redirection.
    /// Ang tanan nga lain nga mga formatting macros ([`format!`], [`write!`], [`println!`], etc) ang proxied pinaagi sa usa ka niini.
    /// `format_args!`, dili sama sa nakuha sa iyang mga macros, molikay sa magapundok alokasyon.
    ///
    /// Inyong magamit sa [`fmt::Arguments`] bili nga `format_args!` mobalik sa `Debug` ug `Display` konteksto sama sa nakita sa ubos.
    /// Ang panig-ingnan usab sa nagpakita nga `Debug` ug `Display` format sa sama nga butang: ang gidugang format hilo sa `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Alang sa dugang nga impormasyon, tan-awa ang mga dokumento sa [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama sa `format_args`, apan midugang ang usa ka newline sa katapusan.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Gisusi ang us aka variable sa palibot sa oras nga pagtipon.
    ///
    /// Ang kini nga macro molapad sa kantidad sa gihinganlan nga variable sa palibot sa oras nga pagtipon, nga naghatag usa ka ekspresyon sa tipo `&'static str`.
    ///
    ///
    /// Kon ang palibot baryable dili gihubit, nan, ang usa ka hinugpong nga sayop nga mibuga.
    /// Aron dili makapagawas usa ka sayup nga pag-ipon, gamiton hinoon ang [`option_env!`] macro.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ikaw mahimo ipahiangay sa mensahe sa sayop pinaagi sa agi sa usa ka hilo nga ingon sa ikaduha nga sukaranan:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Kung ang `documentation` environment variable dili gihubit, makuha nimo ang mosunud nga sayup:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally nagsusi usa ka palibot baryable sa pagtipon panahon.
    ///
    /// Kon ang ginganlan si palibot baryable mao ang karon sa pagtipon sa panahon, kini sa pagpalapad sa sa usa ka pagpahayag sa matang `Option<&'static str>` kansang bili mao `Some` sa bili sa palibot baryable.
    /// Kung wala ang variable sa kalikopan, kung ingon niini mapadako ang hangtod sa `None`.
    /// Tan-awa ang [`Option<T>`][Option] alang sa dugang nga impormasyon sa niini nga matang.
    ///
    /// Usa ka pagtipon sa panahon sa sayop nga wala gayud mibuga diha nga ang paggamit niini nga macro sa walay pagtagad sa kon sa palibot baryable mao karon o dili.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates ilhanan ngadto sa usa ka ilhanan.
    ///
    /// macro Kini nagkinahanglan og bisan unsa nga gidaghanon sa mga comma-mibulag ilhanan, ug concatenates kanila sa tanan ngadto sa usa, nga nagahatag sa usa ka ekspresyon nga mao ang usa ka bag-o nga ilhanan.
    /// Matikdi nga hygiene kini sa ingon nga kini nga macro dili pagdakop sa lokal nga baryable.
    /// Usab, ingon sa usa ka kinatibuk-ang pagmando sa, macros ang gitugotan lamang sa butang, pamahayag o ekspresyon posisyon.
    /// Nga paagi samtang ikaw mahimo nga mogamit niini nga macro alang sa nga nagtumong sa kasamtangan nga baryable, gimbuhaton o mga modules etc, nga kamo dili nagpaila sa usa ka bag-o nga ang usa niini.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (bag-o, makalingaw, ang ngalan) { }//dili magamit sa niini nga paagi!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nagtapo sa mga literal sa usa ka hiwa nga static string.
    ///
    /// macro Kini nagkinahanglan og bisan unsa nga gidaghanon sa mga comma-mibulag literals, nga nagahatag sa usa ka ekspresyon sa matang `&'static str` nga nagrepresentar sa tanan nga mga literals concatenated sa wala-sa-tuo.
    ///
    ///
    /// Ang mga integer ug naglutaw nga punto nga literal gikutuban aron maapil sa tingub.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ginpasangkad sa gidaghanon linya nga kini gigamit.
    ///
    /// Sa [`column!`] ug [`file!`], ang mga macros naghatag kasayuran sa pag-debug alang sa mga taghimo bahin sa lokasyon sa sulud sa gigikanan.
    ///
    /// Ang expanded ekspresyon adunay matang `u32` ug mao ang 1-based, mao nga sa unang linya sa matag PAMB file sa 1, ang ikaduha ngadto sa 2, ug uban pa
    /// Kini nahiuyon sa mga mensahe sayop pinaagi sa komon nga nagtigom o popular nga mga editor.
    /// Ang mibalik nga linya mao ang dili kinahanglan nga ang linya sa mga `line!` pagsangpit sa iyang kaugalingon, apan hinoon sa unang macro pagsangpit padulong ngadto sa pagsangpit sa `line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ginpasangkad sa gidaghanon kolum sa nga kini gigamit.
    ///
    /// Uban sa [`line!`] ug [`file!`], kini nga mga macros paghatag og impormasyon debugging alang sa developers bahin sa nahimutangan sa sulod sa tinubdan.
    ///
    /// Ang expanded ekspresyon adunay matang `u32` ug mao ang 1-based, mao nga ang unang kolum sa matag PAMB linya sa 1, ang ikaduha ngadto sa 2, ug uban pa
    /// Kini nahiuyon sa mga mensahe sayop pinaagi sa komon nga nagtigom o popular nga mga editor.
    /// Ang mibalik kolum mao ang dili kinahanglan nga ang linya sa mga `column!` pagsangpit sa iyang kaugalingon, apan hinoon sa unang macro pagsangpit padulong ngadto sa pagsangpit sa `column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ginpasangkad sa ngalan file diin kini gigamit.
    ///
    /// Uban sa [`line!`] ug [`column!`], kini nga mga macros paghatag og impormasyon debugging alang sa developers bahin sa nahimutangan sa sulod sa tinubdan.
    ///
    /// Ang gipalapdan nga ekspresyon adunay tipo nga `&'static str`, ug ang giuli nga file dili ang pangamuyo sa `file!` macro mismo, hinonoa ang una nga pag-ampo sa makro nga nag-una sa pagsangpit sa `file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Gipasabut ang mga argumento niini.
    ///
    /// macro Kini nga magahatag usa ka pagpahayag sa matang `&'static str` nga mao ang stringification sa tanan nga mga tokens miagi sa macro.
    /// Wala`y pagbutang mga pagdili sa syntax sa macro nga pangamuyo mismo.
    ///
    /// Timan-i nga ang gipalapdan resulta sa input tokens mahimong mausab sa future.Ikaw kinahanglan nga mag-amping kon magsalig kamo sa output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Naglakip usa ka UTF-8 encode file ingon usa ka string.
    ///
    /// payl nahimutang paryente sa sa kasamtangan nga file (usab sa kon sa unsang paagi modules makaplagan).
    /// Ang gihatag nga dalan hubaron diha sa usa ka plataporma-piho nga dalan sa pagtipon panahon.
    /// Busa, pananglitan, sa usa ka pag-ampo sa usa ka Windows dalan nga naglangkob sa backslashes `\` dili pagtipon sa husto sa Unix.
    ///
    ///
    /// macro Kini nga magahatag usa ka pagpahayag sa matang `&'static str` nga mao ang mga sulod sa file.
    ///
    /// # Examples
    ///
    /// Paghunahuna nga adunay duha nga mga file sa parehas nga direktoryo nga adunay mga musunud nga sulud:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Ang pagtigum sa 'main.rs' ug pagpadagan sa sangputanan nga binary mag-print "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Naglakip sa usa ka file nga ingon sa usa ka pakisayran ngadto sa usa ka Byte gubat.
    ///
    /// payl nahimutang paryente sa sa kasamtangan nga file (usab sa kon sa unsang paagi modules makaplagan).
    /// Ang gihatag nga dalan hubaron diha sa usa ka plataporma-piho nga dalan sa pagtipon panahon.
    /// Busa, pananglitan, sa usa ka pag-ampo sa usa ka Windows dalan nga naglangkob sa backslashes `\` dili pagtipon sa husto sa Unix.
    ///
    ///
    /// macro Kini nga magahatag usa ka pagpahayag sa matang `&'static [u8; N]` nga mao ang mga sulod sa file.
    ///
    /// # Examples
    ///
    /// Paghunahuna nga adunay duha nga mga file sa parehas nga direktoryo nga adunay mga musunud nga sulud:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Ang pagtigum sa 'main.rs' ug pagpadagan sa sangputanan nga binary mag-print "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ginpasangkad sa usa ka hilo nga nagrepresentar sa kasamtangan nga module dalan.
    ///
    /// Ang kasamtangan nga module dalan mahimong naghunahuna sa ingon nga ang hierarchy sa modules padulong balik ngadto sa crate root.
    /// Ang unang bahin sa sa dalan mibalik ang ngalan sa crate karon nga tinigum, hinipos.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Nagsusi boolean kalihokan sa bandera kontorno sa pagtipon-panahon.
    ///
    /// Dugang pa sa `#[cfg]` hiyas, kini nga macro gihatag sa pagtugot sa boolean ekspresyon evaluation sa mga bandila kontorno.
    /// Kanunay kini mosangput sa dili kaayo doble nga code.
    ///
    /// Ang syntax nga gihatag ngadto sa macro kini mao ang sama nga syntax ingon nga ang mga [`cfg`] hiyas.
    ///
    /// `cfg!`, dili sama sa `#[cfg]`, wala kuhaa sa bisan unsa nga code ug mag asister sa lamang sa tinuod o bakak.
    /// Pananglitan, ang tanan nga mga bloke sa usa ka ekspresyon panginahanglan if/else nga mahimong balido sa diha nga `cfg!` gigamit alang sa kahimtang, bisan unsa `cfg!` ang pagtimbangtimbang.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses sa usa ka file nga ingon sa usa ka ekspresyon o sa usa ka butang sumala sa konteksto.
    ///
    /// payl nahimutang paryente sa sa kasamtangan nga file (usab sa kon sa unsang paagi modules makaplagan).Ang gihatag nga agianan gipasabut sa us aka paagi nga tukma sa platform sa pagtigum sa oras.
    /// Busa, pananglitan, sa usa ka pag-ampo sa usa ka Windows dalan nga naglangkob sa backslashes `\` dili pagtipon sa husto sa Unix.
    ///
    /// Pinaagi sa paggamit niini nga macro mao ang kanunay nga ang usa ka maayo nga ideya, tungod kay kon ang file nga gianalisar ingon sa usa ka ekspresyon, kini moadto sa nga gibutang sa palibot nga code unhygienically.
    /// Mahimong magresulta kini sa mga variable o function nga lahi sa gipaabot sa file kung adunay mga variable o function nga adunay parehas nga ngalan sa karon nga file.
    ///
    ///
    /// # Examples
    ///
    /// Paghunahuna nga adunay duha nga mga file sa parehas nga direktoryo nga adunay mga musunud nga sulud:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Paghipos 'main.rs' ug sa nagaagay nga ang resulta duha ang imprinta "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Nagpahayag nga ang usa ka boolean ekspresyon mao ang `true` sa Runtime.
    ///
    /// Ipatawag kini ang [`panic!`] macro kung ang gihatag nga ekspresyon dili masusi sa `true` sa oras nga mag-runtime.
    ///
    /// # Uses
    ///
    /// Mga pangangkon kanunay gitan-aw sa duha debug ug pagpagawas nagtukod, ug dili mahimo nga kakulangan.
    /// Tan-awa [`debug_assert!`] alang sa mga pangangkon nga wala nakahimo sa pagpagawas nagtukod pinaagi sa default.
    ///
    /// Luwas code mahimo nga magsalig sa `assert!` sa pagpatuman sa pagdagan-panahon invariants nga, kon nakalapas sa mahimong mosangpot sa unsafety.
    ///
    /// Sa lain nga paggamit-kaso sa `assert!` naglakip sa pagsulay ug sa pagpatuman sa run-panahon invariants sa luwas nga code (kansang paglapas dili mahimong moresulta sa unsafety).
    ///
    ///
    /// # Pasadya nga mga Mensahe
    ///
    /// Ang kini nga macro adunay usa ka ikaduha nga porma, diin ang usa ka naandan nga mensahe nga panic mahimong mahatag o wala mga argumento alang sa pag-format.
    /// Tan-awa ang [`std::fmt`] alang sa syntax alang sa niini nga matang.
    /// Mga ekspresyon nga gigamit ingon nga mga argumento format lamang nga evaluate kon ang pangangkon mapakyas.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ang panic mensahe alang niini nga mga assertions mao ang stringified bili sa ekspresyon nga gihatag.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // usa ka yano kaayo nga function
    ///
    /// assert!(some_computation());
    ///
    /// // ihingusog uban sa usa ka batasan nga mensahe
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Pagpundok sa linya.
    ///
    /// Basaha ang [unstable book] alang sa paggamit.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Ang tigum sa inline nga istilo sa LLVM.
    ///
    /// Basaha ang [unstable book] alang sa paggamit.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Pagtigum sa lebel sa lebel sa modyul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Mga agi-agi tokens ngadto sa sumbanan nga output.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Makahimo sa o disables pagsubay sa kagamitan, katuyoan gigamit alang sa debugging sa ubang mga macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Kinaiya macro nga gigamit sa paggamit sa tinubdan sa macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Kinaiya macro apply sa usa ka function aron sa pagpabalik niini ngadto sa usa ka yunit sa pagsulay.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Gipasabut ang makro sa hiyas sa usa ka kalihokan aron mahimo kini usa ka benchmark test.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Usa ka pagpatuman detalye sa `#[test]` ug `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Kinaiya macro apply sa usa ka nagahunong sa pagparehistro niini ingon nga sa usa ka global nga allocator.
    ///
    /// Tan-awa usab sa [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Nagabantay sa butang kini nga gigamit sa kon sa miagi nga dalan mao ang accessible, ug removes kini kon dili.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Nagpalapad sa tanan `#[cfg]` ug `#[cfg_attr]` mga hiyas sa code tipik kini apply ngadto sa.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Nagabukal pagpatuman detalye sa `rustc` tighipos, ayaw paggamit.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Nagabukal pagpatuman detalye sa `rustc` tighipos, ayaw paggamit.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}