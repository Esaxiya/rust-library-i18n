Panics sa kasamtangan nga hilo.

Kini nagtugot sa usa ka programa sa undang dayon ug sa paghatag og feedback ngadto sa caller sa programa.
`panic!` kinahanglan nga gigamit sa diha nga ang usa ka programa ot sa usa ka mauli nga kahimtang.

Ang kini nga macro mao ang hingpit nga paagi aron maipahayag ang mga kondisyon sama pananglit sa code ug sa mga pagsulay.
`panic!` hugut nga gihigot sa `unwrap` nga pamaagi sa parehas nga [`Option`][ounwrap] ug [`Result`][runwrap] enum.
Ang parehas nga pagpatuman gitawag nga `panic!` kung kini gitakda sa [`None`] o [`Err`] nga lahi.

Sa diha nga ang paggamit sa `panic!()` nga imong mahimo hingalan sa usa ka hilo payload, nga gitukod sa paggamit sa [`format!`] syntax.
payload nga mao ang gigamit sa dihang injecting sa panic ngadto sa pagtawag Rust hilo, hinungdan sa bug-os ang hilo sa panic.

Ang kinaiya sa default `std` hook, ie
ang code nga midagan direkta human sa panic ang gisangpit, mao sa pag-imprinta sa mga mensahe sa payload sa `stderr` uban sa impormasyon file/line/column sa `panic!()` tawag.

Ikaw mahimo mopalabaw sa panic hook paggamit [`std::panic::set_hook()`].
Sulod sa hook usa ka panic mahimong makuha ingon nga usa ka `&dyn Any + Send`, nga naglakip bisan sa usa ka `&str` o `String` alang sa regular nga `panic!()` mga pag-ampo.
Sa panic nga adunay kantidad sa uban pang lahi, mahimong magamit ang [`panic_any`].

[`Result`] enum mao ang kanunay nga ang usa ka mas maayo nga solusyon alang sa pagkaayo gikan sa mga sayop kay sa paggamit sa `panic!` macro.
macro Kini kinahanglan nga gamiton sa paglikay sa nga nagagikan sa paggamit sa sayop nga mga prinsipyo, sama sa gikan sa gawas nga tinubdan.
Detalyado nga impormasyon mahitungod sa sayop handling makaplagan diha sa [book].

Tan-awa usab ang macro [`compile_error!`], alang sa pagpataas sa mga sayup sa panahon sa pagtipon.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Karon nga pagpatuman

Kon ang nag-unang nga hilo panics kini undang sa inyong tanan nga mga hilo ug matapos sa imong programa sa code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





