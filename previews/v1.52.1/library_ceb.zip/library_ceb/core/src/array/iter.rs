//! Gihubit ang tag-iya sa `IntoIter` nga iterator alang sa mga array.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Usa ka itudlo nga [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Kini ang paghan-ay nga gitapos namon.
    ///
    /// Ang mga elemento nga adunay index `i` diin ang `alive.start <= i < alive.end` wala pa mahatag ug mga balido nga mga entry sa array.
    /// Ang mga elemento nga adunay mga indeks nga `i < alive.start` o `i >= alive.end` gihatag na ug kinahanglan dili na ma-access!Kadtong mga patay nga elemento mahimo`g usab sa usa ka hingpit nga wala`y kaalam nga kahimtang!
    ///
    ///
    /// Mao nga ang nag-imbitar mao ang:
    /// - `data[alive]` buhi (ie adunay sulud nga mga elemento)
    /// - `data[..alive.start]` ug `data[alive.end..]` mga patay (ie ang mga elemento na sa pagbasa ug dili kinahanglan nga gihikap na!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Ang mga elemento sa `data` nga wala pa mahatag.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Nagmugna sa usa ka bag-o nga iterator sa ibabaw sa gihatag `array`.
    ///
    /// *Matikdi*: niini nga pamaagi mahimong deprecated sa future, human sa [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Ang lahi sa `value` usa ka `i32` dinhi, imbis nga `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: Ang dalayegon dinhi mao ang tinuod nga luwas.Ang mga dokumento sa `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` gigarantiyahan nga adunay parehas nga gidak-on ug paghanay
        // > ingon `T`.
        //
        // Gipakita pa sa mga doc ang us aka transmute gikan sa usa ka laray nga `MaybeUninit<T>` ngadto sa usa ka laray nga `T`.
        //
        //
        // Uban niana nga, kini nga Initialization nagtagbaw sa mga invariants.

        // FIXME(LukasKalbertodt): sa pagkatinuod sa paggamit `mem::transmute` dinhi, sa higayon nga kini buhat uban sa const Generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Hangtud unya, atong magamit ang `mem::transmute_copy` sa paghimo sa usa ka bitwise kopya ingon sa usa ka lain-laing mga matang, nan kalimti `array` sa ingon nga kini dili nagpatulo.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Nagbalik usa ka dili mabalhin nga hiwa sa tanan nga mga elemento nga wala pa mahatag.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KALUWAS: Nahibal-an namon nga ang tanan nga mga elemento sa sulud sa `alive` husto nga gisugdan.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Mobalik sa usa ka mutable ad-ad sa tanan nga mga elemento nga wala mitugyan pa.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KALUWAS: Nahibal-an namon nga ang tanan nga mga elemento sa sulud sa `alive` husto nga gisugdan.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Kuhaa ang sunod nga indeks gikan sa atubangan.
        //
        // Ang pagdugang `alive.start` sa 1 nagpadayon sa invariant bahin sa `alive`.
        // Bisan pa, tungod sa kini nga pagbag-o, sa mubo nga panahon, ang buhi nga sona dili na `data[alive]`, apan `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Basaha ang elemento gikan sa laray.
            // SAFETY: `idx` mao ang usa ka index ngadto sa kanhi "alive" rehiyon sa
            // han-ay.Ang pagbasa sa kini nga elemento nagpasabut nga ang `data[idx]` giisip nga patay na karon (ie ayaw paghikap).
            // Ingon nga ang `idx` mao ang sinugdanan sa buhi nga-sona, ang buhi nga sona karon `data[alive]` na usab, nga gipahiuli ang tanan nga nag-imbitar.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Kuhaa ang sunod nga indeks gikan sa likod.
        //
        // Ang pagkunhod sa `alive.end` sa 1 nagpadayon sa invariant bahin sa `alive`.
        // Bisan pa, tungod sa kini nga pagbag-o, sa mubo nga panahon, ang buhi nga sona dili na `data[alive]`, apan `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Basaha ang elemento gikan sa laray.
            // SAFETY: `idx` mao ang usa ka index ngadto sa kanhi "alive" rehiyon sa
            // han-ay.Ang pagbasa sa kini nga elemento nagpasabut nga ang `data[idx]` giisip nga patay na karon (ie ayaw paghikap).
            // Ingon `idx` mao ang katapusan sa buhi-zone, ang buhi zone mao karon `data[alive]` pag-usab, pagpasig-uli sa tanang mga invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: Kini mao ang luwas: `as_mut_slice` mobalik gayud sa sub-ad-ad
        // sa mga elemento nga wala pa mabalhin ug nga nahabilin nga ihulog.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Dili gyud mopaunlod tungod sa invariant `buhi.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// iterator Ang pagkatinuod nagtaho sa husto nga gitas-on.
// Ang gidaghanon sa mga "alive" elemento (nga sa gihapon nga mitugyan) mao ang gitas-on sa laing `alive`.
// laing Kini nga decremented sa gitas-on sa bisan hain `next` o `next_back`.
// Kanunay kini nga gipamubu sa 1 sa mga kana nga pamaagi, apan kung ibalik ra ang `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Mubo nga sulat, kita dili gayud kinahanglan nga pagpares sa eksaktong sama nga buhi range, aron mahimo kita clone sa offset 0 sa walay pagtagad sa diin `self` mao.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // I-clone ang tanan nga buhi nga mga elemento.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Pagsulat usa ka clone sa bag-ong laray, dayon i-update ang buhi nga sakup niini.
            // Kon cloning panics, kita husto drop sa miaging mga butang.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Lamang imprinta sa mga elemento nga wala mitugyan pa: nga kita dili access sa mitugyan elemento na.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}