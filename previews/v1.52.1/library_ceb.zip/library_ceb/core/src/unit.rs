use crate::iter::FromIterator;

/// Gibuak ang tanan nga mga butang sa yunit gikan sa usa ka iterator ngadto sa usa.
///
/// Kini labi ka mapuslanon kung gihiusa sa mga labi ka taas nga lebel nga mga abstraksiyon, sama sa pagkolekta sa usa ka `Result<(), E>` diin ang imong pag-atiman lang sa mga sayup
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}