//! Mga lahi nga nagpitik sa datos sa lokasyon niini sa memorya.
//!
//! Kini usahay mapuslanon nga adunay mga butang nga gigarantiyahan nga dili molihok, sa diwa nga ang ilang pagbutang sa panumduman dili mausab, ug ingon niana masaligan.
//! Ang usa ka punoan nga pananglitan sa mao nga senaryo mao ang paghimo sa mga struktura nga alang sa kaugalingon, tungod kay ang pagbalhin sa usa ka butang nga adunay mga panudlo sa iyang kaugalingon mao ang magwagtang sa silot nga mahimong hinungdan sa dili matino nga pamatasan.
//!
//! Sa usa ka taas nga lebel, gisiguro sa usa ka [`Pin<P>`] nga ang pointee sa bisan unsang tipo sa puntos nga `P` adunay usa ka malig-on nga lokasyon sa memorya, nga nagpasabut nga dili kini mahimo`g ibalhin sa ubang lugar ug ang memorya niini dili mahimo`g mabalhin hangtod mawala.Kita moingon nga ang pointee mao "pinned".Ang mga butang nahimong labi ka maliputon kung naghisgot sa mga tipo nga naghiusa sa pinned sa dili pinned nga datos;[see below](#projections-and-structural-pinning) alang sa dugang nga mga detalye.
//!
//! Pinaagi sa default, tanan nga mga lahi sa Rust mahimo`g mabalhin.
//! Gitugotan sa Rust ang pagpasa sa tanan nga mga klase nga by-value, ug ang kasagarang mga klase nga smart-pointer sama sa [`Box<T>`] ug `&mut T` nagtugot sa pag-ilis ug pagbalhin sa mga kantidad nga sulud niini: mahimo ka makagawas sa usa ka [`Box<T>`], o mahimo nimo gamiton ang [`mem::swap`].
//! [`Pin<P>`] wraps sa usa ka pointer nga matang `P`, mao [`Pin`]`<`[`Box`] `<T>>`ninglihok sama sa usa ka naandan
//!
//! [`Box<T>`]: when usa ka [`Pin`]`<`[`Box`] `<T>>`nahulog, ingon usab ang mga sulud niini, ug ang memorya nakuha
//!
//! nakigsabotSa susama, ang [`Pin`]`<&mut T>` sama sa `&mut T`.Apan, [`Pin<P>`] wala himoa nga kliyente sa tinuod angkon sa usa ka [`Box<T>`] o `&mut T` sa pinned data, nga nagpasabot nga dili ka makahimo sa paggamit sa operasyon sama sa [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` nanginahanglan `&mut T`, apan dili namon kini makuha.
//!     // Na-stuck kami, dili namon mapalit ang mga sulud nga kini nga pakisayran.
//!     // Mahimo namon gamiton ang `Pin::get_unchecked_mut`, apan dili kana luwas tungod sa usa ka hinungdan:
//!     // wala kami gitugotan nga gamiton kini alang sa pagbalhin sa mga butang gikan sa `Pin`.
//! }
//! ```
//!
//! Kini angayan nga sublion usab nga ang [`Pin<P>`] dili *dili* gibag-o ang katinuud nga giisip sa usa ka tigpagsama nga Rust ang tanan nga mga matang nga mabalhin.Ang [`mem::swap`] nagpabilin nga matawag alang sa bisan unsang `T`.Hinunoa, [`Pin<P>`] magpugong sa pipila ka *mga prinsipyo*(nagpunting sa pinaagi sa pointers giputos sa [`Pin<P>`]) gikan sa mibalhin pinaagi sa paghimo niini nga imposible sa pagtawag sa mga pamaagi nga nagkinahanglan `&mut T` sa kanila (sama sa [`mem::swap`]).
//!
//! [`Pin<P>`] mahimong gamiton sa pag-wrap sa bisan unsa nga pointer matang `P`, ug sa ingon kini interact sa [`Deref`] ug [`DerefMut`].Usa ka [`Pin<P>`] diin ang `P: Deref` kinahanglan isipon ingon usa ka "`P`-style pointer" sa usa ka naka pin nga `P::Target`-busa, usa ka [`Pin`]`<`[`Box`]`<T>>`gipanag-iya nga pointer sa usa ka pin na `T`, ug usa ka [`Pin`] `<` [`Rc`]`<T>>`usa ka panudlo nga naihap sa pakisayran sa usa ka pin nga `T`.
//! Alang sa pagkahusto, ang [`Pin<P>`] nagsalig sa mga pagpatuman sa [`Deref`] ug [`DerefMut`] nga dili mobalhin gikan sa ilang `self` nga parameter, ug ibalik ra gihapon ang usa ka pointer sa naka-pin nga datos kung gitawag sila sa usa ka naka-pin nga pointer.
//!
//! # `Unpin`
//!
//! Daghang mga matang sa mga kanunay nga sa kinabubut-on movable, bisan sa diha nga pinned, tungod kay sila wala mosalig sa may usa ka lig-on nga address.Kauban niini ang tanan nga sukaranan nga lahi (sama sa [`bool`], [`i32`], ug mga pakisayran) ingon man mga lahi nga gilangkoban ra sa kini nga mga lahi.Ang mga lahi nga wala`y labot sa pagpilit ipatuman ang [`Unpin`] auto-trait, nga nagkansela sa epekto sa [`Pin<P>`].
//! Alang sa `T: Unpin`, [`Pin`]`<`[`Box`] `<T>> Ug [`Box<T>`] function identically, ingon sa pagbuhat sa [`Pin`]` <&Mut T> `ug `&mut T`.
//!
//! Hinumdomi nga ang pinning ug [`Unpin`] nakaapekto lang sa gitudlo nga tipo nga `P::Target`, dili ang tipo sa pointer nga `P` mismo nga naputos sa [`Pin<P>`].Pananglitan, kung ang [`Box<T>`] o [`Unpin`] o wala`y epekto sa pamatasan sa [`Pin`]` <`[` Box`]`<T>> `(Dinhi, `T` mao ang talinis nga-sa type).
//!
//! # Pananglitan: kaugalingon nga referensial nga estruktura
//!
//! Sa wala pa kami moadto sa dugang nga mga detalye aron ipasabut ang mga garantiya ug mga kapilian nga may kalabutan sa `Pin<T>`, gihisgutan namon ang pipila nga mga pananglitan kung giunsa kini magamit.
//! Mobati nga gawasnon sa [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Kini usa ka kaugalingon nga referensial nga istruktura tungod kay ang hiwa nga natad nagpunting sa natad sa datos.
//! // Dili namon mahibal-an ang tag-compiler bahin niana sa usa ka normal nga pakisayran, tungod kay kini nga sundanan dili mahulagway sa naandan nga mga lagda sa pagpangutang.
//! //
//! // Hinuon naggamit kami usa ka hilaw nga tudlo, bisan kung usa nga nahibal-an nga dili mahimo`g wala, ingon nahibal-an namon nga nagtudlo kini sa pisi.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Aron maseguro nga dili molihok ang datos kung mobalik ang pagpaandar, gibutang namon kini sa tinapok diin kini magpabilin sa tibuok kinabuhi nga butang, ug ang paagi ra nga ma-access kini pinaagi sa usa ka pointer niini.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // gihimo ra namon ang pointer sa higayon nga ang datos naa sa lugar kung dili kini mobalhin na sa wala pa kami magsugod
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // Nahibal-an namon nga kini luwas tungod kay ang pagbag-o sa usa ka uma dili mobalhin sa tibuuk nga istruktura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Kinahanglan itudlo sa pointer ang tama nga lokasyon, basta wala maglihok ang estruktura.
//! //
//! // Samtang, libre kita nga ibalhin ang pointer sa palibot.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Tungod kay wala ipatuman sa among tipo ang Unpin, dili kini makahimo sa pagtipon:
//! // himoa nga si Mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Pananglitan: lista sa nanghilabot nga doble nga nalangkit
//!
//! Sa usa ka intrusive list nga doble nga nalambigit, ang koleksyon dili tinuod nga gigahin ang memorya alang sa mga elemento mismo.
//! Ang pagdumala kontrolado sa mga kliyente, ug ang mga elemento mahimo mabuhi sa usa ka stack frame nga labi ka buhi ang kinabuhi kaysa sa koleksyon.
//!
//! Aron mahimo kini nga trabaho, ang matag elemento adunay mga panudlo sa gisundan niini ug manununod sa lista.Ang mga elemento mahimo ra nga idugang kung kini ma-pin, tungod kay ang pagbalhin sa mga elemento sa palibot mahimong dili husto ang mga panudlo.Labut pa, ang pagpatuman sa [`Drop`] sa usa ka naka-link nga elemento sa lista mag-tap sa mga tudlo sa gisundan ug manununod niini aron makuha ang kaugalingon gikan sa lista.
//!
//! Crucially, kita makahimo sa mosalig sa [`drop`] nga gitawag.Kung ang usa ka elemento mahimo`g mapalitan o mahimo`g dili balido nga wala`y pagtawag sa [`drop`], ang mga panudlo dinhi gikan sa mga silingan nga elemento mahimo`g dili balido, nga makaguba sa istraktura sa datos.
//!
//! Tungod niini, ang pag-pin usab adunay usa ka garantiya nga adunay kalabotan nga [`drop`].
//!
//! # `Drop` guarantee
//!
//! Ang katuyoan sa pag-pin aron masaligan ang pagbutang sa pipila nga datos sa memorya.
//! Aron mahimo kini nga trabaho, ang dili lang pagbalhin sa datos gikutuban;deallocating, repurposing, o kung dili man ang pagwagtang sa memorya nga gigamit sa pagtipig sa datos gidili usab.
//! Konkreto, alang sa naka-pin nga datos kinahanglan nimo nga ipadayon ang invariant nga *ang memorya niini dili mabalhin o mabalik gikan sa higayon nga ma-pin kini hangtod nga tawgon ang [`drop`]*.Kausa ra nga mibalik ang [`drop`] o panics, mahimong magamit ang memorya.
//!
//! Ang panumduman mahimo nga "invalidated" pinaagi sa deallocation, apan pinaagi usab sa pag-ilis sa usa ka [`Some(v)`] sa [`None`], o pagtawag sa [`Vec::set_len`] sa "kill" pipila nga mga elemento gikan sa usa ka vector.Mahimo kini repurposed pinaagi sa paggamit sa [`ptr::write`] aron masobrahan kini nga wala una tawagi ang destructor.Walay bisan kinsa sa kini nga gitugotan sa pinned data nga walay pagtawag [`drop`].
//!
//! Kini gyud ang klase nga garantiya nga ang nanghilabot nga lista nga na-link gikan sa miaging seksyon kinahanglan molihok nga tama.
//!
//! Timan-i nga kini nga garantiya dili *wala* nagpasabut nga ang panumduman dili molugak!Hingpit gihapon nga okay nga dili na gyud tawagan ang [`drop`] sa usa ka naka-pin nga elemento (pananglitan, mahimo ka pa usab tawagan ang [`mem::forget`] sa usa ka [`Pin`]`<` [`Box`]`<T>>`).Sa pananglitan sa lista nga doble nga nalambigit, kana nga elemento magpabilin ra sa lista.Bisan pa dili ka mahimo nga libre o gamiton usab ang pagtipig *nga wala magtawag sa [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Kung ang imong tipo naggamit pinning (sama sa duha nga pananglitan sa taas), kinahanglan ka mag-amping sa pagpatuman sa [`Drop`].Ang pag-andar sa [`drop`] nagkinahanglan `&mut self`, apan kini gitawag nga *bisan kung ang imong tipo kaniadto na-pin*!Kini sama sa awtomatikong gitawag sa tag-compiler nga [`Pin::get_unchecked_mut`].
//!
//! Dili gyud kini hinungdan sa usa ka problema sa luwas nga code tungod kay ang pagpatuman sa us aka klase nga nagsalig sa pag-pin nanginahanglan dili luwas nga code, apan hibal-i nga ang paghukum nga gamiton ang pag-pin sa imong tipo (pananglitan pinaagi sa pagpatuman sa pila ka operasyon sa [`Pin`]`<&Kaugalingon>`o [`Pin`] `<&Mut Kaugalingon>`) adunay mga sangputanan alang sa imong [`Drop`] pagpatuman ingon man: kon ang usa ka elemento sa imong matang unta pinned, kamo kinahanglan gayud nga pagtratar sa [`Drop`] ingon bug-os sa pagkuha [`Pin`]`<&Mut Kaugalingon>`.
//!
//!
//! Pananglitan, mahimo nimo ipatuman ang `Drop` sama sa mosunud:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` okay ra tungod nahibal-an namon nga kini nga kantidad wala na gigamit pag-usab gikan sa pagkahulog.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ang tinuod nga drop code moadto dinhi.
//!         }
//!     }
//! }
//! ```
//!
//! Ang pag-andar `inner_drop` adunay tipo nga [`drop`]*kinahanglan* adunay, mao nga kini gisiguro nga dili nimo aksidente nga gigamit ang `self`/`this` sa usa ka paagi nga sukwahi sa pag-pin.
//!
//! Labut pa, kung ang imong tipo `#[repr(packed)]`, awtomatikong ibalhin sa tagtipon ang mga umahan aron mahulog kini.Mahimo pa usab kana alang sa mga umahan nga mahinabo nga nahanay.Ingon usa ka sangputanan, dili nimo magamit ang pag-pin sa usa ka `#[repr(packed)]` nga tipo.
//!
//! # Mga Proyekto ug Structural Pinning
//!
//! Kung nagtrabaho kauban ang mga pinned struct, motumaw ang pangutana kung giunsa ma-access sa usa ka tawo ang mga natad sa kana nga istruktura sa usa ka pamaagi nga moagi ra sa [`Pin`]`<&mut Struct>`.
//! Ang naandan nga pamaagi mao ang pagsulat mga pamaagi sa helper (mao nga gitawag nga *projections*) nga gihimo ang [`Pin`]`<&mut Struct>` nga usa ka pakisayran sa uma, apan unsa nga tipo ang kinahanglan adunay kana nga pakisayran?Kini ba ang [`Pin`]`<&mut Field>`o `&mut Field`?
//! Ang parehas nga pangutana nga mitumaw sa mga uma sa usa ka `enum`, ug usab kung gikonsidera ang mga container/wrapper nga lahi sama sa [`Vec<T>`], [`Box<T>`], o [`RefCell<T>`].
//! (Ang kini nga pangutana naaplikar sa parehas nga dili mabalhin ug gipaambitan nga mga pakisayran, gigamit ra namon ang labi ka daghang kaso sa mga mutable referensya dinhi alang sa ilustrasyon.)
//!
//! Nahimo nga kini sa tinuud ra sa tagsulat ang istruktura sa datos aron mahukman kung ang pinned projection alang sa usa ka piho nga natad nahimo nga [`Pin`]`<&mut Struct>`ngadto sa [`Pin`] `<&mut Field>` o `&mut Field` Adunay pila nga mga pagpugong bisan pa, ug ang labi ka hinungdan nga pagpugong mao ang *pagkamakanunayon*:
//! ang matag natad mahimong *mahimong* gipaabot sa usa ka naka-pin nga pakisayran,*o* gikuha ang pag-pin ingon usa ka bahin sa projisyon.
//! Kung ang duha gihimo alang sa parehas nga uma, tingali dili kana matugkad!
//!
//! Ingon nga ang tagsulat sa usa ka gambalay data kamo sa pagdesisyon alang sa matag uma kon pinning "propagates" sa uma niini o dili.
//! Ang pinning nga nagpakaylap gitawag usab nga "structural", tungod kay nagsunod kini sa istruktura sa tipo.
//! Sa mga mosunud nga suskrisyon, gisaysay namon ang mga pagkonsiderar nga kinahanglan buhaton alang sa bisan kinsa nga kapilian.
//!
//! ## Ang pinning *dili* istruktura alang sa `field`
//!
//! Ingon og kontra-intuitive nga ang uma sa usa ka naka-pin nga istruktura mahimong dili ma-pin, apan kana ang labing kadali nga kapilian: kung ang usa ka [`Pin`]`<&mut Field>`dili gyud gihimo, wala`y mahimo nga sayup!Mao nga, kung magbuut ka nga ang pila ka uma wala`y struktural nga pag-pin, tanan nga kinahanglan nimo nga masiguro mao nga dili ka makahimo usa ka pinned nga pakisayran sa natad.
//!
//! Ang mga natad nga wala pag-pin sa istruktura mahimong adunay usa ka pamaagi sa pagbuut nga mahimong [00 Pin]] "<&mut Struct>` ngadto sa `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Okay ra kini tungod kay ang `field` wala gyud gikonsiderar nga pin.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Mahimo ka usab nga `impl Unpin for Struct`*bisan kung* ang klase nga `field` dili [`Unpin`].Kung unsa ang gihunahuna sa kana nga tipo bahin sa pag-pin dili kalabutan kung wala`y [`Pin`]` <&mut Field>` nga gihimo.
//!
//! ## Ang pinning *mao ang* istruktura alang sa `field`
//!
//! Ang uban pang kapilian mao ang paghukum nga ang pinning mao ang "structural" alang sa `field`, nagpasabut nga kung ang istruktohan naka-pin sa ingon usab ang uma.
//!
//! Gitugotan ang pagsulat usa ka proyeksyon nga nagmugna usa ka [`Pin`]`<&mut Field>`, sa ingon nagsaksi nga ang uma na-pin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Kini mao ang okay tungod kay `field` ang pinned sa diha nga `self` mao.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Bisan pa, ang pag-pin sa istruktura adunay pipila nga dugang nga mga kinahanglanon:
//!
//! 1. Ang istruktura kinahanglan nga [`Unpin`] lamang kung ang tanan nga istruktura nga mga uma [`Unpin`].Kini mao ang remate, apan [`Unpin`] mao ang usa ka luwas trait, sa pagkaagi nga ang tagsulat sa magtukod kini mao ang imong responsibilidad dili * aron sa pagdugang sa usa ka butang nga sama sa `impl<T> Unpin for Struct<T>`.
//! (Matikdi nga ang pagdugang sa usa ka prodyeksyon operasyon nagkinahanglan nga dili luwas code, mao nga ang mga kamatuoran nga [`Unpin`] mao ang usa ka luwas nga trait wala sa pagguba sa baruganan nga ikaw adunay lamang sa kabalaka sa bisan unsa nga sa niini nga kon imong gamiton `unsafe`.)
//! 2. Ang moguba sa istraktura kinahanglan dili ibalhin ang mga istruktura nga natad gikan sa lantugi niini.Kini ang ensakto nga punto nga gipataas sa [previous section][drop-impl]: Ang `drop` nagkinahanglan `&mut self`, apan ang istruktura (ug busa ang mga umahan) mahimong na-pin sa una.
//!     Kinahanglan nimo nga garantiyahan nga dili ka maglihok sa usa ka uma sa sulud sa imong pagpatuman sa [`Drop`].
//!     Sa partikular, sama sa gipatin-aw kaniadto, kini gipasabut nga ang imong istraktura kinahanglan *dili* mahimong `#[repr(packed)]`.
//!     Kitaa ang kana nga seksyon kung unsaon pagsulat ang [`drop`] sa usa ka paagi nga ang tigtabang makatabang kanimo nga dili aksidente nga mabuak ang pinning.
//! 3. Kinahanglan nimo nga sigurohon nga imong gipadayon ang [`Drop` guarantee][drop-guarantee]:
//!     sa higayon nga ma-pin ang imong estruktura, ang panumduman nga adunay sulud dili masobrahan o makalihok nga wala tawagi ang mga nagguba sa sulud.
//!     Mahimo kini malimbongon, ingon nasaksihan sa [`VecDeque<T>`]: ang tiglaglag sa [`VecDeque<T>`] mahimong mapakyas sa pagtawag sa [`drop`] sa tanan nga mga elemento kung usa sa mga nagguba nga panics.Gilapas niini ang garantiya sa [`Drop`], tungod kay mahimo`g mosangput kini sa mga elemento nga ma-deallocate nga wala tawagi ang ilang destructor.(Ang [`VecDeque<T>`] wala`y mga proxy sa pag-pin, busa dili kini hinungdan sa pagkawalay kalainan.)
//! 4. Dili ka kinahanglan maghatag bisan unsang ubang mga operasyon nga mahimong mosangput sa pagbalhin sa datos gikan sa mga istruktura nga natad kung ang imong tipo napilo.Pananglitan, kon ang magtukod naglakip sa usa ka [`Option<T>`] ug adunay usa ka `take`-sama sa operasyon sa matang `fn(Pin<&mut Struct<T>>) -> Option<T>`, nga operasyon mahimong gamiton sa pagbalhin sa usa ka `T` gikan sa usa ka pinned `Struct<T>`-nga paagi pinning dili mahimo nga structural alang sa uma nga naghupot niini nga datos
//!
//!     Alang sa usa ka labi ka komplikado nga pananglitan sa pagbalhin sa datos gikan sa usa ka naka-pin nga tipo, hunahunaa kung ang [`RefCell<T>`] adunay pamaagi nga `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Unya mahimo namon ang mosunud:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Kini ang katalagman, kini nagpasabut nga mahimo naton unang i-pin ang sulud sa [`RefCell<T>`] (gamit ang `RefCell::get_pin_mut`) ug dayon ibalhin ang kana nga sulud gamit ang mutable reference nga nakuha namon sa ulahi.
//!
//! ## Examples
//!
//! Alang sa usa ka tipo nga sama sa [`Vec<T>`], parehas nga posibilidad (pinning sa istruktura o dili) adunay kahulugan.
//! Ang usa ka [`Vec<T>`] nga adunay istruktura nga pag-pin mahimong adunay mga pamaagi nga `get_pin`/`get_pin_mut` aron makuha ang mga pin nga pakisayran sa mga elemento.Apan, kini dili * motugot pagtawag [`pop`][Vec::pop] sa usa ka pinned [`Vec<T>`] tungod kay buot mobalhin sa (structurally pinned) sulod!Dili usab tugotan ang [`push`][Vec::push], nga mahimo nga mo-reallocate ug ingon usab mabalhin ang mga sulud.
//!
//! Ang usa ka [`Vec<T>`] nga wala ang istruktura nga pag-pin mahimo nga `impl<T> Unpin for Vec<T>`, tungod kay ang mga sulud nga wala gyud ma-pin ug ang [`Vec<T>`] mismo maayo ra usab nga ibalhin usab.
//! Sa kana nga punto ang pag-pin wala ra epekto sa vector sa tanan.
//!
//! Sa sukaranan nga librarya, ang mga tipo sa pointer sa kinatibuk-an wala'y istruktura nga pag-pin, ug sa ingon wala sila gitanyag nga mga proxyon sa pag-pin.Kini ang hinungdan nga ang `Box<T>: Unpin` naghupot sa tanan nga `T`.
//! Makatarunganon nga buhaton kini alang sa mga tipo sa pointer, tungod kay ang pagbalhin sa `Box<T>` dili sa tinuud nga pagbalhin sa `T`: ang [`Box<T>`] mahimo nga libre nga mabalhin (aka `Unpin`) bisan kung ang `T` dili.Sa tinuud, bisan ang [`Pin`]`<`[`Box`]`<T>>`ug [`Pin`] `<&mut T>` kanunay [`Unpin`] sa ilang kaugalingon, alang sa parehas nga hinungdan: ang ilang sulud (ang `T`) naka-pin, apan ang mga panudlo mismo mahimo`g ibalhin nga dili ibalhin ang naka-pin nga datos.
//! Alang sa parehas nga [`Box<T>`] ug [`Pin`]`<`[`Box`] `<T>>`, kung ang sulud nga naka-pin sa tibuuk nga independente sa kung ang tudlo gitudlo, nga nagpasabut nga ang pinning *dili* istruktura.
//!
//! Kung nagpatuman sa usa ka [`Future`] kombinator, kasagaran kinahanglan nimo ang pag-pin sa istruktura alang sa salag sa futures, tungod kay kinahanglan nimo makuha ang mga pin nga pakisayran sa kanila aron tawagan ang [`poll`].
//! Apan kung ang imong panagsama adunay sulud bisan unsang uban nga datos nga dili kinahanglan nga ma-pin, mahimo nimo kana nga mga natad nga dili istruktura ug busa gawasnon nga ma-access kini sa usa ka mutable nga pakisayran bisan kung adunay ka ['Pin`]`<&mut Kaugalingon>` (ingon sama sa imong kaugalingon nga pagpatuman sa [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Usa ka naka-pin nga tudlo.
///
/// Kini usa ka balot sa palibot sa us aka klase nga pointer nga naghimo sa pointer nga "pin" ang kantidad niini sa lugar, nga gipugngan ang kantidad nga gi-refer sa kanang tudlo gikan sa pagbalhin gawas kung ipatuman ang [`Unpin`].
///
///
/// *Tan-awa ang dokumentasyon nga [`pin` module] alang sa usa ka pagpasabut sa pag-pin.*
///
/// [`pin` module]: self
///
// Note: ang `Clone` nga nakuha gikan sa ubos hinungdan sa pagkawalay kalagmitan posible nga ipatuman
// `Clone` alang sa mabalhin nga mga pakisayran.
// Tan-awa ang <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> alang sa dugang nga mga detalye.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ang mga mosunud nga pagpatuman dili makuha aron malikayan ang mga isyu sa kahimsog.
// `&self.pointer` kinahanglan dili ma-access sa mga wala`y pagsalig nga pagpatuman sa trait.
//
// Tan-awa ang <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> alang sa dugang nga mga detalye.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Pagtukod sa usa ka bag-o nga `Pin<P>` palibot sa usa ka pointer sa pipila data sa usa ka matang nga galamiton [`Unpin`].
    ///
    /// Dili sama sa `Pin::new_unchecked`, kini nga pamaagi luwas tungod kay ang pointer nga `P` nag-undang sa usa ka [`Unpin`] nga tipo, nga gikansela ang mga garantiya sa pag-pin.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KALUWASAN: ang kantidad nga gipunting mao ang `Unpin`, ug busa wala`y kinahanglanon
        // sa palibot pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Giablihan ang kini nga `Pin<P>` nga nagbalik sa nagpahiping pointer.
    ///
    /// Gikinahanglan niini nga ang datos sa sulud niining `Pin` mao ang [`Unpin`] aron mahimo namon nga dili igsapayan ang mga pag-pin invariant kung giablihan kini.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Paghimo usa ka bag-ong `Pin<P>` palibot sa usa ka pakisayran sa pipila nga datos sa usa ka tipo nga mahimo o dili mapatuman ang `Unpin`.
    ///
    /// Kung ang `pointer` dereferences sa usa ka `Unpin` type, ang `Pin::new` kinahanglan gamiton hinoon.
    ///
    /// # Safety
    ///
    /// Ang kini nga magtutukod dili luwas tungod kay dili namon masiguro nga ang datos nga gitudlo sa `pointer` naka-pin, nagpasabut nga ang datos dili ibalhin o ang paghipos niini mahimong dili balido hangtod mahulog kini.
    /// Kung ang gitukod nga `Pin<P>` dili garantiya nga ang datos nga `P` nga punto nga naka-pin, kana usa ka paglapas sa kontrata sa API ug mahimong mosangput sa wala matino nga pamatasan sa ulahi nga mga operasyon sa (safe).
    ///
    /// Pinaagi sa paggamit sa kini nga pamaagi, naghimo ka usa ka promise bahin sa pagpatuman sa `P::Deref` ug `P::DerefMut`, kung adunay kini.
    /// Labing importante, dili sila kinahanglan nga mobalhin gikan sa ilang `self` argumento: `Pin::as_mut` ug `Pin::as_ref` motawag `DerefMut::deref_mut` ug `Deref::deref` * sa pinned pointer ug magdahum niini nga mga pamaagi aron sa pagtuboy sa pinning invariants.
    /// Labut pa, pinaagi sa pagtawag sa kini nga pamaagi ikaw promise nga ang pakisayran nga `P` dereferensya nga dili ibalhin gikan pag-usab;sa piho nga, kinahanglan dili mahimo nga makakuha usa ka `&mut P::Target` ug pagkahuman mobalhin gikan sa kana nga pakisayran (gamit, pananglitan [`mem::swap`]).
    ///
    ///
    /// Pananglitan, sa pagtawag `Pin::new_unchecked` sa usa ka `&'a mut T` mao ang dili luwas tungod kay samtang ikaw makahimo sa pagbuno niini alang sa gihatag nga tibuok kinabuhi `'a`, ikaw walay kontrol sa kon kini nagbantay sa pinned sa makausa `'a` tumoy:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Kini kinahanglan ipasabut nga ang pointee `a` dili na makalihok pag-usab.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Ang adres sa `a` nabag-o sa stack slot`b`, busa ang `a` nibalhin bisan kung kaniadto pa namon kini gi-pin!Gilapas namon ang kontrata sa pag-pin sa API.
    /////
    /// }
    /// ```
    ///
    /// Ang usa ka kantidad, sa higayon nga ma-pin, kinahanglan magpabilin nga naka-pin hangtod sa hangtod (gawas kung ang tipo niini nagpatuman sa `Unpin`).
    ///
    /// Sa susama, ang pagtawag sa `Pin::new_unchecked` sa usa ka `Rc<T>` dili luwas tungod kay adunay mahimong mga alias sa parehas nga datos nga wala mapailalom sa mga pagdili sa pag-pin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Kini kinahanglan ipasabut nga ang pointee dili na makalihok pag-usab.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Karon, kung ang `x` mao ra ang pakisayran, adunay kami us aka mutable nga pakisayran sa datos nga among gi-pin sa taas, nga mahimo namon gamiton aron mabalhin kini sama sa nakita sa naunang panig-ingnan.
    ///     // Gilapas namon ang kontrata sa pag-pin sa API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Nakakuha us aka naka-pin nga gipaambit nga reperensya gikan sa naka-pin nga pointer.
    ///
    /// Kini mao ang usa ka komon nga paagi sa pag-adto gikan sa `&Pin<Pointer<T>>` ngadto sa `Pin<&T>`.
    /// Kini luwas tungod kay, ingon bahin sa kontrata sa `Pin::new_unchecked`, ang pointee dili makalihok pagkahuman namugna ang `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Ang pagpatuman sa `Pointer::Deref` gisalikway usab sa kontrata sa `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KALUWASAN: tan-awa ang dokumentasyon sa kini nga kalihokan
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Giablihan ang kini nga `Pin<P>` nga nagbalik sa nagpahiping pointer.
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas.Kinahanglan nimo nga garantiyahan nga magpadayon ka sa pagtambal sa pointer `P` ingon nga naka-pin pagkahuman nga gitawag nimo kini nga function, aron ang mga invariants sa `Pin` type mahimo`g mapadayon.
    /// Kung ang code nga gigamit ang sangputanan nga `P` dili magpadayon sa pagpadayon sa mga pag-pin sa invariant nga usa ka paglapas sa kontrata sa API ug mahimong mosangput sa wala matino nga pamatasan sa ulahi nga mga operasyon sa (safe).
    ///
    ///
    /// Kon ang nahiilalum data mao [`Unpin`], [`Pin::into_inner`] kinahanglan nga gamiton sa baylo.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Gets sa usa ka pinned mutable reperensiya gikan niini nga pinned pointer.
    ///
    /// Kini usa ka generic nga pamaagi aron moadto gikan sa `&mut Pin<Pointer<T>>` hangtod `Pin<&mut T>`.
    /// Kini luwas tungod kay, ingon bahin sa kontrata sa `Pin::new_unchecked`, ang pointee dili makalihok pagkahuman namugna ang `Pin<Pointer<T>>`.
    ///
    /// "Malicious" implementar sa sa `Pointer::DerefMut` usab nagmando sa sa sa kontrata sa `Pin::new_unchecked`.
    ///
    /// Mapuslanon kini nga pamaagi kung naghimo daghang tawag sa mga pag-andar nga makonsumo sa pinned type.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // sa pagbuhat sa usa ka butang
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` nag-ut-ot sa `self`, mao nga sublion usab ang `Pin<&mut Self>` pinaagi sa `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KALUWASAN: tan-awa ang dokumentasyon sa kini nga kalihokan
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Mohatag og mga bag-o nga bili sa handumanan sa luyo sa pinned pakisayran.
    ///
    /// Gipunting niini ang naka-pin nga datos, apan kana okay: ang destructor niini gipadagan sa wala pa mapalabi, mao nga wala`y paglapas sa garantiya sa pag-pin.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Naghimo usa ka bag-ong pin pinaagi sa pagmapa sa sulud nga kantidad.
    ///
    /// Pananglitan, kung gusto nimo makakuha og `Pin` nga uma sa usa ka butang, mahimo nimo kini gamiton aron makaadto sa kana nga uma sa usa ka linya sa code.
    /// Bisan pa, adunay daghang mga gotchas sa kini nga "pinning projections";
    /// tan-awa ang [`pin` module] dokumento alang sa dugang detalye sa hilisgutan nga.
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas.
    /// Kinahanglan nimong garantiya nga ang datos nga imong ibalik dili molihok basta wala maglihok ang kantidad sa argumento (pananglitan, tungod kay usa kini sa mga natad sa kana nga kantidad), ug dili usab ka molihok gikan sa argumento nga imong nadawat sa sulod nga function.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KALUWASAN: kinahanglan ang kontrata sa kahilwasan alang sa `new_unchecked`
        // gituboy pinaagi sa caller.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Nakakuha usa ka gipaambit nga reperensya gikan sa usa ka pin.
    ///
    /// Kini luwas tungod kay dili posible nga mobalhin gikan sa usa ka gipaambit nga reperensya.
    /// Mahimo nga adunay ingon usa ka isyu dinhi nga adunay interior mutability: sa tinuud, kini *posible* nga ibalhin ang usa ka `T` gikan sa usa ka `&RefCell<T>`.
    /// Apan, kini mao ang dili usa ka problema nga ingon sa taas nga ingon nga adunay wala usab anaa sa usa ka `Pin<&T>` nagtudlo ngadto sa mao gihapon nga data, ug `RefCell<T>` wala himoa paghimo kaninyo nga usa ka pinned paghisgot sa mga sulod niini.
    ///
    /// Tan-awa ang diskusyon sa ["pinning projections"] alang sa dugang nga mga detalye.
    ///
    /// Note: `Pin` usab nagpatuman `Deref` sa target, nga mahimong gamiton sa pag-access sa mga sulod nga bili.
    /// Bisan pa, ang `Deref` naghatag lamang us aka reperensya nga mabuhi hangtod nga manghulam sa `Pin`, dili sa tibuok kinabuhi nga `Pin` mismo.
    /// Gitugotan kini nga pamaagi nga himuon ang `Pin` nga usa ka pakisayran nga adunay parehas nga kinabuhi sama sa orihinal nga `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Gikabig kini nga `Pin<&mut T>` sa usa ka `Pin<&T>` nga adunay parehas nga kinabuhi.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Nakakuha us aka mutable nga pakisayran sa datos sa sulud niining `Pin`.
    ///
    /// Gikinahanglan nga ang datos sa sulud niining `Pin` mao ang `Unpin`.
    ///
    /// Note: Gipatuman usab sa `Pin` ang `DerefMut` sa datos, nga mahimong magamit aron ma-access ang sulud nga kantidad.
    /// Bisan pa, ang `DerefMut` naghatag lamang us aka reperensya nga mabuhi hangtod nga manghulam sa `Pin`, dili sa tibuok kinabuhi nga `Pin` mismo.
    ///
    /// Gitugotan kini nga pamaagi nga himuon ang `Pin` nga usa ka pakisayran nga adunay parehas nga kinabuhi sama sa orihinal nga `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Nakakuha us aka mutable nga pakisayran sa datos sa sulud niining `Pin`.
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas.
    /// Kamo kinahanglan gayud nga garantiya nga dili gayud kamo mobalhin sa mga data gikan sa mga mutable paghisgot modawat kaninyo sa diha nga magtawag kaninyo niining function, mao nga ang mga invariants sa matang `Pin` mahimong nagtuboy.
    ///
    ///
    /// Kung ang nagpahiping datos mao ang `Unpin`, kinahanglan gamiton hinoon ang `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Paghimo usa ka bag-ong pin pinaagi sa pagmapa sa sulud nga kantidad.
    ///
    /// Pananglitan, kung gusto nimo makakuha og `Pin` nga uma sa usa ka butang, mahimo nimo kini gamiton aron makaadto sa kana nga uma sa usa ka linya sa code.
    /// Bisan pa, adunay daghang mga gotchas sa kini nga "pinning projections";
    /// tan-awa ang [`pin` module] dokumento alang sa dugang detalye sa hilisgutan nga.
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas.
    /// Kinahanglan nimong garantiya nga ang datos nga imong ibalik dili molihok basta wala maglihok ang kantidad sa argumento (pananglitan, tungod kay usa kini sa mga natad sa kana nga kantidad), ug dili usab ka molihok gikan sa argumento nga imong nadawat sa sulod nga function.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KALUWASAN: ang nagtawag responsable sa dili paglihok sa
        // bili gikan sa kini nga pakisayran.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KALUWASAN: ingon ang kantidad nga `this` garantiya nga wala
        // gibalhin, kini nga tawag sa `new_unchecked` luwas.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Pagkuha usa ka pinned nga pakisayran gikan sa usa ka static nga pakisayran.
    ///
    /// Kini luwas, tungod kay ang `T` gihulaman alang sa `'static` tibuok kinabuhi, nga dili matapos.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KALUWASAN: Ang 'static loan garantiya ang datos dili
        // moved/invalidated hangtod nga nahulog kini (nga dili gyud).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Pagkuha usa ka pin na mutable nga pakisayran gikan sa usa ka static mutable nga pakisayran.
    ///
    /// Kini luwas, tungod kay ang `T` gihulaman alang sa `'static` tibuok kinabuhi, nga dili matapos.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KALUWASAN: Ang 'static loan garantiya ang datos dili
        // moved/invalidated hangtod nga nahulog kini (nga dili gyud).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: kini nagpasabot nga ang bisan unsang impl sa `CoerceUnsized` nga nagtugot sa pagpamugos gikan
// usa ka tipo nga nagpasabut `Deref<Target=impl !Unpin>` sa usa ka tipo nga nagpahiwatig nga `Deref<Target=Unpin>` dili maayo.
// Ang bisan unsang ingon nga impl tingali nga dili maayo alang sa uban pang mga hinungdan, bisan pa, busa kinahanglan namon nga mag-amping nga dili tugutan ang mga ingon nga impls nga makalanding sa std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}