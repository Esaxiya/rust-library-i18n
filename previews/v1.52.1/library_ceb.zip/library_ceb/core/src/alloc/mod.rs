//! Mga API sa paggahin sa memorya

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Ang `AllocError` sayop nagpakita sa usa ka alokasyon kapakyasan nga mahimong tungod sa resource kakapoy o sa usa ka butang nga sayop sa diha nga paghiusa sa mga gihatag nga mga argumento input sa allocator niini.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Kita kinahanglan nga kini alang sa ubos impl sa trait sayop)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Ang usa ka pagpatuman sa `Allocator` mahimo paggahin, pagtubo, pagminus, ug pag-deallocate arbitraryong mga bloke sa datos nga gihulagway pinaagi sa [`Layout`][].
///
/// `Allocator` gilaraw nga ipatuman sa mga ZST, pakisayran, o mga smart pointer tungod kay ang adunay usa ka taghatag sama sa `MyAlloc([u8; N])` dili mabalhin, nga wala`y pag-update sa mga panudlo sa gigahin nga memorya.
///
/// Dili sama sa [`GlobalAlloc`][], zero-kadako nga alokasyon mga gitugotan sa `Allocator`.
/// Kung ang usa ka nagpahiping taghatag dili suportahan kini (sama sa jemalloc) o ibalik ang usa ka null pointer (sama sa `libc::malloc`), kinahanglan kini makuha sa pagpatuman.
///
/// ### Karon nga gigahin nga panumduman
///
/// Ang pila sa mga pamaagi nanginahanglan nga ang usa ka memory block *nga karon igahin* pinaagi sa usa ka taghatag.Kini paagi nga:
///
/// * ang pagsugod sa address alang niana nga handumanan block kaniadto mibalik sa [`allocate`], [`grow`], o [`shrink`], ug
///
/// * ang memory block wala`y pagkahuman nga gibalhin, diin ang mga bloke mahimong direkta nga ibalhin pinaagi sa pagpasa sa [`deallocate`] o gibag-o pinaagi sa pagpasa sa [`grow`] o [`shrink`] nga nagbalik sa `Ok`.
///
/// Kon `grow` o `shrink` mibalik `Err`, ang milabay pointer nagpabilin balido.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Pagkuha sa memorya
///
/// Ang pipila sa mga pamaagi nanginahanglan nga ang usa ka layout *angay* usa ka memory block.
/// Kon unsa ang ipasabut sa usa ka Layout sa "fit" sa usa ka handumanan block paagi (o equivalently, alang sa usa ka handumanan block sa "fit" sa usa ka Layout) mao nga ang mosunod nga mga kondisyon kinahanglan nga naghupot:
///
/// * block kinahanglan nga gigahin uban sa sama nga paglaray, pagtalay ingon [`layout.align()`], ug
///
/// * Ang gihatag nga [`layout.size()`] kinahanglan mahulog sa range `min ..= max`, diin:
///   - `min` mao ang kadako sa layout labing bag-o nga gigamit aron sa paggahin ang bloke, ug
///   - `max` mao ang pinaka-ulahing aktuwal nga gidak-on mibalik gikan sa [`allocate`], [`grow`], o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Sag-ulohon nga bloke mibalik gikan sa usa ka allocator kinahanglan nagpunting sa balido panumduman ug magpabilin sa ilang kabalido hangtud sa higayon ug sa tanan nga clones mga nagpatulo,
///
/// * cloning o makapatandog sa allocator kinahanglan dili imbalido handumanan bloke mibalik gikan sa allocator niini.Ang usa ka klon nga taghatag kinahanglan magbuhat sama sa parehas nga tagahatag, ug
///
/// * bisan unsang tudlo sa usa ka memory block nga mao ang [*currently allocated*] mahimong ipasa sa bisan unsang ubang pamaagi sa taghatag.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Mga paningkamot sa paggahin sa usa ka block sa handumanan.
    ///
    /// Sa kalampusan, ibalik ang usa ka [`NonNull<[u8]>`][NonNull] nga miting sa gidak-on ug mga garantiya sa paghanay sa `layout`.
    ///
    /// Ang gibalik nga bloke mahimo nga adunay usa ka labi ka daghan nga gidak-on kaysa sa gipiho sa `layout.size()`, ug mahimo o wala ang mga sulud nga gisugdan.
    ///
    /// # Errors
    ///
    /// Ang pagbalik sa `Err` nagpaila nga nahurot ang bisan unsang memorya o ang `layout` dili katagbo sa gidak-on sa maglalagda o mga pagpugong sa pag-align.
    ///
    /// Giawhag ang mga pagpatuman nga ibalik ang `Err` sa pagkahurot sa memorya kaysa pag-panic o pag-abort, apan dili kini usa ka higpit nga kinahanglanon.
    /// (Piho nga: kini mao ang *legal* sa pagpatuman niini nga trait ibabaw sa usa ka nagpahiping lumad nga alokasyon librarya nga aborts sa panumdoman kakapoy.)
    ///
    /// Kliyente buot sa pagpataktak pagsuma sa tubag sa usa ka sayop alokasyon gidasig sa pagtawag sa [`handle_alloc_error`] function, kay sa direkta pagsangpit `panic!` o susama nga mga.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Ang mga baye sama sa `allocate`, apan gisiguro usab nga ang gibalik nga panumduman zero-initialized.
    ///
    /// # Errors
    ///
    /// Ang pagbalik sa `Err` nagpaila nga nahurot ang bisan unsang memorya o ang `layout` dili katagbo sa gidak-on sa maglalagda o mga pagpugong sa pag-align.
    ///
    /// Giawhag ang mga pagpatuman nga ibalik ang `Err` sa pagkahurot sa memorya kaysa pag-panic o pag-abort, apan dili kini usa ka higpit nga kinahanglanon.
    /// (Piho nga: kini mao ang *legal* sa pagpatuman niini nga trait ibabaw sa usa ka nagpahiping lumad nga alokasyon librarya nga aborts sa panumdoman kakapoy.)
    ///
    /// Kliyente buot sa pagpataktak pagsuma sa tubag sa usa ka sayop alokasyon gidasig sa pagtawag sa [`handle_alloc_error`] function, kay sa direkta pagsangpit `panic!` o susama nga mga.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KALUWASAN: Ang `alloc` mobalik usa ka balido nga memory block
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Gibalhin ang panumduman nga girekomenda sa `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` kinahanglan nga magtimaan usa ka bloke sa memorya [*currently allocated*] pinaagi sa kini nga tagahatag, ug
    /// * `layout` kinahanglan [*fit*] kana nga bloke sa memorya.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pagsulay sa pag-extend sa handumanan block.
    ///
    /// Nagbalik usa ka bag-ong [`NonNull<[u8]>`][NonNull] nga adunay sulud nga pointer ug ang tinuud nga kadako sa gigahin nga panumduman.Ang pointer angay alang sa pagpugong sa datos nga gihulagway sa `new_layout`.
    /// Aron mahimo kini, ang allocator mahimong extend sa alokasyon pakisayran sa `ptr` sa mohaom sa bag-ong layout.
    ///
    /// Kung ibalik kini ang `Ok`, kung ingon niana ang pagpanag-iya sa memory block nga girekomenda sa `ptr` gibalhin sa ninghatag.
    /// panumdoman ang aron o mahimo nga dili na gibuhian, ug kinahanglan nga giisip nga dili na magamit gawas kon kini gibalhin balik ngadto sa caller pag-usab pinaagi sa pagbalik bili sa niini nga paagi.
    ///
    /// Kon kini nga pamaagi mobalik `Err`, nan, pagpanag-iya sa mga block handumanan wala gibalhin ngadto sa allocator niini, ug ang mga sulod sa mga block sa panumduman ang mga Walay kausaban.
    ///
    /// # Safety
    ///
    /// * `ptr` kinahanglan magtumong sa usa ka block sa handumanan [*currently allocated*] pinaagi sa allocator niini.
    /// * `old_layout` kinahanglan [*fit*] kana nga bloke sa memorya (Ang argumento nga `new_layout` dili kinahanglan nga mohaum niini.).
    /// * `new_layout.size()` kinahanglan nga labaw pa kay o katumbas sa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibalik ang `Err` kung ang bag-ong layout dili katagbo sa gidak-on ug paglinya sa mga tagaluwas sa tagahatag, o kung ang pagdako kung dili mapakyas.
    ///
    /// Giawhag ang mga pagpatuman nga ibalik ang `Err` sa pagkahurot sa memorya kaysa pag-panic o pag-abort, apan dili kini usa ka higpit nga kinahanglanon.
    /// (Piho nga: kini mao ang *legal* sa pagpatuman niini nga trait ibabaw sa usa ka nagpahiping lumad nga alokasyon librarya nga aborts sa panumdoman kakapoy.)
    ///
    /// Kliyente buot sa pagpataktak pagsuma sa tubag sa usa ka sayop alokasyon gidasig sa pagtawag sa [`handle_alloc_error`] function, kay sa direkta pagsangpit `panic!` o susama nga mga.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: tungod kay `new_layout.size()` kinahanglan mas dako pa kay sa o katumbas sa
        // `old_layout.size()`, ang mga tigulang ug bag-o nga handumanan alokasyon mga balido alang sa mabasa ug misulat alang sa `old_layout.size()` bytes.
        // Ingon usab, tungod kay ang daan nga alokasyon wala pa makalihok, dili kini mahimong magsapaw sa `new_ptr`.
        // Sa ingon, ang tawag sa `copy_nonoverlapping` luwas.
        // Ang kontrata sa kahilwasan alang sa `dealloc` kinahanglan nga ipadayon sa nanawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ang mga baye sama sa `grow`, apan gisiguro usab nga ang mga bag-ong sulud gitakda sa zero sa wala pa ibalik.
    ///
    /// Ang memory block magbaton sa mga mosunud nga sulud pagkahuman sa usa ka malampuson nga tawag sa
    /// `grow_zeroed`:
    ///   * Ang Bytes `0..old_layout.size()` gitipigan gikan sa orihinal nga paggahin.
    ///   * Ang Bytes `old_layout.size()..old_size` mahimong mapreserba o ma-zero, depende sa pagpatuman sa taghatag.
    ///   `old_size` nagtumong sa gidak-on sa block sa panumduman sa wala pa ang `grow_zeroed` tawag, nga mahimong mas dako pa kay sa gidak-on nga orihinal nga gihangyo sa diha nga kini gigahin.
    ///   * Bytes `old_size..new_size` mga zeroed.Ang `new_size` nagtumong sa kadako sa memory block nga gibalik sa tawag nga `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` kinahanglan magtumong sa usa ka block sa handumanan [*currently allocated*] pinaagi sa allocator niini.
    /// * `old_layout` kinahanglan [*fit*] kana nga bloke sa memorya (Ang argumento nga `new_layout` dili kinahanglan nga mohaum niini.).
    /// * `new_layout.size()` kinahanglan nga labaw pa kay o katumbas sa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibalik ang `Err` kung ang bag-ong layout dili katagbo sa gidak-on ug paglinya sa mga tagaluwas sa tagahatag, o kung ang pagdako kung dili mapakyas.
    ///
    /// Giawhag ang mga pagpatuman nga ibalik ang `Err` sa pagkahurot sa memorya kaysa pag-panic o pag-abort, apan dili kini usa ka higpit nga kinahanglanon.
    /// (Piho nga: kini mao ang *legal* sa pagpatuman niini nga trait ibabaw sa usa ka nagpahiping lumad nga alokasyon librarya nga aborts sa panumdoman kakapoy.)
    ///
    /// Kliyente buot sa pagpataktak pagsuma sa tubag sa usa ka sayop alokasyon gidasig sa pagtawag sa [`handle_alloc_error`] function, kay sa direkta pagsangpit `panic!` o susama nga mga.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: tungod kay `new_layout.size()` kinahanglan mas dako pa kay sa o katumbas sa
        // `old_layout.size()`, ang mga tigulang ug bag-o nga handumanan alokasyon mga balido alang sa mabasa ug misulat alang sa `old_layout.size()` bytes.
        // Ingon usab, tungod kay ang daan nga alokasyon wala pa makalihok, dili kini mahimong magsapaw sa `new_ptr`.
        // Sa ingon, ang tawag sa `copy_nonoverlapping` luwas.
        // Ang kontrata sa kahilwasan alang sa `dealloc` kinahanglan nga ipadayon sa nanawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mga pagsulay sa pagminus sa memory block.
    ///
    /// Nagbalik usa ka bag-ong [`NonNull<[u8]>`][NonNull] nga adunay sulud nga pointer ug ang tinuud nga kadako sa gigahin nga panumduman.Ang pointer angay alang sa pagpugong sa datos nga gihulagway sa `new_layout`.
    /// Aron matuman kini, ang tighatag mahimo nga maghinay ang alokasyon nga girekomenda sa `ptr` aron mohaum sa bag-ong layout.
    ///
    /// Kung ibalik kini ang `Ok`, kung ingon niana ang pagpanag-iya sa memory block nga girekomenda sa `ptr` gibalhin sa ninghatag.
    /// panumdoman ang aron o mahimo nga dili na gibuhian, ug kinahanglan nga giisip nga dili na magamit gawas kon kini gibalhin balik ngadto sa caller pag-usab pinaagi sa pagbalik bili sa niini nga paagi.
    ///
    /// Kon kini nga pamaagi mobalik `Err`, nan, pagpanag-iya sa mga block handumanan wala gibalhin ngadto sa allocator niini, ug ang mga sulod sa mga block sa panumduman ang mga Walay kausaban.
    ///
    /// # Safety
    ///
    /// * `ptr` kinahanglan magtumong sa usa ka block sa handumanan [*currently allocated*] pinaagi sa allocator niini.
    /// * `old_layout` kinahanglan [*fit*] kana nga bloke sa memorya (Ang argumento nga `new_layout` dili kinahanglan nga mohaum niini.).
    /// * `new_layout.size()` kinahanglan nga mas gamay kaysa o katumbas sa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibalik ang `Err` kung ang bag-ong layout dili katagbawan sa gidak-on ug paglinya sa mga limitasyon sa tagahatag, o kung ang pagkubus kung dili mapakyas.
    ///
    /// Giawhag ang mga pagpatuman nga ibalik ang `Err` sa pagkahurot sa memorya kaysa pag-panic o pag-abort, apan dili kini usa ka higpit nga kinahanglanon.
    /// (Piho nga: kini mao ang *legal* sa pagpatuman niini nga trait ibabaw sa usa ka nagpahiping lumad nga alokasyon librarya nga aborts sa panumdoman kakapoy.)
    ///
    /// Kliyente buot sa pagpataktak pagsuma sa tubag sa usa ka sayop alokasyon gidasig sa pagtawag sa [`handle_alloc_error`] function, kay sa direkta pagsangpit `panic!` o susama nga mga.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: tungod kay `new_layout.size()` kinahanglan ubos sa o katumbas sa
        // `old_layout.size()`, pareho ang daan ug bag-ong alokasyon sa memorya nga balido alang sa pagbasa ug pagsulat alang sa `new_layout.size()` bytes.
        // Ingon usab, tungod kay ang daan nga alokasyon wala pa makalihok, dili kini mahimong magsapaw sa `new_ptr`.
        // Sa ingon, ang tawag sa `copy_nonoverlapping` luwas.
        // Ang kontrata sa kahilwasan alang sa `dealloc` kinahanglan nga ipadayon sa nanawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Nagmugna sa usa ka "by reference" adapter alang niini nga pananglitan sa `Allocator`.
    ///
    /// Ang mibalik adapter usab implementar `Allocator` ug lamang manghulam niini.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KALUWASAN: ang kontrata sa kahilwasan kinahanglan nga ipadayon sa nanawag
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALUWASAN: ang kontrata sa kahilwasan kinahanglan nga ipadayon sa nanawag
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALUWASAN: ang kontrata sa kahilwasan kinahanglan nga ipadayon sa nanawag
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALUWASAN: ang kontrata sa kahilwasan kinahanglan nga ipadayon sa nanawag
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}