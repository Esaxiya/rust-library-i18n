/// Gigamit alang sa operasyon sa pag-indeks (`container[index]`) sa dili mabalhin nga mga konteksto.
///
/// `container[index]` sa tinuud nga syntactic sugar alang sa `*container.index(index)`, apan kung gigamit ingon usa ka dili mabalhin nga kantidad.
/// Kung gihangyo ang usa ka mutable nga kantidad, gigamit hinoon ang [`IndexMut`].
/// Kini nagtugot sa nindot nga mga butang sama sa `let value = v[index]` kon ang matang sa `value` implementar [`Copy`].
///
/// # Examples
///
/// Ang mosunud nga panig-ingnan nagpatuman sa `Index` sa usa ka mabasa nga `NucleotideCount` lamang nga sulud, nga makahimo sa indibidwal nga mga ihap nga makuha uban ang index syntax.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Ang mibalik nga matang human sa pag-indeks.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Gihimo ang operasyon sa (`container[index]`) sa pag-indeks.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Gigamit alang sa mga operasyon sa pag-indeks (`container[index]`) sa mabalhin nga mga konteksto.
///
/// `container[index]` sa tinuud nga syntactic sugar alang sa `*container.index_mut(index)`, apan kung gigamit ingon usa ka mutable nga kantidad.
/// Kung gihangyo ang usa ka dili mabalhin nga kantidad, gigamit na hinoon ang [`Index`] trait.
/// Gitugotan niini ang mga maayong butang sama sa `v[index] = value`.
///
/// # Examples
///
/// Usa ka yano kaayo nga pagpatuman sa usa ka `Balance` nga istruktura nga adunay duha nga kilid, diin ang matag usa mahimo`g ma-indeks nga mabalhin ug dili mabalhin.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Sa kini nga kaso, ang `balance[Side::Right]` asukal alang sa `*balance.index(Side::Right)`, tungod kay* nagbasa ra kami * `balance[Side::Right]`, dili kini gisulat.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Bisan pa, sa kini nga kaso ang `balance[Side::Left]` asukal alang sa `*balance.index_mut(Side::Left)`, tungod kay nagsulat kami nga `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Gihimo ang mabalhin nga operasyon sa (`container[index]`) nga mabalhin.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}