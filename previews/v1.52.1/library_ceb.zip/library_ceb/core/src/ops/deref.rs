/// Gigamit alang sa dili mabalhin nga operasyon sa dereferencing, sama sa `*v`.
///
/// Gawas nga gigamit alang sa tin-aw nga operasyon sa dereferencing sa (unary) `*` operator sa dili mabalhin nga mga konteksto, ang `Deref` gigamit usab nga implicit sa tagtipon sa daghang mga kahimtang.
/// Ang kini nga mekanismo gitawag nga ['`Deref` coercion'][more].
/// Sa mga mutable konteksto, gigamit ang [`DerefMut`].
///
/// Implementing `Deref` alang sa Smart pointers naghimo access sa mga data sa luyo nila sayon, nga mao ang ngano nga sila pagpatuman `Deref`.
/// Sa pikas nga bahin, ang mga lagda bahin sa `Deref` ug [`DerefMut`] piho nga gidisenyo aron mapaigo ang mga smart point.
/// Tungod niini, ang **`Deref` kinahanglan ipatuman lamang alang sa mga smart pointer** aron malikayan ang pagkalibog.
///
/// Alang sa parehas nga mga hinungdan,**kini trait kinahanglan dili mapakyas**.Kapakyasan sa panahon sa dereferencing mahimong hilabihan sa paglahugay sa diha nga `Deref` ang gisangpit bug-os.
///
/// # Labi pa sa pagpamugos sa `Deref`
///
/// Kung gipatuman sa `T` ang `Deref<Target = U>`, ug ang `x` usa ka kantidad sa tipo nga `T`, nan:
///
/// * Sa dili mabalhin nga mga konteksto, ang `*x` (diin ang `T` dili usa ka pakisayran ni usa ka hilaw nga pahimangno) katumbas sa `* Deref::deref(&x)`.
/// * Ang mga mithi sa tipo nga `&T` gipugos sa mga kantidad nga lahi nga `&U`
/// * `T` implicit nga nagpatuman sa tanan nga (immutable) nga pamaagi sa tipo nga `U`.
///
/// Alang sa dugang nga mga detalye, bisitaha ang [the chapter in *The Rust Programming Language*][book] maingon man ang mga seksyon sa pakisayran sa [the dereference operator][ref-deref-op], [method resolution] ug [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Usa ka istruktura nga adunay us aka uma nga mahimo`g ma-access pinaagi sa pag-undang sa istruktura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ang resulta matang human sa dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Mga Dereferensya ang kantidad.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Gigamit alang sa mabalhin nga mga operasyon sa pagdemensa, sama sa `*v = 1;`.
///
/// Gawas nga gigamit alang sa tin-aw nga operasyon sa dereferencing uban ang (unary) `*` operator sa mga mutable konteksto, ang `DerefMut` gigamit usab nga implicit sa tagtipon sa daghang mga kahimtang.
/// Ang kini nga mekanismo gitawag nga ['`Deref` coercion'][more].
/// Sa dili mabalhin nga mga konteksto, gigamit ang [`Deref`].
///
/// Implementing `DerefMut` alang sa Smart pointers naghimo mutating sa mga data sa luyo nila sayon, nga mao ang ngano nga sila pagpatuman `DerefMut`.
/// Sa pikas nga bahin, ang mga lagda bahin sa [`Deref`] ug `DerefMut` piho nga gidisenyo aron mapaigo ang mga smart point.
/// Tungod niini, ang **`DerefMut` kinahanglan lang ipatuman alang sa mga smart pointer** aron malikayan ang pagkalibog.
///
/// Alang sa parehas nga mga hinungdan,**kini trait kinahanglan dili mapakyas**.Kapakyasan sa panahon sa dereferencing mahimong hilabihan sa paglahugay sa diha nga `DerefMut` ang gisangpit bug-os.
///
/// # Labi pa sa pagpamugos sa `Deref`
///
/// Kung gipatuman sa `T` ang `DerefMut<Target = U>`, ug ang `x` usa ka kantidad sa tipo nga `T`, nan:
///
/// * Sa mabalhin nga mga konteksto, ang `*x` (diin ang `T` dili usa ka pakisayran ni usa ka hilaw nga pahimangno) katumbas sa `* DerefMut::deref_mut(&mut x)`.
/// * Ang mga mithi sa tipo nga `&mut T` gipugos sa mga kantidad nga lahi nga `&mut U`
/// * `T` implicit nga nagpatuman sa tanan nga (mutable) nga pamaagi sa tipo nga `U`.
///
/// Alang sa dugang nga mga detalye, bisitaha ang [the chapter in *The Rust Programming Language*][book] maingon man ang mga seksyon sa pakisayran sa [the dereference operator][ref-deref-op], [method resolution] ug [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Usa ka magtukod sa usa ka ka uma nga mao ang usbon pinaagi sa dereferencing sa magtukod.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Masubli nga pag-undang sa bili.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Gipasabut nga ang usa ka istruktura mahimong magamit ingon usa ka pamaagi nga tigdawat, nga wala ang `arbitrary_self_types` nga bahin.
///
/// Gipatuman kini sa mga tipo sa stdlib sama sa `Box<T>`, `Rc<T>`, `&T`, ug `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}