/// Usa ka trait alang sa pagpasadya sa pamatasan sa `?` operator.
///
/// Ang usa ka tipo nga pagpatuman sa `Try` usa nga adunay kanonikal nga paagi aron kini makit-an sa mga termino sa usa ka success/failure dichotomy.
/// Gitugotan niini nga trait ang parehas nga pagkuha sa mga kantidad sa kalampusan o pagkapakyas gikan sa usa ka na nga pananglitan ug paghimo sa usa ka bag-ong pananglitan gikan sa usa ka sangputanan sa tagumpay o pagkapakyas.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ang lahi sa kini nga kantidad kung tan-awon nga malampuson.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ang lahi sa kini nga kantidad kung tan-awon nga napakyas.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Nag-apply sa "?" operator.Ang pagbalik sa `Ok(t)` nagpasabot nga ang pagpatuman kinahanglan magpadayon nga normal, ug ang sangputanan sa `?` mao ang kantidad `t`.
    /// Ang pagbalik sa `Err(e)` nagpasabot nga ang pagpatuman kinahanglan branch sa kinasulorang sulud nga enclosed `catch`, o pagbalik gikan sa pagpaandar.
    ///
    /// Kung ang usa ka resulta nga `Err(e)` ibalik, ang kantidad nga `e` mahimong "wrapped" sa pagbalik nga tipo sa sakop nga sakup (nga kinahanglan ipatuman mismo sa `Try`).
    ///
    /// Sa piho nga paagi, ang kantidad `X::from_error(From::from(e))` gibalik, diin ang `X` mao ang pagbalik nga tipo sa paglakip sa pagpaandar.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wrap sa usa ka sayop nga bili sa pagtukod sa composite resulta.
    /// Pananglitan, ang `Result::Err(x)` ug `Result::from_error(x)` managsama.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Pagputos usa ka OK nga kantidad aron matukod ang sagol nga sangputanan.
    /// Pananglitan, ang `Result::Ok(x)` ug `Result::from_ok(x)` managsama.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}