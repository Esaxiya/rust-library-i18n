use crate::marker::Unpin;
use crate::pin::Pin;

/// Ang resulta sa usa ka generator pagpadayon.
///
/// Ang kini nga enum gibalik gikan sa pamaagi nga `Generator::resume` ug gipakita ang posible nga mga kantidad nga ibalik sa usa ka generator.
/// Karon kini katumbas sa bisan hain sa usa ka suspensyon nga punto (`Yielded`) o usa ka pagtapos nga punto (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Ang generator gisuspinde nga adunay kantidad.
    ///
    /// Gipakita sa kini nga estado nga ang usa ka generator gisuspinde, ug kasagarang katugbang sa usa ka pahayag nga `yield`.
    /// Ang bili nga gihatag sa niini nga laing kaangay sa ekspresyon miagi sa `yield` ug nagtugot generators sa paghatag sa usa ka bili sa matag panahon nga sila mohatag.
    ///
    ///
    Yielded(Y),

    /// Natapos ang generator nga adunay kantidad nga ibalik.
    ///
    /// Gipakita sa kini nga estado nga ang usa ka generator nakatapos sa pagpatuman nga adunay gihatag nga kantidad.
    /// Sa higayon nga ang usa ka generator nga mibalik `Complete` kini gikonsiderar nga usa ka programmer sayop sa pagtawag sa `resume` pag-usab.
    ///
    Complete(R),
}

/// Ang trait gipatuman sa matang builtin generator.
///
/// Ang mga generator, nga sagad gitawag usab nga mga coroutine, karon usa ka eksperimentong bahin sa sinultian sa Rust.
/// Gidugang sa mga generator nga [RFC 2033] karon nga gituyo aron labi nga maghatag usa ka bloke sa pagtukod alang sa async/await syntax apan lagmit molugway usab sa paghatag usa ka kahulugan nga ergonomic alang sa mga iterator ug uban pang mga pasiuna.
///
///
/// Ang syntax ug mga semantiko alang sa generator mao ang mabalhinon ug nagkinahanglan sa usa ka dugang nga RFC alang sa stabilization.Hinuon, sa kini nga oras, ang syntax sama sa pagsira:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Daghang mga dokumentasyon sa mga generator ang makit-an sa dili lig-on nga libro.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Ang matang sa bili niini nga generator makahatag.
    ///
    /// Kini nakig matang kaangay sa `yield` ekspresyon ug mga mithi nga gitugotan nga mibalik sa matag higayon nga ang usa ka generator abot.
    ///
    /// Pananglitan usa ka iterator-as-a-generator ang mahimo`g adunay kini nga klase ingon `T`, ang tipo nga giulit.
    ///
    type Yield;

    /// Ang lahi sa kantidad nga ningbalik sa kini nga generator.
    ///
    /// Kini kaangay sa matang mibalik gikan sa usa ka generator sa bisan uban sa usa ka `return` pamahayag o bug-os ingon nga ang katapusan nga pagpahayag sa usa ka generator literal.
    /// Pananglitan ang futures gamiton kini ingon `Result<T, E>` tungod kay kini nagrepresentar sa usa ka nahuman nga future.
    ///
    ///
    type Return;

    /// Nagpadayon sa pagpatuman sa kini nga generator.
    ///
    /// Kini nga pag-andar magpadayon sa pagpatuman sa generator o magsugod sa pagpatuman kung wala pa kini mahimo.
    /// Ang kini nga tawag mobalik sa katapusan nga punto sa suspensyon sa generator, nga ipadayon ang pagpatuman gikan sa labing bag-ong `yield`.
    /// Ang generator magpadayon sa pagpatuman hangtod kini magbunga o mobalik, sa oras nga kini nga kalihokan mobalik.
    ///
    /// # Bumalik bili
    ///
    /// Ang `GeneratorState` enum nga gibalik gikan sa kini nga pag-andar nagpaila kung unsang estado ang generator sa pagbalik.
    /// Kung ang `Yielded` variant ibalik unya ang generator nakaabut sa usa ka punto nga suspensyon ug usa ka kantidad nga nakuha.
    /// Ang mga generator sa kini nga estado magamit alang sa pagpadayon sa ulahi nga punto.
    ///
    /// Kung ang `Complete` ibalik unya ang generator nakompleto nga nahuman sa gihatag nga kantidad.Dili balido alang sa generator nga ipadayon pag-usab.
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar mahimo og panic kung kini gitawag pagkahuman nga ang `Complete` nga lahi naibalik kaniadto.
    /// Samtang ang mga literals sa generator sa sinultian gigarantiyahan nga panic sa pagpadayon pagkahuman sa `Complete`, dili kini gigarantiyahan alang sa tanan nga pagpatuman sa `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}