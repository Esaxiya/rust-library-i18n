use crate::marker::Unsize;

/// Trait nga nagpakita nga kini mao ang usa ka pointer o sa usa ka panapton alang sa usa, diin unsizing nga gihimo sa pointee.
///
/// Tan-awa ang [DST coercion RFC][dst-coerce] ug [the nomicon entry on coercion][nomicon-coerce] alang sa dugang nga mga detalye.
///
/// Alang sa mga builtin pointer type, ang mga pointers sa `T` mapugos sa mga pointers sa `U` kung `T: Unsize<U>` pinaagi sa pag-convert gikan sa usa ka nipis nga pointer ngadto sa usa ka fat pointer.
///
/// Alang sa mga naandan nga lahi, ang pagpamugos dinhi molihok pinaagi sa pagpugos sa `Foo<T>` hangtod `Foo<U>` nga gihatag usa ka impl nga `CoerceUnsized<Foo<U>> for Foo<T>` anaa.
/// Ang ingon nga usa ka impl mahimo lamang isulat kung ang `Foo<T>` adunay usa ra nga dili phantomdata nga natad nga naglambigit sa `T`.
/// Kung ang lahi sa kana nga uma mao ang `Bar<T>`, kinahanglan adunay usa ka pagpatuman sa `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Ang pagpamugos molihok pinaagi sa pagpugos sa `Bar<T>` field ngadto sa `Bar<U>` ug pagpuno sa nahabilin nga mga uma gikan sa `Foo<T>` aron makahimo usa ka `Foo<U>`.
/// Epektibo kini nga mag-drill sa usa ka pointer field ug pugson kana.
///
/// Sa kasagaran, alang sa mga smart pointers ipatuman nimo ang `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, nga adunay usa ka kapilian nga `?Sized` nga gihigot sa `T` mismo.
/// Alang sa mga tipo sa pambalot nga direkta nga gisulud ang `T` sama sa `Cell<T>` ug `RefCell<T>`, mahimo nimo nga direktang ipatuman ang `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Tugotan niini ang pagpugos sa mga klase sama sa `Cell<Box<T>>` nga molihok.
///
/// [`Unsize`][unsize] gigamit aron markahan ang mga tipo nga mahimong pugson sa mga DST kung naa sa likod sa mga panudlo.Kini gipatuman nga awtomatiko sa tagtipon.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *Mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Gigamit kini alang sa kahilwasan sa butang, aron masusi kung ang matang sa tigdawat sa usa ka pamaagi mahimong ipadala.
///
/// Usa ka pananglitan sa pagpatuman sa trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}