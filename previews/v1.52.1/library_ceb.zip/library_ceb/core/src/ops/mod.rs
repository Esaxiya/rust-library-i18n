//! Sobra kadali nga mga operator.
//!
//! Ang pagpatuman sa kini nga traits nagtugot kanimo nga mag-overload sa pipila ka mga operator.
//!
//! Ang pipila sa mga kini nga traits gi-import sa prelude, busa magamit kini sa matag programa nga Rust.Ang mga operator ra nga gisuportahan sa traits ang mahimong sobra ang karga.
//! Pananglitan, ang madugangan nga operator (`+`) mahimong sobra nga ma-overload pinaagi sa [`Add`] trait, apan tungod kay ang operator sa asaynment nga (`=`) wala`y nagpaluyo sa trait, wala`y paagi nga mag-overload ang mga semantiko niini.
//! Dugang pa, module kini wala paghatag og bisan unsa nga mekanismo sa paghimo sa bag-ong mga operators.
//! Kung kinahanglan ang traitless overloading o custom operator, kinahanglan nimo nga tan-awon ang mga macros o compiler plugins aron mapalapdan ang syntax sa Rust.
//!
//! Ang mga pagpatuman sa operator traits kinahanglan dili katingad-an sa ilang tagsatagsa nga mga konteksto, nga hinumduman ang ilang naandan nga gipasabut ug [operator precedence].
//! Pananglitan, kung gipatuman ang [`Mul`], ang operasyon kinahanglan adunay kaamgiran sa pagpadaghan (ug pagpaambit sa gipaabut nga mga kabtangan sama sa pagkaugnayan).
//!
//! Hinumdomi nga ang `&&` ug `||` operator mubu sa circuit, ie, gisusi ra nila ang ilang ikaduhang operand kung nakatampo kini sa sangputanan.Tungod kay ang kini nga pamatasan dili mapatuman sa traits, ang `&&` ug `||` dili gisuportahan ingon daghang mga operator.
//!
//! Daghan sa mga operator ang naghatag bili sa ilang mga opera.Sa mga dili kinatibuk-ang konteksto nga naglambigit sa mga built-in nga tipo, sa kasagaran dili kini problema.
//! Bisan pa, ang paggamit sa kini nga mga operator sa generic code, nanginahanglan pipila nga atensyon kung ang mga kantidad kinahanglan gamiton pag-usab sukwahi sa pagtugot sa mga operator nga mangaut-ut kanila.Ang usa ka kapilian mao ang panagsang paggamit sa [`clone`].
//! Ang laing kapilian mao ang pagsalig sa mga lahi nga nalakip sa paghatag dugang nga pagpatuman sa operator alang sa mga pakisayran.
//! Pananglitan, alang sa usa ka gihubit sa tiggamit nga `T` nga gituohan nga pagsuporta sa pagdugang, tingali maayo nga ideya nga ipatuman ang parehas nga `T` ug `&T` ang traits [`Add<T>`][`Add`] ug [`Add<&T>`][`Add`] aron ang generic code mahimong isulat nga wala kinahanglan nga cloning.
//!
//!
//! # Examples
//!
//! Ang kini nga pananglitan naghimo sa usa ka `Point` nga istraktura nga nagpatuman sa [`Add`] ug [`Sub`], ug pagkahuman gipakita ang pagdugang ug pagminus sa duha nga `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Tan-awa ang dokumentasyon alang sa matag trait alang sa usa ka pananglitan nga pagpatuman.
//!
//! Ang [`Fn`], [`FnMut`], ug [`FnOnce`] traits gipatuman sa mga tipo nga mahimong ipangayo sama sa mga gimbuhaton.Hinumdomi nga ang [`Fn`] nagkinahanglan `&self`, [`FnMut`] nagkinahanglan `&mut self` ug [`FnOnce`] nagkinahanglan `self`.
//! Nahiuyon kini sa tulo nga lahi nga mga pamaagi nga mahimo`g ipangayo sa usa ka pananglitan: call-by-refer, call-by-mutable-refer, ug call-by-value.
//! Ang labing naandan nga paggamit sa mga traits mao ang paglihok ingon mga utlanan sa labi ka taas nga lebel nga gimbuhaton nga magkuha mga gimbuhaton o pagsira ingon mga lantugi.
//!
//! Pagkuha usa ka [`Fn`] ingon usa ka parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Pagkuha usa ka [`FnMut`] ingon usa ka parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Pagkuha sa usa ka [`FnOnce`] ingon sa usa ka sukaranan:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` nag-ut-ut sa mga nakuha nga baryable, busa dili kini mahimong ipadagan labaw pa sa usa ka beses
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ang pagsulay sa pagsangpit sa `func()` pag-usab maglabay usa ka `use of moved value` nga sayup alang sa `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` dili na mahimong tawgon sa kini nga punto
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;