/// Ang bersyon sa operator sa tawag nga nagkinahanglan dili mabalhin nga tigdawat.
///
/// Higayon sa `Fn` mahimong gitawag balik-balik nga walay mutating estado.
///
/// *Kini nga trait (`Fn`) dili malibug sa [function pointers] (`fn`).*
///
/// `Fn` awtomatikong-implementar sa closures nga lamang sa pagkuha sa dili mausab nga mga pakisayran sa nabihag baryable o sa pagbuhat sa dili pagkadakop sa bisan unsa sa tanan, ingon man usab sa (safe) [function pointers] (uban sa pipila caveats, tan-awa ang ilang mga dokumento alang sa dugang detalye).
///
/// Dugang pa, alang sa bisan unsang tipo nga `F` nga nagpatuman sa `Fn`, gipatuman usab sa `&F` ang `Fn`.
///
/// Tungod kay ang duha [`FnMut`] ug [`FnOnce`] mga supertraits sa `Fn`, sa bisan unsa nga higayon sa `Fn` mahimong gamiton ingon nga usa ka sukaranan diin ang usa ka [`FnMut`] o [`FnOnce`] gilauman.
///
/// Paggamit `Fn` ingon usa ka gigapos kung gusto nimo nga dawaton ang usa ka parameter nga sama sa pagpaandar sa tipo ug kinahanglan nga kini tawgon og balik-balik ug wala`y mutating estado (pananglitan, kung dungan nga pagtawag niini).
/// Kung dili nimo kinahanglan ang ingon ka higpit nga mga kinahanglanon, gamita ang [`FnMut`] o [`FnOnce`] ingon mga utlanan.
///
/// Tan-awa ang [chapter on closures in *The Rust Programming Language*][book] alang sa pipila pa nga kasayuran bahin sa kini nga hilisgutan.
///
/// Usab sa mubo nga sulat mao ang espesyal nga syntax alang sa `Fn` traits (eg
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal nga detalye niini mahimo nga magtumong sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nagtawag pagsira
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Paggamit usa ka parameter nga `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aron nga regex makasalig nga `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Gihimo ang operasyon sa pagtawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Ang bersyon sa operator sa tawag nga nagkinahanglan us aka mutable receiver.
///
/// Ang mga hitabo nga `FnMut` mahimong tawgon nga balik-balik ug mahimong mutate nga estado.
///
/// `FnMut` awtomatiko nga gipatuman pinaagi sa mga pagsira nga nagkuha mga mutable referensya sa mga nakuha nga variable, maingon man ang tanan nga mga lahi nga nagpatuman sa [`Fn`], pananglitan, (safe) [function pointers] (tungod kay ang `FnMut` usa ka supertrait nga [`Fn`]).
/// Dugang pa, alang sa bisan unsang tipo nga `F` nga nagpatuman sa `FnMut`, gipatuman usab sa `&mut F` ang `FnMut`.
///
/// Tungod kay ang [`FnOnce`] usa ka supertrait nga `FnMut`, ang bisan unsang pananglitan sa `FnMut` mahimong magamit diin gipaabut ang [`FnOnce`], ug tungod kay ang [`Fn`] usa ka subtrait nga `FnMut`, ang bisan unsang pananglitan sa [`Fn`] mahimong magamit diin gipaabot ang `FnMut`.
///
/// Paggamit `FnMut` ingon sa usa ka utlanan sa diha nga kamo gusto sa pagdawat sa usa ka sukaranan sa function-sama sa matang ug sa panginahanglan sa pagtawag niini balik-balik, samtang sa pagtugot niini sa motransporm kahimtang.
/// Kung dili nimo gusto ang parameter nga mutate estado, gamita ang [`Fn`] ingon usa ka gigapos;kon kamo dili kinahanglan sa pagtawag niini balik-balik, sa paggamit sa [`FnOnce`].
///
/// Tan-awa ang [chapter on closures in *The Rust Programming Language*][book] alang sa pipila pa nga kasayuran bahin sa kini nga hilisgutan.
///
/// Usab sa mubo nga sulat mao ang espesyal nga syntax alang sa `Fn` traits (eg
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal nga detalye niini mahimo nga magtumong sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nagatawag sa usa ka mutably pagdakop closure
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Paggamit usa ka parameter nga `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aron nga regex makasalig nga `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Gihimo ang operasyon sa pagtawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Ang bersyon sa operator sa tawag nga nagkinahanglan usa ka hatagan nga hatagan bili.
///
/// Ang mga hitabo nga `FnOnce` mahimong tawagan, apan tingali dili kini matawag sa daghang mga higayon.Tungod niini, kon ang bugtong butang nga nahibaloan bahin sa usa ka matang mao nga kini nagpatuman `FnOnce`, kini mahimo lamang nga gitawag sa makausa.
///
/// `FnOnce` awtomatiko nga gipatuman sa mga pagsira nga mahimong mag-ut-ut nga nakuha nga mga variable, maingon man ang tanan nga lahi nga nagpatuman sa [`FnMut`], pananglitan, (safe) [function pointers] (tungod kay ang `FnOnce` usa ka supertrait nga [`FnMut`]).
///
///
/// Tungod kay ang parehas nga [`Fn`] ug [`FnMut`] mga subtrait nga `FnOnce`, ang bisan unsang pananglitan sa [`Fn`] o [`FnMut`] mahimong magamit diin gipaabut ang `FnOnce`.
///
/// Paggamit `FnOnce` ingon usa ka gigapos kung gusto nimo nga dawaton ang usa ka parameter nga sama sa pagpaandar sa tipo ug kinahanglan lang nimo kini tawgon kausa.
/// Kon imong gikinahanglan aron sa pagtawag sa mga sukaranan sa balik-balik, sa paggamit sa [`FnMut`] ingon sa usa ka utlanan;kung kinahanglan nimo usab kini aron dili ma-mutate ang estado, gamita ang [`Fn`].
///
/// Tan-awa ang [chapter on closures in *The Rust Programming Language*][book] alang sa pipila pa nga kasayuran bahin sa kini nga hilisgutan.
///
/// Usab sa mubo nga sulat mao ang espesyal nga syntax alang sa `Fn` traits (eg
/// `Fn(usize, bool) -> usize`).Ang mga interesado sa mga teknikal nga detalye niini mahimo nga magtumong sa [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Paggamit usa ka parameter nga `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ut sa iyang nadakpan baryable, mao nga kini dili mahimong modagan nga labaw pa kay sa makausa.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ang pagsulay sa pagsangpit sa `func()` pag-usab maglabay usa ka `use of moved value` nga sayup alang sa `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` dili na mahimong tawgon sa kini nga punto
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aron nga regex makasalig nga `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Ang mibalik matang human sa operator tawag gigamit.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Gihimo ang operasyon sa pagtawag.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}