//! Ang `Default` trait alang sa matang nga adunay makahuluganon nga mga prinsipyo sa default.

#![stable(feature = "rust1", since = "1.0.0")]

/// Usa ka trait alang sa paghatag sa usa ka matang sa usa ka mapuslanon nga default bili.
///
/// Usahay, gusto nimo mahibalik sa usa ka klase nga default nga bili, ug dili nimo igsapayan kung unsa kini.
/// Kanunay kini nga moabut uban ang `mga istruktura nga nagpasabut sa usa ka hugpong nga kapilian:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Unsa nga paagi kita nagpaila sa pipila remate mga hiyas?Mahimo nimo gamiton ang `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Karon, kamo og sa tanan sa mga mithi default.Ang Rust nagpatuman sa `Default` alang sa lainlaing mga klase sa primitibo.
///
/// Kung gusto nimong ipatigbabaw ang usa ka piho nga kapilian, apan ipadayon ang ubang mga default:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Kini nga trait mahimong gamiton uban sa `#[derive]` kon ang tanan nga mga kaumahan sa matang sa pagpatuman `Default`.
/// Sa diha nga `derive`d, kini gamiton sa default bili alang sa matang sa matag uma ni.
///
/// ## Unsaon nako pagpatuman ang `Default`?
///
/// Paghatag usa ka pagpatuman alang sa `default()` nga pamaagi nga ibalik ang kantidad sa imong tipo nga kinahanglan mahimong default:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Gibalik ang "default value" alang sa usa ka lahi.
    ///
    /// Ang mga default nga kantidad kanunay usa ka klase nga inisyal nga kantidad, bili sa pag-ila, o uban pa nga mahimong adunay kahulugan ingon usa ka default.
    ///
    ///
    /// # Examples
    ///
    /// Paggamit mga built-in nga default nga kantidad:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Paghimo sa imong kaugalingon:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Bumalik ang remate bili sa usa ka matang sumala sa `Default` trait.
///
/// Ang tipo nga mobalik gipahinumdom gikan sa konteksto;katumbas kini sa `Default::default()` apan labi ka mubu nga tipo.
///
/// Pananglitan:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Naggumikan makro pagmugna usa ka impl sa trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }