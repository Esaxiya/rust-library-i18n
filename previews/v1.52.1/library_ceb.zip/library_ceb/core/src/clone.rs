//! Ang `Clone` trait alang sa matang nga dili mahimong 'bug-os nga gikopya'.
//!
//! Sa Rust, ang pipila nga yano nga tipo mao ang "implicitly copyable" ug kung imong itudlo kanila o ipasa kini nga mga argumento, ang magdawat makadawat usa ka kopya, nga ibilin ang orihinal nga kantidad sa lugar.
//! Kini nga mga matang sa wala magkinahanglan og alokasyon sa pagkopya ug dili finalizers (ie, dili sila naglakip gipanag-iya kahon o pagpatuman [`Drop`]), mao nga ang mga tighipos giisip sila barato ug luwas sa pagkopya.
//!
//! Alang sa ubang matang kopya kinahanglan nga tin-aw, pinaagi sa kombensiyon sa pagpatuman sa [`Clone`] trait ug sa pagtawag sa [`clone`] pamaagi.
//!
//! [`clone`]: Clone::clone
//!
//! Panguna nga pananglitan sa paggamit:
//!
//! ```
//! let s = String::new(); // Ang tipo sa hilo nagpatuman sa Clone
//! let copy = s.clone(); // aron mahimo naton kini i-clone
//! ```
//!
//! Aron dali ipatuman ang Clone trait, mahimo usab nimo gamiton ang `#[derive(Clone)]`.Pananglitan:
//!
//! ```
//! #[derive(Clone)] // gidugang namon ang Clone trait sa Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ug karon mahimo na naton kini i-clone!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Usa ka komon nga trait alang sa abilidad sa tin-aw nga kopyahon sa usa ka butang.
///
/// Lahi gikan sa [`Copy`] sa nga [`Copy`] mao ang bug-os nga ug hilabihan barato, samtang `Clone` mao ang kanunay nga tin-aw ug mahimo o dili mahimo nga mahal.
/// Aron sa pagpatuman niini nga mga kinaiya, Rust dili motugot kaninyo sa reimplement [`Copy`], apan nga kamo mahimo nga reimplement `Clone` ug modagan arbitraryong code.
///
/// Tungod kay ang `Clone` labi ka kasagaran kaysa [`Copy`], mahimo nimo nga awtomatiko nga mahimo ang bisan unsang [`Copy`] nga `Clone` usab.
///
/// ## Derivable
///
/// Ang kini nga trait mahimong magamit sa `#[derive]` kung ang tanan nga mga uma `Clone`.Ang pagpatunga nga `derive`d sa [`Clone`] nagtawag [`clone`] sa matag natad.
///
/// [`clone`]: Clone::clone
///
/// Alang sa usa ka generic nga istruktura, gipatuman sa `#[derive]` ang `Clone` nga kondisyon pinaagi sa pagdugang nga gihigot nga `Clone` sa mga generic parameter.
///
/// ```
/// // `derive` nagpatuman sa Clone alang sa Pagbasa<T>sa diha nga T mao Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Unsaon nako pagpatuman ang `Clone`?
///
/// Matang nga [`Copy`] kinahanglan nga adunay usa ka gamay nga pagpatuman sa `Clone`.Dugang pormal:
/// kon `T: Copy`, `x: T`, ug `y: &T`, nan `let x = y.clone();` mao ang katumbas sa `let x = *y;`.
/// Kinahanglan nga mag-amping ang mga manwal nga pagpatuman aron mapadayon ang kini nga invariant;bisan pa, ang dili luwas nga code kinahanglan dili mosalig niini aron masiguro ang kahilwasan sa memorya.
///
/// Ang usa ka panig-ingnan mao ang usa ka generic magtukod naghupot sa usa ka function pointer.Sa kini nga kaso, ang pagpatuman sa `Clone` dili mahimong `derive`d, apan mahimong ipatuman ingon:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Dugang nga mga nagpatuman
///
/// Dugang pa sa mga [implementors listed below][impls], ang mosunod nga mga matang usab sa pagpatuman sa `Clone`:
///
/// * matang function nga butang (ie, ang lahi matang gihubit alang sa matag function)
/// * Mga tipo sa pagpaandar nga gigamit (pananglitan, `fn() -> i32`)
/// * matang Array, alang sa tanan nga mga gidak-on, kon ang matang butang usab implementar `Clone` (pananglitan, `[i32; 123456]`)
/// * Mga lahi sa tuple, kung ang matag sangkap nagpatuman usab `Clone` (pananglitan, `()`, `(i32, bool)`)
/// * matang pagsira, kon sila pagdakop walay bili gikan sa palibot o kon ang tanan nga nadakpan nga mga prinsipyo pagpatuman `Clone` sa ilang mga kaugalingon.
///   Hinumdomi nga ang mga variable nga nakuha sa gipaambit nga reperensiya kanunay nagpatuman sa `Clone` (bisan kung wala ang referent), samtang ang mga variable nga nakuha sa mutable referensya dili gyud ipatuman ang `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Nagbalik usa ka kopya sa kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str galamiton Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Naghimo kopya-asaynment gikan sa `source`.
    ///
    /// `a.clone_from(&b)` katumbas sa `a = b.clone()` sa pagpaandar, apan mahimong mapalibutan aron magamit pag-usab ang mga gigikanan sa `a` aron malikayan ang wala kinahanglana nga paggahin.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Kuha macro pagmugna sa usa ka impl sa trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): kini nga mga structs gigamit lamang pinaagi sa#[kuha] aron ihingusog nga ang matag bahin sa usa ka matang galamiton Clone o Kopya.
//
//
// Kini nga mga lakang dili gyud makita sa code sa gumagamit.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ang pagpatuman sa `Clone` alang sa mga primitive type.
///
/// Implementar sa nga dili gihulagway diha sa Rust ang gipatuman sa `traits::SelectionContext::copy_clone_conditions()` sa `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ang gipaambit nga mga pakisayran mahimo nga ma-clone, apan ang mga mutable referensya *dili*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ang gipaambit nga mga pakisayran mahimo nga ma-clone, apan ang mga mutable referensya *dili*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}