//! Pag-andar alang sa pag-order ug pagtandi.
//!
//! module Kini nga naglakip sa nagkalain-laing mga himan alang sa nagmando ug pagtandi sa mga hiyas.Sa katingbanan:
//!
//! * [`Eq`] ug [`PartialEq`] mga traits nga nagtugot kanimo nga ipasabut ang kinatibuk-an ug dili bahin nga pagkaparehas taliwala sa mga kantidad, matag usa.
//! - Implementar kanila overloads sa `==` ug `!=` operators.
//! * [`Ord`] ug [`PartialOrd`] mga traits nga motugot kaninyo sa nagpaila kinatibuk ug partial orderings sa taliwala sa mga prinsipyo, sa tinagsa.
//!
//! Ang pagpatuman sa kanila sobra sa mga operator sa `<`, `<=`, `>`, ug `>=`.
//! * [`Ordering`] usa ka enum nga gibalik sa mga punoan nga gimbuhaton sa [`Ord`] ug [`PartialOrd`], ug gihulagway ang usa ka pag-order.
//! * [`Reverse`] mao ang usa ka magtukod nga nagtugot kaninyo sa sayon nga makausab sa usa ka tulomanon.
//! * [`max`] ug [`min`] mga gimbuhaton nga pagtukod sa sa [`Ord`] ug motugot kanimo sa pagpangita sa maximum o minimum sa duha ka mga mithi.
//!
//! Alang sa dugang nga mga detalye, tan-awa ang tagsatagsa nga dokumentasyon sa matag aytem sa lista.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Ang Trait alang sa pagtandi sa pagkaparehas diin ang [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Kini nga trait nagtugot alang sa partial pagkasama, alang sa matang nga wala sa usa ka bug-os nga nga panagtandi relasyon.
/// Pananglitan, sa naglutaw nga mga numero punto `NaN != NaN`, mao nga matang naglutaw punto pagpatuman `PartialEq` apan dili [`trait@Eq`].
///
/// Pormal, ang pagkaparehas kinahanglan (alang sa tanan `a`, `b`, `c` nga tipo `A`, `B`, `C`):
///
/// - **ay**: kon `A: PartialEq<B>` ug `B: PartialEq<A>`, unya **`usa ka==b` nagpasabot`b==a`**;ug
///
/// - **Transitive**: kung `A: PartialEq<B>` ug `B: PartialEq<C>` ug `A:
///   PartialEq<C>`, pagkahuman **` a==b`ug `b == c` nagpasabut`a==c`**.
///
/// Hinumdomi nga ang `B: PartialEq<A>` (symmetric) ug `A: PartialEq<C>` (transitive) impls wala pugsa nga maglungtad, apan kini nga mga kinahanglanon magamit bisan kanus-a sila adunay.
///
/// ## Derivable
///
/// Kini nga trait mahimong gamiton sa `#[derive]`.Kung `maggikan` sa mga struct, duha nga mga higayon managsama kung ang tanan nga mga uma parehas, ug dili managsama kung ang bisan unsang mga uma dili managsama.Sa diha nga `derive`d sa enums, ang matag laing mao nga sama sa iyang kaugalingon ug dili ikagtanding sa ubang mga variants.
///
/// ## Unsaon nako pagpatuman ang `PartialEq`?
///
/// `PartialEq` nanginahanglan ra ang ipatuman nga [`eq`] nga pamaagi;[`ne`] gihubit sa mga termino sa niini pinaagi sa default.Ang bisan unsang manwal nga pagpatuman sa [`ne`]*kinahanglan* respetuhon ang lagda nga ang [`eq`] usa ka estrikto nga baligtad sa [`ne`];nga mao, ang `!(a == b)` kon ug lamang kon `a != b`.
///
/// Implementar sa sa `PartialEq`, [`PartialOrd`], ug [`Ord`]*kinahanglan* mouyon sa usag usa.Kini sayon nga aksidenteng paghimo kanila mouyon sa magdawatan sa pipila sa mga traits ug sa kamut sa pagpatuman sa uban.
///
/// Usa ka pananglitan nga pagpatuman alang sa usa ka domain diin ang duha ka libro giisip nga parehas nga libro kung magkatugma ang ilang ISBN, bisan kung magkalainlain ang mga format:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Giunsa nako matandi ang duha nga lainlaing lahi?
///
/// Ang matang nga imong mahimo itandi sa ang kontrolado sa `matang sukaranan ni PartialEq`.
/// Pananglitan, ang ni tweak sa atong miaging code sa usa ka gamay:
///
/// ```
/// // Nagpatuman ang nakuha<BookFormat>==<BookFormat>mga pagtandi
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ipatuman<Book>==<BookFormat>mga pagtandi
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ipatuman<BookFormat>==<Book>mga pagtandi
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Pinaagi sa pag-usab sa `impl PartialEq for Book` sa `impl PartialEq<BookFormat> for Book`, kita motugot `BookFormat`s nga itandi sa`Book`s.
///
/// Ang usa ka pagtandi sama sa usa sa taas, nga wala magtagad sa pipila nga mga natad sa istruktura, mahimong peligro.Dali kini nga mahimong hinungdan sa usa ka wala gituyo nga paglapas sa mga kinahanglanon alang sa usa ka bahin nga adunay kalabutan sa pagkaparehas.
/// Pananglitan, kung gitipigan namon ang gipatuman sa itaas nga `PartialEq<Book>` alang sa `BookFormat` ug nagdugang usa ka pagpatuman sa `PartialEq<Book>` alang sa `Book` (bisan pinaagi sa usa ka `#[derive]` o pinaagi sa manwal nga pagpatuman gikan sa unang panig-ingnan) nan ang sangputanan makalapas sa pagbiya:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Kini nga pamaagi pagsulay alang sa `self` ug `other` gipabilhan sa managsama, ug gigamit sa `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Ang kini nga pamaagi pagsulay sa `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Kuha macro pagmugna sa usa ka impl sa trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Ang Trait alang sa pagtandi sa pagkaparehas diin ang [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Kini paagi, nga dugang pa sa `a == b` ug `a != b` nga higpit nga inverses, ang pagkasama kinahanglan (alang sa tanan `a`, `b` ug `c`):
///
/// - reflexive: `a == a`;
/// - simetriko: Ang `a == b` nagpasabot `b == a`;ug
/// - Transitive: `a == b` ug `b == c` nagpasabot `a == c`.
///
/// kabtangan Kini nga dili gitan-aw sa mga tighipos, ug busa `Eq` nagpasabot [`PartialEq`], ug walay dugang nga mga pamaagi.
///
/// ## Derivable
///
/// Kini nga trait mahimong magamit sa `#[derive]`.
/// Sa diha nga `derive`d, tungod kay `Eq` walay dugang mga pamaagi, lamang kini nga nagpahibalo sa tighipos nga kini mao ang usa ka nga panagtandi relasyon kay sa usa ka partial nga panagtandi relasyon.
///
/// Hinumdomi nga ang estratehiya sa `derive` nagkinahanglan sa tanan nga mga uma `Eq`, nga dili kanunay gitinguha.
///
/// ## Unsaon nako pagpatuman ang `Eq`?
///
/// Kung dili nimo magamit ang estratehiya sa `derive`, isulti nga ang imong tipo nagpatuman sa `Eq`, nga wala`y pamaagi:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // kini nga pamaagi gigamit lamang pinaagi sa#[magdawatan] nga mopahayag nga ang matag bahin sa usa ka matang galamiton#[magdawatan] sa iyang kaugalingon, sa kasamtangan nga magdawatan sa imprastraktura sa pagbuhat niini nga pangangkon nga walay paggamit sa usa ka pamaagi sa niini nga trait paagi mao ang dul-an sa imposible.
    //
    //
    // Dili gyud kini kinahanglan ipatuman sa kamut.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Kuha macro pagmugna sa usa ka impl sa trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: kini nga magtukod gigamit lamang pinaagi sa#[kuha] sa
// gipahayag nga ang matag bahin sa usa ka tipo nagpatuman sa Eq.
//
// Kini nga istruktura kinahanglan dili gyud makita sa code sa gumagamit.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ang usa ka `Ordering` mao ang sangputanan sa usa ka pagtandi taliwala sa duha nga mga kantidad.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Usa ka tulomanon diin ang usa ka itandi bili mao ang dili kaayo kay sa lain.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Usa ka pag-order diin ang usa ka gitandi nga kantidad parehas sa lain.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Usa ka pag-order diin ang gitandi nga kantidad labi ka daghan sa usa pa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Mibalik `true` kon ang tulomanon mao ang `Equal` laing.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Gibalik ang `true` kung ang pag-order dili ang `Equal` nga lahi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Gibalik ang `true` kung ang pag-order mao ang variant nga `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Gibalik ang `true` kung ang pag-order mao ang variant nga `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Mibalik `true` kon ang tulomanon mao ang bisan hain sa `Less` o `Equal` nga bersyon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Mibalik `true` kon ang tulomanon mao ang bisan hain sa `Greater` o `Equal` nga bersyon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Gibaliktad ang `Ordering`.
    ///
    /// * `Less` mahimong `Greater`.
    /// * `Greater` mahimong `Less`.
    /// * `Equal` mahimong `Equal`.
    ///
    /// # Examples
    ///
    /// Basic nga kinaiya:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Mahimo kini nga pamaagi aron mabalhin ang pagtandi:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // paghan-ay ang laray gikan sa labing kadako hangtod sa labing gamay.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Mga kadena duha ka pag-order.
    ///
    /// Gibalik ang `self` kung dili kini `Equal`.Kay kon dili mobalik `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Talikala sa tulomanon uban sa gihatag nga function.
    ///
    /// Mobalik `self` sa diha nga kini dili `Equal`.
    /// Kung dili tawgon ang `f` ug ibalik ang resulta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Usa ka katabang magtukod alang sa reverse pagkasunodsunod.
///
/// magtukod Kini mao ang usa ka magtatabang nga gigamit sa mga gimbuhaton sama sa [`Vec::sort_by_key`] ug mahimong gamiton aron sa pagbawi order sa usa ka bahin sa usa ka yawe.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait alang sa matang nga pagporma sa usa ka [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ang usa ka order usa ka kinatibuk-ang han-ay kung kini (alang sa tanan nga `a`, `b` ug `c`):
///
/// - total ug asymetriko: gayud sa usa sa `a < b`, `a == b` o `a > b` tinuod;ug
/// - Transitive, `a < b` ug `b < c` nagpasabot `a < c`.Ang parehas kinahanglan nga maghupot alang sa parehas nga `==` ug `>`.
///
/// ## Derivable
///
/// Kini nga trait mahimong magamit sa `#[derive]`.
/// Sa diha nga `derive`d sa structs, kini og usa ka [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) tulomanon base sa ibabaw-sa-ubos nga deklarasyon aron sa mga sakop sa sa magtukod ni.
///
/// Sa diha nga `derive`d sa enums, variants mga gisugo sa ilang top-sa-ubos discriminant order.
///
/// ## Pagtandi sa leksikograpiko
///
/// Ang pagtandi sa Lexicographic usa ka operasyon nga adunay mga mosunud:
///  - Duha ka han-ay ang gitandi nga elemento sa elemento.
///  - Ang unang mismatching elemento ninghubit, ningsaysay nga han-ay mao ang lexicographically dili kaayo o mas dako pa kay sa uban nga mga.
///  - Kung ang usa ka han-ay usa ka pauna sa uban pa, ang labi ka mubu nga han-ay sa lexicographically mas gamay kaysa sa uban.
///  - Kon ang duha ka han-ay nga adunay katumbas nga mga elemento ug anaa sa sama nga gitas-on, dayon ang mga han-ay mao ang lexicographically managsama.
///  - Ang usa ka wala`y sulod nga han-ay mas gamay og lexicographically kaysa bisan unsang dili-walay sulod nga han-ay.
///  - Duha ka wala`y sulod nga han-ay ang managsama sa lexicographically.
///
/// ## Unsaon nako sa pagpatuman `Ord`?
///
/// `Ord` nagkinahanglan nga ang matang usab [`PartialOrd`] ug [`Eq`] (nga nagkinahanglan [`PartialEq`]).
///
/// Unya kamo kinahanglan gayud nga nagpaila sa usa ka pagpatuman sa [`cmp`].Ikaw mahimo nga makakaplag niini mapuslanon sa paggamit sa [`cmp`] sa uma sa imong type ni.
///
/// Implementar sa sa [`PartialEq`], [`PartialOrd`], ug `Ord`*kinahanglan* mouyon sa usag usa.
/// Nga mao, ang `a.cmp(b) == Ordering::Equal` kon ug lamang kon `a == b` ug `Some(a.cmp(b)) == a.partial_cmp(b)` alang sa tanan `a` ug `b`.
/// Kini sayon nga aksidenteng paghimo kanila mouyon sa magdawatan sa pipila sa mga traits ug sa kamut sa pagpatuman sa uban.
///
/// Ania ang usa ka panig-ingnan diin kamo gusto sa matang sa mga tawo pinaagi sa gitas-on lamang, nagsalikway sa `id` ug `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Kini nga pamaagi mobalik sa usa ka [`Ordering`] sa taliwala sa `self` ug `other`.
    ///
    /// Pinaagi sa kombensiyon, gibalik sa `self.cmp(&other)` ang pag-order nga parehas sa ekspresyon nga `self <operator> other` kung tinuod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Gitandi ug gibalik ang labing kadaghan nga duha nga kantidad.
    ///
    /// Gibalik ang ikaduha nga argumento kung gitino sa pagtandi nga managsama sila.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Nagtandi ug mobalik sa minimum sa duha ka mga mithi.
    ///
    /// Gibalik ang una nga lantugi kung gitino sa pagtandi nga managsama sila.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Idili sa usa ka bili sa usa ka sal.
    ///
    /// Gibalik ang `max` kung ang `self` mas daghan kaysa `max`, ug `min` kung ang `self` mas gamay kaysa `min`.
    /// Kung dili kini mobalik `self`.
    ///
    /// # Panics
    ///
    /// Panics kon `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Kuha macro pagmugna sa usa ka impl sa trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait alang sa mga kantidad nga mahimo itandi alang sa usa ka paghan-ay.
///
/// pagtandi kinahanglan pagtagbaw, kay ang tanan `a`, `b` ug `c`:
///
/// - asymmetry: kung `a < b` dayon `!(a > b)`, ingon man `a > b` nagpasabot `!(a < b)`;ug
/// - transitivity: `a < b` ug `b < c` nagpasabot `a < c`.Ang sama nga kinahanglan salipdanan alang sa mga `==` ug `>`.
///
/// Hinumdomi nga kini nga mga kinahanglanon nagpasabut nga ang trait mismo kinahanglan ipatuman nga simetriko ug transitively: kung `T: PartialOrd<U>` ug `U: PartialOrd<V>` dayon `U: PartialOrd<T>` ug `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Kini nga trait mahimong gamiton sa `#[derive]`.Sa diha nga `derive`d sa structs, kini og usa ka lexicographic tulomanon base sa ibabaw-sa-ubos nga deklarasyon aron sa mga sakop sa sa magtukod ni.
/// Sa diha nga `derive`d sa enums, variants mga gisugo sa ilang top-sa-ubos discriminant order.
///
/// ## Unsaon nako sa pagpatuman `PartialOrd`?
///
/// `PartialOrd` nanginahanglan ra ang pagpatuman sa pamaagi nga [`partial_cmp`], uban ang uban pa nga napatungha gikan sa mga default nga pagpatuman.
///
/// Apan kini nagpabilin posible nga sa pag-implementar sa uban gilain alang sa matang nga wala sa usa ka kinatibuk-order.
/// Pananglitan, alang sa naglutaw numero punto, `NaN < 0 == false` ug `NaN >= 0 == false` (cf.
/// IEEE 754-2008 seksyon 5.11).
///
/// `PartialOrd` nagkinahanglan sa imong tipo nga mahimong [`PartialEq`].
///
/// Implementar sa sa [`PartialEq`], `PartialOrd`, ug [`Ord`]*kinahanglan* mouyon sa usag usa.
/// Kini sayon nga aksidenteng paghimo kanila mouyon sa magdawatan sa pipila sa mga traits ug sa kamut sa pagpatuman sa uban.
///
/// Kung ang imong tipo [`Ord`], mahimo nimo ipatuman ang [`partial_cmp`] pinaagi sa paggamit sa [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Ikaw mahimo usab nga makakaplag niini mapuslanon sa paggamit sa [`partial_cmp`] sa uma sa imong type ni.
/// Ania ang usa ka pananglitan sa mga tipo nga `Person` nga adunay usa ka naglutaw-punto nga `height` nga uma nga mao ra ang magamit nga uma alang sa paghan-ay:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Gibalik kini nga pamaagi usa ka pag-order taliwala sa mga kantidad nga `self` ug `other` kung adunay usa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Kung dili mahimo ang pagtandi:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Kini nga pamaagi sulayan ubos pa kay sa (alang sa `self` ug `other`) ug gigamit sa `<` operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Ang kini nga pamaagi nagsulay dili kaayo o katumbas sa (alang sa `self` ug `other`) ug gigamit sa `<=` operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ang kini nga pamaagi pagsulay sa labi ka daghan kaysa (alang sa `self` ug `other`) ug gigamit sa `>` operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Kini nga pamaagi sulayan nga mas dako pa kay sa o itanding (alang sa `self` ug `other`) ug gigamit sa `>=` operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Naggumikan makro pagmugna usa ka impl sa trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Nagtandi ug mobalik sa minimum sa duha ka mga mithi.
///
/// Gibalik ang una nga lantugi kung gitino sa pagtandi nga managsama sila.
///
/// Sa sulud naggamit us aka alyas hangtod [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Gibalik ang minimum sa duha nga kantidad kalabot sa gipiho nga function sa pagtandi.
///
/// Gibalik ang una nga lantugi kung gitino sa pagtandi nga managsama sila.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Mobalik sa mga elemento nga naghatag sa minimum nga bili gikan sa bungat function.
///
/// Gibalik ang una nga lantugi kung gitino sa pagtandi nga managsama sila.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Gitandi ug gibalik ang labing kadaghan nga duha nga kantidad.
///
/// Gibalik ang ikaduha nga argumento kung gitino sa pagtandi nga managsama sila.
///
/// Internally naggamit sa usa ka alyas sa [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Mibalik sa maximum sa duha ka mga mithi uban sa pagtahod ngadto sa espesipikong function pagtandi.
///
/// Gibalik ang ikaduha nga argumento kung gitino sa pagtandi nga managsama sila.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Gibalik ang elemento nga naghatag sa labing kadaghan nga kantidad gikan sa gitino nga paglihok.
///
/// Gibalik ang ikaduha nga argumento kung gitino sa pagtandi nga managsama sila.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Pagpatuman sa PartialEq, Eq, PartialOrd ug Ord alang sa karaang matang
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Ang han-ay dinhi hinungdanon aron makamugna labi ka kamahinungdanon nga pagtigum.
                    // Tan-awa ang <https://github.com/rust-lang/rust/issues/63758> alang sa dugang nga impormasyon.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Sa pagsalibay sa i8 ug pagkabig sa kalainan sa usa ka pagkasunodsunod og dugang nga kamalaumon katilingban.
            //
            // Tan-awa ang <https://github.com/rust-lang/rust/issues/66780> alang sa dugang impormasyon.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool ingon i8 mobalik 0 o 1, mao nga ang mga kalainan dili mahimo nga sa bisan unsa pa
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &mga panudlo

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}