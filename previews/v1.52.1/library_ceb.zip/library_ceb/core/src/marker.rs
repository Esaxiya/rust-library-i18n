//! Karaan nga traits ug matang nga nagrepresentar sa nag-unang mga kabtangan sa matang.
//!
//! Rust matang mahimong giklasipikar sa nagkalain-laing mga mapuslanon nga mga paagi sumala sa ilang kinaiya kabtangan.
//! Kini nga mga klasipikasyon gihulagway ingon nga traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Matang nga mahimong ibalhin sa tibuok utlanan hilo.
///
/// trait Kini awtomatikong-implementar sa diha nga motino sa tighipos kini angay.
///
/// Usa ka panig-ingnan sa usa ka matang non-`Send` mao ang paghisgot-ihap pointer [`rc::Rc`][`Rc`].
/// Kung ang duha nga sulud pagsulay sa pag-clone sa [`Rc`] nga nagtudlo sa parehas nga kantidad nga naihap sa pakisayran, mahimo nila nga sulayan nga i-update ang pag-ihap sa pakisayran sa parehas nga oras, nga mao ang [undefined behavior][ub] tungod kay ang [`Rc`] dili mogamit mga operasyon sa atomiko
///
/// Ang ig-agaw niini nga [`sync::Arc`][arc] naggamit mga operasyon sa atomic (nga nakaabut sa pipila ka mga overhead) ug ingon niini ang `Send`.
///
/// Tan-awa ang [the Nomicon](../../nomicon/send-and-sync.html) alang sa dugang nga mga detalye.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Matang sa usa ka kanunay nga gidak-on nga nailhan sa pagtipon panahon.
///
/// Ang tanan nga matang lantugi adunay usa ka bug-os nga gigapos sa `Sized`.Ang espesyal nga syntax `?Sized` mahimong magamit aron makuha ang kini nga gigapos kung dili kini angay.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // pagtukod FooUse(Foo<[i32]>);//sayop: sized dili gipatuman alang sa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ang us aka eksepsiyon mao ang gipakita nga `Self` nga lahi sa usa ka trait.
/// Usa ka trait wala sa usa ka bug-os nga `Sized` gigapos ingon nga kini mao mahiuyon sa [trait butang] ni diin, pinaagi sa kahulogan, ang trait kinahanglan nga buhat uban sa tanan nga posible nga tigpatuman, ug sa ingon mahimo nga sa bisan unsa nga gidak-on.
///
///
/// Bisan tuod Rust motugot kaninyo sa gapuson `Sized` sa usa ka trait, dili kamo makahimo sa paggamit niini aron sa pagporma sa usa ka trait butang sa ulahi:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // himoa y: &dyn Bar= &Impl;//sayop: ang trait `Bar` dili nga sa usa ka butang
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // alang sa Default, alang sa panig-ingnan, nga nagkinahanglan nga `[T]: !Default` nga evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Matang nga mahimong "unsized" sa usa ka maabtikon-kadako nga matang.
///
/// Kay sa panig-ingnan, ang kadako gubat matang `[i8; 2]` implementar `Unsize<[i8]>` ug `Unsize<dyn fmt::Debug>`.
///
/// Ang tanan nga mga implementar sa `Unsize` awtomatikong nga gihatag sa tighipos.
///
/// `Unsize` gipatuman alang sa:
///
/// - `[T; N]` mao `Unsize<[T]>`
/// - `T` mao `Unsize<dyn Trait>` sa diha nga `T: Trait`
/// - `Foo<..., T, ...>` mao `Unsize<Foo<..., U, ...>>` kon:
///   - `T: Unsize<U>`
///   - Foo mao ang usa ka magtukod
///   - Lamang sa katapusan nga kapatagan sa `Foo` adunay usa ka matang nga naglambigit `T`
///   - `T` dili bahin sa matang sa bisan unsa nga lain nga mga kaumahan
///   - `Bar<T>: Unsize<Bar<U>>`, kon sa katapusan nga kapatagan sa `Foo` adunay matang `Bar<T>`
///
/// `Unsize` gigamit uban sa [`ops::CoerceUnsized`] sa pagtugot sa "user-defined" mga sudlanan sama sa [`Rc`] sa naglakip sa maabtikon-kadako matang.
/// Tan-awa ang [DST coercion RFC][RFC982] ug [the nomicon entry on coercion][nomicon-coerce] alang sa dugang detalye.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Gikinahanglan trait alang sa permanenteng nga gigamit sa sumbanan posporo.
///
/// Sa bisan unsa nga matang nga derives `PartialEq` awtomatikong nagpatuman niini trait, sa walay pagtagad sa kon sa iyang matang-lantugi pagpatuman `Eq`.
///
/// Kon ang usa ka `const` butang naglakip sa pipila ka mga matang nga dili pagpatuman niini trait, nga matang sa bisan (1.) wala pagpatuman `PartialEq` (nga sa ato sa kanunay nga dili mohatag og nga pagtandi pamaagi, nga code nga kaliwatan nga nangagpas anaa), o (2.) kini galamiton *sa iyang kaugalingon nga* bersyon sa `PartialEq` (nga kita maghunahuna wala mahiuyon ngadto sa usa ka structural-pagkasama pagtandi).
///
///
/// Sa bisan hain sa duha ka situwasyon sa ibabaw, atong isalikway paggamit sa maong usa ka kanunay nga diha sa usa ka sumbanan match.
///
/// Tan-awa usab ang [structural match RFC][RFC1445], ug [issue 63438] nga nadasig nanglalin gikan sa hiyas-based disenyo niini nga trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Gikinahanglan trait alang sa permanenteng nga gigamit sa sumbanan posporo.
///
/// Sa bisan unsa nga matang nga derives `Eq` awtomatikong nagpatuman niini trait, sa walay pagtagad sa kon matang lantugi niini pagpatuman `Eq`.
///
/// Kini mao ang usa ka hack sa pagtrabaho sa usa ka limitasyon sa atong matang sa sistema.
///
/// # Background
///
/// Gusto namo nga sa nagkinahanglan nga matang sa consts nga gigamit sa sumbanan posporo ang mga hiyas `#[derive(PartialEq, Eq)]`.
///
/// Sa usa ka labaw nga sulundon nga kalibutan, kita check nga kinahanglanon sa lang pagsusi nga ang gihatag nga matang galamiton sa mga `StructuralPartialEq` trait ug ang `Eq` trait.
/// Apan, nga imong mahimo ADTs nga *buhaton*`derive(PartialEq, Eq)`, ug mahimo nga usa ka kaso nga gusto kita sa tighipos sa pagdawat, ug bisan pa niana matang sa kanunay nga ni mapakyas sa pagpatuman `Eq`.
///
/// Kini usa ka kaso nga ingon niini:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ang problema sa code sa ibabaw mao nga `Wrap<fn(&())>` wala pagpatuman `PartialEq`, ni `Eq`, tungod kay `alang sa < 'sa usa ka> fn(&'a _)` does not implement those traits.)
///
/// Tungod niini, dili kami makasalig sa walay hinungdan nga pagsusi alang sa `StructuralPartialEq` ug sa `Eq` ra.
///
/// Ingon sa usa ka hack nga buhat sa palibot niini, atong gamiton ang duha ka lain nga traits giindyeksyon sa matag usa sa duha ka mga derives (`#[derive(PartialEq)]` ug `#[derive(Eq)]`) ug tseke nga ang duha kanila mga karon ingon nga kabahin sa structural-match pagsusi.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Matang kansang mga prinsipyo masundog pinaagi lamang sa pagkopya tipik.
///
/// Pinaagi sa remate, baryable bindings adunay 'lakang semantiko.'Sa lain nga mga pulong:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` mibalhin sa `y`, ug busa dili magamit
///
/// // println ("{: ?}", x);//kasaypanan: paggamit sa nagtukmod bili
/// ```
///
/// Bisan pa, kung ang usa ka tipo nagpatuman sa `Copy`, kini hinoon adunay 'kopya nga semantiko':
///
/// ```
/// // Mahimo naton makuha ang pagpatuman sa `Copy`.
/// // `Clone` mao ang gikinahanglan usab, ingon nga kini usa ka supertrait sa `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` usa ka kopya sa `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Kini importante nga timan-nga sa niini nga mga duha ka mga ehemplo, ang mga kalainan lamang mao kon ikaw gitugotan sa access `x` human sa buluhaton.
/// Ubos sa hood, sa usa ka kopya ug usa ka lakang mahimong moresulta sa mga tipik nga gikopya sa handumanan, bisan tuod kini usahay optimized sa.
///
/// ## Unsaon nako sa pagpatuman `Copy`?
///
/// Adunay duha ka paagi sa pag-implementar `Copy` sa imong type.simple mao ang sa paggamit sa `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ikaw mahimo usab nga pagpatuman `Copy` ug `Clone` kamut:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Adunay usa ka gamay nga kalainan tali sa duha ka: ang `derive` estratehiya usab ibutang sa usa ka `Copy` gigapos sa matang lantugi, nga dili sa kanunay gitinguha.
///
/// ## Unsa ang kalainan tali sa `Copy` ug `Clone`?
///
/// Ang mga kopya mahinungdan nga nahinabo, pananglitan ingon bahin sa usa ka asaynment `y = x`.Ang pamatasan sa `Copy` dili sobra;kini mao ang kanunay nga ang usa ka yano nga gamay-maalamon nga kopya.
///
/// Cloning mao ang usa ka tin-aw nga aksyon, `x.clone()`.Ang pagpatuman sa [`Clone`] makahatag bisan unsang kinahanglan nga piho nga tipo nga kinahanglan aron madoble ang mga kantidad nga luwas.
/// Kay sa panig-ingnan, sa pagpatuman sa [`Clone`] alang sa [`String`] nagkinahanglan sa pagkopya sa mga talinis nga-sa hilo buffer sa mohon.
/// Usa ka yano nga bitwise kopya sa [`String`] mga prinsipyo nga lamang kopyahon ang pointer, padulong ngadto sa usa ka double nga libre sa linya.
/// Tungod niini nga rason, [`String`] mao [`Clone`] apan dili `Copy`.
///
/// [`Clone`] mao ang usa ka supertrait sa `Copy`, mao ang tanang mga butang nga mao `Copy` kinahanglan usab nga pagpatuman [`Clone`].
/// Kung ang usa ka tipo `Copy` unya ang pagpatuman sa [`Clone`] kinahanglan ra ibalik ang `*self` (tan-awa ang pananglitan sa taas).
///
/// ## Sa diha nga ang akong matang nga `Copy`?
///
/// Mahimo ipatuman sa usa ka tipo ang `Copy` kung ang tanan nga sangkap niini ipatuman ang `Copy`.Kay sa panig-ingnan, kini nga magtukod mahimong `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Usa ka magtukod mahimong `Copy`, ug [`i32`] mao `Copy`, busa `Point` mao ang angayan nga mahimong `Copy`.
/// Sa pagtandi, hunahunaa
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ang istruktura `PointList` dili mapatuman ang `Copy`, tungod kay ang [`Vec<T>`] dili `Copy`.Kung gisulayan namon nga makuha ang usa ka pagpatuman sa `Copy`, makakuha kami usa ka sayup:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Mipakigbahin mga pakisayran (`&T`) usab `Copy`, busa ang usa ka matang mahimong `Copy`, bisan sa diha nga kini naghupot mipakigbahin mga pakisayran sa mga matang `T` nga dili * `Copy`.
/// Hunahunaa ang mosunud nga istraktura, nga mahimong ipatuman ang `Copy`, tungod kay naghupot ra kini usa ka *gipaambit nga reperensya* sa among dili-`Copy` type `PointList` gikan sa taas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Sa diha nga *dili* sa akong matang nga `Copy`?
///
/// Ang pila ka lahi dili makopya nga luwas.Pananglitan, pagkopya `&mut T` nga paghimo sa usa ka aliased mutable pakisayran.
/// Ang pagkopya sa [`String`] madoble ang kaakohan alang sa pagdumala sa buffer ['String`], nga magdala sa doble nga libre.
///
/// Generalizing sa ulahing mga kaso, bisan unsa nga matang sa pagpatuman [`Drop`] dili mahimo nga `Copy`, tungod kay kini pagdumala sa pipila ka mga kapanguhaan gawas sa iyang kaugalingon nga [`size_of::<T>`] bytes.
///
/// Kung gisulayan nimo nga ipatuman ang `Copy` sa usa ka istruktura o enum nga sulud dili datos nga`Copy`, makuha nimo ang error [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kanus-a *kinahanglan* ang akong tipo nga `Copy`?
///
/// Kasagaran nagsulti, kung ang imong tipo _can_ nagpatuman sa `Copy`, kinahanglan kini.
/// Hinumdomi, bisan pa, ang pagpatuman sa `Copy` bahin sa publiko nga API nga imong tipo.
/// Kon ang matang mahimo non-`Copy` sa future, kini mahimo nga buotan sa omit sa `Copy` pagpatuman karon, sa paglikay sa usa ka paglapas sa kausaban API.
///
/// ## Dugang nga mga nagpatuman
///
/// Dugang pa sa mga [implementors listed below][impls], ang mosunod nga mga matang usab sa pagpatuman sa `Copy`:
///
/// * matang function nga butang (ie, ang lahi matang gihubit alang sa matag function)
/// * Mga tipo sa pagpaandar nga gigamit (pananglitan, `fn() -> i32`)
/// * matang Array, alang sa tanan nga mga gidak-on, kon ang matang butang usab implementar `Copy` (pananglitan, `[i32; 123456]`)
/// * Mga lahi sa tuple, kung ang matag sangkap nagpatuman usab `Copy` (pananglitan, `()`, `(i32, bool)`)
/// * matang pagsira, kon sila pagdakop walay bili gikan sa palibot o kon ang tanan nga nadakpan nga mga prinsipyo pagpatuman `Copy` sa ilang mga kaugalingon.
///   Hinumdomi nga ang mga variable nga nakuha sa gipaambit nga reperensiya kanunay nagpatuman sa `Copy` (bisan kung wala ang referent), samtang ang mga variable nga nakuha sa mutable referensya dili gyud ipatuman ang `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Kini nagtugot sa pagkopya sa usa ka matang nga wala pagpatuman `Copy` tungod sa nagduhiraw nga utlanan tibuok kinabuhi (pagkopya `A<'_>` sa diha nga lamang `A<'static>: Copy` ug `A<'_>: Clone`).
// Kita niini nga hiyas dinhi alang sa karon lamang tungod kay adunay mga na sa pipila ka kasamtangan nga mga espesyalisasyon sa `Copy` nga na anaa sa standard librarya, ug walay paagi sa luwas nga adunay kinaiya niini nga katungod karon.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Kuha macro pagmugna sa usa ka impl sa trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mga lahi diin luwas nga ipaambit ang mga pakisayran tali sa mga sulud.
///
/// trait Kini awtomatikong-implementar sa diha nga motino sa tighipos kini angay.
///
/// Ang tukmang kahulugan mao: usa ka matang `T` mao [`Sync`] kon ug kon `&T` mao [`Send`].
/// Sa laing mga pulong, kon walay posibilidad sa [undefined behavior][ub] (lakip na ang mga lumba data) sa diha nga agi `&T` mga pakisayran sa taliwala sa hilo.
///
/// Ingon sa madahom, karaang matang nga sama [`u8`] ug [`f64`] tanan mga [`Sync`], ug sa ingon ang mga yano nga hiusa matang nga adunay sulod kanila, sama tuples, structs ug enums.
/// Dugang nga mga ehemplo sa mga nag-unang matang [`Sync`] naglakip "immutable" matang nga sama `&T`, ug ang mga kauban sa yano nga napanunod mutability, sama sa [`Box<T>`][box], [`Vec<T>`][vec] ug labing ubang mga matang sa collection.
///
/// (Ang mga generic parameter kinahanglan [`Sync`] aron ang ilang sulud mahimong [`Sync`].)
///
/// Usa ka daw katingalahan nga sangputanan sa kahulugan mao nga `&mut T` mao `Sync` (kon `T` mao `Sync`) bisan pa nga kini daw sama sa aron sa paghatag og unsynchronized mutasyon.
/// Ang limbong mao ang us aka mutable nga pakisayran sa luyo sa usa ka gipaambit nga reperensiya (kana mao, `& &mut T`) mahimong mabasa ra, ingon kini usa ka `& &T`.
/// Busa walay risgo sa usa ka data lumba.
///
/// Matang nga dili `Sync` mao kadtong adunay "interior mutability" sa usa ka non-lugas nga hilo-luwas nga porma, sama sa [`Cell`][cell] ug [`RefCell`][refcell].
/// Kini nga matang sa pagtugot alang sa mutasyon sa ilang mga sulod bisan pinaagi sa usa ka dili mausab nga, mipakigbahin pakisayran.
/// Kay sa panig-ingnan sa `set` pamaagi sa [`Cell<T>`][cell] nagkinahanglan `&self`, mao kini nagkinahanglan lamang sa usa ka mipakigbahin pakisayran [`&Cell<T>`][cell].
/// Ang pamaagi gihimo sa walay dungan, sa ingon [`Cell`][cell] dili mahimo nga `Sync`.
///
/// Laing panig-ingnan sa usa ka matang non-`Sync` mao ang paghisgot-ihap pointer [`Rc`][rc].
/// Tungod sa bisan unsang pakisayran nga [`&Rc<T>`][rc], mahimo nimong i-clone ang usa ka bag-ong [`Rc<T>`][rc], usbon ang mga ihap sa pakisayran sa dili atomic nga paagi.
///
/// Kay sa mga kaso sa diha nga ang usa ka nagabuhat panginahanglan hilo-luwas sa sulod mutability, Rust naghatag [atomic data types], ingon man usab sa tin-aw nga locking pinaagi [`sync::Mutex`][mutex] ug [`sync::RwLock`][rwlock].
/// Kini nga mga matang sa pagsiguro nga ang bisan unsa nga mutasyon dili hinungdan data lumba, busa ang mga matang nga mga `Sync`.
/// Ingon usab, naghatag ang [`sync::Arc`][arc] usa ka luwas nga luwas nga analogue sa [`Rc`][rc].
///
/// Ang bisan unsang mga lahi nga adunay interior mutability kinahanglan usab nga gamiton ang [`cell::UnsafeCell`][unsafecell] wrapper sa palibot sa value(s) nga mahimo`g mutate pinaagi sa usa ka gipaambit nga reperensiya.
/// Ang napakyas sa pagbuhat niini mao ang [undefined behavior][ub].
/// Pananglitan, [`transmute`][tamdon]-ing gikan sa `&T` ngadto sa `&mut T` mao imbalido.
///
/// Tan-awa ang [the Nomicon][nomicon-send-and-sync] alang sa dugang detalye bahin sa `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sa higayon nga suportahan aron makadugang mga nota sa mga yuta sa `rustc_on_unimplemented` sa beta, ug kini gipalapdan aron masusi kung ang usa ka pagsira bisan diin man sa kinahanglanon nga kadena, ipadako kini sama sa ingon (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-kadako matang nga gigamit sa pagtimaan sa mga butang nga "act like" iya nila ang usa ka `T`.
///
/// Sa pagdugang sa usa ka `PhantomData<T>` uma sa imong matang nagsulti sa tighipos nga ang imong matang molihok ingon nga bisan tuod tindahan kini nga usa ka bili sa matang `T`, bisan kini dili gayud.
/// Gigamit kini nga kasayuran sa pagkalkula sa piho nga mga kabtangan sa kahilwasan.
///
/// Kay ang usa ka labaw pa sa-giladmon nga katin-awan kon sa unsang paagi sa paggamit sa `PhantomData<T>`, palihog tan-awa ang [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Usa ka makalilisang nga sulat 👻👻👻
///
/// Bisan tuod sila ang duha adunay makahahadlok ngalan, `PhantomData` ug 'matang kalag' nga may kalabutan, apan dili susama.Usa ka kalag nga matang sukaranan mao lamang ang usa ka matang sukaranan nga wala gayud gigamit.
/// Sa Rust, kini sa kasagaran hinungdan sa tighipos sa pagbagulbol, ug ang solusyon mao ang aron sa pagdugang sa usa ka "dummy" paggamit sa dalan sa `PhantomData`.
///
/// # Examples
///
/// ## Wala gigamit nga mga parameter sa kinabuhi
///
/// Tingali ang labing kasagarang kaso sa paggamit alang sa `PhantomData` usa ka istruktura nga adunay wala gigamit nga parameter sa kinabuhi, kasagaran ingon bahin sa pipila nga dili luwas nga code.
/// Pananglitan, dinhi mao ang usa ka magtukod `Slice` nga adunay duha ka mga pointers sa matang `*const T`, lagmit nagtudlo ngadto sa usa ka gubat dapit:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ang katuyoan mao nga ang nagpahiping datos balido ra sa tibuuk nga kinabuhi nga `'a`, busa ang `Slice` dili kinahanglan mabuhi labaw sa `'a`.
/// Apan, kini nga katuyoan dili gipahayag sa code, tungod kay walay mga gamit sa tibuok kinabuhi `'a` ug busa kini dili paghawan unsa data kini magamit sa.
/// Kita sa pagtul-id niini pinaagi sa pagsulti sa tighipos sa paglihok ingon nga kon ang `Slice` magtukod naglangkob sa usa ka pakisayran `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Kini usab ang nanginahanglan sa anotasyon `T: 'a`, nga gipakita nga ang bisan unsang mga pakisayran sa `T` balido sa tibuok kinabuhi nga `'a`.
///
/// Kung gisugdan ang usa ka `Slice` hatagan ra nimo ang kantidad `PhantomData` alang sa uma `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Wala magamit nga lantugi matang
///
/// Kini usahay mahitabo nga ikaw wala magamit nga matang lantugi nga nagpakita kon unsa ang matang sa data sa usa ka magtukod mao "tied" sa, bisan pa nga ang data dili tinuod nga makaplagan diha sa magtukod sa iyang kaugalingon.
/// Ania ang usa ka pananglitan diin kini mitumaw sa [FFI].
/// Ang interface sa langyaw naggamit mga kuptanan sa tipo `*mut ()` aron magtumong sa mga kantidad nga Rust sa lainlaing mga lahi.
/// track kita sa matang Rust paggamit sa usa ka kalag nga matang sukaranan sa magtukod `ExternalResource` nga wraps sa usa ka kuptanan.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Pagpanag-iya ug ang drop check
///
/// Pagdugang sa usa ka uma sa matang `PhantomData<T>` nagpaila nga ang imong matang tag-iya data sa matang `T`.Kini usab nagpasabut nga kung ang imong tipo nahulog, mahimo kini paghulog sa usa o daghang mga pananglitan sa tipo nga `T`.
/// Kini may kalabotan sa [drop check] pagtuki sa Rust tighipos ni.
///
/// Kung ang imong istraktura dili tinuud nga *tag-iya* sa datos sa tipo `T`, mas maayo nga gamiton ang usa ka tipo sa pakisayran, sama sa `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (kung wala`y magamit sa tibuok kinabuhi), aron dili mailhan ang tag-iya.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Gigamit ang tigpagsama-sulud nga trait aron tudloan ang tipo sa mga nagpihig nga enum.
///
/// Kini nga trait ang awtomatikong gipatuman alang sa matag matang, ug wala makadugang sa bisan unsa nga garantiya sa [`mem::Discriminant`].
/// Kini mao ang **dili tino ang kinaiya** sa dalayegon sa taliwala sa `DiscriminantKind::Discriminant` ug `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ang tipo sa diskriminasyon, nga kinahanglan makatagbaw sa trait bounds nga gikinahanglan sa `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Tighipos-internal trait gigamit aron sa pagtino kon ang usa ka matang naglangkob sa bisan unsa nga `UnsafeCell` internal, apan dili pinaagi sa usa ka indirection.
///
/// Makaapekto kini, pananglitan, kung ang usa ka `static` nga kana nga klase gibutang sa read-only static memory o gisulat nga panumduman nga static.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Mga lahi nga mahimo`g luwas nga malihok human ma-pin.
///
/// Rust sa iyang kaugalingon walay ideya sa dili matarug matang, ug giisip nagalihok (pananglitan, pinaagi sa buluhaton o [`mem::replace`]) kanunay nga luwas.
///
/// Ang matang [`Pin`][Pin] gigamit inay sa pagpugong nagalihok pinaagi sa matang sa sistema.Point `P<T>` giputos sa [`Pin<P<T>>`][Pin] wrapper dili matarug sa.
/// Tan-awa ang dokumentasyon nga [`pin` module] alang sa dugang nga kasayuran sa pag-pin.
///
/// Pagpatuman sa `Unpin` trait alang `T` gituboy ang mga pagdili sa pinning sa matang, nga unya nagtugot sa pagbalhin `T` gikan sa [`Pin<P<T>>`][Pin] uban sa mga gimbuhaton sama sa [`mem::replace`].
///
///
/// `Unpin` walay sangputanan sa tanan alang sa mga dili-pinned data.
/// Sa partikular, [`mem::replace`] malipayon nagalihok `!Unpin` data (kini sa mga buhat alang sa bisan unsa nga `&mut T`, dili lamang sa dihang `T: Unpin`).
/// Bisan pa, dili nimo magamit ang [`mem::replace`] sa datos nga giputos sa sulud sa usa ka [`Pin<P<T>>`][Pin] tungod kay dili nimo makuha ang `&mut T` nga imong gikinahanglan alang niana, ug *kana* mao ang nagpalihok sa kini nga sistema.
///
/// Busa niini, alang sa panig-ingnan, mahimo lamang nga buhaton sa mga matang sa pagpatuman `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Kinahanglan namon ang us aka mutable nga pakisayran aron tawagan ang `mem::replace`.
/// // Mahimo naton makuha ang ingon nga pakisayran sa (implicitly) nga naghangyo sa `Pin::deref_mut`, apan posible lamang kana tungod kay gipatuman sa `String` ang `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Kini nga trait ang awtomatikong gipatuman alang sa halos tanang matang.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Usa ka tipo sa marker diin wala ipatuman ang `Unpin`.
///
/// Kon ang usa ka matang naglakip sa usa ka `PhantomPinned`, dili kini pagpatuman `Unpin` pinaagi sa default.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementar sa sa `Copy` alang sa karaang matang.
///
/// Implementar sa nga dili gihulagway diha sa Rust ang gipatuman sa `traits::SelectionContext::copy_clone_conditions()` sa `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Mipakigbahin mga pakisayran mahimong kopyahon, apan mutable mga pakisayran *dili*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}