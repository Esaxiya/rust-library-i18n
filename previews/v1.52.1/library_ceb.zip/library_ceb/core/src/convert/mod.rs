//! Traits alang sa pagkakabig sa taliwala sa mga matang.
//!
//! Ang traits sa kini nga module naghatag usa ka paagi aron mabalhin gikan sa us aka tipo ngadto sa lain nga tipo.
//! Ang matag trait nag-alagad sa usa ka lain-laing mga katuyoan:
//!
//! - Ipatuman ang [`AsRef`] trait alang sa barato nga mga pagkakabig sa reperensya sa reperensiya
//! - Sa pagpatuman sa [`AsMut`] trait alang sa barato nga mutable-sa-mutable pagkakabig
//! - Sa pagpatuman sa [`From`] trait alang sa nga nagaut-ut bili-sa-bili pagkakabig
//! - Sa pagpatuman sa [`Into`] trait alang sa nga nagaut-ut bili-sa-bili pagkakabig ngadto sa matang sa gawas sa kasamtangan nga crate
//! - Ang [`TryFrom`] ug [`TryInto`] traits magbinuotan sama sa [`From`] ug [`Into`], apan kinahanglan nga ipatuman sa diha nga ang pagkakabig mapakyas.
//!
//! Ang traits sa module niini kanunay nga gigamit ingon nga trait bounds alang sa generic nga gimbuhaton sa ingon nga sa mga argumento sa daghang matang gisuportahan.Tan-awa ang dokumentasyon sa matag trait alang sa panig-ingnan.
//!
//! Ingon sa usa ka librarya tagsulat, kamo kinahanglan nga sa kanunay gusto sa pagpatuman [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] kay sa [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], ingon sa [`From`] ug [`TryFrom`] paghatag og mas dako nga pagka-flexible ug sa paghalad sa katumbas [`Into`] o [`TryInto`] implementar alang sa free, salamat sa usa ka habol nga pagpatuman sa standard librarya.
//! Kung ang pag-target sa usa ka bersyon sa wala pa ang Rust 1.41, mahimo nga kinahanglan nga ipatuman ang [`Into`] o [`TryInto`] direkta kung magkombertir sa us aka klase sa gawas sa karon nga crate.
//!
//! # Mga Generic nga Pagpatuman
//!
//! - [`AsRef`] ug [`AsMut`] auto-dereference kon sa sulod nga matang mao ang usa ka pakisayran
//! - [`Gikan`]`<U>alang sa T` nagpasabot [`Ngadto`]`</u><T><U>alang sa U`</u>
//! - [`TryFrom`]`<U>alang sa T` nagpasabot [`TryInto`]`</u><T><U>alang sa U`</u>
//! - [`From`] ug [`Into`] mga reflexive, nga nagpasabut nga ang tanan nga mga lahi mahimo nga `into` sa ilang mga kaugalingon ug `from` mismo
//!
//! Kitaa ang matag trait alang sa mga pananglitan sa paggamit.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Ang pagpaandar sa identidad.
///
/// Duha ka butang ang hinungdanon nga hinumdoman bahin sa kini nga kalihokan:
///
/// - Kini dili kanunay katumbas sa usa ka pagsira sama sa `|x| x`, tungod kay ang pagsira mahimong pugson ang `x` sa usa ka lahi nga lahi.
///
/// - Kini nagpalihok sa mga input `x` miagi sa function.
///
/// Samtang daw nga lain nga adunay usa ka function nga lang returns balik sa input, adunay mga pipila ka mga makapaikag nga mga gamit.
///
///
/// # Examples
///
/// Ang paggamit sa `identity` wala'y mahimo sa usa ka han-ay sa uban pa, makaikag, mga gimbuhaton:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Pagpakaaron-ingnon naton nga ang pagdugang usa usa ka makaiikag nga paglihok.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Pinaagi sa paggamit sa `identity` ingon sa usa ka base kaso "do nothing" sa usa ka conditional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Buhata ang labi ka makapaikag nga mga butang ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Pinaagi sa paggamit sa `identity` sa pagbantay sa `Some` lahi sa usa ka iterator sa `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Gigamit sa pagbuhat sa usa ka barato nga paghisgot-sa-reference pagkakabig.
///
/// Kini trait mao ang susama sa [`AsMut`] nga gigamit alang sa pagkabig sa taliwala sa mutable mga pakisayran.
/// Kon imong gikinahanglan aron sa pagbuhat sa usa ka mahalon nga pagkakabig kini mao ang mas maayo sa pagpatuman sa [`From`] sa matang `&T` o pagsulat sa usa ka batasan function.
///
/// `AsRef` adunay parehas nga pirma sama sa [`Borrow`], apan ang [`Borrow`] lahi sa pipila ka mga aspeto:
///
/// - Dili sama sa `AsRef`, [`Borrow`] adunay usa ka habol impl alang sa bisan unsa `T`, ug mahimong gamiton sa pagdawat sa bisan sa usa ka pakisayran o sa usa ka bili.
/// - [`Borrow`] nagkinahanglan usab nga [`Hash`], [`Eq`] ug [`Ord`] alang sa hinulaman bili katumbas sa sa mga sa sa gipanag-iya nga bili.
/// Tungod niini nga hinungdan, kung gusto nimo manghulam usa ra ka uma sa usa ka istruktura nga mahimo nimo ipatuman ang `AsRef`, apan dili ang [`Borrow`].
///
/// **Note: Kini nga trait dili gayud mapakyas **.Kon ang pagkakabig mahimong mapakyas, sa paggamit sa usa ka hinalad nga pamaagi nga mobalik sa usa ka [`Option<T>`] o sa usa ka [`Result<T, E>`].
///
/// # Mga Generic nga Pagpatuman
///
/// - `AsRef` auto-dereferences kung ang sulud nga tipo usa ka pakisayran o us aka mutable nga pakisayran (pananglitan: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Pinaagi sa paggamit sa trait bounds nga kita modawat sa mga argumento sa mga lain-laing mga matang sa kadugayon nga sila mahimong makabig ngadto sa bungat matang `T`.
///
/// Pananglitan: Pinaagi sa paghimo sa usa ka generic function nga nagkinahanglan sa usa ka `AsRef<str>` atong ipahayag nga kita gusto nga modawat sa tanan nga mga pakisayran nga mahimong makabig ngadto sa [`&str`] ingon nga usa ka argumento.
/// Tungod kay ang duha [`String`] ug [`&str`] pagpatuman `AsRef<str>` nga kita modawat sa duha ingon sa input argumento.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Nagbuhat, naghimo sa pagkakabig.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Gigamit aron mahimo ang usa ka barato nga mabalhin-sa-mabalhin nga pakli nga reperensiya.
///
/// Kini trait mao ang susama sa [`AsRef`] apan gigamit alang sa pagkabig sa taliwala sa mutable mga pakisayran.
/// Kung kinahanglan nimo buhaton ang usa ka mahal nga pagkakabig mas maayo nga ipatuman ang [`From`] nga adunay tipo nga `&mut T` o pagsulat usa ka naandan nga kalihokan.
///
/// **Note: Kini nga trait dili gayud mapakyas **.Kon ang pagkakabig mahimong mapakyas, sa paggamit sa usa ka hinalad nga pamaagi nga mobalik sa usa ka [`Option<T>`] o sa usa ka [`Result<T, E>`].
///
/// # Mga Generic nga Pagpatuman
///
/// - `AsMut` auto-dereferences kon sa sulod nga matang mao ang usa ka mutable pakisayran (eg: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Pinaagi sa paggamit sa `AsMut` ingon trait bound alang sa usa ka generic function nga atong pagdawat sa tanan nga mga mutable mga pakisayran nga mahimong makabig ngadto sa type `&mut T`.
/// Tungod kay gipatuman sa [`Box<T>`] ang `AsMut<T>` mahimo namon isulat ang usa ka function `add_one` nga nagkuha sa tanan nga mga argumento nga mahimong mabalhin sa `&mut u64`.
/// Tungod kay [`Box<T>`] implementar `AsMut<T>`, `add_one` modawat argumento sa matang `&mut Box<u64>` ingon man:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Nagbuhat, naghimo sa pagkakabig.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Usa ka bili-sa-kantidad nga pagkakabig nga nag-usik sa kantidad sa pagsulud.Ang kaatbang sa [`From`].
///
/// Usa ka kinahanglan sa paglikay sa pagpatuman sa [`Into`] ug pagpatuman [`From`] sa baylo.
/// Implementing [`From`] awtomatikong naghatag sa usa uban sa usa ka pagpatuman sa [`Into`] mga pasalamat ngadto sa habol pagpatuman sa standard librarya.
///
/// Mas gusto ang paggamit sa [`Into`] labaw sa [`From`] kung gipiho ang trait bounds sa usa ka generic function aron masiguro nga ang mga tipo nga nagpatuman ra sa [`Into`] mahimo usab nga magamit.
///
/// **Note: Kini nga trait kinahanglan dili magpakyas **.Kung ang pagkabig mahimong mapakyas, gamita ang [`TryInto`].
///
/// # Mga Generic nga Pagpatuman
///
/// - [`Gikan`]`<T>alang sa U` nagpasabot `Into<U> for T`
/// - [`Into`] reflexive, nga nagpasabut nga gipatuman ang `Into<T> for T`
///
/// # Pagpatuman sa [`Into`] alang sa mga pagkakabig sa mga panggawas nga tipo sa daang mga bersyon sa Rust
///
/// Sa wala pa Rust 1.41, kon ang destinasyon matang dili bahin sa kasamtangan nga crate unya ikaw dili pagpatuman [`From`] direkta.
/// Pananglitan, kuhaa kini nga code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Mapakyas kini sa pagtipon sa labing daan nga mga bersyon sa sinultian tungod kay ang mga panudlo sa orphaning sa Rust kaniadto labi ka istrikto.
/// Aron malaktawan kini, mahimo nimo nga ipatuman ang [`Into`] direkta:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Mahinungdanon nga masabtan nga ang [`Into`] wala maghatag usa ka pagpatuman sa [`From`] (sama sa gibuhat sa [`From`] sa [`Into`]).
/// Busa, kamo kinahanglan kanunay maningkamot sa pagpatuman [`From`] ug dayon mahulog balik sa [`Into`] kon [`From`] dili ipatuman.
///
/// # Examples
///
/// [`String`] nagpatuman [`Ngadto`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Aron mapahayag nga gusto namon ang usa ka generic function nga kuhaon ang tanan nga mga argumento nga mahimo`g mabalhin sa usa ka tin-aw nga tipo nga `T`, mahimo namon magamit ang usa ka trait bound sa [`Into`]`<T>`.
///
/// Pananglitan: Ang function `is_hello` nagkinahanglan sa tanan nga mga argumento nga mahimong makabig ngadto sa usa ka [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Nagbuhat, naghimo sa pagkakabig.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Gigamit sa pagbuhat sa bili-sa-bili pagkakabig samtang nga nagaut-ut sa input nga bili.Kini mao ang katugbang nga sa [`Into`].
///
/// Kinahanglan kanunay nga gusto sa usa ang pagpatuman sa `From` labaw sa [`Into`] tungod kay ang pagpatuman sa `From` awtomatikong naghatag sa usa nga adunay usa ka pagpatuman sa [`Into`] salamat sa pagpatuman sa habol sa sagad nga librarya.
///
///
/// Ipatuman ra ang [`Into`] kung gipunting ang usa ka bersyon sa wala pa ang Rust 1.41 ug pagkabig sa usa ka tipo sa gawas sa karon nga crate.
/// `From` dili makahimo sa pagbuhat niini nga mga matang sa mga pagkakabig sa unang bersiyon tungod sa orphaning lagda ni Rust.
/// Tan-awa ang [`Into`] alang sa dugang nga mga detalye.
///
/// Gusto sa paggamit sa [`Into`] sa paggamit sa `From` sa diha nga specifying trait bounds sa usa ka generic function.
/// Kini nga paagi, matang nga direktang pagpatuman [`Into`] mahimong gamiton ingon nga mga argumento ingon man.
///
/// Ang `From` usab mapuslanon kung naghimo sa pagdumala sa sayup.Kung ang paghimo sa usa ka pagpaandar nga mahimo`g mapakyas, ang tipo sa pagbalik sa kasagaran mahimo`g porma `Result<T, E>`.
/// Ang `From` trait mopayano sayop pagdumala pinaagi sa pagtugot sa usa ka function sa pagbalik sa usa ka matang sayop nga encapsulate daghang matang sa sayop.Tan-awa ang seksyon nga "Examples" ug [the book][book] alang sa dugang nga mga detalye.
///
/// **Note: Kini nga trait dili gayud mapakyas **.Kung ang pagkabig mahimong mapakyas, gamita ang [`TryFrom`].
///
/// # Mga Generic nga Pagpatuman
///
/// - `From<T> for U` nagpasabot [`Ngadto`]`<U>alang sa T`</u>
/// - `From` mao reflexive, nga nagpasabot nga `From<T> for T` gipatuman
///
/// # Examples
///
/// [`String`] nagpatuman `From<&str>`:
///
/// Usa ka tin-aw nga pagkakabig gikan sa usa ka `&str` ngadto sa usa ka hilo nahimo nga ingon sa mosunod:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Samtang sa pagbuhat sa sayop pagdumala niini mao ang kanunay nga mapuslanon sa pagpatuman `From` alang sa inyong kaugalingon nga matang kasaypanan.
/// Pinaagi sa pagkabig sa nahiilalum matang sayop sa atong kaugalingong batasan matang kasaypanan nga encapsulates ang tinuod nga hinungdan sa matang sayop, kita makabalik sa usa ka matang sayop nga walay pagkawala sa impormasyon sa hinungdan.
/// Ang '?' operator awtomatikong mga kinabig sa nahiilalum matang sayop sa atong batasan nga matang sayop pinaagi sa pagtawag `Into<CliError>::into` nga awtomatikong gihatag sa diha nga pagpatuman sa `From`.
/// Pagkahuman gisudya sa tagompuno kung unsang pagpatuman sa `Into` ang kinahanglan gamiton.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Nagbuhat, naghimo sa pagkakabig.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Usa ka misulay pagkakabig nga magasunog hangtud `self`, nga mahimo o dili mahimo nga mahal.
///
/// Ang mga tagsulat sa librarya dili sagad nga dili direkta nga ipatuman kini nga trait, apan kinahanglan nga ipalabi ang pagpatuman sa [`TryFrom`] trait, nga nagtanyag labi ka daghang pagkaayo ug naghatag us aka katumbas nga `TryInto` nga pagpatuman nga libre, salamat sa usa ka habol nga pagpatuman sa sumbanan nga librarya.
/// Alang sa dugang nga kasayuran bahin niini, tan-awa ang dokumentasyon alang sa [`Into`].
///
/// # Pagpatuman sa `TryInto`
///
/// Nag-antos kini sa parehas nga mga pagdili ug pangatarungan sama sa pagpatuman sa [`Into`], kitaa didto alang sa mga detalye.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Gibalik ang klase kung adunay sayup nga pagkakabig.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Nagbuhat, naghimo sa pagkakabig.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Yano ug luwas nga tipig nga mga pagkakabig nga mahimong mapakyas sa usa ka kontrolado nga paagi sa ilalum sa pipila ka mga kahimtang.Kini ang sukli sa [`TryInto`].
///
/// Kini mapuslanon kung nagbuhat ka usa ka klase nga pagkakabig nga mahimo`g gamay nga kalampusan apan mahimo usab nga kinahanglan nimo ang espesyal nga pagdumala.
/// Pananglitan, wala`y paagi aron mabalhin ang usa ka [`i64`] ngadto sa usa ka [`i32`] gamit ang [`From`] trait, tungod kay ang usa ka [`i64`] mahimong adunay sulud nga usa ka kantidad nga dili mahimo`g representante sa usa ka [`i32`] ug busa ang pagkakabig mawad-an sa datos.
///
/// Mahimo kini nga pagdumala pinaagi sa pagputol sa [`i64`] sa usa ka [`i32`] (hinungdanon nga hatagan ang kantidad nga modulo [`i32::MAX`] sa [`i64`]) o pinaagi sa pag-uli ra sa [`i32::MAX`], o sa ubang pamaagi.
/// Ang [`From`] trait gituyo alang sa hingpit nga pagkakabig, busa gipahibalo sa `TryFrom` trait ang programmer kung ang usa ka pag-usab sa tipo mahimo`g daotan ug tugotan sila nga magdesisyon kung unsaon kini pagdumala.
///
/// # Mga Generic nga Pagpatuman
///
/// - `TryFrom<T> for U` nagpasabut sa [`Sulayi Sa Kini`]`<U>alang sa T`</u>
/// - [`try_from`] mao reflexive, nga nagpasabot nga `TryFrom<T> for T` gipatuman ug dili mapakyas-ang nakig matang `Error` alang sa pagtawag `T::try_from()` sa usa ka bili sa matang `T` mao [`Infallible`].
/// Sa diha nga ang matang [`!`] mao ang estable sa [`Infallible`] ug [`!`] mahimong katumbas.
///
/// `TryFrom<T>` mahimong ipatuman ingon sa mosunud:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Ingon nga gihulagway, [`i32`] galamiton `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Sa hilum truncates `big_number`, nagkinahanglan pagsakop ug pagdumala sa truncation human sa kamatuoran.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Mobalik sa usa ka sayop tungod kay `big_number` kaayo dako nga aron mohaom sa usa ka `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Mibalik `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Gibalik ang klase kung adunay sayup nga pagkakabig.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Nagbuhat, naghimo sa pagkakabig.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Ingon sa gibayaw sa&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ingon sa pagtaas sa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): mopuli sa ibabaw impls alang sa&/&Mut uban sa mosunod nga mga labaw nga kinatibuk-ang usa ka:
// // Ingon sa pagbayaw sa Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>alang sa D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Gibayaw sa AsMut ang labaw sa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ilisan ang sa itaas nga impl alang sa &mut sa mosunud nga labi ka kadaghanan:
// // Gibayaw sa AsMut ang DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>alang sa D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Gikan sa nagpasabut sa
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Gikan sa (ug sa ingon Ngadto sa) mao ang reflexive
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **kalig-on Mubo nga sulat sa:** impl Kini wala pa anaa, apan kita "reserving space" sa pagdugang niini sa future.
/// Tan-awa ang [rust-lang/rust#64715][#64715] alang sa mga detalye.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): sa pagbuhat sa usa ka prinsipyo ayuhon sa baylo.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Ang TryFrom nagpasabot nga Pagsulay Sa
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Ang mga dili mabag-o nga pagkabag-o katumbas sa semantikal nga mga sayup nga pagkakabig nga adunay usa ka lahi nga klase nga sayup.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// CONCRETE IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ANG WALA-SAYOP NGA MATUOD NGA SAYOP
////////////////////////////////////////////////////////////////////////////////

/// Ang tipo sa sayup alang sa mga sayup nga dili gyud mahimo.
///
/// Tungod kay kini nga enum walay laing, sa usa ka bili sa niini nga matang dili gayud tinuod nga anaa.
/// Kini mahimong mapuslanon alang sa generic Apis nga paggamit sa [`Result`] ug parameterize sa matang sa sayop, nagpakita nga ang resulta mao ang kanunay [`Ok`].
///
/// Kay sa panig-ingnan, ang [`TryFrom`] trait (pagkakabig nga pagbalik sa usa ka [`Result`]) nga adunay usa ka habol pagpatuman alang sa tanan nga matang sa diin anaa ang usa ka reverse [`Into`] pagpatuman.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Pagkaangay sa Future
///
/// enum Kini nga sa mao usab nga papel ingong [the `!`“never”type][never], nga mao ang mabalhinon sa niini nga bersyon sa Rust.
/// Sa diha nga `!` mao ang estable, magplano kami sa paghimo sa `Infallible` usa ka matang alyas niini:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ug sa katapusan gihikawan ang `Infallible`.
///
/// Apan adunay usa ka kaso diin `!` syntax mahimong gamiton sa atubangan `!` mao ang estable sa ingon nga sa usa ka bug-os-fledged matang: sa posisyon sa matang pagbalik sa usa ka function ni.
/// Sa piho nga paagi, posible nga pagpatuman alang sa duha nga magkalainlain nga tipo sa pag-andar:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Uban sa `Infallible` nga usa ka enum, kini nga code mao ang balido.
/// Apan sa diha nga `Infallible` mahimong usa ka alyas alang sa never type, ang duha ka `impl`s magsugod sa sapaw ug busa nga gisalikway sa trait pagsunod sa mga lagda sa pinulongan ni.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}