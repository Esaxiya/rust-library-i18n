//! Opsyonal nga mga prinsipyo.
//!
//! Ang tipo nga [`Option`] nagrepresentar sa usa ka opsyonal nga kantidad: matag [`Option`] parehas nga [`Some`] ug adunay sulud, o [`None`], ug dili.
//! [`Option`] matang kaayo komon sa Rust code, ingon nga sila sa usa ka gidaghanon sa mga gamit:
//!
//! * Mga pasiuna nga kantidad
//! * Ibalik ang mga kantidad alang sa mga pag-andar nga dili gipiho sa tibuuk nga sakup sa pag-input (bahin nga pag-andar)
//! * Ibalik ang kantidad alang kung dili ang pagreport sa yano nga mga sayup, diin ang [`None`] gibalik sa sayup
//! * Opsyonal nga mga uma sa estruktura
//! * Mga istraktura nga umahan nga mahimong ipahulam o "taken"
//! * Opsyonal nga mga argumento sa paglihok
//! * Dili matudlo nga mga panudlo
//! * Pagpuli sa mga butang gikan sa lisud nga mga kahimtang
//!
//! Ang [`Option`] s sagad nga giparis sa sumbanan nga pagtandi aron pangutan-on ang presensya sa usa ka kantidad ug paglihok, kanunay giisip ang kaso nga [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Ang pagbalik bili sa function mao ang usa ka kapilian
//! let result = divide(2.0, 3.0);
//!
//! // Pareha sa sumbanan aron makuha ang kantidad
//! match result {
//!     // division mao ang balido nga
//!     Some(x) => println!("Result: {}", x),
//!     // Dili husto ang pagkabahinbahin
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Ipakita kung giunsa ang `Option` gigamit sa praktis, nga adunay daghang mga pamaagi
//
//! # Mga kapilian ug panudlo ("nullable" pointers)
//!
//! Ang mga tipo sa pointer sa Rust kinahanglan kanunay nga magtudlo sa usa ka balido nga lokasyon;wala`y mga pakisayran sa "null".Hinunoa, Rust adunay *opsyonal* pointers, sama sa opsyonal nga gipanag-iya kahon, [`Option`]` <`[` Kahon<T>`]`> `.
//!
//! Ang mosunud nga pananglitan naggamit [`Option`] aron makahimo usa ka opsyonal nga kahon nga [`i32`].
//! Timan-i nga aron magamit una ang sulud nga kantidad nga [`i32`], ang gamit nga `check_optional` kinahanglan nga mogamit sa pagsukma sa sundanan aron mahibal-an kung ang kahon adunay usa ka kantidad (ie, kini mao ang [`Some(...)`][`Some`]) o dili ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Gipasalig sa Rust nga ma-optimize ang mga mosunud nga lahi nga `T` nga ang [`Option<T>`] adunay parehas nga gidak-on sa `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` istruktura palibot sa usa sa mga lahi sa kini nga lista.
//!
//! Dugang nga gigarantiyahan nga, alang sa mga kaso sa taas, mahimo usa ka [`mem::transmute`] gikan sa tanan nga balido nga mga kantidad nga `T` hangtod `Option<T>` ug gikan sa `Some::<T>(_)` hangtod `T` (apan ang pagbalhin sa `None::<T>` ngadto sa `T` dili matino nga kinaiya).
//!
//! # Examples
//!
//! Panguna nga sumbanan sa sumbanan sa [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Pagkuha usa ka pakisayran sa sulud nga sulud
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Kuhaa ang sulud nga sulud, gub-on ang Kapilian
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Ig-una ang usa ka resulta sa [`None`] sa wala pa ang usa ka loop:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Usa ka listahan sa mga data sa pagpangita pinaagi sa.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Pangitaon namon ang ngalan sa labing kadaghan nga hayop, apan aron magsugod kami adunay `None` lamang.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Karon nakit-an namon ang ngalan sa pipila ka dako nga hayop
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// Ang matang `Option`.Tan-awa ang [the module level documentation](self) alang sa daghan pa.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Wala`y bili
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Ang pila nga kantidad `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Pagpatuman sa tipo
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Pagpangutana sa sulud nga sulud
    /////////////////////////////////////////////////////////////////////////

    /// Mobalik `true` kon ang kapilian mao ang usa ka [`Some`] bili.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Gibalik ang `true` kung ang kapilian usa ka kantidad nga [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Gibalik ang `true` kung ang kapilian usa ka kantidad nga [`Some`] nga adunay sulud nga gihatag nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter alang sa pagtrabaho uban ang mga pakisayran
    /////////////////////////////////////////////////////////////////////////

    /// Kinabig gikan sa `&Option<T>` ngadto sa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Gikabig ang usa ka `Option <` [`String`]`>`ngadto sa usa ka 'Option <`[`usize`]`> `, nga gipreserba ang orihinal.
    /// Gikuha sa pamaagi nga [`map`] ang argumento nga `self` pinaagi sa kantidad, pagkonsumo sa orihinal, mao nga kini nga pamaagi naggamit `as_ref` aron una nga kuhaon ang `Option` sa usa ka pakisayran sa kantidad sa sulud sa orihinal.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Una, isalibay ang `Option<String>` hangtod `Option<&String>` nga adunay `as_ref`, pagkahuman ubusa ang *kana* sa `map`, ibilin ang `text` sa stack.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Mga kinabig gikan sa `&mut Option<T>` hangtod `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Mga nakabig gikan sa [`Pin`]`<ug Kapilian<T>>`Sa`Option <`[`Pin`] `<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // KALUWASAN: Ang `x` gigarantiyahan nga ma-pin tungod kay gikan kini sa `self`
        // nga pinned.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Mga kinabig gikan sa [`Pin`]`<&mut Option<T>>`to`Option <`[`Pin`] `<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // KALUWASAN: Ang `get_unchecked_mut` wala gyud gigamit aron mabalhin ang `Option` sa sulud sa `self`.
        // `x` gigarantiyahan nga ma-pin tungod kay gikan kini sa `self` nga gi-pin.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Pagkuha sa sulud nga mga kantidad
    /////////////////////////////////////////////////////////////////////////

    /// Gibalik ang sulud nga kantidad nga [`Some`], nga gikonsumo ang kantidad nga `self`.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang kantidad usa ka [`None`] nga adunay usa ka naandan nga mensahe nga panic nga gihatag sa `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Gibalik ang sulud nga kantidad nga [`Some`], nga gikonsumo ang kantidad nga `self`.
    ///
    /// Tungod kay kini nga pagpaandar mahimo og panic, ang paggamit niini sa kadaghanan wala`y kadasig.
    /// Hinuon, gusto nga gamiton ang pagsukma sa sumbanan ug pagdumala ang kaso nga [`None`] nga tin-aw, o tawagan ang [`unwrap_or`], [`unwrap_or_else`], o [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics kung ang bili sa kaugalingon katumbas sa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Gibalik ang sulud nga kantidad nga [`Some`] o usa ka gihatag nga default.
    ///
    /// Ang mga pangatarungan nga gipasa sa `unwrap_or` madasigon nga gisusi;kung gipasa nimo ang sangputanan sa usa ka tawag sa pag-andar, girekomenda nga gamiton ang [`unwrap_or_else`], nga tapulan nga gisusi.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Gibalik ang sulud nga kantidad nga [`Some`] o gikwenta kini gikan sa usa ka pagsira.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Gibalik ang sulud nga kantidad nga [`Some`], gikonsumo ang kantidad nga `self`, nga wala`y pagsusi nga ang kantidad dili [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa kini nga pamaagi sa [`None`] mao ang *[wala matino nga kinaiya]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Dili tino ang kinaiya!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // SAFETY: ang kaluwasan kontrata kinahanglan gituboy pinaagi sa caller.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ang pagbag-o adunay sulud nga mga kantidad
    /////////////////////////////////////////////////////////////////////////

    /// Ang mapa usa ka `Option<T>` hangtod `Option<U>` pinaagi sa pag-apply sa usa ka function sa usa ka sulud nga kantidad.
    ///
    /// # Examples
    ///
    /// Gikabig ang usa ka `Option <` [`String`]`>` ngadto sa usa ka 'Option <`[` usize`]`>`, nga ninggamit sa orihinal:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` Gikuha ang kaugalingon *sa kantidad*, nga nag-usik sa `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Nag-apply usa ka function sa sulud nga sulud (kung adunay), o gibalik ang gihatag nga default (kung wala).
    ///
    /// Ang mga pangatarungan nga gipasa sa `map_or` madasigon nga gisusi;kung gipasa nimo ang sangputanan sa usa ka tawag sa pag-andar, girekomenda nga gamiton ang [`map_or_else`], nga tapulan nga gisusi.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Nag-apply usa ka function sa sulud nga sulud (kung adunay), o giisip ang usa ka default (kung wala).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Transforms sa `Option<T>` ngadto sa usa ka [`Result<T, E>`], mapa [`Some(v)`] sa [`Ok(v)`] ug [`None`] sa [`Err(err)`].
    ///
    /// Argumento miagi sa `ok_or` maikagong evaluate;kung gipasa nimo ang sangputanan sa usa ka tawag sa pag-andar, girekomenda nga gamiton ang [`ok_or_else`], nga tapulan nga gisusi.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Gibag-o ang `Option<T>` sa usa ka [`Result<T, E>`], pagmapa sa [`Some(v)`] hangtod [`Ok(v)`] ug [`None`] hangtod [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Gisal-ot ang `value` sa kapilian unya gibalik ang usa ka mabalhin nga pakisayran niini.
    ///
    /// Kung ang kapilian adunay sulud usa ka kantidad, ang daan nga kantidad gihulog.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // SAFETY: ang code sa ibabaw lang napuno sa mga kapilian
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Mga magtutukod sa Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Nagbalik usa ka iterator sa posible nga sulud nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Nagbalik usa ka mabalhin nga iterator sa posible nga sulud nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ang operasyon sa Boolean sa mga kantidad, mahinamon ug tapulan
    /////////////////////////////////////////////////////////////////////////

    /// Gibalik ang [`None`] kung ang kapilian [`None`], kung dili ibalik ang `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Gibalik ang [`None`] kung ang kapilian [`None`], kung dili tawgon ang `f` nga adunay balot nga kantidad ug ibalik ang resulta.
    ///
    ///
    /// Ang ubang mga sinultian nagtawag sa kini nga operasyon nga flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Gibalik ang [`None`] kung ang kapilian [`None`], kung dili tawgon ang `predicate` nga adunay balot nga kantidad ug mobalik:
    ///
    ///
    /// - [`Some(t)`] kung ibalik sa `predicate` ang `true` (diin ang `t` mao ang balot nga kantidad), ug
    /// - [`None`] kung ang `predicate` mobalik `false`.
    ///
    /// Ang kini nga kalihokan molihok nga parehas sa [`Iterator::filter()`].
    /// Mahanduraw nimo ang `Option<T>` nga usa ka iterator sa usa o zero nga elemento.
    /// `filter()` tugotan ka nga maghukum kung unsang mga elemento ang ipadayon.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Gibalik ang kapilian kung adunay sulud kini nga kantidad, kung dili ibalik ang `optb`.
    ///
    /// Ang mga pangatarungan nga gipasa sa `or` madasigon nga gisusi;kung gipasa nimo ang sangputanan sa usa ka tawag sa pag-andar, girekomenda nga gamiton ang [`or_else`], nga tapulan nga gisusi.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Gibalik ang kapilian kung adunay sulud kini nga kantidad, kung dili nagtawag sa `f` ug ibalik ang sangputanan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Gibalik ang [`Some`] kung eksakto ang usa sa `self`, `optb` ang [`Some`], kung dili ibalik ang [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Pagsulod-sama sa operasyon sa sal-ot kon Walay ug mobalik sa usa ka pakisayran
    /////////////////////////////////////////////////////////////////////////

    /// Gisal-ot ang `value` sa kapilian kung kini [`None`], pagkahuman ibalik ang usa ka mabalhin nga pakisayran sa sulud nga kantidad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Gisal-ot ang default nga kantidad sa kapilian kung kini [`None`], pagkahuman ibalik ang usa ka mabalhin nga pakisayran sa sulud nga sulud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Misal-ot sa usa ka bili computed gikan sa `f` ngadto sa kapilian kon kini mao ang [`None`], dayon mobalik sa usa ka mutable paghisgot sa anaa bili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // KALUWASAN: usa ka `None` nga lahi alang sa `self` unta ang gipulihan sa usa ka `Some`
            // lahi sa code sa taas.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Gikuha ang bili sa kapilian, gibilin ang [`None`] sa lugar niini.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Gipulihan ang tinuud nga kantidad sa kapilian sa kantidad nga gihatag sa parameter, nga gibalik ang daang kantidad kung naa, nga gibilin ang [`Some`] sa lugar niini nga wala`y deinitializing nga bisan kinsa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Ang Zips `self` adunay uban pang `Option`.
    ///
    /// Kung ang `self` mao ang `Some(s)` ug ang `other` mao ang `Some(o)`, kini nga pamaagi mobalik sa `Some((s, o))`.
    /// Kay kon dili, `None` ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Ang Zips `self` ug uban pang `Option` nga adunay function `f`.
    ///
    /// Kon `self` mao `Some(s)` ug `other` mao `Some(o)`, kini nga pamaagi mobalik `Some(f(s, o))`.
    /// Kay kon dili, `None` ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Ang mapa usa ka `Option<&T>` sa usa ka `Option<T>` pinaagi sa pagkopya sa mga sulud sa kapilian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Maps sa usa ka `Option<&mut T>` sa usa ka `Option<T>` pinaagi sa pagkopya sa mga sulod sa kapilian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Ang mapa usa ka `Option<&T>` sa usa ka `Option<T>` pinaagi sa pag-clone sa sulud sa kapilian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Ang mapa usa ka `Option<&mut T>` sa usa ka `Option<T>` pinaagi sa pag-clone sa sulud sa kapilian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Gikonsumo ang `self` samtang nagpaabut sa [`None`] ug wala'y pagbalik.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang kantidad usa ka [`Some`], nga adunay usa ka mensahe nga panic lakip ang naagi nga mensahe, ug ang sulud sa [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Dili kini panic, tungod kay ang tanan nga mga yawi talagsaon.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Gikonsumo ang `self` samtang nagpaabut sa [`None`] ug wala'y pagbalik.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang kantidad usa ka [`Some`], nga adunay naandan nga mensahe nga panic nga gihatag sa kantidad nga ['Pipila`].
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Dili kini panic, tungod kay ang tanan nga mga yawi talagsaon.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Gibalik ang sulud nga kantidad nga [`Some`] o usa ka default
    ///
    /// Gikonsumo ang `self` nga argumento dayon, kung [`Some`], ibalik ang sulud nga sulud, kung dili kung [`None`], ibalik ang [default value] alang sa kana nga tipo.
    ///
    ///
    /// # Examples
    ///
    /// Gikabig ang usa ka hilo sa usa ka integer, nga gihimo nga dili maayo nga pagkaporma nga mga pisi sa 0 (ang default nga kantidad alang sa mga integer).
    /// [`parse`] gibag-o ang usa ka pisi sa bisan unsang uban pang lahi nga nagpatuman sa [`FromStr`], nga gibalik ang [`None`] sa sayup.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Mga kinabig gikan sa `Option<T>` (o `&Option<T>`) ngadto sa `Option<&T::Target>`.
    ///
    /// Gibiyaan ang orihinal nga Opsyon nga naa sa lugar, naghimo usa ka bag-o nga adunay usa nga pakigsulti sa orihinal, dugang nga pagpamugos sa mga sulud pinaagi sa [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Mga kinabig gikan sa `Option<T>` (o `&mut Option<T>`) ngadto sa `Option<&mut T::Target>`.
    ///
    /// Gibiyaan ang orihinal nga `Option` sa lugar, naghimo usa ka bag-o nga sulud nga adunay us aka mutable nga pakisayran sa `Deref::Target` nga lahi sa sulud nga tipo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Gibalhin ang usa ka `Option` sa usa ka [`Result`] sa usa ka [`Result`] sa usa ka `Option`.
    ///
    /// [`None`] mapa sa [`Ok`]`(`[`Wala`] `)`.
    /// [`Pipila`]`(`[`Ok`] `(_))` ug [`Pipila`]`(`[`Err`] `(_))` mapa ngadto sa [`Ok`]`(`[`Pipila`] `(_))` ug [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Kini usa ka bulag nga pag-andar aron maminusan ang kadako sa code nga .expect() mismo.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Kini usa ka bulag nga pag-andar aron maminusan ang kadako sa code nga .expect_none() mismo.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Pagpatuman sa Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Gibalik ang [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Gibalik ang usik nga iterator sa posible nga sulud nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Gikopya ang `val` sa usa ka bag-ong `Some`.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Kinabig gikan sa `&Option<T>` ngadto sa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Gikabig ang usa ka `Option <` [`String`]`>`ngadto sa usa ka 'Option <`[`usize`]`> `, nga gipreserba ang orihinal.
    /// Gikuha sa pamaagi nga [`map`] ang argumento nga `self` pinaagi sa kantidad, pagkonsumo sa orihinal, mao nga kini nga pamaagi naggamit `as_ref` aron una nga kuhaon ang `Option` sa usa ka pakisayran sa kantidad sa sulud sa orihinal.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Mga kinabig gikan sa `&mut Option<T>` hangtod `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ang Option Iterators
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Usa ka iterator sa us aka pakisayran sa [`Some`] nga lahi sa usa ka [`Option`].
///
/// Ang iterator nagahatag usa ka kantidad kung ang [`Option`] usa ka [`Some`], kung wala wala.
///
/// Kini nga `struct` gimugna sa [`Option::iter`] function.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Usa ka iterator sa us aka mutable nga pakisayran sa [`Some`] nga lahi sa usa ka [`Option`].
///
/// Ang iterator nagahatag usa ka kantidad kung ang [`Option`] usa ka [`Some`], kung wala wala.
///
/// Kini nga `struct` gimugna sa [`Option::iter_mut`] function.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Usa ka iterator sa kantidad sa [`Some`] nga lahi sa usa ka [`Option`].
///
/// Ang iterator nagahatag usa ka kantidad kung ang [`Option`] usa ka [`Some`], kung wala wala.
///
/// Kini nga `struct` gimugna sa [`Option::into_iter`] function.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Gikuha ang matag elemento sa [`Iterator`]: kung kini [`None`][Option::None], wala'y dugang nga mga elemento nga gikuha, ug ang [`None`][Option::None] ibalik.
    /// Kinahanglan nga dili mahitabo ang [`None`][Option::None], usa ka sulud nga adunay mga kantidad sa matag [`Option`] ang ibalik.
    ///
    /// # Examples
    ///
    /// Ania ang usa ka panig-ingnan nga increments sa matag integer sa usa ka vector.
    /// Gigamit namon ang gisusi nga variant sa `add` nga nagbalik `None` kung ang pagkalkula moresulta sa usa ka overflow.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Sama sa nakita nimo, ibalik niini ang gipaabot, balido nga mga butang.
    ///
    /// Ania ang usa pa nga pananglitan nga gisulayan nga kuhaon ang usa gikan sa us aka lista sa mga integer, ning higayona nagsusi alang sa underflow:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Tungod kay ang katapusang elemento zero, kini moagos.Sa ingon, ang sangputanan nga kantidad mao ang `None`.
    ///
    /// Ania ang usa ka pagbag-o sa miaging pananglitan, gipakita nga wala'y dugang nga mga elemento nga gikuha gikan sa `iter` pagkahuman sa una nga `None`.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Tungod kay ang ikatulo nga elemento hinungdan sa usa ka underflow, wala`y gikuha nga dugang nga mga elemento, busa ang katapusang kantidad nga `shared` mao ang 6 (= `3 + 2 + 1`), dili 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Kini mahimong pulihan sa Iterator::scan sa diha nga kini nga performance bug nga sirado.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Ang tipo sa sayup nga sangputanan gikan sa pagpadapat sa pagsulay sa operator (`?`) sa usa ka kantidad nga `None`.
/// Kung gusto nimo tugotan ang `x?` (diin ang `x` usa ka `Option<T>`) nga mabalhin sa imong tipo sa sayup, mahimo nimo ipatuman ang `impl From<NoneError>` alang sa `YourErrorType`.
///
/// Sa kini nga kaso, ang `x?` sulud sa usa ka pag-andar nga nagbalik sa `Result<_, YourErrorType>` maghubad sa usa ka `None` nga kantidad sa usa ka `Err` nga sangputanan.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Mga kinabig gikan sa `Option<Option<T>>` hangtod `Option<T>`
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Flattening removes usa lamang ka ang-ang sa nagsalag sa usa ka panahon:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}