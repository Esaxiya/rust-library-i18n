//! Mga lahi sa sayup alang sa pagkakabig ngadto sa dili managsama nga mga lahi.

use crate::convert::Infallible;
use crate::fmt;

/// Gibalik ang tipo sa sayup kung napakyas ang usa ka gisusi nga integral nga matang sa pagkakabig.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Pagtugma kaysa pagpamugos aron maseguro nga ang code sama sa `From<Infallible> for TryFromIntError` sa taas magpadayon sa paglihok kung ang `Infallible` mahimo`g usa ka alias sa `!`.
        //
        //
        match never {}
    }
}

/// Usa ka sayup nga mahimo`g ibalik kung gipa-parse ang usa ka integer.
///
/// Ang kini nga sayup gigamit ingon usa ka tipo sa sayup alang sa mga pag-andar sa `from_str_radix()` sa mga primitive integer type, sama sa [`i8::from_str_radix`].
///
/// # Mga potensyal nga hinungdan
///
/// Lakip sa uban pang mga hinungdan, ang `ParseIntError` mahimong itambog tungod sa pagpanguna o pagsubay sa whitespace sa hilo eg, kung makuha kini gikan sa sukaranan nga input.
///
/// Ang paggamit sa pamaagi nga [`str::trim()`] nagsiguro nga wala`y mapabilin nga kaputi sa wala pa pag-parse.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum aron tipigan ang lainlaing mga lahi sa sayup nga mahimong hinungdan nga mapakyas ang pag-parse sa usa ka integer.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Wala`y bili ang gipili nga bili.
    ///
    /// Lakip sa uban pang mga hinungdan, ang kini nga lahi itukod kung giparada ang usa ka walay sulod nga pisi.
    Empty,
    /// Adunay sulud nga dili husto nga digit sa sulud niini.
    ///
    /// Lakip sa uban pang mga hinungdan, ang kini nga lahi igatukod sa diha nga ang pag-parse sa usa ka pisi nga adunay sulud nga dili ASCII char.
    ///
    /// Ang kini nga lahi gitukod usab kung ang usa ka `+` o `-` wala ibutang sa sulud sa usa ka pisi sa kaugalingon o sa tunga-tunga sa usa ka numero.
    ///
    ///
    InvalidDigit,
    /// Ang integer daghan kaayo aron tipigan ang target nga tipo sa integer.
    PosOverflow,
    /// Ang integer gamay ra kaayo aron tipigan ang target nga tipo sa integer.
    NegOverflow,
    /// Ang kantidad mao ang Zero
    ///
    /// Ang kini nga lahi ibuga kung ang parsing nga string adunay kantidad nga zero, nga mahimong iligal alang sa dili-zero nga mga lahi.
    ///
    Zero,
}

impl ParseIntError {
    /// Mga output nga detalyado nga hinungdan sa pag-parse sa usa ka integer nga pagkapakyas.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}