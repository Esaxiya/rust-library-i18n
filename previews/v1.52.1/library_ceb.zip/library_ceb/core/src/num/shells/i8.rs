//! Kanunay alang sa 8-bit nga gipirmahan nga integer type.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Ang bag-ong kodigo kinahanglan gamiton direkta ang mga kauban nga koneksyon sa primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }