//! Kanunay alang sa 32-gamay nga wala pirma nga tipo sa integer.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Ang bag-ong kodigo kinahanglan gamiton direkta ang mga kauban nga koneksyon sa primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }