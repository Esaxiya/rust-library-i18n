//! Mabag alang sa 64-gamay matang gipirmahan integer.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Ang bag-ong kodigo kinahanglan gamiton direkta ang mga kauban nga koneksyon sa primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }