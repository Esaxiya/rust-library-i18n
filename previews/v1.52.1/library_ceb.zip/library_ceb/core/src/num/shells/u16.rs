//! Kanunay alang sa 16-gamay nga wala pirma nga tipo sa integer.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Ang bag-ong kodigo kinahanglan gamiton direkta ang mga kauban nga koneksyon sa primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }