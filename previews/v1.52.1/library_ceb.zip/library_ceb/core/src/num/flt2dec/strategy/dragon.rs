//! Hapit diretso (apan gamay na nga na-optimize) nga hubad sa Rust sa Larawan 3 sa "Pag-imprinta Mga Numeros nga Naglutaw-Punto Dali ug Sakto" [^ 1].
//!
//!
//! [^1]: Burger, RG ug Dybvig, RK 1996. Pag-print sa mga numero nga naglutaw-point
//!   dali ug ensakto.SIGPLAN Dili.31, 5 (Mayo. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// gikalkula nga mga array sa `Digit`s alang sa 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// magamit ra kung `x < 16 * scale`;Ang `scaleN` kinahanglan `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Ang labing mub-ot nga pagpatuman sa mode alang sa Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ang numero nga `v` nga pormat nahibal-an nga:
    // - katumbas sa `mant * 2^exp`;
    // - gisundan sa `(mant - 2 *minus)* 2^exp` sa orihinal nga tipo;ug
    // - gisundan sa `(mant + 2 *plus)* 2^exp` sa orihinal nga tipo.
    //
    // klaro, ang `minus` ug `plus` dili mahimo nga zero.(alang sa mga infinities, gigamit namon ang mga kantidad nga wala`y sakup.) Ginaisip usab namon nga bisan usa ka digit ang nakamugna, ie, ang `mant` dili mahimo usab nga zero.
    //
    // nagpasabut usab kini nga bisan unsang numero taliwala sa `low = (mant - minus)*2^exp` ug `high = (mant + plus)* 2^exp` mapa sa kini nga eksaktong numero sa naglutaw nga punto, nga adunay mga utlanan nga kauban kung ang orihinal nga mantissa parehas (ie, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ang `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // banabana ang `k_0` gikan sa orihinal nga mga input nga matagbawon nga `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ang hugut nga gihigot nga `k` matagbaw nga `10^(k-1) < high <= 10^k` gikalkulo sa ulahi.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ibaylo ang `{mant, plus, minus} * 2^exp` ngadto sa porma nga praksyonal aron:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // bahinon ang `mant` sa `10^k`.karon `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // pag-ayo sa diha nga `mant + plus > scale` (o `>=`).
    // wala namon tinuud nga pagbag-o ang `scale`, tungod kay mahimo namon laktawan ang una nga pagdaghan hinoon.
    // karon `scale < mant + plus <= scale * 10` ug andam kami sa pagmugna mga digit.
    //
    // timan-i nga ang `d[0]`*mahimo* nga zero, kung `scale - plus < mant < scale`.
    // sa kini nga kahimtang nga kahimtang sa pag-ikot (`up` sa ubus) mapukaw dayon.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // katumbas sa pag-scale sa `scale` sa 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` alang sa digit nga henerasyon.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // mga invariant, diin ang `d[0..n-1]` mga digit nga nahimo hangtod karon:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (sa ingon `mant / scale < 10`) diin ang `d[i..j]` us aka mubo alang sa `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // makamugna usa ka digit: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // kini usa ka gipayano nga paghulagway sa giusab nga Dragon algorithm.
        // Daghang mga panagsama nga gigikanan ug pagkumpleto nga mga argumento nga gitangtang alang sa kasayon.
        //
        // magsugod sa gibag-o nga mga invariant, tungod kay gi-update namon ang `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ibutang nga ang `d[0..n-1]` mao ang labing mubu nga representasyon taliwala sa `low` ug `high`, ie, ang `d[0..n-1]` nagtagbaw sa pareho sa mosunud apan ang `d[0..n-2]` wala:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: mga digit nga bilog hangtod `v`);ug
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (tama ang katapusang numero).
        //
        // ang ikaduha nga kondisyon nagpasayon sa `2 * mant <= scale`.
        // ang pagsulbad sa mga invariant sa termino sa `mant`, `low` ug `high` nagahatag usa ka labi ka yano nga bersyon sa unang kondisyon: `-plus < mant < minus`.
        // sukad sa `-plus < 0 <= mant`, adunay kami husto nga labing mubu nga representasyon kung ang `mant < minus` ug `2 * mant <= scale`.
        // (ang nahauna mahimong `mant <= minus` kung parehas ang orihinal nga mantissa.)
        //
        // kung ang ikaduha wala maggunit (`2 * mant> scale`), kinahanglan naton nga dugangan ang katapusang numero.
        // igo na kini alang sa pagpahiuli sa kana nga kondisyon: nahibal-an na namon nga ang digital nga henerasyon naghatag garantiya sa `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // sa kini nga kaso, ang una nga kondisyon mahimong `-plus < mant - scale < minus`.
        // sukad sa `mant < scale` pagkahuman sa henerasyon, adunay kami `scale < mant + plus`.
        // (pag-usab, mahimo kini `scale <= mant + plus` kung parehas ang orihinal nga mantissa.)
        //
        // sa laktod:
        // - hunong ug lingin ang `down` (ipadayon ang mga digit sama sa) kung `mant < minus` (o `<=`).
        // - hunong ug lingin ang `up` (dugangi ang katapusang numero) kung `scale < mant + plus` (o `<=`).
        // - padayon sa pagmugna kung dili.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // kami adunay labing mubu nga representasyon, magpadayon sa pag-ikot

        // ibalik ang mga nagdapit.
        // gihimo niini nga kanunay gitapos ang algorithm: ang `minus` ug `plus` kanunay nagdugang, apan ang `mant` gipunting nga modulo `scale` ug ang `scale` naayo.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Nahitabo ang pag-round sa kung i) ang kahimtang ra sa pag-ikot ang na-trigger, o ii) parehas nga mga kondisyon ang natangtang ug ang pagguba sa kurbatang gusto nga pag-ikid.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // kung ang pag-round up nagbag-o sa gitas-on, kinahanglan usab magbag-o ang exponent.
        // ingon nga kini nga kahimtang lisud kaayo makatagbaw (posible nga imposible), apan luwas ug sigurado ra kita dinhi.
        //
        // SAFETY: kita initialized nga handumanan sa ibabaw.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: kita initialized nga handumanan sa ibabaw.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Ang ensakto ug naayo nga pagpatuman sa mode alang sa Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // banabana ang `k_0` gikan sa orihinal nga mga input nga matagbawon nga `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // bahinon ang `mant` sa `10^k`.karon `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // pag-ayo sa diha nga `mant + plus >= scale`, diin `plus / scale = 10^-buf.len() / 2`.
    // aron mapadayon ang naayos nga gidak-on nga bignum, gigamit namon ang `mant + floor(plus) >= scale`.
    // wala namon tinuud nga pagbag-o ang `scale`, tungod kay mahimo namon laktawan ang una nga pagdaghan hinoon.
    // pag-usab uban ang labing mub-an nga algorithm, ang `d[0]` mahimo`g zero apan sa ulahi malibot.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // katumbas sa pag-scale sa `scale` sa 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // kung nagtrabaho kami sa katapusang digit nga limitasyon, kinahanglan namon nga pahubasan ang buffer sa wala pa ang aktuwal nga paghatag aron malikayan ang doble nga pag-ikot.
    //
    // timan-i nga kinahanglan naton nga padak-an pag-usab ang buffer kung mahitabo ang pag-ikot!
    let mut len = if k < limit {
        // oops, dili man kami makahimo paghimo usa ka * digit.
        // posible kini kung, ingon, adunay kami usa ka butang sama sa 9.5 ug kini gikutuban sa 10.
        // Gibalik namon ang usa ka walay sulod nga buffer, nga adunay eksepsyon sa ulahi nga pag-ikid nga kaso nga mahitabo kung ang `k == limit` ug kinahanglan nga maghimo og eksakto nga usa ka digit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` alang sa digit nga henerasyon.
        // (mahimo kini mahal, busa ayaw kuwentaha sila kung wala`y mahimo ang buffer.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // Ang mga mosunud sa mga digit pulos mga zero, mohunong kami dinhi ayaw *dili* pagsulay nga himuon ang pag-ikot!hinoon, pun-a ang nahabilin nga mga digit.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: kita initialized nga handumanan sa ibabaw.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // pag-round up kung mohunong kami sa tungatunga sa mga digit kung ang mga mosunud nga digit eksakto nga 5000 ..., susihon ang nag-una nga digit ug paningkamoti ang pag-ikid bisan (ie, likayi ang pag-round up kung parehas ang nauna nga digit).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // KALUWASAN: Ang `buf[len-1]` gisugdan.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // kung ang pag-round up nagbag-o sa gitas-on, kinahanglan usab magbag-o ang exponent.
        // apan gihangyo kami sa usa ka pirmi nga numero sa mga digit, busa ayaw usba ang buffer ...
        // SAFETY: kita initialized nga handumanan sa ibabaw.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... Gawas kung gihangyo hinoon kami ang gitakda nga ensakto.
            // kinahanglan usab naton nga susihon kana, kung ang orihinal nga buffer wala`y sulod, ang dugang nga digit mahimo ra nga idugang kung `k == limit` (kaso nga edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: kita initialized nga handumanan sa ibabaw.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}