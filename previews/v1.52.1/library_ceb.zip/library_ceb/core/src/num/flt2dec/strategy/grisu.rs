//! Ang Rust nga pagpahiangay sa Grisu3 algorithm nga gihulagway sa "Pag-print sa Mga Numero nga Floating-Point nga Dali ug Sakto sa mga Integer" [^ 1].
//! Ninggamit kini mga 1KB sa precomputed table, ug sa baylo, kini dali kaayo alang sa kadaghanan nga mga input.
//!
//! [^1]: Florian Loitsch.2010. Pagpatik sa mga numero sa naglutaw-punt nga dali ug
//!   tukma sa mga integer.SIGPLAN Dili.45, 6 (Hunyo 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// tan-awa ang mga komentaryo sa `format_shortest_opt` alang sa katarungan.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Gihatag `x > 0`, mobalik `(k, 10^k)` sa ingon nga ang `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Sa labing mubo nga mode pagpatuman alang sa Grisu.
///
/// mobalik Kini `None` sa diha nga kini mobalik sa usa ka eksakto nga representasyon kon dili.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // kinahanglan naton labing menos tulo nga tipik sa dugang nga katukma

    // magsugod sa na-normalize nga kantidad sa gipaambit nga exponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // pangitaa ang bisan unsang `cached = 10^minusk` nga ingon niana `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // tungod kay ang `plus` na-normalize, kini nagpasabut nga `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // gihatag ang among mga kapilian nga `ALPHA` ug `GAMMA`, gibutang kini sa `plus * cached` sa `[4, 2^32)`.
    //
    // klaro nga kana nga pagatinguhaon mao ang pag-maximize sa `GAMMA - ALPHA`, mao nga dili namon kinahanglan daghang mga cache nga 10 nga gahum, apan adunay pipila nga mga konsiderasyon:
    //
    //
    // 1. gusto namon nga ipadayon ang `floor(plus * cached)` sulud sa `u32` tungod kay nanginahanglan kini usa ka mahal nga pagkabahin.
    //    (dili gyud kini malikayan, kinahanglan ang nahabilin alang sa pagbanabana sa katukma.)
    // 2.
    // ang nahabilin nga `floor(plus * cached)` balik-balik nga gipadaghan sa 10, ug dili kini kinahanglan mag-awas.
    //
    // ang una naghatag `64 + GAMMA <= 32`, samtang ang ikaduha naghatag `10 * 2^-ALPHA <= 2^64`;
    // -60 ug ang -32 mao ang pinakataas nga kutub sa kini nga pagpugong, ug gigamit usab kini sa V8.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // sukdanan fps.naghatag kini sa labing kadaghan nga sayup nga 1 ulp (napamatud-an gikan sa Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-tinuud nga han-ay sa minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // labaw sa `minus`, `v` ug `plus` ang mga *kadaghan* nga mga pagbanabana (sayup <1 ulp).
    // tungod kay wala kami nahibal-an nga ang sayup positibo o negatibo, gigamit namon ang duha nga mga pagbanabana nga parehas ang gintang ug adunay labing kadaghan nga sayup nga 2 ulps.
    //
    // ang "unsafe region" usa ka liberal interval nga una namong gihimo.
    // ang "safe region" usa ka konserbatibo nga agwat nga gidawat ra namon.
    // magsugod kami sa tama nga repr sa sulud sa dili luwas nga rehiyon, ug paningkamutan nga makit-an ang labing duol nga repr sa `v` nga naa usab sa sulud nga luwas nga rehiyon.
    // kung dili pwede, give up ta.
    //
    let plus1 = plus.f + 1;
    // pasagdi ang plus0 = plus.f, 1;//alang ra sa pagpatin-aw pasagdi ang minus0 = minus.f + 1;//alang ra sa pagpatin-aw
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // gipaambit nga exponent

    // bahinon ang `plus1` sa mga bahin nga dili bahin ug pagkabulag.
    // Ang mga integral nga bahin gigarantiyahan nga mohaum sa u32, tungod kay ang gi-cache nga kuryente naggarantiya sa `plus < 2^32` ug ang na-normalize nga `plus.f` kanunay nga mas mubu sa `2^64 - 2^4` tungod sa tukma nga kinahanglanon.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // kuwentaha ang labing kadaghan nga `10^max_kappa` nga dili molapas sa `plus1` (sa ingon `plus1 < 10^(max_kappa+1)`).
    // kini usa ka taas nga utlanan nga `kappa` sa ubos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: kung ang `k` mao ang labing kadaghan nga integer st
    // `0 <= y mod 10^k <= y - x`,              unya ang `V = floor(y / 10^k) * 10^k` naa sa `[x, y]` ug usa sa labing mubu nga representasyon (nga adunay gamay nga ihap sa hinungdanon nga mga numero) sa kana nga sakup.
    //
    //
    // pangitaa ang gitas-on sa digit nga `kappa` taliwala sa `(minus1, plus1)` sama sa sa Theorem 6.2.
    // Ang Theorem 6.2 mahimong gamiton aron maibulag ang `x` pinaagi sa pagkinahanglan nga `y mod 10^k < y - x` hinoon.
    // (pananglitan, `x` =32000, `y` =32777; `kappa` =2 sukad `y mod 10 ^ 3=777 <y, x=777`.) Ang algorithm nagsalig sa ulahi nga yugto sa pag-verify aron maibulag ang `y`.
    //
    let delta1 = plus1 - minus1;
    // pasagdi ang delta1int=(delta1>> e) ingon usize;//alang ra sa pagpatin-aw
    let delta1frac = delta1 & ((1 << e) - 1);

    // paghatag mga bahin nga bahin, samtang gisusi kung unsa ang katukma sa matag lakang.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // mga digit nga ihatag pa
    loop {
        // kita sa kanunay adunay sa labing menos usa ka digit sa paghatag, sama sa `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (nagsunod kini sa `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // bahinon ang `remainder` sa `10^kappa`.parehas nga gi-scale sa `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; nakit-an namon ang husto nga `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // sukdanan 10 ^ kappa balik sa gipaambit nga exponent
            return round_and_weed(
                // SAFETY: kita initialized nga handumanan sa ibabaw.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // gub-a ang loop kung gihatag namon ang tanan nga integral nga mga digit.
        // ang eksaktong numero sa mga digit mao ang `max_kappa + 1` ingon `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ibalik ang mga invariant
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // paghatag mga tipik nga bahin, samtang gisusi kung unsa ang katukma sa matag lakang.
    // niining panahona nagsalig kami sa gibalikbalik nga pagdaghan, tungod kay ang pagkabahinbahin mawad-an sa katukma.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // sa sunod nga digit kinahanglan nga mahinungdanon sama sa na gisulayan kita nga sa wala pa paglapas sa invariants, diin `m = max_kappa + 1` (#sa numero sa bahin):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // dili mag-awas, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // bahinon ang `remainder` sa `10^kappa`.
        // parehas nga gi-scale sa `2^e / 10^kappa`, busa ang naulahi implicit dinhi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicit tigbulag
            return round_and_weed(
                // SAFETY: kita initialized nga handumanan sa ibabaw.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ibalik ang mga invariant
        kappa -= 1;
        remainder = r;
    }

    // nakamugna namon ang tanan nga hinungdanon nga numero sa `plus1`, apan dili sigurado kung kini ang labing kaayo nga usa.
    // pananglitan, kung ang `minus1` mao ang 3.14153 ... ug ang `plus1` nga 3.14158 ..., adunay 5 lainlaing labing mubu nga representasyon gikan sa 3.14154 hangtod 3.14158 apan adunay ra kami labing kadaghan.
    // kinahanglan naton nga sunod-sunod nga ibanan ang katapusang numero ug susihon kung kini ba ang labing kaayo nga repr.
    // adunay labing daghan nga 9 nga mga kandidato (..1 hangtod ..9), busa medyo dali kini.("rounding" phase)
    //
    // gisusi sa pagpaandar kung kini nga "optimal" repr sa tinuud sa sulud sa mga ulp range, ug ingon usab, posible nga ang "second-to-optimal" repr mahimo nga labing maayo tungod sa sayup sa pag-ikot.
    // sa bisan hain nga mga kaso ningbalik kini `None`.
    // ("weeding" phase)
    //
    // ang tanan nga mga lantugi dinhi gi-scale sa kasagarang (apan gipadayag) kantidad `k`, aron:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ug ingon usab, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ug usab, `threshold > plus1v` gikan sa nangagi nga mga invariant)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // paghimo duha nga gibanabana sa `v` (tinuud nga `plus1 - v`) sulud sa 1.5 ulps.
        // ang sangputanan nga representasyon kinahanglan mao ang labing duul nga representasyon sa pareho.
        //
        // dinhi `plus1 - v` gigamit sukad kalkulasyon gibuhat uban sa pagtahod ngadto sa `plus1` aron sa paglikay sa overflow/underflow (busa sa daw gikambyo mga ngalan).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // pagminus sa katapusan nga digit ug paghunong sa labing duul nga representasyon sa `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // nagtrabaho kami uban ang gibanabana nga mga digit nga `w(n)`, nga sa una parehas sa `plus1 - plus1 % 10^kappa`.pagkahuman sa pagpadagan sa loop nga lawas `n` nga mga panahon, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // gibutang namon ang `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (sa ingon `nahabilin= plus1w(0)`) aron mapayano ang mga pagsusi.
            // timan-i nga ang `plus1w(n)` kanunay nga nagdugang.
            //
            // kami adunay tulo nga mga kondisyon aron matapos.ang bisan kinsa sa kanila maghimo sa loop nga dili makapadayon, apan adunay kami bisan usa ka balido nga representasyon nga nahibal-an nga labing duul sa `v + 1 ulp` bisan unsaon.
            // igpakita namon sila ingon TC1 hangtod TC3 alang sa kamubu.
            //
            // TC1: Ang `w(n) <= v + 1 ulp`, ie, kini ang katapusang repr nga mahimong labing duul.
            // katumbas kini sa `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // inubanan sa TC2 (nga tseke kon `w(n+1)` is valid), kini magpugong sa posible nga nagaawas sa kalkulasyon sa `plus1w(n)`.
            //
            // TC2: Ang `w(n+1) < minus1`, ie, ang sunod nga repr siguradong dili molibot sa `v`.
            // katumbas kini sa `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ang wala nga kamot nga bahin mahimo nga mag-awas, apan nahibal-an naton ang `threshold > plus1v`, busa kung ang TC1 bakak, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ug mahimo naton nga luwas nga masulay kung ang `threshold - plus1w(n) < 10^kappa` hinoon.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ie, ang sunod nga repr mao
            // wala`y duul sa `v + 1 ulp` kaysa karon nga repr.
            // gihatag `z(n) = plus1v_up - plus1w(n)`, kini nahimo nga `abs(z(n)) <= abs(z(n+1))`.pag-usab nga giisip nga ang TC1 bakak, kita adunay `z(n) > 0`.kita adunay duha ka mga kaso nga gikonsiderar:
            //
            // - kung ang `z(n+1) >= 0`: TC3 mahimong `z(n) <= z(n+1)`.
            // tungod kay nagdako ang `plus1w(n)`, kinahanglan nga mokunhod ang `z(n)` ug klaro nga kini sayup.
            // - kanus-a `z(n+1) < 0`:
            //   - TC3a: ang pauna nga kundisyon mao `plus1v_up < plus1w(n) + 10^kappa`.sa paghunahuna nga TC2 bakak, `threshold >= plus1w(n) + 10^kappa` mao nga dili kini makaapaw.
            //   - TC3b: Ang TC3 mahimong `z(n) <= -z(n+1)`, ie, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ang gipanghimatuud nga TC1 naghatag `plus1v_up > plus1w(n)`, busa dili kini mahimo nga mag-overflow o mag-underflow kung gihiusa sa TC3a.
            //
            // tungod niini, kinahanglan naton nga hunongon kung `TC1 || TC2 || (TC3a && TC3b)`.ang mosunud katumbas sa balitok niini, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ang labing mubu nga repr dili matapos sa `0`
                plus1w += ten_kappa;
            }
        }

        // susiha kung kini nga representasyon mao usab ang pinakaduol nga representasyon sa `v - 1 ulp`.
        //
        // parehas ra kini sa gitapos nga mga kondisyon alang sa `v + 1 ulp`, nga ang tanan nga `plus1v_up` gipulihan sa baylo nga `plus1v_down`.
        // parehas nga gihuptan ang pag-analisar sa overflow.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Karon adunay kami labing duul nga representasyon sa `v` taliwala sa `plus1` ug `minus1`.
        // kini mao ang kaayo liberal, bisan, mao nga atong isalikway bisan unsa nga `w(n)` dili tali sa `plus0` ug `minus0`, ie, `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // kita paggamit sa mga kamatuoran nga `threshold = plus1 - minus1` ug `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ang labing mub-ot nga pagpatuman sa mode alang sa Grisu nga adunay fallback sa Dragon.
///
/// Kinahanglan kini gamiton alang sa kadaghanan nga mga kaso.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KALUWASAN: Ang checker sa panghulam dili igo nga maalamon aron magamit namon ang `buf`
    // sa ikaduha nga branch, busa nahugawan namon ang kinabuhi dinhi.
    // Apan gigamit ra usab namo ang `buf` kung ang `format_shortest_opt` gibalik ang `None` mao nga okay ra kini.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ang eksakto ug naayo nga pagpatuman sa mode alang sa Grisu.
///
/// mobalik Kini `None` sa diha nga kini mobalik sa usa ka eksakto nga representasyon kon dili.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // kinahanglan naton labing menos tulo nga tipik sa dugang nga katukma
    assert!(!buf.is_empty());

    // normalize ug sukdon ang `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // bahinon ang `v` sa mga bahin nga dili bahin ug pagkabulag.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // parehas nga daan nga `v` ug bag-ong `v` (gi-scale sa `10^-k`) adunay sayup nga <1 ulp (Theorem 5.1).
    // ingon nga kita wala mahibalo sa sayop mao ang positibo o negatibo, atong gamiton ang duha ka pagbanabana spaced parehong ug sa kinatas-an nga sayop sa 2 ulps (sama nga sa labing mubo nga kaso).
    //
    //
    // ang katuyoan mao ang pagpangita sa ensakto nga bilugan nga serye sa mga digit nga naandan sa parehas nga `v - 1 ulp` ug `v + 1 ulp`, mao nga labi kaming masaligon.
    // kung dili kini mahimo, wala kami nahibal-an kung hain ang husto nga output alang sa `v`, busa naghatag kami ug mibalik.
    //
    // `err` gihubit ingon `1 ulp * 2^e` dinhi (parehas sa ulp sa `vfrac`), ug sukdon namon kini bisan kanus-a mapataas ang `v`.
    //
    //
    //
    let mut err = 1;

    // kuwentaha ang labing kadaghan nga `10^max_kappa` nga dili molapas sa `v` (sa ingon `v < 10^(max_kappa+1)`).
    // kini usa ka taas nga utlanan nga `kappa` sa ubos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // kung nagtrabaho kami sa katapusang digit nga limitasyon, kinahanglan namon nga pahubasan ang buffer sa wala pa ang aktuwal nga paghatag aron malikayan ang doble nga pag-ikot.
    //
    // timan-i nga kinahanglan naton nga padak-an pag-usab ang buffer kung mahitabo ang pag-ikot!
    let len = if exp <= limit {
        // oops, dili man kami makahimo paghimo usa ka * digit.
        // posible kini kung, ingon, adunay kami usa ka butang sama sa 9.5 ug kini gikutuban sa 10.
        //
        // sa prinsipyo mahimo dayon naton nga tawagan ang `possibly_round` nga adunay usa ka walay sulod nga buffer, apan ang pag-scale sa `max_ten_kappa << e` sa 10 mahimo nga magresulta sa pag-awas.
        //
        // sa ingon kita nga sloppy dinhi ug pagpalapad sa sayop range sa usa ka butang sa 10.
        // madugangan niini ang sayup nga negatibo nga rate, apan ra gyud,*kaayo* gamay;
        // mahimo ra kini kapansin-pansin kung ang mantissa labi ka daghan sa 60 nga tipik.
        //
        // KALUWASAN: `len=0`, busa ang obligasyon nga una nga kini nga memorya wala`y hinungdan.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // mohatag mga hinungdan nga bahin.
    // ang sayup hingpit nga pagkabulag, busa dili namon kinahanglan nga susihon kini sa kini nga bahin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // mga digit nga ihatag pa
    loop {
        // Kanunay kami adunay bisan usa ka digit nga maghatag mga invariant:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (Kini mosunod nga ang `remainder = vint % 10^(kappa+1)`)
        //
        //

        // bahinon ang `remainder` sa `10^kappa`.parehas nga gi-scale sa `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // puno na ang buffer?pagdagan ang rounding pass nga adunay nahabilin.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KALUWAS: gisugdan namon ang `len` daghang mga byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // gub-a ang loop kung gihatag namon ang tanan nga integral nga mga digit.
        // ang eksaktong numero sa mga digit mao ang `max_kappa + 1` ingon `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ibalik ang mga invariant
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // paghatag mga tipik nga bahin.
    //
    // sa prinsipyo makapadayon kami sa katapusan nga magamit nga digit ug susihon kung unsa ang katukma.
    // Ikasubo nga nagtrabaho kami uban ang adunay kutub nga sukod nga mga integer, busa kinahanglan namon ang pila ka sukaranan aron mahibal-an ang pag-awas.
    // V8 naggamit `remainder > err`, nga nahimong sayup kung managlahi ang una nga `i` hinungdan nga mga numero nga `v - 1 ulp` ug `v`.
    // bisan pa niini gisalikway ang daghan kaayo kung dili husto nga input.
    //
    // tungod kay ang ulahi nga hugna adunay tama nga pagkakita sa overflow, hinoon gigamit namon ang labi ka higpit nga sukdanan:
    // nagpadayon kami hangtud ang `err` milapas sa `10^kappa / 2`, aron ang sakup sa taliwala sa `v - 1 ulp` ug `v + 1 ulp` siguradong adunay duha o daghan pa nga mga bilugan nga representasyon.
    //
    // parehas kini sa una nga duha nga pagtandi gikan sa `possibly_round`, alang sa pakisayran.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // mga invariant, diin ang `m = max_kappa + 1` (#sa mga digit sa dili bahin nga bahin):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // dili mag-awas, `2^e * 10 < 2^64`
        err *= 10; // dili mag-awas, `err * 10 < 2^e * 5 < 2^64`

        // bahinon ang `remainder` sa `10^kappa`.
        // parehas nga gi-scale sa `2^e / 10^kappa`, busa ang naulahi implicit dinhi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // puno na ang buffer?pagdagan ang rounding pass nga adunay nahabilin.
        if i == len {
            // KALUWAS: gisugdan namon ang `len` daghang mga byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ibalik ang mga invariant
        remainder = r;
    }

    // wala`y pulos ang dugang nga pagkalkula (siguradong napakyas ang `possibly_round`), busa naghatag kami.
    return None;

    // gihimo namon ang tanan nga gihangyo nga mga digit sa `v`, nga kinahanglan managsama usab sa katugbang nga mga numero sa `v - 1 ulp`.
    // karon gisusi namon kung adunay usa ka talagsaon nga representasyon nga gipaambit sa parehas nga `v - 1 ulp` ug `v + 1 ulp`;mahimo kini parehas sa nahimo nga mga digit, o sa nalibot nga bersyon sa mga digit.
    //
    // kung ang sulud adunay sulud nga daghang mga representasyon sa parehas nga gitas-on, dili kami makasiguro ug kinahanglan ibalik ang `None` hinoon.
    //
    // ang tanan nga mga lantugi dinhi gi-scale sa kasagarang (apan gipadayag) kantidad `k`, aron:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KALUWASAN: ang una nga `len` bytes nga `buf` kinahanglan una nga himuon.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (alang sa pakisayran, gipakita sa tuldok-tuldok nga linya ang eksaktong kantidad alang sa mga mahimo nga representasyon sa gihatag nga ihap sa mga numero.)
        //
        //
        // ang sayup sobra kadako nga adunay labing menos tulo nga posible nga representasyon taliwala sa `v - 1 ulp` ug `v + 1 ulp`.
        // dili naton mahibal-an kung kinsa ang tama.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // sa tinuud, ang 1/2 ulp igo na aron ipaila ang duha nga posible nga representasyon.
        // (hinumdomi nga kinahanglan namon ang usa ka talagsaon nga representasyon alang sa parehas nga `v - 1 ulp` ug `v + 1 ulp`.) dili kini mag-awas, ingon nga `ulp < ten_kappa` gikan sa una nga pagsusi.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ Kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // kung ang `v + 1 ulp` duul sa bilugan nga representasyon (nga naa na sa `buf`), nan luwas kita nga makabalik.
        // timan-i nga ang `v - 1 ulp`*mahimo* nga mas gamay kaysa sa karon nga representasyon, apan ingon nga `1 ulp < 10^kappa / 2`, igo na kini nga kondisyon:
        // ang distansya tali sa `v - 1 ulp` ug sa karon nga representasyon dili molapas sa `10^kappa / 2`.
        //
        // ang kondisyon katumbas sa `remainder + ulp < 10^kappa / 2`.
        // tungod kay dali kini mag-awas, susihon una kung `remainder < 10^kappa / 2`.
        // napamatud-an na namo nga `ulp < 10^kappa / 2`, mao nga basta ang `10^kappa` wala mag-overflow pagkahuman, maayo ang ikaduha.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KALUWASAN: ang nagpatawag sa amon mao ang nagpahinumdom sa maong panumduman.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------nahibilin------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // sa uban nga mga kamot, kon `v - 1 ulp` mao nga mas duol ngadto sa rounded-up nga representasyon, kita kinahanglan sa palibot ug mobalik.
        // alang sa parehas nga hinungdan dili namon kinahanglan nga susihon ang `v + 1 ulp`.
        //
        // ang kondisyon katumbas sa `remainder - ulp >= 10^kappa / 2`.
        // pag-usab gisusi namon una kung ang `remainder > ulp` (timan-i nga dili kini `remainder >= ulp`, tungod kay ang `10^kappa` dili gyud zero).
        //
        // timan-i usab nga ang `remainder - ulp <= 10^kappa`, busa ang ikaduha nga pagsusi dili mag-awas.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KALUWASAN: kinahanglan nga gisugdan sa tagatawag ang kana nga panumduman.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // pagdugang lang usa ka dugang nga digit kung gihangyo namon ang nakapunting nga katukma.
                // kinahanglan usab naton nga susihon kana, kung ang orihinal nga buffer wala`y sulod, ang dugang nga digit mahimo ra nga idugang kung `exp == limit` (kaso nga edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KALUWASAN: kami ug ang nagtawag sa una nga panumduman.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // kung dili kita nahukman (ie, ang pipila nga mga kantidad tali sa `v - 1 ulp` ug `v + 1 ulp` nagtuyok ug ang uban nagtuyok) ug gihatag.
        //
        None
    }
}

/// Ang eksakto ug naayo nga pagpatuman sa mode alang sa Grisu nga adunay Dragon fallback.
///
/// Kinahanglan kini gamiton alang sa kadaghanan nga mga kaso.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KALUWASAN: Ang checker sa panghulam dili igo nga maalamon aron magamit namon ang `buf`
    // sa ikaduha nga branch, busa nahugawan namon ang kinabuhi dinhi.
    // Apan gigamit ra usab namo ang `buf` kung ang `format_exact_opt` gibalik ang `None` mao nga okay ra kini.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}