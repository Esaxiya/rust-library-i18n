//! Nag-decode sa usa ka naglutaw-punto nga kantidad sa tagsatagsa nga mga bahin ug mga sakup sa sayup.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Na-decode nga wala pirmahi nga wala`y katapusan nga kantidad, sama sa:
///
/// - Ang orihinal nga kantidad katumbas sa `mant * 2^exp`.
///
/// - Ang bisan unsang numero gikan sa `(mant - minus)*2^exp` hangtod `(mant + plus)* 2^exp` molibut sa orihinal nga kantidad.
/// Ang sakup gilakip lamang kung ang `inclusive` mao ang `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Ang gisukot nga mantissa.
    pub mant: u64,
    /// Ang labi ka gamay nga sakup sa sayup.
    pub minus: u64,
    /// Sa taas nga sakup sa sayup.
    pub plus: u64,
    /// Ang gipaambit nga exponent sa base 2.
    pub exp: i16,
    /// Tinuod kung lakip ang sakup sa sayup.
    ///
    /// Sa IEEE 754, tinuod kini kung parehas ang orihinal nga mantissa.
    pub inclusive: bool,
}

/// Na-decode ang wala mapirmahan nga kantidad.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Ang mga infinities, positibo man o negatibo.
    Infinite,
    /// Zero, positibo man o negatibo.
    Zero,
    /// Natapos ang mga numero nga adunay dugang nga naka-decode nga natad.
    Finite(Decoded),
}

/// Usa ka tipo sa naglutaw nga punto nga mahimong `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Ang minimum nga positibo nga normal nga kantidad.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Nagbalik usa ka ilhanan (tinuod kung negatibo) ug kantidad nga `FullDecoded` gikan sa gihatag nga numero sa naglutaw nga punto.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // mga silingan: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode kanunay gitipigan ang exponent, mao nga ang mantissa gidak-on alang sa mga subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // mga silingan: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // diin ang maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // mga silingan: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}