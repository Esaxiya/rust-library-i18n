//! Ang lainlaing mga algorithm gikan sa papel.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Ang gidaghanon sa mga makahulugan nga tipik sa Fp
const P: u32 = 64;

// Gitago ra namon ang labing kaayo nga pagduol alang sa *tanan* nga exponents, busa ang variable nga "h" ug ang mga kauban nga kondisyon mahimong mawala.
// Gibaligya kini nga pasundayag alang sa usa ka paris nga kilobytes nga wanang.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Sa kadaghanan nga mga arkitektura, ang mga operasyon sa floating point adunay usa ka tin-aw nga gamay nga gidak-on, busa ang katukma sa pag-ihap gitino sa us aka matag operasyon.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Sa x86, ang x87 FPU gigamit alang sa mga operasyon sa float kung ang mga extension sa SSE/SSE2 dili magamit.
// Ang x87 FPU nagpalihok nga adunay 80 ka piraso nga katukma pinaagi sa default, nga nagpasabut nga ang mga operasyon molibut sa 80 nga mga bit hinungdan nga mahitabo ang doble nga pag-ikot kung ang mga kantidad sa ulahi girepresenta ingon
//
// 32/64 gamay nga mga bili sa float.Aron mabuntog kini, ang pulong nga pagpugong sa FPU mahimong itakda aron ang mga pagkalkula gihimo sa gusto nga katukma.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Usa ka istruktura nga gigamit aron mapreserba ang orihinal nga kantidad sa pulong nga pagkontrol sa FPU, aron kini mapahiuli kung mahulog ang istraktura.
    ///
    ///
    /// Ang x87 FPU usa ka 16-bits nga nagparehistro nga ang mga uma ingon ang mosunud:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Ang dokumentasyon alang sa tanan nga mga natad nga magamit sa IA-32 Architectures Software Developer's Manual (Tomo 1).
    ///
    /// Ang natad ra nga may kalabutan sa mosunud nga code mao ang PC, Control sa Precision.
    /// Gitino sa kini nga natad ang katukma sa mga operasyon nga gihimo sa FPU.
    /// Mahimo kini ibutang sa:
    ///  - 0b00, us aka ensakto nga ie, 32-bits
    ///  - 0b10, doble nga katukma ie, 64-piraso
    ///  - 0b11, doble nga gipalapdan nga katukma ie, 80-bits (default estado) Ang kantidad nga 0b01 gireserba ug dili gamiton.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // KALUWASAN: ang panudlo sa `fldcw` gi-awdit aron makahimo sa paglihok nga husto
        // bisan unsang `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Gigamit namon ang ATT syntax aron suportahan ang LLVM 8 ug LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Gitakda ang ensakto nga natad sa FPU sa `T` ug gibalik ang usa ka `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // I-compute ang kantidad alang sa Precision Control field nga angay alang sa `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ka tipik
            8 => 0x0200, // 64 nga tipik
            _ => 0x0300, // default, 80 tipik
        };

        // Kuhaa ang orihinal nga kantidad sa pulong nga pagpugong aron maibalik kini sa ulahi, kung ang istraktura nga `FPUControlWord` nahulog SA KALUWASAN: ang panudlo nga `fnstcw` gi-awdit aron makahimo sa pagtrabaho nga tama sa bisan unsang `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Gigamit namon ang ATT syntax aron suportahan ang LLVM 8 ug LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Ibutang ang pulong nga pagpugong sa gitinguha nga katukma.
        // Nakab-ot kini pinaagi sa pagtakuban sa daan nga katukma (bits 8 ug 9, 0x300) ug pag-ilis niini sa ensakto nga bandila nga nakalkula sa taas.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ang tulin nga agianan sa Bellerophon gamit ang mga sukod sa sukod sa makina ug mga float.
///
/// Gikuha kini sa usa ka bulag nga gimbuhaton aron mahimo kini pagsulay sa wala pa magtukod usa ka bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95
    // Gitandi namon ang eksaktong kantidad sa MAX_SIG hapit sa katapusan, kini usa ra ka dali, barato nga pagsalikway (ug gipagawas usab ang nahabilin nga code gikan sa pagkabalaka bahin sa underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ang tulin nga agianan krusyal nga nagsalig sa aritmetika nga ginalibutan sa husto nga gidaghanon sa mga tipik nga wala`y bisan unsang intermisyon nga paglibut.
    // Sa x86 (nga wala ang SSE o SSE2) kinahanglan niini ang katukma sa x87 FPU stack nga usbon aron direkta kini nga molibot sa 64/32 bit.
    // Ang pag-andar sa `set_precision` nag-amping sa pagbutang sa katukma sa mga arkitektura nga nagkinahanglan nga ibutang kini pinaagi sa pagbag-o sa tibuuk kalibutan nga estado (sama sa control word sa x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ang kaso nga e <0 dili mapilo sa ubang branch.
    // Ang mga negatibo nga gahum miresulta sa usa ka balik-balik nga bahin nga bahin sa binary, nga gilibot, nga hinungdan sa tinuud (ug usahay medyo makahuluganon!) Nga mga sayup sa katapusan nga sangputanan.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Ang Algorithm Bellerophon wala`y hinungdan nga kodigo nga gipakamatarung sa dili gamay nga pagtuki sa numero.
///
/// Gilibot niini ang "f" sa usa ka float nga adunay 64 gamay nga kahulugan ug gipadaghan kini pinaagi sa labing kaayo nga pag-abut sa `10^e` (sa parehas nga format nga floating point).Kanunay kini nga igo aron makuha ang tama nga sangputanan.
/// Bisan pa, kung ang sangputanan hapit sa tunga sa tunga sa duha nga kasikbit nga (ordinary) floats, ang compound rounding error gikan sa pagpadaghan sa duha nga duul nagpasabut nga ang sangputanan mahimo`g mawala sa pipila nga mga tipik.
/// Kung nahinabo kini, ang iterative Algorithm R nag-ayo sa mga butang.
///
/// Ang gigunitan nga kamot nga "close to halfway" gihimo nga ensakto sa pagtuki sa numero sa papel.
/// Sa mga pulong ni Clinger:
///
/// > Ang slop, gipahayag sa mga yunit sa labing dyutay nga hinungdan nga bahin, usa ka apil nga gihigot alang sa sayup
/// > natipon sa panahon sa naglutaw punto kalkulasyon sa gibanabana sa f * 10 ^ e.(Ang slop mao
/// > dili usa ka utlanan alang sa tinuud nga sayup, apan gikutuban ang kalainan sa taliwala sa gibana-bana nga z ug
/// > ang labing kaayo nga mahimo nga pag-abut nga mogamit mga p b sa makahulugan.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Ang mga kaso nga abs(e) <log5(2^N) naa sa fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Igo ba ang bakilid nga makahimo sa usa ka kalainan sa pag-ikid sa n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Usa ka iterative algorithm nga nagpalambo sa usa ka naglutaw nga punto nga pagbanabana nga `f * 10^e`.
///
/// Ang matag pag-iterate nakakuha usa ka yunit sa katapusang lugar nga duul, nga siyempre labi ka dugay nga nagtagbo kung ang `z0` bisan pa mahuman.
/// Maayo na lang, kung gigamit ingon fallback alang sa Bellerophon, ang pagsugod nga pag-abut gipalayo sa labing usa ka ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Pagpangita positibo nga integers `x`, `y` sa ingon nga ang `x / y` eksakto nga `(f *10^e) / (m* 2^k)`.
        // Dili lamang kini malikayan ang pag-atubang sa mga timailhan sa `e` ug `k`, gitangtang usab namon ang gahum sa duha nga sagad sa `10^e` ug `2^k` aron himuon nga mas gamay ang mga numero.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Gisulat kini nga medyo dili maayo tungod kay ang among mga bignum dili pagsuporta sa mga negatibo nga numero, busa gigamit namon ang hingpit nga impormasyon sa pag-sign sign.
        // Ang pagpadaghan sa m_digits dili mahimong mag-awas.
        // Kung ang `x` o `y` igoigo nga kadaghan nga kinahanglan naton mabalaka bahin sa pag-awas, nan igo usab sila nga ang `make_ratio` gipakubus ang tipik sa usa ka hinungdan nga 2 ^ 64 o labaw pa.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Dili kinahanglan x pa, magtipig usa ka clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Kinahanglan pa y, paghimo usa ka kopya.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Tungod sa `x = f` ug `y = m` diin ang `f` nagrepresentar sa mga input decimal digit sama sa naandan ug ang `m` mao ang hinungdan sa usa ka naglutaw nga punto nga pag-abot, himua ang ratio nga `x / y` nga parehas sa `(f *10^e) / (m* 2^k)`, nga mahimo`g mabawasan sa usa ka kusog sa duha nga pareho.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, gawas nga gaminusan ang bahin sa pipila nga gahum nga duha.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dili kini mahimo mag-awas tungod kay nanginahanglan positibo nga `e` ug negatibo nga `k`, nga mahimo ra mahitabo alang sa mga kantidad nga hapit sa 1, nga nagpasabut nga ang `e` ug `k` medyo gamay ra.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dili usab kini makaapaw, kitaa sa taas.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), pag-usab nga pagminus sa us aka sagad nga gahum nga duha.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptuwal, ang Algorithm M mao ang pinakasimple nga paagi aron mabalhin ang usa ka decimal ngadto sa usa ka float.
///
/// Naghimo kami usa ka ratio nga katumbas sa `f * 10^e`, pagkahuman paglabay sa gahum nga duha hangtod nga makahatag kini usa ka balido nga float makahulugan.
/// Ang binary exponent nga `k` mao ang ihap sa mga panahon nga gipadaghan namon ang numerator o denominator sa duha, ie, sa tanan nga mga panahon ang `f *10^e` katumbas sa `(u / v)* 2^k`.
/// Kung nahibal-an namon ang significanceand, kinahanglan ra namon nga libutan pinaagi sa pagsusi sa nahabilin nga bahin, nga gihimo sa mga katabang sa helper sa ubus sa ubus.
///
///
/// Kini nga algorithm labi ka hinay, bisan sa pag-optimize nga gihulagway sa `quick_start()`.
/// Bisan pa, kini ang pinakasimple sa mga algorithm aron mohaum alang sa overflow, underflow, ug subnormal nga mga sangputanan.
/// Ang kini nga pagpatuman gikuha sa kung ang Bellerophon ug Algorithm R nalupig.
/// Dali ang pagpangita sa underflow ug overflow: Ang ratio dili pa usa ka in-range nga hataas, bisan pa naabot ang exponent sa minimum/maximum.
/// Sa kaso sa pag-awas, ibalik ra namon ang pagkawalay katapusan.
///
/// Mas dali ang pagdumala sa underflow ug mga subnormal.
/// Ang usa ka dako nga problema mao ang, sa minimum nga exponent, ang ratio mahimo pa usab nga daghan alang sa usa ka significance.
/// Tan-awa ang underflow() alang sa mga detalye.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Pag-ayo sa posible nga pag-optimize: paghimo sa kadaghanan nga big_to_fp aron mahimo namon ang katumbas nga fp_to_float(big_to_fp(u)) dinhi, kung wala ang doble nga pagtuyok.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kinahanglan nga mohunong kita sa labing menos nga exponent, kung maghulat kita hangtod sa `k < T::MIN_EXP_INT`, kung ingon-ana mapalayo kami sa usa ka hinungdan nga duha.
            // Ikasubo nga kini nagpasabut nga kinahanglan naton nga espesyal-ang naandan nga mga numero nga adunay minimum exponent.
            // Ang FIXME nakakaplag usa ka labi ka elegante nga pormula, apan gipadagan ang `tiny-pow10` nga pagsulay aron masiguro nga kini tinuod nga husto!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Laktawan ang kadaghanan sa mga iterasyon sa Algorithm M pinaagi sa pagsusi sa gitas-on sa gamay.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ang gamay nga gitas-on usa ka pagbanabana sa base duha nga logarithm, ug log(u / v) = log(u), log(v).
    // Ang banabana gipalabi sa labing daghan nga 1, apan kanunay usa nga wala`y pagtantiya, busa ang sayup sa log(u) ug log(v) parehas nga pag-sign ug pagkansela (kung daghan ang duha).
    // Busa ang sayup alang sa log(u / v) labi usab sa usa.
    // Ang target ratio usa kung diin ang u/v naa sa usa ka range nga hataas.Sa ingon ang among kahimtang sa pagtapos mao ang log2(u / v) nga ang hinungdan sa mga piraso, usa ka plus/minus.
    // FIXME Ang pagtan-aw sa ikaduha nga gamay mahimong mapaayo ang banabana ug malikayan ang pila pa nga pagkabahin.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Pag-ilalom o subnormal.Ibilin kini sa punoan nga kalihokan.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Pag-awasIbilin kini sa punoan nga kalihokan.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ang ratio dili usa ka kadaghan nga hataas nga adunay minimum nga exponent, busa kinahanglan naton nga palibuton ang sobra nga mga tipik ug ayohon ang exponent sumala niana.
    // Ang tinuud nga kantidad karon ingon niini:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q pagputol (girepresenta ni rem)
    //
    // Busa, kung ang mga bilugan-bit nga bit!= 0.5 ULP, sila ang nagbuut sa pag-ikid sa ilang kaugalingon.
    // Kung managsama sila ug ang nahabilin dili-zero, ang kantidad kinahanglan pa usab nga bilugan.
    // Lamang kung ang mga bilugan nga piraso nga 1/2 ug ang nahabilin nga zero, adunay kami tunga-sa-parehas nga sitwasyon.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinaryong round-to-even, nga ginalabog pinaagi sa pag-ikot base sa nahabilin sa usa ka dibisyon.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}