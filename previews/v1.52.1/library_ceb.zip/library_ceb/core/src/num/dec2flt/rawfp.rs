//! Bit bitdling sa positibo nga IEEE 754 floats.Dili maayong pagdumala ang mga negatibo nga numero.
//! Ang mga naandan nga numero sa naglutaw nga punto adunay usa ka representasyon nga kanonikal ingon (frac, exp) nga ang kantidad mao ang 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) diin ang N ang gidaghanon sa mga tipik.
//!
//! Ang mga subnormal gamay nga magkalainlain ug katingad-an, apan parehas nga prinsipyo ang magamit.
//!
//! Hinuon, bisan pa, girepresenta namon sila ingon (sig, k) nga adunay positibo, ingon nga ang kantidad f *
//! 2 <sup>e</sup> .Gawas nga tin-aw ang "hidden bit", gibag-o niini ang exponent sa gitawag nga mantissa shift.
//!
//! Pagbutang us aka paagi, kasagaran ang mga float gisulat ingon (1) apan dinhi kini gisulat ingon (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Gitawag namon ang (1) nga **praksyonal nga representasyon** ug (2) ang **integral nga representasyon**.
//!
//! Daghang mga gimbuhaton sa kini nga modyul ang nagdumala ra sa normal nga mga numero.Ang mga naandan nga dec2flt konserbatibo nga magkuha sa husto nga unahan sa kalibutan nga hinay nga agianan (Algorithm M) alang sa gamay kaayo ug daghan kaayo nga mga numero.
//! Ang kana nga algorithm nagkinahanglan next_float() ra nga nagdumala sa mga subnormal ug zero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Usa ka helper nga trait aron malikayan ang pagdoble sa tinuud nga tanan nga code sa pagkakabig alang sa `f32` ug `f64`.
///
/// Tan-awa ang komentaryo sa modyul sa ginikanan kon nganong kinahanglan kini.
///
/// Kinahanglan nga **dili gyud** ipatuman alang sa ubang mga lahi o magamit sa gawas sa modyul nga dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Ang tipo nga gigamit sa `to_bits` ug `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Naghimo usa ka hilaw nga transmutation sa usa ka integer.
    fn to_bits(self) -> Self::Bits;

    /// Naghimo usa ka hilaw nga transmutation gikan sa usa ka integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Gibalik ang kategorya nga nahisakup sa kini nga numero.
    fn classify(self) -> FpCategory;

    /// Gibalik ang mantissa, exponent ug pag-sign ingon integer.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Nagdecode sa float.
    fn unpack(self) -> Unpacked;

    /// Mga cast gikan sa usa ka gamay nga integer nga mahimo nga representante sa eksakto.
    /// Ang Panic kung ang integer dili mahimo nga girepresenta, ang uban pang code sa kini nga module siguruha nga dili gyud kini hinabo.
    fn from_int(x: u64) -> Self;

    /// Nakuha ang kantidad nga 10 <sup>e</sup> gikan sa usa ka pre-compute nga lamesa.
    /// Panics alang sa `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Kung unsa ang giingon sa ngalan.
    /// Mas dali ang lisud nga code kaysa pag-juggling sa mga intrinsik ug gilauman nga kanunay nga pil-on kini sa LLVM.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Usa ka konserbatibo nga gihigot sa decimal nga digit sa mga input nga dili makagbuhat sa overflow o zero o
    /// mga subnormal.Tingali ang decimal exponent sa labing kadaghan nga normal nga kantidad, busa ang ngalan.
    const MAX_NORMAL_DIGITS: usize;

    /// Kung ang labing makahuluganon nga decimal digit adunay usa ka kantidad sa lugar nga labi ka daghan sa niini, ang numero sa tinuud gilibut sa wala'y katapusan.
    ///
    const INF_CUTOFF: i64;

    /// Kung ang labing makahuluganon nga decimal digit adunay usa ka lugar nga kantidad og kantidad kaysa niini, ang numero sa tinuud gilibot sa zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Ang gidaghanon sa mga tipik sa exponent.
    const EXP_BITS: u8;

    /// Ang gidaghanon sa mga tipik sa makahulugan,*lakip ang* tinago nga gamay.
    const SIG_BITS: u8;

    /// Ang gidaghanon sa mga tipik sa makahulugan,*wala iapil* ang gitago nga gamay.
    const EXPLICIT_SIG_BITS: u8;

    /// Ang labing kadaghan nga ligal nga exponent sa representasyon sa praksyonal.
    const MAX_EXP: i16;

    /// Ang minimum nga ligal nga exponent sa representasyon sa praksyonal, wala`y labot ang mga subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` alang sa integral nga representasyon, ie, nga gigamit ang pagbalhin.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` naka-encode (ie, nga adunay gipahigayong bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` alang sa integral nga representasyon, ie, nga gigamit ang pagbalhin.
    const MIN_EXP_INT: i16;

    /// Ang labing kadaghan nga na-normalize nga significance sa integral nga representasyon.
    const MAX_SIG: u64;

    /// Ang dyutay nga na-normalize nga makahulugan sa integral nga representasyon.
    const MIN_SIG: u64;
}

// Kasagaran sa usa ka workaround alang sa #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Gibalik ang mantissa, exponent ug pag-sign ingon integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponent bias + mantissa shift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Ang rkruppe dili sigurado kung husto ang `as` sa tanan nga mga platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Gibalik ang mantissa, exponent ug pag-sign ingon integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponent bias + mantissa shift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Ang rkruppe dili sigurado kung husto ang `as` sa tanan nga mga platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Nagbag-o ang usa ka `Fp` sa pinakaduol nga tipo sa float sa makina.
/// Dili makontrol ang dili kasagarang mga sangputanan.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bit, mao nga xe adunay mantissa shift nga 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Pagtuyok sa 64-bit significanceand sa T::SIG_BITS bits nga adunay tunga-sa-parehas.
/// Dili makontrol ang exponent overflow.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ayuhon ang pagbalhin sa mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Baliktad sa `RawFloat::unpack()` alang sa na-normalize nga mga numero.
/// Ang Panics kung ang hataas o exponent dili balido alang sa na-normalize nga mga numero.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Kuhaa ang natago nga gamay
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ayuhon ang exponent alang sa exponent bias ug mantissa shift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Leave sign gamay sa 0 ("+"), ang among mga numero positibo tanan
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Paghimo usa ka subnormal.Gitugotan ang usa ka mantissa nga 0 ug magbuhat og zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ang naka-encode nga exponent mao ang 0, ang bit sa karatula mao ang 0, busa kinahanglan namon nga hubaron pag-usab ang mga tipik.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Gibanabana ang usa ka bignum nga adunay usa ka Fp.Nagtuyok sa sulud sa 0.5 ULP nga adunay tunga nga pantay.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Giputol namon ang tanan nga mga tipik sa wala pa ang index `start`, ie, epektibo kami nga molihok sa tuo pinaagi sa usa ka kantidad nga `start`, busa kini usab ang exponent nga kinahanglan namon.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) depende sa pinutol nga mga piraso.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Makita ang kinadak-ang numero sa naglutaw nga punto nga mas higpit kaysa sa lantugi.
/// Dili makontrol ang mga subnormal, zero, o exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Pagpangita labing gamay nga numero sa naglutaw nga higpit nga mas dako kaysa sa lantugi.
// Kini nga operasyon mao ang saturating, ie, next_float(inf) ==inf.
// Dili sama sa kadaghanan nga code sa kini nga modyul, kini nga pag-andar nagdumala sa zero, subnormals, ug infinities.
// Bisan pa, sama sa tanan nga ubang mga code dinhi, wala kini pag-atubang sa NaN ug mga negatibo nga numero.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Kini daw maayo nga kaayo nga tinuod, apan kini nga mga buhat.
        // 0.0 gi-encode ingon ang tanan nga zero nga pulong.Ang mga subnormal 0x000m ... m diin m ang mantissa.
        // Sa partikular, ang labing gamay subnormal mao ang 0x0 ... 01 ug ang kinadak-ang 0x000F ... F.
        // Ang labing gamay nga normal nga numero mao ang 0x0010 ... 0, busa kini nga suok nga kaso molihok usab.
        // Kung ang pagdugang nagaawas sa mantissa, ang pagdala gamay nagdugang sa exponent sumala sa gusto namon, ug ang mantissa bits mahimong zero.
        // Tungod sa tinago nga gamay nga kombensiyon, kini usab ang eksakto nga gusto namon!
        // Sa katapusan, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}