//! Pasadya nga pagpatuman sa (bignum) nga ihap nga arbitraryong katukma.
//!
//! Gidisenyo kini aron malikayan ang alokasyon sa tapok nga gasto sa memory sa stack.
//! Ang labing gigamit nga tipo sa bignum, `Big32x40`, gikutuban sa 32 × 40=1,280 bits ug magkuha labing 160 nga mga byte nga stack memory.
//! Kini labaw pa sa igo alang sa round-tripping sa tanan nga posible nga adunay katapusan nga mga kantidad nga `f64`.
//!
//! Sa prinsipyo posible nga adunay daghang mga lahi sa bignum alang sa lainlaing mga pag-input, apan dili namon kini buhaton aron malikayan ang code bloat.
//!
//! Ang matag bignum gisubay gihapon alang sa tinuud nga mga paggamit, busa sa kasagaran dili kini hinungdan.
//!

// Ang kini nga module alang ra sa dec2flt ug flt2dec, ug publiko ra tungod sa mga coretest.
// Wala kini gituyo aron kanunay mapadayon.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Ang mga operasyon sa aritmetika kinahanglan sa mga bignum.
pub trait FullOps: Sized {
    /// Gibalik ang `(carry', v')` nga ingon niana `carry' * 2^W + v' = self + other + carry`, diin ang `W` mao ang gidaghanon sa mga tipik sa `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Gibalik ang `(carry', v')` nga ingon niana `carry'*2^W + v' = self* other + carry`, diin ang `W` mao ang gidaghanon sa mga tipik sa `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Gibalik ang `(carry', v')` nga ingon niana `carry'*2^W + v' = self* other + other2 + carry`, diin ang `W` mao ang gidaghanon sa mga tipik sa `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Gibalik ang `(quo, rem)` nga ingon niana `borrow *2^W + self = quo* other + rem` ug `0 <= rem < other`, diin ang `W` mao ang gidaghanon sa mga tipik sa `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Dili kini mahimong mag-awas;ang output taliwala sa `0` ug `2 * 2^nbits - 1`.
                    // FIXME: ma-optimize ba kini sa LLVM ngadto sa ADC o pareho?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dili kini mahimong mag-awas;
                    // ang output taliwala sa `0` ug `2^nbits * (2^nbits - 1)`.
                    // FIXME: ma-optimize ba kini sa LLVM ngadto sa ADC o pareho?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dili kini mahimong mag-awas;
                    // ang output taliwala sa `0` ug `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Dili kini mahimong mag-awas;ang output taliwala sa `0` ug `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Tan-awa ang RFC #521 alang sa pagpaandar niini.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Ang talaan sa gahum nga 5 representante sa mga digit.Sa piho nga paagi, ang labing kadaghan nga kantidad nga {u8, u16, u32} kana usa ka kusog nga lima, dugang ang katugbang nga exponent.
/// Gigamit sa `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Gigahin nga stack-arbitrary-Precision (hangtod sa piho nga limitasyon) integer.
        ///
        /// Gisuportahan kini sa us aka gihan-ay nga sukod sa sukod nga gihatag nga tipo nga ("digit").
        /// Samtang ang pag-ayo dili kaayo dako (kasagaran mga gatusan ka mga byte), ang pagkopya nga wala`y pagduhaduha mahimo nga magresulta sa pagkaigo sa pasundayag.
        ///
        /// Ingon niini tinuyo nga dili `Copy`.
        ///
        /// Ang tanan nga mga operasyon magamit sa bignums panic sa kaso sa pag-awas.
        /// Responsable ang nanawag nga mogamit daghang igo nga mga klase sa bignum.
        pub struct $name {
            /// Usa plus ang offset sa maximum "digit" nga gigamit.
            /// Dili kini maminusan, busa pagbantay sa han-ay sa pagkalkula.
            /// `base[size..]` kinahanglan nga zero.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` nagrepresentar sa `a + b *2^W + c* 2^(2W) + ...` diin ang `W` mao ang gidaghanon sa mga tipik sa tipo sa digit.
            base: [$ty; $n],
        }

        impl $name {
            /// Naghimo usa ka bignum gikan sa usa ka digit.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Naghimo usa ka bignum gikan sa kantidad nga `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Gibalik ang sulud nga mga digit ingon usa ka slice `[a, b, c, ...]` nga ingon nga ang numeric nga kantidad mao ang `a + b *2^W + c* 2^(2W) + ...` diin ang `W` mao ang gidaghanon sa mga tipik sa tipo sa digit.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Gibalik ang `i`-th bit diin ang bit 0 mao ang labing dyutay nga hinungdan.
            /// Sa ato pa, ang gamay nga adunay gibug-aton `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Gibalik ang `true` kung ang bignum zero.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Gibalik ang numero sa mga tipik nga kinahanglan aron makarepresenta sa kini nga kantidad.
            /// Hinumdomi nga ang zero giisip nga kinahanglan 0 bits.
            pub fn bit_length(&self) -> usize {
                // Laktawan ang labing makahuluganon nga mga numero nga zero.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Wala`y numero nga dili zero, ie, ang numero mao ang zero.
                    return 0;
                }
                // Mahimo kini ma-optimize sa leading_zeros() ug gamay nga pagbag-o, apan tingali dili kini angay nga hasol.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Nagdugang `other` sa kaugalingon ug gibalik ang kaugalingon nga mutable referensya.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Gikuha ang `other` gikan sa iyang kaugalingon ug gibalik ang kaugalingon nga mutable referensya.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Gipadaghan ang kaugalingon niini pinaagi sa usa ka kadako nga digit nga `other` ug gibalik ang kaugalingon niini nga mutable referensya.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Gipadaghan ang kaugalingon sa `2^bits` ug gibalik ang kaugalingon nga mutable referensya.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // pagbalhin sa `digits * digitbits` bits
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // pagbalhin sa `bits` bits
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. mga digit] mao ang zero, dili kinahanglan nga pagbalhin
                }

                self.size = sz;
                self
            }

            /// Gipadaghan ang kaugalingon sa `5^e` ug gibalik ang kaugalingon nga mutable referensya.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Adunay ensakto nga n nga pag-agi sa mga zero sa 2 ^ n, ug ang nag-usa ra nga gidak-on sa digit nga magkasunod nga gahum sa duha, busa kini angayan kaayo nga indeks alang sa lamesa.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Padaghan sa labing kadaghan nga gahum nga nag-usa ka numero kutob sa mahimo ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... pagkahuman tapuson ang nahabilin.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Gipadaghan ang kaugalingon sa us aka numero nga gihulagway sa `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (diin ang `W` mao ang gidaghanon sa mga tipik sa tipo sa digit) ug gibalik ang kaugalingon niini nga mutable referensya.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // ang sulud nga kalihokan.labing kaayo molihok kung aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Gibahin ang kaugalingon sa us aka digit nga kadako nga `other` ug gibalik ang kaugalingon nga mutable referensya *ug* ang nahabilin.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Bahina ang kaugalingon sa us aka lain nga bignum, nga gisapawan ang `q` gamit ang kinutlo ug `r` sa nahabilin.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Binuang hinay base-2 taas nga dibisyon gikuha gikan
                // https://en.wikipedia.org/wiki/Division_algorithm
                // Ang FIXME naggamit labi ka daghang base ($ty) alang sa taas nga pagkabahin.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Ibutang ang gamay nga `i` nga q hangtod 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Ang tipo sa digit alang sa `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// gigamit kini alang sa pagsulay ra.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}