macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Ang labing gamay nga kantidad nga mahimong girepresenta sa kini nga klase sa integer.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Ang labing kadaghan nga kantidad nga mahimong girepresenta sa kini nga klase sa integer.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Ang kadak-an sa kini nga tipo sa integer sa mga tipik.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Gikabig ang usa ka hiwa sa pisi sa usa ka gihatag nga sukaranan sa usa ka integer.
        ///
        /// Gilauman nga ang pisi usa ka kapilian nga `+` o `-` sign nga sundan sa mga digit.
        /// Ang nag-una ug nagsubay sa whitespace nagrepresentar sa usa ka sayup.
        /// Ang digits us aka subset sa kini nga mga karakter, depende sa `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ang kini nga function nga panics kung ang `radix` wala sa sakup gikan sa 2 hangtod 36.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Gibalik ang gidaghanon sa mga sa binary nga representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Mibalik ang gidaghanon sa mga sero sa duha representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Gibalik ang gidaghanon sa mga nag-una nga zero sa binary nga representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Gibalik ang gidaghanon sa mga nagsubay nga zero sa binary nga representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Gibalik ang numero sa mga nanguna sa binary nga representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Gibalik ang ihap sa mga ning-agi sa binary nga representasyon sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Gibag-o ang mga piraso sa wala pinaagi sa usa nga gitino nga kantidad, `n`, nga giputos ang mga pinutol nga mga piraso sa katapusan sa resulta nga integer.
        ///
        ///
        /// Palihug hinumdomi nga dili kini parehas nga operasyon sa `<<` shifting operator!
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Gibag-o ang mga piraso sa tuo pinaagi sa usa nga gitino nga kantidad, `n`, nga giputos ang mga pinutol nga piraso sa pagsugod sa resulta nga integer.
        ///
        ///
        /// Palihug hinumdomi nga dili kini parehas nga operasyon sa `>>` shifting operator!
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Gibag-o ang byte order sa integer.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// pasagdi m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Gibag-o ang han-ay sa mga piraso sa integer.
        /// Ang labing gamay nga hinungdanon nga gamay mahimong labing hinungdanon nga gamay, ikaduha nga labing gamay nga hinungdan mahimong gamay nga labing hinungdanon nga gamay, ug uban pa.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// pasagdi m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Gikabig ang usa ka integer gikan sa dako nga endian hangtod sa katapusan sa target.
        ///
        /// Sa big endian kini usa ka no-op.Sa gamay nga endian gibaylo ang mga byte.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// kung cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } lain pa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Gikabig ang usa ka integer gikan sa gamay nga endian hangtod sa katapusan sa target.
        ///
        /// Sa gamay nga endian kini usa ka no-op.Sa dako nga endian gibaylo ang mga byte.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// kung cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } lain pa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Gikabig ang `self` ngadto sa daghang endian gikan sa katapusan nga target.
        ///
        /// Sa big endian kini usa ka no-op.Sa gamay nga endian gibaylo ang mga byte.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// kung cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } sa uban pa { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // o dili nga mahimo?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Gikabig ang `self` ngadto sa gamay nga endian gikan sa katapusan sa target.
        ///
        /// Sa gamay nga endian kini usa ka no-op.Sa dako nga endian gibaylo ang mga byte.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// kung cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } sa uban pa { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Gisusi ang dugang nga integer.
        /// Gikalkulo ang `self + rhs`, gibalik ang `None` kung nahitabo ang overflow.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Wala gisusi nga pagdugang sa integer.Gikalkulo ang `self + rhs`, sa paghunahuna nga ang pag-awas dili mahitabo.
        /// Kini resulta sa dili tino ang kinaiya sa diha nga
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Gisusi ang pagkubu sa integer.
        /// Gikalkulo ang `self - rhs`, gibalik ang `None` kung nahitabo ang overflow.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Wala gisusi nga pagkuha sa integer.Gikalkulo ang `self - rhs`, sa paghunahuna nga ang pag-awas dili mahitabo.
        /// Kini resulta sa dili tino ang kinaiya sa diha nga
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Gisusi ang pagpadaghan sa integer.
        /// Gikalkulo ang `self * rhs`, gibalik ang `None` kung nahitabo ang overflow.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Wala gisusi ang pagpadaghan sa integer.Gikalkulo ang `self * rhs`, sa paghunahuna nga ang pag-awas dili mahitabo.
        /// Kini resulta sa dili tino ang kinaiya sa diha nga
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Gisusi ang pagbahinbahin sa integer.
        /// Gikalkulo ang `self / rhs`, gibalik ang `None` kung `rhs == 0` o ang pagbahinbahin moresulta sa pag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // KALUWASAN: div pinaagi sa zero ug pinaagi sa INT_MIN gisusi sa taas
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Gisusi ang pagbahinbahin sa Euclidean.
        /// Gikalkulo ang `self.div_euclid(rhs)`, gibalik ang `None` kung `rhs == 0` o ang pagkabahin hinungdan sa pag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Gisusi ang nahabilin nga integer.
        /// Gikalkulo ang `self % rhs`, gibalik ang `None` kung `rhs == 0` o ang pagkabahin hinungdan sa pag-awas.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // KALUWASAN: div pinaagi sa zero ug pinaagi sa INT_MIN gisusi sa taas
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Gisusi ang nahabilin sa Euclidean.
        /// Gikalkulo ang `self.rem_euclid(rhs)`, gibalik ang `None` kung `rhs == 0` o ang pagkabahin hinungdan sa pag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Gisusi ang negasyon
        /// Nakalkula ang `-self`, gibalik ang `None` kung `self == MIN`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gisusi ang pagbalhin sa wala.
        /// Giihap ang `self << rhs`, gibalik ang `None` kung ang `rhs` mas daghan kaysa o katumbas sa gidaghanon sa mga piraso sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gisusi ang tuo nga pagbalhin.
        /// Giihap ang `self >> rhs`, gibalik ang `None` kung ang `rhs` mas daghan kaysa o katumbas sa gidaghanon sa mga piraso sa `self`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gisusi ang hingpit nga kantidad.
        /// Nakalkula ang `self.abs()`, gibalik ang `None` kung `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Gisusi ang exponentiation.
        /// Kwentahon `self.pow(exp)`, pagbalik `None` kon nagaawas nahitabo.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // tungod kay exp!=0, sa katapusan ang exp kinahanglan nga 1.
            // Pag-atubang sa katapusang gamay sa exponent nga gilain, tungod kay ang pag-square sa base pagkahuman dili kinahanglan ug mahimong hinungdan sa wala kinahanglana nga pag-awas.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating integer nga pagdugang.
        /// Giihap ang `self + rhs`, nakapabusog sa mga utlanan sa numero imbis nga mag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Pagkuha sa saturating integer.
        /// Kwentahon `self - rhs`, matumog sa numerawo utlanan sa baylo nga sa awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Makabusog nga pagsalikway sa integer.
        /// Giisip ang `-self`, gibalik ang `MAX` kung `self == MIN` imbis nga mag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Nagtagbaw nga hingpit nga kantidad.
        /// Giisip ang `self.abs()`, gibalik ang `MAX` kung `self == MIN` imbis nga mag-awas.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Ang saturating nga pagdugang sa integer.
        /// Giihap ang `self * rhs`, nakapabusog sa mga utlanan sa numero imbis nga mag-awas.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Matumog integer exponentiation.
        /// Giihap ang `self.pow(exp)`, nakapabusog sa mga utlanan sa numero imbis nga mag-awas.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Pagdugang sa pagdugang sa (modular).
        /// Kwentahon `self + rhs`, wrapping sa palibot sa utlanan sa sa matang.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Pagputos sa (modular) nga pagkuha.
        /// Nakalkula ang `self - rhs`, nga giputos sa palibot sa utlanan sa lahi.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Pagputos sa (modular) nga pagpadaghan.
        /// Gikalkulo ang `self * rhs`, giputos sa libut sa utlanan sa tipo.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Pagputol sa dibisyon sa (modular).Gikalkulo ang `self / rhs`, giputos sa libut sa utlanan sa tipo.
        ///
        /// Ang kaso ra kung diin mahimo`g mahitabo ang ingon nga pagputos kung gibahinbahin sa usa ang `MIN / -1` sa usa ka pinirmahan nga tipo (diin ang `MIN` mao ang negatibo nga gamay nga kantidad alang sa tipo);katumbas kini sa `-MIN`, usa ka positibo nga kantidad nga daghan kaayo nga girepresenta sa tipo.
        /// Sa ingon nga kaso, kini nga pag-andar nagabalik mismo sa `MIN`.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Pagputol sa dibisyon sa Euclidean.
        /// Nakalkula ang `self.div_euclid(rhs)`, nga giputos sa palibot sa utlanan sa lahi.
        ///
        /// Ang pagputos mahitabo ra sa `MIN / -1` sa usa ka pinirmahan nga tipo (diin ang `MIN` mao ang negatibo nga gamay nga kantidad alang sa tipo).
        /// Katumbas kini sa `-MIN`, usa ka positibo nga kantidad nga daghan kaayo aron mahimo`g representante sa tipo.
        /// Sa kini nga kaso, kini nga pamaagi mobalik sa `MIN` mismo.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Ang nahabilin nga pagputos sa (modular).Kwentahon `self % rhs`, wrapping sa palibot sa utlanan sa sa matang.
        ///
        /// Ang maong wrap-sa palibot dili sa tinuod mahitabo mathematically;Ang pagpatuman sa mga artifact naghimo nga `x % y` dili balido alang sa `MIN / -1` sa usa ka pinirmahan nga tipo (diin ang `MIN` mao ang negatibo nga gamay nga kantidad).
        ///
        /// Sa ingon nga kaso, kini nga pag-andar nagabalik `0`.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Pagputos sa nahabilin nga Euclidean.Gikalkulo ang `self.rem_euclid(rhs)`, giputos sa libut sa utlanan sa tipo.
        ///
        /// Ang pagputos mahitabo ra sa `MIN % -1` sa usa ka pinirmahan nga tipo (diin ang `MIN` mao ang negatibo nga gamay nga kantidad alang sa tipo).
        /// Sa kini nga kaso, ningbalik ang pamaagi sa 0.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Pagbalot sa pagsalikway sa (modular).Gikalkulo ang `-self`, giputos sa libut sa utlanan sa tipo.
        ///
        /// Ang nag-usa ra nga kaso diin ang ingon nga pagputos mahimo nga mahitabo kung ang usa gibalibaran ang `MIN` sa usa ka pinirmahan nga tipo (diin ang `MIN` mao ang negatibo nga gamay nga kantidad alang sa tipo);kini usa ka positibo nga kantidad nga daghan kaayo aron magrepresentar sa tipo.
        /// Sa ingon nga kaso, kini nga pag-andar nagabalik mismo sa `MIN`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-libre nga gamay nga pagbalhin sa wala;abot sa `self << mask(rhs)`, diin `mask` removes sa bisan unsa nga high-order tipik sa `rhs` nga hinungdan sa pagbalhin ngadto sa molabaw sa bitwidth sa matang.
        ///
        /// Hinumdomi nga kini dili * parehas sa usa ka rotate-left;ang RHS sa usa ka wrapping shift-left gidid-an sa sukod sa tipo, kaysa ang mga tipik nga gibalhin gikan sa LHS nga gibalik sa pikas nga tumoy.
        ///
        /// Ang mga tipo sa primitive integer tanan nagpatuman sa usa ka [`rotate_left`](Self::rotate_left) function, nga mahimong imong gusto sa baylo.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // KALUWASAN: ang masking pinaagi sa bitsize sa tipo nagsiguro nga dili kami mobalhin
            // gikan sa utlanan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-libre nga gamay nga pagbalhin-tuo;nagahatag `self >> mask(rhs)`, diin gikuha sa `mask` ang bisan unsang mga high-order bits nga `rhs` nga mahimong hinungdan sa pagbalhin nga molapas sa bitwidth sa tipo.
        ///
        /// Hinumdomi nga kini dili * parehas sa usa ka tuyok sa tuo;ang RHS sa usa ka wrapping shift-right gikutuban sa sukod sa tipo, kaysa ang mga tipik nga gibalhin gikan sa LHS nga gibalik sa pikas nga tumoy.
        ///
        /// Ang mga tipo sa primitive integer tanan nagpatuman sa usa ka [`rotate_right`](Self::rotate_right) function, nga mahimong imong gusto sa baylo.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // KALUWASAN: ang masking pinaagi sa bitsize sa tipo nagsiguro nga dili kami mobalhin
            // gikan sa utlanan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Ang pagputos sa (modular) hingpit nga kantidad.Gikalkulo ang `self.abs()`, giputos sa libut sa utlanan sa tipo.
        ///
        /// Ang kaso ra kung diin mahimo`g mahitabo ang ingon nga pagputos kung kuhaon sa usa ang hingpit nga kantidad sa negatibo nga dyutay nga kantidad alang sa tipo;kini usa ka positibo nga kantidad nga daghan kaayo aron magrepresentar sa tipo.
        /// Sa ingon nga kaso, kini nga pag-andar nagabalik mismo sa `MIN`.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Kwentahon ang bug-os nga bili sa `self` walay bisan unsa nga pagputos o nataranta.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Ang pagputos sa (modular) exponentiation.
        /// Gikalkulo ang `self.pow(exp)`, giputos sa libut sa utlanan sa tipo.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // tungod kay exp!=0, sa katapusan ang exp kinahanglan nga 1.
            // Pag-atubang sa katapusang gamay sa exponent nga gilain, tungod kay ang pag-square sa base pagkahuman dili kinahanglan ug mahimong hinungdan sa wala kinahanglana nga pag-awas.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Gikalkula ang `self` + `rhs`
        ///
        /// Nagbalik usa ka tuple sa pagdugang uban ang usa ka boolean nga nagpakita kung ang usa ka arithmetic overflow mahitabo.
        /// Kung ang usa ka pag-awas unta nahinabo nga ang gibalus nga kantidad ibalik.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Gikalkula ang `self`, `rhs`
        ///
        /// Nagbalik usa ka tuple sa pagkuha lakip ang usa ka boolean nga nagpakita kung ang usa ka arithmetic overflow mahitabo.
        /// Kung ang usa ka pag-awas unta nahinabo nga ang gibalus nga kantidad ibalik.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Gikalkula ang pagpadaghan sa `self` ug `rhs`.
        ///
        /// Nagbalik usa ka tuple sa pagpadaghan kauban ang usa ka boolean nga nagpaila kung mahitabo ang usa ka arithmetic overflow.
        /// Kung ang usa ka pag-awas unta nahinabo nga ang gibalus nga kantidad ibalik.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, tinuod));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Nagtinguha sa tigbahín sa diha nga `self` nabahin sa `rhs`.
        ///
        /// Nagbalik usa ka tuple sa divisor kauban ang usa ka boolean nga nagpaila kung mahitabo ang usa ka arithmetic overflow.
        /// Kung ang usa ka pag-awas mahitabo kini sa imong kaugalingon mabalik.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Gikalkula ang kinutlo sa Euclidean dibisyon `self.div_euclid(rhs)`.
        ///
        /// Nagbalik usa ka tuple sa divisor kauban ang usa ka boolean nga nagpaila kung mahitabo ang usa ka arithmetic overflow.
        /// Kung ang usa ka pag-awas mahitabo unya ang `self` ibalik.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Gikalkula ang nahabilin kung ang `self` gibahin sa `rhs`.
        ///
        /// Gibalik ang usa ka tupol sa nahabilin pagkahuman pagbahin kauban ang usa ka boolean nga nagpakita kung ang usa ka arithmetic overflow mahitabo.
        /// Kung ang usa ka pag-awas mahitabo unya 0 ibalik.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Nag-awas nga nahabilin nga Euclidean.Nakalkula ang `self.rem_euclid(rhs)`.
        ///
        /// Gibalik ang usa ka tupol sa nahabilin pagkahuman pagbahin kauban ang usa ka boolean nga nagpakita kung ang usa ka arithmetic overflow mahitabo.
        /// Kung ang usa ka pag-awas mahitabo unya 0 ibalik.
        ///
        /// # Panics
        ///
        /// Ang kini nga pagpaandar mahimong panic kung ang `rhs` mao ang 0.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Maka panghimakak sa kaugalingon, nga magaawas kon kini mao nga sama sa sa minimum nga bili.
        ///
        /// Nagbalik usa ka tuple sa gipanghimatuud nga bersyon sa imong kaugalingon kauban ang usa ka boolean nga nagpaila kung usa ka overflow ang nahinabo.
        /// Kung ang `self` mao ang minimum nga kantidad (pananglitan, `i32::MIN` alang sa mga kantidad nga tipo `i32`), kung ingon niana ang ibalik nga minimum nga kantidad ug ibalik ang `true` alang sa usa ka overflow nga nahinabo.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Gibag-o ang kaugalingon nga nabilin sa `rhs` bits.
        ///
        /// Nagbalik usa ka tuple sa nabag-o nga bersyon sa kaugalingon kauban ang usa ka boolean nga nagpakita kung ang kantidad sa pagbalhin labi ka daghan kaysa o managsama sa gidaghanon sa mga tipik.
        /// Kung ang kantidad sa pagbalhin sobra ka daghan, nan ang kantidad gitabon sa (N-1) diin ang N ang gidaghanon sa mga tipik, ug kini nga kantidad gigamit aron mahimo ang pagbalhin.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, tinuod));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Gibag-o ang kaugalingon sa tuo pinaagi sa `rhs` bits.
        ///
        /// Nagbalik usa ka tuple sa nabag-o nga bersyon sa kaugalingon kauban ang usa ka boolean nga nagpakita kung ang kantidad sa pagbalhin labi ka daghan kaysa o managsama sa gidaghanon sa mga tipik.
        /// Kung ang kantidad sa pagbalhin sobra ka daghan, nan ang kantidad gitabon sa (N-1) diin ang N ang gidaghanon sa mga tipik, ug kini nga kantidad gigamit aron mahimo ang pagbalhin.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, tinuod));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Gikalkulo ang hingpit nga kantidad nga `self`.
        ///
        /// Nagbalik usa ka tuple sa hingpit nga bersyon sa kaugalingon kauban ang us aka boolean nga nagpaila kung adunay nahinabo nga overflow.
        /// Kung ang kaugalingon mao ang minimum nga kantidad
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// unya ang minimum nga kantidad ibalik pag-usab ug ang tinuod ibalik alang sa usa ka nag-awas nga nahinabo.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Gipataas ang kaugalingon sa gahum sa `exp`, nga gigamit ang exponentiation pinaagi sa pag-square.
        ///
        /// Nagbalik usa ka tuple sa exponentiation kauban ang usa ka bool nga nagpakita kung usa ka overflow ang nahinabo.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, tinuod));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scratch space alang sa pagtipig mga sangputanan sa nagaawas nga_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // tungod kay exp!=0, sa katapusan ang exp kinahanglan nga 1.
            // Pag-atubang sa katapusang gamay sa exponent nga gilain, tungod kay ang pag-square sa base pagkahuman dili kinahanglan ug mahimong hinungdan sa wala kinahanglana nga pag-awas.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Gipataas ang kaugalingon sa gahum sa `exp`, nga gigamit ang exponentiation pinaagi sa pag-square.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // tungod kay exp!=0, sa katapusan ang exp kinahanglan nga 1.
            // Pag-atubang sa katapusang gamay sa exponent nga gilain, tungod kay ang pag-square sa base pagkahuman dili kinahanglan ug mahimong hinungdan sa wala kinahanglana nga pag-awas.
            //
            //
            acc * base
        }

        /// Gikalkula ang kinutlo sa pagkabahin sa Euclidean sa `self` sa `rhs`.
        ///
        /// Gikalkulo niini ang integer `n` nga ingon niana `self = n * rhs + self.rem_euclid(rhs)`, nga adunay `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Sa laing pagkasulti, ang sangputanan mao ang `self / rhs` nga gilibot sa integer `n` nga ingon niana `self >= n * rhs`.
        /// Kung `self > 0`, katumbas kini sa lingin padulong sa zero (ang default sa Rust);
        /// kung `self < 0`, parehas kini sa lingin padulong sa +/-infinity.
        ///
        /// # Panics
        ///
        /// Ang kini nga pag-andar panic kung ang `rhs` 0 o ang pagbahin sa mga resulta sa overflow.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// pasagdan ang b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Gikalkula ang labing gamay nga dili nabilin nga nabilin nga `self (mod rhs)`.
        ///
        /// Gihimo kini ingon nga pinaagi sa Euclidean division algorithm-gihatag ang `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, ug `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ang kini nga pag-andar panic kung ang `rhs` 0 o ang pagbahin sa mga resulta sa overflow.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// pasagdan ang b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Gikalkulo ang hingpit nga kantidad nga `self`.
        ///
        /// # Sobra nga pamatasan
        ///
        /// Ang hingpit nga kantidad sa
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// dili mahimong girepresenta ingon usa ka
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ug ang pagsulay sa pagkalkulo niini magpahinabo sa usa ka pag-awas.
        /// Kini gipasabut nga ang code sa mode sa debug mag-aghat sa usa ka panic sa kini nga kaso ug mabalik ang na-optimize nga code
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// nga wala`y panic.
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Hinumdomi nga ang#[inline] sa taas nagpasabut nga ang nag-overflow nga mga semantiko sa pagbawas nagsalig sa crate nga gipunting naton.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Nagbalik usa ka numero nga nagrepresentar sa ilhanan sa `self`.
        ///
        ///  - `0` kung ang numero zero
        ///  - `1` kung positibo ang numero
        ///  - `-1` kung ang numero negatibo
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Gibalik ang `true` kung ang `self` positibo ug `false` kung ang numero zero o negatibo.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Gibalik ang `true` kung ang `self` negatibo ug `false` kung ang numero zero o positibo.
        ///
        ///
        /// # Examples
        ///
        /// Panguna nga gamit:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Ibalik ang representasyon sa memorya sa kini nga integer ingon usa ka byte array sa big-endian (network) byte order.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ibalik ang representasyon sa memorya sa kini nga integer ingon usa ka byte array sa gamay nga endian byte order.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ibalik ang representasyon sa memorya sa kini nga integer ingon usa ka byte array sa lumad nga han-ay nga han-ay.
        ///
        /// Ingon gigamit ang lumad nga katapusan sa target platform, ang portable code kinahanglan gamiton ang [`to_be_bytes`] o [`to_le_bytes`], kung angay, sa baylo.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, kung cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } lain pa {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // KALUWASAN: nag-ayo ang tunog tungod kay ang mga integer yano nga daan nga mga datatypes aron kanunay naton mahimo
        // ibalhin kini sa mga array sa mga byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // KALUWASAN: ang mga integer yano nga daan nga mga datatypes aron kanunay naton kini madala
            // mga array sa mga byte
            unsafe { mem::transmute(self) }
        }

        /// Ibalik ang representasyon sa memorya sa kini nga integer ingon usa ka byte array sa lumad nga han-ay nga han-ay.
        ///
        ///
        /// [`to_ne_bytes`] kinahanglan nga gipalabi sa kini bisan kanus-a mahimo.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// pasagdi ang mga byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, kung cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } lain pa {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // KALUWASAN: ang mga integer yano nga daan nga mga datatypes aron kanunay naton kini madala
            // mga array sa mga byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Paghimo usa ka kantidad nga integer gikan sa representasyon niini ingon usa ka byte array sa dako nga endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gamit ang std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pahulay;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Paghimo usa ka kantidad nga integer gikan sa representasyon niini ingon usa ka byte array sa gamay nga endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gamit ang std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pahulay;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Paghimo usa ka kantidad nga integer gikan sa representasyon sa memorya niini ingon usa ka byte array sa lumad nga pagtapos.
        ///
        /// Ingon gigamit ang lumad nga katapusan sa target platform, ang portable code lagmit gusto nga mogamit [`from_be_bytes`] o [`from_le_bytes`], kung angay na hinoon.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } lain pa {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gamit ang std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pahulay;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // KALUWASAN: nag-ayo ang tunog tungod kay ang mga integer yano nga daan nga mga datatypes aron kanunay naton mahimo
        // transmute sa kanila
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // KALUWASAN: ang mga integer yano nga daan nga mga datatypes aron kanunay naton kini mapadala
            unsafe { mem::transmute(bytes) }
        }

        /// Kinahanglan nga gamiton ang bag-ong code
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Gibalik ang labing gamay nga kantidad nga mahimong girepresenta sa kini nga klase sa integer.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Kinahanglan nga gamiton ang bag-ong code
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Gibalik ang labing kadaghan nga kantidad nga mahimong girepresenta sa kini nga klase sa integer.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}