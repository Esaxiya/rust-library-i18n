//! Ang libcore nga prelude
//!
//! Kini nga module gituyo alang sa mga mogamit sa libcore nga dili usab mag-link sa libstd.
//! Ang kini nga module gi-import pinaagi sa default kung gigamit ang `#![no_std]` sa parehas nga pamaagi sama sa standard nga librarya nga prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Ang 2015 nga bersyon sa kinauyokan nga prelude.
///
/// Tan-awa ang [module-level documentation](self) alang sa daghan pa.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ang bersyon sa 2018 sa kinauyokan nga prelude.
///
/// Tan-awa ang [module-level documentation](self) alang sa daghan pa.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ang bersyon nga 2021 sa kinauyokan nga prelude.
///
/// Tan-awa ang [module-level documentation](self) alang sa daghan pa.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Pagdugang daghang mga butang.
}