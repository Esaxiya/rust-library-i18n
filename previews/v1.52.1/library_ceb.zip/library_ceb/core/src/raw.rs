#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Adunay sulud nga mga kahulugan alang sa layout sa mga built-in nga tipo sa tagtipon.
//!
//! Mahimo sila magamit ingon mga target sa mga transmute sa dili luwas nga code alang sa direkta nga pagmaniobra sa mga hilaw nga representasyon.
//!
//!
//! Ang ilang kahulugan kinahanglan kanunay nga magkatugma sa gihubit sa ABI sa `rustc_middle::ty::layout`.
//!

/// Ang representasyon sa usa ka trait nga butang sama sa `&dyn SomeTrait`.
///
/// Ang kini nga istraktura adunay parehas nga paghan-ay sa mga tipo sama sa `&dyn SomeTrait` ug `Box<dyn AnotherTrait>`.
///
/// `TraitObject` gigarantiyahan nga itugma ang mga layout, apan dili kini ang tipo sa mga trait nga mga butang (pananglitan, ang mga umahan dili direkta nga ma-access sa usa ka `&dyn SomeTrait`) ug dili usab kini makontrol ang layout (ang pagbag-o sa kahulugan dili magbag-o sa layout sa usa ka `&dyn SomeTrait`).
///
/// Gidisenyo lamang kini aron magamit sa dili luwas nga kodigo nga kinahanglan gamiton ang mga detalye sa ubos nga lebel.
///
/// Wala'y paagi sa pagtumong sa tanan nga mga butang nga trait sa kasagaran, mao nga ang nag-usa ra nga paagi aron makahimo og mga kantidad sa kini nga klase mao ang mga pag-andar sama sa [`std::mem::transmute`][transmute].
/// Sa susama, ang bugtong nga paagi aron makahimo usa ka tinuud nga butang nga trait gikan sa usa ka `TraitObject` nga kantidad mao ang `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing sa usa ka trait butang uban sa wala-magkatakdo nga matang-usa diin ang vtable dili hisgotan sa matang sa mga bili nga ang data pointer puntos-ang kaayo lagmit sa paggiya sa dili tino ang kinaiya.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // usa ka pananglitan trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // himoa nga ang tighipos sa paghimo sa usa ka trait butang
/// let object: &dyn Foo = &value;
///
/// // tan-awa ang hilaw nga representasyon
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ang data pointer mao ang address sa `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // pagtukod usa ka bag-ong butang, nga nagtudlo sa usa ka lainlaing `i32`, nag-amping nga gamiton ang `i32` vtable gikan sa `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // kinahanglan kini molihok sama ra kung gitukod namon ang usa ka trait nga butang gikan sa `other_value` direkta
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}