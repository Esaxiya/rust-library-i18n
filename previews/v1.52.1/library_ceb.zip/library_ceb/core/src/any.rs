//! Gipatuman sa kini nga module ang `Any` trait, nga naghatag kusog nga pag-type sa bisan unsang `'static` type pinaagi sa runtime reflection.
//!
//! `Any` mahimo sa iyang kaugalingon nga gigamit sa pagkuha sa usa ka `TypeId`, ug adunay labaw pa nga mga bahin sa diha nga gigamit ingon nga sa usa ka trait butang.
//! Ingon sa `&dyn Any` (sa usa ka hinulaman trait butang), kini ang `is` ug `downcast_ref` pamaagi, aron sa pagsulay kon ang anaa bili sa usa ka gihatag nga matang, ug sa pagkuha sa usa ka paghisgot sa mga sulod nga bili ingon nga usa ka matang.
//! Ingon `&mut dyn Any`, adunay usab pamaagi nga `downcast_mut`, alang sa pagkuha us aka mutable nga pakisayran sa sulud nga kantidad.
//! `Box<dyn Any>` nagdugang ang `downcast` nga pamaagi, nga mosulay sa pagkabig sa usa ka `Box<T>`.
//! Tan-awa ang [`Box`] dokumento alang sa bug-os nga mga detalye.
//!
//! Hinumdomi nga ang `&dyn Any` limitado sa pagsulay kung ang us aka kantidad usa ka gipiho nga konkreto nga tipo, ug dili magamit aron masulay kung ang usa ka tipo nagpatuman sa usa ka trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers ug `dyn Any`
//!
//! Usa ka piraso nga pamatasan nga ibutang sa hunahuna kung naggamit `Any` ingon usa ka trait nga butang, labi na ang mga tipo sama sa `Box<dyn Any>` o `Arc<dyn Any>`, mao nga ang pagtawag sa `.type_id()` sa kantidad makahatag sa `TypeId` sa *container*, dili sa nagpahiping trait nga butang.
//!
//! Mahimo kini malikayan pinaagi sa pagkabig sa smart pointer sa usa ka `&dyn Any` sa baylo, nga ibalik ang `TypeId` sa butang.
//! Pananglitan:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Labi ka nga gusto nimo kini:
//! let actual_id = (&*boxed).type_id();
//! // ... kaysa niini:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tagda ang usa ka kahimtang diin kita buot nga log sa usa ka bili milabay sa usa ka function.
//! Nahibal-an namon ang kantidad nga among gibuhat sa pagpatuman sa Debug, apan wala namon nahibal-an ang konkreto nga tipo niini.Gusto namo nga sa paghatag sa espesyal nga pagtambal sa pipila ka mga matang: sa niini nga kaso sa pag-imprenta sa gitas-on sa hilo nagpabili sa wala pa sa ilang bili.
//! Wala namon nahibal-an ang konkreto nga tipo sa among kantidad sa pag-ipon sa oras, busa kinahanglan namon gamiton hinoon ang pagpamalandong sa runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger function alang sa bisan unsa nga matang nga galamiton debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Sulayi sa kinabig sa atong bili ngadto sa usa ka `String`.
//!     // Kung malampuson, gusto namon nga ipagawas ang gitas-on sa String` ingon man ang kantidad niini.
//!     // Kon dili, kini usa ka lain-laing mga matang: lang print kini gikan unadorned.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Kini nga pag-andar gusto nga i-log ang parameter niini sa wala pa magtrabaho kini.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... pagbuhat sa pipila sa uban nga mga buhat
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Bisan unsang trait
///////////////////////////////////////////////////////////////////////////////

/// Usa ka trait nga sundogon ang dinamikong pag-type.
///
/// Kadaghanan sa mga lahi nagpatuman sa `Any`.Apan, bisan unsa nga matang nga naglakip sa usa ka non-`'static` pakisayran dili.
/// Tan-awa ang [module-level documentation][mod] alang sa dugang nga mga detalye.
///
/// [mod]: crate::any
// Kini trait dili luwas, bisan tuod kita mosalig sa detalye sa `type_id` function kini ni bugtong impl sa dili luwas nga code (pananglitan, `downcast`).Kasagaran, kana mahimo`g usa ka problema, apan tungod kay ang bugtong nga impl sa `Any` usa ka habol nga pagpatuman, wala`y lain nga code ang mahimong mapatuman sa `Any`.
//
// kita nga mapanghimatuorang sa paghimo niini nga trait luwas-kini dili hinungdan sa pagkabuak, kay sa pagpugong sa atong tanan nga mga implementar-apan kita dili mopili sa ingon nga ang duha dili gayud gikinahanglan ug mahimo nga libogon tiggamit bahin sa kalainan sa dili luwas traits ug dili luwas nga mga pamaagi (ie, `type_id` gihapon nga luwas sa pagtawag, apan nga kita lagmit gusto nagpakita sa ingon sa dokumentasyon).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Nakuha ang `TypeId` nga `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Mga pamaagi sa extension alang sa Bisan unsang mga butang nga trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Siguroha nga ang mga resulta sa eg, apil sa usa ka lugas nga hilo nga mahimong giimprinta ug busa gigamit sa `unwrap`.
// Mahimong sa ulahi dili na kinahanglan kung ang pagpadala molihok uban ang pag-upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Gibalik ang `true` kung ang boxed type parehas sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Pagkuha `TypeId` sa tipo nga kini nga pagpaandar gisugdan.
        let t = TypeId::of::<T>();

        // Kuhaa ang `TypeId` nga tipo sa trait nga butang (`self`).
        let concrete = self.type_id();

        // Itandi ang parehas nga `TypeId`s sa pagkaparehas.
        t == concrete
    }

    /// Gibalik ang pipila nga pakisayran sa kantidad nga kahon kung kini lahi sa `T`, o `None` kung dili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KALUWASAN: gisusi ra kung nagtudlo kami sa husto nga tipo, ug makasalig kami
            // kana nga pagsusi alang sa kahilwasan sa memorya tungod kay gipatuman namon ang Bisan unsang alang sa tanan nga mga lahi;wala`y ubang mga impls nga mahimo`g maglungtad tungod kay sila magkasumpaki sa among impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Mobalik sa pipila ka mutable paghisgot sa nagpugong bili kon kini mao ang sa matang `T`, o `None` kon kini mao ang dili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KALUWASAN: gisusi ra kung nagtudlo kami sa husto nga tipo, ug makasalig kami
            // kana nga pagsusi alang sa kahilwasan sa memorya tungod kay gipatuman namon ang Bisan unsang alang sa tanan nga mga lahi;wala`y ubang mga impls nga mahimo`g maglungtad tungod kay sila magkasumpaki sa among impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pagpadayon sa pamaagi nga gihubit sa tipo nga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ug ang mga pamaagi niini
///////////////////////////////////////////////////////////////////////////////

/// Ang usa ka `TypeId` nagrepresentar sa us aka tibuuk nga kalibutan nga nagpaila alang sa usa ka lahi.
///
/// Ang matag `TypeId` mao ang usa ka opaque butang nga dili motugot inspection sa unsay sulod apan motugot nag-unang mga operasyon sama sa cloning, pagtandi, sa pag-imprinta, ug sa pagpakita.
///
///
/// Ang usa ka `TypeId` karon magamit ra alang sa mga lahi nga gipahinungod sa `'static`, apan ang kini nga limitasyon mahimong makuha sa future.
///
/// Samtang ang `TypeId` nagpatuman sa `Hash`, `PartialOrd`, ug `Ord`, angay nga hinumdoman nga ang mga hash ug paghan-ay magkalainlain taliwala sa pagpagawas sa Rust.
/// Paglikay sa pagsalig sa kanila sa sulud sa imong code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Gibalik ang `TypeId` sa tipo nga kini nga tibuuk nga paglihok gisugdan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Gibalik ang ngalan sa usa ka tipo ingon usa ka hiwa sa pisi.
///
/// # Note
///
/// Gilaraw kini alang sa paggamit sa diagnostic.
/// Ang ensakto nga sulud ug pormat sa gibalik nga pisi dili gitino, gawas sa pagkahimong labing paghukum nga paghulagway sa tipo.
/// Pananglitan, taliwala sa mga mga kuwerdas nga `type_name::<Option<String>>()` aron mobalik ang mga `"Option<String>"` ug `"std::option::Option<std::string::String>"`.
///
///
/// Ang giuli nga pisi dili kinahanglan isipon nga usa ka talagsaon nga nagpaila sa usa ka lahi tungod kay daghang mga tipo ang mahimong mapa sa parehas nga ngalan sa tipo.
/// Sa susama, walay garantiya nga ang tanan nga mga bahin sa usa ka matang magapakita diha sa mibalik hilo: kay sa panig-ingnan, sa tibuok kinabuhi specifiers karon wala naglakip.
/// Ingon kadugangan, ang output mahimong magbag-o sa taliwala sa mga bersyon sa nag-compiler.
///
/// Ang kasamtangan nga implementasyon naggamit sa sama nga imprastruktura nga sama sa tighipos diagnostics ug debuginfo, apan kini dili garantiya.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Gibalik ang ngalan sa tipo sa gitudlo nga kantidad ingon usa ka hiwa sa pisi.
/// Kini parehas sa `type_name::<T>()`, apan mahimong magamit diin ang lahi sa usa ka variable dili dali makuha.
///
/// # Note
///
/// Gilaraw kini alang sa paggamit sa diagnostic.Ang tukmang sulod ug format sa pisi dili bungat, sa uban nga kay sa usa ka labing maayo nga-nga paningkamot nga paghulagway sa matang.
/// Kay sa panig-ingnan, `type_name_of_val::<Option<String>>(None)` makabalik `"Option<String>"` o `"std::option::Option<std::string::String>"`, apan dili `"foobar"`.
///
/// Ingon kadugangan, ang output mahimong magbag-o sa taliwala sa mga bersyon sa nag-compiler.
///
/// Ang kini nga kalihokan dili masulbad ang mga butang nga trait, nagpasabut nga ang `type_name_of_val(&7u32 as &dyn Debug)` mahimo`g ibalik ang `"dyn Debug"`, apan dili ang `"u32"`.
///
/// Ang matang ngalan dili kinahanglan nga giisip nga usa ka talagsaon nga ilhanan sa usa ka matang;
/// daghang matang mahimo sa pagpakigbahin sa mao gihapon nga ngalan nga matang.
///
/// Ang kasamtangan nga implementasyon naggamit sa sama nga imprastruktura nga sama sa tighipos diagnostics ug debuginfo, apan kini dili garantiya.
///
/// # Examples
///
/// Giimprinta ang mga default nga klase sa integer ug float.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}