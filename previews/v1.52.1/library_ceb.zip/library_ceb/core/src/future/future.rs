#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Usa ka future nagrepresentar sa usa ka asynchronous pagsuma.
///
/// Usa ka future mao ang usa ka bili nga dili mahuman na sa pagkwenta pa.
/// Kini nga matang sa "asynchronous value" naghimo niini nga posible alang sa usa ka lugas nga hilo sa pagpadayon sa pagbuhat sa mapuslanon nga buhat samtang maghulat alang sa bili nga mahimong anaa.
///
///
/// # Ang `poll` pamaagi
///
/// Ang panguna nga pamaagi sa future, `poll`,*pagsulay* nga sulbaron ang future sa usa ka katapusang kantidad.
/// Kini nga pamaagi dili babagan kung ang bili dili pa andam.
/// Hinunoa, ang kasamtangan nga tahas mao ang gikatakda nga mipamata sa diha nga kini posible nga sa paghimo sa dugang nga pag-uswag pinaagi sa `poll`ing pag-usab.
/// Ang `context` nga gipasa sa pamaagi nga `poll` makahatag usa ka [`Waker`], nga usa ka gunitanan alang sa pagmata sa karon nga buluhaton.
///
/// Sa diha nga ang paggamit sa usa ka future, ikaw sa kinatibuk-dili sa pagtawag `poll` direkta, apan sa baylo `.await` sa bili.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Ang matang sa bili nga gipatungha sa pagkompleto.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Mosulay sa pagsulbad sa future ngadto sa usa ka katapusan nga bili, pagparehistro sa kasamtangan nga buluhaton alang sa wakeup kon ang bili dili pa magamit.
    ///
    /// # Bumalik bili
    ///
    /// Mobalik kini nga kalihokan:
    ///
    /// - [`Poll::Pending`] kon ang future dili andam pa
    /// - [`Poll::Ready(val)`] nga adunay sangputanan `val` sa kini nga future kung kini nahuman nga malampuson.
    ///
    /// Sa higayon nga ang usa ka future nahuman na, ang mga kliyente dili na kinahanglan `poll` kini pag-usab.
    ///
    /// Sa diha nga ang usa ka future dili andam pa, `poll` mobalik `Poll::Pending` ug mga dapa sa usa ka clone sa [`Waker`] gikopya gikan sa kasamtangan nga [`Context`].
    /// Kini nga [`Waker`] Dayon mipamata sa higayon nga ang future makahimo pag-uswag.
    /// Pananglitan, ang usa ka future naghulat alang sa usa ka ugbokanan nga mahimong mabasa motawag `.clone()` sa [`Waker`] ug tigumon kini.
    /// Kon mag-abot sa usa ka signal sa ubang dapit nagpakita nga ang mga suksokanang mao ang mabasa, [`Waker::wake`] gitawag ug ang piyakpiyak tahas ni future ang awoken.
    /// Kung nahigmata na ang usa ka buluhaton, kinahanglan kini nga pagsulay nga `poll` ang future pag-usab, nga mahimo o dili makahimo usa ka katapusang kantidad.
    ///
    /// Hinumdomi nga sa daghang mga tawag sa `poll`, ang [`Waker`] lamang gikan sa [`Context`] nga gipasa sa labing bag-o nga tawag ang kinahanglan nga gikatakda aron makadawat usa ka pagpukaw.
    ///
    /// # Runtime kinaiya
    ///
    /// Ang Futures ra ang *inert*;kinahanglan sila nga *aktibo*`poll` nga makahimo sa pag-uswag, nagpasabut nga sa matag higayon nga pukawon ang karon nga buluhaton, kinahanglan kini nga aktibo nga i-re`poll` ang pagpaabut sa futures nga adunay pa kini interes.
    ///
    /// Ang `poll` function wala gitawag balik-balik sa usa ka hugot nga loop-sa baylo, kini kinahanglan lamang nga gitawag sa diha nga ang future nagpakita nga kini mao ang andam na sa paghimo sa pag-uswag (pinaagi sa pagtawag `wake()`).
    /// Kon ikaw pamilyar sa `poll(2)` o `select(2)` syscalls sa Unix kini ni nga kantidad noting nga futures kasagaran sa pagbuhat sa dili * mag-antus sa sama nga mga problema sa "all wakeups must poll all events";labi sila sama sa `epoll(4)`.
    ///
    /// Usa ka pagpatuman sa `poll` kinahanglan maningkamot nga mobalik sa madali, ug kinahanglan nga dili babagan.Ang pagbalik sa dali nga pagpugong sa wala kinahanglan nga pagbara sa mga hilo o mga galong sa kalihokan.
    /// Kung nahibal-an nga abante nga oras nga ang usa ka tawag sa `poll` mahimong matapos nga makadiyot, ang trabaho kinahanglan nga i-offload sa usa ka thread pool (o susama nga butang) aron masiguro nga ang `poll` makabalik dayon.
    ///
    /// # Panics
    ///
    /// Sa higayon nga ang usa ka future nga nahuman (mibalik `Ready` gikan sa `poll`), nga nagatawag sa iyang `poll` pamaagi pag-usab aron panic, babagan sa walay katapusan, o hinungdan sa uban nga mga matang sa mga problema;ang `Future` trait wala gibutang nga mga kinahanglanon sa mga epekto sa ingon nga tawag.
    /// Apan, ingon nga ang mga `poll` pamaagi dili nagtimaan `unsafe`, naandan lagda ni Rust paggamit: tawag kinahanglan dili hinungdan sa dili tino ang kinaiya (sa panumdoman sa korapsyon, sayop nga paggamit sa `unsafe` gimbuhaton, o sa sama), sa walay pagtagad sa estado sa future ni.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}