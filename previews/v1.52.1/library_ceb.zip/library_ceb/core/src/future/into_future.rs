use crate::future::Future;

/// Ang pagkakabig ngadto sa usa ka `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Ang output nga ang future magpatunghag sa pagkompleto.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Nga matang sa future kita milingi niini ngadto sa?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Nagmugna sa usa ka future gikan sa usa ka bili.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}