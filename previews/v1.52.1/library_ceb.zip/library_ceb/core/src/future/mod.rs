#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchronous mga prinsipyo.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Kinahanglan kini nga tipo tungod kay:
///
/// ang usa ka) Generators dili pagpatuman `for<'a, 'b> Generator<&'a mut Context<'b>>`, mao nga kita kinahanglan nga moagi sa usa ka hilaw nga pointer (tan-awa sa <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Hilaw nga pointers ug `NonNull` dili `Send` o `Sync`, aron nga sa paghimo sa matag future non-Send/Sync ingon man, ug dili kita gusto nga.
///
/// Gipasayon usab niini ang pagpaubus sa HIR sa `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Pagputos sa usa ka generator sa usa ka future.
///
/// Ang kini nga kalihokan nagbalik usa ka `GenFuture` sa ilawom, apan gitago kini sa `impl Trait` aron makahatag labi ka maayo nga mga mensahe sa sayup (`impl Future` kaysa `GenFuture<[closure.....]>`).
///
// Kini mao ang `const` sa paglikay sa dugang nga mga sayop human kita mamaayo gikan sa `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Gisalig namon ang katinuud nga ang async/await futures dili matarug aron makahimo pagmugna sa kaugalingon nga mga pahulam sa nagpahiping generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // KALUWASAN: Luwas tungod kay kita !Unpin + !Drop, ug kini usa lang ka projime sa uma.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ipadayon ang generator, himua ang `&mut Context` nga usa ka `NonNull` nga hilaw nga pointer.
            // Ang pagpaubus sa `.await` luwas nga ibalik kana sa usa ka `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `cx.0` usa ka balido nga tudlo
    // nga nagtuman sa tanan nga mga kinahanglanon alang sa usa ka mutable nga pakisayran.
    unsafe { &mut *cx.0.as_ptr().cast() }
}