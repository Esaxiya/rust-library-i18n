//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Ang labing kataas nga balido nga code point nga mahimo sa usa ka `char`.
    ///
    /// Ang `char` usa ka [Unicode Scalar Value], nga nagpasabut nga kini usa ka [Code Point], apan ang usa ra sa sulud sa usa ka piho nga sakup.
    /// `MAX` mao ang labing taas nga balido code punto nga ang usa ka balido nga [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () gigamit sa Unicode nga nagrepresentar sa usa ka pagsusi sa kahulogan sa sayop.
    ///
    /// Kini mahimong mahitabo, alang sa panig-ingnan, sa diha nga sa paghatag mangil-umol UTF-8 bytes sa [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Ang bersyon sa [Unicode](http://www.unicode.org/) nga ang Unicode mga bahin sa `char` ug `str` mga pamaagi gibase sa.
    ///
    /// Ang mga bag-ong bersyon sa Unicode regular nga gipagawas ug pagkahuman ang tanan nga mga pamaagi sa standard library depende sa Unicode ang gi-update.
    /// Busa ang pamatasan sa pipila ka mga pamaagi nga `char` ug `str` ug ang kantidad sa kini nga kanunay nga pagbag-o sa paglabay sa panahon.
    /// Kini mao ang dili * giisip nga usa ka pagbanagbanag kausaban.
    ///
    /// Ang laraw sa pagnumero sa bersyon gipatin-aw sa [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Nagmugna sa usa ka iterator sa ibabaw sa UTF-16 encoded puntos code sa `iter`, pagbalik unpaired kahalili ingon `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Usa ka lossy decoder mahimo nga nakuha pinaagi sa pag-ilis sa `Err` resulta sa puli nga kinaiya:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Kinabig sa usa ka `u32` ngadto sa usa ka `char`.
    ///
    /// Mubo nga sulat nga ang tanan nga `char`s mga balido [`u32`], ug mahimong isalikway sa usa uban sa
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Apan, ang mga Reverse dili tinuod: dili ang tanan balido [`u32`] sa mga balido`char`s.
    /// `from_u32()` mobalik `None` kon ang input dili usa ka balido nga bili alang sa usa ka `char`.
    ///
    /// Alang sa dili luwas nga bersyon sa kini nga pag-andar nga wala manumbaling sa kini nga mga pagsusi, tan-awa ang [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Mibalik `None` sa diha nga ang input dili usa ka balido nga `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Gibag-o ang usa ka `u32` sa usa ka `char`, nga wala manumbaling ang pagkamaayo.
    ///
    /// Mubo nga sulat nga ang tanan nga `char`s mga balido [`u32`], ug mahimong isalikway sa usa uban sa
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Apan, ang mga Reverse dili tinuod: dili ang tanan balido [`u32`] sa mga balido`char`s.
    /// `from_u32_unchecked()` ang ibaliwala kini, ug blindly gitambog ngadto sa `char`, nga lagmit pagmugna sa usa ka imbalido usa.
    ///
    ///
    /// # Safety
    ///
    /// Ang kini nga pag-andar dili luwas, tungod kay mahimo kini maghatag dili balido nga mga kantidad nga `char`.
    ///
    /// Alang sa usa ka luwas nga bersyon sa kini nga pag-andar, tan-awa ang pagpaandar sa [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAFETY: ang kaluwasan kontrata kinahanglan gituboy pinaagi sa caller.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Nakabig usa ka digit sa gihatag nga radix sa usa ka `char`.
    ///
    /// Ang usa ka 'radix' dinhi usahay gitawag usab nga 'base'.
    /// Usa ka radix sa duha ka nagpaila nga usa ka duha nga gidaghanon, ang usa ka radix sa napulo, decimal, ug usa ka radix sa napulo ug unom, hexadecimal, sa paghatag sa pipila ka komon nga mga prinsipyo.
    ///
    /// Gisuportahan ang mga arbitraryong radice.
    ///
    /// `from_digit()` ibalik ang `None` kung ang input dili usa ka digit sa gihatag nga radix.
    ///
    /// # Panics
    ///
    /// Panics kon gihatag sa usa ka radix mas dako pa kay sa 36.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Ang Decimal 11 usa ka digit sa base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Pagbalik sa `None` kung ang input dili usa ka digit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Minglabaw sa usa ka dako nga radix, hinungdan sa usa ka panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Checks kon ang usa ka `char` mao ang usa ka digit sa gihatag nga radix.
    ///
    /// Ang usa ka 'radix' dinhi usahay gitawag usab nga 'base'.
    /// Usa ka radix sa duha ka nagpaila nga usa ka duha nga gidaghanon, ang usa ka radix sa napulo, decimal, ug usa ka radix sa napulo ug unom, hexadecimal, sa paghatag sa pipila ka komon nga mga prinsipyo.
    ///
    /// Gisuportahan ang mga arbitraryong radice.
    ///
    /// Kung itandi sa [`is_numeric()`], ang kini nga pag-andar nakilala ra ang mga karakter nga `0-9`, `a-z` ug `A-Z`.
    ///
    /// 'Digit' gipasabut nga mao ra ang mosunud nga mga karakter:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Kay sa usa ka mas komprehensibo nga pagsabot sa 'digit', tan-awa [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics kon gihatag sa usa ka radix mas dako pa kay sa 36.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Minglabaw sa usa ka dako nga radix, hinungdan sa usa ka panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Nagbag-o ang usa ka `char` sa usa ka digit sa gihatag nga radix.
    ///
    /// Ang usa ka 'radix' dinhi usahay gitawag usab nga 'base'.
    /// Usa ka radix sa duha ka nagpaila nga usa ka duha nga gidaghanon, ang usa ka radix sa napulo, decimal, ug usa ka radix sa napulo ug unom, hexadecimal, sa paghatag sa pipila ka komon nga mga prinsipyo.
    ///
    /// Gisuportahan ang mga arbitraryong radice.
    ///
    /// 'Digit' gipasabut nga mao ra ang mosunud nga mga karakter:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Gibalik ang `None` kung ang `char` dili magtumong sa usa ka digit sa gihatag nga radix.
    ///
    /// # Panics
    ///
    /// Panics kon gihatag sa usa ka radix mas dako pa kay sa 36.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Minglabaw sa usa ka non-digit nga resulta sa kapakyasan:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Minglabaw sa usa ka dako nga radix, hinungdan sa usa ka panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ang code ang tipak sa dinhi sa pagpalambo sa pagpatay speed sa mga kaso diin ang `radix` mao ang kanunay nga ug 10 o mas gagmay
        //
        let val = if likely(radix <= 10) {
            // Kon dili sa usa ka digit, ang usa ka gidaghanon nga mas dako kay sa radix nga gibuhat.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Mobalik sa usa ka iterator nga magahatag sa hexadecimal Unicode ikyas sa usa ka kinaiya nga sama `char`s.
    ///
    /// Kini makaikyas karakter sa Rust syntax sa porma `\u{NNNNNN}` diin `NNNNNN` mao ang usa ka hexadecimal representasyon.
    ///
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // o-ing 1 gisiguro nga alang sa c==0 ang pagkalkula sa code nga ang usa ka digit kinahanglan ipatik ug (nga parehas) likayan ang (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ang indeks sa labing makahuluganon nga hex digit
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Usa ka taas nga nga bersyon sa `escape_debug` nga optionally gitugotan makaikyas Gipadako grapemo codepoints.
    /// Gitugotan kami niini nga ma-format ang mga karakter sama sa dili maayo nga marka sa mga marka kung naa kini sa pagsugod sa usa ka pisi.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Nagbalik usa ka iterator nga naghatag literal nga code sa pag-ikyas sa usa ka karakter ingon mga `char`s.
    ///
    /// Kini makalingkawas sa mga karakter nga susama sa `Debug` implementar sa `str` o `char`.
    ///
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Nagbalik usa ka iterator nga naghatag literal nga code sa pag-ikyas sa usa ka karakter ingon mga `char`s.
    ///
    /// remate ang mga pinili nga may usa ka kahilig ngadto sa og literals nga legal sa usa ka matang sa mga pinulongan, lakip na ang C++ 11 ug sa susamang C-pamilya pinulongan.
    /// Ang ensakto nga mga lagda mao ang:
    ///
    /// * Ang Tab nakaikyas ingon `\t`.
    /// * Carro pagbalik giluwas ingon `\r`.
    /// * Line feed giluwas ingon `\n`.
    /// * Ang usa nga kinutlo nakagawas ingon `\'`.
    /// * Ang doble nga kinutlo nakagawas ingon `\"`.
    /// * Nakalikay ang Backslash ingon `\\`.
    /// * Ang bisan unsang karakter sa 'ma-print ASCII' range `0x20` .. `0x7e` inclusive dili nakaikyas.
    /// * Ang tanan nga lain nga mga karakter nga gihatag hexadecimal Unicode makagawas;tan-awa ang [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Mibalik ang gidaghanon sa mga bytes niini `char` kinahanglan kon encoded sa UTF-8.
    ///
    /// Kana nga ihap sa mga byte kanunay taliwala sa 1 ug 4, lakip na.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ang tipo nga `&str` naggarantiya nga ang sulud niini UTF-8, ug aron maibalhin namon ang gitas-on nga kuhaon kung ang matag code point girepresentar ingon usa ka `char` vs sa `&str` mismo:
    ///
    ///
    /// ```
    /// // ingon chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ang duha mahimong girepresenta ingon tulo ka mga byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ingon sa usa ka &str, kining duha ka mga encoded sa UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // makita naton nga mikuha sila unom ka bytes nga total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... sama sa &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Gibalik ang numero sa 16-bit code unit nga kinahanglan sa `char` kung na-encode sa UTF-16.
    ///
    ///
    /// Tan-awa ang dokumento alang sa [`len_utf8()`] alang sa dugang katin-awan sa niini nga konsepto.
    /// Kini nga pag-andar usa ka salamin, apan alang sa UTF-16 imbis nga UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// - Encode kini nga kinaiya sama sa UTF-8 ngadto sa gihatag Byte buffer, ug unya mobalik sa subslice sa buffer nga naglangkob sa simbolikong kinaiya.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon ang buffer dili dako nga igo.
    /// Ang usa ka buffer nga gitas-on sa upat igoigo ang igo aron ma-encode ang bisan unsang `char`.
    ///
    /// # Examples
    ///
    /// Sa parehas nga kini nga pananglitan, ang 'ß' nagkinahanglan duha ka byte aron ma-encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Usa ka buffer nga gamay ra kaayo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` dili usa ka puli nga, mao nga kini mao ang balido UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// - Encode kini nga kinaiya sama sa UTF-16 ngadto sa gihatag `u16` buffer, ug unya mobalik sa subslice sa buffer nga naglangkob sa simbolikong kinaiya.
    ///
    ///
    /// # Panics
    ///
    /// Panics kon ang buffer dili dako nga igo.
    /// Usa ka buffer sa gitas-on sa 2 mao ang dako nga igo sa encode sa bisan unsa nga `char`.
    ///
    /// # Examples
    ///
    /// Sa parehas nga kini nga pananglitan, ang '𝕊' nagkuha og duha nga `u16` aron ma-encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Usa ka buffer nga gamay ra kaayo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Gibalik ang `true` kung kini nga `char` adunay `Alphabetic` nga kabtangan.
    ///
    /// `Alphabetic` gihulagway sa Kapitulo 4 (Kinaiya Properties) sa [Unicode Standard] ug bungat sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // Ang gugma daghang butang, apan dili kini alpabetiko
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Gibalik ang `true` kung kini nga `char` adunay `Lowercase` nga kabtangan.
    ///
    /// `Lowercase` gihulagway sa Kapitulo 4 (Kinaiya Properties) sa [Unicode Standard] ug bungat sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Ang lainlaing mga iskrip sa China ug bantas wala`y kaso, ug busa:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Gibalik ang `true` kung kini nga `char` adunay `Uppercase` nga kabtangan.
    ///
    /// `Uppercase` gihulagway sa Kapitulo 4 (Kinaiya Properties) sa [Unicode Standard] ug bungat sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Ang lainlaing mga iskrip sa China ug bantas wala`y kaso, ug busa:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Gibalik ang `true` kung kini nga `char` adunay `White_Space` nga kabtangan.
    ///
    /// `White_Space` ang bungat sa [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ang usa ka non-paglapas luna
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Gibalik ang `true` kung kini nga `char` matagbaw sa bisan unsang [`is_alphabetic()`] o [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Gibalik ang `true` kung kini nga `char` adunay kasagaran nga kategorya alang sa mga control code.
    ///
    /// Control mga code (puntos code uban sa kinatibuk-ang kategoriya sa `Cc`) gihubit sa Kapitulo 4 (Kinaiya Properties) sa [Unicode Standard] ug bungat sa [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Gibalik ang `true` kung kini nga `char` adunay `Grapheme_Extend` nga kabtangan.
    ///
    /// `Grapheme_Extend` gihulagway sa [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ug gitino sa [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Mibalik `true` kon kini `char` adunay usa sa mga kinatibuk-ang mga kategoriya alang sa mga numero.
    ///
    /// Ang kinatibuk-ang mga kategorya alang sa mga numero (`Nd` alang sa decimal digit, `Nl` alang sa susama sa letra nga mga karakter nga numero, ug `No` alang sa uban pang mga karakter nga numero) gipiho sa [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Nagbalik usa ka iterator nga naghatag sa gagmay nga pagmapa nga kini nga `char` ingon usa o daghan pa
    /// `char`s.
    ///
    /// Kung kini nga `char` wala`y gamay nga pagmapa, ang iterator nagahatag parehas nga `char`.
    ///
    /// Kon kini nga `char` adunay usa ka usa ka-sa-usa ka lowercase mapping nga gihatag sa [Unicode Character Database][ucd] [`UnicodeData.txt`], ang iterator abot nga `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kung kini nga `char` nanginahanglan espesyal nga konsiderasyon (pananglitan daghang `char`s) ang iterator naghatag sa`char` (s) nga gihatag sa [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Kini nga operasyon nagabuhat sa usa ka walay kondisyon nga mapping nga walay pagpahaum sa.Nga mao, ang pagkakabig mao ang gawasnon sa konteksto ug pinulongan.
    ///
    /// Sa [Unicode Standard], Chapter 4 (Kinaiya Properties) naghisgot kaso mapping sa kinatibuk ug Kapitulo 3 (Conformance) naghisgot sa default algorithm alang sa kaso sa pagkakabig.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Usahay ang sangputanan labaw pa sa usa ka karakter:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ang mga karakter nga wala`y parehas nga uppercase ug lowercase nga nakabig sa ilang kaugalingon.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Mobalik sa usa ka iterator nga magahatag sa uppercase mapping niining `char` ingon sa usa o labaw pa
    /// `char`s.
    ///
    /// Kon kini `char` wala sa usa ka uppercase mapping, ang iterator makahatag sa sama nga `char`.
    ///
    /// Kung kini nga `char` adunay us aka us aka uppercase mapping nga gihatag sa [Unicode Character Database][ucd] [`UnicodeData.txt`], naghatag ang iterator nga `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kung kini nga `char` nanginahanglan espesyal nga konsiderasyon (pananglitan daghang `char`s) ang iterator naghatag sa`char` (s) nga gihatag sa [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Kini nga operasyon nagabuhat sa usa ka walay kondisyon nga mapping nga walay pagpahaum sa.Nga mao, ang pagkakabig mao ang gawasnon sa konteksto ug pinulongan.
    ///
    /// Sa [Unicode Standard], Chapter 4 (Kinaiya Properties) naghisgot kaso mapping sa kinatibuk ug Kapitulo 3 (Conformance) naghisgot sa default algorithm alang sa kaso sa pagkakabig.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Usahay ang sangputanan labaw pa sa usa ka karakter:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ang mga karakter nga wala`y parehas nga uppercase ug lowercase nga nakabig sa ilang kaugalingon.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Hinumdomi sa lokal nga lugar
    ///
    /// Sa Turkish, ang katumbas nga 'i' sa Latin adunay lima ka porma imbis nga duha:
    ///
    /// * 'Dotless': Ako/ı, usahay gisulat ï
    /// * 'Dotted': Í/i
    ///
    /// Timan-i nga ang lowercase dotted 'i' mao ang sama nga ingon sa mga Latin.Busa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ang bili sa `upper_i` dinhi nagsalig sa pinulongan sa mga teksto: kon kita sa `en-US`, kini kinahanglan nga `"I"`, apan kon kita sa `tr_TR`, kini kinahanglan nga `"İ"`.
    /// `to_uppercase()` wala kini tagda, ug busa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// naghupot sa tibuok pinulongan.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Gisusi kung ang kantidad naa sa sulud sa ASCII range.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Naghimo usa ka kopya sa kantidad sa ASCII sa taas nga kaso nga katumbas.
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mapataas ang kantidad nga naa sa lugar, gamita ang [`make_ascii_uppercase()`].
    ///
    /// Aron mapadako ang mga karakter nga ASCII agig dugang sa mga dili ASCII nga mga karakter, gamita ang [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Naghimo usa ka kopya sa kantidad sa ASCII nga mas ubos nga kaso nga katumbas.
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron lowercase sa bili sa-dapit, sa paggamit sa [`make_ascii_lowercase()`].
    ///
    /// Sa pagminus sa mga karakter nga ASCII agig dugang sa mga dili ASCII nga mga karakter, gamita ang [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tseke nga duha ka mga prinsipyo mao ang usa ka ASCII kaso-sensitibo match.
    ///
    /// Katumbas sa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Gikabig kini nga tibuuk sa ASCII sa taas nga kaso nga katumbas sa lugar.
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Sa pagbalik sa usa ka bag-o nga uppercased bili nga walay pag-usab sa kasamtangan nga usa ka, sa paggamit sa [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Gikabig kini nga tipo sa ASCII nga mas ubos nga kaso nga katumbas sa lugar.
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mabalik ang us aka bag-ong gibug-aton nga kantidad nga dili pagbag-o ang naa na, gamita ang [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Checks kon ang bili mao ang usa ka ASCII alpabetikong kinaiya:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Susihon kung ang kantidad us aka ASCII nga dagkung karakter:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Checks kon ang bili mao ang usa ka ASCII lowercase kinaiya:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Checks kon ang bili mao ang usa ka ASCII letra-numero nga kinaiya:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', o
    /// - U + 0061 'a' ..=U + 007A 'z', o
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Susihon kung ang kantidad us aka ASCII decimal digit:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Susihon kung ang kantidad usa ka ASCII hexadecimal digit:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', o
    /// - U + 0041 'A' ..=U + 0046 'F', o
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Checks kon ang bili mao ang usa ka ASCII punctuation kinaiya:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, o
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, o
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Checks kon ang bili mao ang usa ka ASCII graphic kinaiya:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Checks kon ang bili mao ang usa ka ASCII whitespace kinaiya:
    /// U + 0020 LUNA, U + 0009 pinahigda TAB, U + 000A PAGTULUN sa bahog, U + 000C FORM sa bahog, o U + 000D carro MOBALIK.
    ///
    /// Rust naggamit sa WhatWG infra Standard ni [definition of ASCII whitespace][infra-aw].Daghang uban pang mga kahulugan nga gigamit sa kadaghanan.
    /// Pananglitan, [the POSIX locale][pct] naglakip sa U + 000B bertikal TAB ingon man sa tanang mga karakter sa ibabaw, apan-gikan sa sama nga specification-[sa default nga pagmando alang sa "field splitting" sa Bourne shell][bfs] giisip *lamang* LUNA, pinahigda TAB, ug NAGPAKAON sa LINE ingon puti.
    ///
    ///
    /// Kon ikaw pagsulat sa usa ka programa nga pagproseso sa usa ka kasamtangan nga format file, check kon unsa ang kahulugan nga ang format sa whitespace anaa sa atubangan sa paggamit niini nga function.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Checks kon ang bili mao ang usa ka ASCII pagkontrol sa kinaiya:
    /// U + 0000 NUL ..=U + 001F UNIT separator, o U + 007F panas.
    /// Hinumdomi nga ang kadaghanan sa mga karakter sa whitespace sa puti mao ang mga karakter sa pagkontrol, apan ang SPACE dili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Gi-encode ang usa ka hilaw nga kantidad nga u32 ingon UTF-8 sa gihatag nga byte buffer, ug pagkahuman ibalik ang subslice sa buffer nga adunay sulud nga na-encode nga karakter.
///
///
/// Dili sama sa `char::encode_utf8`, kini nga pamaagi nagdumala usab sa mga codepoint sa sulud nga sulud.
/// (Paghimo sa usa ka `char` sa puli nga range mao ang UB.) Ang resulta mao ang balido [generalized UTF-8] apan dili balido UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics kon ang buffer dili dako nga igo.
/// Ang usa ka buffer nga gitas-on sa upat igoigo ang igo aron ma-encode ang bisan unsang `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// - Encode sa usa ka hilaw u32 bili sama sa UTF-16 ngadto sa gihatag `u16` buffer, ug unya mobalik sa subslice sa buffer nga naglangkob sa simbolikong kinaiya.
///
///
/// Dili sama sa `char::encode_utf16`, kini nga pamaagi usab handol codepoints sa puli nga range.
/// (Ang paghimo sa usa ka `char` sa sulud nga sulud mao ang UB.)
///
/// # Panics
///
/// Panics kon ang buffer dili dako nga igo.
/// Usa ka buffer sa gitas-on sa 2 mao ang dako nga igo sa encode sa bisan unsa nga `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // KALUWASAN: ang matag braso nagsusi kung adunay igo nga mga tipik aron sulatan
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Nahulog ang BMP
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ang mga suplemento nga ayroplano nagbungkag sa mga puli.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}