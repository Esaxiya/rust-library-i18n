//! Pagsuporta sa Panic sa standard nga librarya.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Usa ka istruktura nga naghatag kasayuran bahin sa usa ka panic.
///
/// `PanicInfo` gambalay ang milabay sa usa ka panic hook set sa function [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Gibalik ang bayad nga kauban sa panic.
    ///
    /// Kini kasagarang, apan dili kanunay, usa ka `&'static str` o [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Kung ang `panic!` macro gikan sa `core` crate (dili gikan sa `std`) gigamit uban ang usa ka formatting string ug pipila nga dugang nga mga argumento, ibalik kana nga mensahe nga andam gamiton pananglitan sa [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Nagbalik impormasyon bahin sa lokasyon diin gikan ang panic, kung magamit.
    ///
    /// Kini nga pamaagi kanunay nga ibalik ang [`Some`], apan mahimo`g mabag-o kini nga mga bersyon sa future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Kung kini gibag-o aron usahay mobalik Wala,
        // pakigsabot sa kana nga kaso sa std::panicking::default_hook ug std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: dili namon magamit ang downcast_ref: :<String>() Dinhi
        // tungod kay ang String dili magamit sa libcore!
        // Ang payload usa ka String kung ang `std::panic!` gitawag nga adunay daghang mga argumento, apan sa kana nga kaso magamit usab ang mensahe.
        //

        self.location.fmt(formatter)
    }
}

/// Usa ka istraktura nga adunay kasayuran bahin sa lokasyon sa usa ka panic.
///
/// Ang kini nga istraktura gimugna sa [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ang mga pagtandi alang sa pagkaparehas ug paghan-ay gihimo sa file, linya, unya ang prayoridad sa kolum.
/// Ang mga file gitandi ingon mga lubid, dili `Path`, nga mahimo`g wala damha.
/// Kitaa ang mga dokumentasyon [[Lokasyon: : file`] alang sa dugang nga paghisgot.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Gibalik ang lokasyon sa gigikanan sa nanawag sa kini nga kalihokan.
    /// Kung ang nagtawag sa function nga adunay anotasyon pagkahuman ang lokasyon sa tawag niini ibalik, ug uban pa hangtod sa stack sa una nga tawag sa sulud sa usa ka wala gisubay nga lawas sa pag-andar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Mibalik ang [`Location`] sa nga kini gitawag.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Nagbalik usa ka [`Location`] gikan sa sulud sa kahulugan sa kini nga function.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // Ang pagpadagan sa parehas nga wala masubay nga pag-andar sa usa ka lainlaing lokasyon naghatag kanamo sa parehas nga sangputanan
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // Ang pagpadagan sa gisubay nga gimbuhaton sa usa ka lahi nga lokasyon naghimo usa ka lainlaing kantidad
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Gibalik ang ngalan sa gigikanan nga file diin gikan ang panic.
    ///
    /// # `&str`, dili `&Path`
    ///
    /// Ang mibalik nga ngalan nagtumong sa usa ka tinubdan nga dalan sa paghipos sistema, apan kini mao ang dili balido sa pagrepresentar kini direkta ingon sa usa ka `&Path`.
    /// Ang nahipos nga code mahimong modagan sa usa ka lainlaing sistema nga adunay lainlaing pagpatuman sa `Path` kaysa sa sistema nga naghatag sa mga sulud ug kini nga librarya wala karon usa ka lainlaing lahi nga "host path".
    ///
    /// Ang labing makapatingala nga kinaiya mahitabo sa diha nga "the same" file mao ang makab-ot pinaagi sa daghang mga alagianan diha sa module nga sistema (sa kasagaran sa paggamit sa `#[path = "..."]` hiyas o susama), nga hinungdan sa unsa ang makita nga mahimong susama code sa pagbalik nagkalainlaing mga hiyas gikan niini nga function.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Ang kini nga kantidad dili angay alang sa pagpasa sa `Path::new` o susama nga mga konstruktor kung magkalainlain ang host platform ug target platform.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Gibalik ang numero sa linya kung diin gikan ang panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Gibalik ang haligi diin gikan ang panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Usa ka sulud nga trait nga gigamit sa libstd aron mapasa ang datos gikan sa libstd ngadto sa `panic_unwind` ug uban pa nga mga runtime sa panic.
/// Dili gituyo nga ma-stabilize bisan unsang orasa sa dili madugay, ayaw paggamit.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Kuhaa ang hingpit nga pagpanag-iya sa mga sulud.
    /// Ang tipo sa pagbalik sa tinuud `Box<dyn Any + Send>`, apan dili namon magamit ang `Box` sa libcore.
    ///
    /// Human niini nga pamaagi na gitawag, lamang sa pipila ka mga dummy default bili mahibilin sa `self`.
    /// Sa pagtawag niini nga pamaagi sa makaduha, o pagtawag `get` human sa pagtawag niini nga pamaagi, mao ang usa ka sayop.
    ///
    /// argumento ang hinulaman tungod kay ang panic Runtime (`__rust_start_panic`) lamang sa usa ka gets hinulaman `dyn BoxMeUp`.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Manghulam ra sa sulud.
    fn get(&mut self) -> &(dyn Any + Send);
}