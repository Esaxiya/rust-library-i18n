//! Mga lahi sa atomo
//!
//! Atomic matang sa paghatag og karaang mipakigbahin-panumdoman komunikasyon tali sa mga hilo, ug ang mga building blocks sa ubang dungan matang.
//!
//! Gihubit sa kini nga modyul ang mga bersyon sa atomo sa usa ka pinili nga ihap sa mga primitive type, lakip ang [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ug uban pa.
//! Atomic matang karon operasyon nga, sa diha nga gigamit sa husto nga paagi, kalihukan updates sa taliwala sa hilo.
//!
//! Ang matag pamaagi nagkinahanglan usa ka [`Ordering`] nga nagrepresentar sa kusog sa memory babag alang sa kana nga operasyon.Kini nga mga orderings mao ang mga sama sa [C++20 atomic orderings][1].Alang sa dugang nga kasayuran tan-awa ang [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Ang mga variable sa atomic luwas nga ipanghatag taliwala sa mga sulud (gipatuman nila ang [`Sync`]) apan wala nila gihatag ang ilang mekanismo alang sa pagpaambit ug pagsunod sa [threading model](../../../std/thread/index.html#the-threading-model) sa Rust.
//!
//! Ang labing komon nga paagi sa pagpakigbahin sa usa ka atomic baryable mao ang gibutang kini ngadto sa usa ka [`Arc`][arc] (usa ka atomically-reference-giisip mipakigbahin pointer).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomic matang mahimong gitipigan diha sa nagahunong baryable, initialized sa paggamit sa kanunay initializers sama [`AtomicBool::new`].Ang mga atomic statics kanunay gigamit alang sa tapulan nga globalisasyon.
//!
//! # Portability
//!
//! Ang tanan nga atomic matang sa module niini garantiya nga mahimong [lock-free] kon sila anaa.Kini nagpasabot nga sila dili internal pagbaton sa usa ka global nga mutex.Ang mga tipo ug operasyon sa atomiko dili garantiya nga wala`y paghulat.
//! Kini nagpasabut nga ang mga operasyon sama sa `fetch_or` mahimong ipatuman sa us aka kumpare nga pagbag-o.
//!
//! Atomic operasyon mahimo nga ipatuman sa pahamatngon layer uban sa mas dako nga gidak-on nga atomics.Pananglitan ang pipila nga mga platform naggamit 4-byte atomic nga mga panudlo aron ipatuman ang `AtomicI8`.
//! Hinumdomi nga ang kini nga pagsundog dili kinahanglan adunay epekto sa pagkahusto sa code, kini usa ra ka butang nga kinahanglan mahibal-an.
//!
//! Ang mga tipo sa atomiko sa kini nga modyul mahimong dili magamit sa tanan nga mga platform.Ang atomic matang dinhi tanan mga kaylap nga anaa, bisan pa niana, ug mahimo sa kinatibuk-nga nagsalig sa kasamtangan nga.Ang ubang mga taw-taw nga eksepsiyon mao ang:
//!
//! * PowerPC ug MIPS plataporma sa 32-gamay pointers dili `AtomicU64` o `AtomicI64` matang.
//! * ARM ang mga platform sama sa `armv5te` nga dili alang sa Linux nagahatag ra sa mga operasyon nga `load` ug `store`, ug ayaw suportahi ang operasyon sa Compare and Swap (CAS), sama sa `swap`, `fetch_add`, ubp.
//! Dugang pa sa Linux, kini nga mga CAS operasyon gipatuman pinaagi sa [operating system support], nga moabut uban sa usa ka silot performance.
//! * ARM ang mga target nga adunay `thumbv6m` naghatag ra sa `load` ug `store` nga operasyon, ug dili suportahan ang operasyon sa Compare ug Swap (CAS), sama sa `swap`, `fetch_add`, ubp.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Hinumdomi nga ang mga platform sa future mahimong madugang nga wala usab suporta alang sa pipila nga mga operasyon sa atomic.Maximally portable code gusto magbantay bahin sa unsang mga lahi sa atomic ang gigamit.
//! `AtomicUsize` ug ang `AtomicIsize` sa kinatibuk-an mao ang labi ka madaladala, bisan kung wala kini magamit bisan diin.
//! Alang sa pakisayran, ang `std` librarya nagkinahanglan og mga pointer nga kadako sa pointer, bisan kung dili ang `core`.
//!
//! Karon inyong kinahanglan sa paggamit sa `#[cfg(target_arch)]` sa panguna sa kondisyon pagtipon sa code sa mga atomics.Adunay usa ka dili malig-on nga `#[cfg(target_has_atomic)]` usab nga mahimong mapalig-on sa future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Usa ka yano nga spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Paghulat sa uban nga mga hilo sa pagbuhi sa pungpong sa buhok
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Pagpadayon sa usa ka pangkalibutang nga ihap sa mga live thread:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Usa ka tipo sa boolean nga mahimo nga luwas nga mapaambitan taliwala sa mga sulud.
///
/// matang Kini nga sama nga representasyon sa-handumanan nga ingon sa usa ka [`bool`].
///
/// **Mubo nga sulat**: matang Kini mao lamang ang anaa sa ibabaw sa plataporma nga sa pagsuporta sa atomic luwan ug mga dapa sa mga `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Naghimo usa ka `AtomicBool` nga gisugdan sa `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Ang pagpadala implicit nga gipatuman alang sa AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Usa ka hilaw nga tipo sa pagpatudlo nga mahimong luwas nga maibut sa taliwala sa mga sulud.
///
/// matang Kini nga sama nga representasyon sa-handumanan nga ingon sa usa ka `*mut T`.
///
/// **Hinumdomi**: Magamit lang kini nga tipo sa mga platform nga nagsuporta sa mga karga nga atomo ug mga tindahan sa mga panudlo.
/// gidak-on niini nag-agad sa gidak-on sa target pointer ni.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Nagmugna sa usa ka bili `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Mga pag-order sa memorya sa atomo
///
/// Ang mga paghan-ay sa memorya nagtino sa paagi nga ang mga operasyon sa atomiko nagsumpay sa memorya.
/// Sa iyang labing huyang [`Ordering::Relaxed`], lamang ang handumanan direkta natandog sa operasyon ang synchronized.
/// Sa laing bahin, ang usa ka tindahan-load parisan sa [`Ordering::SeqCst`] operasyon pagpahiangay sa uban nga mga handumanan samtang dugang pagpreserbar sa usa ka kinatibuk-ang han-ay sa maong mga operasyon sa tibuok sa tanan nga mga hilo.
///
///
/// ni Rust panumdoman orderings mga [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Alang sa dugang impormasyon tan-awa ang [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Wala`y mga pagpugong sa pag-order, mga operasyon ra lang sa atomic.
    ///
    /// Katugbang sa [`memory_order_relaxed`] sa C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Sa diha nga inubanan sa usa ka tindahan, sa tanan nga nagligad nga mga operasyon mahimong nagmando sa atubangan sa bisan unsang luwan sa niini nga bili uban sa [`Acquire`] (o mas lig-on) nagmando.
    ///
    /// Sa partikular, ang tanan nga nagligad nga misulat mahimong makita sa tanan nga mga hilo nga sa pagbuhat sa usa ka [`Acquire`] (o mas lig-on) luwan sa niini nga bili.
    ///
    /// Matikdi nga ang paggamit niini nga tulomanon alang sa usa ka operasyon nga kombinar luwan ug mga tindahan nangulo sa usa ka load nga operasyon [`Relaxed`]!
    ///
    /// pagsunodsunod Kini mao ang magamit lamang alang sa operasyon nga makahimo sa usa ka tindahan.
    ///
    /// Katugbang sa [`memory_order_release`] sa C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Sa diha nga inubanan sa usa ka load, kon ang puno bili gisulat sa usa ka tindahan nga operasyon uban sa [`Release`] (o mas lig-on) pagkasunodsunod, unya ang tanan nga sunod-sunod nga operasyon mahimo nga nagmando human sa tindahan nga.
    /// Sa partikular, ang tanan nga mosunud nga karga makakita sa datos nga gisulat sa wala pa ang tindahan.
    ///
    /// Matikdi nga ang paggamit niini nga tulomanon alang sa usa ka operasyon nga kombinar luwan ug mga tindahan nangulo sa usa ka operasyon [`Relaxed`] tindahan!
    ///
    /// pagsunodsunod Kini mao ang magamit lamang alang sa operasyon nga makahimo sa usa ka load.
    ///
    /// Kaangay sa [`memory_order_acquire`] sa C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Adunay mga epekto sa pareho nga [`Acquire`] ug [`Release`] nga magkahiusa:
    /// Kay luwan kini naggamit [`Acquire`] tulomanon.Alang sa mga tindahan gigamit kini ang pag-order sa [`Release`].
    ///
    /// Matikdi nga sa kaso sa `compare_and_swap`, kini mao ang posible nga sa operasyon matapos sa dili pagbuhat sa bisan unsa nga tindahan ug busa kini adunay lang [`Acquire`] tulomanon.
    ///
    /// Bisan pa, ang `AcqRel` dili gyud maghimo sa [`Relaxed`] access.
    ///
    /// Ang kini nga pag-order magamit lang alang sa mga operasyon nga managsama sa pareho nga karga ug tindahan.
    ///
    /// Kaangay sa [`memory_order_acq_rel`] sa C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Sama sa [`Acquire`]/[`Release`]/[`AcqRel`](alang sa load, tindahan, ug load-uban sa-tindahan nga operasyon, sa tinagsa) uban sa dugang nga garantiya nga ang tanan nga mga hilo makakita sa tanan nga mga sequentially makanunayon operations sa maong han-ay .
    ///
    ///
    /// Kaangay sa [`memory_order_seq_cst`] sa C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Usa ka [`AtomicBool`] initialized sa `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Naghimo usa ka bag-ong `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Mobalik sa usa ka mabalhin nga pakisayran sa nagpahiping [`bool`].
    ///
    /// Kini mao ang luwas tungod kay ang mutable pakisayran garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // KALUWASAN: ang mabalhin nga pakisayran naggarantiya sa talagsaon nga pagpanag-iya.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Get atomic access ngadto sa usa ka `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAFETY: ang mutable paghisgot garantiya talagsaon nga pagpanag-iya, ug
        // paglaray, pagtalay sa mga `bool` ug `Self` mao ang 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Gikonsumo ang atomic ug gibalik ang sulud nga kantidad.
    ///
    /// Kini mao ang luwas tungod kay agi `self` pinaagi sa bili garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Gilulanan sa usa ka bili gikan sa bool.
    ///
    /// `load` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
    /// Ang posible nga mga kantidad mao ang [`SeqCst`], [`Acquire`] ug [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kon `order` mao [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // KALUWASAN: ang bisan unsang karera sa datos mapugngan sa mga atomic intrinsics ug hilaw
        // ang gipasa nga pointer mao ang balido tungod kay nakuha namon kini gikan sa usa ka pakisayran.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Tindahan sa usa ka bili ngadto sa bool.
    ///
    /// `store` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
    /// Ang posible nga mga kantidad mao ang [`SeqCst`], [`Release`] ug [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Ang Panics kung `order` ang [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // KALUWASAN: ang bisan unsang karera sa datos mapugngan sa mga atomic intrinsics ug hilaw
        // ang gipasa nga pointer mao ang balido tungod kay nakuha namon kini gikan sa usa ka pakisayran.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Nagtipig usa ka kantidad sa bool, nga gibalik ang miaging kantidad.
    ///
    /// `swap` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Tindahan sa usa ka bili ngadto sa [`bool`] kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
    ///
    /// Ang pagbalik bili mao ang kanunay nga sa miaging bili.Kung katumbas kini sa `current`, nan ang kantidad na-update.
    ///
    /// `compare_and_swap` usab sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.
    /// Timan-i nga bisan kung naggamit [`AcqRel`], ang operasyon mahimong mapakyas ug tungod niini nagpasundayag ra nga usa ka `Acquire` nga karga, apan wala`y mga semantiko nga `Release`.
    /// Ang paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`] kung nahinabo kini, ug ang paggamit sa [`Release`] naghimo sa bahin nga nag-load nga [`Relaxed`].
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Ang paglalin sa `compare_exchange` ug `compare_exchange_weak`
    ///
    /// `compare_and_swap` mao ang katumbas sa `compare_exchange` uban sa mosunod nga mapping alang sa handumanan orderings:
    ///
    /// Orihinal |Kalampusan |Pagkapakyas
    /// -------- | ------- | -------
    /// Gipahulay |Gipahulay |Relaks Pagkuha |Batoni ang |Batoni Release |release |Relaks nga AcqRel |AcqRel |Batoni SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ang gitugotan nga mapakyas spuriously bisan pa sa diha nga ang pagtandi molampos, nga nagtugot sa mga tighipos sa pagmugna mas maayo nga katilingban code sa diha nga ang itandi ug swap gigamit diha sa usa ka laang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Tindahan sa usa ka bili ngadto sa [`bool`] kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
    ///
    /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
    /// Sa kalampusan kini nga kantidad gigarantiyahan nga katumbas sa `current`.
    ///
    /// `compare_exchange` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
    /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
    /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
    ///
    /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Tindahan sa usa ka bili ngadto sa [`bool`] kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
    ///
    /// Dili sama sa [`AtomicBool::compare_exchange`], kini nga pag-andar gitugotan nga mapakyas bisan kung molampos ang pagtandi, nga mahimong moresulta sa labi ka episyente nga code sa pipila nga mga platform.
    ///
    /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
    ///
    /// `compare_exchange_weak` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
    /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
    /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
    /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Lohikal nga "and" nga adunay kantidad nga boolean.
    ///
    /// Gihimo sa usa ka makatarunganon nga "and" operasyon sa kasamtangan bili ug ang argumento `val`, ug set sa mga bag-o nga bili sa resulta.
    ///
    /// Gibalik ang miaging kantidad.
    ///
    /// `fetch_and` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Lohikal nga "nand" nga adunay kantidad nga boolean.
    ///
    /// Gihimo sa usa ka makatarunganon nga "nand" operasyon sa kasamtangan bili ug ang argumento `val`, ug set sa mga bag-o nga bili sa resulta.
    ///
    /// Gibalik ang miaging kantidad.
    ///
    /// `fetch_nand` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Dili namon magamit ang atomic_nand dinhi tungod kay mahimo kini magresulta sa usa ka bool nga adunay dili husto nga kantidad.
        // Nahitabo kini tungod kay ang operasyon sa atomiko gihimo uban ang 8-bit nga integer sa sulud, nga magtakda sa taas nga 7 bits.
        //
        // Busa kita lang sa paggamit sa fetch_xor o swap sa baylo.
        if val {
            // ! (X&tinuod nga)== !x Kita kinahanglan magtuwad sa bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==tinuod Kinahanglan naton nga itakda ang bool sa tinuod.
            //
            self.swap(true, order)
        }
    }

    /// Makataronganon "or" uban sa usa ka boolean bili.
    ///
    /// Naghimo usa ka lohikal nga operasyon nga "or" sa karon nga kantidad ug lantugi `val`, ug gitakda ang bag-ong kantidad sa sangputanan.
    ///
    /// Gibalik ang miaging kantidad.
    ///
    /// `fetch_or` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Lohikal nga "xor" nga adunay kantidad nga boolean.
    ///
    /// Gihimo sa usa ka makatarunganon nga "xor" operasyon sa kasamtangan bili ug ang argumento `val`, ug set sa mga bag-o nga bili sa resulta.
    ///
    /// Gibalik ang miaging kantidad.
    ///
    /// `fetch_xor` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Gibalik ang usa ka mabalhin nga tudlo sa nagpahiping [`bool`].
    ///
    /// Ang paghimo nga dili atomic nga pagbasa ug pagsulat sa sangputanan nga integer mahimong usa ka lahi sa datos.
    /// Ang kini nga pamaagi kadaghanan mapuslanon alang sa FFI, diin ang pirma sa pagpaandar mahimong mogamit `*mut bool` imbis nga `&AtomicBool`.
    ///
    /// Ang pagpauli sa usa ka `*mut` pointer gikan sa usa ka gipaambit nga reperensya sa kini nga atomo luwas tungod kay ang mga tipo sa atomic nagtrabaho uban ang mutability sa sulud
    /// Ang tanan nga pagbag-o sa usa ka atomic nagbag-o sa kantidad pinaagi sa usa ka gipaambit nga reperensya, ug mahimo kini nga luwas kung gigamit nila ang mga operasyon sa atomic.
    /// Ang bisan unsang paggamit sa namalik hilaw pointer nagkinahanglan sa usa ka `unsafe` block ug sa gihapon adunay sa pagtuboy sa sama nga pagdili: operasyon sa ibabaw niini kinahanglan nga atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Gikuha ang kantidad, ug gi-apply ang usa ka function niini nga nagbalik sa usa ka opsyonal nga bag-ong kantidad.Gibalik ang usa ka `Result` nga `Ok(previous_value)` kung ang pagpaandar nga gibalik `Some(_)`, kung dili ang `Err(previous_value)`.
    ///
    /// Note: Kini mahimo nga motawag sa function daghang mga panahon kon ang bili giusab gikan sa ubang mga hilo sa kasamtangan, samtang ang function mobalik `Some(_)`, apan ang function na apply sa makausa lamang sa sa mga gitipigan bili.
    ///
    ///
    /// `fetch_update` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// Ang una naghulagway sa gikinahanglan nga tulomanon alang sa diha nga ang mga operasyon sa katapusan molampos samtang ang ikaduha naghulagway sa gikinahanglan nga tulomanon alang sa mga luwan.
    /// Kini nga katugbang sa kalampusan ug kapakyasan nga paghan-ay sa [`AtomicBool::compare_exchange`] matag usa.
    ///
    /// Pinaagi sa paggamit sa [`Acquire`] ingon nga kalampusan tulomanon naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa katapusang malampuson load [`Relaxed`].
    /// Ang pag-order sa pag-load sa (failed) mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Kini nga pamaagi mao ang anaa lamang sa platform nga pagsuporta atomic operasyon sa `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Naghimo usa ka bag-ong `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Mobalik sa usa ka mutable paghisgot sa tinuod nga hinungdan sa pointer.
    ///
    /// Kini mao ang luwas tungod kay ang mutable pakisayran garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Get atomic access ngadto sa usa ka pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ang mabalhin nga pakisayran naggarantiya sa talagsaon nga pagpanag-iya.
        //  - ang paghanay sa `*mut T` ug `Self` parehas sa tanan nga mga platform nga gisuportahan sa rust, ingon gipamatud sa taas.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Gikonsumo ang atomic ug gibalik ang sulud nga kantidad.
    ///
    /// Kini mao ang luwas tungod kay agi `self` pinaagi sa bili garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Gilulanan sa usa ka bili gikan sa pointer.
    ///
    /// `load` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
    /// Ang posible nga mga kantidad mao ang [`SeqCst`], [`Acquire`] ug [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics kon `order` mao [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Nagtipig usa ka kantidad sa pointer.
    ///
    /// `store` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
    /// Ang posible nga mga kantidad mao ang [`SeqCst`], [`Release`] ug [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Ang Panics kung `order` ang [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Nagtipig usa ka kantidad sa pointer, nga gibalik ang miaging kantidad.
    ///
    /// `swap` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
    /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
    ///
    ///
    /// **Note:** Magamit ra kini nga pamaagi sa mga platform nga nagsuporta sa mga operasyon sa atomic sa mga pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Nagtipig usa ka kantidad sa pointer kung ang karon nga kantidad parehas sa kantidad nga `current`.
    ///
    /// Ang pagbalik bili mao ang kanunay nga sa miaging bili.Kung katumbas kini sa `current`, nan ang kantidad na-update.
    ///
    /// `compare_and_swap` usab sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.
    /// Timan-i nga bisan kung naggamit [`AcqRel`], ang operasyon mahimong mapakyas ug tungod niini nagpasundayag ra nga usa ka `Acquire` nga karga, apan wala`y mga semantiko nga `Release`.
    /// Ang paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`] kung nahinabo kini, ug ang paggamit sa [`Release`] naghimo sa bahin nga nag-load nga [`Relaxed`].
    ///
    /// **Note:** Magamit ra kini nga pamaagi sa mga platform nga nagsuporta sa mga operasyon sa atomic sa mga pointers.
    ///
    /// # Ang paglalin sa `compare_exchange` ug `compare_exchange_weak`
    ///
    /// `compare_and_swap` mao ang katumbas sa `compare_exchange` uban sa mosunod nga mapping alang sa handumanan orderings:
    ///
    /// Orihinal |Kalampusan |Pagkapakyas
    /// -------- | ------- | -------
    /// Gipahulay |Gipahulay |Relaks Pagkuha |Batoni ang |Batoni Release |release |Relaks nga AcqRel |AcqRel |Batoni SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ang gitugotan nga mapakyas spuriously bisan pa sa diha nga ang pagtandi molampos, nga nagtugot sa mga tighipos sa pagmugna mas maayo nga katilingban code sa diha nga ang itandi ug swap gigamit diha sa usa ka laang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Nagtipig usa ka kantidad sa pointer kung ang karon nga kantidad parehas sa kantidad nga `current`.
    ///
    /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
    /// Sa kalampusan kini nga kantidad gigarantiyahan nga katumbas sa `current`.
    ///
    /// `compare_exchange` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
    /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
    /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
    ///
    /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Magamit ra kini nga pamaagi sa mga platform nga nagsuporta sa mga operasyon sa atomic sa mga pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Nagtipig usa ka kantidad sa pointer kung ang karon nga kantidad parehas sa kantidad nga `current`.
    ///
    /// Dili sama sa [`AtomicPtr::compare_exchange`], kini nga pag-andar gitugotan nga mapakyas bisan kung molampos ang pagtandi, nga mahimong moresulta sa labi ka episyente nga code sa pipila nga mga platform.
    ///
    /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
    ///
    /// `compare_exchange_weak` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
    /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
    /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
    /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Magamit ra kini nga pamaagi sa mga platform nga nagsuporta sa mga operasyon sa atomic sa mga pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // KALUWASAN: Kini nga intrinsic dili luwas tungod kay kini naglihok sa usa ka hilaw nga pahimangno
        // apan nahibal-an namon nga sigurado nga ang pointer balido (nakuha ra namon kini gikan sa usa ka `UnsafeCell` nga adunay kami sa pakisayran) ug ang operasyon nga atomiko mismo nagtugot kanamo nga luwas nga mabalhin ang sulud nga `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Gikuha ang kantidad, ug gi-apply ang usa ka function niini nga nagbalik sa usa ka opsyonal nga bag-ong kantidad.Gibalik ang usa ka `Result` nga `Ok(previous_value)` kung ang pagpaandar nga gibalik `Some(_)`, kung dili ang `Err(previous_value)`.
    ///
    /// Note: Kini mahimo nga motawag sa function daghang mga panahon kon ang bili giusab gikan sa ubang mga hilo sa kasamtangan, samtang ang function mobalik `Some(_)`, apan ang function na apply sa makausa lamang sa sa mga gitipigan bili.
    ///
    ///
    /// `fetch_update` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
    /// Ang una naghulagway sa gikinahanglan nga tulomanon alang sa diha nga ang mga operasyon sa katapusan molampos samtang ang ikaduha naghulagway sa gikinahanglan nga tulomanon alang sa mga luwan.
    /// Kini nga katugbang sa kalampusan ug kapakyasan nga paghan-ay sa [`AtomicPtr::compare_exchange`] matag usa.
    ///
    /// Pinaagi sa paggamit sa [`Acquire`] ingon nga kalampusan tulomanon naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa katapusang malampuson load [`Relaxed`].
    /// Ang pag-order sa pag-load sa (failed) mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
    ///
    /// **Note:** Magamit ra kini nga pamaagi sa mga platform nga nagsuporta sa mga operasyon sa atomic sa mga pointers.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Gikabig ang usa ka `bool` sa usa ka `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ang kini nga macro natapos nga wala magamit sa pipila nga mga arkitektura.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Usa ka tipo sa integer nga mahimong luwas nga maibut sa taliwala sa mga sulud.
        ///
        /// Ang kini nga tipo adunay parehas nga representasyon sa panumduman sama sa nagpahiping tipo sa integer, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Alang sa dugang mahitungod sa mga kalainan tali sa atomic nga mga matang ug sa mga dili-atomic matang ingon man sa mga impormasyon mahitungod sa portability sa niini nga matang, palihog tan-awa ang [module-level documentation].
        ///
        ///
        /// **Note:** Ang kini nga klase magamit ra sa mga platform nga nagsuporta sa mga atomic load ug mga tindahan nga [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Ang usa ka atomic integer gisugdan sa `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Imbit nga gipatuman ang pagpadala.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Naghimo usa ka bag-ong atomic integer.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Mobalik sa usa ka mutable paghisgot sa tinuod nga hinungdan sa integer.
            ///
            /// Kini mao ang luwas tungod kay ang mutable pakisayran garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// himoa nga si Mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (pila_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ang mabalhin nga pakisayran naggarantiya sa talagsaon nga pagpanag-iya.
                //  - ang paglinya sa `$int_type` ug `Self` parehas, sama sa gisaad sa $cfg_align ug gipamatud sa taas.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Gikonsumo ang atomic ug gibalik ang sulud nga kantidad.
            ///
            /// Kini mao ang luwas tungod kay agi `self` pinaagi sa bili garantiya nga walay laing mga hilo nga dungan-access sa atomic data.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Gilulanan sa usa ka bili gikan sa atomic integer.
            ///
            /// `load` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
            /// Ang posible nga mga kantidad mao ang [`SeqCst`], [`Acquire`] ug [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics kon `order` mao [`Release`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Tindahan sa usa ka bili ngadto sa atomic integer.
            ///
            /// `store` nagkinahanglan usa ka argumento nga [`Ordering`] nga naglarawan sa pag-order sa memorya sa kini nga operasyon.
            ///  Ang posible nga mga kantidad mao ang [`SeqCst`], [`Release`] ug [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Ang Panics kung `order` ang [`Acquire`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Tindahan sa usa ka bili ngadto sa atomic integer, pagbalik sa miaging bili.
            ///
            /// `swap` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Tindahan sa usa ka bili ngadto sa atomika integer kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
            ///
            /// Ang pagbalik bili mao ang kanunay nga sa miaging bili.Kung katumbas kini sa `current`, nan ang kantidad na-update.
            ///
            /// `compare_and_swap` usab sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.
            /// Timan-i nga bisan kung naggamit [`AcqRel`], ang operasyon mahimong mapakyas ug tungod niini nagpasundayag ra nga usa ka `Acquire` nga karga, apan wala`y mga semantiko nga `Release`.
            ///
            /// Ang paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`] kung nahinabo kini, ug ang paggamit sa [`Release`] naghimo sa bahin nga nag-load nga [`Relaxed`].
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Ang paglalin sa `compare_exchange` ug `compare_exchange_weak`
            ///
            /// `compare_and_swap` mao ang katumbas sa `compare_exchange` uban sa mosunod nga mapping alang sa handumanan orderings:
            ///
            /// Orihinal |Kalampusan |Pagkapakyas
            /// -------- | ------- | -------
            /// Gipahulay |Gipahulay |Relaks Pagkuha |Batoni ang |Batoni Release |release |Relaks nga AcqRel |AcqRel |Batoni SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ang gitugotan nga mapakyas spuriously bisan pa sa diha nga ang pagtandi molampos, nga nagtugot sa mga tighipos sa pagmugna mas maayo nga katilingban code sa diha nga ang itandi ug swap gigamit diha sa usa ka laang.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Tindahan sa usa ka bili ngadto sa atomika integer kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
            ///
            /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
            /// Sa kalampusan kini nga kantidad gigarantiyahan nga katumbas sa `current`.
            ///
            /// `compare_exchange` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
            /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
            /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
            /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
            ///
            /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Tindahan sa usa ka bili ngadto sa atomika integer kon ang kasamtangang bili mao ang sama nga ingon nga ang mga bili `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// Kini nga pag-andar gitugotan nga mapakyas nga mapakyas bisan kung nagmalampuson ang pagtandi, nga mahimong moresulta sa labi ka episyente nga code sa pipila nga mga platform.
            /// Ang pagbalik nga kantidad usa ka sangputanan nga gipakita kung ang bag-ong kantidad gisulat ug sulud sa naunang kantidad.
            ///
            /// `compare_exchange_weak` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
            /// `success` naghulagway sa gikinahanglan nga tulomanon alang sa mabasa-balhin, lainon-isulat operasyon nga mahitabo kon ang pagtandi sa `current` molampos.
            /// `failure` naglaraw sa kinahanglan nga pag-order alang sa operasyon sa pag-load nga nahinabo kung napakyas ang pagtandi.
            /// Ang paggamit sa [`Acquire`] ingon ang pag-order sa kalampusan naghimo sa tindahan nga bahin sa kini nga operasyon nga [`Relaxed`], ug ang paggamit sa [`Release`] naghimo sa malampuson nga [`Relaxed`].
            ///
            /// Ang pagkahan-ay sa pagkapakyas mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// himoa nga mut daan= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     ipares sa val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Midugang sa sa kasamtangan nga bili, pagbalik sa miaging bili.
            ///
            /// Ang kini nga operasyon nagputos sa paglibut.
            ///
            /// `fetch_add` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Mga subract gikan sa karon nga kantidad, nga gibalik ang naunang kantidad.
            ///
            /// Ang kini nga operasyon nagputos sa paglibut.
            ///
            /// `fetch_sub` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" uban sa kasamtangan nga bili.
            ///
            /// Naghimo usa ka gamay nga operasyon nga "and" sa karon nga kantidad ug lantugi `val`, ug gitakda ang bag-ong kantidad sa sangputanan.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_and` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" uban sa kasamtangan nga bili.
            ///
            /// Naghimo usa ka gamay nga operasyon nga "nand" sa karon nga kantidad ug lantugi `val`, ug gitakda ang bag-ong kantidad sa sangputanan.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_nand` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" uban sa kasamtangan nga bili.
            ///
            /// Naghimo usa ka gamay nga operasyon nga "or" sa karon nga kantidad ug lantugi `val`, ug gitakda ang bag-ong kantidad sa sangputanan.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_or` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" nga adunay karon nga kantidad.
            ///
            /// Naghimo usa ka gamay nga operasyon nga "xor" sa karon nga kantidad ug lantugi `val`, ug gitakda ang bag-ong kantidad sa sangputanan.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_xor` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Gikuha ang kantidad, ug gi-apply ang usa ka function niini nga nagbalik sa usa ka opsyonal nga bag-ong kantidad.Gibalik ang usa ka `Result` nga `Ok(previous_value)` kung ang pagpaandar nga gibalik `Some(_)`, kung dili ang `Err(previous_value)`.
            ///
            /// Note: Kini mahimo nga motawag sa function daghang mga panahon kon ang bili giusab gikan sa ubang mga hilo sa kasamtangan, samtang ang function mobalik `Some(_)`, apan ang function na apply sa makausa lamang sa sa mga gitipigan bili.
            ///
            ///
            /// `fetch_update` nagkinahanglan sa duha ka [`Ordering`] argumento sa paghulagway sa handumanan pagsunodsunod operasyon niini.
            /// Gihubit sa nahauna ang kinahanglan nga pag-order kung kanus-a molampos ang operasyon samtang ang ikaduha naghulagway sa gikinahanglan nga pag-order alang sa mga karga.Kini nga katugbang sa kalampusan ug kapakyasan nga paghan-ay sa
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Pinaagi sa paggamit sa [`Acquire`] ingon nga kalampusan tulomanon naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa katapusang malampuson load [`Relaxed`].
            /// Ang pag-order sa pag-load sa (failed) mahimo ra nga [`SeqCst`], [`Acquire`] o [`Relaxed`] ug kinahanglan katumbas o labi ka mahuyang kaysa sa kalampusan sa pag-order.
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Pag-order: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Pag-order: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum nga adunay karon nga kantidad.
            ///
            /// Makita ang maximum sa karon nga kantidad ug ang argumento `val`, ug gitakda ang bag-ong kantidad sa resulta.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_max` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// himoa nga bar=42;
            /// tugoti max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// ! Ihingusog (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum nga adunay karon nga kantidad.
            ///
            /// Nakapangita ang minimum sa karon nga kantidad ug ang argumento `val`, ug gitakda ang bag-ong kantidad sa resulta.
            ///
            /// Gibalik ang miaging kantidad.
            ///
            /// `fetch_min` nagkinahanglan sa usa ka [`Ordering`] argumento nga naghulagway sa handumanan pagsunodsunod operasyon niini.Posible ang tanan nga mga mode sa pag-order.
            /// Matikdi nga sa paggamit sa [`Acquire`] naghimo sa tindahan nga bahin sa niini nga operasyon [`Relaxed`], ug sa paggamit sa [`Release`] naghimo sa load nga bahin [`Relaxed`].
            ///
            ///
            /// **Hinumdomi**: Ang kini nga pamaagi magamit ra sa mga platform nga nagsuporta sa mga operasyon nga atomiko
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// himoa nga bar=12;
            /// pasagdi ang min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: lumba data nga gibabagan sa atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Mipauli ang usa ka mabalhin nga tudlo sa nagpahiping integer.
            ///
            /// Ang paghimo nga dili atomic nga pagbasa ug pagsulat sa sangputanan nga integer mahimong usa ka lahi sa datos.
            /// Kini nga pamaagi mao ang kasagaran mapuslanon alang sa FFI, diin ang function pirma mahimong mogamit
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ang pagpauli sa usa ka `*mut` pointer gikan sa usa ka gipaambit nga reperensya sa kini nga atomo luwas tungod kay ang mga tipo sa atomic nagtrabaho uban ang mutability sa sulud
            /// Ang tanan nga pagbag-o sa usa ka atomic nagbag-o sa kantidad pinaagi sa usa ka gipaambit nga reperensya, ug mahimo kini nga luwas kung gigamit nila ang mga operasyon sa atomic.
            /// Ang bisan unsang paggamit sa namalik hilaw pointer nagkinahanglan sa usa ka `unsafe` block ug sa gihapon adunay sa pagtuboy sa sama nga pagdili: operasyon sa ibabaw niini kinahanglan nga atomic.
            ///
            ///
            /// # Examples
            ///
            /// `` `Ibaliwala (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SAFETY: Luwas samtang nga `my_atomic_op` mao atomic.
            /// dili luwas {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Mibalik sa miaging bili (sama sa __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Mibalik sa miaging bili (sama sa __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ibalik ang max nga kantidad (gipirmahan nga pagtandi)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ibalik ang kantidad nga min (gipirmahan nga pagtandi)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// mobalik ang max bili (Unsigned pagtandi)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// mobalik ang min bili (Unsigned pagtandi)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Usa ka atomic koral.
///
/// Naa sa gitakda nga pagkahan-ay, usa ka koral ang nagpugong sa tagtipig ug CPU gikan sa pag-usab sa pila ka mga klase nga operasyon sa memorya sa palibot niini.
/// Naghimo kana nga mga pagsabay-uban nga mga relasyon tali niini ug mga operasyon sa atomiko o mga koral sa ubang mga sulud.
///
/// Ang usa ka koral 'A' nga adunay (labing menos) [`Release`] nga nagmando sa mga semantiko, naghiusa sa usa ka koral nga 'B' nga adunay (labing menos) [`Acquire`] nga mga semantiko, kung ug kung adunay mga operasyon nga X ug Y, parehas nga naglihok sa pipila nga atomic nga butang nga 'M' nga ingon ang A nagsunod-sunod. X, Y ang synchronized sa atubangan sa B ug ako nag-sa kausaban sa M.
/// Naghatag kini usa ka pagkahitabo sa wala pa ang pagsalig tali sa A ug B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Ang mga operasyon sa atomiko nga adunay [`Release`] o [`Acquire`] semantics mahimo usab nga magkasabay sa usa ka koral.
///
/// Ang usa ka koral nga may [`SeqCst`] pagkasunodsunod, dugang pa sa nga may duha [`Acquire`] ug [`Release`] semantiko, partisipante sa global nga programa aron sa ubang mga operasyon ug/o mga koral [`SeqCst`].
///
/// Gidawat ang pag-order sa [`Acquire`], [`Release`], [`AcqRel`] ug [`SeqCst`].
///
/// # Panics
///
/// Panics kung `order` ang [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Usa ka usag mahilayo karaang base sa spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Paghulat hangtod ang daan nga kantidad mao ang `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // koral Kini nga synchronizes-uban sa tindahan sa `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SAFETY: paggamit sa usa ka atomic nga koral mao ang luwas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Usa ka tighipos sa panumduman koral.
///
/// `compiler_fence` wala magpagawas bisan unsang code sa makina, apan gidili ang mga klase sa memorya nga pag-usab nga gisugo ang maghimo.Sa piho nga, depende sa gihatag [`Ordering`] semantiko, ang tighipos mahimo nga gisalikway gikan sa makapatandog nga mabasa o misulat gikan sa atubangan sa o human sa tawag ngadto sa pikas nga daplin sa tawag sa `compiler_fence`.Mubo nga sulat nga kini **dili** pagpugong sa mga * hardware gikan sa pagbuhat sa maong re-nagmando.
///
/// Dili kini problema sa us aka sulud nga konteksto sa pagpatuman, apan kung ang uban pang mga sulud mahimong mag-usab sa memorya sa parehas nga oras, kinahanglan ang labi ka kusgan nga mga primitibo sa pag-synchronize sama sa [`fence`].
///
/// Ang re-nagmando napugngan sa lain-laing mga tulomanon semantiko mao ang:
///
///  - sa [`SeqCst`], wala gitugotan ang pag-usab sa pagbasa ug pagsulat sa tibuuk nga punto.
///  - uban sa [`Release`], nga nag-una mabasa ug misulat dili matarug nangagi sunod-sunod nga misulat.
///  - uban ang [`Acquire`], ang mga sunud nga pagbasa ug pagsulat dili mabalhin sa una nga mga una nga pagbasa.
///  - nga adunay [`AcqRel`], pareho sa gipatuman nga mga patakaran ang gipatuman.
///
/// `compiler_fence` mao ang kinatibuk lamang mapuslanon alang sa pagpugong sa usa ka lugas nga hilo gikan sa paspas uban sa iyang kaugalingon. *Nga mao, kon ang usa ka gihatag nga hilo nagpahamtang sa usa ka piraso sa code, ug unya ang nabalda, ug magsugod pagtuman sa code sa ubang dapit (samtang pa sa sa mao gihapon nga hilo, ug conceptually pa sa sa mao gihapon nga kinauyokan).Sa tradisyonal nga mga programa, kini mahimo lamang sa mahitabo sa diha nga ang usa ka signal handler ang narehistro.
/// Sa dugang nga ubos-level code, ingon nga mga kahimtang mahimo usab nga motungha sa diha nga pagdumala sa polling, sa diha nga pagpatuman sa lunhaw nga hilo uban sa pre-emption, ug uban pa
/// Giawhag ang mga interesado nga magbasa nga basahon ang diskusyon sa Linux kernel bahin sa [memory barriers].
///
/// # Panics
///
/// Panics kung `order` ang [`Relaxed`].
///
/// # Examples
///
/// Kung wala ang `compiler_fence`, ang `assert_eq!` sa pagsunod sa code dili *dili* gigarantiyahan nga magmalampuson, bisan pa sa tanan nga nahinabo sa usa ka sulud.
/// Sa pagtan-aw kon ngano, hinumdumi nga ang tighipos mao ang gawasnon sa nagbalhin, nagbaylo sa mga tindahan sa `IMPORTANT_VARIABLE` ug `IS_READ` sukad sila duha `Ordering::Relaxed`.Kung nahimo kini, ug ang handler sa signal gisangpit dayon pagkahuman nga gi-update ang `IS_READY`, kung ingon ang signal handler makakita sa `IS_READY=1`, apan `IMPORTANT_VARIABLE=0`.
/// Pinaagi sa paggamit sa usa ka `compiler_fence` tambal niini nga sitwasyon.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // pugngan ang mga naunang pagsulat gikan sa pagbalhin lapas niini nga punto
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SAFETY: paggamit sa usa ka atomic nga koral mao ang luwas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signal ang processor nga kini mao ang sa sulod sa usa ka busy-atang nanagkalinyas-loop ("nanagkalinyas Lock").
///
/// Ang kini nga pag-andar dili na gusto sa [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}