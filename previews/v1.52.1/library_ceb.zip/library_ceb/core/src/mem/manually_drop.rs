use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Usa ka pambalot aron mapugngan ang tagtipon gikan sa awtomatikong pagtawag sa `T`'s destructor.
/// Kini nga tagputos 0-gasto.
///
/// `ManuallyDrop<T>` mao ang ulipon ngadto sa mao gihapon nga optimizations layout ingon `T`.
/// Ingon usa ka sangputanan, wala kini *epekto* sa mga pangagpas nga gihimo sa tagtipon bahin sa mga sulud niini.
/// Pananglitan, ang pagsugod sa usa ka `ManuallyDrop<&mut T>` nga adunay [`mem::zeroed`] dili matino nga pamatasan.
/// Kon imong gikinahanglan aron sa pagdumala sa uninitialized data, sa paggamit sa [`MaybeUninit<T>`] sa baylo.
///
/// Timan-i nga access sa mga bili sa sulod sa usa ka `ManuallyDrop<T>` mao ang luwas.
/// Kini nagpasabot nga ang usa ka `ManuallyDrop<T>` kansang sulud nga gihulog dili kinahanglan ibutyag pinaagi sa usa ka luwas nga publiko nga API.
/// Sa katugbang, ang `ManuallyDrop::drop` dili luwas.
///
/// # `ManuallyDrop` ug ihulog order.
///
/// Ang Rust adunay maayong pagkasabut nga [drop order] nga mga kantidad.
/// Aron maseguro nga mga uma o mga lokal nga naghulog sa sa usa ka piho nga order, reorder ang mga deklarasyon sa ingon nga sa bug-os nga drop order mao ang husto nga usa ka.
///
/// Posible nga gamiton ang `ManuallyDrop` aron makontrol ang pagkahulog nga pagkahan-ay, apan kini nanginahanglan dili luwas nga code ug lisud nga buhaton og tama sa wala`y pahulay.
///
///
/// Pananglitan, kon kamo gusto nga maseguro nga ang usa ka piho nga uma ang naghulog human sa uban, sa paghimo niini sa katapusan nga kapatagan sa usa ka magtukod:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` mahulog pagkahuman sa `children`.
///     // Rust garantiya nga kaumahan naghulog sa sa kapunongan sa deklarasyon.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Pagputos sa usa ka kantidad aron mahimong ihulog sa kamut.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Ikaw mahimo sa gihapon luwas nga-operate sa bili
    /// assert_eq!(*x, "Hello");
    /// // Apan ang `Drop` dili madagan dinhi
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Nagmina sa bili gikan sa `ManuallyDrop` sudlanan.
    ///
    /// Gitugotan niini nga mahulog usab ang kantidad.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Gihulog niini ang `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Nagkinahanglan sa bili gikan sa `ManuallyDrop<T>` sudlanan sa gawas.
    ///
    /// Kini nga pamaagi mao ang una sa gituyo alang sa pagbalhin sa mga prinsipyo sa drop.
    /// Inay sa paggamit sa [`ManuallyDrop::drop`] sa kamut drop sa bili, kamo makahimo sa paggamit niini nga paagi sa pagkuha sa bili ug sa paggamit niini bisan pa niana gitinguha.
    ///
    /// Bisan kanus-a mahimo, labi nga labi nga gamiton ang [`into_inner`][`ManuallyDrop::into_inner`] hinoon, nga makababag sa pagdoble sa sulud sa `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// function Kini nga semantically nagalihok sa anaa bili nga walay pagpugong sa dugang nga paggamit, sa pagbiya sa kahimtang sa sudlanan niini nga mausab.
    /// Kini mao ang imong responsibilidad sa pagsiguro nga kini nga `ManuallyDrop` wala gigamit pag-usab.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAFETY: kita sa pagbasa gikan sa usa ka pakisayran, nga mao ang garantiya
        // nga mahimong balido alang sa mabasa.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Kinamut nga gihulog ang sulud nga sulud.Kini mao gayud nga katumbas sa pagtawag [`ptr::drop_in_place`] uban sa usa ka pointer sa anaa bili.
    /// Sa ingon, gawas kon ang anaa bili mao ang usa ka packed magtukod, ang destructor pagatawgon sa-dapit nga walay pagbalhin sa bili, ug sa ingon mahimong gigamit sa luwas nga drop [pinned] data.
    ///
    /// Kon kamo adunay iya sa bili, kamo makahimo sa paggamit [`ManuallyDrop::into_inner`] sa baylo.
    ///
    /// # Safety
    ///
    /// function Kini nga midagan sa destructor sa anaa bili.
    /// Sa uban nga kay mga kausaban nga gihimo sa destructor sa iyang kaugalingon, ang handumanan nga nahibilin mausab, ug sa ingon ngadto sa tighipos ang hisgutan pa naghupot sa usa ka gamay-sumbanan nga mao ang balido alang sa matang `T`.
    ///
    ///
    /// Bisan pa, ang kantidad nga "zombie" dili kinahanglan ibutyag sa luwas nga code, ug kini nga pag-andar dili dapat tawgon labaw pa sa kausa.
    /// Sa paggamit sa usa ka bili human kini na mingtolo, o drop sa usa ka bili daghang mga panahon, hinungdan dili tino ang Pamatasan (depende sa unsa ang `drop`).
    /// Kini kasagaran napugngan sa matang nga sistema, apan tiggamit sa `ManuallyDrop` kinahanglan sakdagon ang mga garantiya nga walay tabang gikan sa tighipos.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SAFETY: kita pagtulo sa bili nagpunting sa pinaagi sa usa ka mutable pakisayran
        // nga gigarantiyahan nga mahimong balido alang sa mga pagsulat.
        // Kini mao ang ngadto sa mga caller aron sa pagsiguro nga `slot` dili nagpatulo pag-usab.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}