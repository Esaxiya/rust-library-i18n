use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Usa ka matang wrapper sa pagtukod uninitialized higayon sa `T`.
///
/// # Initialization makanunayon
///
/// tighipos, sa kinatibuk-an, nga nangagpas nga ang usa ka baryable ang husto nga paagi initialized sumala sa mga gikinahanglan sa matang sa baryable ni.Pananglitan, ang usa ka baryable sa matang paghisgot kinahanglan ilaray ug non-bili.
/// Kini mao ang usa ka makanunayon nga kinahanglan *kanunay* nga gituboy, bisan sa dili luwas code.
/// Ingon sa usa ka sangputanan, zero-initializing sa usa ka baryable sa matang pakisayran hinungdan dayon [undefined behavior][ub], bisan kon ang paghisgot sa walay katapusan gets gigamit sa access sa panumduman:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // dili tino ang kinaiya!⚠️
/// // Ang katumbas code uban sa `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // dili tino ang kinaiya!⚠️
/// ```
///
/// Kini gipahimuslan sa tighipos sa mga nagkalain-laing optimizations, sama sa eliding run-panahon tseke ug usbaw sa `enum` layout.
///
/// Sa susama, sa bug-os uninitialized handumanan mahimong adunay bisan unsa nga sulod, samtang ang usa ka `bool` kinahanglan kanunay nga `true` o `false`.Tungod niini, ang paghimo sa usa ka wala nahibal-an nga `bool` wala mahibal-an nga kinaiya:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // dili tino ang kinaiya!⚠️
/// // Ang katumbas nga code nga adunay `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // dili tino ang kinaiya!⚠️
/// ```
///
/// Dugang pa, uninitialized handumanan mao ang espesyal nga sa nga kini dili usa ka natudlong sa bili ("fixed" nga nagpasabot "it won't change without being written to").Ang pagbasa sa parehas nga wala maibalhin nga byte sa daghang mga higayon makahatag lainlaing mga sangputanan.
/// Kini naghimo niini nga dili tino ang kinaiya nga adunay uninitialized data sa usa ka baryable bisan kon nga baryable adunay usa ka matang integer, nga kon mahimo naghupot sa bisan unsa nga *natudlong* gamay nga sumbanan:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // dili tino ang kinaiya!⚠️
/// // Ang katumbas code uban sa `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // dili tino ang kinaiya!⚠️
/// ```
/// (Matikdi nga ang mga lagda sa palibot uninitialized integers wala finalize pa, apan hangtud nga sila, kini mao ang advisable sa paglikay kanila.)
///
/// Sa ibabaw sa nga, hinumdumi nga ang kadaghanan sa mga matang nga adunay dugang nga mga invariants sa unahan lamang nga giisip initialized sa lebel matang.
/// Pananglitan, ang usa ka `1`-initialized [`Vec<T>`] giisip initialized (ubos sa kasamtangan nga pagpatuman; kini wala naglangkob sa usa ka lig-on nga garantiya) tungod kay ang bugtong gikinahanglan sa tighipos nahibalo mahitungod niini mao nga ang data pointer kinahanglan nga non-bili.
/// Pagmugna sa maong usa ka `Vec<T>` dili hinungdan *diha-diha nga* dili tino ang kinaiya, apan hinungdan sa dili tino ang kinaiya sa labing luwas nga operasyon (lakip na ang pagtulo niini).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` nag-alagad aron luwas code pag-atubang sa uninitialized data.
/// Kini usa ka sinyales sa tagtipon nga nagpaila nga ang datos dinhi mahimong *dili* ipasugod:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Paghimo usa ka tin-aw nga wala magamit nga pakisayran.
/// // Nahibal-an sa tagtipon nga ang datos sa sulud sa usa ka `MaybeUninit<T>` mahimong dili balido, ug busa dili kini UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ibutang kini sa usa ka balido nga bili.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Kinuha ang initialized data-kini mao ang gitugotan lamang *human* sa husto nga paagi initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Nahibal-an sa tig-compiler nga dili maghimo bisan unsang sayup nga pangagpas o pag-optimize sa kini nga code.
///
/// Ikaw mahimo nga maghunahuna sa `MaybeUninit<T>` ingon nga usa ka gamay nga sama sa `Option<T>` apan walay bisan kinsa sa mga tracking run-panahon ug walay bisan kinsa sa mga tseke sa kaluwasan.
///
/// ## out-pointers
///
/// kamo makahimo sa paggamit `MaybeUninit<T>` sa pagpatuman sa "out-pointers": inay nga mobalik data gikan sa usa ka function, moagi kini nga usa ka pointer sa pipila (uninitialized) handumanan sa pagbutang sa mga resulta sa.
/// Kini mahimong mapuslanon sa diha nga kini mao ang importante alang sa caller sa pagpugong sa unsa nga paagi nga ang handumanan ang resulta mao ang gitipigan sa gets gigahin, ug ikaw gusto sa paglikay sa wala kinahanglana nga nagalihok.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` wala ihulog sa daan nga mga sulod, nga mao ang importante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Karon nahibalo kita `v` ang initialized!Kini usab naghimo sa pagsiguro nga ang mga vector gets sa husto nga paagi nagpatulo.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Pagsugod sa us aka elemento nga daghang elemento
///
/// `MaybeUninit<T>` mahimong magamit aron mapasugod ang daghang elemento nga gisundan sa elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Paghimo usa ka wala mahibal-an nga array sa `MaybeUninit`.
///     // Ang `assume_init` luwas tungod kay ang matang kita nag-angkon nga initialized dinhi mao ang usa ka hugpong sa `MaybeUninit`s, nga wala magkinahanglan og Initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ang paghulog sa usa ka `MaybeUninit` wala'y gibuhat.
///     // Mao kini ang paggamit sa hilaw nga point buluhaton sa baylo nga sa `ptr::write` dili hinungdan sa daan nga uninitialized bili nga nagatulo.
/////
///     // Usab kon adunay usa ka panic sa panahon niini nga laang, kita adunay usa ka handumanan leak, apan walay isyu sa panumduman sa kaluwasan.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ang tanan initialized.
///     // Pagbalhin sa array sa pasiuna nga tipo.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Mahimo usab sa pagtrabaho uban sa partially initialized arrays, nga mahimong makita diha sa ubos-level datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Paghimo usa ka wala mahibal-an nga array sa `MaybeUninit`.
/// // Ang `assume_init` luwas tungod kay ang matang kita nag-angkon nga initialized dinhi mao ang usa ka hugpong sa `MaybeUninit`s, nga wala magkinahanglan og Initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Ipha ang gidaghanon sa mga elemento nga among gihatag.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Alang sa matag aytem diha sa gubat, ihulog kon gigahin kita niini.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing sa usa ka magtukod uma-sa-uma
///
/// Mahimo nimong gamiton ang `MaybeUninit<T>`, ug ang [`std::ptr::addr_of_mut`] macro, aron mapasugdan ang mga gawi sa nataran sa uma:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing sa `name` uma
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing sa `list` uma Kon adunay usa ka panic dinhi, nan ang `String` sa `name` leaks uma.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Ang tanan nga mga natad giuna, busa gitawag namon ang `assume_init` aron makakuha usa ka una nga Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` mao ang garantiya nga ang mga sama nga gidak-on, paglaray, pagtalay, ug ABI ingon `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Hinuon hinumdumi nga ang usa ka tipo *nga adunay sulud nga* nga `MaybeUninit<T>` dili kinahanglan parehas nga paghan-ay;Ang Rust wala sa kadaghanan nga garantiya nga ang mga uma sa usa ka `Foo<T>` adunay parehas nga pagkahan-ay ingon usa ka `Foo<U>` bisan kung ang `T` ug `U` adunay parehas nga kadako ug paghanay.
///
/// Dugang pa tungod kay ang bisan unsang gamay nga kantidad nga balido alang sa usa ka `MaybeUninit<T>` ang tagatala dili magamit ang mga pag-optimize sa non-zero/niche-filling, nga posibleng magresulta sa labi ka kadako:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Kung ang `T` luwas sa FFI, nan ingon usab ang `MaybeUninit<T>`.
///
/// Samtang `MaybeUninit` mao `#[repr(transparent)]` (nga nagpakita nga kini garantiya sa sama nga gidak-on, paglaray, pagtalay, ug ABI ingon `T`), kini nagabuhat dili *-usab sa bisan unsa nga sa miaging caveats.
/// `Option<T>` ug `Option<MaybeUninit<T>>` mahimo gihapon adunay lain-laing gidak-on, ug ang matang nga adunay sulod sa usa ka uma sa matang `T` mahimong gibutang sa (ug kadako) lahi kay sa kon uma nga `MaybeUninit<T>`.
/// `MaybeUninit` usa ka klase nga unyon, ug ang `#[repr(transparent)]` sa mga unyon dili malig-on (tan-awa ang [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Paglabay sa panahon, ang eksaktong mga garantiya sa `#[repr(transparent)]` sa mga unyon mahimong mabanhaw, ug ang `MaybeUninit` mahimo o dili magpabilin nga `#[repr(transparent)]`.
/// Nga miingon, `MaybeUninit<T>` kabubut *kanunay* garantiya nga kini adunay sama nga gidak-on, paglaray, pagtalay, ug ABI ingon `T`;Kini ra ang paagi nga gipatuman sa `MaybeUninit` nga garantiya nga mahimong molambo.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang butang aron kita wrap sa ubang mga matang sa niini.Kini mapuslanon alang sa mga generator.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Dili sa pagtawag `T::clone()`, dili kita mahibalo kon kita initialized igo alang sa nga.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Nagmugna sa usa ka bag-o nga `MaybeUninit<T>` initialized sa gihatag nga bili.
    /// Kini mao ang luwas sa pagtawag [`assume_init`] sa pagbalik bili sa niini nga function.
    ///
    /// Hinumdomi nga ang paghulog sa usa ka `MaybeUninit<T>` dili gyud tawagan ang drop code sa `T`.
    /// Kini mao ang imong responsibilidad sa pagsiguro `T` gets nagatulo kon kini na initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Nagmugna sa usa ka bag-o nga `MaybeUninit<T>` sa usa ka uninitialized nga kahimtang.
    ///
    /// Hinumdomi nga ang paghulog sa usa ka `MaybeUninit<T>` dili gyud tawagan ang drop code sa `T`.
    /// Kini mao ang imong responsibilidad sa pagsiguro `T` gets nagatulo kon kini na initialized.
    ///
    /// Tan-awa ang [type-level documentation][MaybeUninit] alang sa pipila ka mga ehemplo.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Paghimo og bag-ong gubat sa `MaybeUninit<T>` butang, sa usa ka uninitialized nga kahimtang.
    ///
    /// Note: sa usa ka future Rust bersyon niini nga pamaagi mahimong wala kinahanglana nga sa diha nga gubat literal nga syntax nagtugot [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// nga panig-ingnan sa ubos dayon sa paggamit sa `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Mobalik sa usa ka (posible nga mas gamay) ad-ad sa data nga sa pagkatinuod sa pagbasa
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: Usa ka uninitialized `[MaybeUninit<_>; LEN]` balido.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Nagmugna sa usa ka bag-o nga `MaybeUninit<T>` sa usa ka uninitialized nga kahimtang, uban sa handumanan nga puno sa `0` bytes.Kini nag-agad sa `T` kon nga na naghimo alang sa hustong Initialization.
    ///
    /// Pananglitan, `MaybeUninit<usize>::zeroed()` ang initialized, apan `MaybeUninit<&'static i32>::zeroed()` dili tungod kay mga pakisayran dili kinahanglan nga bili.
    ///
    /// Hinumdomi nga ang paghulog sa usa ka `MaybeUninit<T>` dili gyud tawagan ang drop code sa `T`.
    /// Kini mao ang imong responsibilidad sa pagsiguro `T` gets nagatulo kon kini na initialized.
    ///
    /// # Example
    ///
    /// Husto nga paggamit sa niini nga function: initializing sa usa ka magtukod sa zero, diin ang tanan nga mga kaumahan sa magtukod makahupot sa gamay-sumbanan 0 ingon sa usa ka balido nga bili.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Dili husto* paggamit sa kini nga pag-andar: ang pagtawag sa `x.zeroed().assume_init()` kung ang `0` dili usa ka balido nga gamay nga sundanan alang sa tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Sa sulud sa usa ka pares, naghimo kami usa ka `NotZero` nga wala`y balidong diskriminasyon.
    /// // Kini dili matino nga pamatasan.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` nagpunting sa gigahin handumanan.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Mopakita sa bili sa `MaybeUninit<T>`.
    /// Gisapawan niini ang bisan unsang naunang kantidad nga wala kini ihulog, busa pag-amping nga dili gamiton kini kaduha gawas kung gusto nimo laktawan ang pagpadagan sa destructor.
    ///
    /// Alang sa imong kasayon, gibalik usab niini ang usa ka mabalhin nga pakisayran sa (karon luwas na nga gisugdan) nga sulud sa `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: Kita lang initialized niini nga bili.
        unsafe { self.assume_init_mut() }
    }

    /// Nakakuha usa ka pointer sa sulud nga kantidad.
    /// Ang pagbasa gikan sa kini nga panudlo o paghimo niini nga usa ka pakisayran wala mahibal-an nga pamatasan gawas kung ang `MaybeUninit<T>` mapasugod.
    /// Pagsulat sa handumanan nga kini nga pointer (non-transitively) puntos sa mao dili tino ang kinaiya (gawas sa sulod sa usa ka `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Paghimo og usa ka pakisayran ngadto sa `MaybeUninit<T>`.Kini mao ang okay tungod kay initialized kita niini.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Dili husto* paggamit sa kini nga pamaagi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Nakahimo kami usa ka pakigsulti sa usa ka wala mahibal-an nga vector!Kini mao ang dili tino ang kinaiya.⚠️
    /// ```
    ///
    /// (Matikdi nga ang mga lagda sa palibot paghisgot sa uninitialized data wala finalize pa, apan hangtud nga sila, kini mao ang advisable sa paglikay kanila.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ug `ManuallyDrop` mga duha `repr(transparent)` aron kita gisalikway sa pointer.
        self as *const _ as *const T
    }

    /// Gets sa usa ka mutable pointer sa anaa bili.
    /// Ang pagbasa gikan sa kini nga panudlo o paghimo niini nga usa ka pakisayran wala mahibal-an nga pamatasan gawas kung ang `MaybeUninit<T>` mapasugod.
    ///
    /// # Examples
    ///
    /// Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Paghimo og usa ka pakisayran ngadto sa `MaybeUninit<Vec<u32>>`.
    /// // Okay ra kini tungod kay giuna namon kini.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Dili husto* paggamit sa kini nga pamaagi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Nakahimo kami usa ka pakigsulti sa usa ka wala mahibal-an nga vector!Kini mao ang dili tino ang kinaiya.⚠️
    /// ```
    ///
    /// (Matikdi nga ang mga lagda sa palibot paghisgot sa uninitialized data wala finalize pa, apan hangtud nga sila, kini mao ang advisable sa paglikay kanila.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ug `ManuallyDrop` mga duha `repr(transparent)` aron kita gisalikway sa pointer.
        self as *mut _ as *mut T
    }

    /// Nagmina sa bili gikan sa `MaybeUninit<T>` sudlanan.Kini mao ang usa ka dako nga paagi sa pagsiguro nga ang mga data nga na naghulog, tungod kay ang mga resulta `T` mao ang subject sa sa naandan nga drop handling.
    ///
    /// # Safety
    ///
    /// Kini mao ang ngadto sa mga caller sa garantiya nga ang `MaybeUninit<T>` gayud anaa sa usa ka initialized nga kahimtang.Sa pagtawag niini sa diha nga ang sulod wala pa bug-os initialized hinungdan diha-diha nga dili tino ang kinaiya.
    /// Ang [type-level documentation][inv] naglangkob sa dugang nga impormasyon mahitungod niini nga Initialization makanunayon.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Sa ibabaw sa nga, hinumdumi nga ang kadaghanan sa mga matang nga adunay dugang nga mga invariants sa unahan lamang nga giisip initialized sa lebel matang.
    /// Pananglitan, ang usa ka `1`-initialized [`Vec<T>`] giisip initialized (ubos sa kasamtangan nga pagpatuman; kini wala naglangkob sa usa ka lig-on nga garantiya) tungod kay ang bugtong gikinahanglan sa tighipos nahibalo mahitungod niini mao nga ang data pointer kinahanglan nga non-bili.
    ///
    /// Pagmugna sa maong usa ka `Vec<T>` dili hinungdan *diha-diha nga* dili tino ang kinaiya, apan hinungdan sa dili tino ang kinaiya sa labing luwas nga operasyon (lakip na ang pagtulo niini).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Dili husto* paggamit sa kini nga pamaagi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` wala initialized pa, mao nga kini nga katapusan nga linya hinungdan dili tino ang kinaiya.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` ang initialized.
        // Kini usab nagpasabot nga `self` kinahanglan nga usa ka `value` laing.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Ginbasa ang bili gikan sa `MaybeUninit<T>` sudlanan.Ang resulta `T` mao ang subject sa sa naandan nga drop handling.
    ///
    /// Kon mahimo, kini mao ang mas maayo nga gamiton ang [`assume_init`] sa baylo, nga magpugong nagkopya sa sulod sa `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Kini mao ang ngadto sa mga caller sa garantiya nga ang `MaybeUninit<T>` gayud anaa sa usa ka initialized nga kahimtang.Ang pagtawag niini kung ang sulud dili pa hingpit nga napasugod hinungdan sa wala matino nga pamatasan.
    /// Ang [type-level documentation][inv] naglangkob sa dugang nga impormasyon mahitungod niini nga Initialization makanunayon.
    ///
    /// Dugang pa, nagbilin kini usa ka kopya sa parehas nga datos sa `MaybeUninit<T>`.
    /// Kung naggamit daghang mga kopya sa datos (pinaagi sa pagtawag sa `assume_init_read` daghang beses, o una nga pagtawag sa `assume_init_read` ug pagkahuman [`assume_init`]), responsibilidad nimo nga masiguro nga ang datos mahimo`g madoble.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` mao `Copy`, aron atong mabasa sa daghang mga panahon.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Nagkopya sa usa ka `None` bili mao ang okay, aron atong mabasa sa daghang mga panahon.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Dili husto* paggamit sa kini nga pamaagi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Kita karon gibuhat sa duha ka kopya sa sa mao gihapon nga vector, padulong ngadto sa usa ka double-free ⚠️ sa diha nga sila nga duha get nagpatulo sa!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` ang initialized.
        // Ang pagbasa gikan sa `self.as_ptr()` luwas tungod kay ang `self` kinahanglan nga pasiuna.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Pagtulo sa sulud nga kantidad sa lugar.
    ///
    /// Kon kamo adunay pagpanag-iya sa `MaybeUninit`, kamo makahimo sa paggamit [`assume_init`] sa baylo.
    ///
    /// # Safety
    ///
    /// Kini mao ang ngadto sa mga caller sa garantiya nga ang `MaybeUninit<T>` gayud anaa sa usa ka initialized nga kahimtang.Ang pagtawag niini kung ang sulud dili pa hingpit nga napasugod hinungdan sa wala matino nga pamatasan.
    ///
    /// Dugang pa niini, ang tanan nga dugang nga mga invariant sa tipo nga `T` kinahanglan matagbaw, tungod kay ang pagpatuman sa `Drop` sa `T` (o mga miyembro niini) mahimong mosalig niini.
    /// Pananglitan, ang usa ka `1`-initialized [`Vec<T>`] giisip initialized (ubos sa kasamtangan nga pagpatuman; kini wala naglangkob sa usa ka lig-on nga garantiya) tungod kay ang bugtong gikinahanglan sa tighipos nahibalo mahitungod niini mao nga ang data pointer kinahanglan nga non-bili.
    ///
    /// Pagtulo sa maong usa ka `Vec<T>` Apan ang hinungdan sa dili tino ang kinaiya.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: ang caller kinahanglan garantiya nga `self` ang initialized ug
        // nagtagbaw sa tanan nga mga invariants sa `T`.
        // Pagtulo sa bili sa dapit mao ang luwas kon nga mao ang kaso.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Gets sa usa ka gipakigbahin nga paghisgot sa mga anaa bili.
    ///
    /// Kini mahimong mapuslanon sa diha nga kita gusto sa pag-access sa usa ka `MaybeUninit` nga initialized apan dili iya sa `MaybeUninit` (pagpugong sa paggamit sa `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini sa diha nga ang sulod wala pa bug-os initialized hinungdan dili tino ang kinaiya: kini mao ang ngadto sa caller sa garantiya nga ang `MaybeUninit<T>` gayud anaa sa usa ka initialized nga kahimtang.
    ///
    ///
    /// # Examples
    ///
    /// ### Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Karon nga ang among `MaybeUninit<_>` nahibal-an nga gisugdan, okay ra nga maghimo usa ka gipaambit nga pakigsulti niini:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` nga initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Dili sakto nga* paggamit sa niini nga pamaagi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Nakahimo kami usa ka pakigsulti sa usa ka wala mahibal-an nga vector!Kini mao ang dili tino ang kinaiya.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Ig-una ang `MaybeUninit` gamit ang `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Paghisgot sa usa ka uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` ang initialized.
        // Kini usab nagpasabot nga `self` kinahanglan nga usa ka `value` laing.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Gets sa usa ka mutable (unique) paghisgot sa anaa bili.
    ///
    /// Kini mahimong mapuslanon sa diha nga kita gusto sa pag-access sa usa ka `MaybeUninit` nga initialized apan dili iya sa `MaybeUninit` (pagpugong sa paggamit sa `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Sa pagtawag niini sa diha nga ang sulod wala pa bug-os initialized hinungdan dili tino ang kinaiya: kini mao ang ngadto sa caller sa garantiya nga ang `MaybeUninit<T>` gayud anaa sa usa ka initialized nga kahimtang.
    /// Pananglitan, `.assume_init_mut()` dili mahimong gamiton sa initialize sa usa ka `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Husto nga paggamit sa kini nga pamaagi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Gipauna ang *tanan* nga mga byte sa input buffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ig-una ang `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Karon kita nasayud nga `buf` nga initialized, aron kita `.assume_init()` niini.
    /// // Apan, sa paggamit sa `.assume_init()` mahimong makamugna og usa ka `memcpy` sa 2048 bytes.
    /// // Aron ihingusog ang atong buffer nga initialized walay pagkopya niini, upgrade kita sa `&mut MaybeUninit<[u8; 2048]>` ngadto sa usa ka `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KALUWASAN: Ang `buf` gipauna.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Karon nga kita sa paggamit sa `buf` ingon sa usa ka normal nga ad-ad:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Dili sakto nga* paggamit sa niini nga pamaagi:
    ///
    /// Ikaw dili sa paggamit sa `.assume_init_mut()` sa initialize sa usa ka bili:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kita gibuhat sa usa ka (mutable) paghisgot sa usa ka uninitialized `bool`!
    ///     // Kini dili matino nga pamatasan.⚠️
    /// }
    /// ```
    ///
    /// Pananglitan, dili nimo mahimo ang [`Read`] sa usa ka uninitialized buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) paghisgot sa wala nahibal-an nga panumduman!
    ///                             // Kini dili matino nga pamatasan.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ni kamo makahimo sa paggamit sa direkta nga uma access sa pagbuhat sa uma-sa-uma anam-anam Initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) paghisgot sa wala nahibal-an nga panumduman!
    ///                  // Kini dili matino nga pamatasan.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) paghisgot sa wala nahibal-an nga panumduman!
    ///                  // Kini dili matino nga pamatasan.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Karon kami nagsalig sa dili tama nga sayup sa taas, ie, adunay kami mga pakisayran sa wala nahibal-an nga datos (pananglitan, sa `libcore/fmt/float.rs`).
    // Kinahanglan nga mohimo kita usa ka katapusang desisyon bahin sa mga lagda sa wala pa pagpalig-on.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` ang initialized.
        // Kini usab nagpasabot nga `self` kinahanglan nga usa ka `value` laing.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Nagmina sa mga mithi sa usa ka gubat sa `MaybeUninit` sudlanan.
    ///
    /// # Safety
    ///
    /// Kini mao ang ngadto sa mga caller sa garantiya nga ang tanan nga mga elemento sa gubat anaa sa usa ka initialized nga kahimtang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KALUWASAN: Karon luwas na samtang gisugdan namon ang tanan nga mga elemento
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ang caller garantiya nga ang tanan nga mga elemento sa gubat nga initialized
        // * `MaybeUninit<T>` ug ang T gigarantiyahan nga adunay parehas nga layout
        // * MaybeUnint dili drop, mao nga walay mga doble nga frees Ug sa ingon ang pagkakabig luwas
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Panag-isip nga ang tanan nga mga elemento gisugdan, pagkuha usa ka hiwa sa kanila.
    ///
    /// # Safety
    ///
    /// Naa ra sa nanawag aron garantiyahan nga ang mga elemento nga `MaybeUninit<T>` naa gyud sa usa ka pasiuna nga estado.
    ///
    /// Sa pagtawag niini sa diha nga ang sulod wala pa bug-os initialized hinungdan dili tino ang kinaiya.
    ///
    /// Tan-awa ang [`assume_init_ref`] alang sa daghang mga detalye ug pananglitan.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: nagataktak sa ad-ad sa usa ka `*const [T]` luwas sukad pa sa caller garantiya nga
        // `slice` mao initialized, and`MaybeUninit` mao ang garantiya nga ang mga sama nga layout ingon `T`.
        // Ang nakuha nga pointer mao ang balido tungod kay kini nagtumong sa memorya nga gipanag-iya sa `slice` nga usa ka pakisayran ug busa garantiya nga mahimong balido alang sa mga pagbasa.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ingnon ta ang tanan nga mga elemento nga initialized, pagkuha sa usa ka mutable ad-ad sa ila.
    ///
    /// # Safety
    ///
    /// Naa ra sa nanawag aron garantiyahan nga ang mga elemento nga `MaybeUninit<T>` naa gyud sa usa ka pasiuna nga estado.
    ///
    /// Sa pagtawag niini sa diha nga ang sulod wala pa bug-os initialized hinungdan dili tino ang kinaiya.
    ///
    /// Tan-awa ang [`assume_init_mut`] alang sa daghang mga detalye ug pananglitan.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KALUWASAN: parehas sa mga nota sa kaluwasan alang sa `slice_get_ref`, apan adunay kami usa
        // mutable paghisgot nga usab garantiya nga mahimong balido alang sa misulat.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Sa usa ka gets pointer sa unang elemento sa gubat.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Gets sa usa ka mutable pointer sa unang elemento sa gubat.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Gikopya ang mga elemento gikan sa `src` hangtod `this`, nga gibalik ang usa ka mabalhin nga pakisayran sa na-initalize nga sulud sa `this`.
    ///
    /// Kon `T` wala pagpatuman `Copy`, gamita [`write_slice_cloned`]
    ///
    /// Kini parehas sa [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// function Kini panic kon ang duha ka mga hiwa adunay lain-laing mga gitas-on.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: kita lang gikopya ang tanan nga mga elemento sa Len ngadto sa mopagawas kapasidad
    /// // sa unang src.len() mga elemento sa vec mga balido karon.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] ug&[MaybeUninit<T>] Makabaton sa sama nga layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KALUWASAN: Ang mga balido nga elemento bag-o lang nakopya sa `this` mao nga kini napahimutang
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones sa mga elemento gikan sa `src` ngadto sa `this`, pagbalik sa usa ka mutable paghisgot sa karon initalized sulod sa `this`.
    /// Ang bisan unsang na initalized elemento dili nagatulo.
    ///
    /// Kon `T` galamiton `Copy`, paggamit [`write_slice`]
    ///
    /// Kini mao ang susama sa [`slice::clone_from_slice`] apan wala drop kasamtangan nga mga elemento.
    ///
    /// # Panics
    ///
    /// Ang kini nga pag-andar panic kung ang duha nga mga hiwa adunay lainlaing gitas-on, o kung ang pagpatuman sa `Clone` panics.
    ///
    /// Kon adunay usa ka panic, ang na-clone nga mga elemento nga nagatulo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KALUWASAN: gi-clone na lang namon ang tanan nga mga elemento sa len sa ekstrang kapasidad
    /// // sa unang src.len() mga elemento sa vec mga balido karon.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // dili sama sa copy_from_slice kini wala sa pagtawag clone_from_slice sa ad-ad mao kini tungod kay `MaybeUninit<T: Clone>` wala pagpatuman Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KALUWASAN: ang kini nga hilaw nga hiwa magasulud ra sa una nga mga butang
                // mao nga, gitugotan nga ihulog kini.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kinahanglan naton nga dayag nga hiwaon sila sa parehas nga gitas-on
        // alang sa mga utlanan sa pagsusi nga elided, ug ang optimizer makamugna memcpy alang sa yano nga mga kaso (alang sa panig-ingnan T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // magbalantay ang gikinahanglan b/c panic unta mahitabo sa panahon sa usa ka clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KALUWASAN: Ang mga balido nga elemento gisulat lang sa `this` mao nga kini napahimutang
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}