//! Panguna nga gimbuhaton alang sa pag-atubang sa memorya.
//!
//! module Kini nga naglangkob sa mga gimbuhaton alang sa querying sa gidak-on ug sa paglaray, pagtalay sa mga matang, initializing ug pagmaniobra sa panumduman.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Nagkinahanglan pagpanag-iya ug "forgets" bahin sa bili **walay nagdagan sa iyang destructor**.
///
/// Sa bisan unsa nga mga kapanguhaan sa bili manager, sama sa mohon sa panumduman o sa usa ka file kuptanan, ang magpabilin sa walay kataposan sa usa ka makab-ot nga kahimtang.Apan, dili kini ang garantiya nga pointers niini nga handumanan magpabilin balido.
///
/// * Kon kamo gusto nga tulo handumanan, tan-awa [`Box::leak`].
/// * Kung gusto nimong makakuha usa ka hilaw nga puntos sa panumduman, tan-awa ang [`Box::into_raw`].
/// * Kung gusto nimo igawas ang usa ka kantidad nga husto, pagpadagan sa destructor niini, tan-awa ang [`mem::drop`].
///
/// # Safety
///
/// `forget` dili gimarkahan ingon nga `unsafe`, tungod kay ang kaluwasan garantiya ni Rust wala maglakip sa usa ka garantiya nga ang destructors kanunay modagan.
/// Pananglitan, usa ka programa mahimo paghimo sa usa ka pakisayran cycle gamit ang [`Rc`][rc], o pagtawag [`process::exit`][exit] sa exit nga dili sa nagaagay nga destructors.
/// Busa, nagtugot sa `mem::forget` gikan sa luwas nga code wala pundamental-usab sa kaluwasan garantiya ni Rust.
///
/// Nga miingon, leaking mga kapanguhaan sama sa panumdoman o I/O mga butang mao ang kasagaran undesirable.
/// Ang panginahanglan moabut sa pipila nga mga espesyalista nga mga kaso sa paggamit alang sa FFI o dili luwas nga code, apan bisan pa, ang [`ManuallyDrop`] kasagarang gipalabi.
///
/// Tungod kay gitugotan ang pagkalimot sa usa ka kantidad, bisan unsang `unsafe` code nga imong gisulat kinahanglan magtugot alang sa kini nga posibilidad.Ikaw dili mobalik sa usa ka bili ug magdahum nga ang caller nga kinahanglan modagan destructor sa bili ni.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ang kanonikal nga luwas nga paggamit sa `mem::forget` mao ang sa circumvent destructor sa usa ka bili ni gipatuman sa `Drop` trait.Pananglitan, kini moagas usa ka `File`, ie
/// pagbawi sa luna nga gikuha sa baryable apan wala gayud suod sa nahiilalum sistema kapanguhaan:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Kini mao ang mapuslanon sa diha nga ang pagpanag-iya sa mga nagpahiping kapanguhaan kaniadto gibalhin ngadto sa code gawas sa Rust, alang sa panig-ingnan pinaagi sa pagpasa sa mga hilaw nga file kapsiyon sa C code.
///
/// # Ang relasyon sa `ManuallyDrop`
///
/// Samtang `mem::forget` mahimo usab nga gamiton sa pagbalhin *handumanan* pagpanag-iya, ang pagbuhat sa ingon sayop-prone.
/// [`ManuallyDrop`] kinahanglan nga gamiton sa baylo.Tagda, pananglitan, kini nga code:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Paghimo usa ka `String` gamit ang mga sulud sa `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // tulo `v` tungod kay ang handumanan karon nakahimo sa `s`
/// mem::forget(v);  // Sayop, v mao ang imbalido ug dili kinahanglan nga milabay sa usa ka function
/// assert_eq!(s, "Az");
/// // `s` ang bug-os nagpatulo ug ang mga handumanan deallocated.
/// ```
///
/// Adunay duha ka isyu sa pananglitan sa taas:
///
/// * Kon dugang nga code gidugang sa taliwala sa pagtukod sa `String` ug sa pagsangpit sa `mem::forget()`, usa ka panic sa sulod nga kini ang hinungdan sa sa usa ka double nga gawasnon tungod kay ang sama nga handumanan nga gidumala sa duha `v` ug `s`.
/// * Human sa pagtawag `v.as_mut_ptr()` ug pagpasa sa pagpanag-iya sa mga data sa `s`, ang `v` bili mao ang walay pulos.
/// Bisan sa diha nga ang usa ka bili lang mibalhin sa `mem::forget` (nga dili-inspeksyon niini), ang pipila ka matang adunay higpit nga mga kinahanglanon sa ilang mga prinsipyo nga sa paghimo kanila nga walay pulos sa diha nga nagbitay o wala na nga gipanag-iya.
/// Ang paggamit sa dili balido nga mga kantidad sa bisan unsang paagi, lakip ang pagpasa niini sa o pagpabalik niini gikan sa mga pag-andar, naglangkob sa wala matino nga pamatasan ug mahimong mabuak ang mga pangagpas nga gihimo sa tagtipon.
///
/// Ang pagbalhin sa `ManuallyDrop` naglikay sa parehas nga mga isyu:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sa dili pa kita disassemble `v` sa iyang hilaw nga mga bahin, ang imong sigurado kini dili na nagpatulo!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Karon disassemble ang `v`.Kini nga mga operasyon dili panic, busa dili mahimo nga usa ka leak.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Sa katapusan, pagtukod usa ka `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ang bug-os nagpatulo ug ang mga handumanan deallocated.
/// ```
///
/// `ManuallyDrop` kusganon nga gipugngan ang doble nga gawasnon tungod kay gipadagan namon ang destructor sa `v` sa wala pa pagbuhat bisan unsa pa.
/// `mem::forget()` wala tugoti kini tungod kay nahurot ang lantugi niini, gipugos kami nga tawagan lang kini pagkahuman makuha ang bisan unsang kinahanglan gikan sa `v`.
/// Bisan kung ang usa ka panic gipaila taliwala sa pagtukod sa `ManuallyDrop` ug pagtukod sa pisi (nga dili mahinabo sa code sama sa gipakita), magresulta kini sa usa ka leak ug dili usa ka doble nga libre.
/// Sa ato pa, ang `ManuallyDrop` nasayop sa kilid sa pagtulo sa baylo nga masayup sa kilid sa (doble-) nga pagtulo.
///
/// Ingon usab, gipugngan kami sa `ManuallyDrop` gikan sa pag-adto sa "touch" `v` pagkahuman ibalhin ang pagpanag-iya sa `s`-ang katapusang lakang sa pakig-uban sa `v` aron mapahawa kini nga wala gipadagan ang destructor niini hingpit nga gilikayan.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Sama sa [`forget`], apan modawat usab sa wala`y kadako nga mga kantidad.
///
/// Ang kini nga kalihokan usa ra ka shim nga gilaraw nga tangtangon kung ang bahin sa `unsized_locals` malig-on.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Gibalik ang gidak-on sa usa ka tipo sa mga byte.
///
/// Labi ka piho, kini ang offset sa mga byte taliwala sa sunud-sunod nga mga elemento sa usa ka laray nga adunay kana nga tipo sa item lakip ang pag-align sa padding.
///
/// Sa ingon, alang sa bisan unsang tipo nga `T` ug gitas-on `n`, ang `[T; n]` adunay gidak-on nga `n * size_of::<T>()`.
///
/// Sa kinatibuk-an, ang gidak-on sa usa ka tipo dili malig-on sa tibuuk nga mga panagsama, apan ang piho nga mga lahi sama sa mga pasiuna.
///
/// Ang mosunud nga lamesa naghatag sa gidak-on alang sa mga pasiuna.
///
/// Matang |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Dugang pa, ang `usize` ug `isize` adunay parehas nga gidak-on.
///
/// Ang mga lahi nga `*const T`, `&T`, `Box<T>`, `Option<&T>`, ug `Option<Box<T>>` tanan adunay parehas nga kadako.
/// Kung ang `T` Gidak-on, ang tanan nga mga lahi adunay parehas nga kadako sa `usize`.
///
/// Ang pagbag-o sa usa ka pointer dili magbag-o sa gidak-on niini.Ingon niana, ang `&T` ug `&mut T` adunay parehas nga gidak-on.
/// Ingon usab alang sa `*const T` ug `* mut T`.
///
/// # Kadako sa mga butang nga `#[repr(C)]`
///
/// Ang representasyon sa `C` alang sa mga aytem adunay gihubit nga layout.
/// Sa kini nga layout, ang kadak-an sa mga butang stable usab basta ang tanan nga mga uma adunay usa ka lig-on nga gidak-on.
///
/// ## Kadak-an sa mga Hinungdan
///
/// Alang sa `structs`, ang gidak-on gitino sa mosunud nga algorithm.
///
/// Alang sa matag natad sa istruktura nga gimando pinaagi sa mando sa deklarasyon:
///
/// 1. Idugang ang gidak-on sa uma.
/// 2. I-Round up ang kasamtangan nga gidak-on sa pinakaduol nga daghang sa sunod nga [alignment].
///
/// Sa katapusan, palibuton ang gidak-on sa istraktura sa pinakaduol nga kadaghan sa [alignment] niini.
/// Ang paglinya sa istraktura sagad mao ang labing kadaghan nga paglinya sa tanan nga mga natad niini;mahimo kini mabag-o sa paggamit sa `repr(align(N))`.
///
/// Dili sama sa `C`, ang mga gidak-on nga gidak-on sa zero wala gikutup hangtod sa usa ka byte nga gidak-on.
///
/// ## Kadako sa mga Enum
///
/// Ang mga enum nga wala`y dala nga datos gawas sa pagpihig adunay parehas nga kadako sa mga enum C sa platform nga sila gitipon.
///
/// ## Kadak-an sa mga Unyon
///
/// Ang kadak-an sa usa ka unyon mao ang kadak-an sa labing kadaghan nga natad.
///
/// Dili sama sa `C`, ang mga zero nga gidak-on sa unyon dili gikutuban hangtod sa usa ka byte nga gidak-on.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Ang ubang mga primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Ang ubang mga arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer gidak-on pagkasama
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Paggamit `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ang kadak-an sa una nga uma 1, busa idugang ang 1 sa gidak-on.Ang kadak-on 1.
/// // Ang paglinya sa ikaduhang natad mao ang 2, busa pagdugang 1 sa gidak-on alang sa padding.Ang kadak-an 2.
/// // Ang kadak-an sa ikaduha nga uma 2, busa idugang ang 2 sa gidak-on.Ang gidak-on mao ang 4.
/// // Ang pagpahiangay sa ikatulong uma mao ang 1, mao nga sa pagdugang 0 ngadto sa gidak-on alang sa padding.Ang gidak-on mao ang 4.
/// // Ang gidak-on sa ikatolo ka uma mao ang 1, mao nga sa pagdugang sa 1 ngadto sa gidak-on.Gidak-on mao ang 5.
/// // Sa katapusan, ang paglinya sa istraktura mao ang 2 (tungod kay ang labing kadaghan nga paghanay taliwala sa mga uma niini 2), busa pagdugang 1 sa gidak-on alang sa padding.
/// // Gidak-on mao ang 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs sa pagsunod sa sama nga mga lagda.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Timan-i nga reordering sa mga kaumahan mahimong ipaubos sa gidak-on.
/// // Mahimo namon tangtangon ang parehas nga mga byte padding pinaagi sa pagbutang `third` sa wala pa ang `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ang kadako sa unyon mao ang kadako sa labing kadaghan nga uma.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Gibalik ang kadako sa gitudlo nga kantidad sa mga byte.
///
/// Kasagaran kini parehas sa `size_of::<T>()`.
/// Bisan pa, kung ang `T` * wala`y statically-kilala nga kadako, pananglit, usa ka hiwa nga [`[T]`][slice] o usa ka [trait object], nan ang `size_of_val` mahimong magamit aron makuha ang kadaghan nga naila sa kadasig.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KALUWASAN: Ang `val` usa ka pakisayran, busa kini usa ka balido nga hilaw nga puntos
    unsafe { intrinsics::size_of_val(val) }
}

/// Gibalik ang kadako sa gitudlo nga kantidad sa mga byte.
///
/// Kasagaran kini parehas sa `size_of::<T>()`.Bisan pa, kung ang `T` * wala`y statically-kilala nga kadako, pananglitan, usa ka hiwa nga [`[T]`][slice] o usa ka [trait object], nan ang `size_of_val_raw` mahimong magamit aron makuha ang kadaghan nga naila sa kadasig.
///
/// # Safety
///
/// function Kini mao ang luwas lamang sa tawag kon ang mosunod nga mga kondisyon naghupot:
///
/// - Kung ang `T` mao ang `Sized`, kini nga paglihok kanunay luwas tawgon.
/// - Kung ang wala`y sukod nga ikog sa `T` mao ang:
///     - usa ka [slice], unya ang gitas-on sa hiwa nga hiwa kinahanglan usa ka pasiuna nga integer, ug ang gidak-on sa *tibuuk nga kantidad*(dinamikong gitas-on sa ikog + statically kadako nga unlapi) kinahanglan nga moangay sa `isize`.
///     - usa ka [trait object], nan ang bahin nga mabutang sa pointer kinahanglan magtudlo sa usa ka balido nga vtable nga nakuha sa usa ka dili mapugos nga pagpamugos, ug ang gidak-on sa *tibuuk nga kantidad*(dinamikong gitas-on sa ikog + statically kadako nga unlapi) kinahanglan nga mohaum sa `isize`.
///
///     - usa ka (unstable) [extern type], kung ingon kini nga pag-andar kanunay luwas tawgon, apan mahimo nga panic o kung dili ibalik ang sayup nga kantidad, tungod kay wala mahibal-an ang layout sa extern type.
///     Kini ang parehas nga pamatasan sa [`size_of_val`] sa usa ka pakisayran sa usa ka klase nga adunay usa ka ikog nga klase nga ikog.
///     - kung dili, kini konserbatibong gitugotan nga tawagan kini nga pag-andar.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KALUWASAN: ang magtawag kinahanglan maghatag usa ka balido nga hilaw nga pahimangno
    unsafe { intrinsics::size_of_val(val) }
}

/// Gibalik ang [ABI]-kinahanglan nga minimum nga paglinya sa usa ka tipo.
///
/// Ang matag pakisayran sa usa ka kantidad sa tipo nga `T` kinahanglan usa ka kadaghan sa kini nga numero.
///
/// Kini ang gigamit nga paghanay alang sa mga uma sa istruktura.Mahimo kini nga mas gamay kaysa sa gusto nga paghanay.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Gibalik ang [ABI]-kinahanglan nga minimum nga paglinya sa tipo sa kantidad nga gipunting sa `val`.
///
/// Ang matag pakisayran sa usa ka kantidad sa tipo nga `T` kinahanglan usa ka kadaghan sa kini nga numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KALUWASAN: ang val usa ka pakisayran, mao nga kini usa ka balido nga hilaw nga puntos
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibalik ang [ABI]-kinahanglan nga minimum nga paglinya sa usa ka tipo.
///
/// Ang matag pakisayran sa usa ka kantidad sa tipo nga `T` kinahanglan usa ka kadaghan sa kini nga numero.
///
/// Kini ang gigamit nga paghanay alang sa mga uma sa istruktura.Mahimo kini nga mas gamay kaysa sa gusto nga paghanay.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Gibalik ang [ABI]-kinahanglan nga minimum nga paglinya sa tipo sa kantidad nga gipunting sa `val`.
///
/// Ang matag pakisayran sa usa ka kantidad sa tipo nga `T` kinahanglan usa ka kadaghan sa kini nga numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KALUWASAN: ang val usa ka pakisayran, mao nga kini usa ka balido nga hilaw nga puntos
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibalik ang [ABI]-kinahanglan nga minimum nga paglinya sa tipo sa kantidad nga gipunting sa `val`.
///
/// Ang matag pakisayran sa usa ka kantidad sa tipo nga `T` kinahanglan usa ka kadaghan sa kini nga numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// function Kini mao ang luwas lamang sa tawag kon ang mosunod nga mga kondisyon naghupot:
///
/// - Kung ang `T` mao ang `Sized`, kini nga paglihok kanunay luwas tawgon.
/// - Kung ang wala`y sukod nga ikog sa `T` mao ang:
///     - usa ka [slice], unya ang gitas-on sa hiwa nga hiwa kinahanglan usa ka pasiuna nga integer, ug ang gidak-on sa *tibuuk nga kantidad*(dinamikong gitas-on sa ikog + statically kadako nga unlapi) kinahanglan nga moangay sa `isize`.
///     - usa ka [trait object], nan ang bahin nga mabutang sa pointer kinahanglan magtudlo sa usa ka balido nga vtable nga nakuha sa usa ka dili mapugos nga pagpamugos, ug ang gidak-on sa *tibuuk nga kantidad*(dinamikong gitas-on sa ikog + statically kadako nga unlapi) kinahanglan nga mohaum sa `isize`.
///
///     - usa ka (unstable) [extern type], kung ingon kini nga pag-andar kanunay luwas tawgon, apan mahimo nga panic o kung dili ibalik ang sayup nga kantidad, tungod kay wala mahibal-an ang layout sa extern type.
///     Kini ang parehas nga pamatasan sa [`align_of_val`] sa usa ka pakisayran sa usa ka klase nga adunay usa ka ikog nga klase nga ikog.
///     - kung dili, kini konserbatibong gitugotan nga tawagan kini nga pag-andar.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KALUWASAN: ang magtawag kinahanglan maghatag usa ka balido nga hilaw nga pahimangno
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibalik ang `true` kung naghulog mga kantidad sa tipo nga `T` nga hinungdan.
///
/// Kini pulos us aka hint sa pag-optimize, ug mahimong ipatuman nga konserbatibo:
/// mahimo kini ibalik ang `true` alang sa mga lahi nga dili kinahanglan nga ihulog.
/// Ingon sa kanunay nga ibalik ang `true` usa ka balido nga pagpatuman sa kini nga function.Bisan pa kung kini nga pag-andar tinuod nga nagbalik sa `false`, nan mahimo ka nga masiguro ang paghulog sa `T` wala`y epekto.
///
/// Ang mubu nga lebel nga pagpatuman sa mga butang sama sa mga koleksyon, nga kinahanglan nga ihulog sa kamut ang ilang datos, kinahanglan gamiton kini nga kalihokan aron malikayan ang dili kinahanglan nga pagsulay nga ihulog ang tanan nila nga sulud kung malaglag na kini.
///
/// Tingali dili kini kalainan sa mga pagtukod sa pagpagawas (diin ang usa ka loop nga wala`y mga epekto nga daling makit-an ug matangtang), apan kanunay usa ka dakong kadaugan alang sa mga debug build.
///
/// Hinumdomi nga gihimo na sa [`drop_in_place`] kini nga pagsusi, busa kung ang imong kabug-atan sa trabaho mahimong maminusan sa pipila ka gamay nga mga tawag nga [`drop_in_place`], ang paggamit niini dili kinahanglan.
/// Sa piho nga timan-i nga mahimo nimong [`drop_in_place`] ang usa ka hiwa, ug kana magahimo usa ka pagsusi sa mga kinahanglanon nga _ _ _ _ _ _ _ _ alang sa tanan nga mga kantidad.
///
/// Ang mga lahi sama sa Vec busa `drop_in_place(&mut self[..])` ra nga dili tin-aw nga naggamit `needs_drop`.
/// Ang mga lahi sama sa [`HashMap`], sa pikas nga bahin, kinahanglan nga ihulog ang mga kantidad nga tag-usa ug kinahanglan gamiton kini nga API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ania ang usa ka pananglitan kung giunsa mahimong magamit sa usa ka koleksyon ang `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ihulog ang datos
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Gibalik ang kantidad sa tipo nga `T` nga girepresenta sa all-zero byte-pattern.
///
/// Kini gipasabut nga, pananglitan, ang padding byte sa `(u8, u16)` dili kinahanglan nga ma-zero.
///
/// Wala'y garantiya nga ang usa ka all-zero byte-pattern nagrepresentar sa usa ka balido nga kantidad sa pipila ka mga klase nga `T`.
/// Pananglitan, ang all-zero byte-pattern dili balido nga kantidad alang sa mga tipo sa pakisayran (`&T`, `&mut T`) ug mga tudlo sa pagpaandar.
/// Ang paggamit sa `zeroed` sa mga ingon nga lahi hinungdan sa dayon nga [undefined behavior][ub] tungod kay ang [the Rust compiler assumes][inv] nga kanunay adunay usa ka balido nga kantidad sa usa ka variable nga giisip nga una.
///
///
/// Kini adunay parehas nga epekto sa [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Kini mapuslanon alang sa FFI usahay, apan sa kinatibuk-an kinahanglan likayan.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Husto nga paggamit sa kini nga kalihokan: pagsugod sa usa ka integer nga adunay zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Dili husto* paggamit sa kini nga pag-andar: pagsugod sa usa ka pakisayran nga adunay zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Dili tino ang kinaiya!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ug pag-usab!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang tanan nga wala`y bili nga bili balido alang sa `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ang mga normal nga tseke sa memory-initialization sa Bypass Rust pinaagi sa pagpakaaron-ingnon nga nakaghimo usa ka kantidad nga tipo nga `T`, samtang wala`y gihimo.
///
/// **Natangtang ang gamit niini.** Sa baylo, gamiton ang [`MaybeUninit<T>`].
///
/// Ang hinungdan sa pagkatangtang sa kusog mao nga ang pagpaandar sa batakan dili magamit nga tama: adunay parehas nga epekto sa [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Sama sa gipatin-aw sa [`assume_init` documentation][assume_init], ang [the Rust compiler assumes][inv] nga ang mga kantidad husto nga gisugdan.
/// Ingon usa ka sangputanan, pagtawag pananglitan
/// `mem::uninitialized::<bool>()` hinungdan sa dayon nga wala matino nga kinaiya alang sa pagbalik sa usa ka `bool` nga dili siguradong bisan `true` o `false`.
/// Ang labi ka daotan, tinuud nga wala nahibal-an nga panumduman sama sa kung unsa ang gibalik dinhi nga espesyal sa nahibal-an sa tagtipig nga wala kini usa ka pirmi nga kantidad.
/// Gihimo niini nga dili matino nga pamatasan nga adunay uninitialized data sa usa ka variable bisan kung ang variable nga adunay usa ka integer type.
/// (Matikdi nga ang mga lagda sa palibot uninitialized integers wala finalize pa, apan hangtud nga sila, kini mao ang advisable sa paglikay kanila.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang usa ka wala`y hinungdan nga kantidad balido alang sa `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ibalhin ang mga kantidad sa duha nga mga lokasyon nga dili mabalhin, nga wala`y deinitialize nga bisan kinsa sa usa.
///
/// * Kung gusto nimong magbaylo gamit ang usa ka default o kantidad sa dummy, tan-awa ang [`take`].
/// * Kung gusto nimong magbaylo sa usa ka nakapasa nga kantidad, nga ibalik ang daan nga kantidad, tan-awa ang [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KALUWASAN: ang mga hilaw nga mga panudlo gihimo gikan sa luwas nga mabalhin nga mga pakisayran nga nagtagbaw sa tanan
    // mga pagpugong sa `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Gipulihan ang `dest` sa default nga kantidad nga `T`, gibalik ang miaging kantidad nga `dest`.
///
/// * Kung gusto nimong ilisan ang mga kantidad sa duha nga mga variable, tan-awa ang [`swap`].
/// * Kung gusto nimong ilisan ang usa ka gipasa nga kantidad imbis ang default nga kantidad, tan-awa ang [`replace`].
///
/// # Examples
///
/// Usa ka yano nga pananglitan:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` Gitugotan ang pagkuha sa pagpanag-iya sa usa ka uma sa istruktura pinaagi sa pag-ilis niini sa kantidad nga "empty".
/// Kung wala ang `take` mahimo nimo madagan ang mga isyu sama niini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Hinumdomi nga ang `T` dili kinahanglan ipatuman ang [`Clone`], mao nga dili ni mahimo ma-clone ug ma-reset ang `self.buf`.
/// Apan ang `take` mahimong magamit aron maibulag ang orihinal nga kantidad nga `self.buf` gikan sa `self`, nga tugotan kini ibalik:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Gibalhin ang `src` sa pakisayran nga `dest`, nga gibalik ang miaging kantidad nga `dest`.
///
/// Ni ihulog ang kantidad.
///
/// * Kung gusto nimong ilisan ang mga kantidad sa duha nga mga variable, tan-awa ang [`swap`].
/// * Kung gusto nimong ilisan ang usa ka default nga kantidad, tan-awa ang [`take`].
///
/// # Examples
///
/// Usa ka yano nga pananglitan:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` gitugotan ang pagkonsumo sa usa ka istraktura nga uma pinaagi sa pag-ilis niini sa lain nga kantidad.
/// Kung wala ang `replace` mahimo nimo madagan ang mga isyu sama niini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Hinumdomi nga ang `T` dili kinahanglan ipatuman ang [`Clone`], busa dili namon mahimo ang clone `self.buf[i]` aron malikayan ang paglihok.
/// Apan ang `replace` mahimong magamit aron maibulag ang orihinal nga kantidad sa indeks gikan sa `self`, nga tugotan kini ibalik:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KALUWAS: Gibasa namon gikan sa `dest` apan direkta nga gisulat ang `src` ngadto niini pagkahuman,
    // sa ingon ang daang kantidad dili madoble.
    // Wala`y nahulog ug wala dinhi ang mahimo nga panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Mga dispose sa usa ka kantidad
///
/// Gihimo kini pinaagi sa pagtawag sa pagpatuman sa argumento sa [`Drop`][drop].
///
/// Kini epektibo nga wala`y gibuhat alang sa mga lahi nga nagpatuman sa `Copy`, pananglitan
/// integers.
/// Ang ingon nga mga kantidad gikopya ug ang _then_ gibalhin sa pagpaandar, mao nga nagpadayon ang kantidad pagkahuman sa kini nga tawag sa pag-andar.
///
///
/// Kini nga kalihokan dili salamangka;kini literal nga gipasabut ingon
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Tungod kay ang `_x` gibalhin sa pagpaandar, kini awtomatikong gihulog sa wala pa mobalik ang pagpaandar.
///
/// [drop]: Drop
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // tin-aw nga drop sa vector
/// ```
///
/// Tungod kay gipatuman sa [`RefCell`] ang mga lagda sa pagpangutang sa runtime, mahimo nga ipagawas sa `drop` ang [`RefCell`] loan:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // biyaan ang mabalhin nga pahulam sa kini nga slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ang mga integer ug uban pang mga lahi nga nagpatuman sa [`Copy`] wala maapektuhan sa `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // usa ka kopya sa `x` ang gibalhin ug gihulog
/// drop(y); // ang usa ka kopya sa `y` ang mibalhin ug nagpatulo sa
///
/// println!("x: {}, y: {}", x, y.0); // anaa pa gihapon
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Gihubad ang `src` ingon adunay klase nga `&U`, ug pagkahuman gibasa ang `src` nga wala ibalhin ang sulud nga sulud.
///
/// Kini nga pag-andar dili malig-on nga hunahunaon nga ang pointer `src` balido alang sa [`size_of::<U>`][size_of] bytes pinaagi sa pagbalhin sa `&T` sa `&U` ug pagkahuman gibasa ang `&U` (gawas nga kini gibuhat sa usa ka paagi nga husto bisan kung ang `&U` naghimo sa labi ka istrikto nga mga kinahanglanon nga paghanay kaysa `&T`).
/// Kini usab dili luwas nga maghimo usa ka kopya sa sulud nga kantidad sa baylo nga mobalhin sa `src`.
///
/// Dili kini usa ka sayup sa pagtapok sa oras kung ang `T` ug `U` adunay lainlaing gidak-on, apan kini gidasig nga tawgon lamang kini nga kalihokan diin ang `T` ug `U` adunay parehas nga gidak-on.Ang kini nga pag-andar makapukaw sa [undefined behavior][ub] kung ang `U` mas daghan kaysa `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopyaha ang datos gikan sa 'foo_array' ug tagda kini ingon usa ka 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Pag-usab sa mga gikopya data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ang sulod sa 'foo_array' kinahanglan nga dili nausab
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Kung ang U adunay labi ka taas nga kinahanglanon sa paghanay, ang src mahimo nga dili angay nga gihan-ay.
    if align_of::<U>() > align_of::<T>() {
        // KALUWASAN: Ang `src` usa ka pakisayran nga gigarantiyahan nga mahimong balido alang sa mga pagbasa.
        // Kinahanglan nga garantiya sa nanawag nga luwas ang tinuud nga transmutation.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // KALUWASAN: Ang `src` usa ka pakisayran nga gigarantiyahan nga mahimong balido alang sa mga pagbasa.
        // Gisusi ra namon nga ang `src as *const U` husto nga nakahanay.
        // Kinahanglan nga garantiya sa nanawag nga luwas ang tinuud nga transmutation.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Usa ka klase nga opaque nga nagrepresenta sa nagpihig sa us aka enum.
///
/// Kitaa ang pagpaandar sa [`discriminant`] sa kini nga modyul alang sa dugang nga kasayuran.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Kini nga mga pagpatuman sa trait dili makuha tungod kay dili namon gusto ang bisan unsang mga utlanan sa T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Nagbalik usa ka kantidad nga talagsaon nga nagpaila sa variant sa enum sa `v`.
///
/// Kung ang `T` dili usa ka enum, ang pagtawag sa kini nga pag-andar dili magresulta sa wala matino nga pamatasan, apan ang kantidad sa pagbalik dili matino.
///
///
/// # Stability
///
/// Ang diskriminante sa usa ka variant sa enum mahimong magbag-o kung magbag-o ang kahulugan sa enum.
/// Ang usa ka diskriminasyon sa pipila nga lahi dili magbag-o taliwala sa mga panagsama nga adunay parehas nga tagatala.
///
/// # Examples
///
/// Mahimo kini gamiton aron itandi ang mga enum nga nagdala sa datos, samtang wala igsapayan ang tinuud nga datos:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Gibalik ang gidaghanon sa mga lahi sa enum type `T`.
///
/// Kung ang `T` dili usa ka enum, ang pagtawag sa kini nga pag-andar dili magresulta sa wala matino nga pamatasan, apan ang kantidad sa pagbalik dili matino.
/// Parehas, kung ang `T` usa ka enum nga adunay daghang mga lahi kaysa `usize::MAX` ang pagbalik nga kantidad dili matino.
/// Ang mga lahi nga wala`y puy-anan maihap.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}