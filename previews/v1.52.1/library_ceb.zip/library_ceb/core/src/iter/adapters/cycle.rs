use crate::{iter::FusedIterator, ops::Try};

/// Usa ka iterator nga nagbalikbalik nga wala`y katapusan.
///
/// `struct` Kini gibuhat sa [`cycle`] pamaagi sa [`Iterator`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // sa pagbalik-balik iterator mao ang bisan walay sulod o walay katapusan nga
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // hingpit nga pag-usab sa karon nga iterator.
        // kini mao ang gikinahanglan tungod kay `self.iter` mahimong biyaan bisan sa dihang `self.orig` dili
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // makompleto sa usa ka bug-os nga pagbalik-balik, sa pagtuman sa track sa kon ang nagbisikleta iterator mao ang walay sulod o dili.
        // kita kinahanglan nga mobalik sa sayo sa kaso sa usa ka walay sulod nga iterator sa pagpugong sa usa ka walay katapusan nga loop
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Wala'y pag-override sa `fold`, tungod kay ang `fold` wala'y hinungdan alang sa `Cycle`, ug wala kami mahimo bisan unsang labi ka maayo kaysa default.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}