use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Kini nga trait naghatag og transitive access sa tinubdan-stage sa usa ka pipeline interator-adapter sa ilalum sa mga kahimtang nga
/// * ang gigikanan sa iterator `S` mismo nagpatuman sa `SourceIter<Source = S>`
/// * adunay usa ka pagtugyan sa pagpatuman niini nga trait alang sa matag adapter sa pipeline sa taliwala sa mga tinubdan ug sa pipeline consumer.
///
/// Sa diha nga ang tinubdan mao ang usa ka pagpanag-iya iterator magtukod (kasagarang gitawag `IntoIter`) nan kini mahimong mapuslanon alang sa nagbatiran [`FromIterator`] implementar o nagpaayo sa nahibiling mga elemento human sa usa ka iterator nga partially gikapoy.
///
///
/// Matikdi nga implementar sa dili kinahanglan nga adunay sa paghatag og access sa mga sulod nga-labing tinubdan sa usa ka pipeline.Usa ka stateful intermediate adapter mahimo mahinamon pagtimbang-timbang sa usa ka bahin sa pipeline, ug ibutyag ang iyang mga internal nga storage sama sa tinubdan.
///
/// Ang trait mao ang dili luwas tungod kay ang tigpatuman kinahanglan sakdagon dugang nga kabtangan sa kaluwasan.
/// Tan-awa ang [`as_inner`] alang sa mga detalye.
///
/// # Examples
///
/// Pagkuha sa usa ka bahin nga nahurot nga gigikanan:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Usa ka tinubdan stage sa usa ka iterator pipeline.
    type Source: Iterator;

    /// Pagkuha ang tinubdan sa usa ka iterator pipeline.
    ///
    /// # Safety
    ///
    /// Implementar sa sa kinahanglan mobalik sa sama nga mutable pakisayran alang sa ilang tibuok kinabuhi, gawas kon gipulihan sa usa ka caller.
    /// Callers mahimo lamang ilis sa mga pakisayran sa diha nga sila mihunong subli ug ihulog ang iterator pipeline human sa pagkuha sa tinubdan.
    ///
    /// Kini nagpasabut nga ang mga adaptor sa iterator mahimong mosalig sa gigikanan nga dili mausab sa panahon sa pag-ulit apan dili sila makasalig niini sa ilang pagpatuman sa Drop.
    ///
    /// Ang pagpatuman sa kini nga pamaagi nagpasabut nga ang mga adaptor mobiya sa pribado-ra nga pag-access sa ilang gigikanan ug magsalig ra sa mga garantiya nga gihimo pinauyon sa mga lahi sa pamaagi sa tigdawat.
    /// Ang kakulang sa gipugngan nga pag-access nanginahanglan usab nga ang mga adapter kinahanglan ipadayon ang publiko nga API sa gigikanan bisan kung adunay sila access sa sulud niini.
    ///
    /// Callers sa baylo kinahanglan magdahum ang tinubdan nga sa bisan unsa nga kahimtang nga mao ang pinasubay sa iyang mga publiko nga API sukad adapter naglingkod sa taliwala niini, ug sa mga tinubdan sa samang access.
    /// Sa partikular sa usa ka adapter mahimo nga mangaut-ut labaw pa nga mga elemento kay sa hugot nga gikinahanglan.
    ///
    /// Ang kinatibuk-ang tumong sa maong mga kinahanglanon mao nga ang mga consumer sa usa ka pipeline nga paggamit
    /// * bisan unsa nga patayng lawas sa tinubdan human subli nga mihunong
    /// * ang handumanan nga nahimong magamit pinaagi sa pagpaasdang sa usa ka nagaut-ut iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Usa ka iterator adapter nga og output samtang ang nagpahiping iterator og `Result::Ok` mga prinsipyo.
///
///
/// Kon ang usa ka sayop nga nasugatan, ang iterator pag-undang ug ang sayop nga gitipigan.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Iproseso ang gihatag nga iterator nga ingon kung naghatag kini usa ka `T` imbis nga `Result<T, _>`.
/// Sa bisan unsa nga mga sayop mohunong sa sulod iterator ug sa kinatibuk-ang resulta mahimong usa ka sayop.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}