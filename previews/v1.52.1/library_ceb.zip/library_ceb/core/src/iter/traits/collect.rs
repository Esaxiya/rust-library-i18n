/// Ang pagkakabig gikan sa usa ka [`Iterator`].
///
/// Pinaagi sa pagpatuman sa `FromIterator` alang sa usa ka lahi, gihubit nimo kung giunsa kini himuon gikan sa usa ka iterator.
/// Kini mao ang komon alang sa matang nga naghulagway sa usa ka koleksyon sa mga pipila ka mga matang.
///
/// [`FromIterator::from_iter()`] mao panagsa ra nga gitawag tin-aw, ug sa baylo nga gigamit pinaagi sa [`Iterator::collect()`] pamaagi.
///
/// Tan-awa ang [`Iterator::collect()`]'s dokumento alang sa dugang nga mga ehemplo.
///
/// Tan-awa usab: [`IntoIterator`].
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Pinaagi sa paggamit sa [`Iterator::collect()`] sa bug-os sa paggamit `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Pagpatuman sa `FromIterator` alang sa imong tipo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Usa ka sample nga koleksyon, nga usa lamang ka putos sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Atong ihatag niini ang pipila mga pamaagi aron kita sa paghimo sa usa ug sa pagdugang sa mga butang nga niini.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ug kita pagpatuman FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Karon makahimo kita usa ka bag-ong iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... ug sa paghimo sa usa ka MyCollection gikan niini
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // pagkolekta usab mga buhat!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Naghimo usa ka kantidad gikan sa usa ka iterator.
    ///
    /// Tan-awa ang [module-level documentation] alang sa daghan pa.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Ang pagkakabig sa usa ka [`Iterator`].
///
/// Pinaagi sa pagpatuman sa `IntoIterator` alang sa usa ka lahi, gihubit nimo kung giunsa kini mabalhin sa usa ka iterator.
/// Kini mao ang komon alang sa matang nga naghulagway sa usa ka koleksyon sa mga pipila ka mga matang.
///
/// Ang usa ka kaayohan sa pagpatuman sa `IntoIterator` mao ang imong tipo nga [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Tan-awa usab: [`FromIterator`].
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Pagpatuman sa `IntoIterator` alang sa imong tipo:
///
/// ```
/// // Usa ka sample nga koleksyon, nga usa lamang ka putos sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Atong ihatag niini ang pipila mga pamaagi aron kita sa paghimo sa usa ug sa pagdugang sa mga butang nga niini.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ug ipatuman namon ang IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Karon makahimo kami usa ka bag-ong koleksyon ...
/// let mut c = MyCollection::new();
///
/// // ... makadugang sa pipila ka putos niini ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ug unya sa pagpabalik niini ngadto sa usa ka Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Kini mao ang komon sa paggamit sa `IntoIterator` ingon nga usa ka trait bound.Gitugotan nga magbag-o ang tipo sa pagkolekta sa input, basta usa pa kini nga iterator.
/// Dugang nga mga utlanan mahimong bungat pinaagi sa pagpugong sa sa
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Ang tipo sa mga elemento nga gisubli.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kinsa nga lahi sa iterator ang gihimo naton kini?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Naghimo usa ka iterator gikan sa usa ka kantidad.
    ///
    /// Tan-awa ang [module-level documentation] alang sa daghan pa.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Extend sa usa ka koleksyon sa mga sulod sa usa ka iterator.
///
/// Iterators og usa ka serye sa mga prinsipyo, ug mga koleksyon mahimo usab nga naghunahuna sa ingon nga sa usa ka serye sa mga prinsipyo.
/// Ang `Extend` trait tulay niini nga gintang, pagtugot sa kaninyo sa paghatag sa usa ka koleksyon sa lakip na sa mga sulod sa iterator nga.
/// Sa diha nga gitunol sa usa ka koleksyon sa usa ka na sa kasamtangan nga yawe, nga entry ang updated o, sa kaso sa koleksyon nga motugot daghang entries sa managsama nga mga yawe, nga entry ang gisal-ut.
///
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// // Mahimo nimo mapaabot ang usa ka String nga adunay pipila ka mga chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Pagpatuman sa `Extend`:
///
/// ```
/// // Usa ka sample nga koleksyon, nga usa lamang ka putos sa Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Atong ihatag niini ang pipila mga pamaagi aron kita sa paghimo sa usa ug sa pagdugang sa mga butang nga niini.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // sukad sa MyCollection adunay usa ka listahan sa mga i32s, kita pagpatuman Extend sa i32
/// impl Extend<i32> for MyCollection {
///
///     // Kini mao ang usa ka gamay nga simple sa mga kongkreto nga matang pirma: nga kita motawag extend sa bisan unsa nga butang nga mahimong ngadto sa usa ka Iterator nga naghatag kanato i32s.
///     // Tungod kay kita kinahanglan i32s nga ibutang ngadto sa MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // pagpatuman sa kaayo prangka: loop pinaagi sa iterator, ug add() matag elemento sa atong kaugalingon.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // palapdan naton ang aton koleksyon nga may tatlo pa nga numero
/// c.extend(vec![1, 2, 3]);
///
/// // dugang kita niini nga mga elemento ngadto sa katapusan
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Mihatag og usa ka koleksyon sa mga sulod sa usa ka iterator.
    ///
    /// Ingon nga kini mao lamang ang gikinahanglan nga pamaagi alang niini trait, ang [trait-level] docs naglakip sa dugang nga mga detalye.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // Mahimo nimo mapaabot ang usa ka String nga adunay pipila ka mga chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Nagpalugway sa usa ka koleksyon nga adunay eksakto nga usa ka elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Gireserba ang kapasidad sa usa ka koleksyon alang sa gihatag nga ihap sa mga dugang nga elemento.
    ///
    /// Ang default pagpatuman ang walay bisan unsa.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}