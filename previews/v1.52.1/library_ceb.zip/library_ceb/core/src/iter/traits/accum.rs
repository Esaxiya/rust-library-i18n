use crate::iter;
use crate::num::Wrapping;

/// Trait sa pagrepresentar matang nga mahimong gibuhat sa pagsumada sa usa ka iterator.
///
/// trait Kini gigamit sa pagpatuman sa [`sum()`] pamaagi sa iterators.
/// Matang nga sa pagpatuman sa trait mahimong namugna sa [`sum()`] pamaagi.
/// Sama [`FromIterator`] kini trait kinahanglan panagsa ra nga gitawag direkta ug inay nakig sugilanon sa pinaagi sa [`Iterator::sum()`].
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// Pamaagi nga nagkinahanglan sa usa ka iterator ug makamugna `Self` gikan sa mga elemento sa "summing up" sa mga butang.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait sa pagrepresentar matang nga mahimong gibuhat sa pagpadaghan elemento sa usa ka iterator.
///
/// Gigamit kini nga trait aron ipatuman ang [`product()`] nga pamaagi sa mga iterator.
/// Ang mga lahi nga nagpatuman sa trait mahimong makamugna sa pamaagi nga [`product()`].
/// Sama sa [`FromIterator`] kini nga trait kinahanglan kanunay tawgon nga direkta ug sa baylo makig-uban sa [`Iterator::product()`].
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// Pamaagi nga nagkinahanglan sa usa ka iterator ug makamugna `Self` gikan sa mga elemento pinaagi sa pagpadaghan sa mga butang.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// Nagkinahanglan sa matag elemento sa [`Iterator`]: kon kini mao ang usa ka [`Err`], walay dugang nga mga elemento nga nakuha, ug ang mga [`Err`] ang mibalik.
    /// Angay ba nga walay [`Err`] mahitabo, ang kantidad sa tanan nga mga elemento mao ang mibalik.
    ///
    /// # Examples
    ///
    /// Kini kantidad ang tanan nga integer sa usa ka vector, pagsalikway sa kantidad kon ang usa ka negatibo nga elemento ang nasugatan:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// Nagkinahanglan sa matag elemento sa [`Iterator`]: kon kini mao ang usa ka [`Err`], walay dugang nga mga elemento nga nakuha, ug ang mga [`Err`] ang mibalik.
    /// Angay ba nga walay [`Err`] mahitabo, ang produkto sa tanan nga mga elemento mao ang mibalik.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// Gikuha ang matag elemento sa [`Iterator`]: kung kini usa ka [`None`], wala'y dugang nga mga elemento nga gikuha, ug ang [`None`] ibalik.
    /// Angay ba nga walay [`None`] mahitabo, ang kantidad sa tanan nga mga elemento mao ang mibalik.
    ///
    /// # Examples
    ///
    /// Kini kantidad sa posisyon sa kinaiya 'a' sa usa ka vector sa mga kuldas, kon ang usa ka pulong nga wala sa mga kinaiya 'a' sa operasyon mobalik `None`:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// Gikuha ang matag elemento sa [`Iterator`]: kung kini usa ka [`None`], wala'y dugang nga mga elemento nga gikuha, ug ang [`None`] ibalik.
    /// Kinahanglan nga dili mahitabo ang [`None`], ang produkto sa tanan nga mga elemento ibalik.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}