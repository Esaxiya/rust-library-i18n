/// Usa ka iterator nga nahibal-an ang eksakto nga gitas-on niini.
///
/// Daghang mga [`Iterator`] ang wala mahibal-an kung pila ka beses kini mag-iterate, apan ang uban nahibal-an.
/// Kon nahibalo ang usa ka iterator sa unsa nga paagi sa daghang mga higayon kini iterate, paghatag og access sa impormasyon nga mahimong mapuslanon.
/// Pananglitan, kon kamo gusto nga iterate naglakaw, ang usa ka maayo nga pagsugod mao ang mahibalo diin ang katapusan mao ang.
///
/// Kung nagpatuman sa usa ka `ExactSizeIterator`, kinahanglan mo usab ipatuman ang [`Iterator`].
/// Kung gibuhat kini, ang pagpatuman sa [`Iterator::size_hint`]*kinahanglan* ibalik ang eksaktong sukat sa iterator.
///
/// Ang pamaagi nga [`len`] adunay usa ka default nga pagpatuman, busa kasagaran dili nimo kini ipatuman.
/// Apan, aron kamo makahimo sa paghatag og usa ka labaw nga performant pagpatuman kay sa remate, mao importanting kini sa niini nga kaso makahimo sa pagbati.
///
///
/// Mubo nga sulat nga kini nga trait mao ang usa ka luwas nga trait ug sa ingon nga paagi nga dili ug *dili* garantiya nga ang mibalik gitas-on mao ang husto.
/// Kini paagi nga `unsafe` code **dili kinahanglan** mosalig sa sa kahusto sa [`Iterator::size_hint`].
/// Ang mabalhinon ug dili luwas [`TrustedLen`](super::marker::TrustedLen) trait naghatag niining dugang nga garantiya.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// // ang usa ka may kinutuban laing nahibalo kon sa unsa nga paagi sa daghang mga higayon kini iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Sa [module-level docs], implementar kita sa usa ka [`Iterator`], `Counter`.
/// Atong pagpatuman `ExactSizeIterator` alang niini ingon man:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Dali namon makalkula ang nahabilin nga gidaghanon sa mga iterasyon.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ug karon nga kita sa paggamit niini!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Mibalik sa eksaktong gitas-on sa iterator.
    ///
    /// Gisiguro sa pagpatuman nga ang iterator mobalik eksakto nga `len()` nga daghang beses sa usa ka [`Some(T)`] nga kantidad, sa wala pa ibalik ang [`None`].
    ///
    /// Kini nga pamaagi adunay usa ka default nga pagpatuman, mao nga kasagaran dili nimo kini ipatuman nga direkta.
    /// Apan, kon ikaw sa paghatag sa usa ka labaw nga hapsay nga pagpatuman, nga imong mahimo sa pagbuhat sa ingon.
    /// Tan-awa ang [trait-level] docs alang sa usa ka panig-ingnan.
    ///
    /// function Kini nga sa mao usab nga garantiya sa kaluwasan ingon nga ang mga function [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // ang usa ka may kinutuban laing nahibalo kon sa unsa nga paagi sa daghang mga higayon kini iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: pangangkon Kini mao ang sobra depensiba, apan kini nagsusi sa makanunayon
        // gigarantiyahan sa trait.
        // Kon kini nga trait mga rust-internal, kita sa paggamit sa debug_assert !;assert_eq!nga susihon ang tanan nga user implementar sa Rust usab.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Gibalik ang `true` kung ang iterator wala`y sulod.
    ///
    /// Kini nga pamaagi nga adunay usa ka default pagpatuman sa paggamit sa [`ExactSizeIterator::len()`], mao nga kamo dili kinahanglan sa pagpatuman niini sa imong kaugalingon.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}