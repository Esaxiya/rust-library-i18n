// ibaliwala-ayo-filelength Kini nga file hapit eksklusibo nga naglangkob sa kahulugan sa `Iterator`.
// Dili naton kana mabahin sa daghang mga file.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Usa ka interface alang sa pag-atubang sa mga iterator.
///
/// Kini mao ang nag-unang iterator trait.
/// Alang sa dugang mahitungod sa konsepto sa iterators sa kinatibuk-, palihog tan-awa ang [module-level documentation].
/// Sa partikular, nga kamo mahimo nga gusto nga masayud sa unsa nga paagi sa [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Ang tipo sa mga elemento nga gisubli.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Asdang ang iterator ug mobalik sa sunod nga bili.
    ///
    /// Gibalik ang [`None`] kung nahuman na ang pag-ulit.
    /// Tagsa-tagsa nga iterator implementar mahimong mopili sa pagpabalik sa subli, ug sa ingon sa pagtawag `next()` pag-usab mahimo o dili mahimo nga sa ngadto-ngadto magsugod pagbalik [`Some(Item)`] pag-usab sa pipila ka mga punto.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Usa ka tawag sa next() mobalik sa sunod nga bili ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ug pagkahuman Wala bisan usa nahuman na.
    /// assert_eq!(None, iter.next());
    ///
    /// // Dugang tawag mahimo o mahimo nga dili mobalik `None`.Dinhi, sila kanunay nga kabubut-on.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Mibalik ang mga utlanan sa mga nabilin nga gitas-on sa iterator.
    ///
    /// Sa piho nga, `size_hint()` mobalik sa usa ka tuple diin ang unang elemento mao ang ubos-ubos nga gigapos, ug ang ikaduha nga elemento mao ang ibabaw nga ginapos.
    ///
    /// Ang ikaduha nga katunga sa sa tuple nga mibalik ang usa ka [`Option`]`<`[`usize`] `>`.
    /// Usa ka [`None`] dinhi paagi nga sa bisan walay nailhan ibabaw nga gigapos, o sa ibabaw nga gigapos ang mas dako pa kay sa [`usize`].
    ///
    /// # pagpatuman mubo nga mga sulat
    ///
    /// Kini dili ipatuman nga ang usa ka iterator pagpatuman makahatag sa gipahayag gidaghanon sa mga elemento.Ang usa ka iterator sa buggy mahimong makahatag gamay kaysa sa ubos nga gihigot o labaw pa sa taas nga utlanan sa mga elemento.
    ///
    /// `size_hint()` ang pangunang gituyo aron gamiton alang sa optimizations sama sa pagreserba luna alang sa mga elemento sa iterator, apan dili kinahanglan nga misalig sa pananglitan, omit utlanan tseke sa dili luwas code.
    /// Usa ka sayop nga pagpatuman sa `size_hint()` kinahanglan nga dili mosangpot ngadto sa paglapas sa handumanan sa kaluwasan.
    ///
    /// Nga miingon, ang pagpatuman kinahanglan nga mohatag og usa ka husto nga pagbana-bana, tungod kay kon dili kini mahimo nga usa ka paglapas sa trait ni protocol.
    ///
    /// Ang default pagpatuman mobalik `(0: [` None`]`): nga mao ang husto alang sa bisan unsa nga iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Usa ka labi ka komplikado nga pananglitan:
    ///
    /// ```
    /// // Ang parehas nga mga numero gikan sa zero hangtod sa napulo.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // aron kita iterate gikan sa zero ngadto sa napulo ka pilo.
    /// // Kay nahibalo nga kini sa lima ka gayud sa dili mahimo nga walay pagpahamtang filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Atong makadugang lima pa numero uban sa chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // Karon ang parehas nga utlanan nadugangan lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Mibalik `None` alang sa usa ka ibabaw nga gigapos:
    ///
    /// ```
    /// // sa usa ka walay katapusan nga iterator walay ibabaw nga gigapos ug ang maximum nga posible ubos-ubos nga utlanan
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Naglamoy sa iterator, sa pag-ihap sa gidaghanon sa mga iterations ug pagbalik niini.
    ///
    /// Kini nga pamaagi motawag [`next`] balik-balik hangtud [`None`] ang nasugatan, pagbalik sa gidaghanon sa mga higayon kini nakita [`Some`].
    /// Matikdi nga [`next`] ang nga gitawag sa labing menos kausa sa bisan kon ang iterator wala sa bisan unsa nga mga elemento.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Sobra nga Panggawi
    ///
    /// Ang pamaagi dili nagbantay batok sa mga pag-awas, busa ang pag-ihap sa mga elemento sa usa ka iterator nga adunay labaw pa sa [`usize::MAX`] nga mga elemento mahimo nga maggama sa sayup nga sangputanan o panics.
    ///
    /// Kon debug pangangkon makahimo, usa ka panic mao ang garantiya.
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar mahimo og panic kung ang iterator adunay labaw pa sa [`usize::MAX`] nga mga elemento.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Naglamoy sa iterator, pagbalik sa katapusan nga elemento.
    ///
    /// Kini nga pamaagi ang pagtimbang-timbang sa iterator hangtud mobalik kini [`None`].
    /// Samtang sa pagbuhat sa ingon, nagabantay niini sa track sa sa kasamtangan nga elemento.
    /// Human sa [`None`] ang mibalik, `last()` unya mobalik sa katapusan nga elemento niini nakita.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Asdang ang iterator sa `n` elemento.
    ///
    /// Kini nga pamaagi sa maikagong skip `n` elemento pinaagi sa pagtawag sa [`next`] sa `n` panahon hangtud [`None`] ang nasugatan.
    ///
    /// `advance_by(n)` ibalik ang [`Ok(())`][Ok] kung ang iterator malampuson nga nag-uswag sa mga elemento nga `n`, o [`Err(k)`][Err] kung ang [`None`] nakit-an, diin ang `k` mao ang gidaghanon sa mga elemento nga iterator gipaabante sa wala pa mahurot ang mga elemento (ie
    /// ang gitas-on sa iterator).
    /// Matikdi nga `k` mao ang kanunay nga ubos pa kay sa `n`.
    ///
    /// Ang pagtawag sa `advance_by(0)` dili mag-ut-ut sa bisan unsang mga elemento ug kanunay ibalik ang [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` ra ang gilaktawan
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Mobalik ang `n`th elemento sa iterator.
    ///
    /// Sama sa kadaghanan sa mga operasyon sa pag-indeks, ang ihap magsugod gikan sa zero, mao nga ibalik sa `nth(0)` ang una nga kantidad, `nth(1)` ang ikaduha, ug uban pa.
    ///
    /// Mubo nga sulat nga ang tanan nga nag-unang mga elemento, ingon man ang mibalik elemento, nga mangaut-ut gikan sa iterator.
    /// Kana nagpasabut nga ang nangaging mga elemento igasalikway, ug ingon man ang pagtawag sa `nth(0)` daghang beses sa parehas nga iterator nga mobalik sa lainlaing mga elemento.
    ///
    ///
    /// `nth()` ibalik ang [`None`] kung ang `n` mas daghan kaysa o katumbas sa gitas-on sa iterator.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Sa pagtawag `nth()` daghang mga panahon dili balikon kadto nga mga iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Mibalik `None` kon adunay dili kaayo kay sa `n + 1` elemento:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Nagmugna sa usa ka iterator sugod sa samang punto, apan ang paggawas sa gihatag nga kantidad sa matag subli.
    ///
    /// Mubo nga sulat 1: Ang unang elemento sa iterator kanunay mibalik, sa walay pagtagad sa mga lakang nga gihatag.
    ///
    /// Mubo nga sulat 2: Ang panahon sa nga panumbalinga mga elemento nga gibira dili natudlong.
    /// `StepBy` naglihok sama sa han-ay nga `next(), nth(step-1), nth(step-1),…`, apan libre usab nga maggawi sama sa pagkasunud-sunod
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Nga paagi gigamit mahimong mausab alang sa pipila iterators alang sa mga rason nga performance.
    /// Ang ikaduha nga paagi magpauswag sa iterator sa sayo pa ug mahimong mag-ut-ut sa daghang mga butang.
    ///
    /// `advance_n_and_return_first` katumbas sa:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// pamaagi ang panic kon ang gihatag nga lakang mao `0`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Nagkinahanglan sa duha ka iterators ug nagmugna sa usa ka bag-o nga iterator sa duha sa han-ay.
    ///
    /// `chain()` mobalik sa usa ka bag-o nga iterator nga una iterate sa ibabaw sa mga mithi gikan sa unang iterator ug unya sa mga hiyas nga gikan sa ikaduha nga iterator.
    ///
    /// Sa laing mga pulong, nagkonektar kini sa duha ka iterators sa tingub, sa usa ka kadena.🔗
    ///
    /// [`once`] sagad gigamit sa mopahiangay sa usa ka bili ngadto sa usa ka kadena sa ubang mga matang sa subli.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay ang argumento sa `chain()` naggamit [`IntoIterator`], kita moagi sa bisan unsa nga mahimong makabig ngadto sa usa ka [`Iterator`], dili lang sa usa ka [`Iterator`] sa iyang kaugalingon.
    /// Pananglitan, nagpikas (`&[T]`) pagpatuman [`IntoIterator`], ug aron mahimo nga miagi sa `chain()` direkta:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kon pagtrabaho kaninyo uban sa Windows API, ikaw mahimong kinabig [`OsStr`] sa `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips sa' duha ka iterators ngadto sa usa ka ka iterator sa mga nagtinagurha.
    ///
    /// `zip()` mobalik sa usa ka bag-o nga iterator nga iterate sa ibabaw sa laing duha ka iterators, pagbalik sa usa ka tuple diin ang unang elemento moabut gikan sa unang iterator, ug ang ikaduha nga elemento gikan sa ikaduhang iterator.
    ///
    ///
    /// Sa ato pa, nag-zip ang duha nga iterator, nga usa ra.
    ///
    /// Kung ang bisan kinsa nga iterator mobalik [`None`], ang [`next`] gikan sa gi-zip nga iterator ibalik ang [`None`].
    /// Kon ang unang iterator mobalik [`None`], `zip` ang mubo-circuit ug `next` dili pagatawgon sa ikaduhang iterator.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay ang argumento sa `zip()` naggamit [`IntoIterator`], kita moagi sa bisan unsa nga mahimong makabig ngadto sa usa ka [`Iterator`], dili lang sa usa ka [`Iterator`] sa iyang kaugalingon.
    /// Pananglitan, nagpikas (`&[T]`) pagpatuman [`IntoIterator`], ug aron mahimo nga miagi sa `zip()` direkta:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` kanunay gigamit aron ma-zip ang usa ka walay katapusan nga iterator sa usa nga adunay katapusan.
    /// Kini mga buhat tungod kay ang kinutuban iterator sa ngadto-ngadto mobalik [`None`], pagtapos sa zipper.Zipping sa `(0..)` mahimong tan-awon sa usa ka daghan nga sama sa [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Nagmugna sa usa ka bag-o nga iterator nga mga dapit sa usa ka kopya sa `separator` tali sa tapad nga mga butang sa mga orihinal nga iterator.
    ///
    /// Sa kaso `separator` wala pagpatuman [`Clone`] o mga panginahanglan nga kwentahon sa matag panahon, sa paggamit sa [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Ang unang elemento gikan sa `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ang nagbulag.
    /// assert_eq!(a.next(), Some(&1));   // Ang sunod nga elemento gikan sa `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ang nagbulag.
    /// assert_eq!(a.next(), Some(&2));   // Ang katapusan nga elemento gikan sa `a`.
    /// assert_eq!(a.next(), None);       // Natapos na ang iterator.
    /// ```
    ///
    /// `intersperse` mahimong mapuslanon kaayo sa pag-apil sa mga butang sa usa ka iterator ni paggamit sa usa ka komon nga elemento:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Nagmugna sa usa ka bag-o nga iterator nga nagbutang sa usa ka butang nga namugna sa `separator` tali sa tapad nga mga butang sa mga orihinal nga iterator.
    ///
    /// pagsira sa pagatawgon gayud sa makausa sa matag higayon nga ang usa ka butang nga gibutang taliwala sa duha ka tapad mga butang gikan sa nagpahiping iterator;
    /// piho nga, ang pagsira dili tawgon kung ang nagpahiping iterator moani mas mubu sa duha nga mga butang ug pagkahuman ihatag ang ulahi nga butang.
    ///
    ///
    /// Kon ang iterator ni butang galamiton [`Clone`], kini mahimo nga mas sayon sa paggamit sa [`intersperse`].
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Ang una nga elemento gikan sa `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ang nagbulag.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Ang sunod nga elemento gikan sa `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ang nagbulag.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ang katapusan nga elemento gikan sa gikan sa `v`.
    /// assert_eq!(it.next(), None);               // Natapos na ang iterator.
    /// ```
    ///
    /// `intersperse_with` mahimong magamit sa mga sitwasyon diin ang magbulag kinahanglan isipon:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // pagsira sa mutably makahulam sa iyang konteksto aron sa pagmugna sa usa ka butang.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nagkinahanglan og usa ka pagsirado ug nagmugna sa usa ka iterator nga gitawag nga pagsirado sa matag elemento.
    ///
    /// `map()` mousab sa usa ka iterator ngadto sa usa, sa mga paagi sa iyang argumento:
    /// usa ka butang nga nagpatuman sa [`FnMut`].Kini og usa ka bag-o nga iterator nga nagtawag niini nga pagsira sa matag elemento sa orihinal nga iterator.
    ///
    /// Kon ikaw maayo sa paghunahuna sa mga matang, nga kamo mahimo maghunahuna sa `map()` sama niini:
    /// Kung adunay ka usa ka iterator nga makahatag kanimo mga elemento sa pila ka klase nga `A`, ug gusto nimo ang usa ka iterator sa uban pang lahi nga `B`, mahimo nimo gamiton ang `map()`, pagpasa sa usa ka pagsira nga nagkinahanglan usa ka `A` ug ibalik ang usa ka `B`.
    ///
    ///
    /// `map()` sama sa konsepto sa usa ka [`for`] loop.Apan, ingon nga `map()` tapolan, kini labing maayo nga gigamit sa dihang na ikaw nagtrabaho uban sa uban nga iterators.
    /// Kung naghimo ka usa ka klase nga looping alang sa usa ka epekto, giisip kini nga labi ka idiomatiko nga gamiton ang [`for`] kaysa `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kon ikaw sa pagbuhat sa pipila ka mga matang sa epekto, gusto [`for`] sa `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ayaw pagbuhat niini:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // kini dili bisan pa ipakanaug, ingon nga kini mao ang tapolan.Rust pagpasidaan kaninyo mahitungod niini.
    ///
    /// // Hinuon, gamiton alang sa:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Gitawag sa usa ka pagsira sa matag elemento sa usa ka iterator.
    ///
    /// Kini mao ang katumbas sa paggamit sa usa ka [`for`] loop sa iterator, bisan tuod `break` ug `continue` dili posible nga gikan sa usa ka pagsira.
    /// Sa kinatibuk-an labi ka idiomatiko ang paggamit sa usa ka `for` loop, apan ang `for_each` mahimong labi nga mabasa kung giproseso ang mga butang sa katapusan sa mas taas nga mga chain sa iterator.
    ///
    /// Sa pipila ka mga kaso `for_each` mahimo usab nga mas paspas pa kay sa usa ka laang, tungod kay kini gamiton internal subli sa mga adapter sama `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Alang sa usa ka gamay nga pananglitan, ang usa ka `for` loop mahimo nga mas limpyo, apan ang `for_each` mahimo nga labi nga ipadayon ang usa ka estilo nga magamit sa labi ka taas nga mga iterator:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Naghimo usa ka iterator diin naggamit usa ka pagsira aron mahibal-an kung kinahanglan ba ihatag ang usa ka elemento.
    ///
    /// Gihatag ang usa ka elemento sa pagsira kinahanglan mobalik `true` o `false`.Ang mibalik iterator mohatag lamang sa mga elemento nga sa pagsira mobalik tinuod.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay ang pagsira milabay ngadto sa `filter()` nagkinahanglan og usa ka pakisayran, ug sa daghan nga mga iterators iterate sa ibabaw sa mga pakisayran, kini modala ngadto sa usa ka posible nga paglahugay sa sitwasyon, diin ang mga matang sa mga pagsira mao ang usa ka double pakisayran:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // kinahanglan duha * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ni kini nga komon sa sa baylo sa paggamit destructuring sa argumento aron sa paghukas sa sa usa:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // pareho&ug *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o sa duha:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // duha ka &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// sa kini nga mga sapaw.
    ///
    /// Hinumdomi nga ang `iter.filter(f).next()` katumbas sa `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Nagmugna sa usa ka iterator nga ang duha mga pagsala ug mga mapa.
    ///
    /// Ang giuli nga iterator nagahatag lamang sa `mga kantidad` diin ang gihatag nga pagsira sa pagbalik `Some(value)`.
    ///
    /// `filter_map` mahimong gamiton sa paghimo sa mga kadena sa [`filter`] ug [`map`] dugang nga malip-ot.
    /// Ang panig-ingnan sa ubos shows kon sa unsang paagi ang usa ka `map().filter().map()` mahimong on ngadto sa usa ka tawag sa `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ania sa mao usab nga panig-ingnan, apan uban sa [`filter`] ug [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Nagmugna sa usa ka iterator nga naghatag sa kasamtangan nga ihap subli ingon man sa sunod nga bili.
    ///
    /// Ang iterator mibalik abot nagtinagurha `(i, val)`, diin `i` mao ang kasamtangan nga index sa subli ug `val` mao ang bili mibalik sa iterator.
    ///
    ///
    /// `enumerate()` nagpadayon sa pag-ihap ingon usa ka [`usize`].
    /// Kon kamo gusto sa pag-ihap sa usa ka lain-laing mga kadako integer, ang [`zip`] function naghatag og susama nga kalihukan.
    ///
    /// # Sobra nga Panggawi
    ///
    /// pamaagi sa dili pagbantay batok sa moawas, mao nga pagpaila labaw pa kay sa [`usize::MAX`] elemento sa bisan og sa sayop nga resulta o panics.
    /// Kon debug pangangkon makahimo, usa ka panic mao ang garantiya.
    ///
    /// # Panics
    ///
    /// Ang mibalik tingali iterator panic kon ang sa-nga-mibalik index nga magaawas sa usa ka [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Nagmugna sa usa ka iterator nga makagamit [`peek`] sa pagtan-aw sa sunod nga elemento sa iterator nga walay nga nagaut-ut niini.
    ///
    /// Midugang ang usa ka [`peek`] pamaagi sa usa ka iterator.Tan-awa ang dokumentasyon niini alang sa dugang nga kasayuran.
    ///
    /// Matikdi nga ang mga nagpahiping pa iterator ang miabante sa diha nga [`peek`] gitawag sa unang panahon: Aron sa pagkuha sa mga sunod nga elemento, [`next`] gitawag sa nagpahiping iterator, busa bisan unsa nga kiliran sa epekto (ie
    ///
    /// bisan unsa nga butang sa uban nga kay sa paghakot sa mga sunod nga bili) sa [`next`] pamaagi mahitabo.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lets kanato sa pagtan-aw ngadto sa future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // nga kita peek() daghang mga panahon, ang mga iterator dili pag-asdang
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // pagkahuman sa iterator nga nahuman, mao usab ang peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Naghimo usa ka iterator nga ang mga elemento nga [`laktawan`] pinasukad sa us aka predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` nagkinahanglan og usa ka pagsirado ingon nga usa ka argumento.Kini motawag niini nga pagsira sa matag elemento sa iterator, ug wala magtagad sa mga elemento hangtud mobalik kini `false`.
    ///
    /// Human sa `false` ang mibalik, `skip_while()`'s trabaho mao ang sa ibabaw, ug ang uban sa mga elemento nga mitugyan.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay ang pagsira milabay ngadto sa `skip_while()` nagkinahanglan og usa ka pakisayran, ug sa daghan nga mga iterators iterate sa ibabaw sa mga pakisayran, kini modala ngadto sa usa ka posible nga paglahugay sa sitwasyon, diin ang mga matang sa mga pagsira argumento mao ang usa ka double pakisayran:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // kinahanglan duha * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mohunong human sa usa ka inisyal nga `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // samtang kini unta sa bakak, tungod kay kita na na sa usa ka bakak, skip_while() wala gigamit sa bisan unsa nga labaw pa
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Nagmugna sa usa ka iterator nga abot elemento base sa usa ka predicate.
    ///
    /// `take_while()` nagkinahanglan og usa ka pagsirado ingon nga usa ka argumento.Kini motawag niini nga pagsira sa matag elemento sa iterator, ug mohatag sa mga elemento samtang kini mobalik `true`.
    ///
    /// Pagkahuman ibalik ang `false`, ang trabaho nga `take_while()`'s natapos na, ug ang nahabilin nga mga elemento wala panumbalinga.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay ang pagsira milabay ngadto sa `take_while()` nagkinahanglan og usa ka pakisayran, ug sa daghan nga mga iterators iterate sa ibabaw sa mga pakisayran, kini modala ngadto sa usa ka posible nga paglahugay sa sitwasyon, diin ang mga matang sa mga pagsira mao ang usa ka double pakisayran:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // kinahanglan duha * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mohunong human sa usa ka inisyal nga `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Kita labaw pa nga mga elemento nga ubos pa kay sa zero, apan tungod kay kami na na sa usa ka bakak, take_while() wala gigamit sa bisan unsa nga labaw pa
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tungod kay `take_while()` kinahanglan nga motan-aw sa bili aron sa pagtan-aw kon kini kinahanglan nga naglakip o dili, nga nagaut-ut iterators makakita nga kini gikuha:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ang `3` wala na didto, tungod kay nahurot aron mahibal-an kung ang paghunong kinahanglan mohunong, apan wala ibalik sa iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Nagmugna sa usa ka iterator nga ang duha abot elemento base sa usa ka predicate ug mga mapa.
    ///
    /// `map_while()` nagkuha usa ka pagsira ingon usa ka lantugi.
    /// Kini motawag niini nga pagsira sa matag elemento sa iterator, ug mohatag sa mga elemento samtang kini mobalik [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ania sa mao usab nga panig-ingnan, apan uban sa [`take_while`] ug [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mohunong human sa usa ka inisyal nga [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Kita adunay dugang nga mga elemento nga mahimong mohaum sa u32 (4, 5), apan `map_while` mibalik `None` alang sa `-3` (ingon nga ang mga `predicate` mibalik `None`) ug `collect` pag-undang sa unang `None` nasugatan.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Tungod kay ang `map_while()` kinahanglan nga tan-awon ang kantidad aron mahibal-an kung kinahanglan ba nga iupod o dili, ang pagkonsumo sa mga iterator makit-an nga gikuha kini:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ang `-3` dili na didto, tungod kay kini mangaut-ut diha sa aron sa pagtan-aw kon ang subli kinahanglan mohunong, apan wala gibutang balik ngadto sa iterator.
    ///
    /// Hinumdomi nga dili sama sa [`take_while`] kini nga iterator **dili** fuse.
    /// Kini dili usab bungat unsa kining iterator mobalik human sa unang [`None`] ang mibalik.
    /// Kon kinahanglan kamo fused iterator, sa paggamit sa [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Nagmugna sa usa ka iterator nga molukso sa unang `n` elemento.
    ///
    /// Human sila na-ut, ang uban sa mga elemento nga mitugyan.
    /// Kay sa importanting niini nga pamaagi direkta, sa baylo mopatigbabaw sa mga `nth` pamaagi.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Naghimo usa ka iterator nga naghatag sa una nga mga elemento nga `n`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` sagad gigamit uban sa usa ka walay katapusan nga iterator, sa paghimo niini nga may kinutuban:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kon ubos pa kay sa `n` elemento anaa, `take` ang limitahan sa iyang kaugalingon ngadto sa gidak-on sa tinuod nga hinungdan sa iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ang us aka iterator adapter nga parehas sa [`fold`] nga naghupot sa sulud nga estado ug naghimo usa ka bag-ong iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` nagkinahanglan sa duha ka mga argumento: sa usa ka inisyal nga bili nga mga binhi sa mga internal nga kahimtang, ug ang usa ka pagsirado uban sa duha ka mga argumento, ang una nga usa ka mutable paghisgot sa internal nga kahimtang ug ang ikaduha sa usa ka iterator elemento.
    ///
    /// pagsirado mahimong assign sa internal nga kahimtang sa bahin sa estado sa taliwala sa iterations.
    ///
    /// Sa subli, ang pagsira nga apply ngadto sa matag elemento sa iterator ug ang pagbalik bili gikan sa pagsira, usa ka [`Option`], ang mitugyan sa iterator.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // matag pagliwat, padamuon namon ang estado sa elemento
    ///     *state = *state * x;
    ///
    ///     // unya, igahatag namon ang negatibo nga estado
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Nagmugna sa usa ka iterator nga nagabuhat sama sa mapa, apan magpisat dugmonan gambalay.
    ///
    /// Ang [`map`] adapter kaayo mapuslanon, apan lamang sa diha nga ang pagsira argumento og mga mithi.
    /// Kon kini og usa ka iterator sa baylo, may usa ka dugang nga layer sa indirection.
    /// `flat_map()` ang kuhaa kining dugang nga layer sa iyang kaugalingon.
    ///
    /// Ikaw mahimo nga maghunahuna sa `flat_map(f)` ingon sa semantiko katumbas sa [`map`] ping, ug unya [`flatten`] og sama sa `map(f).flatten()`.
    ///
    /// Laing paagi sa paghunahuna mahitungod sa `flat_map()`: [`map`] sa pagsirado mobalik sa usa ka butang alang sa matag elemento, ug `flat_map()`'s closure mobalik sa usa ka iterator alang sa matag elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mobalik sa usa ka iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Nagmugna sa usa ka iterator nga magpisat dugmonan gambalay.
    ///
    /// Kini mapuslanon kung adunay ka usa ka iterator nga iterator o us aka iterator sa mga butang nga mahimo`g mahimo`g iterator ug gusto nimong tangtangon ang usa ka lebel sa pagkagusto.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Pagmapa ug pagkahuman pagpatag:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mobalik sa usa ka iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Mahimo usab-usab kini sa mga termino sa [`flat_map()`], nga mao ang mas maayo sa niini nga kaso tungod kay kini nagpasabot nga katuyoan nga mas tin-aw:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mobalik sa usa ka iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening removes usa lamang ka ang-ang sa nagsalag sa usa ka panahon:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Nakita namon dinhi nga ang `flatten()` wala maghimo usa ka "deep" patag.
    /// Hinunoa, sa usa lamang ka ang-ang sa nesting nga gikuha.Nga mao, kon `flatten()` kamo sa usa ka tulo-ka-dimensional nga gubat, ang resulta mahimong duha ka-dimensional ug dili usa ka-gidak-on.
    /// Aron makakuha usa ka us aka sukod nga istraktura, kinahanglan mo usab nga `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Nagmugna sa usa ka iterator nga natapos human sa unang [`None`].
    ///
    /// Human sa usa ka iterator mobalik [`None`], future tawag mahimo o mahimo nga dili mohatag sa pag-usab [`Some(T)`].
    /// `fuse()` mopahiangay sa usa ka iterator, pagsiguro nga human sa usa ka [`None`] ang gihatag, kini sa kanunay mobalik [`None`] sa walay katapusan.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // sa usa ka iterator nga alternates sa taliwala sa ubang mga ug sa Walay
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // kon kini bisan pa, Some(i32), laing Walay
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // atong makita sa atong iterator mobalik ug sa
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // bisan pa, sa higayon nga fuse naton kini ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // kini sa kanunay mobalik `None` human sa unang panahon.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ba sa usa ka butang sa matag elemento sa usa ka iterator, nga moagi sa bili sa.
    ///
    /// Sa diha nga ang paggamit sa iterators, inyong kanunay nga mokadena pipila kanila sa tingub.
    /// Samtang nagtrabaho sa ingon nga code, tingali gusto nimong susihon kung unsa ang nahinabo sa lainlaing mga bahin sa pipeline.Sa pagbuhat niana, sal-ot sa usa ka tawag sa `inspect()`.
    ///
    /// Kini mas komon alang sa `inspect()` nga gigamit ingon nga usa ka debugging himan kay sa anaa sa imong katapusan nga code, apan aplikasyon mahimong makakaplag niini mapuslanon sa pipila ka mga sitwasyon nga sa diha nga mga sayop nagkinahanglan nga Logged sa wala pa gilabay.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // kini nga iterator ay mao ang komplikado.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // dugangan naton ang pila ka tawag sa inspect() aron maimbestigahan kung unsa ang nahinabo
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Kini imprinta:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logging mga sayop sa dili pa ilabay kanila:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Kini imprinta:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Nagapangutang usa ka iterator, kay sa nga nagaut-ut niini.
    ///
    /// Kini mao ang mapuslanon sa pagtugot sa pagpadapat sa iterator adapters samtang pagbaton pagpanag-iya sa mga orihinal nga iterator.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // kon kita mosulay sa paggamit iter pag-usab, kini dili sa trabaho.
    /// // Ang mosunod nga linya naghatag "sayop: paggamit sa mibalhin bili: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ang ni mosulay nga pag-usab
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // sa baylo, nagdugang kami sa usa ka .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // Karon kini maayo ra:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforms sa usa ka iterator ngadto sa usa ka koleksyon.
    ///
    /// `collect()` mahimo sa bisan unsa nga butang iterable, ug sa pagpabalik niini ngadto sa usa ka may kalabutan nga koleksyon.
    /// Kini usa sa labi ka kusug nga pamaagi sa standard nga librarya, nga gigamit sa lainlaing mga konteksto.
    ///
    /// Ang labing nag-unang mga sumbanan sa nga `collect()` gigamit mao ang sa pagpabalik sa usa ka koleksyon sa usa.
    /// nga ikaw magkuha sa koleksyon, pagtawag [`iter`] sa ibabaw niini, sa pagbuhat sa usa ka hugpong sa mga kausaban, ug unya `collect()` sa katapusan.
    ///
    /// `collect()` mahimo usab nga paghimo higayon sa mga matang nga dili tipikal nga koleksyon.
    /// Pananglitan, ang usa ka [`String`] mahimong gitukod gikan sa [`char`], ug sa usa ka iterator sa [`Result<T, E>`][`Result`] mga butang mahimo nga kolektahon sa `Result<Collection<T>, E>`.
    ///
    /// Tan-awa ang mga pananglitan sa ubus alang sa daghan pa.
    ///
    /// Tungod kay `collect()` mao kinatibuk-an, kini ang hinungdan sa mga problema uban sa type inference.
    /// Sa ingon, `collect()` mao ang usa sa mga pipila ka mga higayon imong makita ang syntax mapinanggaon nga nailhan sa 'turbofish': `::<>`.
    /// Kini makatabang sa inference algorithm makasabut ilabi nga koleksyon ikaw naningkamot sa pagkolekta sa.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Mubo nga sulat nga gikinahanglan kita sa `: Vec<i32>` sa wala-kamot sa kilid.Kini tungod kay makolekta namon, pananglitan, usa ka [`VecDeque<T>`] hinoon:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Pinaagi sa paggamit sa 'turbofish' sa baylo nga sa annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tungod kay `collect()` lamang kahingawa mahitungod sa unsay imong pagkolekta sa, nga kamo mahimo gihapon sa paggamit sa usa ka partial nga matang Timaan, `_`, uban sa turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Paggamit `collect()` aron makahimo usa ka [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Kon ikaw adunay usa ka listahan sa [`moresulta<T, E>`][`Resulta`] s, mahimo nimo gamiton ang `collect()` aron mahibal-an kung adunay bisan usa kanila nga napakyas:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // naghatag kanato sa unang sayop
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // naghatag kanato sa listahan sa mga tubag
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Ut sa usa ka iterator, pagmugna sa duha ka koleksyon gikan niini.
    ///
    /// Ang predicate miagi sa `partition()` makabalik `true`, o `false`.
    /// `partition()` gibalik ang usa ka parisan, tanan nga mga elemento diin gibalik ang `true`, ug ang tanan nga mga elemento diin gibalik ang `false`.
    ///
    ///
    /// Tan-awa usab ang [`is_partitioned()`] ug [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Gisubli ang mga elemento sa kini nga iterator *sa lugar* sumala sa gihatag nga predicate, ingon nga ang tanan nga mobalik sa `true` mag-una sa tanan nga mobalik sa `false`.
    ///
    /// Mobalik ang gidaghanon sa mga `true` mga elemento nga makita.
    ///
    /// Ang paryente aron sa partisyon mga butang dili magpabilin.
    ///
    /// Tan-awa usab sa [`is_partitioned()`] ug [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Ang pagbulag sa lugar taliwala sa mga gabii ug mga kalagmitan
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kita kinahanglan nga mabalaka mahitungod sa ihap nga magaawas?Ang bugtong paagi nga makabaton sa labaw pa kay sa
        // `usize::MAX` mutable mga pakisayran uban sa ZSTs, nga dili mapuslanon sa pagbulag, pagkabahin ...

        // Ang kini nga mga pagsira sa "factory" nga gimbuhaton naglungtad aron malikayan ang pagkamanggihatagon sa `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Balik-balik nga pangitaa ang una nga `false` ug ibaylo kini sa katapusan nga `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Checks kon ang mga elemento niini nga iterator nga pagbahin sumala sa gihatag nga predicate, sama nga ang tanan nga mga nga ang pagbalik `true` una sa tanan nga mga nga ang pagbalik `false`.
    ///
    ///
    /// Tan-awa usab ang [`partition()`] ug [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Bisan ang tanan nga mga butang sa pagsulay `true`, o ang unang hugpong sa mga pulong pag-undang sa `false` ug check kita nga adunay mga wala na `true` mga butang sa tapus nga.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Usa ka pamaagi iterator nga magamit sa usa ka function ingon sa kadugayon nga kini mobalik nga malampuson, og usa ka single, katapusan nga bili.
    ///
    /// `try_fold()` nagkinahanglan sa duha ka mga argumento: usa ka inisyal nga bili, ug ang usa ka pagsirado uban sa duha ka mga argumento: usa ka 'accumulator', ug usa ka elemento.
    /// Ang pagsirado sa bisan malampuson mobalik, uban sa bili nga ang accumulator kinahanglan nga adunay alang sa sunod nga subli, o kini mobalik kapakyasan, uban sa usa ka bili sayop nga propagated balik ngadto sa caller diha-diha dayon (short-circuiting).
    ///
    ///
    /// Ang inisyal nga kantidad mao ang kantidad nga makuha sa nagtitipig sa una nga pagtawag.Kon paggamit sa pagsira milampos batok sa matag elemento sa iterator, `try_fold()` mobalik sa katapusan nga accumulator nga ingon sa kalampusan.
    ///
    /// Nga pagkiyugpos mapuslanon sa matag higayon nga kamo adunay usa ka koleksyon sa mga butang, ug gusto sa pagmugna sa usa ka bili gikan niini.
    ///
    /// # Hinumdomi ang Mga Nagpatuman
    ///
    /// Pipila sa mga uban nga mga pamaagi sa (forward) adunay remate implementar sa sa mga termino sa usa ka niini, mao nga naningkamot sa pagpatuman sa niini nga tin-aw kon kini sa pagbuhat sa butang nga mas maayo pa kay sa default `for` laang pagpatuman.
    ///
    /// Sa partikular, sa pagsulay sa pagbaton niini nga tawag `try_fold()` sa internal nga mga bahin nga gikan nga kini nga iterator gilangkuban.
    /// Kon ang daghang mga tawag gikinahanglan, ang `?` operator mahimong sayon alang sa pagkadena sa sa accumulator bili sa daplin, apan pagbantay sa bisan unsa nga invariants nga panginahanglan nga gituboy sa atubangan niadtong unang mga mobalik.
    /// Kini usa ka pamaagi nga `&mut self`, busa ang pag-ulit kinahanglan nga buhion usab human maigo ang usa ka sayup dinhi.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ang gisusi padron sa tanan nga sa mga elemento sa gubat
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // kantidad Kini nga moawas sa diha nga sa pagdugang sa 100 elemento
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Tungod kay kini mubo-circuited, ang nabilin nga mga elemento anaa pa gihapon pinaagi sa iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Usa ka pamaagi iterator nga magamit sa usa ka masayop function sa matag butang sa iterator, mohunong sa unang sayop ug pagbalik nga sayop.
    ///
    ///
    /// Kini mahimo usab nga naghunahuna sa ingon nga ang masalaypon nga matang sa [`for_each()`] o ingon sa nasyonalidad nga bersyon sa [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Kini mubu sa sirkito, busa ang nahabilin nga mga butang naa pa usab sa iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Toril sa tanan nga elemento ngadto sa usa ka accumulator pinaagi sa pagpadapat sa usa ka operasyon, pagbalik ang katapusan nga resulta.
    ///
    /// `fold()` nagkinahanglan sa duha ka mga argumento: usa ka inisyal nga bili, ug ang usa ka pagsirado uban sa duha ka mga argumento: usa ka 'accumulator', ug usa ka elemento.
    /// Gibalik sa pagsira ang kantidad nga kinahanglan adunay sa nagtigum alang sa sunod nga iterasyon.
    ///
    /// Ang inisyal nga bili mao ang bili sa accumulator adunay sa unang tawag.
    ///
    /// Pagkahuman ipadapat kini nga pagsira sa matag elemento sa iterator, ibalik sa `fold()` ang nagtigum.
    ///
    /// Kini nga operasyon mao ang usahay gitawag 'reduce' o 'inject'.
    ///
    /// Nga pagkiyugpos mapuslanon sa matag higayon nga kamo adunay usa ka koleksyon sa mga butang, ug gusto sa pagmugna sa usa ka bili gikan niini.
    ///
    /// Note: `fold()`, ug sa susamang mga pamaagi nga mitadlas sa tibuok iterator, dili mahimo nga undang alang sa walay kinutuban nga iterators, bisan sa traits alang sa nga sa usa ka resulta mao ang determinable sa may kinutuban nga panahon.
    ///
    /// Note: Ang [`reduce()`] mahimong magamit aron magamit ang una nga elemento ingon ang inisyal nga kantidad, kung ang tipo nga nagtigum ug tipo sa item parehas.
    ///
    /// # Hinumdomi ang Mga Nagpatuman
    ///
    /// Pipila sa mga uban nga mga pamaagi sa (forward) adunay remate implementar sa sa mga termino sa usa ka niini, mao nga naningkamot sa pagpatuman sa niini nga tin-aw kon kini sa pagbuhat sa butang nga mas maayo pa kay sa default `for` laang pagpatuman.
    ///
    ///
    /// Sa partikular, sa pagsulay sa pagbaton niini nga tawag `fold()` sa internal nga mga bahin nga gikan nga kini nga iterator gilangkuban.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ang katibuk-an sa tanan nga mga elemento sa laray
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// paglakaw Atong pinaagi sa matag lakang sa subli dinhi:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ug mao nga, ang atong katapusan nga resulta, `6`.
    ///
    /// ni kini nga komon alang sa mga tawo nga wala gigamit iterators sa usa ka daghan sa paggamit sa usa ka `for` laang sa usa ka listahan sa mga butang nga sa pagtukod sa sa usa ka resulta.Mahimo kana nga `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // alang sa laang:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // parehas sila
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Pagmobu, pagminus sa mga elemento sa usa ka sa usa ka, sa balik-balik nga pagpadapat sa sa usa ka pagkunhod sa operasyon.
    ///
    /// Kung ang iterator wala`y sulod, ibalik ang [`None`];kay kon dili, mobalik ang resulta sa pagkunhod.
    ///
    /// Alang sa mga iterator nga adunay labing menos usa ka elemento, parehas kini sa [`fold()`] nga adunay una nga elemento sa iterator ingon inisyal nga kantidad, gipilo ang matag mosunud nga elemento niini.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Pangitaa ang labing kadaghan nga kantidad:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Mga pagsulay kon ang matag elemento sa iterator matches sa usa ka predicate.
    ///
    /// `all()` nagkinahanglan og usa ka pagsira nga mobalik `true` o `false`.Kini magamit kini nga pagsira sa matag elemento sa iterator, ug kon sila sa tanan nga mobalik `true`, nan mao usab ang `all()`.
    /// Kung adunay bisan kinsa sa kanila nga mobalik `false`, ibalik kini sa `false`.
    ///
    /// `all()` mao ang mubo-circuiting;sa lain nga mga pulong, kini mohunong sa pagproseso sa diha nga kini makakaplag ug usa ka `false`, nga gihatag nga bisan unsa pa ang mahitabo, ang resulta usab `false`.
    ///
    ///
    /// Usa ka walay sulod nga iterator mobalik `true`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Sa paghunong sa unang `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mahimo pa naton gamiton ang `iter`, tungod kay adunay daghang mga elemento.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Mga pagsulay kon sa bisan unsa nga elemento sa iterator matches sa usa ka predicate.
    ///
    /// `any()` nagkinahanglan og usa ka pagsira nga mobalik `true` o `false`.Kini magamit kini nga pagsira sa matag elemento sa iterator, ug kon bisan kinsa kanila mobalik `true`, nan mao usab ang `any()`.
    /// Kon sila mobalik `false`, kini mobalik `false`.
    ///
    /// `any()` mubu sa sirkito;sa lain nga mga pulong, kini mohunong sa pagproseso sa diha nga kini makakaplag ug usa ka `true`, nga gihatag nga bisan unsa pa ang mahitabo, ang resulta usab `true`.
    ///
    ///
    /// Ang usa ka walay sulod nga iterator mobalik `false`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Sa paghunong sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mahimo pa naton gamiton ang `iter`, tungod kay adunay daghang mga elemento.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Pagpangita alang sa usa ka elemento sa usa ka iterator nga nagtagbaw sa usa ka predicate.
    ///
    /// `find()` nagkinahanglan og usa ka pagsira nga mobalik `true` o `false`.
    /// Kini magamit kini nga pagsira sa matag elemento sa iterator, ug kon bisan kinsa kanila mobalik `true`, unya `find()` mobalik [`Some(element)`].
    /// Kon sila mobalik `false`, kini mobalik [`None`].
    ///
    /// `find()` mubu sa sirkito;sa lain nga mga pulong, kini mohunong sa pagproseso sa diha nga ang pagsira mobalik `true`.
    ///
    /// Tungod kay `find()` nagkinahanglan og usa ka pakisayran, ug sa daghan nga mga iterators iterate sa ibabaw sa mga pakisayran, kini modala ngadto sa usa ka posible nga paglahugay sa sitwasyon diin ang mga argumento mao ang usa ka double pakisayran.
    ///
    /// Makita nimo kini nga epekto sa mga pananglitan sa ubus, nga adunay `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Sa paghunong sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mahimo pa naton gamiton ang `iter`, tungod kay adunay daghang mga elemento.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Matikdi nga `iter.find(f)` mao ang katumbas sa `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Magamit function ngadto sa mga elemento sa iterator ug mobalik sa una nga non-walay resulta.
    ///
    ///
    /// `iter.find_map(f)` mao ang katumbas sa `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Magamit function ngadto sa mga elemento sa iterator ug mobalik sa una nga tinuod nga resulta o ang una nga sayop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Gipangita ang usa ka elemento sa usa ka iterator, nga gibalik ang indeks niini.
    ///
    /// `position()` nagkinahanglan og usa ka pagsira nga mobalik `true` o `false`.
    /// Kini magamit kini nga pagsira sa matag elemento sa iterator, ug kon ang usa kanila mobalik `true`, unya `position()` mobalik [`Some(index)`].
    /// Kung ang tanan kanila ibalik ang `false`, ibalik ang [`None`].
    ///
    /// `position()` mubu sa sirkito;sa lain nga mga pulong, kini mohunong sa pagproseso sa diha nga kini makakaplag ug usa ka `true`.
    ///
    /// # Sobra nga Panggawi
    ///
    /// pamaagi sa dili pagbantay batok sa moawas, mao nga kon adunay labaw pa kay sa [`usize::MAX`] non-matching nga mga elemento, kini sa bisan og sa sayop nga resulta o panics.
    ///
    /// Kon debug pangangkon makahimo, usa ka panic mao ang garantiya.
    ///
    /// # Panics
    ///
    /// function Kini nga gahum panic kon ang iterator adunay labaw pa kay `usize::MAX` non-matching nga mga elemento.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Sa paghunong sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mahimo pa naton gamiton ang `iter`, tungod kay adunay daghang mga elemento.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Ang mibalik index nag-agad sa iterator kahimtang
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Pagpangita alang sa usa ka elemento sa usa ka iterator gikan sa too nga, pagbalik index niini.
    ///
    /// `rposition()` nagkinahanglan og usa ka pagsira nga mobalik `true` o `false`.
    /// Kini magamit kini nga pagsira sa matag elemento sa iterator, sugod gikan sa katapusan, ug kon ang usa kanila mobalik `true`, unya `rposition()` mobalik [`Some(index)`].
    ///
    /// Kung ang tanan kanila ibalik ang `false`, ibalik ang [`None`].
    ///
    /// `rposition()` mubu sa sirkito;sa lain nga mga pulong, kini mohunong sa pagproseso sa diha nga kini makakaplag ug usa ka `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Sa paghunong sa unang `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mahimo pa naton gamiton ang `iter`, tungod kay adunay daghang mga elemento.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Walay panginahanglan alang sa usa ka nagaawas check dinhi, tungod kay `ExactSizeIterator` nagpasabot nga ang gidaghanon sa mga elemento pagsinta ngadto sa usa ka `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Mibalik sa maximum elemento sa usa ka iterator.
    ///
    /// Kon sa pipila ka mga elemento parehong maximum, sa katapusan nga elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Gibalik ang minimum nga elemento sa usa ka iterator.
    ///
    /// Kon sa pipila ka mga elemento parehong minimum, ang unang elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Gibalik ang elemento nga naghatag sa labing kadaghan nga kantidad gikan sa gitino nga paglihok.
    ///
    ///
    /// Kon sa pipila ka mga elemento parehong maximum, sa katapusan nga elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Mobalik sa mga elemento nga naghatag sa maximum nga bili uban sa pagtahod ngadto sa espesipikong function pagtandi.
    ///
    ///
    /// Kon sa pipila ka mga elemento parehong maximum, sa katapusan nga elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Mobalik sa mga elemento nga naghatag sa minimum nga bili gikan sa bungat function.
    ///
    ///
    /// Kon sa pipila ka mga elemento parehong minimum, ang unang elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Mobalik sa mga elemento nga naghatag sa minimum nga bili uban sa pagtahod ngadto sa espesipikong function pagtandi.
    ///
    ///
    /// Kon sa pipila ka mga elemento parehong minimum, ang unang elemento nga mibalik.
    /// Kon ang iterator mao ang walay sulod, [`None`] ang mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Kapit direksyon sa usa ka iterator ni.
    ///
    /// Kasagaran, iterators iterate gikan sa wala ngadto sa tuo.
    /// Human sa paggamit sa `rev()`, usa ka kabubut-on iterator sa baylo iterate gikan sa tuo ngadto sa wala.
    ///
    /// Kini mao ang posible nga lamang kon ang iterator adunay usa ka katapusan, busa `rev()` nagtrabaho lamang sa [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Mga kinabig sa usa ka iterator sa nagtinagurha ngadto sa usa ka parisan sa mga sudlanan.
    ///
    /// `unzip()` nag-ut-ut sa us aka iterator nga pares, naghimo duha nga koleksyon: usa gikan sa wala nga elemento sa mga pares, ug usa gikan sa mga husto nga elemento.
    ///
    ///
    /// function Kini mao, sa pipila ka diwa, sa atbang sa [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Naghimo usa ka iterator diin gikopya ang tanan nga mga elemento niini.
    ///
    /// Kini mapuslanon kung adunay ka usa ka iterator nga labaw sa `&T`, apan kinahanglan nimo ang usa ka iterator nga labaw sa `T`.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // gikopya mao ang sama nga ingon sa .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Nagmugna sa usa ka iterator nga [`clone`] sa tanan nga mga elemento niini.
    ///
    /// Kini mapuslanon kung adunay ka usa ka iterator nga labaw sa `&T`, apan kinahanglan nimo ang usa ka iterator nga labaw sa `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // Ang cloned parehas sa .map(|&x| x), alang sa mga integer
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Gisubli sa usa ka iterator hangtod sa hangtod.
    ///
    /// Inay sa mohunong sa [`None`], ang iterator hinoon magsugod pag-usab, gikan sa sinugdanan.Human sa iterating pag-usab, kini magsugod sa sinugdanan sa pag-usab.Ug usab.
    /// Ug usab.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Nagsumaryo sa mga elemento sa usa ka iterator.
    ///
    /// Nagkinahanglan sa matag elemento, midugang kanila, ug mobalik ang resulta.
    ///
    /// Usa ka walay sulod nga iterator mobalik sa zero bili sa matang.
    ///
    /// # Panics
    ///
    /// Kung ang pagtawag sa `sum()` ug usa ka primitive integer type ang ibalik, kini nga pamaagi panic kung ang pag-compute sa overflows ug debug assertions gipaandar.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates sa tibuok iterator, pagpadaghan sa tanan nga mga elemento
    ///
    /// Usa ka walay sulod nga iterator mobalik sa usa ka bili sa matang.
    ///
    /// # Panics
    ///
    /// Sa diha nga sa pagtawag sa `product()` ug sa usa ka karaang matang integer ang mibalik, pamaagi ang panic kon ang pagsuma moawas ug debug pangangkon nga nakahimo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) nagtandi sa mga elemento niini nga [`Iterator`] uban sa laing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) nagtandi sa mga elemento niini nga [`Iterator`] uban sa mga sa usa uban sa pagtahod ngadto sa espesipikong function pagtandi.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) nagtandi sa mga elemento niini nga [`Iterator`] uban sa laing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) nagtandi sa mga elemento niini nga [`Iterator`] uban sa mga sa usa uban sa pagtahod ngadto sa espesipikong function pagtandi.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Gitino kung ang mga elemento sa kini nga [`Iterator`] parehas sa uban pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Motino kon ang mga elemento niini nga [`Iterator`] mga sama sa mga sa sa usa uban sa pagtahod ngadto sa espesipikong function pagkasama.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Motino kon ang mga elemento niini nga [`Iterator`] mga dili patas nga sa mga sa laing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Gitino kung ang mga elemento sa [`Iterator`] nga kini mao ang [lexicographically](Ord#lexicographical-comparison) mas gamay kaysa sa uban pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Motino kon ang mga elemento niini nga [`Iterator`] mga [lexicographically](Ord#lexicographical-comparison) dili kaayo o itanding sa laing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Motino kon ang mga elemento niini nga [`Iterator`] mga [lexicographically](Ord#lexicographical-comparison) nga mas dako kay sa usa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Motino kon ang mga elemento niini nga [`Iterator`] mga [lexicographically](Ord#lexicographical-comparison) nga labaw pa kay o itanding sa laing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Checks kon ang mga elemento sa iterator niining mga lainlainon.
    ///
    /// Nga mao, alang sa matag elemento `a` ug sa iyang mosunod nga elemento `b`, `a <= b` kinahanglan nga naghupot.Kon ang iterator abot sa tukma gayud zero o usa ka elemento, `true` ang mibalik.
    ///
    /// Hinumdomi nga kung ang `Self::Item` `PartialOrd` ra, apan dili `Ord`, ang gipasabut sa kahitas-an nagpasabut nga kini nga pag-andar nagabalik `false` kung ang bisan unsang duha ka sunod-sunod nga mga butang dili ikatanding.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Checks kon ang mga elemento sa iterator niining mga lainlainon sa paggamit sa gihatag nga comparator function.
    ///
    /// Imbis nga gamiton ang `PartialOrd::partial_cmp`, gigamit sa kini nga function ang gihatag nga `compare` function aron mahibal-an ang pagkasunud sa duha nga elemento.
    /// Gawas sa nga, kini katumbas sa [`is_sorted`];tan-awa ang iyang mga dokumento alang sa dugang nga impormasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Gisusi kung ang mga elemento sa kini nga iterator ba gihan-ay gamit ang gihatag nga mahinungdanong function nga pagkuha.
    ///
    /// Inay sa pagtandi sa mga elemento sa iterator direkta, kini nga function nagtandi sa mga yawe sa mga elemento, sama sa gitinguha sa `f`.
    /// Gawas sa nga, kini katumbas sa [`is_sorted`];tan-awa ang iyang mga dokumento alang sa dugang nga impormasyon.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Kitaa ang [TrustedRandomAccess]
    // Ang dili kasagaran nga ngalan mao ang paglikay sa mga pagbangga sa ngalan sa resolusyon sa pamaagi tan-awa ang #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}