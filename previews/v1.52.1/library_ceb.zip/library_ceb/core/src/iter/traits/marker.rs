/// Usa ka iterator nga kanunay nagpadayon sa pagtugyan sa `None` sa diha nga gikapoy.
///
/// Nagatawag sa sunod sa usa ka fused iterator nga mibalik `None` sa makausa mao ang garantiya sa pagbalik [`None`] pag-usab.
/// trait Kini kinahanglan nga ipatuman sa tanan nga mga iterators nga paggawi niini nga paagi tungod kay kini nagtugot usbaw [`Iterator::fuse()`].
///
///
/// Note: Sa kinatibuk-an, kamo kinahanglan nga dili mogamit sa `FusedIterator` sa generic utlanan kon kamo kinahanglan nga ang usa ka fused iterator.
/// Hinunoa, kamo kinahanglan nga lang sa pagtawag [`Iterator::fuse()`] sa iterator.
/// Kon ang iterator na fused, ang dugang nga [`Fuse`] wrapper mahimong usa ka dili-op nga walay silot performance.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Usa ka iterator nga nagtaho sa usa ka tukma sa gitas-on sa paggamit sa size_hint.
///
/// Ang iterator nagtaho usa ka gidak-on nga timaan diin kini eksakto (ang ubos nga utlanan parehas sa taas nga gihigot), o ang taas nga utlanan mao ang [`None`].
///
/// Ang ibabaw nga utlanan kinahanglan lamang [`None`] kon ang aktuwal nga iterator gitas-on mao ang mas dako pa kay sa [`usize::MAX`].
/// Sa maong kahimtang, ang sa ubos nga gigapos kinahanglan [`usize::MAX`], nga miresulta sa usa ka [`Iterator::size_hint()`] sa `(usize::MAX, None)`.
///
/// Ang iterator kinahanglan maghimo sa ensakto nga gidaghanon sa mga elemento nga gi-report o gibalhin sa wala pa moabut ang katapusan.
///
/// # Safety
///
/// trait Kini kinahanglan lamang ipatuman sa diha nga ang kontrata nga gituboy.
/// Ang mga konsumedor sa kini nga trait kinahanglan susihon ang [`Iterator::size_hint()`]’s sa taas nga utlanan.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Usa ka iterator nga sa diha nga nagahatag sa usa ka butang nga gikuha sa labing menos usa ka elemento gikan sa nagpahiping [`SourceIter`].
///
/// Pagtawag sa bisan unsang pamaagi nga moabante sa iterator, pananglitan
/// [`next()`] o [`try_fold()`], garantiya nga alang sa matag lakang sa labing menos usa ka bili sa nahiilalum tinubdan sa iterator ni nga mibalhin gikan ug ang resulta sa iterator kadena mahimong gisal-ut sa iyang dapit, sa paghunahuna nga structural pagpilit sa tinubdan motugot sa maong usa ka pagsal-ot.
///
/// Sa laing mga pulong niini nga trait nagpakita nga ang usa ka iterator pipeline mahimo nga kolektahon sa dapit.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}