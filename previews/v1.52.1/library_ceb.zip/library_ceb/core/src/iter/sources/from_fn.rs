use crate::fmt;

/// Nagmugna sa usa ka bag-o nga iterator diin ang matag subli nagtawag sa gihatag closure `F: FnMut() -> Option<T>`.
///
/// Gitugotan niini ang paghimo sa usa ka pasadya nga iterator nga adunay bisan unsang pamatasan nga wala gigamit ang labi nga synosex sa verbose sa paghimo sa usa ka gipahinungod nga tipo ug pagpatuman sa [`Iterator`] trait alang niini.
///
/// Matikdi nga ang `FromFn` iterator wala sa paghimo sa mga pagpakaingon mahitungod sa kinaiya sa pagsira, ug busa conservatively wala pagpatuman [`FusedIterator`], o mopalabaw [`Iterator::size_hint()`] gikan sa iyang default `(0, None)`.
///
///
/// pagsira sa makahimo sa paggamit misuhot ug palibot niini aron sa pagsubay sa estado sa tibuok iterations.Depende sa kon sa unsang paagi nga ang iterator gigamit, kini mahimo nga nagkinahanglan specifying sa [`move`] keyword sa pagsira.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Atong pag-implementar sa sa counter iterator gikan sa [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Pagdugang sa among ihap.Kini mao ang ngano nga kita nagsugod sa zero.
///     count += 1;
///
///     // Check sa pagtan-aw kon nang kita nahuman ihap o dili.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Usa ka iterator diin ang matag iterasyon nagtawag sa gihatag nga pagsira nga `F: FnMut() -> Option<T>`.
///
/// Kini nga `struct` gimugna sa [`iter::from_fn()`] function.
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}