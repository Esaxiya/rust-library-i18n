use crate::iter::{FusedIterator, TrustedLen};

/// Nagmugna sa usa ka iterator nga magahatag ug usa ka elemento gayud sa makausa.
///
/// Kini kasagarang gigamit aron mapahiangay ang us aka kantidad sa usa ka [`chain()`] nga uban pang mga lahi sa pagliwat.
/// Tingali ikaw adunay usa ka iterator nga naglangkob sa hapit tanan nga mga butang, apan nga kamo kinahanglan nga usa ka dugang nga espesyal nga kaso.
/// Tingali ikaw adunay usa ka function nga buhat sa iterators, apan nga kamo kinahanglan lamang sa pagproseso sa usa ka bili.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::iter;
///
/// // ang usa ang labing kamingaw nga numero
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // usa ra, kana ra ang makuha naton
/// assert_eq!(None, one.next());
/// ```
///
/// Ang kadena kauban ang laing iterator.
/// Isulti naton nga gusto namon nga iterate ang matag file sa `.foo` nga direktoryo, apan usa usab ang file sa pagsasaayos,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita kinahanglan nga kinabig gikan sa usa ka iterator sa DirEntry-s sa usa ka iterator sa PathBufs, mao nga atong gamiton mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // karon, ang atong iterator lamang alang sa atong config file
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // mokadena ang duha ka iterators ngadto sa usa ka dako nga iterator
/// let files = dirs.chain(config);
///
/// // kini mohatag kanato sa tanan nga mga files sa .foo ingon man sa .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Usa ka iterator nga magahatag ug usa ka elemento gayud sa makausa.
///
/// `struct` Kini gibuhat sa function [`once()`].Tan-awa ang dokumentasyon niini alang sa daghan pa.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}