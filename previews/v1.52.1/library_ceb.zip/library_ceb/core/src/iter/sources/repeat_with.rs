use crate::iter::{FusedIterator, TrustedLen};

/// Naghimo usa ka bag-ong iterator nga nagsubli sa mga elemento sa tipo nga `A` nga walay katapusan pinaagi sa pag-apply sa gihatag nga pagsira, ang repeater, `F: FnMut() -> A`.
///
/// Ang `repeat_with()` function nagtawag sa repeater sa ibabaw ug sa ibabaw sa pag-usab.
///
/// Walay kinutuban nga iterators sama `repeat_with()` sagad nga gigamit sa mga adapter sama [`Iterator::take()`], aron sa paghimo kanila nga may kinutuban.
///
/// Kon ang matang nga elemento sa iterator nga imong gikinahanglan galamiton [`Clone`], ug kini mao ang OK aron sa pagbantay sa tinubdan elemento sa handumanan, nga kamo kinahanglan sa baylo sa paggamit sa [`repeat()`] function.
///
///
/// Usa ka iterator nga gipatungha sa `repeat_with()` dili usa ka [`DoubleEndedIterator`].
/// Kon kinahanglan kamo `repeat_with()` sa pagbalik sa usa ka [`DoubleEndedIterator`], palihug abli sa usa ka GitHub isyu nga nagpatin-aw sa imong paggamit sa kaso.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::iter;
///
/// // ang ni maghunahuna kita adunay pipila ka mga bili sa usa ka matang nga dili `Clone` o nga dili gusto nga makabaton sa handumanan lang pa tungod kay kini mao ang mahal:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // usa ka piho nga bili hangtod sa hangtod:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Paggamit mutation ug adunay katapusan:
///
/// ```rust
/// use std::iter;
///
/// // Gikan sa zeroth hangtod sa ikatulo nga gahum sa duha:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ug karon kita gibuhat
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Usa ka iterator nga gisubli elemento sa matang `A` hangtod sa hangtod pinaagi sa pagpadapat sa mga gihatag closure `F: FnMut() -> A`.
///
///
/// `struct` Kini gibuhat sa function [`repeat_with()`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}