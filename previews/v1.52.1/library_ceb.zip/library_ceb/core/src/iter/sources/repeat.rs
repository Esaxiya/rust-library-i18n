use crate::iter::{FusedIterator, TrustedLen};

/// Naghimo usa ka bag-ong iterator nga walay katapusan nga gisubli ang usa ka elemento.
///
/// Ang `repeat()` function magabutyag sa usa ka single nga bili sa ibabaw ug sa ibabaw sa pag-usab.
///
/// Ang mga walay katapusan nga iterator sama sa `repeat()` kanunay gigamit sa mga adaptor sama sa [`Iterator::take()`], aron mahimo`g katapusan.
///
/// Kon ang matang nga elemento sa iterator nga imong gikinahanglan wala pagpatuman `Clone`, o kon dili nimo gusto nga sa pagtuman sa mga balik-balik nga elemento sa handumanan, nga kamo mahimo sa baylo sa paggamit sa [`repeat_with()`] function.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::iter;
///
/// // ang gidaghanon sa upat ka 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, upat pa
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Pagkahuman sa [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // kana nga ulahi nga pananglitan daghan kaayo sa upat.Atong lamang sa upat ka tiil.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ug karon kita gibuhat
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Usa ka iterator nga nagsubli sa usa ka elemento nga wala`y katapusan.
///
/// `struct` Kini gibuhat sa function [`repeat()`].Tan-awa ang dokumentasyon niini alang sa daghan pa.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}