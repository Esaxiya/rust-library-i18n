use crate::iter::{FusedIterator, TrustedLen};

/// Nagmugna sa usa ka iterator nga hinayng naglakaw samtang og usa ka bili gayud sa makausa pinaagi sa paggamit sa gihatag pagsira.
///
/// Kini sagad nga gigamit sa mopahiangay sa usa ka bili generator ngadto sa usa ka [`chain()`] sa ubang mga matang sa subli.
/// Tingali ikaw adunay usa ka iterator nga naglangkob sa hapit tanan nga mga butang, apan nga kamo kinahanglan nga usa ka dugang nga espesyal nga kaso.
/// Tingali ikaw adunay usa ka function nga buhat sa iterators, apan nga kamo kinahanglan lamang sa pagproseso sa usa ka bili.
///
/// Dili sama sa [`once()`], kini nga function sa hinayng naglakaw samtang makamugna sa bili sa hangyo.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::iter;
///
/// // ang usa ang labing kamingaw nga numero
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // usa ra, kana ra ang makuha naton
/// assert_eq!(None, one.next());
/// ```
///
/// Ang kadena kauban ang laing iterator.
/// Isulti naton nga gusto namon nga iterate ang matag file sa `.foo` nga direktoryo, apan usa usab ang file sa pagsasaayos,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita kinahanglan nga kinabig gikan sa usa ka iterator sa DirEntry-s sa usa ka iterator sa PathBufs, mao nga atong gamiton mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // karon, ang atong iterator lamang alang sa atong config file
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // mokadena ang duha ka iterators ngadto sa usa ka dako nga iterator
/// let files = dirs.chain(config);
///
/// // kini mohatag kanato sa tanan nga mga files sa .foo ingon man sa .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Usa ka iterator nga naghatag usa ka elemento sa tipo nga `A` pinaagi sa pag-apply sa gihatag nga pagsira `F: FnOnce() -> A`.
///
///
/// `struct` Kini gibuhat sa function [`once_with()`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}