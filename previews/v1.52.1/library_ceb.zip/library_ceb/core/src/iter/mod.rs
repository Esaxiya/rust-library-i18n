//! Adunay mahimo`g gawas nga pag-ulit.
//!
//! Kong ikaw sa imong kaugalingon sa usa ka koleksyon sa mga pipila ka mga matang, ug gikinahanglan sa paghimo sa usa ka operasyon sa mga elemento sa miingon collection, inyong madali modagan ngadto sa 'iterators'.
//! Gigamit ang mga Iterator sa idiomatiko nga Rust code, busa angay nga pamilyar sa kanila.
//!
//! Sa wala pa sa pagpatin-aw sa dugang, ang ni pakigpulong kon sa unsang paagi module kini nga estraktura:
//!
//! # Organization
//!
//! module Kini nga kadaghanan organisar pinaagi sa matang:
//!
//! * [Traits] mao ang punoan nga bahin: kini nga traits nagpasabut kung unsang klase nga mga iterator ang anaa ug kung unsa ang mahimo nimo niini.Ang mga pamaagi sa mga traits mga bili sa pagbutang sa pipila ka dugang nga panahon sa pagtuon sa.
//! * [Functions] paghatag pipila nga makatabang nga mga paagi aron makahimo pipila nga sukaranan nga mga iterator.
//! * [Structs] mao ang kanunay nga ang pagbalik matang sa mga nagkalain-laing mga pamaagi sa module niini traits.inyong kasagaran gusto nga motan-aw sa pamaagi nga nagmugna sa `struct`, kay sa `struct` sa iyang kaugalingon.
//! Alang sa dugang nga detalye bahin sa ngano, tan-awa ang '[Implementing Iterator](#implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Mao na!dig Atong ngadto sa iterators.
//!
//! # Iterator
//!
//! Ang kasingkasing ug kalag sa module mao kini ang [`Iterator`] trait.Ang kinauyokan sa [`Iterator`] ingon niini:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Usa ka iterator adunay usa ka pamaagi, [`next`], nga sa diha nga gitawag, mobalik sa usa ka [`Option`]`<Item>`.
//! [`next`] ibalik ang [`Some(Item)`] basta adunay mga elemento, ug kung nahuman na silang tanan, ibalik ang `None` aron ipakita nga nahuman na ang pag-ulit.
//! Ang mga indibidwal nga iterator mahimong mopili nga ipadayon ang pag-iterate, ug busa ang pagtawag sa [`next`] pag-usab mahimo o dili sa katapusan magsugod pagbalik og [`Some(Item)`] pag-usab sa pipila ka mga punto (pananglitan, tan-awa ang [`TryIter`]).
//!
//!
//! Ang tibuuk nga kahulugan sa [Iterator`] lakip ang daghang uban pang mga pamaagi, apan kini mga default nga pamaagi, gitukod sa ibabaw sa [`next`], ug makuha nimo kini nga libre.
//!
//! Iterators usab composable, ug kini ni komon sa kadena kanila sa pagbuhat sa mas komplikado nga mga matang sa pagproseso.Tan-awa ang seksyon sa [Adapters](#adapters) sa ubos alang sa dugang detalye.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Ang tulo ka matang sa subli
//!
//! Adunay tulo ka komon nga mga pamaagi nga makamugna iterators gikan sa usa ka koleksyon:
//!
//! * `iter()`, nga nagsubli sa `&T`.
//! * `iter_mut()`, nga iterates sa `&mut T`.
//! * `into_iter()`, nga iterates sa `T`.
//!
//! Ang lainlaing mga butang sa sumbanan nga librarya mahimong magpatuman sa usa o daghan sa tulo, kung angay.
//!
//! # Implementing Iterator
//!
//! Pagmugna sa usa ka iterator sa imong kaugalingon nga naglakip sa duha ka mga lakang: sa paghimo sa usa `struct` sa paghupot sa estado sa iterator, ug unya implementar sa [`Iterator`] alang sa nga `struct`.
//! Kini ang hinungdan nga adunay daghan nga `mga istr` sa kini nga modyul: adunay usa alang sa matag iterator ug iterator adapter.
//!
//! Himoon naton ang usa ka iterator nga ginganlan `Counter` nga giihap gikan sa `1` hangtod `5`:
//!
//! ```
//! // Una, ang istruktura:
//!
//! /// Usa ka iterator nga importante gikan sa usa ngadto sa lima ka
//! struct Counter {
//!     count: usize,
//! }
//!
//! // gusto namon nga ang among ihap magsugod sa usa, busa dugangan namon ang usa ka new() nga pamaagi aron makatabang.
//! // Kini mao ang dili hugot nga gikinahanglan, apan sayon.
//! // Mubo nga sulat nga magsugod kita `count` sa zero, kita makakita nganong sa `next()`'s pagpatuman sa ubos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Unya, kita pagpatuman `Iterator` alang sa atong `Counter`:
//!
//! impl Iterator for Counter {
//!     // mag-ihap kami uban ang usize
//!     type Item = usize;
//!
//!     // next() mao ra ang kinahanglan nga pamaagi
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Pagdugang sa among ihap.Kini mao ang ngano nga kita nagsugod sa zero.
//!         self.count += 1;
//!
//!         // Check sa pagtan-aw kon nang kita nahuman ihap o dili.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ug karon nga kita sa paggamit niini!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Sa pagtawag [`next`] niini nga paagi gets balik-balik nga.Ang Rust adunay usa ka konstruksyon nga mahimong magtawag sa [`next`] sa imong iterator, hangtod moabut sa `None`.Mangadto sa nga sa sunod.
//!
//! timan-i usab nga `Iterator` naghatag og usa ka remate pagpatuman sa mga pamaagi sama sa `nth` ug `fold` nga pagtawag `next` internally.
//! Apan, kini mao ang posible nga usab sa pagsulat sa usa ka batasan nga pagpatuman sa mga pamaagi sama sa `nth` ug `fold` kon ang usa ka iterator mahimo kompyut kanila nga mas episyente nga walay pagtawag `next`.
//!
//! # `for` galong ug `IntoIterator`
//!
//! ni Rust `for` laang syntax mao ang tinuod asukar alang sa iterators.Ania ang usa ka sukaranan nga pananglitan sa `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! I-print niini ang mga numero usa hangtod lima, matag usa sa ilang kaugalingon nga linya.Apan may namatikdan ka dinhi: wala gyud kami nagtawag bisan unsa sa among vector aron makahimo usa ka iterator.Unsay naghatag?
//!
//! Adunay usa ka trait sa standard librarya sa pagkabig sa usa ka butang ngadto sa usa ka iterator: [`IntoIterator`].
//! Kini trait adunay usa ka pamaagi, [`into_iter`], nga mga kinabig ang butang pagpatuman sa [`IntoIterator`] ngadto sa usa ka iterator.
//! Atong tan-awon pag-usab ang `for` loop nga kana, ug kung unsa kini gibalhin sa tagtipon:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ang Rust de-sugars niini sa:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Una, gitawag namon ang `into_iter()` sa kantidad.Unya, pagpares kita sa iterator nga mobalik, sa pagtawag [`next`] ibabaw ug sa ibabaw hangtud nga makita nato ang usa ka `None`.
//! Sa niana nga punto, kita `break` gikan sa laang, ug kita gihimo iterating.
//!
//! Adunay usa pa ka malalangon nga gamay dinhi: ang standard librarya naglakip sa usa ka makapaikag nga pagpatuman sa [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Sa laing mga pulong, ang tanan [`Iterator`] ni pagpatuman [`IntoIterator`], pinaagi sa lang pagbalik sa ilang mga kaugalingon.Kini nagpasabot duha ka mga butang:
//!
//! 1. Kon ikaw pagsulat sa usa ka [`Iterator`], kamo makahimo sa paggamit niini uban sa usa ka `for` loop.
//! 2. Kon ikaw sa paghimo sa usa ka koleksyon sa, pagpatuman sa [`IntoIterator`] kay kini motugot sa inyong mga koleksyon nga gigamit uban sa `for` loop.
//!
//! # Nagsulti pinaagi sa pakisayran
//!
//! Sukad [`into_iter()`] nagkinahanglan `self` pinaagi sa bili, sa paggamit sa usa ka `for` laang sa iterate sa ibabaw sa usa ka koleksyon sa ut-ot nga koleksyon.Kasagaran, ikaw mahimo nga iterate sa ibabaw sa usa ka koleksyon sa walay nagaut-ut niini.
//! Daghang mga koleksyon nagtanyag mga pamaagi nga naghatag mga iterator labaw sa mga pakisayran, nga naandan nga gitawag nga `iter()` ug `iter_mut()` matag usa:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` gihapon nga gipanag-iya sa niini nga function.
//! ```
//!
//! Kung ang usa ka tipo sa koleksyon nga `C` naghatag `iter()`, kini sagad nagpatuman usab sa `IntoIterator` alang sa `&C`, nga adunay usa ka pagpatuman nga tawagan ra og `iter()`.
//! Ingon man usab, usa ka koleksyon sa `C` nga naghatag `iter_mut()` sa kinatibuk implementar `IntoIterator` alang sa `&mut C` pinaagi sa pagdelegar ngadto sa `iter_mut()`.Naghatag kini usa ka kombenyente nga laktod:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // parehas sa `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama sa `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Samtang daghang mga koleksyon ang nagtanyag `iter()`, dili tanan nagtanyag `iter_mut()`.
//! Pananglitan, ang pagbag-o sa mga yawi sa usa ka [`HashSet<T>`] o [`HashMap<K, V>`] mahimong ibutang ang koleksyon sa usa ka dili parehas nga estado kung ang mga hinungdanon nga hash nagbag-o, busa ang kini nga mga koleksyon nagtanyag ra og `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ang mga pag-andar nga kuhaon usa ka [`Iterator`] ug ibalik ang laing [`Iterator`] kanunay gitawag nga 'iterator adapters', tungod kay kini usa ka porma sa 'adapter
//! pattern'.
//!
//! Komon nga iterator adapters naglakip sa [`map`], [`take`], ug [`filter`].
//! Alang sa dugang, tan-awa ang ilang dokumentasyon.
//!
//! Kon ang usa ka iterator adapter panics, ang iterator mahimong diha sa usa ka dili piho nga (apan sa panumduman nga luwas) estado.
//! Ang kini nga estado dili usab gigarantiyahan nga magpabilin nga pareho sa mga bersyon sa Rust, busa kinahanglan nimo nga likayan ang pagsalig sa eksaktong mga kantidad nga gibalik sa usa ka iterator nga nakurat.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Ang Iterators (ug ang iterator [adapters](#adapters)) mga *tapulan*. Kini nagpasabut nga ang paghimo lang og iterator dili _do_ usa ka buok daghan. Wala gyud mahitabo hangtod nga tawgon nimo ang [`next`].
//! Kini usahay usa ka tinubdan sa kalibog kung naghimo usa ka iterator ra alang sa mga epekto niini.
//! Kay sa panig-ingnan, ang [`map`] pamaagi nagtawag sa usa ka pagsira sa matag elemento kini iterates sa ibabaw sa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dili kini mag-print sa bisan unsang mga kantidad, tungod kay naghimo ra kami usa ka iterator, imbis nga gamiton kini.tighipos ang pagpasidaan kanato mahitungod niini nga matang sa kinaiya:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ang idiom nga paagi sa pagsulat sa usa ka [`map`] alang sa iyang kiliran epekto mao ang sa paggamit sa usa ka `for` loop o pagtawag sa [`for_each`] nga pamaagi:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Ang usa pa nga kasagarang paagi aron masusi ang us aka iterator mao ang paggamit sa [`collect`] nga pamaagi aron makahimo usa ka bag-ong koleksyon.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ang mga Iterator dili kinahanglan nga adunay katapusan.Ingon usa ka pananglitan, ang us aka bukas nga han-ay usa ka walay katapusan nga iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Kini mao ang komon sa paggamit sa [`take`] iterator adapter sa pagpabalik sa usa ka walay katapusan nga iterator ngadto sa usa ka may kinutuban nga usa:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Kini imprinta sa mga numero `0` pinaagi `4`, ang matag sa ilang kaugalingon nga linya.
//!
//! Oso diha sa hunahuna nga mga pamaagi sa walay kinutuban nga iterators, bisan kadtong alang sa nga sa usa ka resulta mahimong determinado mathematically sa may kinutuban nga panahon, dili mahimo nga undang.
//! Sa piho nga paagi, ang mga pamaagi sama sa [`min`], nga sa kinatibuk-an nga kaso nanginahanglan pagtabok sa matag elemento sa iterator, lagmit dili malampuson nga makabalik alang sa bisan unsang wala`y katapusan nga iterator.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O dili!Usa ka walay kinutuban nga loop!
//! // `ones.min()` hinungdan sa usa ka walay kinutuban nga laang, mao nga dili kita makaabot sa niini nga punto!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;