//! Mga paagi aron makahimo usa ka `str` gikan sa bytes slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Gikabig ang usa ka hiwa nga mga byte sa usa ka hiwa nga pisi.
///
/// Ang usa ka string slice ([`&str`]) gihimo sa bytes ([`u8`]), ug usa ka byte slice nga ([`&[u8]`][byteslice]) nga gihimo sa bytes, busa ang kini nga kalihokan nakabig taliwala sa duha.
/// Dili ang tanan nga Byte hiwa mga balido hiwa hilo, Apan: [`&str`] nagkinahanglan nga kini mao ang balido UTF-8.
/// `from_utf8()` pagsusi aron masiguro nga ang mga byte balido nga UTF-8, ug pagkahuman buhaton ang pagkakabig.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Kung nakasiguro ka nga ang byte slice balido nga UTF-8, ug dili nimo gusto nga maabut ang overhead sa validity check, adunay usa ka dili luwas nga bersyon sa kini nga function, ang [`from_utf8_unchecked`], nga adunay parehas nga pamatasan apan gilaktawan ang tseke.
///
///
/// Kung kinahanglan nimo ang `String` imbis nga `&str`, hunahunaa ang [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Tungod kay mahimo nimo nga ibutang-gahin ang usa ka `[u8; N]`, ug mahimo nimo kini kuhaon nga [`&[u8]`][byteslice], kini nga kalihokan usa ka paagi aron adunay usa ka giapud-apod nga string.Adunay pananglitan niini sa mga pananglitan sa seksyon sa ubus.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Mibalik `Err` kon ang ad-ad mao ang dili UTF-8 uban sa usa ka paghulagway nga ingon sa ngano nga ang gihatag ad-ad mao ang dili UTF-8.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::str;
///
/// // pipila ka mga byte, sa usa ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nahibal-an namon nga kini nga mga byte balido, busa gamita ra ang `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Sayup nga mga byte:
///
/// ```
/// use std::str;
///
/// // ang pipila dili balido nga mga byte, sa usa ka vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Tan-awa ang mga doc alang sa [`Utf8Error`] alang sa daghang mga detalye sa mga lahi sa sayup nga mahimo`g ibalik.
///
/// Usa ka "stack allocated string":
///
/// ```
/// use std::str;
///
/// // pipila ka mga byte, sa usa ka stack-gigahin nga array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Nahibal-an namon nga kini nga mga byte balido, busa gamita ra ang `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Lang midagan validation.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Kinabig sa usa ka mutable ad-ad sa bytes sa usa ka mutable hilo ad-ad.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ingon usa ka mabalhinon nga vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ingon sa nahibal-an namon nga kini nga mga byte balido, mahimo namon magamit ang `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Sayup nga mga byte:
///
/// ```
/// use std::str;
///
/// // Ang pila dili balido nga mga byte sa usa ka nabag-o nga vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Tan-awa ang mga doc alang sa [`Utf8Error`] alang sa daghang mga detalye sa mga lahi sa sayup nga mahimo`g ibalik.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Lang midagan validation.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Kinabig sa usa ka ad-ad sa bytes sa usa ka hilo ad-ad sa walay pagsusi nga ang hilo naglakip balido UTF-8.
///
/// Tan-awa ang luwas nga bersyon, [`from_utf8`], alang sa dugang nga kasayuran.
///
/// # Safety
///
/// function Kini mao ang dili luwas tungod kay kini wala pagsusi nga ang bytes milabay sa niini balido UTF-8.
/// Kung kini nga pagpugong nalapas, wala matino nga mga sangputanan nga pamatasan, tungod kay ang nahabilin sa Rust naghunahuna nga ang [`&str`] s mao ang balido nga UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::str;
///
/// // pipila ka mga byte, sa usa ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang mga byte `v` balido nga UTF-8.
    // Nagsalig usab sa `&str` ug `&[u8]` nga adunay parehas nga layout.
    unsafe { mem::transmute(v) }
}

/// Gikabig ang usa ka hiwa nga mga byte sa usa ka hiwa sa pisi nga wala gisusi nga ang sulud adunay sulud nga UTF-8;mutable nga bersyon.
///
///
/// Tan-awa ang dili mausab nga bersyon, [`from_utf8_unchecked()`] alang sa dugang nga impormasyon.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang bytes `v`
    // mga balido UTF-8, sa ingon ang cast sa `*mut str` mao ang luwas.
    // Ingon usab, luwas ang pagpanghimatuud sa pointer tungod kay kana nga panudlo gikan sa usa ka pakisayran nga gigarantiyahan nga mahimong balido alang sa mga pagsulat.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}