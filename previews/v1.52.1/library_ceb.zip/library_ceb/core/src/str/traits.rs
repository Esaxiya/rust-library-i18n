//! Ang pagpatuman sa Trait alang sa `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Nagpatuman sa paghan-ay sa mga kuwerdas.
///
/// Ang mga kuwerdas gisugo nga [lexicographically](Ord#lexicographical-comparison) pinaagi sa ilang mga kantidad nga byte.
/// Gisugo niini ang mga puntos sa code sa Unicode pinahiuyon sa ilang mga posisyon sa mga tsart sa code.
/// Dili kini parehas sa "alphabetical" nga han-ay, nga lainlain sa sinultian ug lugar.
/// Ang paghan-ay sa mga pisi sumala sa mga sumbanan nga gidawat sa kultura nagkinahanglan og datos nga piho sa lokal nga gawas sa sakup sa `str` nga tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Nagpatuman sa operasyon sa pagtandi sa mga lubid.
///
/// Ang mga hilo gitandi sa [lexicographically](Ord#lexicographical-comparison) pinaagi sa ilang mga kantidad nga byte.
/// Gitandi niini ang mga punto sa code sa Unicode pinahiuyon sa ilang mga posisyon sa mga tsart sa code.
/// Dili kini parehas sa "alphabetical" nga han-ay, nga lainlain sa sinultian ug lugar.
/// Ang pagtandi sa mga pisi sumala sa mga sumbanan nga gidawat sa kultura nagkinahanglan og datos nga piho sa lokal nga gawas sa sakup sa `str` nga tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Galamiton substring slicing sa syntax `&self[..]` o `&mut self[..]`.
///
/// Gibalik ang usa ka hiwa sa tibuuk nga pisi, ie, nagbalik `&self` o `&mut self`.Katumbas sa `&kaugalingon [0 ..
/// len] `o`&mut sa kaugalingon [0 ..
/// len]`.
/// Dili sama sa uban nga mga operasyon sa pag-index, wala gayud kini mahimo panic.
///
/// Kini nga operasyon mao ang *O*(1).
///
/// Sa wala pa ang 1.20.0, kini nga mga operasyon sa pag-indeks gisuportahan gihapon sa direkta nga pagpatuman sa `Index` ug `IndexMut`.
///
/// Katumbas sa `&self[0 .. len]` o `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Galamiton substring slicing sa syntax `&self[begin .. end]` o `&mut self[begin .. end]`.
///
/// Pagbalik sa usa ka ad-ad sa mga gihatag nga hilo gikan sa Byte laing [`begin`, `end`).
///
/// Kini nga operasyon mao ang *O*(1).
///
/// Sa wala pa ang 1.20.0, kini nga mga operasyon sa pag-indeks gisuportahan gihapon sa direkta nga pagpatuman sa `Index` ug `IndexMut`.
///
/// # Panics
///
/// Panics kon `begin` o `end` wala itudlo sa sugod Byte timbang, tugbang sa usa ka kinaiya (sama sa gihubit sa `is_char_boundary`), kon `begin > end`, o kon `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // kini ang panic:
/// // Byte 2 bakak sa sulod sa `ö`:
/// // &s [2 ..3];
///
/// // byte 8 naa sa sulud sa `老`&s [1 ..
/// // 8];
///
/// // Byte 100 ang sa gawas sa hilo&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KALUWASAN: gisusi ra kung ang `start` ug `end` naa sa usa ka char border,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            // Kita usab gitan-aw char utlanan, mao nga kini mao ang balido UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: lang gitan-aw nga `start` ug `end` anaa sa usa ka char utlanan.
            // Nahibal-an namon nga ang pointer talagsaon tungod kay nakuha namon kini gikan sa `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KALUWASAN: ginagarantiyahan sa nanawag nga ang `self` naa sa mga utlanan nga `slice`
        // nga nagtagbaw sa tanan nga mga kondisyon alang sa `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: tan-awa ang mga komento sa `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary nagsusi nga ang indeks naa sa [0, .len()] dili magamit pag-usab ang `get` ingon sa taas, tungod sa kasamok sa NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KALUWASAN: gisusi ra kung ang `start` ug `end` naa sa usa ka char border,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Galamiton substring slicing sa syntax `&self[.. end]` o `&mut self[.. end]`.
///
/// Mobalik sa usa ka ad-ad sa mga gihatag nga hilo gikan sa Byte laing [`0`, `end`).
/// Katumbas sa `&self[0 .. end]` o `&mut self[0 .. end]`.
///
/// Kini nga operasyon mao ang *O*(1).
///
/// Sa wala pa ang 1.20.0, kini nga mga operasyon sa pag-indeks gisuportahan gihapon sa direkta nga pagpatuman sa `Index` ug `IndexMut`.
///
/// # Panics
///
/// Ang Panics kung ang `end` wala magtudlo sa pagsugod byte offset sa usa ka karakter (sama sa gipasabut sa `is_char_boundary`), o kung `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: lang gitan-aw nga `end` anaa sa usa ka char utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: lang gitan-aw nga `end` anaa sa usa ka char utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: lang gitan-aw nga `end` anaa sa usa ka char utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Galamiton substring slicing sa syntax `&self[begin ..]` o `&mut self[begin ..]`.
///
/// Gibalik ang usa ka hiwa sa gihatag nga pisi gikan sa byte range [`pagsugod`, `len`).Tumbas sa `&kaugalingon [magsugod ..
/// len] `o`&mut kaugalingon [pagsugod ..
/// len]`.
///
/// Kini nga operasyon mao ang *O*(1).
///
/// Sa wala pa ang 1.20.0, kini nga mga operasyon sa pag-indeks gisuportahan gihapon sa direkta nga pagpatuman sa `Index` ug `IndexMut`.
///
/// # Panics
///
/// Ang Panics kung ang `begin` wala magtudlo sa pagsugod byte offset sa usa ka karakter (sama sa gipasabut sa `is_char_boundary`), o kung `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KALUWASAN: gisusi ra nga ang `start` naa sa usa ka char nga utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KALUWASAN: gisusi ra nga ang `start` naa sa usa ka char nga utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KALUWASAN: ginagarantiyahan sa nanawag nga ang `self` naa sa mga utlanan nga `slice`
        // nga nagtagbaw sa tanan nga mga kondisyon alang sa `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: susama sa `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // KALUWASAN: gisusi ra nga ang `start` naa sa usa ka char nga utlanan,
            // ug nagpasa kami sa usa ka luwas nga pakisayran, busa ang kantidad sa pagbalik usa ra usab.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Nagpatuman sa pag-slice sa substring nga adunay syntax `&self[begin ..= end]` o `&mut self[begin ..= end]`.
///
/// Mobalik sa usa ka ad-ad sa mga gihatag nga hilo gikan sa Byte laing [`begin`, `end`].Katumbas sa `&self [begin .. end + 1]` o `&mut self[begin .. end + 1]`, gawas kung ang `end` adunay labing kadaghan nga kantidad alang sa `usize`.
///
/// Kini nga operasyon mao ang *O*(1).
///
/// # Panics
///
/// Panics kon `begin` wala itudlo sa sugod Byte timbang, tugbang sa usa ka kinaiya (sama sa gihubit sa `is_char_boundary`), kon `end` dili punto sa katapusan Byte timbang, tugbang sa usa ka kinaiya (`end + 1` mao ang bisan usa ka sugod Byte offset o itanding `len`), kon `begin > end`, o kung `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Nagpatuman sa pag-slice sa substring nga adunay syntax `&self[..= end]` o `&mut self[..= end]`.
///
/// Gibalik ang usa ka hiwa sa gihatag nga pisi gikan sa byte range [0, `end`].
/// Katumbas sa `&self [0 .. end + 1]`, gawas kon `end` ang maximum bili alang sa `usize`.
///
/// Kini nga operasyon mao ang *O*(1).
///
/// # Panics
///
/// Ang Panics kung ang `end` wala magtudlo sa katapusan nga byte offset sa usa ka karakter (`end + 1` usa ka pagsugod byte offset sama sa gipasabut sa `is_char_boundary`, o parehas sa `len`), o kung `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse sa usa ka bili gikan sa usa ka hilo
///
/// Ang pamaagi nga `FromStr`'s [`from_str`] kanunay nga gigamit nga implicit, pinaagi sa [`parse`] nga pamaagi sa [`str`].
/// Kitaa ang dokumentasyon ni [`parse`] alang sa mga pananglitan.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` wala sa usa ka tibuok kinabuhi nga sukaranan, ug sa ingon sa imong mahimo lamang parse matang nga wala naglangkob sa usa ka tibuok kinabuhi sukaranan sa ilang mga kaugalingon.
///
/// Sa laing mga pulong, nga imong mahimo sa parse sa usa ka `i32` uban `FromStr`, apan dili usa ka `&i32`.
/// Ikaw mahimo parse sa usa ka magtukod nga naglakip sa usa ka `i32`, apan dili sa usa ka nga naglakip sa usa ka `&i32`.
///
/// # Examples
///
/// Panguna nga pagpatuman sa `FromStr` sa usa ka pananglitan nga `Point` type:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ang nakig-sayop nga mahimo nga namalik gikan sa parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Gipapasar ang usa ka string `s` aron mabalik ang usa ka kantidad sa kini nga lahi.
    ///
    /// Kon parsing molampos, mobalik sa bili sa sulod [`Ok`], kon dili sa diha nga ang hilo maoy mangil-ay pagbalik ang usa ka sayop sa piho nga sa sa sulod [`Err`].
    /// Ang matang sayop mao ang piho nga sa pagpatuman sa trait.
    ///
    /// # Examples
    ///
    /// Basic paggamit sa [`i32`], usa ka matang nga galamiton `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse sa usa ka `bool` gikan sa usa ka hilo.
    ///
    /// Naghatag usa ka `Result<bool, ParseBoolError>`, tungod kay ang `s` mahimo o dili mahimo nga tinuod nga matun-an.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Mubo nga sulat, diha sa daghan nga mga kaso, ang mga `.parse()` pamaagi sa `str` mao ang labaw nga husto nga.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}