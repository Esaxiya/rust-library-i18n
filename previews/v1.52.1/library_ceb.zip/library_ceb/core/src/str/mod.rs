//! Pagmaniobra sa pisi.
//!
//! Alang sa dugang detalye, tan-awa ang [`std::str`] module.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. gikan sa utlanan
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. magsugod <=katapusan
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. utlanan sa kinaiya
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // pangitaa ang kinaiya
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` kinahanglan gayud nga ubos pa kay sa len ug usa ka char utlanan
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Gibalik ang gitas-on sa `self`.
    ///
    /// Kini nga gitas-on naa sa mga byte, dili mga [`char`] o graphemes.
    /// Sa laing mga pulong, kini dili mahimo nga kon unsa ang usa ka tawo giisip sa gitas-on sa pisi.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Mibalik `true` kon `self` adunay usa ka gitas-on sa zero bytes.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Gisusi kung ang `index`-th byte mao ang una nga byte sa usa ka han-ay sa UTF-8 code point o ang katapusan sa pisi.
    ///
    ///
    /// Ang pagsugod ug sa katapusan sa sa pisi (sa diha nga `index== self.len()`) giisip nga mga utlanan.
    ///
    /// Mibalik `false` kon `index` mas labaw pa kay sa `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // pagsugod sa `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // ikaduha nga byte nga `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // ikatulo nga byte nga `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ug len mao ang kanunay nga ok.
        // Pagsulay alang sa 0 tin-aw aron nga kini optimize sa check dali ug skip sa pagbasa sa data hilo alang sa kaso nga.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Kini gamay nga mahiya nga katumbas sa: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Gikabig ang usa ka hiwa sa pisi sa usa ka byte slice.
    /// Sa kinabig sa Byte ad-ad balik ngadto sa usa ka hilo nga ad-ad, sa paggamit sa mga [`from_utf8`] function.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: const tingog tungod kay tamdon kita sa duha ka mga matang sa mga sama nga layout
        unsafe { mem::transmute(self) }
    }

    /// Kinabig sa usa ka mutable hilo ad-ad sa usa ka mutable Byte ad-ad.
    ///
    /// # Safety
    ///
    /// Kinahanglan nga sigurohon sa nanawag nga ang sulud sa hiwa balido nga UTF-8 sa wala pa matapos ang pagpangutang ug gigamit ang nagpahiping `str`.
    ///
    ///
    /// Ang paggamit sa usa ka `str` nga ang sulud dili balido UTF-8 dili matino nga pamatasan.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: ang cast gikan sa `&str` ngadto sa `&[u8]` mao ang luwas sukad `str`
        // adunay parehas nga layout ingon `&[u8]` (ang libstd ra ang makahimo sa kini nga garantiya).
        // Ang pointer dereference mao ang luwas tungod kay kini moabut gikan sa usa ka mutable pakisayran nga mao ang garantiya nga mahimong balido alang sa misulat.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Nakabig usa ka hiwa sa pisi sa usa ka hilaw nga puntos.
    ///
    /// Ingon sa hilo hiwa mao ang usa ka ad-ad sa bytes, ang hilaw pointer puntos sa usa ka [`u8`].
    /// Kini nga pointer magtudlo sa una nga byte sa hiwa sa pisi.
    ///
    /// Kinahanglan nga sigurohon sa nanawag nga ang gibalik nga pointer wala gyud gisulat.
    /// Kung kinahanglan nimo nga mutate ang mga sulud sa hiwa sa pisi, gamita ang [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Kinabig sa usa ka mutable hilo ad-ad sa usa ka hilaw nga pointer.
    ///
    /// Ingon sa hilo hiwa mao ang usa ka ad-ad sa bytes, ang hilaw pointer puntos sa usa ka [`u8`].
    /// Kini nga pointer magtudlo sa una nga byte sa hiwa sa pisi.
    ///
    /// Responsibilidad nimo nga masiguro nga ang hiwa sa pisi nabag-o ra sa us aka paagi nga kini nagpabilin nga balido nga UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Mobalik usa ka subslice nga `str`.
    ///
    /// Kini ang alternatibo nga dili panic sa pag-indeks sa `str`.
    /// Mobalik [`None`] sa matag higayon nga katumbas indexing operasyon buot panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // mga indeks dili sa mga utlanan sa han-ay sa UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // gikan sa utlanan
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Mobalik sa usa ka mutable subslice sa `str`.
    ///
    /// Kini ang alternatibo nga dili panic sa pag-indeks sa `str`.
    /// Mobalik [`None`] sa matag higayon nga katumbas indexing operasyon buot panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // husto nga gitas-on
    /// assert!(v.get_mut(0..5).is_some());
    /// // gikan sa utlanan
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Gibalik ang wala gisusi nga subslice nga `str`.
    ///
    /// Kini ang wala kapilian nga kapilian sa pag-indeks sa `str`.
    ///
    /// # Safety
    ///
    /// Ang mga nanawag sa kini nga gimbuhaton responsable nga kini nga mga precondition matagbaw:
    ///
    /// * Ang indeks sa pagsugod kinahanglan dili molapas sa katapusan nga indeks;
    /// * Ang mga indeks kinahanglan naa sa sulod sa mga utlanan sa orihinal nga hiwa;
    /// * Ang mga indeks kinahanglan ibutang sa mga utlanan sa han-ay sa UTF-8.
    ///
    /// Ang pagkapakyas niana, ang giuli nga hiwa sa pisi mahimo nga magrepresentar sa dili balido nga memorya o makalapas sa mga invariant nga gipahibalo sa `str` nga tipo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // KALUWASAN: kinahanglan nga ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `get_unchecked`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Mobalik sa usa ka mutable, dili mapugngan subslice sa `str`.
    ///
    /// Kini ang wala kapilian nga kapilian sa pag-indeks sa `str`.
    ///
    /// # Safety
    ///
    /// Ang mga nanawag sa kini nga gimbuhaton responsable nga kini nga mga precondition matagbaw:
    ///
    /// * Ang indeks sa pagsugod kinahanglan dili molapas sa katapusan nga indeks;
    /// * Ang mga indeks kinahanglan naa sa sulod sa mga utlanan sa orihinal nga hiwa;
    /// * Ang mga indeks kinahanglan ibutang sa mga utlanan sa han-ay sa UTF-8.
    ///
    /// Ang pagkapakyas niana, ang giuli nga hiwa sa pisi mahimo nga magrepresentar sa dili balido nga memorya o makalapas sa mga invariant nga gipahibalo sa `str` nga tipo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `get_unchecked_mut`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Naghimo usa ka hiwa sa pisi gikan sa lain nga hiwa sa pisi, giagi ang mga tseke sa kahilwasan.
    ///
    /// Kini kasagarang dili girekomendar, sa paggamit uban sa Pasidaan!Alang sa usa ka luwas nga kapilian tan-awa ang [`str`] ug [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ang kini nga bag-ong hiwa gikan sa `begin` hangtod `end`, lakip ang `begin` apan wala`y labot ang `end`.
    ///
    /// Aron makakuha usa ka mabalhin nga hiwa sa pisi, tan-awa ang pamaagi nga [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Callers sa niini nga function mao ang responsable nga tulo ka gikinahanglan nga mga matagbaw:
    ///
    /// * `begin` kinahanglan dili molapas sa `end`.
    /// * `begin` ug `end` kinahanglan mga byte nga posisyon sa sulud sa hiwa sa pisi.
    /// * `begin` ug `end` kinahanglan maghigda sa mga utlanan sa han-ay sa UTF-8.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // KALUWASAN: kinahanglan nga ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `get_unchecked`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Naghimo usa ka hiwa sa pisi gikan sa lain nga hiwa sa pisi, giagi ang mga tseke sa kahilwasan.
    /// Kini kasagarang dili girekomendar, sa paggamit uban sa Pasidaan!Alang sa usa ka luwas nga kapilian tan-awa ang [`str`] ug [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ang kini nga bag-ong hiwa gikan sa `begin` hangtod `end`, lakip ang `begin` apan wala`y labot ang `end`.
    ///
    /// Aron makakuha usa ka dili mabalhin nga hiwa sa pisi, tan-awa ang pamaagi nga [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Callers sa niini nga function mao ang responsable nga tulo ka gikinahanglan nga mga matagbaw:
    ///
    /// * `begin` kinahanglan dili molapas sa `end`.
    /// * `begin` ug `end` kinahanglan mga byte nga posisyon sa sulud sa hiwa sa pisi.
    /// * `begin` ug `end` kinahanglan maghigda sa mga utlanan sa han-ay sa UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `get_unchecked_mut`;
        // ang ad-ad mao ang dereferencable tungod kay `self` mao ang usa ka luwas nga pakisayran.
        // Ang mibalik pointer mao ang luwas tungod kay impls sa `SliceIndex` nga garantiya nga kini mao ang.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Bahina ang usa ka hiwa nga pisi sa duha sa usa ka indeks.
    ///
    /// Ang lantugi, `mid`, kinahanglan usa ka byte offset gikan sa pagsugod sa pisi.
    /// kinahanglan usab kini sa ibabaw sa utlanan sa usa ka code punto UTF-8.
    ///
    /// Ang duha ka mga hiwa mibalik go gikan sa pagsugod sa hilo ad-ad sa `mid`, ug gikan sa `mid` ngadto sa katapusan sa sa pisi ad-ad.
    ///
    /// Aron makuha ang mga mutable nga hiwa sa pisi, tan-awa ang pamaagi nga [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics kon `mid` dili sa usa ka UTF-8 code punto utlanan, o kon kini mao ang milabay nga sa katapusan sa katapusan nga code nga punto sa hilo ad-ad.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary nagsusi nga ang indeks naa sa [0, .len()]
        if self.is_char_boundary(mid) {
            // KALUWASAN: gisusi ra nga ang `mid` naa sa usa ka char nga utlanan.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Bahina ang us aka mutable nga hiwa nga pisi sa duha sa usa ka indeks.
    ///
    /// Ang lantugi, `mid`, kinahanglan usa ka byte offset gikan sa pagsugod sa pisi.
    /// kinahanglan usab kini sa ibabaw sa utlanan sa usa ka code punto UTF-8.
    ///
    /// Ang duha ka mga hiwa mibalik go gikan sa pagsugod sa hilo ad-ad sa `mid`, ug gikan sa `mid` ngadto sa katapusan sa sa pisi ad-ad.
    ///
    /// Aron makuha ang dili mabalhin nga mga hiwa sa pisi, tan-awa ang pamaagi nga [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics kon `mid` dili sa usa ka UTF-8 code punto utlanan, o kon kini mao ang milabay nga sa katapusan sa katapusan nga code nga punto sa hilo ad-ad.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary nagsusi nga ang indeks naa sa [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // KALUWASAN: gisusi ra nga ang `mid` naa sa usa ka char nga utlanan.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Gibalik ang usa ka iterator sa mga [`char`] s sa usa ka hiwa sa pisi.
    ///
    /// Ingon sa usa ka hilo ad-ad naglangkob sa balido UTF-8, kita iterate pinaagi sa usa ka hilo ad-ad sa [`char`].
    /// Gipabalik sa kini nga pamaagi ang ingon usa ka iterator.
    ///
    /// Mahinungdanon nga hinumdoman nga ang [`char`] nagrepresentar sa usa ka Halaga sa Unicode Scalar, ug mahimong dili pareho sa imong ideya kung unsa ang usa ka 'character'.
    ///
    /// Subli sa grapemo bulig mahimong unsa ang imong tinuod nga gusto.
    /// kalihukan Kini dili nga gihatag sa standard librarya ni Rust, check crates.io sa baylo.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Hinumdomi, ang [`char`] s dili pareho sa imong intuition bahin sa mga karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // dili 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Gibalik ang usa ka iterator sa mga [`char`] s sa usa ka hiwa sa pisi, ug ang ilang mga posisyon.
    ///
    /// Ingon sa usa ka hilo ad-ad naglangkob sa balido UTF-8, kita iterate pinaagi sa usa ka hilo ad-ad sa [`char`].
    /// Kini nga pamaagi mobalik sa usa ka iterator sa duha niini nga mga [`char`] s, ingon man sa ilang Byte mga posisyon.
    ///
    /// Ang iterator nagahatag tupi.Una ang posisyon, ang [`char`] ikaduha.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Hinumdomi, ang [`char`] s dili pareho sa imong intuition bahin sa mga karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // dili (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // timan-i ang 3 dinhi, sa katapusan nga kinaiya mikuha sa duha ka bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Usa ka iterator sa mga byte sa usa ka slice nga hilo.
    ///
    /// Ingon usa ka hiwa sa pisi nga gilangkoban sa usa ka han-ay sa mga byte, mahimo namon nga iterate pinaagi sa usa ka hiwa sa pisi sa byte
    /// Gipabalik sa kini nga pamaagi ang ingon usa ka iterator.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Magabugha usa ka hilo ad-ad sa whitespace.
    ///
    /// iterator Ang mibalik mobalik hilo hiwa nga sub-hiwa sa mga orihinal nga hilo nga ad-ad, mibulag sa bisan unsa nga kantidad sa whitespace.
    ///
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    /// Kon kamo gusto nga lamang sa split sa ASCII whitespace sa baylo, sa paggamit sa [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ang tanan nga lahi sa whitespace gikonsiderar:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Magabugha usa ka hilo ad-ad sa ASCII whitespace.
    ///
    /// Ang nagbalik nga iterator ibalik ang mga hiwa sa pisi nga mga sub-hiwa sa orihinal nga hiwa sa pisi, nga gilain sa bisan unsang kantidad sa puti nga ASCII.
    ///
    ///
    /// Sa baylo nga bahinon sa Unicode `Whitespace`, gamita ang [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ang tanan nga lahi sa puti nga ASCII gikonsiderar:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Usa ka iterator ibabaw sa mga linya sa usa ka pisi, sama sa hilo hiwa.
    ///
    /// Ang mga linya gitapos sa bisan hain sa usa ka bag-ong linya nga (`\n`) o usa ka pagbalik sa karwahe nga adunay linya nga feed (`\r\n`).
    ///
    /// Ang katapusan nga pagtapos sa linya kapilian.
    /// Ang usa ka pisi nga natapos sa usa ka katapusan nga linya nga natapos mobalik sa parehas nga mga linya ingon usa ka managsama nga pisi nga wala`y katapusan nga linya nga natapos.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Dili kinahanglan ang katapusan nga pagtapos sa linya:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Usa ka iterator ibabaw sa mga linya sa usa ka hilo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Mobalik sa usa ka iterator sa `u16` sa ibabaw sa hilo encoded ingon UTF-16.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Gibalik ang `true` kung ang gihatag nga sumbanan motugma sa usa ka sub-slice sa kini nga slice sa string.
    ///
    /// Mibalik `false` kon kini dili.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Gibalik ang `true` kung ang gihatag nga sumbanan motugma sa usa ka pag-una sa kini nga hiwa sa pisi.
    ///
    /// Mibalik `false` kon kini dili.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Gibalik ang `true` kung ang gihatag nga sumbanan mohaum sa usa ka hulapi sa kini nga hiwa sa pisi.
    ///
    /// Mibalik `false` kon kini dili.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Mibalik ang Byte index sa unang kinaiya niini nga hilo ad-ad nga motakdo sa sumbanan.
    ///
    /// Gibalik ang [`None`] kung ang sumbanan dili magkatugma.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Labi ka komplikado nga mga sundanan gamit ang estilo nga wala`y punto ug pagsira:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Wala pagpangita sa sundanan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Gibalik ang byte index alang sa unang karakter sa labing tuo nga sukwahi sa sundanan sa kini nga hiwa sa pisi.
    ///
    /// Gibalik ang [`None`] kung ang sumbanan dili magkatugma.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Mas komplikado nga mga sumbanan uban sa closures:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Wala pagpangita sa sundanan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Usa ka iterator sa substrings sa kini nga slice sa string, nga gibulag sa mga karakter nga gipares sa usa ka pattern.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang gipabalik nga iterator mahimong usa ka [`DoubleEndedIterator`] kung ang sumbanan nagtugot sa usa ka reverse search ug ang pagpangita sa forward/reverse nagahatag parehas nga mga elemento.
    /// Tinuod kini alang sa, pananglitan, [`char`], apan dili alang sa `&str`.
    ///
    /// Kung ang sumbanan nagtugot sa usa ka pag-usab nga pagpangita apan ang mga sangputanan niini mahimo nga magkalainlain gikan sa usa ka unahan nga pagpangita, mahimong magamit ang [`rsplit`] nga pamaagi.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Kung ang sundanan usa ka slice of chars, pagbahinbahin sa matag panghitabo sa bisan unsang mga karakter:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Kon ang usa ka hilo naglakip sa daghang kasikbit separators, ikaw matapos sa uban nga walay sulod kuldas sa output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Kasikbit separators nagkabulag sa walay sulod nga hilo.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ang mga managbulag sa pagsugod o katapusan sa usa ka pisi silingan sa mga walay sulod nga lubid.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Sa diha nga ang walay sulod nga hilo gigamit ingon nga sa usa ka separator, kini nagbulag sa matag kinaiya diha sa pisi, uban sa mga sinugdanan ug sa katapusan sa sa pisi.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Kasikbit separators modala ngadto sa posible ikatingala nga kinaiya sa diha nga whitespace gigamit ingon nga ang separator.Husto kini nga code:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Naghatag kanimo ang _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Paggamit [`split_whitespace`] alang sa kini nga pamatasan.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Usa ka iterator sa substrings sa kini nga slice sa string, nga gibulag sa mga karakter nga gipares sa usa ka pattern.
    /// Lainlain gikan sa iterator nga gihimo sa `split` sa kana nga `split_inclusive` nga gibilin ang katugbang nga bahin ingon ang terminator sa substring.
    ///
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Kung ang katapusang elemento sa pisi gitugma, kana nga elemento maisip nga terminator sa nag-una nga substring.
    /// Kana nga substring mao ang katapusan nga butang nga ibalik sa iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Usa ka iterator sa substrings sa gihatag nga hilo nga ad-ad, mibulag sa mga karakter nga nakigtagbo sa usa ka sumbanan ug mitugyan sa reverse order.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Gikinahanglan sa giuli nga iterator nga gisuportahan sa sumbanan ang usa ka pag-usab nga pagpangita, ug kini mahimong usa ka [`DoubleEndedIterator`] kung ang usa ka pagpangita nga forward/reverse makahatag parehas nga mga elemento.
    ///
    ///
    /// Alang sa pag-iterate gikan sa atubangan, mahimong gamiton ang [`split`] nga pamaagi.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Usa ka iterator sa substrings sa gihatag nga slice sa string, nga gibulag sa mga karakter nga gipares sa usa ka sumbanan.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Katumbas sa [`split`], gawas nga ang trailing substring gilaktawan kung wala`y sulod.
    ///
    /// [`split`]: str::split
    ///
    /// Kini nga pamaagi mahimong gamiton alang sa hilo data nga mao _terminated_, kay sa _separated_ sa usa ka sumbanan.
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang gipabalik nga iterator mahimong usa ka [`DoubleEndedIterator`] kung ang sumbanan nagtugot sa usa ka reverse search ug ang pagpangita sa forward/reverse nagahatag parehas nga mga elemento.
    /// Tinuod kini alang sa, pananglitan, [`char`], apan dili alang sa `&str`.
    ///
    /// Kon ang sumbanan nagtugot sa usa ka reverse search apan resulta niini tingali lahi gikan sa usa ka sa unahan search, ang [`rsplit_terminator`] pamaagi mahimong gamiton.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Usa ka iterator sa substrings sa `self`, nga gibulag sa mga karakter nga giparis sa us aka sumbanan ug ninghatag sa reverse order.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Katumbas sa [`split`], gawas nga ang trailing substring gilaktawan kung wala`y sulod.
    ///
    /// [`split`]: str::split
    ///
    /// Kini nga pamaagi mahimong gamiton alang sa hilo data nga mao _terminated_, kay sa _separated_ sa usa ka sumbanan.
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang mibalik iterator nagkinahanglan nga ang sumbanan nagsuporta sa usa ka reverse search, ug kini doble nga natapos kon ang usa ka forward/reverse search makahatag sa sama nga mga elemento.
    ///
    ///
    /// Kay iterating gikan sa atubangan, sa [`split_terminator`] pamaagi mahimong gamiton.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Usa ka iterator sa substrings sa gihatag nga slice sa string, gibulag sa usa ka sundanan, gikutuban sa pagbalik sa kadaghanan nga mga item nga `n`.
    ///
    /// Kung ang `n` substrings ibalik, ang katapusan nga substring (ang `n`th substring) maglangkob sa nahabilin sa pisi.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang mibalik iterator dili double natapus na, tungod kay kini dili hapsay nga sa pagsuporta sa.
    ///
    /// Kon ang sumbanan nagtugot sa usa ka reverse search, ang [`rsplitn`] pamaagi mahimong gamiton.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Usa ka iterator sa substrings sa kini nga slice sa string, gibulag sa us aka sumbanan, sugod sa katapusan sa pisi, gikutuban sa pagbalik sa kadaghanan nga mga item nga `n`.
    ///
    ///
    /// Kung ang `n` substrings ibalik, ang katapusan nga substring (ang `n`th substring) maglangkob sa nahabilin sa pisi.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang mibalik iterator dili double natapus na, tungod kay kini dili hapsay nga sa pagsuporta sa.
    ///
    /// Kay natipak gikan sa atubangan, sa [`splitn`] pamaagi mahimong gamiton.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Gibahinbahin ang pisi sa una nga paglitaw sa gitumbok nga delimiter ug gibalik ang unahan sa wala pa ang delimiter ug suffix pagkahuman sa delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Magabugha sa pisi sa katapusan nga panghitabo sa bungat delimiter ug mobalik prefix sa atubangan sa delimiter ug suffix human sa delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Usa ka iterator sa ibabaw sa disjoint motakdo sa usa ka sumbanan sa sulod sa gihatag nga hilo ad-ad.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang gipabalik nga iterator mahimong usa ka [`DoubleEndedIterator`] kung ang sumbanan nagtugot sa usa ka reverse search ug ang pagpangita sa forward/reverse nagahatag parehas nga mga elemento.
    /// Tinuod kini alang sa, pananglitan, [`char`], apan dili alang sa `&str`.
    ///
    /// Kung ang sumbanan nagtugot sa usa ka pag-usab nga pagpangita apan ang mga sangputanan niini mahimo nga magkalainlain gikan sa usa ka unahan nga pagpangita, mahimong magamit ang [`rmatches`] nga pamaagi.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Usa ka iterator sa ibabaw sa disjoint motakdo sa usa ka sumbanan sa sulod niini nga hilo ad-ad, mitugyan sa reverse order.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Gikinahanglan sa giuli nga iterator nga gisuportahan sa sumbanan ang usa ka pag-usab nga pagpangita, ug kini mahimong usa ka [`DoubleEndedIterator`] kung ang usa ka pagpangita nga forward/reverse makahatag parehas nga mga elemento.
    ///
    ///
    /// Kay iterating gikan sa atubangan, sa [`matches`] pamaagi mahimong gamiton.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Usa ka iterator sa ibabaw sa disjoint matches sa usa ka sumbanan sa sulod niini nga hilo ad-ad ingon man ang index nga ang duwa magsugod sa.
    ///
    /// Alang sa mga posporo nga `pat` sulud sa `self` nga nagsapaw, ang mga indeks lamang nga katugbang sa una nga dula ang gibalik.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Ang gipabalik nga iterator mahimong usa ka [`DoubleEndedIterator`] kung ang sumbanan nagtugot sa usa ka reverse search ug ang pagpangita sa forward/reverse nagahatag parehas nga mga elemento.
    /// Tinuod kini alang sa, pananglitan, [`char`], apan dili alang sa `&str`.
    ///
    /// Kung ang sumbanan nagtugot sa usa ka pag-usab nga pagpangita apan ang mga sangputanan niini mahimo nga magkalainlain gikan sa usa ka unahan nga pagpangita, mahimong magamit ang [`rmatch_indices`] nga pamaagi.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ang una nga `aba` ra
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Usa ka iterator sa dili magkahiusa nga mga posporo sa us aka sumbanan sa sulud sa `self`, ninghatag sa balikbalik nga pagkahan-ay upod ang indeks sa dula.
    ///
    /// Kay posporo sa `pat` sulod sa `self` nga sapaw, lamang ang mga lab-a nga katumbas sa sa katapusan nga duwa nga mibalik.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Paglihok sa Iterator
    ///
    /// Gikinahanglan sa giuli nga iterator nga gisuportahan sa sumbanan ang usa ka pag-usab nga pagpangita, ug kini mahimong usa ka [`DoubleEndedIterator`] kung ang usa ka pagpangita nga forward/reverse makahatag parehas nga mga elemento.
    ///
    ///
    /// Alang sa pag-iterate gikan sa atubangan, mahimong gamiton ang [`match_indices`] nga pamaagi.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ang katapusan nga `aba` ra
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Mobalik sa usa ka hilo ad-ad uban sa nag-unang ug sa banas whitespace gikuha.
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Gibalik ang usa ka hiwa sa pisi nga gikuha ang nanguna nga whitespace.
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// `start` sa niini nga konteksto nagpasabot sa unang posisyon sa Byte hilo;alang sa wala-sa-tuo nga sinultian sama sa English o Russian, kini ang wala nga bahin, ug alang sa mga wala nga wala nga sinultian sama sa Arabiko o Hebrew, kini ang tuo nga bahin.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Mobalik sa usa ka hilo ad-ad sa banas whitespace gikuha.
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// `end` sa niini nga konteksto nagpasabot sa katapusan nga posisyon sa Byte hilo;alang sa usa ka sa wala-sa-tuo nga pinulongan sama sa Iningles o Russian, kini mahimong too nga kiliran, ug alang sa matarung nga-sa-mibiya sa mga pinulongan sama sa Arabiko o Hebreohanon, kini nga sa wala nga kiliran.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Gibalik ang usa ka hiwa sa pisi nga gikuha ang nanguna nga whitespace.
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// 'Left' sa kini nga konteksto gipasabut ang una nga posisyon sa kanang byte string;alang sa usa ka sinultian sama sa Arabiko o Hebrew nga 'tuo sa wala' kaysa 'wala sa tuo', kini ang _right_ nga bahin, dili ang wala.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Mobalik sa usa ka hilo ad-ad sa banas whitespace gikuha.
    ///
    /// 'Whitespace' gihubit sumala sa mga termino sa Unicode Derived Core Property `White_Space`.
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// 'Right' sa niini nga konteksto nagpasabot sa katapusan nga posisyon sa Byte hilo;alang sa usa ka pinulongan sama sa Arabiko o Hebreohanon nga mga 'katungod sa sa wala' kay sa 'wala ngadto sa tuo, kini ang _left_ kiliran, dili sa matarung.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Mobalik sa usa ka hilo ad-ad sa tanan nga mga prefix ug suffix nga pagpares sa usa ka sumbanan balik-balik nga gikuha.
    ///
    /// Ang [pattern] mahimong usa ka [`char`], usa ka ad-ad sa [`char`] s, o sa usa ka function o pagsira nga motino kon ang usa ka posporo nga kinaiya.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Hinumdomi ang labing kauna nga nahibal-an nga posporo, itul-id kini sa ubus kung
            // ang miaging dula managlahi
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` nailhan nga mobalik balido lab-a.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Gibalik ang usa ka hiwa sa pisi nga adunay tanan nga mga prefiks nga katugbang sa usa ka sundanan nga gibalikbalik nga gikuha.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// `start` sa niini nga konteksto nagpasabot sa unang posisyon sa Byte hilo;alang sa wala-sa-tuo nga sinultian sama sa English o Russian, kini ang wala nga bahin, ug alang sa mga wala nga wala nga sinultian sama sa Arabiko o Hebrew, kini ang tuo nga bahin.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` nailhan nga mobalik balido lab-a.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Nagpauli sa usa ka hiwa sa pisi nga gitangtang sa unahan.
    ///
    /// Kung ang pisi nagsugod sa sulud nga `prefix`, ibalik ang substring pagkahuman sa unahan, giputos sa `Some`.
    /// Dili sama sa `trim_start_matches`, kini nga pamaagi nagtangtang sa unahan nga eksakto kausa.
    ///
    /// Kon ang pisi dili magsugod uban sa `prefix`, mobalik `None`.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Mobalik sa usa ka hilo ad-ad sa mga suffix gikuha.
    ///
    /// Kung ang pisi natapos sa pattern nga `suffix`, ibalik ang substring sa wala pa ang suffix, giputos sa `Some`.
    /// Dili sama sa `trim_end_matches`, kini nga pamaagi nagtangtang eksakto nga kausa nga suffix.
    ///
    /// Kung ang pisi dili matapos sa `suffix`, ibalik ang `None`.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Gibalik ang usa ka hiwa sa pisi sa tanan nga mga suffix nga parehas sa usa ka sundanan nga gibalikbalik nga gikuha.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// `end` sa niini nga konteksto nagpasabot sa katapusan nga posisyon sa Byte hilo;alang sa usa ka sa wala-sa-tuo nga pinulongan sama sa Iningles o Russian, kini mahimong too nga kiliran, ug alang sa matarung nga-sa-mibiya sa mga pinulongan sama sa Arabiko o Hebreohanon, kini nga sa wala nga kiliran.
    ///
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` nailhan nga mobalik balido lab-a.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Gibalik ang usa ka hiwa sa pisi nga adunay tanan nga mga prefiks nga katugbang sa usa ka sundanan nga gibalikbalik nga gikuha.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// 'Left' sa kini nga konteksto gipasabut ang una nga posisyon sa kanang byte string;alang sa usa ka sinultian sama sa Arabiko o Hebrew nga 'tuo sa wala' kaysa 'wala sa tuo', kini ang _right_ nga bahin, dili ang wala.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Gibalik ang usa ka hiwa sa pisi sa tanan nga mga suffix nga parehas sa usa ka sundanan nga gibalikbalik nga gikuha.
    ///
    /// Ang [pattern] mahimong usa ka `&str`, [`char`], usa ka hiwa sa [`char`] s, o usa ka pag-andar o pagsira nga magtino kung ang usa ka karakter magkatugma.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text directionality
    ///
    /// Ang usa ka hilo usa ka han-ay sa mga byte.
    /// 'Right' sa niini nga konteksto nagpasabot sa katapusan nga posisyon sa Byte hilo;alang sa usa ka pinulongan sama sa Arabiko o Hebreohanon nga mga 'katungod sa sa wala' kay sa 'wala ngadto sa tuo, kini ang _left_ kiliran, dili sa matarung.
    ///
    ///
    /// # Examples
    ///
    /// Yano nga mga sundanan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Usa ka mas komplikado sumbanan, sa paggamit sa usa ka pagsira:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses kini nga hilo ad-ad ngadto sa laing matang.
    ///
    /// Tungod kay ang `parse` usa ka katibuk-an, mahimo kini hinungdan sa mga problema sa pagtuki sa tipo.
    /// Ingon sa ingon, ang `parse` usa sa pipila ka mga higayon nga makita nimo ang syntax nga mabinationg nailhan nga 'turbofish': `::<>`.
    ///
    /// Nakatabang kini sa nahibal-an nga algorithm nga masabtan ang piho nga tipo nga gisulayan nimo pag-ayo.
    ///
    /// `parse` mahimong maparehas sa bisan unsang tipo nga nagpatuman sa [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ibalik ang [`Err`] kung dili posible nga ma-parse kini nga hiwa sa pisi sa gusto nga tipo.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Panguna nga paggamit
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Paggamit sa 'turbofish' imbis nga i-anotate ang `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Pagkapakyas sa parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Gisusi kung ang tanan ba nga mga karakter sa kini nga hilo naa sa sulud sa ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Kita motagad sa matag Byte sama sa kinaiya dinhi: ang tanan multibyte karakter magsugod uban sa usa ka Byte nga dili sa laing ascii, aron kita mohunong didto na.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Gisusi nga ang duha nga mga lubid usa ka case-insensitive match nga ASCII.
    ///
    /// Parehas sa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, apan wala paggahin ug pagkopya sa mga temporaryo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Gikabig kini nga pisi sa ASCII sa taas nga kaso nga katumbas sa lugar.
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Sa pagbalik sa usa ka bag-o nga uppercased bili nga walay pag-usab sa kasamtangan nga usa ka, sa paggamit sa [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // KALUWASAN: luwas tungod kay gibalhin naton ang duha ka lahi nga parehas og layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Mga kinabig niini nga hilo sa iyang ASCII ubos-ubos nga kaso katumbas sa-dapit.
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mabalik ang us aka bag-ong gibug-aton nga kantidad nga dili pagbag-o ang naa na, gamita ang [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // KALUWASAN: luwas tungod kay gibalhin naton ang duha ka lahi nga parehas og layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Bumalik ang usa ka iterator nga makagawas sa matag char sa `self` sa [`char::escape_debug`].
    ///
    ///
    /// Note: lamang mitunol sa grapemo codepoints nga magsugod sa hilo nga nakagawas.
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Ibalik ang us aka iterator nga makagawas sa matag char sa `self` nga adunay [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Bumalik ang usa ka iterator nga makagawas sa matag char sa `self` sa [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ingon usa ka iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Direkta nga paggamit sa `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ang duha mao ang katumbas sa:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Paggamit `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Naghimo usa ka walay sulod nga str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Naghimo usa ka walay sulod nga mutable str
    #[inline]
    fn default() -> Self {
        // SAFETY: Ang walay sulod nga hilo balido UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Usa nga ginganlan, klase nga klase nga fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // KALUWASAN: dili luwas
        unsafe { from_utf8_unchecked(bytes) }
    };
}