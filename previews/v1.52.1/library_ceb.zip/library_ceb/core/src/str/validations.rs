//! Ang mga operasyon nga may kalabotan sa UTF-8 validation.

use crate::mem;

use super::Utf8Error;

/// Mibalik ang inisyal nga codepoint accumulator alang sa unang Byte.
/// Ang una nga byte espesyal, gusto ra sa ilalum 5 bits alang sa gilapdon 2, 4 bits alang sa gilapdon 3, ug 3 bits alang sa gilapdon 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Gibalik ang kantidad sa `ch` nga na-update uban ang pagpadayon byte `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Gisusi kung ang byte us aka UTF-8 byte nga pagpadayon (ie, nagsugod sa mga bit `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Ginbasa ang sunod nga code nga punto gikan sa usa ka Byte iterator (mapahitas sa usa ka UTF-8-sama sa encode).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Pag-decode UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Ang kaso nga Multibyte nagsunod sa Pagbag-o gikan sa us aka kombinasyon nga byte gikan sa: [[[x y] z] w]
    //
    // NOTE: Ang pagkasensitibo sensitibo sa ensakto nga paghimo dinhi
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] kaso
        // Ang ika-5 gamay sa 0xE0 .. Ang 0xEF kanunay nga tin-aw, busa ang `init` balido gihapon
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] paggamit kaso ra ang labing ubos nga 3 nga tipik sa `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Ginbasa ang katapusan nga code nga punto gikan sa usa ka Byte iterator (mapahitas sa usa ka UTF-8-sama sa encode).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Pag-decode UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Ang kaso nga Multibyte nagsunod sa Pagbag-o gikan sa us aka kombinasyon nga byte gikan sa: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// sa paggamit sa truncation nga mohaom sa u64 ngadto sa usize
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Mibalik `true` kon sa bisan unsa nga Byte sa pulong `x` mao nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Naglakaw agi sa `v` nga pagsusi nga kini usa ka balido nga han-ay sa UTF-8, gibalik ang `Ok(())` sa kana nga kaso, o, kung kini dili balido, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // kinahanglan namon data, apan wala: sayup!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Ang 2-byte encoding alang sa mga codepoints\u {0080} hangtod sa\u {07ff} una nga C2 80 katapusang DF BF
            // Ang 3-byte encoding alang sa codepoints\u {0800} hangtod\u {ffff} una E0 A0 80 katapusang EF BF BF wala`y labot ang mga puli nga codepoints\u {d800} sa\u {dfff} ED A0 80 hangtod sa ED BF BF
            // Ang 4-byte encoding alang sa mga codepoints\u {1000} 0 hangtod\u {10ff} sa una nga F0 90 80 80 katapusan F4 8F BF BF
            //
            // Gamita ang UTF-8 syntax gikan sa RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-tail UTF8-3= %xE0% xA0-BF UTF8-tail/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-tail/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii kaso, sa pagsulay sa paglukso sa unahan sa madali.
            // Kung nakahanay ang pointer, basaha ang 2 nga mga pulong sa datos matag iterasyon hangtod nga makit-an namon ang usa ka pulong nga sulud sa dili byte byte.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // KALUWASAN: tungod kay ang `align - index` ug `ascii_block_size` mao
                    // nagkalaing `usize_bytes`, `block = ptr.add(index)` kanunay ilaray sa usa ka `usize` mao nga kini luwas sa dereference duha `block` ug `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // guba kung adunay us aka nonascii byte
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // lakang gikan sa punto diin mihunong ang loop nga buut sa pulong
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Gihatagan usa ka una nga byte, gitino kung pila ang mga byte sa kini nga UTF-8 nga karakter.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Maskara sa mga tipik bili sa usa ka sumpay Byte.
const CONT_MASK: u8 = 0b0011_1111;
/// Ang kantidad sa mga tag bits (tag mask mao ang !CONT_MASK) sa usa ka pagpadayon byte.
const TAG_CONT_U8: u8 = 0b1000_0000;

// truncate `&str` sa gitas-on sa labing itanding `max` pagbalik `true` kon kini truncated, ug ang mga bag-o nga str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}