//! Ang string nga Pattern API.
//!
//! Naghatag ang pattern API usa ka generic nga mekanismo alang sa paggamit sa lainlaing mga lahi sa pattern kung nagpangita pinaagi sa usa ka string.
//!
//! Alang sa dugang nga mga detalye, tan-awa ang traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ug [`DoubleEndedSearcher`].
//!
//! Bisan kung kini nga API dili lig-on, gibutyag kini pinaagi sa mga stable API sa [`str`] nga tipo.
//!
//! # Examples
//!
//! [`Pattern`] ang [implemented][pattern-impls] sa stable API alang sa [`&str`][`str`], [`char`], mga hiwa sa [`char`], ug mga gimbuhaton ug pagsira nga nagpatuman sa `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char sumbanan
//! assert_eq!(s.find('n'), Some(2));
//! // hiwa sa sumbanan sa chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // sumbanan sa pagsira
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Usa ka sumbanan sa hilo.
///
/// Usa ka `Pattern<'a>` nagpahayag nga ang pagpatuman sa matang mahimong gamiton ingon nga usa ka hilo nga sumbanan alang sa pagpangita sa usa ka [`&'a str`][str].
///
/// Pananglitan, ang duha `'a'` ug `"aa"` mga sumbanan nga pagpares sa index `1` sa hilo `"baaaab"`.
///
/// Ang trait sa iyang kaugalingon molihok ingon nga usa ka magtutukod alang sa usa ka nakig-type [`Searcher`], nga nagabuhat sa aktuwal nga buhat sa pagpangita sa teksto sa sumbanan sa usa ka hilo.
///
///
/// Depende sa matang sa sumbanan, sa kinaiya sa mga pamaagi sama sa [`str::find`] ug [`str::contains`] makausab.
/// Gihubit sa lamesa sa ubus ang pipila sa mga pamatasan.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Nalangkit nagasusi sa sumbanan niini nga
    type Searcher: Searcher<'a>;

    /// Nagtukod sa mga kalabutan nakaila gikan sa `self` ug sa `haystack` sa pagpangita sa.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Gisusi kung ang sumbanan motugma bisan asa sa haystack
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Checks kon ang sumbanan motakdo sa atubangan sa nagtipun-og nga dagami
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Gisusi kung ang sumbanan motugma sa likod sa haystack
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Gikuha ang sumbanan gikan sa atubangan sa haystack, kung motugma kini.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SAFETY: `Searcher` nailhan nga mobalik balido lab-a.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Removes sa sumbanan gikan sa likod sa nagtipun-og nga dagami, kon kini matches.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SAFETY: `Searcher` nailhan nga mobalik balido lab-a.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Moresulta sa pagtawag [`Searcher::next()`] o [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Pagpahayag nga ang usa ka duwa sa sumbanan nga nakaplagan didto sa `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Pagpahayag nga `haystack[a..b]` nga gisalikway ingon nga usa ka posible nga duwa sa sumbanan.
    ///
    /// Mubo nga sulat nga mahimong labaw pa kay sa usa `Reject` sa taliwala sa duha ka `Match`es, walay kinahanglanon alang kanila nga inubanan sa usa.
    ///
    ///
    Reject(usize, usize),
    /// Gipahayag nga ang matag byte sa haystack nabisita na, nga nagtapos sa pag-ulit.
    ///
    Done,
}

/// Usa ka nagasulay alang sa usa ka hilo nga sumbanan.
///
/// Ang kini nga trait naghatag mga pamaagi alang sa pagpangita alang sa dili nagsapaw nga mga posporo sa usa ka sumbanan nga nagsugod gikan sa atubangan nga (left) sa usa ka pisi.
///
/// Ipatuman kini sa mga kauban nga `Searcher` nga lahi sa [`Pattern`] trait.
///
/// Ang trait gimarkahan luwas tungod kay ang mga lab-a mibalik sa [`next()`][Searcher::next] mga paagi gikinahanglan sa bakak sa balido utf8 utlanan sa nagtipun-og nga dagami.
/// Gihatagan niini gahum ang mga konsyumer sa kini nga trait nga gihiwa ang haystack nga wala`y dugang nga mga runtime check.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter alang sa tinuod nga hinungdan sa hilo nga nangita sa
    ///
    /// Kanunay nga ibalik ang parehas nga [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Gihimo ang sunod nga lakang sa pagpangita nga nagsugod gikan sa atubangan.
    ///
    /// - Gibalik ang [`Match(a, b)`][SearchStep::Match] kung ang `haystack[a..b]` katugbang sa sundanan.
    /// - Mobalik [`Reject(a, b)`][SearchStep::Reject] kon `haystack[a..b]` dili makatumbas sa sumbanan, bisan pa partially.
    /// - Mobalik [`Done`][SearchStep::Done] kon ang matag Byte sa nagtipun-og nga dagami nga mibisita.
    ///
    /// Ang sapa sa [`Match`][SearchStep::Match] ug [`Reject`][SearchStep::Reject] gipabilhan ngadto sa usa ka [`Done`][SearchStep::Done] adunay han-ay index nga tapad, non-nagsapaw, nga nagatabon sa bug-os nga nagtipun-og nga dagami, ug pagpandong sa utf8 utlanan.
    ///
    ///
    /// Ang usa ka sangputanan nga [`Match`][SearchStep::Match] kinahanglan adunay sulud nga tibuuk nga gisukma nga sundanan, bisan pa ang mga sangputanan nga [`Reject`][SearchStep::Reject] mahimong mabulag sa dili tinuyo nga daghang kasikbit nga mga tipik.Ang duha mga han-ay aron adunay zero gitas-on.
    ///
    /// Ingon sa usa ka panig-ingnan, ang sumbanan `"aaa"` ug sa nagtipun-og nga dagami `"cbaaaaab"` unta og sa sapa
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Makita ang sunod nga sangputanan nga [`Match`][SearchStep::Match].Kitaa ang [`next()`][Searcher::next].
    ///
    /// Dili sama sa [`next()`][Searcher::next], wala`y garantiya nga ang gibalik nga mga sakup niini ug ang [`next_reject`][Searcher::next_reject] mag-overlap.
    /// Iuli niini ang `(start_match, end_match)`, diin ang start_match mao ang indeks diin magsugod ang dula, ug ang end_match mao ang indeks pagkahuman sa katapusan sa dula.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Makakaplag sa sunod [`Reject`][SearchStep::Reject] resulta.Tan-awa ang [`next()`][Searcher::next] ug [`next_match()`][Searcher::next_match].
    ///
    /// Dili sama sa [`next()`][Searcher::next], wala`y garantiya nga ang gibalik nga mga sakup niini ug ang [`next_match`][Searcher::next_match] mag-overlap.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Usa ka reverse nagasusi sa usa ka hilo nga sumbanan.
///
/// Ang kini nga trait naghatag mga pamaagi alang sa pagpangita alang sa dili nagsapaw nga mga posporo sa usa ka sundanan nga nagsugod sa likud nga (right) sa usa ka hilo.
///
/// Ipatuman kini sa mga kauban nga [`Searcher`] nga lahi sa [`Pattern`] trait kung gisuportahan sa sumbanan ang pagpangita niini gikan sa likud.
///
///
/// Ang mga sakup sa indeks nga gibalik sa kini nga trait dili kinahanglan nga eksaktong motugma sa mga sa unahan nga pagpangita sa balihon.
///
/// Kay ang rason ngano nga kini trait gimarkahan luwas, tan-awa sila ginikanan trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Gihimo ang sunod nga lakang sa pagpangita nga nagsugod gikan sa likod.
    ///
    /// - Mibalik [`Match(a, b)`][SearchStep::Match] kon `haystack[a..b]` matches sa sumbanan.
    /// - Gibalik ang [`Reject(a, b)`][SearchStep::Reject] kung ang `haystack[a..b]` dili parehas sa sundanan, bisan sa bahin.
    /// - Gibalik ang [`Done`][SearchStep::Done] kung ang matag byte sa haystack nabisita na
    ///
    /// Ang sapa sa [`Match`][SearchStep::Match] ug [`Reject`][SearchStep::Reject] gipabilhan ngadto sa usa ka [`Done`][SearchStep::Done] adunay han-ay index nga tapad, non-nagsapaw, nga nagatabon sa bug-os nga nagtipun-og nga dagami, ug pagpandong sa utf8 utlanan.
    ///
    ///
    /// Ang usa ka sangputanan nga [`Match`][SearchStep::Match] kinahanglan adunay sulud nga tibuuk nga gisukma nga sundanan, bisan pa ang mga sangputanan nga [`Reject`][SearchStep::Reject] mahimong mabulag sa dili tinuyo nga daghang kasikbit nga mga tipik.Ang duha mga han-ay aron adunay zero gitas-on.
    ///
    /// Ingon sa usa ka panig-ingnan, ang sumbanan `"aaa"` ug sa nagtipun-og nga dagami `"cbaaaaab"` unta og sa sapa `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Nakapangita sa sunod nga sangputanan nga [`Match`][SearchStep::Match].
    /// Kitaa ang [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Nakapangita sa sunod nga sangputanan nga [`Reject`][SearchStep::Reject].
    /// Kitaa ang [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Usa ka ilhanan trait sa pagpahayag nga ang usa ka [`ReverseSearcher`] mahimong gamiton alang sa usa ka [`DoubleEndedIterator`] pagpatuman.
///
/// Kay kini, ang impl sa [`Searcher`] ug [`ReverseSearcher`] kinahanglan nga mosunod niini nga mga kahimtang:
///
/// - Ang tanan nga mga sangputanan sa `next()` kinahanglan managsama sa mga sangputanan sa `next_back()` sa reverse order.
/// - `next()` ug `next_back()` panginahanglan sa paggawi sama sa duha ka tumoy sa usa ka-laing mga hiyas, nga mao ang sila dili "walk past each other".
///
/// # Examples
///
/// `char::Searcher` usa ka `DoubleEndedSearcher` tungod kay ang pagpangita sa usa ka [`char`] nagkinahanglan nga magtan-aw matag usa, nga managsama ang paggawi gikan sa pareho nga tumoy.
///
/// `(&str)::Searcher` dili usa ka `DoubleEndedSearcher` tungod kay ang sumbanan nga `"aa"` sa haystack `"aaa"` parehas sa bisan unsang `"[aa]a"` o `"a[aa]"`, depende kung asa nga bahin kini gipangita.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl alang sa char
/////////////////////////////////////////////////////////////////////////////

/// Nalangkit nga matang sa `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // safety invariant: Ang `finger`/`finger_back` kinahanglan usa ka balido nga utf8 byte index nga `haystack` Kini nga invariant mahimong mabuak *sulud sa* next_match ug next_match_back, bisan pa kinahanglan sila mogawas nga adunay mga tudlo sa mga utlanan nga may kinutuban nga code point.
    //
    //
    /// `finger` mao ang kasamtangan nga Byte index sa unahan search.
    /// Hunahuna nga naa kini sa wala pa ang byte sa indeks niini, ie
    /// `haystack[finger]` mao ang una nga byte sa hiwa nga kinahanglan naton nga susihon sa panahon sa pagpangita sa unahan
    ///
    finger: usize,
    /// `finger_back` ang karon nga byte index sa balik nga pagpangita.
    /// Hunahuna nga naa kini pagkahuman sa byte sa indeks niini, ie
    /// Ang haystack [finger_back, 1] mao ang katapusang byte sa hiwa nga kinahanglan naton nga susihon sa panahon sa pagpangita sa unahan (ug sa ingon ang una nga byte nga susihon kung motawag sa next_back()).
    ///
    finger_back: usize,
    /// Ang karakter nga gipangita
    needle: char,

    // safety invariant: Ang `utf8_size` kinahanglan moubus sa 5
    /// Ang ihap sa mga byte `needle` mokuha kung na-encode sa utf8.
    utf8_size: usize,
    /// Usa ka utf8 encoded kopya sa `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SAFETY: 1-4 garantiya sa kaluwasan sa `get_unchecked`
        // 1. `self.finger` ug ang `self.finger_back` gitipigan sa mga utlanan sa unicode (kanunay kini nga buhaton)
        // 2. `self.finger >= 0` tungod kay nagsugod kini sa 0 ug nagdugang ra
        // 3. `self.finger < self.finger_back` tungod kay kon dili ang char `iter` mobalik `SearchStep::Done`
        // 4.
        // `self.finger` moabut sa wala pa matapos ang haystack tungod kay ang `self.finger_back` magsugod sa katapusan ug maminusan lang
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // pagdugang byte offset sa karon nga karakter nga wala pag-usab pag-encode ingon utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // sa pagkuha sa mga nagtipun-og nga dagami human sa katapusan nga kinaiya nga makita
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ang katapusang byte sa utf8 na-encode nga dagom SAFETY: adunay kami usa ka invariant nga `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ang bag-ong tudlo mao ang indeks sa byte nga among nakit-an, dugangan usa, tungod kay among gisulat ang katapusang byte sa karakter.
                //
                // Hinumdomi nga kini dili kanunay naghatag kanamo usa ka tudlo sa usa ka UTF8 nga utlanan.
                // Kung wala namon * nakit-an ang among karakter mahimo kami mag-indeks sa dili katapusan nga byte sa usa ka 3-byte o 4-byte nga karakter.
                // dili lang kita mahimong skip sa sunod balido sa pagsugod Byte tungod kay sa usa ka kinaiya nga sama sa ꁁ (U + A041 Yi silaba PA), utf-8 `EA 81 81` adunay nato kanunay sa pagpangita sa ikaduha nga Byte sa dihang nangita sa ikatulo.
                //
                //
                // Bisan pa, kini okay gyud.
                // Samtang adunay kami invariant nga ang self.finger naa sa usa ka UTF8 nga utlanan, kini nga invariant dili gisaligan sa sulud niini nga pamaagi (kini gisaligan sa CharSearcher::next()).
                //
                // Kita lamang mogawas niini nga pamaagi sa diha nga pagkab-ot sa kita sa katapusan sa sa pisi, o kon kita makakaplag sa usa ka butang.Kung nakit-an namon ang usa ka butang ang `finger` igatakda sa usa ka UTF8 nga utlanan.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // nakita nga walay bisan unsa, exit
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // himoa nga next_reject paggamit sa default pagpatuman gikan sa nagasusi trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // KALUWASAN: tan-awa ang komentaryo alang sa next() sa taas
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // ibawas ang byte offset sa karon nga karakter nga wala pag-encode pag-usab ingon utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // sa pagkuha sa mga nagtipun-og nga dagami sa apan dili lakip na sa katapusan nga kinaiya nangita
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ang katapusang byte sa utf8 na-encode nga dagom SAFETY: adunay kami usa ka invariant nga `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // gipangita namon ang usa ka hiwa nga gipalabi sa self.finger, idugang ang self.finger aron makuha usab ang orihinal nga indeks
                //
                let index = self.finger + index;
                // ibalik sa memrchr ang indeks sa byte nga gusto namon makit-an.
                // Sa kaso sa usa ka ASCII nga kinaiya, kini sa pagkatinuod ang mga gusto nato ang atong bag-o nga tudlo nga mahimong ("after" ang nakaplagan char sa paradigm sa reverse subli).
                //
                // Kay multibyte chars kita kinahanglan sa skip pinaagi sa gidaghanon sa labaw pa bytes sila kay sa ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ibalhin ang tudlo sa wala pa makit-an ang karakter (ie, sa pagsugod nga indeks)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Dili namon magamit dinhi ang finger_back=index, size + 1.
                // Kung nakit-an namon ang katapusang char sa us aka lainlaing gidak-on nga karakter (o sa tunga nga byte sa usa ka lainlaing karakter) kinahanglan namon nga maibut ang tudlo_back hangtod sa `index`.
                // Kini usab naghimo sa `finger_back` adunay potensyal nga dili na mahimo nga sa usa ka utlanan, apan kini mao ang OK tungod kay lamang kita mogawas kini nga function sa usa ka utlanan o sa diha nga ang nagtipun-og nga dagami nga nangita sa hingpit.
                //
                //
                // Dili sama sa sunod_match wala kini problema sa gibalikbalik nga mga byte sa utf-8 tungod kay gipangita namon ang katapusang byte, ug mahibal-an ra namo ang katapusang byte kung nangita sa likod.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // nakita nga walay bisan unsa, exit
                return None;
            }
        }
    }

    // tugoti ang sunod_reject_back nga gamiton ang default nga pagpatuman gikan sa Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Pagpangita alang sa mga chars nga katumbas sa usa ka gihatag nga [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl alang sa usa ka MultiCharEq wrapper
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Itandi gitas-on sa mga internal nga Byte ad-ad iterator sa pagpangita sa gitas-on sa kasamtangan nga char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Itandi gitas-on sa mga internal nga Byte ad-ad iterator sa pagpangita sa gitas-on sa kasamtangan nga char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Ipatuman alang sa&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Pagbag-o/Pagtangtang tungod sa dili klaro nga kahulugan.

/// Kaugnay nga tipo alang sa `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Pagpangita mga char nga parehas sa bisan unsang mga [`char`] sa hiwa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Ipatuman alang sa F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Nalangkit nga matang sa `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Pagpangita alang sa [`char`] nga parehas sa gihatag nga predicate.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl alang sa&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegado sa `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl alang sa &str
/////////////////////////////////////////////////////////////////////////////

/// Non-alokar substring search.
///
/// Pagdumala ang sumbanan nga `""` ingon nga pagbalik sa wala`y sulod nga mga posporo sa matag utlanan sa kinaiya.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Gisusi kung ang sumbanan parehas ba sa atubangan sa haystack.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Gikuha ang sumbanan gikan sa atubangan sa haystack, kung motugma kini.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SAFETY: prefix lang napamatud-an nga naglungtad.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Gisusi kung ang sumbanan motugma sa likod sa haystack.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Removes sa sumbanan gikan sa likod sa nagtipun-og nga dagami, kon kini matches.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // KALUWASAN: ang igsapayan napamatud-an lang nga adunay.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Nagpangita sa Two Way substring
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Kaugnay nga tipo alang sa `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // gisalikway sa walay sulod nga dagum ang matag char ug gipares sa matag walay sulod nga pisi taliwala niini
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher og balido *Match* lab-a nga ang split sa char utlanan ingon sa kadugayon nga kini husto matching ug nga ang nagtipun-og nga dagami ug dagum mga balido UTF-8 * nagsalikway gikan sa algorithm mapukan sa ibabaw sa bisan unsa nga lab-a, apan kita magalakaw sila sa kamut sa mga sunod nga utlanan nga kinaiya, aron sila luwas nga utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // skip sa sunod nga char utlanan
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // isulat sa `true` ug `false` mga kaso sa pagdasig sa mga tighipos sa specialize sa duha ka mga kaso gilain.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // skip sa sunod nga char utlanan
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // isulat ang `true` ug `false`, sama sa `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Ang internal nga kahimtang sa duha ka-paagi nga algorithm substring search.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// kritikal nga indeks sa hinungdan
    crit_pos: usize,
    /// kritikal nga indeks sa hinungdan sa pagbag-o sa dagom
    crit_pos_back: usize,
    period: usize,
    /// `byteset` mao ang usa ka extension (dili bahin sa duha ka mga paagi nga algorithm);
    /// kini usa ka 64-gamay "fingerprint" diin ang matag set mipaak `j` kaangay ngadto sa usa ka (Byte&63)==j karon sa dagum.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index ngadto sa dagum sa atubangan nga kita na nga nakigtagbo
    memory: usize,
    /// index ngadto sa dagum human nga na kita nga nakigtagbo
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Ang usa ka ilabi mabasa nga katin-awan sa kon unsa na sa dinhi mahimong makita diha sa Crochemore ug ni Rytter basahon "Text Algorithms", ch 13.
        // Partikular nga nakita ang code alang sa "Algorithm CP" sa p.
        // 323.
        //
        // Kung unsa ang nagakahitabo adunay kami kritikal nga hinungdan (u, v) sa dagom, ug gusto namon mahibal-an kung ang u ba us aka suffix sa&v [.. panahon].
        // Kung kini mao, gigamit namon ang "Algorithm CP1".
        // Kay kon dili kita mogamit sa "Algorithm CP2", nga optimized alang sa diha nga ang panahon sa mga dagom mao ang dako nga.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kaso sa mubo nga panahon-ang panahon eksakto nga pag-ihap sa usa ka bulag nga kritikal nga hinungdan alang sa baligtad nga dagom x=u 'v' diin | v '|<period(x).
            //
            // Kini mibulhot sa panahon nga nailhan na.
            // Mubo nga sulat nga ang usa ka kaso nga sama sa x= "acba" mahimong factored gayud sa unahan (crit_pos=1, panahon=3) samtang factored sa gibanabanang panahon sa reverse (crit_pos=2, panahon=2).
            // Gigamit namon ang gihatag nga reverse factorization apan ipadayon ang eksaktong oras.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // kaso sa dugay nga panahon-adunay kami pagbanabana sa tinuud nga yugto, ug ayaw paggamit pagmemorya.
            //
            //
            // Banabana ang panahon pinaagi sa ubos nga gihigot nga max(|u|, |v|) + 1.
            // Ang kritikal nga factorization mao ang hapsay nga sa paggamit alang sa mga sa unahan ug Reverse search.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy bili sa pagpaila nga ang panahon mao ang taas nga
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Usa sa mga punoan nga ideya sa Two-Way mao ang hinungdanon namon ang dagum ngadto sa duha ka halves, (u, v), ug magsugod sa pagsulay nga makit-an ang v sa hugaw pinaagi sa pag-scan sa wala ngadto sa tuo.
    // Kon v posporo, naningkamot kami sa pagpares sa u pinaagi sa scan sa tuo ngadto sa wala.
    // Kung unsa ka layo ang mahimo naton nga pag-ambak kung makasugat kami og dili pareho nga pagsukol tanan nakabase sa kamatuoran nga (u, v) usa ka kritikal nga hinungdan sa dagom.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` naggamit `self.position` ingon kini cursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Susihon nga adunay kami lugar aron makapangita sa posisyon + dili kinahanglan nga mag-overflow ang dagom + dagway kung ibutang namon ang mga hiwa nga gihigot sa sakup sa isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Dali nga laktawan ang daghang mga bahin nga wala`y kalabotan sa among substring
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Tan-awa kon sa tuo nga bahin sa duwa dagum
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Tan-awa kon sa wala nga bahin sa duwa dagum
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Nakakita kami usa ka posporo!
            let match_pos = self.position;

            // Note: idugang ang self.period imbis nga needle.len() aron adunay magsapaw nga mga posporo
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // itakda sa needle.len(), self.period alang sa nagsapaw nga mga posporo
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Mosunod sa mga ideya sa `next()`.
    //
    // Ang mga kahulugan parehas nga simetriko, nga adunay period(x) = period(reverse(x)) ug local_period(u, v) = local_period(reverse(v), reverse(u)), busa kung ang (u, v) usa ka kritikal nga hinungdanon, ingon usab ang (reverse(v), reverse(u)).
    //
    //
    // Alang sa baligtad nga kaso nakalkula namon ang usa ka kritikal nga paktoripikasyon x=u 'v' (uma `crit_pos_back`).Kinahanglan namon | u |<period(x) alang sa unahan nga kaso ug sa ingon | v '|<period(x) alang sa mga Reverse.
    //
    // Aron mapangita ang baliktad pinaagi sa haystack, nangita kami sa unahan pinaagi sa usa ka baligtad nga haystack nga adunay usa ka baligtad nga dagom, nga nagsama sa una u 'ug pagkahuman v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` naggamit `self.end` ingon kini cursor-aron ang `next()` ug `next_back()` independente.
        //
        let old_end = self.end;
        'search: loop {
            // Susihon nga adunay kami sulud nga pangitaon sa katapusan, ang needle.len() maglibot kung wala na`y lugar, apan tungod sa mga utlanan sa gitas-on sa hiwa dili gyud kini mabalot hangtod sa gitas-on sa haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Dali nga laktawan ang daghang mga bahin nga wala`y kalabotan sa among substring
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Tan-awa kon sa wala nga bahin sa duwa dagum
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Tan-awa kon sa tuo nga bahin sa duwa dagum
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Nakakita kami usa ka posporo!
            let match_pos = self.end - needle.len();
            // Note: sub self.period sa baylo nga sa needle.len() nga adunay overlapping posporo
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Pagkwenta sa labing kadaghan nga sukwahi sa `arr`.
    //
    // Ang kinatas-an suffix mao ang usa ka posible nga kritikal factorization (u, v) sa `arr`.
    //
    // Mobalik (`i`, `p`) diin ang `i` mao ang pagsugod indeks sa v ug `p` ang panahon sa v.
    //
    // `order_greater` gitino kung ang lexical order mao ang `<` o `>`.
    // Ang duha mga sugo kinahanglan nga kuwentahon-ang tulomanon uban sa mga kinadak-ang `i` naghatag sa usa ka kritikal nga factorization.
    //
    //
    // Alang sa mga kaso sa dugay nga panahon, ang sangputanan nga panahon dili eksakto (kini mubo ra kaayo).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Katugbang sa i sa papel
        let mut right = 1; // Kaangay sa j sa papel
        let mut offset = 0; // Katugbang sa k sa papel, apan sugod sa 0
        // sa pagpares sa 0-based indexing.
        let mut period = 1; // Katugbang sa p sa papel

        while let Some(&a) = arr.get(right + offset) {
            // `left` mahimong inbound kung kanus-a ang `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ang suffix mas gamay, ang panahon tibuuk nga unahan hangtod karon.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Pag-uswag pinaagi sa pagsubli sa karon nga panahon.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ang mas dako, magsugod gikan sa kasamtangan nga lokasyon.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Pagkwenta sa labing kadaghan nga sukwahi sa baligtad sa `arr`.
    //
    // Ang labing kadaghan nga panagsama usa ka posible nga kritikal nga hinungdan (u ', v') sa `arr`.
    //
    // Gibalik ang `i` diin ang `i` mao ang pagsugod indeks sa v ', gikan sa likud;
    // mobalik dayon kung maabut ang usa ka panahon nga `known_period`.
    //
    // `order_greater` gitino kung ang lexical order mao ang `<` o `>`.
    // Ang duha mga sugo kinahanglan nga kuwentahon-ang tulomanon uban sa mga kinadak-ang `i` naghatag sa usa ka kritikal nga factorization.
    //
    //
    // Alang sa mga kaso sa dugay nga panahon, ang sangputanan nga panahon dili eksakto (kini mubo ra kaayo).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Katugbang sa i sa papel
        let mut right = 1; // Kaangay sa j sa papel
        let mut offset = 0; // Katugbang sa k sa papel, apan sugod sa 0
        // sa pagpares sa 0-based indexing.
        let mut period = 1; // Katugbang sa p sa papel
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ang suffix mas gamay, ang panahon tibuuk nga unahan hangtod karon.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Pag-uswag pinaagi sa pagsubli sa karon nga panahon.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ang mas dako, magsugod gikan sa kasamtangan nga lokasyon.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy nagtugot sa algorithm sa bisan skip non-posporo dayon kutob sa mahimo, o sa trabaho sa usa ka mode diin kini nagpasabwag magasalikway medyo madali.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Laktaw ngadto sa pagpares sa mga lat-ang dayon kutob sa mahimo
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Nagdumili kanunay
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}