//! Ninghubit, ningsaysay utf8 matang sayop.

use crate::fmt;

/// Mga sayup nga mahimong mahitabo sa diha nga pagsulay sa paghubad sa usa ka han-ay sa [`u8`] ingon usa ka hilo.
///
/// Sa ingon, ang `from_utf8` pamilya sa mga gimbuhaton ug mga pamaagi alang sa duha [`String`] ug [`&str`] sa paghimo sa paggamit sa sayop niini, alang sa panig-ingnan.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// mga pamaagi Kini nga matang sa sayop mahimong gigamit sa paghimo sa kalihukan nga susama sa `String::from_utf8_lossy` walay gahin nga tinapok sa panumduman:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Gibalik ang indeks sa gihatag nga hilo hangtod diin nga balido nga UTF-8 ang napamatud-an.
    ///
    /// Kini mao ang maximum index sa ingon nga `from_utf8(&input[..index])` mobalik `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ang pipila dili balido nga mga byte, sa usa ka vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 nagbalik usa ka Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ang ikaduha nga Byte mao imbalido dinhi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Naghatag dugang nga kasayuran bahin sa kapakyasan:
    ///
    /// * `None`: ang katapusan sa input naabut nga wala damha.
    ///   `self.valid_up_to()` mao ang 1 ngadto sa 3 bytes gikan sa kinatumyan sa mga input.
    ///   Kung ang usa ka byte stream (sama sa usa ka file o us aka network socket) nga padayong gi-decode, mahimo kini usa ka balido nga `char` nga ang UTF-8 byte nga pagkasunud naglangkob sa daghang mga tipik.
    ///
    ///
    /// * `Some(len)`: usa ka wala damha nga byte ang nasugatan.
    ///   Ang gitas-on nga gihatag mao nga sa imbalido Byte han-ay nga magsugod sa index nga gihatag sa `valid_up_to()`.
    ///   Ang pag-decode kinahanglan magpadayon pagkahuman sa kana nga pagkasunud (pagkahuman isuksok ang usa ka [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) sa kaso sa lossy decoding.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Usa ka sayop mibalik sa diha nga parsing sa usa ka `bool` paggamit [`from_str`] mapakyas
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}