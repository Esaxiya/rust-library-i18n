//! Usa ka module alang sa pagtrabaho kauban ang hinulaman nga datos.

#![stable(feature = "rust1", since = "1.0.0")]

/// Usa ka trait alang sa paghulam data.
///
/// Sa Rust, kini mao ang komon sa paghatag og lain-laing mga mga hulagway sa usa ka matang sa lain-laing mga kaso sa paggamit.
/// Pananglitan, ang lokasyon sa pagtipig ug pagdumala alang sa usa ka kantidad mahimong piho nga mapili nga angay alang sa usa ka piho nga paggamit pinaagi sa mga tipo sa pointer sama sa [`Box<T>`] o [`Rc<T>`].
/// Labaw sa kini nga mga generic wrappers nga mahimong magamit sa bisan unsang lahi, ang pipila ka mga lahi naghatag mga kapilian nga mga dagway nga naghatag potensyal nga mahal nga pagpaandar.
/// Ang usa ka pananglitan alang sa ingon nga lahi mao ang [`String`] nga nagdugang sa abilidad sa pagpaabot sa usa ka pisi sa punoan nga [`str`].
/// Kini nagkinahanglan sa pagtuman sa dugang nga impormasyon sa wala kinahanglana alang sa usa ka yano, dili mausab nga hilo.
///
/// Ang kini nga mga lahi naghatag access sa nagpahiping datos pinaagi sa mga pakisayran sa tipo sa kana nga datos.Giingon nga sila 'gihulaman ingon' kana nga tipo.
/// Pananglitan, ang usa ka [`Box<T>`] mahimong pahulam ingon `T` samtang ang [`String`] mahimo pahulam ingon `str`.
///
/// Matang sa pagpahayag nga sila mahimong nanghulam sama sa uban matang `T` pinaagi sa pagpatuman sa `Borrow<T>`, paghatag og usa ka pakisayran ngadto sa usa ka `T` sa [`borrow`] pamaagi sa trait ni.Ang usa ka lahi libre nga manghulam ingon lainlaing mga lahi.
/// Kon kini nga buot mutably manghulam ingon nga ang matang-pagtugot sa nahiilalum data nga giusab, kini dugang pagpatuman [`BorrowMut<T>`].
///
/// Dugang pa, sa diha nga sa paghatag og implementar sa alang sa dugang nga traits, kini kinahanglan nga giisip nga kon sila kinahanglan magagawi susama niadtong sa mga hinungdan nga matang nga sama sa usa ka sangputanan sa paglihok ingon nga sa usa ka simbolo niana nga hinungdan nga matang.
/// Ang generic code kasagarang naggamit `Borrow<T>` kung kini mosalig sa parehas nga pamatasan sa mga dugang nga pagpatuman sa trait.
/// Kini nga mga traits lagmit makita ingon nga dugang nga trait bounds.
///
/// Sa piho nga `Eq`, `Ord` ug `Hash` kinahanglan managsama alang sa gihulaman ug gipanag-iya nga mga kantidad: Ang `x.borrow() == y.borrow()` kinahanglan maghatag parehas nga sangputanan sama sa `x == y`.
///
/// Kung kinahanglan nga magtrabaho ang generic code alang sa tanan nga mga lahi nga makahatag usa ka pakigsulti sa may kalabutan nga tipo `T`, kanunay nga mas maayo nga gamiton ang [`AsRef<T>`] tungod kay daghang mga lahi ang luwas nga maimplementar.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ingon usa ka koleksyon sa datos, ang [`HashMap<K, V>`] tag-iya sa parehas nga mga yawe ug mithi.Kung ang tinuud nga datos sa yawi naputos sa us aka klase nga pagdumala, kinahanglan, bisan pa, posible pa nga makapangita usa ka kantidad gamit ang usa ka pakisayran sa datos sa yawi.
/// Pananglitan, kon ang yawe mao ang usa ka pisi, nan kini mao ang lagmit gitipigan sa hash mapa nga ingon sa usa ka [`String`], samtang nga kini mahimong posible nga sa pagpangita sa paggamit sa usa ka [`&str`][`str`].
/// Busa, `insert` nagkinahanglan sa pag-operate sa usa ka `String` samtang `get` kinahanglan nga makahimo sa paggamit sa usa ka `&str`.
///
/// Gamay nga gipasimple, ang mga may kalabutan nga mga bahin sa `HashMap<K, V>` ingon niini:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // gitangtang nga mga uma
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Ang tibuok hash mapa mao ang generic sa ibabaw sa usa ka yawe nga matang `K`.Tungod kay kini nga mga yawe gitipigan sa mapa hash, kini nga matang dunay sa iya data sa yawe ni.
/// Sa diha nga ang pagsal-ot sa usa ka yawe nga-bili paris, ang mapa nga gihatag sa maong usa ka `K` ug mga panginahanglan sa pagpangita sa husto nga hash balde ug check kon ang yawe mao ang na karon base sa nga `K`.Busa nanginahanglan kini og `K: Hash + Eq`.
///
/// Sa diha nga ang pagpangita alang sa usa ka bili sa mapa, Apan, may sa paghatag sa usa ka pakisayran ngadto sa usa ka `K` ingon nga ang mga yawe sa pagpangita alang sa nagkinahanglan sa kanunay nga paghimo sa ingon nga usa ka gipanag-iya nga bili.
/// Alang sa mga yawe sa string, kini gipasabut nga ang `String` nga kantidad kinahanglan himuon alang ra sa pagpangita sa mga kaso diin usa ka `str` lang ang magamit.
///
/// Hinunoa, ang `get` pamaagi mao generic sa ibabaw sa matang sa mga nagpahiping yawe data, nga gitawag `Q` sa pamaagi pirma sa ibabaw.Gisulti niini nga ang `K` nangutang ingon usa ka `Q` pinaagi sa paghangyo nga `K: Borrow<Q>`.
/// Pinaagi sa dugang nga nagkinahanglan `Q: Hash + Eq`, mosignal kini sa kinahanglanon nga `K` ug `Q` adunay implementar sa `Hash` ug `Eq` traits nga og susama nga mga resulta.
///
/// Ang pagpatuman sa `get` nagsalig sa partikular sa susama implementar sa `Hash` pinaagi sa pagtino sa yawe ni hash balde pinaagi sa pagtawag `Hash::hash` sa bili `Q` bisan tuod kini gisal-ut sa yawe base sa bili hash kalkulado gikan sa bili `K`.
///
///
/// Ingon sa usa ka resulta, ang hash mapa higayon kon ang usa ka `K` pagputos sa usa ka `Q` bili og usa ka lain-laing mga hash kay `Q`.Pananglitan, hunahunaa nga adunay ka usa ka klase nga nagputos sa usa ka pisi apan gitandi ang mga letra nga ASCII nga wala tagda ang ilang kaso:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Tungod kay ang duha nga managsama nga kantidad kinahanglan maghimo sa parehas nga kantidad nga hash, ang pagpatuman sa `Hash` kinahanglan usab nga ibaliwala ang kaso sa ASCII, usab:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Mahimo ba `CaseInsensitiveString` pagpatuman `Borrow<str>`?Kini sa pagkatinuod makahatag og usa ka pakisayran ngadto sa usa ka hilo ad-ad pinaagi sa sa iyang mga anaa gipanag-iya hilo.
/// Apan tungod kay lainlain ang pagpatuman sa `Hash`, lahi ang paggawi gikan sa `str` ug busa kinahanglan dili, sa tinuud ipatuman ang `Borrow<str>`.
/// Kon kini nga gusto sa pagtugot sa uban access sa nagpahiping `str`, kini buhaton nga pinaagi sa `AsRef<str>` nga dili dad-on sa bisan unsa nga dugang nga mga kinahanglanon.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Dili mabalhin nga manghulam gikan sa tag-iya nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Usa ka trait alang sa mutable data sa pagpangutang.
///
/// Ingon sa usa ka kauban sa [`Borrow<T>`] niini trait nagtugot sa usa ka matang sa paghulam ingon nga usa ka nagpahiping matang pinaagi sa paghatag sa usa ka mutable pakisayran.
/// Tan-awa ang [`Borrow<T>`] alang sa dugang nga kasayuran bahin sa pagpangutang ingon usa pa nga lahi.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Nagbag-o nga manghulam gikan sa tag-iya nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}