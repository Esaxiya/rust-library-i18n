use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Usa ka interface alang sa pag-atubang sa dili pareho nga mga iterator.
///
/// Kini ang punoan nga sapa nga trait.
/// Alang sa dugang bahin sa konsepto sa mga sapa sa kinatibuk-an, palihug tan-awa ang [module-level documentation].
/// Sa partikular, tingali gusto nimong mahibal-an kung giunsa ang [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Ang lahi sa mga butang nga gihatag sa sapa.
    type Item;

    /// Mosulay sa pagbitad sa sa sunod nga bili sa sapa niini, pagparehistro sa kasamtangan nga buluhaton alang sa wakeup kon ang bili dili pa anaa, ug pagbalik `None` kon ang sapa mao ang gikapoy.
    ///
    /// # Bumalik bili
    ///
    /// Adunay pipila ka posible nga mga prinsipyo pagbalik, ang matag nagpakita sa usa ka lahi nga sapa nga kahimtang:
    ///
    /// - `Poll::Pending` nagpasabut nga ang sunod nga kantidad sa kini nga sapa dili pa andam.Ang mga pagpatuman masiguro nga ang karon nga buluhaton ipahibalo kung kanus-a andam ang sunod nga kantidad.
    ///
    /// - `Poll::Ready(Some(val))` paagi nga ang mga sapa malamposong og usa ka bili, `val`, ug makapatunghag dugang nga mga prinsipyo sa sunod-sunod nga `poll_next` tawag.
    ///
    /// - `Poll::Ready(None)` paagi nga ang mga sapa nga gi-undang, ug `poll_next` kinahanglan nga dili ikapangaliyupo pag-usab.
    ///
    /// # Panics
    ///
    /// Kung nahuman na ang usa ka sapa (gibalik ang `Ready(None)` from `poll_next`), nga gitawag ang `poll_next` nga pamaagi nga usab mahimo og panic, block hangtod sa hangtod, o hinungdan sa uban pang mga lahi nga problema; ang `Stream` trait wala`y kinahanglan nga mga kinahanglanon sa mga epekto sa mao nga tawag.
    ///
    /// Apan, ingon nga ang mga `poll_next` pamaagi dili nagtimaan `unsafe`, naandan lagda ni Rust paggamit: tawag kinahanglan dili hinungdan sa dili tino ang kinaiya (sa panumdoman sa korapsyon, sayop nga paggamit sa `unsafe` gimbuhaton, o sa sama), sa walay pagtagad sa estado sa sapa sa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Gibalik ang mga utlanan sa nahabilin nga gitas-on sa stream.
    ///
    /// Sa piho nga, `size_hint()` mobalik sa usa ka tuple diin ang unang elemento mao ang ubos-ubos nga gigapos, ug ang ikaduha nga elemento mao ang ibabaw nga ginapos.
    ///
    /// Ang ikaduha nga katunga sa sa tuple nga mibalik ang usa ka [`Option`]`<`[`usize`] `>`.
    /// Usa ka [`None`] dinhi paagi nga sa bisan walay nailhan ibabaw nga gigapos, o sa ibabaw nga gigapos ang mas dako pa kay sa [`usize`].
    ///
    /// # pagpatuman mubo nga mga sulat
    ///
    /// Wala kini gipatuman nga ang usa ka pagpatuman sa sapa magbunga sa gideklara nga gidaghanon sa mga elemento.Ang us aka buggy stream mahimong makahatag gamay kaysa sa ubos nga gihigot o labaw pa sa taas nga utlanan sa mga elemento.
    ///
    /// `size_hint()` panguna nga gituyo aron magamit alang sa mga pag-optimize sama sa pagreserba sa wanang alang sa mga elemento sa sapa, apan dili kinahanglan pagsaligan, pananglit, tangtangon ang mga pagbutang sa mga utlanan sa dili luwas nga code.
    /// Usa ka sayop nga pagpatuman sa `size_hint()` kinahanglan nga dili mosangpot ngadto sa paglapas sa handumanan sa kaluwasan.
    ///
    /// Nga miingon, ang pagpatuman kinahanglan nga mohatag og usa ka husto nga pagbana-bana, tungod kay kon dili kini mahimo nga usa ka paglapas sa trait ni protocol.
    ///
    /// Ang default nga pagpatuman mobalik og `(0,` [`Wala`]`)`nga tama alang sa bisan unsang sapa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}