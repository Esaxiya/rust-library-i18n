//! Mahugpong nga dili pareho nga pag-ulit.
//!
//! Kung ang futures dili parehas nga mga kantidad, nan ang mga sapa dili parehas nga iterator.
//! Kong ikaw sa imong kaugalingon sa usa ka asynchronous koleksyon sa pipila ka mga matang, ug gikinahanglan sa paghimo sa usa ka operasyon sa mga elemento sa miingon collection, inyong madali modagan ngadto sa 'streams'.
//! Gigamit ang mga sapa sa idiomatiko nga dili parehas nga Rust code, busa angay nga pamilyar sa kanila.
//!
//! Sa wala pa sa pagpatin-aw sa dugang, ang ni pakigpulong kon sa unsang paagi module kini nga estraktura:
//!
//! # Organization
//!
//! module Kini nga kadaghanan organisar pinaagi sa matang:
//!
//! * [Traits] mao ang punoan nga bahin: kini nga traits gipasabut kung unsang lahi ang mga sapa nga anaa ug kung unsa ang mahimo nimo niini.Ang mga pamaagi sa kini nga traits angayan nga ibutang sa dugang nga oras sa pagtuon.
//! * Ang mga pag-andar nagahatag pila nga makatabang nga mga paagi aron makahimo pipila nga mga punoan nga sapa.
//! * Ang mga istraktura kanunay nga mga pagbalik nga lahi sa lainlaing mga pamaagi sa traits nga modyul niini.Kasagaran gusto nimo nga tan-awon ang pamaagi nga nagmugna sa `struct`, kaysa sa `struct` mismo.
//! Alang sa dugang nga detalye bahin sa ngano, tan-awa ang '[Implementing Stream](#implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Mao na!dig Atong ngadto sa sapa.
//!
//! # Stream
//!
//! Ang kasingkasing ug kalag sa kini nga modyul mao ang [`Stream`] trait.Ang kinauyokan sa [`Stream`] ingon niini:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Dili sama sa `Iterator`, `Stream` naghimo sa usa ka kalainan tali sa [`poll_next`] pamaagi nga mao ang gigamit sa dihang pagpatuman sa usa ka `Stream`, ug usa ka (to-be-implemented) `next` pamaagi nga gigamit sa dihang nga nagaut-ut sa usa ka sapa.
//!
//! Ang mga konsumedor sa `Stream` kinahanglan ra nga ikonsidera ang `next`, nga kung tawgon, ibalik ang usa ka future nga nagahatag `Option<Stream::Item>`.
//!
//! Ang future nga gibalik sa `next` makahatag `Some(Item)` basta adunay mga elemento, ug kung nahuman na silang tanan, mohatag `None` aron ipakita nga nahuman na ang pag-ulit.
//! Kon kita naghulat sa usa ka butang asynchronous sa determinasyon, sa future ang maghulat hangtud sa sapa andam sa pagtugyan sa pag-usab.
//!
//! Ang mga indibidwal nga sapa mahimong makapili nga ipadayon ang pag-ulit, ug busa ang pagtawag sa `next` pag-usab mahimo o dili sa katapusan makahatag usab og `Some(Item)` sa us aka punto.
//!
//! Ang tibuuk nga kahulugan sa [`Stream`] lakip ang uban pang mga pamaagi, apan kini mga default nga pamaagi, gitukod sa ibabaw sa [`poll_next`], ug makuha nimo kini nga libre.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Pagpatuman sa Stream
//!
//! Paghimo sa usa ka sapa sa imong kaugalingon nga mga naglakip sa duha ka mga lakang: sa paghimo sa usa `struct` sa paghupot sa estado sa sapa, ug unya implementar sa [`Stream`] alang sa nga `struct`.
//!
//! Himoon naton ang usa ka sapa nga ginganlan `Counter` nga giihap gikan sa `1` hangtod `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Una, ang istruktura:
//!
//! /// Usa ka sapa nga importante gikan sa usa ngadto sa lima ka
//! struct Counter {
//!     count: usize,
//! }
//!
//! // gusto namon nga ang among ihap magsugod sa usa, busa dugangan namon ang usa ka new() nga pamaagi aron makatabang.
//! // Kini mao ang dili hugot nga gikinahanglan, apan sayon.
//! // Hinumdomi nga gisugdan namon ang `count` sa zero, makita namon kung ngano sa pagpatuman sa `poll_next()`'s sa ubos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pagkahuman, gipatuman namon ang `Stream` alang sa among `Counter`:
//!
//! impl Stream for Counter {
//!     // mag-ihap kami uban ang usize
//!     type Item = usize;
//!
//!     // poll_next() mao ra ang kinahanglan nga pamaagi
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Pagdugang sa among ihap.Kini mao ang ngano nga kita nagsugod sa zero.
//!         self.count += 1;
//!
//!         // Check sa pagtan-aw kon nang kita nahuman ihap o dili.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Ang mga sapa *tamad*.Kini paagi nga lang sa paghimo sa usa ka sapa dili _do_ sa usa ka bug-os nga daghan.Wala gyud mahitabo hangtod nga tawagan nimo ang `next`.
//! Kini mao ang usahay ang usa ka tinubdan sa kalibog sa dihang pagmugna sa usa ka sapa lamang alang sa iyang kiliran epekto.
//! Pasidan-an kami sa nagtipun-og bahin sa kini nga lahi nga batasan:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;