//! Tapolan prinsipyo ug usa ka higayon nga Initialization sa nagahunong data.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Ang usa ka cell nga mahimo nga gisulat sa makausa lamang.
///
/// Dili sama sa `RefCell`, ang usa ka `OnceCell` naghatag lamang nga gipaambit nga mga reperensya nga `&T` sa kantidad niini.
/// Dili sama sa `Cell`, usa ka `OnceCell` wala magkinahanglan pagkopya o ilis sa bili sa pag-access niini.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: gisulat sa labing kausa.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Naghimo usa ka bag-ong walay sulod nga cell.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Nakakuha ang paghisgot sa tinuod nga hinungdan sa bili.
    ///
    /// Mibalik `None` kon ang cell mao ang walay sulod.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SAFETY: Luwas tungod sa `makanunayon ni inner`
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Nakakuha ang mutable paghisgot sa tinuod nga hinungdan sa bili.
    ///
    /// Mibalik `None` kon ang cell mao ang walay sulod.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SAFETY: Luwas tungod kay kita adunay talagsaon nga access
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Gitakda ang mga sulud sa cell sa `value`.
    ///
    /// # Errors
    ///
    /// Kini nga pamaagi mobalik `Ok(())` kon ang cell walay sulod ug `Err(value)` kon kini bug-os nga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SAFETY: Luwas tungod kay kita dili na overlapping mutable nagapangutang
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAFETY: Kini mao lamang ang dapit diin kita ang mga luna, walay rasa
        // tungod sa reentrancy/concurrency posible, ug na gitan-aw kita nga luna karon `None`, mao nga kini nga isulat nagmintinar makanunayon ang `inner` ni.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Nakakuha sa mga sulod sa cell, initializing kini sa `f` kon ang cell walay sulod.
    ///
    /// # Panics
    ///
    /// Kon `f` panics, ang panic ang propagated sa caller, ug ang cell nagpabilin uninitialized.
    ///
    ///
    /// Kini mao ang usa ka sayop sa reentrantly initialize sa cell gikan sa `f`.Ang pagbuhat sa ingon moresulta sa usa ka panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Nakakuha sa mga sulod sa cell, initializing kini sa `f` kon ang cell walay sulod.
    /// Kon ang cell walay sulod ug `f` napakyas, usa ka sayop ang mibalik.
    ///
    /// # Panics
    ///
    /// Kon `f` panics, ang panic ang propagated sa caller, ug ang cell nagpabilin uninitialized.
    ///
    ///
    /// Kini mao ang usa ka sayop sa reentrantly initialize sa cell gikan sa `f`.Ang pagbuhat sa ingon moresulta sa usa ka panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Mubo nga sulat nga + ang pipila * matang sa reentrant Initialization unta mosangpot sa UB (tan-awa sa `reentrant_init` test).
        // nagtuo ko nga lang pagkuha sa niini nga `assert`, samtang pagtuman sa `set/get` nga tingog, apan kini daw mas maayo nga panic, kay sa hilom sa paggamit sa usa ka tigulang nga bili.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Gikonsumo ang selyula, gibalik ang gibug-aton nga kantidad.
    ///
    /// Mibalik `None` kon ang cell walay sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Tungod kay `into_inner` nagkinahanglan `self` sa bili, ang tighipos sa urong nagmatuod nga kini dili karon hinulaman.
        // Busa kini mao ang luwas nga mobalhin gikan sa `Option<T>`.
        self.inner.into_inner()
    }

    /// Nagkinahanglan sa bili gikan niining `OnceCell`, pagbalhin niini ngadto sa usa ka uninitialized nga kahimtang.
    ///
    /// Wala`y epekto ug ibalik ang `None` kung ang `OnceCell` wala pa masugdan.
    ///
    /// Safety gigarantiyahan sa nagkinahanglan sa usa ka mutable pakisayran.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Ang usa ka bili nga initialized sa unang access.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   andam initializing
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Nagmugna sa usa ka bag-o nga tapulan bili sa mga gihatag initializing function.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Nagpugos sa evaluation sa niini nga tapulan bili ug mobalik sa usa ka paghisgot sa resulta.
    ///
    ///
    /// Kini mao ang katumbas sa `Deref` impl, apan ang tin-aw.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Nagmugna sa usa ka bag-o nga tapulan bili sa paggamit `Default` ingon sa initializing function.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}