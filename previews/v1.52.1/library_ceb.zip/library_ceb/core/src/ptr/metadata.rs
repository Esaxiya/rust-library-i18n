#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Naghatag tipo nga metadata nga tipo sa bisan unsang tudlo nga tipo.
///
/// # pointer metadata
///
/// Ang mga hilaw nga tipo sa pointer ug tipo sa pakisayran sa Rust mahimong hunahunaon nga hinimo sa duha nga bahin:
/// ang usa ka data pointer nga naglangkob sa handumanan address sa bili, ug ang uban metadata.
///
/// Alang sa mga lahi nga statically-size (nga nagpatuman sa `Sized` traits) ingon man alang sa mga `extern` nga lahi, giingon nga "nipis" ang mga pointers: ang metadata zero-size ug ang tipo niini `()`.
///
///
/// Pointers sa [dynamically-sized types][dst] giingon nga "halapad" o "tambok", sila adunay dili-zero-kadako metadata:
///
/// * Alang sa mga istraktura nga ang katapusang natad usa ka DST, ang metadata mao ang metadata alang sa katapusang natad
/// * Alang sa tipo nga `str`, ang metadata ang gitas-on sa mga byte ingon `usize`
/// * Alang sa mga klase sa hiwa sama sa `[T]`, ang metadata ang gitas-on sa mga butang ingon `usize`
/// * Kay trait mga butang sama sa `dyn SomeTrait`, metadata mao [`DynMetadata<Self>`][DynMetadata] (eg `DynMetadata<dyn SomeTrait>`)
///
/// Sa future, ang sinultian nga Rust mahimong makakuha bag-ong mga lahi nga lahi nga adunay lainlaing pointer metadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Ang `Pointee` trait
///
/// Ang punto sa kini nga trait mao ang `Metadata` nga may kalabutan nga tipo niini, nga mao ang `()` o `usize` o `DynMetadata<_>` sama sa gihulagway sa taas.
/// Awtomatiko kini nga gipatuman alang sa matag lahi.
/// Mahimo kini ipatuud nga ipatuman sa usa ka generic nga konteksto, bisan kung wala`y katugbang nga gihigot.
///
/// # Usage
///
/// Ang mga hilaw nga panudlo mahimong madugta sa address sa datos ug mga sangkap sa metadata sa ilang pamaagi nga [`to_raw_parts`].
///
/// Sa laing bahin, metadata lamang mahimong makuha sa mga function [`metadata`].
/// Ang usa ka pakisayran mahimong maipasa sa [`metadata`] ug implicitly coerced.
///
/// Ang usa ka (possibly-wide) pointer mahimong ibalik gikan sa address ug metadata nga adunay [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ang tipo alang sa metadata sa mga panudlo ug pakisayran sa `Self`.
    #[lang = "metadata_type"]
    // NOTE: Ipadayon ang trait bounds sa `static_assert_expected_bounds_for_metadata`
    //
    // sa `library/core/src/ptr/metadata.rs` dungan sa mga dinhi:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ang mga panudlo sa lahi nga nagpatuman sa kining trait alyas "manipis".
///
/// Kauban niini ang mga statically-`Sized` nga lahi ug `extern` nga lahi.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ayaw pagpalig-on kini sa wala pa lig-on ang sinultian sa trait sa sinultian?
pub trait Thin = Pointee<Metadata = ()>;

/// Kuhaa ang metadata nga sangkap sa usa ka pointer.
///
/// Ang mga mithi sa tipo nga `*mut T`, `&T`, o `&mut T` mahimong mapasa nga diretso sa kini nga pag-andar tungod kay kini implikado nga gipugos sa `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KALUWASAN: Ang pag-access sa kantidad gikan sa `PtrRepr` nga unyon luwas na tungod sa * const T
    // ug mga PtrComponent<T>adunay parehas nga mga layout sa memorya.
    // Ang std ra ang makahimo niini nga garantiya.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Naghimo usa ka (possibly-wide) nga hilaw nga pointer gikan sa usa ka adres sa datos ug metadata.
///
/// Kini nga paglihok luwas apan ang gipabalik nga tudlo dili kinahanglan nga luwas sa pagkaguba.
/// Alang sa mga hiwa, tan-awa ang dokumentasyon sa [`slice::from_raw_parts`] alang sa mga kinahanglanon sa kahilwasan.
/// Alang sa mga butang nga trait, ang metadata kinahanglan maggikan sa usa ka pointer ngadto sa parehas nga nagpahiping dili pa gihipos nga tipo.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KALUWASAN: Ang pag-access sa kantidad gikan sa `PtrRepr` nga unyon luwas na tungod sa * const T
    // ug mga PtrComponent<T>adunay parehas nga mga layout sa memorya.
    // Ang std ra ang makahimo niini nga garantiya.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Gihimo ang parehas nga pagpaandar ingon [`from_raw_parts`], gawas nga ang usa ka hilaw nga `*mut` pointer ang gibalik, sukwahi sa usa ka hilaw nga `* const` pointer.
///
///
/// Tan-awa ang dokumentasyon sa [`from_raw_parts`] alang sa dugang nga mga detalye.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KALUWASAN: Ang pag-access sa kantidad gikan sa `PtrRepr` nga unyon luwas na tungod sa * const T
    // ug mga PtrComponent<T>adunay parehas nga mga layout sa memorya.
    // Ang std ra ang makahimo niini nga garantiya.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manwal sa impl nga gikinahanglan sa paglikay sa `T: Copy` gigapos.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Kinahanglan ang manwal nga impl aron malikayan ang `T: Clone` nga gigapos.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Ang metadata alang sa usa ka `Dyn = dyn SomeTrait` trait nga tipo sa butang.
///
/// Kini mao ang usa ka pointer sa usa ka vtable (virtual tawag lamesa) nga nagrepresentar sa tanan nga mga gikinahanglan nga impormasyon sa pagmaniobra sa mga matang konkreto gitipigan sulod sa usa ka trait butang.
/// Ang nota labi na kini adunay sulud:
///
/// * gidak-on sa tipo
/// * pag-align sa tipo
/// * usa ka pointer sa `drop_in_place` impl nga tipo (mahimo nga no-op alang sa plain-old-data)
/// * mga panudlo sa tanan nga mga pamaagi alang sa pagpatuman sa tipo sa trait
///
/// Hinumdomi nga ang nahauna nga tulo espesyal tungod kay kinahanglanon kini nga paggahin, paghulog, ug pag-atubang sa bisan unsang butang nga trait.
///
/// Posible nga nganlan kini nga istraktura sa usa ka lahi nga parameter nga dili usa ka `dyn` trait nga butang (pananglitan `DynMetadata<u64>`) apan dili makakuha usa ka makahuluganon nga kantidad sa maong istruktura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Ang sagad nga unahan sa tanan nga mga vtable.Gisundan kini sa mga point point sa pag-andar alang sa mga pamaagi sa trait.
///
/// Pribado nga detalye sa pagpatuman sa `DynMetadata::size_of` ug uban pa.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Gibalik ang gidak-on sa tipo nga kauban niini nga vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Gibalik ang paghanay sa tipo nga kauban niini nga vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Gibalik ang kadako ug paghanay sama sa usa ka `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // KALUWASAN: gipagawas sa tagtipon kini nga vtable alang sa usa ka konkreto nga Rust nga tipo diin
        // Nahibal-an nga adunay usa ka balido nga layout.Parehas nga katarungan sama sa `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Kinahanglan ang manwal nga impls aron malikayan ang mga utlanan sa `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}