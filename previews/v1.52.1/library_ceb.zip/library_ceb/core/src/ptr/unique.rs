use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Usa ka wrapper sa palibot sa usa ka hilaw nga non-bili `*mut T` nga nagpakita nga ang mga tag-iya sa wrapper niini nga nanag-iya sa referent.
/// Mapuslanon alang sa pagtukod ideya ug mga hiyas sama sa `Box<T>`, `Vec<T>`, `String`, ug `HashMap<K, V>`.
///
/// Dili sama sa `*mut T`, `Unique<T>` nagabuhat "as if" sa usa ka higayon sa `T`.
/// Gipatuman niini ang `Send`/`Sync` kung `T` ang `Send`/`Sync`.
/// Gipasabut usab niini ang lahi nga kusug nga aliasing garantiya sa usa ka pananglitan sa `T` nga mapaabut:
/// ang referent sa pointer dili kinahanglan nga giusab nga walay usa ka talagsaon nga dalan sa iyang pagbaton Talagsaong.
///
/// Kung dili ka sigurado kung husto ba nga gamiton ang `Unique` alang sa imong katuyoan, hunahunaa ang paggamit sa `NonNull`, nga adunay mga mahuyang nga semantiko.
///
///
/// Dili sama sa `*mut T`, ang tudlo kinahanglan kanunay nga wala'y bili, bisan kung ang tudlo dili gyud gihatagan gahum.
/// Kini aron magamit sa mga enum ang gidili nga kantidad ingon usa ka diskriminasyon-ang `Option<Unique<T>>` adunay parehas nga gidak-on sa `Unique<T>`.
/// Apan ang pointer aron pa magpaon kon kini dili dereferenced.
///
/// Dili sama sa `*mut T`, ang `Unique<T>` covariant labaw sa `T`.
/// Kini kinahanglan kanunay nga husto alang sa bisan unsang lahi nga nagsuporta sa mga kinahanglanon sa aliasing ni Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: kini nga marker wala`y sangputanan alang sa pagkalainlain, apan kinahanglan
    // aron mahibal-an sa dropck nga lohikal nga amon ang usa ka `T`.
    //
    // Alang sa mga detalye, tan-awa ang:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ang mga pointers mao ang `Send` kung ang `T` mao ang `Send` tungod kay ang datos nga ilang gihisgutan wala mabalhin.
/// Mubo nga sulat nga kini nga aliasing makanunayon ang unenforced sa matang nga sistema;ang abstraction sa paggamit sa `Unique` kinahanglan pagpatuman niini.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ang mga pointers mao ang `Sync` kung ang `T` mao ang `Sync` tungod kay ang datos nga ilang gihisgutan wala mabalhin.
/// Mubo nga sulat nga kini nga aliasing makanunayon ang unenforced sa matang nga sistema;ang abstraction sa paggamit sa `Unique` kinahanglan pagpatuman niini.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Naghimo usa ka bag-ong `Unique` nga nagbitay, apan maayo nga pagkahanay.
    ///
    /// Kini mao ang mapuslanon alang sa initializing matang nga hinayng naglakaw samtang mogahin, sama sa `Vec::new` nagabuhat.
    ///
    /// Matikdi nga ang pointer bili mahimong kalagmitan nagrepresentar sa usa ka balido nga pointer sa usa ka `T`, nga nagpasabot kini nga kinahanglan dili gamiton ingon nga usa ka "not yet initialized" sentinel bili.
    /// Ang mga lahi nga tapulan nga naggahin kinahanglan magsubay sa pagpauna sa ubang mga paagi.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() mobalik sa usa ka balido, non-bili pointer.Ang
        // ang mga kondisyon aron tawagan ang new_unchecked() sa ingon gitahod.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Naghimo usa ka bag-ong `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` kinahanglan nga dili null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `ptr` dili null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Nagmugna sa usa ka bag-o nga `Unique` kon `ptr` mao ang non-bili.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: pointer Ang na gitan-aw ug dili bili.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nakuha ang nagpahiping `*mut` pointer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences sa sulod.
    ///
    /// Ang sangputanan sa tibuok kinabuhi gihigot sa kaugalingon busa kini naggawi "as if" kini sa tinuud usa ka pananglitan sa T nga nanghulam.
    /// Kung kinahanglan ang labi ka taas nga kinabuhi nga (unbound), gamita ang `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka pakisayran.
        unsafe { &*self.as_ptr() }
    }

    /// Labing hinungdan nga gipanghimatuud ang sulud.
    ///
    /// Ang sangputanan sa tibuok kinabuhi gihigot sa kaugalingon busa kini naggawi "as if" kini sa tinuud usa ka pananglitan sa T nga nanghulam.
    /// Kon ang usa ka na (unbound) tibuok kinabuhi ang gikinahanglan, gamita `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka mutable nga pakisayran.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nag-cast sa usa ka tudlo sa uban pang lahi.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KALUWASAN: Ang Unique::new_unchecked() nagmugna usa ka bag-ong talagsaon ug mga kinahanglanon
        // ang gihatag nga pointer aron dili mahimong null.
        // Tungod kay kita agi sa kaugalingon ingon nga usa ka pointer, dili kini mahimo nga bili.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Usa ka mutable paghisgot dili mahimo nga bili
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}