//! Kinamut nga pagdumala ang memorya pinaagi sa mga hilaw nga puntos.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Daghang mga gimbuhaton sa kini nga modyul ang nagdala hilaw nga mga panudlo ingon mga pangatarungan ug pagbasa gikan o pagsulat sa kanila.Aron kini luwas, kini nga mga panudlo kinahanglan nga *balido*.
//! Kung ang usa ka panudlo balido depende sa operasyon nga gigamit alang sa (pagbasa o pagsulat), ug ang gilapdon sa memorya nga na-access (ie, pila ka byte ang read/written).
//! Kadaghanan sa mga pag-andar naggamit `*mut T` ug `* const T` aron ma-access ra ang usa ka kantidad, diin ang dokumentasyon gikuha ang gidak-on ug implicitly nga giisip kini nga `size_of::<T>()` bytes.
//!
//! Ang tukma nga mga lagda alang sa pagkabalido wala pa matino.Ang garantiya nga gihatag sa niini nga punto mao ang kaayo gamay:
//!
//! * Usa ka [null] pointer mao ang *dili* balido, dili bisan sa accesses sa [size zero][zst].
//! * Kay sa usa ka pointer nga mahimong balido, kini mao ang gikinahanglan, apan dili sa kanunay igo, nga ang pointer nga *dereferenceable*: ang handumanan laing mga sa gihatag nga gidak-on sugod sa pointer tanan kinahanglan anaa sa sulod sa mga utlanan sa usa ka gigahin nga butang.
//!
//! Mubo nga sulat nga sa Rust, ang matag (stack-allocated) baryable gikonsiderar nga usa ka lahi nga gigahin butang.
//! * Bisan alang sa mga operasyon sa [size zero][zst], ang tudlo dili kinahanglan nga nagtudlo sa gihisgutan nga memorya, ie, ang deallocation naghimo sa mga tudlo nga dili balido bisan alang sa mga zero-kadako nga operasyon.
//! Apan, sa pagsalibay sa bisan unsa nga non-zero integer *literal* sa usa ka pointer mao ang balido alang sa zero-kadako accesses, bisan kon ang pipila handumanan mahitabo sa anaa sa address nga ug gets deallocated.
//! Kini katumbas sa pagsulat sa imong kaugalingon nga taghatag: ang paggahin og zero-kadako nga mga butang dili kaayo lisud.
//! Ang canonical nga paagi aron makakuha usa ka pointer nga balido alang sa mga zero-kadako nga mga pag-access mao ang [`NonNull::dangling`].
//! * Ang tanan nga mga pag-access nga gihimo sa mga gimbuhaton sa kini nga modyul mao ang *dili atomiko* sa kahulugan nga [atomic operations] nga gigamit aron magkasabay tali sa mga sulud.
//! Kini gipasabut nga dili matino nga pamatasan aron makahimo duha nga dungan nga pag-access sa parehas nga lokasyon gikan sa lainlaing mga thread gawas kung ang parehas nga pag-access gibasa ra gikan sa memorya.
//! Timan-i nga klarong kauban niini ang [`read_volatile`] ug [`write_volatile`]: Dili magamit ang dali nga pag-access alang sa inter-thread nga paghiusa.
//! * Ang sangputan sa paglabay sa usa ka pakisayran sa usa ka pointer balido hangtod nga ang nagpahiping butang buhi ug wala`y pakisayran (mga panudlo ra) nga magamit aron ma-access ang parehas nga memorya.
//!
//! Ang kini nga mga axiom, kauban ang mabinantayon nga paggamit sa [`offset`] alang sa pointer arithmetic, igo aron maipatuman nga tama ang daghang mga gamit nga dili luwas nga code.
//! Lig-on nga garantiya nga gihatag sa ngadto-ngadto, ingon nga ang mga [aliasing] lagda nga determinado.
//! Alang sa dugang nga kasayuran, tan-awa ang [book] maingon man ang seksyon sa pakisayran nga gipahinungod sa [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ang mga balido nga panudlo nga hilaw sama sa gihubit sa taas dili kinahanglan nga husto nga nakahanay (diin ang pag-align sa "proper" gihubit sa tipo sa pointee, ie, ang `*const T` kinahanglan nga ipahanay sa `mem::align_of::<T>()`).
//! Bisan pa, kadaghanan sa mga gimbuhaton nagkinahanglan sa ilang mga argumento nga husto nga ipahiangay, ug klarong isulti kini nga kinahanglanon sa ilang dokumentasyon.
//! Talagsaong mga eksepsiyon niini ang [`read_unaligned`] ug [`write_unaligned`].
//!
//! Kung ang usa ka pag-andar nanginahanglan husto nga paglinya, gihimo kini bisan kung ang pag-access adunay gidak-on nga 0, ie, bisan kung ang memorya wala gyud matandog.Hunahunaa ang paggamit sa [`NonNull::dangling`] sa ingon nga mga kaso.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Pagpatuman sa destructor (kung adunay) sa gipunting nga kantidad.
///
/// Kini mao ang semantically katumbas sa pagtawag [`ptr::read`] ug pagsalikway sa resulta, apan may sa mosunod nga mga bentaha:
///
/// * Gikinahanglan * nga gamiton ang `drop_in_place` aron mahulog ang wala`y gidak-on nga mga klase sama sa mga butang nga trait, tungod kay dili kini mabasa sa stack ug nahulog nga normal.
///
/// * Kini labi ka mahigalaon sa optimizer nga buhaton kini sa [`ptr::read`] kung ihulog ang manwal nga gigahin nga panumduman (pananglitan, sa pagpatuman sa `Box`/`Rc`/`Vec`), tungod kay dili kinahanglan nga ipanghimatuud sa tagpagsama nga kini tunog aron mapalayo ang kopya.
///
///
/// * Mahimo kini gamiton aron ihulog ang datos nga [pinned] kung ang `T` dili `repr(packed)` (ang naka-pin nga datos dili kinahanglan ibalhin sa wala pa kini ihulog).
///
/// Wala matumong nga mga prinsipyo dili nagatulo sa dapit, sila kinahanglan nga kopyahon sa ilaray nahimutangan una sa paggamit sa [`ptr::read_unaligned`].Alang sa mga naka-pack nga struct, kini nga paglihok gihimo nga awtomatiko sa tagtipon.
/// Kini nagpasabut nga ang mga uma sa mga naka-pack nga struct dili ihulog sa lugar.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `to_drop` kinahanglan [valid] alang sa parehas nga pagbasa ug pagsulat.
///
/// * `to_drop` kinahanglan nga sa tukmang paagi ilaray.
///
/// * Ang kantidad nga `to_drop` puntos aron kinahanglan nga balido alang sa paghulog, nga mahimong gipasabut nga kini kinahanglan nga ipadayon ang dugang nga mga invariant, kini pagsalig sa tipo.
///
/// Ingon kadugangan, kung ang `T` dili [`Copy`], ang paggamit sa gitudlo nga kantidad pagkahuman pagtawag sa `drop_in_place` mahimong hinungdan sa wala matino nga pamatasan.Hinumdomi nga ang `*to_drop = foo` giihap ingon usa ka paggamit tungod kay kini ang hinungdan mahulog usab ang kantidad.
/// [`write()`] mahimong gigamit sa overwrite data sa walay hinungdan sa niini nga nagatulo.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kinamut nga pagtangtang sa katapusan nga butang gikan sa usa ka vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Pagkuha usa ka hilaw nga puntos sa katapusan nga elemento sa `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Gipamub-an ang `v` aron mapugngan ang katapusang butang nga mahulog.
///     // Una namon kini nga gibuhat, aron mapugngan ang mga isyu kung ang `drop_in_place` sa ubus sa panics.
///     v.set_len(1);
///     // Kung wala ang usa ka tawag nga `drop_in_place`, ang katapusan nga aytem dili mawala, ug ang memorya nga gidumala niini maipagawas.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Siguroha nga sa katapusan nga butang nga nagpatulo sa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Timan-i nga ang taghimo naghimog kopya niini nga awtomatiko sa paghulog sa mga naka-pack nga struct, ie, dili ka kasagaran mabalaka bahin sa mga kana nga isyu kung dili nimo tawagan ang `drop_in_place` sa kamut.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code dinhi wala nga butang, kini gipulihan sa tinuod nga drop papilit sa tighipos.
    //

    // KALuwas-an: tan-awa ang komento sa taas
    unsafe { drop_in_place(to_drop) }
}

/// Naghimo usa ka null nga hilaw nga pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Naghimo usa ka null mutable hilaw nga pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Kinahanglan ang manwal nga impl aron malikayan ang `T: Clone` nga gigapos.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manwal sa impl nga gikinahanglan sa paglikay sa `T: Copy` gigapos.
impl<T> Copy for FatPtr<T> {}

/// Porma sa usa ka hilaw nga ad-ad gikan sa usa ka pointer ug usa ka gitas-on.
///
/// Ang `len` argumento mao ang gidaghanon sa mga **elemento**, dili ang gidaghanon sa mga bytes.
///
/// Kini nga kalihokan luwas, apan ang tinuud nga paggamit sa bili sa pagbalik dili luwas.
/// Tan-awa ang dokumentasyon sa [`slice::from_raw_parts`] alang sa mga kinahanglanon sa pagkaluwas sa hiwa.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // paghimo usa ka slice pointer sa pagsugod sa usa ka pointer sa una nga elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KALUWASAN: Ang pag-access sa kantidad gikan sa unyon nga `Repr` luwas na tungod sa * const [T]
        //
        // ug ang FatPtr adunay parehas nga mga layout sa memorya.Lamang std makahimo niini nga garantiya.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Gihimo ang parehas nga pagpaandar ingon [`slice_from_raw_parts`], gawas nga ang usa ka hilaw nga mabalhin nga hiwa ang ibalik, sukwahi sa usa ka hilaw nga dili mabalhin nga hiwa.
///
///
/// Tan-awa ang dokumentasyon sa [`slice_from_raw_parts`] alang sa dugang nga mga detalye.
///
/// Kini nga kalihokan luwas, apan ang tinuud nga paggamit sa bili sa pagbalik dili luwas.
/// Tan-awa ang dokumentasyon sa [`slice::from_raw_parts_mut`] alang sa mga kinahanglanon sa pagkaluwas sa hiwa.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // paghatag usa ka kantidad sa usa ka indeks sa hiwa
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KALUWASAN: Ang pag-access sa kantidad gikan sa unyon nga `Repr` luwas na sukad * mut [T]
        // ug ang FatPtr adunay parehas nga mga layout sa memorya
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Gibalhin ang mga kantidad sa duha nga mabalhin nga lokasyon sa parehas nga lahi, nga wala usab gipagawas ang gahum.
///
/// Apan alang sa mosunud nga duha nga mga eksepsyon, kini nga kalihokan katumbas sa semantikal nga [`mem::swap`]:
///
///
/// * Naglihok kini sa mga hilaw nga panudlo imbis nga mga pakisayran.
/// Kung adunay magamit nga mga pakisayran, kinahanglan nga gipalabi ang [`mem::swap`].
///
/// * Ang duha nga gitudlo nga mga kantidad mahimo nga magsapaw.
/// Kon ang mga prinsipyo sa pagbuhat sa sapaw, nan, ang overlapping rehiyon sa handumanan gikan sa `x` gamiton.
/// Gipakita kini sa ikaduha nga pananglitan sa ubus.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * Ang duha `x` ug `y` kinahanglan [valid] alang sa mga mabasa ug misulat.
///
/// * Ang parehas nga `x` ug `y` kinahanglan nga husto nga pagkahan-ay.
///
/// Hinumdomi nga bisan kung ang `T` adunay gidak-on nga `0`, ang mga panudlo kinahanglan nga dili NUL ug husto nga nakahanay.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pagpuli sa duha nga dili nagsapaw nga mga rehiyon:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // kini ang `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // kini ang `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Pagpuli sa duha ka nagsapaw nga mga rehiyon:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // kini ang `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // kini ang `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Ang lab-a `1..3` sa ad-ad sapaw taliwala sa `x` ug `y`.
///     // Makatarunganon nga mga sangputanan alang sa kanila mahimong `[2, 3]`, aron ang mga indeks nga `0..3` mga `[1, 2, 3]` (parehas sa `y` sa wala pa ang `swap`);o alang kanila nga mahimong `[0, 1]` aron ang mga indeks nga `1..4` mga `[0, 1, 2]` (parehas sa `x` sa wala pa ang `swap`).
/////
///     // pagpatuman Kini nga gihubit sa paghimo sa ulahing pagpili.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Hatagi sa atong mga kaugalingon sa pipila ka mga garas luna sa buhat uban.
    // Dili kita kinahanglan mabalaka bahin sa mga tulo: Ang `MaybeUninit` wala'y gibuhat kung nahulog.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Gihimo ang kasaligan nga swap: kinahanglan nga garantiya sa nanawag nga ang `x` ug `y` balido alang sa mga pagsulat ug maayong pagkahanay.
    // `tmp` dili mahimo nga nagsapawan sa bisan unsang `x` o `y` tungod kay ang `tmp` gigahin ra sa stack ingon usa ka gilain nga gigahin nga butang.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ug `y` mahimong magsapaw
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Gibaylo ang `count * size_of::<T>()` bytes taliwala sa duha nga mga rehiyon nga panumduman nga nagsugod sa `x` ug `y`.
/// Ang duha nga rehiyon kinahanglan *dili* magsapaw.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * Parehas nga `x` ug `y` kinahanglan [valid] alang sa parehas nga pagbasa ug pagsulat sa `ihap *
///   size_of: :<T>() `byte.
///
/// * Ang parehas nga `x` ug `y` kinahanglan nga husto nga pagkahan-ay.
///
/// * Ang rehiyon sa panumdoman nagsugod sa `x` nga adunay gidak-on nga `ihap *
///   size_of: :<T>() `mga byte kinahanglan *dili* magsapaw sa rehiyon sa panumduman nga magsugod sa `y` nga adunay parehas nga kadako.
///
/// Mubo nga sulat nga bisan kon ang mga epektibo nga gikopya gidak-on (`-isip * size_of: :<T>Ang ()`) mao ang `0`, ang mga panudlo kinahanglan dili NUL ug husto nga nakahanay.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: ang caller kinahanglan garantiya nga `x` ug `y` mga
    // balido alang sa mga pagsulat ug maayong pagkahanay.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Alang sa mga lahi nga labi ka gamay sa pag-optimize sa block sa ubus, ibaylo lang direkta aron malikayan ang wala`y paglaum nga codegen.
    //
    if mem::size_of::<T>() < 32 {
        // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `x` ug `y` balido
        // alang sa mga pagsulat, maayong pagkahanay, ug dili nagsapawan.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ang pamaagi dinhi aron magamit ang simd aron ibaylo ang x&y nga episyente.
    // Pagsulay nagpadayag nga nagtabla sa bisan hain 32 bytes o 64 bytes sa usa ka panahon mao ang labing hapsay nga alang sa Intel Haswell E processors.
    // Labi nga maka-optimize ang LLVM kung hatagan naton ang usa ka istruktura nga #[repr(simd)], bisan kung dili naton tinuud nga gigamit kini nga istruktura nga direkta.
    //
    //
    // Ang FIXME repr(simd) nabuak sa emscripten ug redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Pag-loop pinaagi sa x&y, pagkopya kanila `Block` sa matag higayon Ang optimizer kinahanglan nga magbukas sa buut sa loop alang sa kadaghanan sa mga lahi nga NB
    // Dili namon magamit ang usa alang sa loop ingon ang `range` impl nagtawag sa `mem::swap` nga recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Paghimo pipila nga wala nahibal-an nga panumduman ingon usa ka space sa pagdeklarar nga `t` dinhi malikayan ang pag-align sa stack kung kini nga loop wala magamit
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: Ingon nga `i < len`, ug ingon nga ang caller kinahanglan garantiya nga `x` ug `y` mga balido
        // alang sa `len` bytes, `x + i` ug `y + i` kinahanglan nga adunay balido nga mga adres, nga nagtuman sa kontrata sa kahilwasan alang sa `add`.
        //
        // Ingon usab, kinahanglan garantiya sa nanawag nga ang `x` ug `y` balido alang sa mga pagsulat, maayong pagkahanay, ug dili nagsapawan, nga nagtuman sa kontrata sa kahilwasan alang sa `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ipuli ang usa ka bloke sa byte nga x&y, gamit ang t ingon usa ka temporaryo nga buffer Kini kinahanglan nga i-optimize ngadto sa episyente nga operasyon sa SIMD kung adunay magamit
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ipuli ang bisan unsang nahabilin nga mga byte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: tan-awa ang miaging kaluwasan comment.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Gibalhin ang `src` sa gitudlo nga `dst`, nga gibalik ang miaging kantidad nga `dst`.
///
/// Ni ihulog ang kantidad.
///
/// Kini nga pag-andar katumbas sa semantikal sa [`mem::replace`] gawas nga kini nagpalihok sa mga hilaw nga panudlo imbis nga mga pakisayran.
/// Kung adunay magamit nga mga pakisayran, kinahanglan nga gipalabi ang [`mem::replace`].
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `dst` kinahanglan [valid] alang sa parehas nga pagbasa ug pagsulat.
///
/// * `dst` kinahanglan nga sa tukmang paagi ilaray.
///
/// * `dst` kinahanglan itudlo sa usa ka husto nga pasiuna nga kantidad sa tipo `T`.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` adunay parehas nga epekto nga dili kinahanglan ang dili luwas nga bloke.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KALUWASAN: ang nagpanawag kinahanglan garantiya nga ang `dst` balido nga mahimo
    // ihulog sa us aka mutable nga reperensiya (balido alang sa mga pagsulat, nakahanay, gisugdan), ug dili mahimong magsapaw sa `src` sanglit ang `dst` kinahanglan magtudlo sa usa ka lahi nga gigahin nga butang.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // dili magsapaw
    }
    src
}

/// Gibasa ang kantidad gikan sa `src` nga wala kini pagbalhin.Gibilin niini ang panumduman sa `src` nga wala mausab.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `src` kinahanglan [valid] para mabasa.
///
/// * `src` kinahanglan nga nahiangay nga husto.Paggamit [`read_unaligned`] kung dili kini ang hinungdan.
///
/// * `src` kinahanglan itudlo sa usa ka husto nga pasiuna nga kantidad sa tipo `T`.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kinamut nga ipatuman ang [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Paghimo usa ka gamay nga kopya sa kantidad sa `a` sa `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ang paggawas sa kini nga punto (mahimong pinaagi sa tin-aw nga pagbalik o pinaagi sa pagtawag sa usa ka gimbuhaton nga panics) hinungdan sa pagkahulog sa kantidad sa `tmp` samtang ang parehas nga kantidad sa gihapon gi-refer sa `a`.
///         // Mahimo kini hinungdan sa dili matino nga pamatasan kung ang `T` dili `Copy`.
/////
/////
///
///         // Paghimo usa ka gamay nga kopya sa kantidad sa `b` sa `a`.
///         // Kini luwas tungod kay ang dili mabalhin nga mga pakisayran dili mahimong alyas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ingon nga sa ibabaw, milapos dinhi magsugyot dili tino ang kinaiya tungod kay ang sama nga bili mao ang pakisayran sa `a` ug `b`.
/////
///
///         // Igbalhin ang `tmp` ngadto sa `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` gibalhin (gikuha sa `write` ang ikaduha nga argumento), busa wala`y gihulog dinhi nga hilisgutan.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Pagpanag-iya sa Gibalik nga Bili
///
/// `read` nagmugna usa ka gamay nga kopya sa `T`, dili igsapayan kung ang `T` mao ang [`Copy`].
/// Kung ang `T` dili [`Copy`], ang paggamit sa pareho nga gibalik nga kantidad ug ang kantidad sa `*src` mahimong makalapas sa kahilwasan sa memorya.
/// Timan-i nga sa paghatag sa `*src` importante nga ingon sa usa ka paggamit tungod kay kini mosulay sa drop sa bili sa `* src`.
///
/// [`write()`] mahimong gigamit sa overwrite data sa walay hinungdan sa niini nga nagatulo.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` karon nagpunting sa parehas nga nagpahiping memorya ingon `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ang pagtudlo sa `s2` hinungdan sa pagkahulog sa orihinal nga kantidad niini.
///     // Sa unahan niini nga punto, ang `s` kinahanglan dili na gamiton, tungod kay ang nagpahiping handumanan gipagawas na.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ang pagtudlo sa `s` hinungdan sa pagkahulog sa daan nga kantidad, nga miresulta sa dili matino nga pamatasan.
/////
///     // s= String::from("bar");//SAYOP
///
///     // `ptr::write` mahimong magamit aron mapuno ang us aka kantidad nga dili ihulog kini.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `src` balido sa mga mabasa.
    // `src` dili masapawan ang `tmp` tungod kay ang `tmp` gigahin ra sa stack ingon usa ka gilain nga gigahin nga butang.
    //
    //
    // Ingon usab, tungod kay nagsulat kami usa ka balido nga kantidad ngadto sa `tmp`, gigarantiyahan nga maipahimatuud nga husto.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Gibasa ang kantidad gikan sa `src` nga wala kini pagbalhin.Gibilin niini ang panumduman sa `src` nga wala mausab.
///
/// Dili sama sa [`read`], ang `read_unaligned` nagtrabaho uban ang mga dili managsunod nga mga pointer.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `src` kinahanglan [valid] para mabasa.
///
/// * `src` kinahanglan itudlo sa usa ka husto nga pasiuna nga kantidad sa tipo `T`.
///
/// Sama sa [`read`], ang `read_unaligned` nagmugna usa ka gamay nga kopya sa `T`, dili igsapayan kung ang `T` mao ang [`Copy`].
/// Kung ang `T` dili [`Copy`], gamit ang pareho nga gibalik nga kantidad ug ang kantidad sa `*src` mahimo [violate memory safety][read-ownership].
///
/// Hinumdomi nga bisan kung ang `T` adunay gidak-on nga `0`, kinahanglan nga dili Null ang pointer.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Sa `packed` strowers
///
/// Karon dili mahimo ang paghimo sa hilaw nga mga panudlo sa wala magkatugma nga mga uma sa usa ka naka-pack nga istruktura.
///
/// Ang pagsulay sa paghimo sa usa ka hilaw nga pahimangno sa usa ka `unaligned` nga istraktud nga istraktura nga adunay ekspresyon sama sa `&packed.unaligned as *const FieldType` nagmugna usa ka tunga-tunga nga wala`y reperensya nga reperensiya sa wala pa kini pagkabalhin sa usa ka hilaw nga puntos.
///
/// Ang kini nga pakisayran temporaryo ug diha-diha dayon ang cast wala`y hinungdan tungod kay kanunay gipaabut sa tagtipig nga ang mga pakisayran maayo nga nakahanay.
/// Ingon usa ka sangputanan, ang paggamit sa `&packed.unaligned as *const FieldType` hinungdan sa dayon nga* wala matino nga kinaiya * sa imong programa.
///
/// Usa ka pananglitan kung unsa ang dili buhaton ug kung giunsa kini may kalabutan sa `read_unaligned` mao ang:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Gisulayan namon dinhi nga kuhaon ang adres sa usa ka 32-bit nga integer nga dili nakahanay.
///     let unaligned =
///         // Ang usa ka panamtang nga wala`y pag-ayo nga pakisayran gihimo dinhi nga nagresulta sa wala matino nga pamatasan bisan kung gigamit man ang pakisayran o wala.
/////
///         &packed.unaligned
///         // Dili makatabang ang paglabay sa usa ka hilaw nga pahimangno;ang sayop nahitabo na.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ang pag-access sa mga wala nakaparis nga mga uma nga direkta gamit ang eg `packed.unaligned` luwas bisan pa.
///
///
///
///
///
///
// FIXME: Update docs base sa resulta sa RFC #2582 ug mga higala.
/// # Examples
///
/// Basaha ang us aka kantidad gikan sa us aka buffer sa byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `src` balido sa mga mabasa.
    // `src` dili masapawan ang `tmp` tungod kay ang `tmp` gigahin ra sa stack ingon usa ka gilain nga gigahin nga butang.
    //
    //
    // Ingon usab, tungod kay nagsulat kami usa ka balido nga kantidad ngadto sa `tmp`, gigarantiyahan nga maipahimatuud nga husto.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Nag-overwrite sa usa ka lokasyon sa memorya nga adunay gihatag nga kantidad nga wala gibasa o gihulog ang daan nga kantidad.
///
/// `write` dili ihulog ang mga sulud sa `dst`.
/// Kini luwas, apan mahimo kini maggula sa mga alokasyon o gigikanan, busa kinahanglan magbantay nga dili mapuno ang usa ka butang nga kinahanglan mahulog.
///
///
/// Dugang pa, dili kini ihulog ang `src`.Sa semantiko, ang `src` gibalhin sa lokasyon nga gitudlo sa `dst`.
///
/// Kini angayan alang sa pagsugod sa wala nahibal-an nga panumduman, o pag-overtake sa memorya nga kaniadto [`read`] gikan.
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `dst` kinahanglan [valid] alang sa misulat.
///
/// * `dst` kinahanglan nga nahiangay nga husto.Paggamit [`write_unaligned`] kung dili kini ang hinungdan.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kinamut nga ipatuman ang [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Paghimo usa ka gamay nga kopya sa kantidad sa `a` sa `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ang paggawas sa kini nga punto (mahimong pinaagi sa tin-aw nga pagbalik o pinaagi sa pagtawag sa usa ka gimbuhaton nga panics) hinungdan sa pagkahulog sa kantidad sa `tmp` samtang ang parehas nga kantidad sa gihapon gi-refer sa `a`.
///         // Mahimo kini hinungdan sa dili matino nga pamatasan kung ang `T` dili `Copy`.
/////
/////
///
///         // Paghimo usa ka gamay nga kopya sa kantidad sa `b` sa `a`.
///         // Kini luwas tungod kay ang dili mabalhin nga mga pakisayran dili mahimong alyas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ingon nga sa ibabaw, milapos dinhi magsugyot dili tino ang kinaiya tungod kay ang sama nga bili mao ang pakisayran sa `a` ug `b`.
/////
///
///         // Igbalhin ang `tmp` ngadto sa `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` gibalhin (gikuha sa `write` ang ikaduha nga argumento), busa wala`y gihulog dinhi nga hilisgutan.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Gitawag namon ang mga intrinsik nga direkta aron malikayan ang mga tawag sa pag-andar sa gihimo nga code tungod kay ang `intrinsics::copy_nonoverlapping` usa ka function sa wrapper.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KALUWASAN: kinahanglan garantiya sa nanawag nga ang `dst` balido alang sa pagsulat.
    // `dst` dili masapawan ang `src` tungod kay ang mutawag adunay mutable access sa `dst` samtang ang `src` gipanag-iya sa kini nga function.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Nag-overwrite sa usa ka lokasyon sa memorya nga adunay gihatag nga kantidad nga wala gibasa o gihulog ang daan nga kantidad.
///
/// Dili sama sa [`write()`], ang tudlo mahimo nga dili magkatugma.
///
/// `write_unaligned` dili ihulog ang mga sulud sa `dst`.Kini luwas, apan mahimo kini maggula sa mga alokasyon o gigikanan, busa kinahanglan magbantay nga dili mapuno ang usa ka butang nga kinahanglan mahulog.
///
/// Dugang pa, dili kini ihulog ang `src`.Sa semantiko, ang `src` gibalhin sa lokasyon nga gitudlo sa `dst`.
///
/// Kini angay alang sa pagsugod sa wala nahibal-an nga panumduman, o pag-overtake sa memorya nga kaniadto nabasa sa [`read_unaligned`].
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `dst` kinahanglan [valid] alang sa misulat.
///
/// Hinumdomi nga bisan kung ang `T` adunay gidak-on nga `0`, kinahanglan nga dili Null ang pointer.
///
/// [valid]: self#safety
///
/// ## Sa `packed` strowers
///
/// Karon dili mahimo ang paghimo sa hilaw nga mga panudlo sa wala magkatugma nga mga uma sa usa ka naka-pack nga istruktura.
///
/// Ang pagsulay sa paghimo sa usa ka hilaw nga pahimangno sa usa ka `unaligned` nga istraktud nga istraktura nga adunay ekspresyon sama sa `&packed.unaligned as *const FieldType` nagmugna usa ka tunga-tunga nga wala`y reperensya nga reperensiya sa wala pa kini pagkabalhin sa usa ka hilaw nga puntos.
///
/// Ang kini nga pakisayran temporaryo ug diha-diha dayon ang cast wala`y hinungdan tungod kay kanunay gipaabut sa tagtipig nga ang mga pakisayran maayo nga nakahanay.
/// Ingon usa ka sangputanan, ang paggamit sa `&packed.unaligned as *const FieldType` hinungdan sa dayon nga* wala matino nga kinaiya * sa imong programa.
///
/// Usa ka pananglitan kung unsa ang dili buhaton ug kung giunsa kini may kalabutan sa `write_unaligned` mao ang:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Gisulayan namon dinhi nga kuhaon ang adres sa usa ka 32-bit nga integer nga dili nakahanay.
///     let unaligned =
///         // Ang usa ka panamtang nga wala`y pag-ayo nga pakisayran gihimo dinhi nga nagresulta sa wala matino nga pamatasan bisan kung gigamit man ang pakisayran o wala.
/////
///         &mut packed.unaligned
///         // Dili makatabang ang paglabay sa usa ka hilaw nga pahimangno;ang sayop nahitabo na.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ang pag-access sa mga wala nakaparis nga mga uma nga direkta gamit ang eg `packed.unaligned` luwas bisan pa.
///
///
///
///
///
///
///
///
///
// FIXME: Update docs base sa resulta sa RFC #2582 ug mga higala.
/// # Examples
///
/// Pagsulat us aka kantidad sa usize sa usa ka byte buffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KALUWASAN: kinahanglan garantiya sa nanawag nga ang `dst` balido alang sa pagsulat.
    // `dst` dili masapawan ang `src` tungod kay ang mutawag adunay mutable access sa `dst` samtang ang `src` gipanag-iya sa kini nga function.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Gitawag namon ang intrinsic direkta aron malikayan ang mga tawag sa pagpaandar sa nahimo nga code.
        intrinsics::forget(src);
    }
}

/// Naghimo usa ka pabalhin nga pagbasa sa kantidad gikan sa `src` nga wala kini pagbalhin.Kini dahon ang handumanan sa `src` mausab.
///
/// Dali moalisngaw operasyon gituyo sa paglihok sa I/O panumdoman, ug garantiya nga dili elided o reordered sa tighipos tabok sa ubang mga dali moalisngaw operasyon.
///
/// # Notes
///
/// Ang Rust wala karon usa ka higpit ug pormal nga gihubit nga modelo sa panumduman, busa ang ensakto nga semantiko sa gipasabut sa "volatile" dinhi mahimo`g mausab sa paglabay sa panahon.
/// Giingon na, ang mga semantiko hapit kanunay matapos nga parehas sa [C11's definition of volatile][c11].
///
/// Dili kinahanglan usbon sa tagtipig ang paryente nga pagkahan-ay o gidaghanon sa mga pabalhin nga operasyon sa memorya.
/// Bisan pa, ang mga dali mabalhin nga operasyon sa memorya sa mga wala`y gidak-on nga mga lahi (pananglitan, kung ang usa ka zero-kadako nga klase gipasa sa `read_volatile`) mga noops ug mahimong ibaliwala.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `src` kinahanglan [valid] para mabasa.
///
/// * `src` kinahanglan nga sa tukmang paagi ilaray.
///
/// * `src` kinahanglan itudlo sa usa ka husto nga pasiuna nga kantidad sa tipo `T`.
///
/// Sama sa [`read`], ang `read_volatile` nagmugna usa ka gamay nga kopya sa `T`, dili igsapayan kung ang `T` mao ang [`Copy`].
/// Kung ang `T` dili [`Copy`], gamit ang pareho nga gibalik nga kantidad ug ang kantidad sa `*src` mahimo [violate memory safety][read-ownership].
/// Bisan pa, ang pagtipig dili [[Kopya`] nga mga lahi sa dali nga hinumdoman hapit dili gyud husto.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Sama sa C, kung ang usa ka operasyon dali maglihok wala`y kalabotan sa mga pangutana nga naglambigit sa dungan nga pag-access gikan sa daghang mga sulud.Ang mga dali maablihan nga pag-access molihok sama sa dili pag-access sa mga atomic bahin niana.
///
/// Sa partikular, ang usa ka lumba taliwala sa usa ka `read_volatile` ug bisan unsang operasyon sa pagsulat sa parehas nga lokasyon dili matino nga pamatasan.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Dili pag-panic aron magpadayon nga gamay ang epekto sa codegen.
        abort();
    }
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Naghimo usa ka dali nga pagsulat sa usa ka lokasyon sa memorya nga adunay gihatag nga kantidad nga wala gibasa o gihulog ang daan nga kantidad.
///
/// Dali moalisngaw operasyon gituyo sa paglihok sa I/O panumdoman, ug garantiya nga dili elided o reordered sa tighipos tabok sa ubang mga dali moalisngaw operasyon.
///
/// `write_volatile` dili ihulog ang mga sulud sa `dst`.Kini luwas, apan mahimo kini maggula sa mga alokasyon o gigikanan, busa kinahanglan magbantay nga dili mapuno ang usa ka butang nga kinahanglan mahulog.
///
/// Dugang pa, dili kini ihulog ang `src`.Sa semantiko, ang `src` gibalhin sa lokasyon nga gitudlo sa `dst`.
///
/// # Notes
///
/// Ang Rust wala karon usa ka higpit ug pormal nga gihubit nga modelo sa panumduman, busa ang ensakto nga semantiko sa gipasabut sa "volatile" dinhi mahimo`g mausab sa paglabay sa panahon.
/// Giingon na, ang mga semantiko hapit kanunay matapos nga parehas sa [C11's definition of volatile][c11].
///
/// Dili kinahanglan usbon sa tagtipig ang paryente nga pagkahan-ay o gidaghanon sa mga pabalhin nga operasyon sa memorya.
/// Bisan pa, ang mga dali mabalhin nga operasyon sa memorya sa mga wala`y gidak-on nga mga lahi (pananglitan, kung ang usa ka zero-kadako nga klase gipasa sa `write_volatile`) mga noops ug mahimong ibaliwala.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Kinaiya mao nga dili tino ang kon sa bisan unsa nga sa mosunod nga mga kondisyon nakalapas:
///
/// * `dst` kinahanglan [valid] alang sa misulat.
///
/// * `dst` kinahanglan nga sa tukmang paagi ilaray.
///
/// Mubo nga sulat nga bisan kon `T` may gidak-on `0`, ang pointer kinahanglan nga non-bili ug sa husto nga paagi ilaray.
///
/// [valid]: self#safety
///
/// Sama sa C, kung ang usa ka operasyon dali maglihok wala`y kalabotan sa mga pangutana nga naglambigit sa dungan nga pag-access gikan sa daghang mga sulud.Ang mga dali maablihan nga pag-access molihok sama sa dili pag-access sa mga atomic bahin niana.
///
/// Sa partikular, ang usa ka lumba taliwala sa usa ka `write_volatile` ug uban pang operasyon (pagbasa o pagsulat) sa parehas nga lokasyon dili matino nga pamatasan.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Dili pag-panic aron magpadayon nga gamay ang epekto sa codegen.
        abort();
    }
    // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Ihan-ay ang pointer `p`.
///
/// Kwentaha ang offset (sa mga termino sa mga elemento nga `stride` stride) nga kinahanglan i-apply sa pointer `p` aron ang pointer `p` mapaangay sa `a`.
///
/// Note: Kini nga pagpatuman maampingong gipahaum sa dili panic.Kini ang UB alang sa kini sa panic.
/// Ang bugtong tinuod nga kausaban nga mahimong dinhi mao ang kausaban sa `INV_TABLE_MOD_16` ug nalangkit nga mabag.
///
/// Kung magdesisyon man kita nga himuon nga posible nga tawagan ang intrinsic sa `a` nga dili usa ka power-of-two, tingali labi ka mabinantayon nga magbag-o ra sa usa ka wala`y pulos nga pagpatuman kaysa pagsulay nga ipahiangay kini aron maanaa ang kana nga pagbag-o.
///
///
/// Bisan unsang pangutana adto sa@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direct paggamit sa niini nga mga intrinsics makatabang sa codegen kamahinungdanon sa opt-level <=
    // 1, diin ang mga bersyon sa pamaagi sa kini nga mga operasyon dili gilinya.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Kalkulahin ang multiplicative modular baliktad sa `x` modulo `m`.
    ///
    /// Ang kini nga pagpatuman gipahaum alang sa `align_offset` ug adunay mga musunud nga preconditions:
    ///
    /// * `m` usa ka gahum-sa-duha;
    /// * `x < m`; (kung `x ≥ m`, ipasa sa baylo nga `x % m`)
    ///
    /// Pagpatuman niini nga function dili panic.Kanunay.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse table modulo 2⁴=16.
        ///
        /// Hinumdomi, nga kini nga lamesa wala sulud mga kantidad diin wala ang baligtad (ie, alang sa `0⁻¹ mod 16`, `2⁻¹ mod 16`, ug uban pa)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo diin gilaraw ang `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KALUWASAN: Ang `m` gikinahanglan aron mahimo`g usa ka gahum-sa-duha, busa dili-zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Gisubli namon ang "up" gamit ang mosunud nga pormula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // hangtod sa 2²ⁿ ≥ mDayon kita pagpakunhod sa atong gitinguha `m` pinaagi sa pagkuha sa resulta `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Hinumdomi, nga gituyo namon ang paggamit sa mga operasyon sa pagputos dinhi-ang orihinal nga pormula naggamit pananglitan, pagbawas `mod n`.
                // Kini bug-os nga maayo nga buhaton sila `mod usize::MAX` hinoon, tungod kay gikuha namon ang sangputanan `mod n` sa katapusan bisan pa.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` mao ang usa ka gahum-sa-duha, busa dili-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Ang kaso mahimong makalkula nga labi ka yano pinaagi sa `-p (mod a)`, apan ang paghimo niini nakababag sa katakus sa LLVM sa pagpili mga panudlo sama sa `lea`.Hinuon nagkwenta kami
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // nga nag-apod-apod sa mga operasyon sa palibot sa pagdala, apan ang pagpahulay sa `and` igo alang sa LLVM aron magamit ang lainlaing mga pag-optimize nga nahibal-an niini.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Nahiangay na.Yay!
        return 0;
    } else if stride == 0 {
        // Kung ang pointer dili nakahanay, ug ang elemento wala`y sukod, kung ingon niana wala`y gidaghanon sa mga elemento ang mopahiangay sa pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KALUWASAN: ang usa mao ang gahum-sa-duha busa dili zero.stride==0 nga kaso ang gidumala sa taas.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KALUWASAN: ang gcdpow adunay labaw nga kadaghan nga daghan sa mga tipik sa usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd mao ang kanunay nga mas dako o katumbas sa 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Gisulbad sa kini nga branch alang sa mosunud nga parehas nga pagkagsama nga pagkagsama:
        //
        // ` p + so = 0 mod a `
        //
        // `p` Ania ang kantidad sa pointer, `s`, lakang sa `T`, `o` offset sa `T`s, ug `a`, ang gihangyo nga paglinya.
        //
        // Uban sa `g = gcd(a, s)`, ug ang mga sa ibabaw nga kahimtang sa pagpasabot nga `p` mao ang bahinon sa `g` usab, kita magtumong sa `a' = a/g`, `s' = s/g`, `p' = p/g`, nan kini mahimong katumbas sa:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ang una nga termino mao ang "the relative alignment of `p` to `a`" (gibahin sa `g`), ang ikaduha nga termino "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (gibahin usab sa `g`).
        //
        // Kinahanglan ang dibisyon sa `g` aron mahimo ang baligtad nga maayong pagkaporma kung ang `a` ug `s` dili co-prime.
        //
        // Dugang pa, ang sangputanan nga gihimo sa kini nga solusyon dili "minimal", busa kinahanglan nga kuhaon ang resulta nga `o mod lcm(s, a)`.Mahimo naton ilisan ang `lcm(s, a)` sa usa ka `a'` ra.
        //
        //
        //
        //
        //

        // KALUWASAN: Ang `gcdpow` adunay taas nga utlanan nga dili molabaw sa ihap sa mga ning-agi nga 0-bits sa `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KALUWASAN: Ang `a2` dili zero.Pagbalhin `a` sa `gcdpow` dili ipasa sa bisan unsa sa mga set tipik
        // sa `a` (nga kini adunay gayud sa usa ka).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KALUWASAN: Ang `gcdpow` adunay taas nga utlanan nga dili molabaw sa ihap sa mga ning-agi nga 0-bits sa `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` adunay usa ka ibabaw nga-gigapos dili labaw pa kay sa gidaghanon sa mga banas 0-tipik sa
        // `a`.
        // Dugang pa, ang pagminus dili mahimo nga mag-awas, tungod kay ang `a2 = a >> gcdpow` kanunay nga higpit nga labaw sa `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KALUWASAN: Ang `a2` usa ka gahum-sa-duha, ingon napamatud sa taas.Ang `s2` higpit nga mas mubu sa `a2`
        // tungod kay ang `(s % a) >> gcdpow` higpit nga mas mubu sa `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Dili gyud makahanay.
    usize::MAX
}

/// Gitandi ang mga hilaw nga panudlo alang sa pagkaparehas.
///
/// Kini parehas sa paggamit sa `==` operator, apan dili kaayo generic:
/// ang mga argumento nga mahimong `*const T` hilaw pointers, dili sa bisan unsa nga galamiton `PartialEq`.
///
/// Mahimo kini gamiton aron itandi ang mga pakisayran sa `&T` (nga gipugos sa `*const T` nga implicit) sa ilang adres kaysa pagtandi sa mga kantidad nga ilang gitudlo (nga kung unsa ang gihimo sa pagpatuman sa `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Ang mga hiwa gitandi usab sa ilang gitas-on (mga tambok nga taba):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Ang Traits gitandi usab sa ilang pagpatuman:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ang mga panudlo adunay parehas nga mga adres.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Ang mga butang adunay parehas nga adres, apan ang `Trait` adunay lainlaing pagpatuman.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ang pag-usab sa pakisayran sa usa ka `*const u8` gitandi sa adres.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash usa ka hilaw nga pointer.
///
/// Mahimo kini gamiton aron ma-hash ang usa ka pakisayran sa `&T` (nga gipugos ang `*const T` nga wala`y hinungdan) pinaagi sa adres niini kaysa sa kantidad nga gitudlo niini (nga kung unsa ang gihimo sa pagpatuman sa `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Nagpatuman alang sa mga panudlo sa pagpaandar
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Gikinahanglan ang intermediate cast ingon usize alang sa AVR
                // aron ang address space sa gigikanan sa function function mapanalipdan sa katapusang function pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Gikinahanglan ang intermediate cast ingon usize alang sa AVR
                // aron ang address space sa gigikanan sa function function mapanalipdan sa katapusang function pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Walay variadic gimbuhaton uban sa 0 lantugi
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Paghimo usa ka `const` nga hilaw nga pointer sa usa ka lugar, nga wala maghimo usa ka tunga nga reperensiya.
///
/// Ang paghimo sa usa ka pakisayran sa `&`/`&mut` gitugotan lamang kung ang pointer husto nga nakahanay ug nagpunting sa pasiuna nga datos.
/// Alang sa mga kaso diin ang mga kinahanglanon dili magpadayon, ang mga hilaw nga panudlo kinahanglan gamiton hinoon.
/// Bisan pa, naghimo ang `&expr as *const _` usa ka pakisayran sa wala pa ihulog kini sa usa ka hilaw nga pahimangno, ug kana nga pakisayran nahiuyon sa parehas nga mga lagda sama sa tanan nga ubang mga pakisayran.
///
/// Ang makro nga kini makahimo usa ka hilaw nga pahimangno *nga wala* paghimo una usa ka pakisayran
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` maghimo usa ka wala magkatakdo nga pakisayran, ug sa ingon ang Dili Maila nga Gawi!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Paghimo usa ka `mut` nga hilaw nga pointer sa usa ka lugar, nga wala maghimo usa ka tunga nga reperensiya.
///
/// Ang paghimo sa usa ka pakisayran sa `&`/`&mut` gitugotan lamang kung ang pointer husto nga nakahanay ug nagpunting sa pasiuna nga datos.
/// Alang sa mga kaso diin ang mga kinahanglanon dili magpadayon, ang mga hilaw nga panudlo kinahanglan gamiton hinoon.
/// Bisan pa, naghimo ang `&mut expr as *mut _` usa ka pakisayran sa wala pa ihulog kini sa usa ka hilaw nga pahimangno, ug kana nga pakisayran nahiuyon sa parehas nga mga lagda sama sa tanan nga ubang mga pakisayran.
///
/// Ang makro nga kini makahimo usa ka hilaw nga pahimangno *nga wala* paghimo una usa ka pakisayran
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` maghimo usa ka wala magkatakdo nga pakisayran, ug sa ingon ang Dili Maila nga Gawi!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` pwersa ang pagkopya sa umahan imbis nga maghimo usa ka pakisayran.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}