use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` apan dili-zero ug covariant.
///
/// Kanunay kini nga tama nga gamiton nga butang kung ang pagtukod sa mga istruktura sa datos nga gigamit ang mga hilaw nga panudlo, apan sa katapusan labi ka peligro gamiton tungod sa dugang nga mga kabtangan.Kung dili ka sigurado kung kinahanglan nimo gamiton ang `NonNull<T>`, gamita ra ang `*mut T`!
///
/// Dili sama sa `*mut T`, ang tudlo kinahanglan kanunay nga wala'y bili, bisan kung ang tudlo dili gyud gihatagan gahum.Kini aron ang mga enum mahimong mogamit sa gidili nga kantidad ingon usa ka diskriminasyon-ang `Option<NonNull<T>>` adunay parehas nga gidak-on sa `* mut T`.
/// Apan ang pointer aron pa magpaon kon kini dili dereferenced.
///
/// Dili sama sa `*mut T`, `NonNull<T>` napili nga mahimong covariant sa `T`.Gihimong posible kini nga gamiton ang `NonNull<T>` kung naghimo sa mga klase sa covariant, apan gipaila ang peligro sa pagkawalay kalig-onan kung gigamit sa usa ka klase nga dili gyud mahimo nga covariant.
/// (Ang sukwahi nga kapilian gihimo alang sa `*mut T` bisan kung sa teknikal nga paagi ang kawala`y mahimo`g hinungdan sa pagtawag sa dili luwas nga mga gimbuhaton.)
///
/// Ang Covariance husto alang sa labi ka luwas nga mga abstraction, sama sa `Box`, `Rc`, `Arc`, `Vec`, ug `LinkedList`.Kini ang hinungdan tungod kay naghatag sila usa ka publiko nga API nga nagsunod sa naandan nga gipaambit nga XOR nga mausab nga mga lagda sa Rust.
///
/// Kung ang imong tipo dili mahimo nga luwas nga mag-covariant, kinahanglan nimo nga masiguro nga adunay sulud kini nga dugang nga natad aron makahatag invariance.Kasagaran niini nga kapatagan mahimong usa ka [`PhantomData`] matang nga sama `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Timan-i nga ang `NonNull<T>` adunay usa ka `From` pananglitan alang sa `&T`.Bisan pa, dili niini gibag-o ang katinuud nga ang pag-mutate pinaagi sa usa ka (pointer nga nakuha gikan sa usa ka) gipaambit nga reperensya dili matino nga pamatasan gawas kung ang mutasyon nahitabo sa sulud sa usa ka [`UnsafeCell<T>`].Parehas sa paghimo sa us aka mutable referensya gikan sa usa ka gipaambit nga reperensya.
///
/// Kung gigamit kini nga pananglitan sa `From` nga wala`y `UnsafeCell<T>`, responsibilidad nimo nga masiguro nga ang `as_mut` dili gyud tawagan, ug ang `as_ptr` wala gyud gigamit alang sa mutasyon.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ang mga pointers dili `Send` tungod kay ang datos nga ilang gi-refer mahimo`g alias.
// NB, kini nga impl mao ang wala kinahanglana, apan kinahanglan nga mohatag og mas maayo nga mga mensahe sayop.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ang mga pointers dili `Sync` tungod kay ang datos nga ilang gi-refer mahimo`g alias.
// NB, kini nga impl mao ang wala kinahanglana, apan kinahanglan nga mohatag og mas maayo nga mga mensahe sayop.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Naghimo usa ka bag-ong `NonNull` nga nagbitay, apan maayo nga pagkahanay.
    ///
    /// Kini mao ang mapuslanon alang sa initializing matang nga hinayng naglakaw samtang mogahin, sama sa `Vec::new` nagabuhat.
    ///
    /// Matikdi nga ang pointer bili mahimong kalagmitan nagrepresentar sa usa ka balido nga pointer sa usa ka `T`, nga nagpasabot kini nga kinahanglan dili gamiton ingon nga usa ka "not yet initialized" sentinel bili.
    /// Ang mga lahi nga tapulan nga naggahin kinahanglan magsubay sa pagpauna sa ubang mga paagi.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KALUWASAN: Ang mem::align_of() mobalik us aka us aka non-zero usize nga pagkahuman isalibay
        // sa usa ka * mut T.
        // Busa, ang `ptr` dili null ug ang mga kondisyon alang sa pagtawag sa new_unchecked() gitahod.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Nagbalik usa ka gipaambit nga mga pakisayran sa kantidad.Sukwahi sa [`as_ref`], kini wala magkinahanglan nga ang bili adunay nga initialized.
    ///
    /// Alang sa mutable counterpart tan-awa ang [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka pakisayran.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Nagbalik usa ka talagsaon nga mga pakisayran sa kantidad.Sukwahi sa [`as_mut`], kini wala magkinahanglan nga ang bili adunay nga initialized.
    ///
    /// Alang sa gipaambit nga katugbang tan-awa ang [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///
    ///   Sa partikular, alang sa gidugayon sa tibuok kinabuhi, ang mga handumanan sa pointer puntos sa kinahanglan dili na Naablihan (mabasa o gisulat) pinaagi sa bisan unsa nga lain nga mga pointer.
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka pakisayran.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Nagmugna sa usa ka bag-o nga `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` kinahanglan nga dili null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KALUWASAN: kinahanglan nga garantiya sa nanawag nga ang `ptr` dili null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Naghimo usa ka bag-ong `NonNull` kung ang `ptr` dili null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KALUWASAN: Ang pointer gisusi na ug dili null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Gihimo sa sama nga kagamitan, katuyoan ingon nga [`std::ptr::from_raw_parts`], gawas nga ang usa ka `NonNull` pointer ang mibalik, sukwahi sa sa usa ka hilaw `*const` pointer.
    ///
    ///
    /// Tan-awa ang dokumento sa [`std::ptr::from_raw_parts`] alang sa dugang detalye.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KALUWASAN: Ang sangputanan sa `ptr::from::raw_parts_mut` dili null tungod kay ang `data_address` mao.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Gub-a ang us aka (mahimo`g lapad) nga punting sa address ug mga sangkap sa metadata.
    ///
    /// Ang pointer mahimo nga sa ulahi nga pagtukod usab sa [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nakuha ang nagpahiping `*mut` pointer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Nagbalik usa ka gipaambit nga reperensiya sa kantidad.Kung ang kantidad mahimo`g uninitialized, kinahanglan gamiton hinoon ang [`as_uninit_ref`].
    ///
    /// Alang sa mutable counterpart tan-awa ang [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan itudlo sa pointer ang una nga pananglitan sa `T`.
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    /// (Ang bahin mahitungod sa initialized dili pa bug-os nga nakahukom, apan hangtud nga kini mao, ang bugtong luwas nga paagi mao ang aron sa pagsiguro nga sila sa pagkatinuod initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka pakisayran.
        unsafe { &*self.as_ptr() }
    }

    /// Nagbalik usa ka talagsaon nga pakisayran sa kantidad.Kung ang kantidad mahimo`g uninitialized, kinahanglan gamiton hinoon ang [`as_uninit_mut`].
    ///
    /// Alang sa gipaambit nga katugbang tan-awa ang [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan itudlo sa pointer ang una nga pananglitan sa `T`.
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///
    ///   Sa partikular, alang sa gidugayon sa tibuok kinabuhi, ang mga handumanan sa pointer puntos sa kinahanglan dili na Naablihan (mabasa o gisulat) pinaagi sa bisan unsa nga lain nga mga pointer.
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    /// (Ang bahin mahitungod sa initialized dili pa bug-os nga nakahukom, apan hangtud nga kini mao, ang bugtong luwas nga paagi mao ang aron sa pagsiguro nga sila sa pagkatinuod initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka mutable nga pakisayran.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nag-cast sa usa ka tudlo sa uban pang lahi.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KALUWASAN: Ang `self` usa ka `NonNull` pointer nga kinahanglan nga dili null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Naghimo usa ka dili null nga hilaw nga hiwa gikan sa usa ka nipis nga pointer ug usa ka gitas-on.
    ///
    /// Ang `len` argumento mao ang gidaghanon sa mga **elemento**, dili ang gidaghanon sa mga bytes.
    ///
    /// function Kini mao ang luwas, apan dereferencing sa pagbalik bili mao ang dili luwas.
    /// Tan-awa ang dokumentasyon sa [`slice::from_raw_parts`] alang sa mga kinahanglanon sa pagkaluwas sa hiwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // paghimo usa ka slice pointer sa pagsugod sa usa ka pointer sa una nga elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Hinumdomi nga kini nga pananglitan artipisyal nga nagpasundayag sa usa ka paggamit sa kini nga pamaagi, apan ang `ipaagi sa hiwa= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KALUWASAN: Ang `data` usa ka `NonNull` pointer nga kinahanglan nga dili null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Mobalik ang gitas-on sa usa ka non-bili hilaw nga ad-ad.
    ///
    /// Ang gibalik nga kantidad mao ang gidaghanon sa mga **elemento**, dili ang gidaghanon sa mga byte.
    ///
    /// function Kini mao ang luwas, bisan pa sa diha nga ang mga dili-- bili hilaw ad-ad dili dereferenced sa usa ka ad-ad tungod kay ang pointer wala sa usa ka balido nga pakigpulong.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Gibalik ang usa ka dili null nga puntos sa buffer sa hiwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KALUWASAN: Nahibal-an namon nga ang `self` dili null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Mobalik usa ka hilaw nga pahimangno sa buffer sa hiwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Nagbalik usa ka gipaambit nga pakisayran sa usa ka hiwa nga posibleng wala mahibal-an nga mga kantidad.Sukwahi sa [`as_ref`], wala kini kinahanglana nga ang kantidad kinahanglan mapasugdan.
    ///
    /// Alang sa mutable counterpart tan-awa ang [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * Ang pointer kinahanglan nga [valid] alang mabasa alang sa `ptr.len() * mem::size_of::<T>()` daghang mga byte, ug kini kinahanglan nga husto nga pagkahan-ay.Ilabi na kini gipasabut:
    ///
    ///     * Ang bug-os nga-laing handumanan sa ad-ad kinahanglan nga anaa sa sulod sa usa ka single nga gigahin butang!
    ///       Ang mga hiwa dili gyud molapas sa daghang mga gigahin nga mga butang.
    ///
    ///     * pointer ang kinahanglan nga ilaray bisan sa zero-ang gitas-on hiwa.
    ///     Ang usa ka katarungan alang niini mao nga ang mga pag-optimize sa layout sa enum mahimong magsalig sa mga pakisayran (lakip ang mga hiwa sa bisan unsang gitas-on) nga nakahanay ug dili null aron mailhan sila gikan sa ubang mga datos.
    ///
    ///     Mahimo ka makakuha usa ka pointer nga magamit ingon `data` alang sa mga zero-length nga mga hiwa gamit ang [`NonNull::dangling()`].
    ///
    /// * Ang kinatibuk-ang gidak-on `ptr.len() * mem::size_of::<T>()` sa ad-ad kinahanglan nga dili mas dako pa kay sa `isize::MAX`.
    ///   Tan-awa ang kaluwasan dokumentasyon sa [`pointer::offset`].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// Kitaa usab ang [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Mobalik sa usa ka talagsaon nga paghisgot sa usa ka ad-ad sa posible uninitialized mga prinsipyo.Sukwahi sa [`as_mut`], kini wala magkinahanglan nga ang bili adunay nga initialized.
    ///
    /// Alang sa gipaambit nga katugbang tan-awa ang [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Sa diha nga sa pagtawag niini nga pamaagi, ikaw aron sa pagsiguro nga ang tanan nga sa mosunod mao ang tinuod:
    ///
    /// * Ang pointer kinahanglan nga [valid] alang sa pagbasa ug pagsulat alang sa `ptr.len() * mem::size_of::<T>()` daghang mga byte, ug kinahanglan nga kini ipahiangay sa husto.Ilabi na kini gipasabut:
    ///
    ///     * Ang bug-os nga-laing handumanan sa ad-ad kinahanglan nga anaa sa sulod sa usa ka single nga gigahin butang!
    ///       Ang mga hiwa dili gyud molapas sa daghang mga gigahin nga mga butang.
    ///
    ///     * pointer ang kinahanglan nga ilaray bisan sa zero-ang gitas-on hiwa.
    ///     Ang usa ka katarungan alang niini mao nga ang mga pag-optimize sa layout sa enum mahimong magsalig sa mga pakisayran (lakip ang mga hiwa sa bisan unsang gitas-on) nga nakahanay ug dili null aron mailhan sila gikan sa ubang mga datos.
    ///
    ///     Mahimo ka makakuha usa ka pointer nga magamit ingon `data` alang sa mga zero-length nga mga hiwa gamit ang [`NonNull::dangling()`].
    ///
    /// * Ang kinatibuk-ang gidak-on `ptr.len() * mem::size_of::<T>()` sa ad-ad kinahanglan nga dili mas dako pa kay sa `isize::MAX`.
    ///   Tan-awa ang kaluwasan dokumentasyon sa [`pointer::offset`].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///   Sa partikular, alang sa gidugayon sa tibuok kinabuhi, ang mga handumanan sa pointer puntos sa kinahanglan dili na Naablihan (mabasa o gisulat) pinaagi sa bisan unsa nga lain nga mga pointer.
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// Kitaa usab ang [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Kini mao ang luwas nga ingon sa `memory` mao ang balido alang sa mabasa ug misulat alang sa `memory.len()` sa daghang mga bytes.
    /// // Hinumdomi nga ang pagtawag sa `memory.as_mut()` dili gitugotan dinhi tungod kay ang sulud mahimo`g wala mahibal-an.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Gibalik ang usa ka hilaw nga tudlo sa usa ka elemento o subslice, nga wala gihimo ang pagsusi sa mga utlanan.
    ///
    /// Ang pagtawag sa kini nga pamaagi nga adunay out-of-bounds index o kung dili maminusan ang `self` mao ang *[dili matino nga pamatasan]* bisan kung wala gigamit ang sangputanan nga pointer.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KALUWASAN: gisiguro sa nanawag nga ang `self` dili madutlan ug `index` nga mga utlanan.
        // Ingon usa ka sangputanan, ang sangputanan nga panudlo dili mahimong NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: Usa ka Talagsaong pointer dili mahimo nga bili, mao nga ang mga kondisyon alang sa
        // new_unchecked() gitahod.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KALUWASAN: Ang us aka mutable nga pakisayran dili mahimong null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Usa ka reperensiya dili mahimo nga bili, mao nga ang mga kondisyon alang sa
        // new_unchecked() gitahod.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}