use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Gibalik ang `true` kung ang pointer null.
    ///
    /// Matikdi nga unsized matang adunay daghan nga mga posible nga bili pointers, ingon lamang sa hilaw nga data pointer giisip, dili sa ilang gitas-on, vtable, ug uban pa
    /// Busa, ang duha nga mga panudlo nga wala`y mahimo mahimo`g dili gihapon makumpara nga managsama sa matag usa.
    ///
    /// ## Ang pamatasan sa panahon sa pagsusi sa const
    ///
    /// Kung gigamit kini nga pag-andar sa panahon sa pagsusi sa konstitusyon, mahimo kini ibalik ang `false` alang sa mga panudlo nga mahimo`g wala`y pulos sa pag-undang.
    /// Sa piho nga paagi, kung ang usa ka pointer sa pipila nga panumduman mapun-an sa unahan sa mga utlanan niini sa paagi nga wala`y hinungdan ang resulta nga pointer, ibalik ra gihapon sa function ang `false`.
    ///
    /// Walay paagi alang sa CTFE nga masayud sa bug-os nga posisyon sa panumdoman, mao nga dili kita makasulti kon ang pointer mao ang bili o dili.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Pagtandi pinaagi sa usa ka cast sa usa ka nipis nga pointer, busa ang mga tambok nga tudlo giisip lamang ang ilang bahin nga "data" alang sa wala`y pulos.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Nag-cast sa usa ka tudlo sa uban pang lahi.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Gub-a ang us aka (mahimo`g lapad) nga punting sa address ug mga sangkap sa metadata.
    ///
    /// Ang pointer mahimo nga sa ulahi nga pagtukod usab sa [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Gibalik ang `None` kung ang pointer null, o kung wala man ibalik ang usa ka gipaambit nga reperensiya sa kantidad nga giputos sa `Some`.Kung ang kantidad mahimo`g uninitialized, kinahanglan gamiton hinoon ang [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kung gitawag kini nga pamaagi, kinahanglan nimo nga masiguro nga *bisan ang* ang pointer NULO *o* ang tanan nga mga mosunud tinuod.
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan itudlo sa pointer ang una nga pananglitan sa `T`.
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    /// (Ang bahin mahitungod sa initialized dili pa bug-os nga nakahukom, apan hangtud nga kini mao, ang bugtong luwas nga paagi mao ang aron sa pagsiguro nga sila sa pagkatinuod initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Wala gisusi nga bersyon
    ///
    /// Kon ikaw sigurado nga ang pointer dili gayud mahimo nga bili ug gipangita alang sa pipila ka matang sa `as_ref_unchecked` nga mobalik ang `&T` sa baylo nga sa `Option<&T>`, masayud nga kamo makahimo dereference sa pointer direkta.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KALuwas-an: kinahanglan garantiya sa nanawag nga ang `self` balido
        // alang sa usa ka pakisayran kung dili kini null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Gibalik ang `None` kung ang pointer null, o kung wala man ibalik ang usa ka gipaambit nga reperensiya sa kantidad nga giputos sa `Some`.
    /// Sukwahi sa [`as_ref`], wala kini kinahanglana nga ang kantidad kinahanglan mapasugdan.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kung gitawag kini nga pamaagi, kinahanglan nimo nga masiguro nga *bisan ang* ang pointer NULO *o* ang tanan nga mga mosunud tinuod.
    ///
    /// * pointer ang kinahanglan nga sa husto nga paagi ilaray.
    ///
    /// * Kinahanglan kini "dereferencable" sa kahulugan nga gihubit sa [the module documentation].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: ang caller kinahanglan garantiya nga `self` magtigum sa tanan nga mga
        // mga kinahanglanon alang sa usa ka pakisayran.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// NAGTINGUHA ang offset gikan sa usa ka pointer.
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung adunay bisan usa sa mga mosunud nga kondisyon nga gilapas, ang sangputanan Wala matino nga Panglihok:
    ///
    /// * Parehas ang pagsugod ug sangputanan nga tudlo kinahanglan naa sa mga utlanan o usa ka byte nga nangagi sa katapusan sa parehas nga gigahin nga butang.
    /// Mubo nga sulat nga sa Rust, ang matag (stack-allocated) baryable gikonsiderar nga usa ka lahi nga gigahin butang.
    ///
    /// * Ang computed offset,**sa bytes**, dili magaawas sa usa ka `isize`.
    ///
    /// * Ang offset nga naa sa mga utlanan dili makasalig sa "wrapping around" ang address space.Nga mao, ang walay katapusan nga-tukma nga kantidad,**sa bytes** kinahanglan mohaum sa usa ka usize.
    ///
    /// Ang tagtipig ug sumbanan nga librarya sa kinatibuk-an nagsulay sa pagsiguro nga ang mga paggahin dili gyud maabut ang gidak-on diin ang usa ka offset mao ang gikabalak-an.
    /// Pananglitan, gisiguro sa `Vec` ug `Box` nga dili gyud sila mogahin labaw pa sa `isize::MAX` bytes, busa kanunay nga luwas ang `vec.as_ptr().add(vec.len())`.
    ///
    /// Kadaghanan sa mga plataporma sa panukiduki dili mahimo ang paghimo sa ingon nga paggahin.
    /// Pananglitan, wala'y nahibal-an nga 64-bit nga plataporma ang makahatag sa usa ka hangyo alang sa 2 <sup>63</sup> bytes tungod sa mga limitasyon sa lamesa sa panid o pagbahinbahin sa wanang sa address.
    /// Bisan pa, ang pipila nga 32-bit ug 16-bit nga mga platform mahimong malampuson nga nag-alagad sa usa ka hangyo labaw pa sa `isize::MAX` bytes nga adunay mga butang sama sa Physical Address Extension.
    ///
    /// Sa ingon, handumanan nakuha direkta gikan allocators o sa panumduman mapa files *tingali* kaayo dako sa pagdumala uban sa niini nga function.
    ///
    /// Hunahunaa ang paggamit sa [`wrapping_offset`] kung kini nga mga pagpugong lisud matagbaw.
    /// Ang bugtong nga bentaha sa kini nga pamaagi mao nga kini nakahatag mas agresibo nga mga pag-optimize sa compiler.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Gikalkula ang offset gikan sa usa ka pointer nga gigamit ang wrapping arithmetic.
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang kini nga operasyon mismo kanunay nga luwas, apan ang paggamit sa sangputanan nga pointer dili.
    ///
    /// Ang sangputanan nga pointer nagpabilin nga gilakip sa parehas nga gigahin nga butang nga gipunting sa `self`.
    /// Kini mahimong dili * gamiton sa pag-access sa usa ka lain-laing mga gigahin butang.Hinumdomi nga sa Rust, ang matag (stack-allocated) variable giisip nga usa ka gilain nga gigahin nga butang.
    ///
    /// Sa laing pagkasulti, ang `let z = x.wrapping_offset((y as isize) - (x as isize))` wala *naghimo* sa `z` parehas sa `y` bisan kung giisip namon nga ang `T` adunay kadako nga `1` ug wala`y pag-awas: Ang `z` giapil gihapon sa butang nga `x` nga gilakip, ug ang pag-dereferencing niini mao ang Undefined behaviour gawas kung ang `x` ug `y` nga punto sa parehas nga gigahin nga butang.
    ///
    /// Kon itandi sa [`offset`], kini nga paagi sa panguna naglangan sa gikinahanglan sa pagpabilin sa sulod sa mao usab nga gigahin nga butang: [`offset`] mao ang diha-diha nga dili tino ang Pamatasan sa diha nga pagtabok butang utlanan;Ang `wrapping_offset` naghimo usa ka pointer apan modala gihapon sa Undefined nga Paglihok kung ang usa ka pointer gihatagan gahum kung kini wala sa utlanan sa butang nga giapil niini.
    /// [`offset`] mahimong ma-optimize nga labi ka maayo ug labi ka gusto sa code nga sensitibo sa performance.
    ///
    /// Ang nadugay check lang giisip sa bili sa pointer nga dereferenced, dili ang intermediate mga prinsipyo nga gigamit sa panahon sa pagkwenta sa katapusan nga resulta.
    /// Pananglitan, ang `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` kanunay parehas sa `x`.Sa laing mga pulong, sa pagbiya sa mga gigahin butang ug unya pag-pagsulod niini sa ulahi ang gitugotan.
    ///
    /// Kung kinahanglan nimo nga tabangan ang mga utlanan sa butang, ihulog ang pointer sa usa ka integer ug buhata ang aritmetika didto.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // Iterate gamit ang usa ka hilaw nga pointer sa mga pagdugang nga duha nga elemento
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Kini nga loop nagpatik sa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // KALUWASAN: ang `arith_offset` intrinsic wala`y kinahanglan nga tawgon.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Gikalkula ang gilay-on sa taliwala sa duha ka mga tudlo.Ang gibalik nga kantidad naa sa mga yunit sa T: ang gilay-on sa mga byte gibahin sa `mem::size_of::<T>()`.
    ///
    /// Ang kini nga kalihokan mao ang balihon sa [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Kung adunay bisan usa sa mga mosunud nga kondisyon nga gilapas, ang sangputanan Wala matino nga Panglihok:
    ///
    /// * Parehas ang pagsugod ug uban pang tudlo kinahanglan naa sa mga utlanan o us aka byte nga natapos sa katapusan sa parehas nga gigahin nga butang.
    /// Mubo nga sulat nga sa Rust, ang matag (stack-allocated) baryable gikonsiderar nga usa ka lahi nga gigahin butang.
    ///
    /// * Ang parehas nga mga panudlo kinahanglan *makuha gikan sa* usa ka pointer sa parehas nga butang.
    ///   (Kitaa sa ubus alang sa usa ka pananglitan.)
    ///
    /// * Ang distansya taliwala sa mga panudlo, sa mga byte, kinahanglan nga usa ka eksaktong gidaghanon sa gidak-on sa `T`.
    ///
    /// * Ang gilay-on sa taliwala sa mga panudlo,**sa mga byte**, dili maapawan ang usa ka `isize`.
    ///
    /// * Ang gilay-on nga sa mga utlanan dili mosalig sa "wrapping around" sa address nga luna.
    ///
    /// Ang mga tipo sa Rust dili gyud mas dako kaysa sa `isize::MAX` ug Rust nga mga alokasyon dili gyud ibalibut sa wanang sa address, busa duha nga mga pointer sa sulud sa pipila nga kantidad sa bisan unsang Rust type `T` kanunay nga matagbaw ang katapusan nga duha nga kondisyon.
    ///
    /// Kasagaran usab nga gisiguro sa sukaranan nga librarya nga ang mga paggahin dili gyud maabut ang gidak-on diin gikabalak-an ang usa ka offset.
    /// Pananglitan, gisiguro sa `Vec` ug `Box` nga dili gyud sila mogahin labaw pa sa `isize::MAX` bytes, mao nga kanunay natagbaw sa `ptr_into_vec.offset_from(vec.as_ptr())` ang katapusan nga duha nga kondisyon.
    ///
    /// Kadaghanan sa mga platform nga batakan dili makahimo bisan usa ka daghang alokasyon.
    /// Pananglitan, wala'y nahibal-an nga 64-bit nga plataporma ang makahatag sa usa ka hangyo alang sa 2 <sup>63</sup> bytes tungod sa mga limitasyon sa lamesa sa panid o pagbahinbahin sa wanang sa address.
    /// Bisan pa, ang pipila nga 32-bit ug 16-bit nga mga platform mahimong malampuson nga nag-alagad sa usa ka hangyo labaw pa sa `isize::MAX` bytes nga adunay mga butang sama sa Physical Address Extension.
    /// Sa ingon, handumanan nakuha direkta gikan allocators o sa panumduman mapa files *tingali* kaayo dako sa pagdumala uban sa niini nga function.
    /// (Hinumdomi nga ang [`offset`] ug [`add`] adunay usab susama nga limitasyon ug busa dili magamit sa daghang mga gahin.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Kini nga pagpaandar sa panics kung ang `T` usa ka Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Dili husto* paggamit:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Himua ang ptr2_other usa ka "alias" nga ptr2, apan nakuha gikan sa ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Tungod kay ang ptr2_other ug ptr2 nakuha gikan sa mga tudlo sa lainlaing mga butang, ang pag-compute sa ilang offset wala matino nga pamatasan, bisan kung parehas sila og punto!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Wala matino nga kinaiya
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Mobalik kung ang duha nga mga panudlo gigarantiyahan nga managsama.
    ///
    /// Sa Runtime kini nga function nagagawi nga sama sa `self == other`.
    /// Apan, sa pipila ka konteksto (pananglitan, pagtipon-panahon evaluation), kini mao ang dili kanunay nga posible nga sa pagtino patas sa duha ka pointers, mao nga kini nga function mahimo spuriously mobalik `false` alang sa pointers nga sa ulahi sa tinuod mobalik sa aron mahimo nga managsama.
    ///
    /// Apan kung ibalik ang `true`, ang mga panudlo gigarantiyahan nga managsama.
    ///
    /// Kini nga pag-andar mao ang salamin sa [`guaranteed_ne`], apan dili kini balihon.Adunay mga pagtandi sa pointer diin ang parehas nga gimbuhaton ibalik ang `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Ang pagbalik sa kantidad mahimo nga magbag-o depende sa bersyon sa nagtipig ug dili luwas nga code mahimong dili magsalig sa sangputanan sa kini nga pag-andar alang sa kahimsog.
    /// Gisugyot nga gamiton ra kini nga pag-andar alang sa mga pag-optimize sa paghimo diin ang mga madaot nga pagbalik sa `false` nga ningbalik sa kini nga pag-andar dili makaapekto sa sangputanan, apan ang paghimo ra.
    /// Ang mga sangputanan sa paggamit niini nga pamaagi aron mahimo`g lainlain ang paggawi sa runtime ug compile-time code nga wala pa masusi.
    /// Kini nga pamaagi dili gamiton aron ipaila ang mga pagkalainlain, ug dili usab kini mapalig-on sa wala pa kami adunay mas maayo nga pagsabut sa kini nga isyu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Mobalik kung ang duha nga mga panudlo gigarantiyahan nga dili patas.
    ///
    /// Sa runtime kini nga pag-andar naglihok sama sa `self != other`.
    /// Apan, sa pipila ka konteksto (pananglitan, pagtipon-panahon evaluation), kini mao ang dili kanunay nga posible nga sa pagtino sa pagkadili managsama sa duha ka pointers, mao nga kini nga function mahimo spuriously mobalik `false` alang sa pointers nga sa ulahi sa tinuod mobalik sa aron mahimo nga managsama.
    ///
    /// Apan sa diha nga kini mobalik `true`, sa mga igpupunting nga gigarantiyahan nga mahimong dili managsama.
    ///
    /// Kini nga pag-andar mao ang salamin sa [`guaranteed_eq`], apan dili kini balihon.Adunay pointer pagtandi nga duha gimbuhaton mobalik `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Ang pagbalik sa kantidad mahimo nga magbag-o depende sa bersyon sa nagtipig ug dili luwas nga code mahimong dili magsalig sa sangputanan sa kini nga pag-andar alang sa kahimsog.
    /// Gisugyot nga gamiton ra kini nga pag-andar alang sa mga pag-optimize sa paghimo diin ang mga madaot nga pagbalik sa `false` nga ningbalik sa kini nga pag-andar dili makaapekto sa sangputanan, apan ang paghimo ra.
    /// Ang mga sangputanan sa paggamit niini nga pamaagi aron mahimo`g lainlain ang paggawi sa runtime ug compile-time code nga wala pa masusi.
    /// Kini nga pamaagi dili gamiton aron ipaila ang mga pagkalainlain, ug dili usab kini mapalig-on sa wala pa kami adunay mas maayo nga pagsabut sa kini nga isyu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Gikalkula ang offset gikan sa usa ka pointer (kasayon alang sa `.offset(count as isize)`).
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung adunay bisan usa sa mga mosunud nga kondisyon nga gilapas, ang sangputanan Wala matino nga Panglihok:
    ///
    /// * Parehas ang pagsugod ug sangputanan nga tudlo kinahanglan naa sa mga utlanan o usa ka byte nga nangagi sa katapusan sa parehas nga gigahin nga butang.
    /// Mubo nga sulat nga sa Rust, ang matag (stack-allocated) baryable gikonsiderar nga usa ka lahi nga gigahin butang.
    ///
    /// * Ang computed offset,**sa bytes**, dili magaawas sa usa ka `isize`.
    ///
    /// * Ang offset nga naa sa mga utlanan dili makasalig sa "wrapping around" ang address space.Kana mao, ang wala`y kinutuban nga katukma nga kantidad kinahanglan mohaum sa usa ka `usize`.
    ///
    /// Ang tagtipig ug sumbanan nga librarya sa kinatibuk-an nagsulay sa pagsiguro nga ang mga paggahin dili gyud maabut ang gidak-on diin ang usa ka offset mao ang gikabalak-an.
    /// Pananglitan, gisiguro sa `Vec` ug `Box` nga dili gyud sila mogahin labaw pa sa `isize::MAX` bytes, busa kanunay nga luwas ang `vec.as_ptr().add(vec.len())`.
    ///
    /// Kadaghanan sa mga plataporma sa panukiduki dili mahimo ang paghimo sa ingon nga paggahin.
    /// Pananglitan, wala'y nahibal-an nga 64-bit nga plataporma ang makahatag sa usa ka hangyo alang sa 2 <sup>63</sup> bytes tungod sa mga limitasyon sa lamesa sa panid o pagbahinbahin sa wanang sa address.
    /// Bisan pa, ang pipila nga 32-bit ug 16-bit nga mga platform mahimong malampuson nga nag-alagad sa usa ka hangyo labaw pa sa `isize::MAX` bytes nga adunay mga butang sama sa Physical Address Extension.
    ///
    /// Sa ingon, handumanan nakuha direkta gikan allocators o sa panumduman mapa files *tingali* kaayo dako sa pagdumala uban sa niini nga function.
    ///
    /// Hunahunaa ang paggamit sa [`wrapping_add`] kung kini nga mga pagpugong lisud nga matagbaw.
    /// Ang bugtong nga bentaha sa kini nga pamaagi mao nga kini nakahatag mas agresibo nga mga pag-optimize sa compiler.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Gikalkula ang offset gikan sa usa ka pointer (kasayon alang sa `.offset ((isipon nga isize).wrapping_neg())`).
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung adunay bisan usa sa mga mosunud nga kondisyon nga gilapas, ang sangputanan Wala matino nga Panglihok:
    ///
    /// * Parehas ang pagsugod ug sangputanan nga tudlo kinahanglan naa sa mga utlanan o usa ka byte nga nangagi sa katapusan sa parehas nga gigahin nga butang.
    /// Mubo nga sulat nga sa Rust, ang matag (stack-allocated) baryable gikonsiderar nga usa ka lahi nga gigahin butang.
    ///
    /// * Ang nakalkula nga offset dili molapas sa `isize::MAX`**bytes**.
    ///
    /// * Ang offset nga naa sa mga utlanan dili makasalig sa "wrapping around" ang address space.Nga mao, ang walay katapusan nga-tukma nga kantidad kinahanglan mohaum sa usa ka usize.
    ///
    /// Ang tagtipig ug sumbanan nga librarya sa kinatibuk-an nagsulay sa pagsiguro nga ang mga paggahin dili gyud maabut ang gidak-on diin ang usa ka offset mao ang gikabalak-an.
    /// Pananglitan, gisiguro sa `Vec` ug `Box` nga dili gyud sila mogahin labaw pa sa `isize::MAX` bytes, busa kanunay nga luwas ang `vec.as_ptr().add(vec.len()).sub(vec.len())`.
    ///
    /// Kadaghanan sa mga plataporma sa panukiduki dili mahimo ang paghimo sa ingon nga paggahin.
    /// Pananglitan, wala'y nahibal-an nga 64-bit nga plataporma ang makahatag sa usa ka hangyo alang sa 2 <sup>63</sup> bytes tungod sa mga limitasyon sa lamesa sa panid o pagbahinbahin sa wanang sa address.
    /// Bisan pa, ang pipila nga 32-bit ug 16-bit nga mga platform mahimong malampuson nga nag-alagad sa usa ka hangyo labaw pa sa `isize::MAX` bytes nga adunay mga butang sama sa Physical Address Extension.
    ///
    /// Sa ingon, handumanan nakuha direkta gikan allocators o sa panumduman mapa files *tingali* kaayo dako sa pagdumala uban sa niini nga function.
    ///
    /// Hunahunaa ang paggamit sa [`wrapping_sub`] kung kini nga mga pagpugong lisud matagbaw.
    /// Ang bugtong nga bentaha sa kini nga pamaagi mao nga kini nakahatag mas agresibo nga mga pag-optimize sa compiler.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Gikalkula ang offset gikan sa usa ka pointer nga gigamit ang wrapping arithmetic.
    /// (Kasayon alang sa `.wrapping_offset(count as isize)`)
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang kini nga operasyon mismo kanunay nga luwas, apan ang paggamit sa sangputanan nga pointer dili.
    ///
    /// Ang sangputanan nga pointer nagpabilin nga gilakip sa parehas nga gigahin nga butang nga gipunting sa `self`.
    /// Kini mahimong dili * gamiton sa pag-access sa usa ka lain-laing mga gigahin butang.Hinumdomi nga sa Rust, ang matag (stack-allocated) variable giisip nga usa ka gilain nga gigahin nga butang.
    ///
    /// Sa laing pagkasulti, ang `let z = x.wrapping_add((y as usize) - (x as usize))` wala *naghimo* sa `z` parehas sa `y` bisan kung giisip namon nga ang `T` adunay kadako nga `1` ug wala`y pag-awas: Ang `z` giapil gihapon sa butang nga `x` nga gilakip, ug ang pag-dereferencing niini mao ang Undefined behaviour gawas kung ang `x` ug `y` nga punto sa parehas nga gigahin nga butang.
    ///
    /// Kung itandi sa [`add`], kini nga pamaagi sagad nga nakapalangan sa kinahanglanon nga magpabilin sa sulud sa parehas nga gigahin nga butang: ang [`add`] diha-diha dayon nga Dili Maila nga Gawi kung molabang sa mga utlanan sa butang;Ang `wrapping_add` naghimo usa ka pointer apan modala gihapon sa Undefined nga Paglihok kung ang usa ka pointer gihatagan gahum kung kini wala sa utlanan sa butang nga giapil niini.
    /// [`add`] mahimong ma-optimize nga labi ka maayo ug labi ka gusto sa code nga sensitibo sa performance.
    ///
    /// Ang nadugay check lang giisip sa bili sa pointer nga dereferenced, dili ang intermediate mga prinsipyo nga gigamit sa panahon sa pagkwenta sa katapusan nga resulta.
    /// Pananglitan, ang `x.wrapping_add(o).wrapping_sub(o)` kanunay parehas sa `x`.Sa ato pa, gitugotan ang pagbiya sa gigahin nga butang ug unya pagsulud usab niini sa ulahi.
    ///
    /// Kung kinahanglan nimo nga tabangan ang mga utlanan sa butang, ihulog ang pointer sa usa ka integer ug buhata ang aritmetika didto.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // Iterate gamit ang usa ka hilaw nga pointer sa mga pagdugang nga duha nga elemento
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Kini nga loop nagpatik sa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Gikalkula ang offset gikan sa usa ka pointer nga gigamit ang wrapping arithmetic.
    /// (kasayon alang sa `.wrapping_offset ((ihap ingon isize).wrapping_neg())`)
    ///
    /// `count` naa sa mga yunit sa T;eg, ang usa ka `count` sa 3 nagrepresentar sa usa ka pointer offset sa `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang kini nga operasyon mismo kanunay nga luwas, apan ang paggamit sa sangputanan nga pointer dili.
    ///
    /// Ang sangputanan nga pointer nagpabilin nga gilakip sa parehas nga gigahin nga butang nga gipunting sa `self`.
    /// Kini mahimong dili * gamiton sa pag-access sa usa ka lain-laing mga gigahin butang.Hinumdomi nga sa Rust, ang matag (stack-allocated) variable giisip nga usa ka gilain nga gigahin nga butang.
    ///
    /// Sa laing pagkasulti, ang `let z = x.wrapping_sub((x as usize) - (y as usize))` wala *naghimo* sa `z` parehas sa `y` bisan kung giisip namon nga ang `T` adunay kadako nga `1` ug wala`y pag-awas: Ang `z` giapil gihapon sa butang nga `x` nga gilakip, ug ang pag-dereferencing niini mao ang Undefined behaviour gawas kung ang `x` ug `y` nga punto sa parehas nga gigahin nga butang.
    ///
    /// Kung itandi sa [`sub`], kini nga pamaagi sagad nga nakapalangan sa kinahanglanon nga magpabilin sa sulud sa parehas nga gigahin nga butang: ang [`sub`] diha-diha dayon nga Dili Maila nga Gawi kung molabang sa mga utlanan sa butang;Ang `wrapping_sub` naghimo usa ka pointer apan modala gihapon sa Undefined nga Paglihok kung ang usa ka pointer gihatagan gahum kung kini wala sa utlanan sa butang nga giapil niini.
    /// [`sub`] mahimong ma-optimize nga labi ka maayo ug labi ka gusto sa code nga sensitibo sa performance.
    ///
    /// Ang nadugay check lang giisip sa bili sa pointer nga dereferenced, dili ang intermediate mga prinsipyo nga gigamit sa panahon sa pagkwenta sa katapusan nga resulta.
    /// Pananglitan, ang `x.wrapping_add(o).wrapping_sub(o)` kanunay parehas sa `x`.Sa ato pa, gitugotan ang pagbiya sa gigahin nga butang ug unya pagsulud usab niini sa ulahi.
    ///
    /// Kung kinahanglan nimo nga tabangan ang mga utlanan sa butang, ihulog ang pointer sa usa ka integer ug buhata ang aritmetika didto.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // Iterate gamit ang usa ka hilaw nga pointer sa mga pagdugang sa duha nga mga elemento (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Kini nga loop nagpatik sa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Gitakda ang kantidad sa puntos ngadto sa `ptr`.
    ///
    /// Sa kaso nga `self` usa ka (fat) pointer sa usa ka dili gidak-on nga tipo, ang kini nga operasyon makaapekto lamang sa bahin sa pointer, samtang alang sa (thin) nga mga panudlo sa kadako nga mga lahi, kini adunay parehas nga epekto ingon usa ka yano nga asaynment.
    ///
    /// Ang sangputanan nga pointer adunay kakuhaan og `val`, ie, alang sa usa ka tambok nga tudlo, kini nga operasyon parehas nga pareho sa paghimo sa usa ka bag-ong tambok nga tudlo nga adunay datos nga kantidad nga `val` apan ang metadata nga `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ang kini nga kalihokan labi nga mapuslanon alang sa pagtugot sa byte-wisdom pointer arithmetic sa mga posibleng tudlo nga tambok:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // ipatik ang "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // KALUWASAN: Sa kaso sa usa ka nipis nga punto, kini nga mga operasyon managsama
        // sa usa ka yano nga buluhaton.
        // Sa kaso sa usa ka taba nga tudlo, uban ang karon nga pagpatuman sa layout sa tambok nga taba, ang una nga natad sa ingon nga usa ka pointer kanunay nga ang data pointer, nga sa mao usab nga asaynment.
        //
        unsafe { *thin = val };
        self
    }

    /// Ginbasa ang bili gikan sa `self` nga walay pagbalhin niini.
    /// Gibilin niini ang panumduman sa `self` nga wala mausab.
    ///
    /// Tan-awa ang [`ptr::read`] alang sa problema sa kaluwasan ug sa mga panig-ingnan.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `read`.
        unsafe { read(self) }
    }

    /// Naghimo usa ka pabalhin nga pagbasa sa kantidad gikan sa `self` nga wala kini pagbalhin.Kini dahon ang handumanan sa `self` mausab.
    ///
    /// Dali moalisngaw operasyon gituyo sa paglihok sa I/O panumdoman, ug garantiya nga dili elided o reordered sa tighipos tabok sa ubang mga dali moalisngaw operasyon.
    ///
    ///
    /// Tan-awa ang [`ptr::read_volatile`] alang sa mga kabalaka ug pananglitan sa kahilwasan.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Ginbasa ang bili gikan sa `self` nga walay pagbalhin niini.
    /// Gibilin niini ang panumduman sa `self` nga wala mausab.
    ///
    /// Dili sama `read`, ang pointer aron wala matumong.
    ///
    /// Tan-awa ang [`ptr::read_unaligned`] alang sa mga kabalaka ug pananglitan sa kahilwasan.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: ang caller kinahanglan pagtuboy sa kontrata kaluwasan alang sa `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Gikopya ang `count * size_of<T>` bytes gikan sa `self` hangtod `dest`.
    /// Ang tinubdan ug padulnganan mahimong magsapaw.
    ///
    /// NOTE: kini adunay *parehas* nga han-ay sa argumento ingon [`ptr::copy`].
    ///
    /// Tan-awa ang [`ptr::copy`] alang sa mga kabalaka ug pananglitan sa kahilwasan.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Gikopya ang `count * size_of<T>` bytes gikan sa `self` hangtod `dest`.
    /// Ang tinubdan ug destinasyon aron dili * sapaw.
    ///
    /// NOTE: kini adunay *parehas* nga han-ay sa argumento ingon [`ptr::copy_nonoverlapping`].
    ///
    /// Tan-awa ang [`ptr::copy_nonoverlapping`] alang sa mga kabalaka ug pananglitan sa kahilwasan.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Gikalkulo ang offset nga kinahanglan ibutang sa pointer aron mahimo kini nga linya sa `align`.
    ///
    /// Kung dili posible nga ihanay ang pointer, ibalik sa pagpatuman ang `usize::MAX`.
    /// Kini mao ang permissible alang sa pagpatuman sa *kanunay* pagbalik `usize::MAX`.
    /// Ang kahimoan ra sa imong algorithm ang mahimong magsalig sa pagkuha sa usa ka magamit nga offset dinhi, dili ang kahusto niini.
    ///
    /// Ang offset gipahayag sa gidaghanon nga mga elemento nga `T`, ug dili mga byte.Ang kantidad nga ibalik mahimong magamit sa pamaagi nga `wrapping_add`.
    ///
    /// Walay mga garantiya sa bisan unsa nga nga offsetting ang pointer dili pagsugwak o moadto sa unahan sa alokasyon nga ang pointer puntos ngadto sa.
    ///
    /// Naa ra sa nanawag aron masiguro nga ang gibalik nga offset husto sa tanan nga mga termino gawas sa paghanay.
    ///
    /// # Panics
    ///
    /// Ang pagpaandar sa panics kung ang `align` dili usa ka gahum-sa-duha.
    ///
    /// # Examples
    ///
    /// Pag-access sa kasikbit nga `u8` ingon `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // samtang ang pointer mahimo`g makahanay pinaagi sa `offset`, magtudlo kini sa gawas sa paggahin
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KALUWASAN: Ang `align` gisusi aron mahimo`g usa ka kusog sa 2 sa taas
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Gibalik ang gitas-on sa usa ka hilaw nga hiwa.
    ///
    /// Ang gibalik nga kantidad mao ang gidaghanon sa mga **elemento**, dili ang gidaghanon sa mga byte.
    ///
    /// Kini nga pag-andar luwas, bisan kung ang hilaw nga hiwa dili mahimong isalibay sa usa ka reperensya sa hiwa tungod kay ang puntero wala`y bili o wala magkatakdo.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: luwas kini tungod kay ang `*const [T]` ug `FatPtr<T>` parehas nga paghan-ay.
            // Lamang `std` makahimo niini nga garantiya.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Mobalik usa ka hilaw nga pahimangno sa buffer sa hiwa.
    ///
    /// Katumbas kini sa paglabay sa `self` hangtod `*const T`, apan labi ka luwas sa tipo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Gibalik ang usa ka hilaw nga tudlo sa usa ka elemento o subslice, nga wala gihimo ang pagsusi sa mga utlanan.
    ///
    /// Ang pagtawag sa kini nga pamaagi nga adunay out-of-bounds index o kung dili maminusan ang `self` mao ang *[dili matino nga pamatasan]* bisan kung wala gigamit ang sangputanan nga pointer.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KALUWASAN: gisiguro sa nanawag nga ang `self` dili madutlan ug `index` nga mga utlanan.
        unsafe { index.get_unchecked(self) }
    }

    /// Gibalik ang `None` kung ang pointer null, o kung wala man ibalik ang usa ka gipaambit nga hiwa sa kantidad nga giputos sa `Some`.
    /// Sukwahi sa [`as_ref`], wala kini kinahanglana nga ang kantidad kinahanglan mapasugdan.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kung gitawag kini nga pamaagi, kinahanglan nimo nga masiguro nga *bisan ang* ang pointer NULO *o* ang tanan nga mga mosunud tinuod.
    ///
    /// * Ang pointer kinahanglan nga [valid] alang mabasa alang sa `ptr.len() * mem::size_of::<T>()` daghang mga byte, ug kini kinahanglan nga husto nga pagkahan-ay.Ilabi na kini gipasabut:
    ///
    ///     * Ang bug-os nga-laing handumanan sa ad-ad kinahanglan nga anaa sa sulod sa usa ka single nga gigahin butang!
    ///       Ang mga hiwa dili gyud molapas sa daghang mga gigahin nga mga butang.
    ///
    ///     * pointer ang kinahanglan nga ilaray bisan sa zero-ang gitas-on hiwa.
    ///     Ang usa ka katarungan alang niini mao nga ang mga pag-optimize sa layout sa enum mahimong magsalig sa mga pakisayran (lakip ang mga hiwa sa bisan unsang gitas-on) nga nakahanay ug dili null aron mailhan sila gikan sa ubang mga datos.
    ///
    ///     Mahimo ka makakuha usa ka pointer nga magamit ingon `data` alang sa mga zero-length nga mga hiwa gamit ang [`NonNull::dangling()`].
    ///
    /// * Ang kinatibuk-ang gidak-on `ptr.len() * mem::size_of::<T>()` sa ad-ad kinahanglan nga dili mas dako pa kay sa `isize::MAX`.
    ///   Tan-awa ang kaluwasan dokumentasyon sa [`pointer::offset`].
    ///
    /// * Kinahanglan nimo ipatuman ang mga lagda sa aliasing sa Rust, tungod kay ang nabalik nga kinabuhi nga `'a` arbitraryong napili ug dili kinahanglan nga ipakita ang tinuud nga kinabuhi sa datos.
    ///   Sa partikular, alang sa gidugayon sa kini nga kinabuhi, ang panumduman nga gitudlo sa pointer kinahanglan dili mutated (gawas sa sulud sa `UnsafeCell`).
    ///
    /// Kini magamit bisan kung ang sangputanan sa kini nga pamaagi wala magamit!
    ///
    /// Kitaa usab ang [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KALUWASAN: kinahanglan ipadayon sa nanawag ang kontrata sa kahilwasan alang sa `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Pagkaparehas alang sa mga panudlo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Pagtandi alang sa mga panudlo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}