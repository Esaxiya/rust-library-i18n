//! Usa ka pagpatuman sa SipHash.

#![allow(deprecated)] // ang mga lahi sa kini nga modyul wala na

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Usa ka pagpatuman sa SipHash 1-3.
///
/// Karon kini ang default hashing function nga gigamit sa standard library (pananglitan, gigamit kini sa `collections::HashMap` pinaagi sa default).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Usa ka pagpatuman sa SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Usa ka pagpatuman sa SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash mao ang usa ka kinatibuk-ang-ang katuyoan hashing function: kini midagan sa usa ka maayo nga speed (competitive sa makahahadlok ug City) ug gitugotan lig-on nga _keyed_ hashing.
///
/// Gitugotan ka niini nga yawi ang imong mga lamesa sa hash gikan sa kusgan nga RNG, sama sa [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Bisan kung ang SipHash algorithm giisip nga sa kinatibuk-an kusgan, wala kini gituyo alang sa katuyoan sa cryptographic.
/// Ingon niana, ang tanan nga gamit nga cryptographic sa kini nga pagpatuman _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // pila ka byte ang among giproseso
    state: State,  // hash Estado
    tail: u64,     // wala maproseso nga bytes le
    ntail: usize,  // sa unsa nga paagi sa daghang mga bytes sa ikog mao ang balido
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, Ang v2 ug v1, v3 nagpakita sa mga pares sa algorithm, ug ang mga simd nga pagpatuman sa SipHash mogamit sa vectors sa v02 ug v13.
    //
    // Pinaagi sa pagbutang kanila diha sa niini nga han-ay sa magtukod, ang tighipos mahimo sa pagkuha sa sa pipila lang ka simd optimizations sa iyang kaugalingon.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Nag-load sa usa ka integer sa gitinguha nga tipo gikan sa usa ka byte stream, sa LE order.
/// Gigamit ang `copy_nonoverlapping` aron tugotan ang tagatala nga makamugna ang labing episyente nga paagi aron ma-load kini gikan sa usa ka posibli nga wala nakaayos nga adres.
///
///
/// Luwas tungod kay: dili mapugngan ang pag-indeks sa i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Luwan sa usa ka u64 paggamit ngadto sa 7 bytes sa usa ka Byte ad-ad.
/// Kini tan-awon malumo apan ang mga tawag sa `copy_nonoverlapping` nga mahitabo (pinaagi sa `load_int_le!`) tanan adunay gitakdang gidak-on ug likayan ang pagtawag sa `memcpy`, nga maayo alang sa katulin.
///
///
/// Luwas tungod kay: dili mapugngan ang pag-indeks sa start..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // kasamtangan nga Byte index (gikan sa LSB) sa output u64
    let mut out = 0;
    if i + 3 < len {
        // SAFETY: `i` dili mahimo nga labaw pa kay sa `len`, ug ang caller kinahanglan garantiya
        // nga ang index start..start + len anaa sa mga utlanan.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // KALUWASAN: parehas sa taas.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // KALUWASAN: parehas sa taas.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Naghimo usa ka bag-ong `SipHasher` nga adunay duha nga pasiuna nga mga yawi nga gitakda sa 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Naghimo usa ka `SipHasher` nga naka-key sa mga gihatag nga mga key.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Nagmugna sa usa ka bag-o nga `SipHasher13` uban sa duha ka inisyal nga yawe gibutang sa 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Naghimo usa ka `SipHasher13` nga naka-key sa mga gihatag nga mga key.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: dili integer hashing mga pamaagi (`write_u *`, `write_i*`) ang gihubit
    // alang sa kini nga tipo.
    // Mahimo namon kini madugangan, kopyahon ang pagpatuman sa `short_write` sa librustc_data_structures/sip128.rs, ug idugang ang mga pamaagi nga `write_u *`/`write_i*` sa `SipHasher`, `SipHasher13`, ug `DefaultHasher`.
    //
    // Kini nga pag-ayo sa SPEED sa integer hashing sa mga hashers, sa gasto sa gamay mohinay pagtipon sa gikusgon sa pipila benchmarks.
    // Tan-awa ang #69152 alang sa mga detalye.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // KALUWASAN: Ang `cmp::min(length, needed)` gigarantiyahan nga dili molapas sa `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Ang buffered nga ikog karon namula, nagproseso sa bag-ong input.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // SAFETY: tungod kay `len - left` mao ang pinakadako nga sa daghang sa 8 ubos sa
            // `len`, ug tungod kay `i` magsugod sa `needed` diin `len` mao `length - needed`, `i + 8` mao ang garantiya nga dili kaayo kay sa o itanding `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // SAFETY: `i` mao karon ang `needed + len.div_euclid(8) * 8`,
        // busa `i + left` = `needed + len` = `length`, nga anaa sa kahulogan itanding `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Nagmugna sa usa ka `Hasher<S>` uban sa duha ka inisyal nga yawe gibutang sa 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}