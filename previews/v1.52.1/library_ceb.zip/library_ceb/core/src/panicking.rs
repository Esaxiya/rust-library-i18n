//! Pagsuporta sa Panic alang sa libcore
//!
//! Ang core library dili mahubit ang panicking, apan kini *nagdeklara* sa panic.
//! Kini gipasabut nga ang mga gimbuhaton sa sulud sa libcore gitugotan sa panic, apan aron mapuslanon ang usa ka paitaas nga crate kinahanglan ipasabut ang panicking aron magamit ang libcore.
//! Ang karon nga interface alang sa pag-panic mao ang:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! kahulugan Kini nagtugot alang sa nataranta nga sa bisan unsa nga kinatibuk-ang mensahe, apan kini dili motugot sa pagkapakyas sa usa ka bili `Box<Any>`.
//! (Ang `PanicInfo` adunay sulud ra nga `&(dyn Any + Send)`, diin gipuno namon ang kantidad nga dummy sa `PanicInfo: : internal_constructor`.) Ang hinungdan niini wala gitugotan ang pag-alibyo sa paggahin.
//!
//!
//! Ang kini nga module adunay sulud nga pila pa nga mga pagpaandar sa panicking, apan kini ang kinahanglan ra nga mga butang alang sa tagtipon.Ang tanan nga panics gipaandar sa us aka kini nga kalihokan.
//! Ang tinuod nga simbolo gideklara pinaagi sa `#[panic_handler]` nga hiyas.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Ang nagpahiping pagpatuman sa XcoreX macro sa libcore kung wala gigamit nga pag-format.
#[cold]
// ayaw gyud paglinya gawas kung panic_immediate_abort aron malikayan ang code bloat sa mga site sa pagtawag kutob sa mahimo
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // kinahanglan sa codegen alang sa panic sa overflow ug uban pang mga terminator nga `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Paggamit Arguments::new_v1 imbis format_args! ("{}", Expr) aron mahimo`g maminusan ang kadako sa overhead.
    // Ang format_args!Gigamit sa makro ang Display trait sa str aron magsulat expr, nga nagtawag sa Formatter::pad, nga kinahanglan ibutang ang string truncation ug padding (bisan kung wala`y gigamit dinhi).
    //
    // Ang paggamit sa Arguments::new_v1 mahimong tugotan ang tagtipon nga tangtangon ang Formatter::pad gikan sa output binary, makatipig hangtod sa pila ka kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // kinahanglan alang sa gisusi sa Constant nga panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // kinahanglan sa codegen alang sa panic sa pag-access sa OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ang nagpahiping pagpatuman sa XcoreX macro sa libcore kung gigamit ang pag-format.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // HINUMDOMI Kini nga kalihokan dili gyud molabang sa utlanan sa FFI;kini usa ka tawag nga Rust-to-Rust nga malutas sa pagpaandar sa `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // KALUWASAN: Ang `panic_impl` gihubit sa luwas nga Rust code ug sa ingon luwas tawgon.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Panlihok sa internal alang sa `assert_eq!` ug `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}