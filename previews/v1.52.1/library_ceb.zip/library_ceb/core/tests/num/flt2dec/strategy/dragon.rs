use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Hinay kaayo si Miri
fn exact_sanity_test() {
    // Ang kini nga pagsulay nagtapos sa pagdagan kung unsa ang mahimo ko ra nga hunahunaon mao ang pipila ka sulud nga kaso sa pag-andar sa `exp2` library, gihubit sa bisan unsang C runtime nga gigamit namo.
    // Sa VS 2013 kini nga pag-andar dayag nga adunay usa ka bug tungod kay kini nga pagsulay napakyas kung na-link, apan sa VS 2015 ang bug nagpakita nga naayo samtang ang pagsulay maayo ra.
    //
    // bug Ang daw usa ka kalainan sa pagbalik bili sa `exp2(-1057)`, diin sa VS 2013 kini mobalik sa usa ka double sa gamay sumbanan 0x2 ug sa VS 2015 kini mobalik 0x20000.
    //
    //
    // Sa pagkakaron isalikway ra gyud ang kini nga pagsulay sa MSVC tungod kay kini gisulayan bisan diin ug dili kami labi ka interesado sa pagsulay sa pagpatuman sa exp2 sa matag platform.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}