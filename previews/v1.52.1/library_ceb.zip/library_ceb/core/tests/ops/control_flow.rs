use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Kini mao ang dili lig-on nga nawong nga dapit, apan makatabang Padayon `?` barato sa taliwala kanila, bisan pa kon LLVM dili kanunay pagpahimulos sa niini karon.
    //
    // (Ang subo nga Resulta ug Opsyon dili magkatugma, busa ang ControlFlow dili parehas sa pareho.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}