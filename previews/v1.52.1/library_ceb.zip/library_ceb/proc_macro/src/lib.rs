//! Usa ka suporta librarya alang sa macro awtor sa diha nga importante nga bag-ong mga macros.
//!
//! Kini nga librarya, nga gihatag sa mga sumbanan nga-apod-apod, naghatag sa mga matang-ut-ut sa mga interface sa procedurally gihubit macro kahulugan sama sa function-sama sa macros `#[proc_macro]`, macro hiyas `#[proc_macro_attribute]` ug sa batasan kuha attributes`#[proc_macro_derive]`.
//!
//!
//! Tan-awa ang [the book] alang sa daghan pa.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Motino kon proc_macro nga abli ngadto sa programa karon nga nagdagan.
///
/// Ang proc_macro crate gituyo lamang alang sa paggamit sulod sa pagpatuman sa pamaagi macros.Ang tanan nga mga gimbuhaton niini nga crate panic kon gisangpit gikan sa gawas sa usa ka pamaagi sa macro, sama sa gikan sa usa ka build script o yunit pagsulay o ordinaryo nga Rust duha.
///
/// Uban sa pagkonsiderar alang sa mga librarya sa Rust nga gilaraw aron masuportahan ang parehong mga kaso nga paggamit sa macro ug non-macro, naghatag ang `proc_macro::is_available()` usa ka dili panic nga paagi aron mahibal-an kung ang imprastraktura nga gikinahanglan aron magamit ang API sa proc_macro karon magamit.
/// Mobalik nga tinuod kung gisangpit gikan sa sulud sa usa ka pamatasan nga pamaagi, sayop kung gisangpit gikan sa bisan unsang uban pa nga binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ang nag-unang matang nga gihatag sa niini nga crate, nga nagrepresentar sa usa ka abstract sapa sa tokens, o, mas espesipiko, usa ka han-ay sa token kahoy.
/// Naghatag ang tipo sa mga interface alang sa pag-iterate sa mga puno nga token ug, sa kasukwahi, pagkolekta sa daghang mga token nga mga punoan sa usa ka sapa.
///
///
/// Kini parehas ang input ug output sa `#[proc_macro]`, `#[proc_macro_attribute]` ug `#[proc_macro_derive]` nga mga kahulugan.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Nagbalik ang sayup gikan sa `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Nagbalik usa ka walay sulod nga `TokenStream` nga sulud walay mga token nga mga punoan.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Susihon kung kini nga `TokenStream` wala`y sulod.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Mga pagsulay sa pagguba sa pisi sa tokens ug pag-parse sa mga tokens sa usa ka token stream.
/// Hinaot nga mapakyas alang sa usa ka gidaghanon sa mga rason, alang sa panig-ingnan, kon ang pisi naglakip timbang delimiters o mga karakter nga dili kasamtangan nga diha sa pinulongan.
///
/// Ang tanan nga tokens sa na-pars nga sapa nakakuha og `Span::call_site()` spans.
///
/// NOTE: sa pipila ka mga sayop mahimong hinungdan panics sa baylo nga sa pagbalik `LexError`.Kita Reserve ang katungod sa pag-usab niini nga mga kasaypanan ngadto sa `LexError`s sa ulahi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Patik sa token sapa nga ingon sa usa ka hilo nga unta losslessly konbertibol balik ngadto sa mao gihapon nga token sapa (modulo parisan), gawas sa posible `TokenTree: : Group`s uban sa `Delimiter::None` delimiters ug negatibo numerawo literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Giimprinta ang token sa us aka porma nga kombenyente alang sa pag-debug.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Naghimo usa ka sapa nga token nga adunay sulud nga usa ka token nga punoan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Nagkolekta usa ka ihap sa mga puno sa token sa usa ka sapa.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Usa ka operasyon nga "flattening" sa mga sapa nga token, gikolekta ang mga punoan nga token gikan sa daghang mga sapa nga token sa usa ka sapa.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Paggamit usa ka na-optimize nga pagpatuman if/when posible.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Ang mga detalye sa pagpatuman sa publiko alang sa tipo nga `TokenStream`, sama sa mga iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Usa ka iterator sa `TokenTree`s`TokenStream`.
    /// subli mao ang "shallow", pananglitan, ang iterator wala recurse ngadto sa delimited mga grupo, ug mobalik tibuok grupo sa ingon nga token kahoy.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` midawat sa arbitraryong tokens ug gipalapdan sa usa ka `TokenStream` nga naglarawan sa input.
/// Pananglitan, ang `quote!(a + b)` maghimo usa ka ekspresyon, nga, kung gisusi, gitukod ang `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ang Unquoting gihimo sa `$`, ug ninglihok pinaagi sa pagkuha sa us aka sunod nga ident ingon ang wala`y termino nga termino.
/// Sa pagkutlo `$` sa iyang kaugalingon, sa paggamit sa `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Usa ka rehiyon sa source code, kauban ang kasayuran sa pagpalapad sa macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Naghimo usa ka bag-ong `Diagnostic` nga adunay gihatag nga `message` sa span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Ang usa ka dangaw nga determinasyon sa macro kahulugan site.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ang gitas-on sa pangamuyo sa karon nga pamaagi nga makro.
    /// Ilhanan nga gibuhat sa gitas-on sa niini masulbad ingon nga kon sila nahisulat direkta sa macro nahimutangan tawag (tawag-site hygiene) ug uban pang mga code sa macro tawag site makahimo sa pagtumong sa kanila ingon man.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ang usa ka dangaw nga nagrepresentar `macro_rules` hygiene, ug usahay mga katuyoan sa macro kahulugan site (lokal nga baryable, label, `$crate`) ug usahay sa macro tawag site (sa tanan).
    ///
    /// Ang lokasyon sa span gikuha gikan sa call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ang orihinal nga file sa gigikanan diin niini ang gipunting.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Ang `Span` alang sa tokens sa miaging macro pagpalapad nga gikan niini `self` si namugna gikan sa, kon sa bisan unsa nga.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ang gitas-on alang sa gigikanan nga gigikanan code nga gihimo ang `self`.
    /// Kon kini nga `Span` wala namugna gikan sa ubang macro pagpalapad unya sa pagbalik bili mao ang sama nga sama sa `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Nakuha ang pagsugod line/column sa gigikanan nga file alang sa kini nga span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Nakuha ang katapusan nga line/column sa gigikanan nga file alang sa kini nga span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Nagmugna sa usa ka bag-o nga gitas-on sa nga naglangkob `self` ug `other`.
    ///
    /// Mobalik `None` kon `self` ug `other` gikan sa lain-laing files.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Nakahimo usa ka bag-ong gilapdon nga adunay parehas nga kasayuran sa line/column ingon `self` apan nga nagsulbad sa mga simbolo nga ingon kini sa `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Naghimo usa ka bag-ong gilapdon nga adunay parehas nga pamatasan sa paglutas sa ngalan ingon `self` apan adunay kasayuran nga line/column nga `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Nagtandi sa parisan sa pagtan-aw kon sila managsama.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Gibalik ang gigikanan nga teksto sa luyo sa usa ka gilapdon.
    /// Kini nagpreserbar sa orihinal nga source code, lakip na ang mga luna ug mga komentaryo.
    /// Kini lamang ang mobalik sa usa ka resulta kon ang gitas-on sa katumbas sa tinuod nga source code.
    ///
    /// Note: Ang makitang resulta sa usa ka macro kinahanglan lamang mosalig sa tokens ug dili sa niini nga tinubdan nga teksto.
    ///
    /// Ang sangputanan sa kini nga kalihokan usa ka labing kaayo nga paningkamot nga magamit alang sa mga diagnostic ra.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Iimprenta usa ka dangaw sa usa ka porma nga kombenyente alang sa debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Usa ka linya-kolum pares nga nagrepresentar sa pagsugod o sa katapusan sa usa ka `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Ang linya nga 1 nga na-index sa gigikanan nga file diin magsugod o matapos ang span nga (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ang 0-index nga kolum (sa UTF-8 nga mga karakter) sa gigikanan nga file diin magsugod o matapos ang span nga (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ang tinubdan file sa usa ka gihatag `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Nakakuha sa dalan niini nga tinubdan file.
    ///
    /// ### Note
    /// Kung ang gilapdon sa code nga kauban sa kini nga `SourceFile` gihimo pinaagi sa usa ka external macro, kini nga macro, mahimo kini dili usa ka tinuud nga agianan sa filesystem.
    /// Gamita [`is_real`] sa pagsusi.
    ///
    /// Usab nga mubo nga sulat nga bisan kon `is_real` mobalik `true`, kon `--remap-path-prefix` gipasa sa sugo linya, ang dalan ingon sa gihatag tingali dili sa tinuod nga balido.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Mibalik `true` kon kini nga tinubdan file mao ang usa ka tinuod nga tinubdan file, ug dili nga namugna pinaagi sa pagpalapad sa usa ka eksternal nga macro ni.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Kini usa ka pag-hack hangtod ipatuman ang intercrate spans ug mahimo kami adunay tinuud nga mga file sa gigikanan alang sa mga spans nga namugna sa mga external macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ang usa ka token o sa usa ka delimited ay sa token kahoy (pananglitan, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Usa ka token sapa gilibutan sa bracket delimiters.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Usa ka nagpaila.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ang usa ka punctuation kinaiya (`+`, `,`, `$`, ug uban pa).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Usa ka literal nga karakter nga (`'a'`), string (`"hello"`), numero (`2.3`), ug uban pa.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Gibalik ang gitas-on sa kini nga kahoy, nga gitugyan sa `span` nga pamaagi sa sulud nga token o usa ka delimitado nga sapa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Gi-configure ang span alang sa *kini ra nga token*.
    ///
    /// Mubo nga sulat nga kon kini token mao ang usa ka `Group` nan kini nga pamaagi dili mapanagway sa gitas-on sa matag usa sa mga internal tokens, kini lamang idelegar sa `set_span` pamaagi sa matag laing.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Agi token kahoy diha sa usa ka porma nga kombenyente alang sa debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ang matag usa niini adunay ngalan sa tipo sa istraktura sa nakuha nga debug, busa ayaw pagsamok sa us aka dugang nga sapaw sa pagkagusto
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Giimprinta ang punoan nga token ingon usa ka pisi nga gituohang mahimong mawala nga mabalhin balik sa parehas nga punoan nga token (modulo spans), gawas sa posible nga `TokenTree: : Group`s nga adunay `Delimiter::None` delimiters ug mga negatibo nga numeric literal.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Usa ka delimitado nga sapa nga token.
///
/// Ang usa ka `Group` sa sulud adunay sulud nga usa ka `TokenStream` nga gilibutan sa mga `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Gihubit kung giunsa ang usa ka han-ay sa mga punoan nga token wala`y utlanan.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Usa ka bug-os nga delimiter, aron, alang sa panig-ingnan, sa pagpakita sa sa palibot tokens pag-abot gikan sa usa ka "macro variable" `$var`.
    /// Mahinungdanon nga mapadayon ang mga prayoridad sa operator sa mga kaso sama sa `$var * 3` diin ang `$var` mao ang `1 + 2`.
    /// Bug-os nga delimiters dili mahimo nga maluwas roundtrip sa usa ka token sapa pinaagi sa usa ka hilo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Nagmugna sa usa ka bag-o nga `Group` uban sa gihatag nga delimiter ug token sapa.
    ///
    /// magbubuhat Kini ang mga gitas-on alang sa niini nga grupo sa `Span::call_site()`.
    /// Sa pag-usab sa gitas-on sa imong mahimo sa paggamit sa `set_span` pamaagi sa ubos.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Gibalik ang delimiter sa kini nga `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Mobalik ang `TokenStream` sa tokens nga delimited sa niini nga `Group`.
    ///
    /// Hinumdomi nga ang giuli nga token stream wala mag-uban sa delimiter nga gibalik sa taas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Mibalik ang gitas-on alang sa mga delimiters niining token sapa, nga naglangkob sa sa tibuok `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Gibalik ang span nga nagtudlo sa nagbukas nga delimiter sa kini nga grupo.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Gibalik ang span nga nagtudlo sa nagtapos nga delimiter sa kini nga grupo.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Gi-configure ang gitas-on alang sa mga delimiter sa `Group`, apan dili ang sulud nga tokens.
    ///
    /// Ang kini nga pamaagi dili ** itakda ang gitas-on sa tanan nga sulud nga tokens nga giapil sa kini nga grupo, apan igabutang ra niini ang gitas-on sa delimiter tokens sa lebel sa `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Patik sa grupo ingon sa usa ka hilo nga kinahanglan nga losslessly konbertibol balik ngadto sa mao gihapon nga grupo (modulo parisan), gawas sa posible `TokenTree: : Group`s sa `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Usa ka `Punct` mao ang usa ka ka punctuation kinaiya sama sa `+`, `-` o `#`.
///
/// Ang mga operator sa multi-character sama sa `+=` girepresenta ingon duha nga mga higayon nga `Punct` nga adunay lainlaing mga porma sa `Spacing` nga gibalik.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Kung ang usa ka `Punct` gisundan dayon sa laing `Punct` o gisundan sa lain nga token o whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// pananglitan, ang `+` mao ang `Alone` sa `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// pananglitan, `+` mao `Joint` sa `+=` o `'#`.
    /// Ingon kadugangan, ang us aka kinutlo nga `'` mahimong moapil sa mga nagpaila aron maporma ang mga kinabuhi nga `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Naghimo usa ka bag-ong `Punct` gikan sa gihatag nga karakter ug spacing.
    /// Ang `ch` argumento kinahanglan usa ka balido nga punctuation kinaiya gitugotan sa pinulongan, kon dili ang function kabubut panic.
    ///
    /// Ang gibalik nga `Punct` adunay default span of `Span::call_site()` nga mahimong labi pa nga ma-configure sa pamaagi nga `set_span` sa ubus.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Gibalik ang kantidad sa kini nga bantas nga karakter ingon `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Gibalik ang gintang sa kini nga bantas nga karakter, nga nagpakita kung gisundan ba dayon kini sa lain nga `Punct` sa token stream, aron mahimo silang kombinasyon sa usa ka multi-character operator (`Joint`), o gisundan kini sa pipila pa nga token o whitespace (`Alone`) busa ang operator sigurado nga natapos.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Gibalik ang gitas-on alang sa kini nga bantas nga karakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// I-configure ang gitas-on alang sa kini nga bantas nga karakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Giimprinta ang bantas nga karakter ingon usa ka pisi nga kinahanglan mawala nga mabalhin sa parehas nga karakter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Usa ka ilhanan (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Naghimo usa ka bag-ong `Ident` nga adunay gihatag nga `string` maingon man ang gitino nga `span`.
    /// Ang argumento nga `string` kinahanglan usa ka balido nga identifier nga gitugot sa sinultian (lakip ang mga keyword, pananglitan `self` o `fn`).Kung dili, ang pagpaandar sa panic.
    ///
    /// Matikdi nga `span`, karon sa rustc, configures sa impormasyon hygiene alang sa ilhanan niini.
    ///
    /// Ingon nga sa panahon niini nga `Span::call_site()` tin-awng opts-sa "call-site" hygiene kahulogan nga ilhanan nga gibuhat sa gitas-on sa niini masulbad ingon nga kon sila nahisulat direkta sa nahimutangan sa mga macro tawag, ug uban pang mga code sa macro tawag site makahimo sa pagtumong sa kanila ingon man.
    ///
    ///
    /// Ang ulahi nga mga spans sama sa `Span::def_site()` magtugot nga mag-opt-in sa "definition-site" hygiene nga nagpasabut nga ang mga identifier nga gihimo sa kini nga span masulbad sa lokasyon sa makro nga kahulugan ug uban pang code sa site sa macro call dili makigsulti kanila.
    ///
    /// Tungod sa karon nga kaimportante sa kahinlo kini nga magtutukod, dili sama sa ubang mga tokens, nanginahanglan usa ka `Span` nga matino sa konstruksyon.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama sa `Ident::new`, apan nagmugna sa usa ka hilaw nga ilhanan (`r#ident`).
    /// Ang `string` argumento nga usa ka balido nga ilhanan gitugotan sa pinulongan (lakip na ang keywords, pananglitan `fn`).
    /// Ang mga keyword nga magamit sa mga bahin sa agianan (pananglitan
    /// `self`, Ang `super`) dili gisuportahan ug hinungdan sa usa ka panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Gibalik ang span sa kini nga `Ident`, nga gilakip ang tibuuk nga pisi nga gibalik sa [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures ang gitas-on niini nga `Ident`, nga lagmit sa pag-usab sa iyang mga hygiene konteksto.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Giimprinta ang nagpaila ingon usa ka pisi nga kinahanglan mawala nga mabalhin balik sa parehas nga nagpaila.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Usa ka literal nga hilo (`"hello"`), Byte hilo (`b"hello"`), kinaiya (`'a'`), Byte kinaiya (`b'a'`), usa ka integer o naglutaw punto nga gidaghanon uban sa o sa walay sa usa ka suffix (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean literals sama `true` ug `false` dili iya dinhi, sila `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Nakahimo usa ka bag-ong nahingpit nga integer nga literal sa gitumbok nga kantidad.
        ///
        /// function Kini paghimo sa usa ka integer sama `1u32` diin ang integer bili bungat mao ang unang bahin sa token ug sa integral nga suffixed usab sa katapusan.
        /// Literals gimugna gikan sa negatibo nga mga numero dili mahimo nga mabuhi round-biyahe pinaagi sa `TokenStream` o kuldas ug mahimong mabungkag ngadto sa duha ka tokens (`-` ug positibo literal).
        ///
        ///
        /// Literals gibuhat pinaagi niini nga paagi ang mga `Span::call_site()` gitas-on pinaagi sa default, nga mahimo nga gihulma, giporma sa mga `set_span` pamaagi sa ubos.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Nakahimo usa ka bag-ong unsuffixed integer nga literal nga adunay gipiho nga kantidad.
        ///
        /// function Kini paghimo sa usa ka integer sama `1` diin ang integer bili bungat mao ang unang bahin sa token.
        /// Walay suffix ang bungat niining token, nga nagpasabot nga pag-ampo sama sa `Literal::i8_unsuffixed(1)` mga katumbas sa `Literal::u32_unsuffixed(1)`.
        /// Ang mga literal nga gihimo gikan sa mga negatibo nga numero mahimong dili mabuhi sa mga rountrips hangtod sa `TokenStream` o mga kuwerdas ug mahimong mabuak sa duha nga tokens (`-` ug positibo nga literal).
        ///
        ///
        /// Literals gibuhat pinaagi niini nga paagi ang mga `Span::call_site()` gitas-on pinaagi sa default, nga mahimo nga gihulma, giporma sa mga `set_span` pamaagi sa ubos.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Nagmugna sa usa ka bag-o nga unsuffixed naglutaw-punto literal.
    ///
    /// magbubuhat Kini mao ang susama sa mga sama `Literal::i8_unsuffixed` diin bili sa float ni mibuga direkta ngadto sa token apan walay suffix gigamit, mao mahimong sabton nga usa ka `f64` sa ulahi sa tighipos.
    ///
    /// Ang mga literal nga gihimo gikan sa mga negatibo nga numero mahimong dili mabuhi sa mga rountrips hangtod sa `TokenStream` o mga kuwerdas ug mahimong mabuak sa duha nga tokens (`-` ug positibo nga literal).
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar nagkinahanglan nga ang gipiho nga float mao ang may katapusan, pananglitan kung kini walay katapusan o NaN kini nga pag-andar panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Nagmugna sa usa ka bag-o nga suffixed naglutaw-punto literal.
    ///
    /// magbubuhat Kini nga paghimo sa usa ka literal nga sama `1.0f32` diin ang bili bungat mao ang nag-unang bahin sa token ug `f32` mao ang suffix sa token.
    /// Kini nga token kanunay nga sabton nga usa ka `f32` sa tighipos.
    /// Ang mga literal nga gihimo gikan sa mga negatibo nga numero mahimong dili mabuhi sa mga rountrips hangtod sa `TokenStream` o mga kuwerdas ug mahimong mabuak sa duha nga tokens (`-` ug positibo nga literal).
    ///
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar nagkinahanglan nga ang gipiho nga float mao ang may katapusan, pananglitan kung kini walay katapusan o NaN kini nga pag-andar panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Nagmugna sa usa ka bag-o nga unsuffixed naglutaw-punto literal.
    ///
    /// magbubuhat Kini mao ang susama sa mga sama `Literal::i8_unsuffixed` diin bili sa float ni mibuga direkta ngadto sa token apan walay suffix gigamit, mao mahimong sabton nga usa ka `f64` sa ulahi sa tighipos.
    ///
    /// Ang mga literal nga gihimo gikan sa mga negatibo nga numero mahimong dili mabuhi sa mga rountrips hangtod sa `TokenStream` o mga kuwerdas ug mahimong mabuak sa duha nga tokens (`-` ug positibo nga literal).
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar nagkinahanglan nga ang gipiho nga float mao ang may katapusan, pananglitan kung kini walay katapusan o NaN kini nga pag-andar panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Nagmugna sa usa ka bag-o nga suffixed naglutaw-punto literal.
    ///
    /// magbubuhat Kini nga paghimo sa usa ka literal nga sama `1.0f64` diin ang bili bungat mao ang nag-unang bahin sa token ug `f64` mao ang suffix sa token.
    /// Kini nga token kanunay nga mapahinumduman nga mahimong usa ka `f64` sa tagtipon.
    /// Ang mga literal nga gihimo gikan sa mga negatibo nga numero mahimong dili mabuhi sa mga rountrips hangtod sa `TokenStream` o mga kuwerdas ug mahimong mabuak sa duha nga tokens (`-` ug positibo nga literal).
    ///
    ///
    /// # Panics
    ///
    /// Kini nga pag-andar nagkinahanglan nga ang gipiho nga float mao ang may katapusan, pananglitan kung kini walay katapusan o NaN kini nga pag-andar panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Hugot nga literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Kinaiya literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Literal nga byte nga pisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Gibalik ang span nga naglangkob sa kini nga literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures ang gitas-on sa nakig alang sa literal nga niini.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Mobalik ang usa ka `Span` nga mao ang usa ka subset sa `self.span()` nga naglangkob sa lamang sa tinubdan bytes sa laing `range`.
    /// Mibalik `None` kon ang buot-nga trimmed gitas-on mao ang sa gawas sa utlanan sa `self`.
    ///
    // FIXME(SergioBenitez): check nga ang Byte laing magsugod ug tumoy sa usa ka UTF-8 utlanan sa tinubdan.
    // kung dili man, lagmit nga ang usa ka panic mahinabo sa ubang lugar kung giimprinta ang gigikanan nga teksto.
    // FIXME(SergioBenitez): walay paagi alang sa user sa nga masayud kon unsa ang `self.span()` tinuod nga maps sa, mao nga kini nga pamaagi mahimo karon lamang nga gitawag binuta.
    // Pananglitan, ang `to_string()` alang sa karakter nga 'c' mobalik "'\u{63}'";walay paagi alang sa user sa nga masayud kon ang tinubdan teksto mao 'c' o kon kini mao '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) usa ka butang nga kaamgiran sa `Option::cloned`, apan alang sa `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Ang NB, ang taytayan naghatag lamang `to_string`, ipatuman ang `fmt::Display` pinasukad niini (ang baliktad sa naandan nga relasyon tali sa duha).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Patik sa literal nga sama sa sa usa ka hilo nga kinahanglan nga losslessly konbertibol balik ngadto sa mao gihapon nga literal nga (gawas sa posible nga nagkalingin sa naglutaw punto literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Gisunud nga pag-access sa mga variable sa palibot.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Kuhaa ang usa ka variable sa palibot ug idugang kini aron matukod ang kasayuran sa pagsalig.
    /// Pagtukod sistema pagtuman sa tighipos makaila nga ang baryable nga Naablihan sa panahon sa pagtigum, ug makahimo sa pagsubli sa pagtukod sa diha nga ang bili sa baryable nga mga kausaban.
    ///
    /// Gawas sa pagsalig sa pagsalig sa kini nga pag-andar kinahanglan katumbas sa `env::var` gikan sa sukaranan nga librarya, gawas nga ang argumento kinahanglan UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}