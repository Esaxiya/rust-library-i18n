// rsbegin.o ug rsend.o mao ang gitawag nga "compiler runtime startup objects".
// sila naglakip code nga gikinahanglan sa husto initialize sa tighipos Runtime.
//
// Sa diha nga ang usa ka executable o dylib larawan nga nalambigit, ang tanan nga user code ug mga librarya ang mga "sandwiched" tali niining duha ka mga file nga butang, mao nga code o data nga gikan sa rsbegin.o mahimong una sa tagsa-tagsa nga mga seksyon sa larawan, samtang code ug data gikan sa rsend.o mahimong sa katapusan nga mga.
// epekto Kini nga gigamit sa mga simbolo nga dapit sa sinugdanan o sa katapusan sa usa ka seksyon, ingon man sa sal-ot sa bisan unsa nga gikinahanglan nga header o footers.
//
// Hinumdomi nga ang tinuud nga punto sa pagsulud sa module nakit-an sa C runtime startup nga butang (kasagaran gitawag nga `crtX.o`), nga pagkahuman gisangpit ang mga callback sa inisyal sa uban pang mga bahin sa runtime (nagparehistro pinaagi sa us aka espesyal nga seksyon sa imahe).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Mga marka nga nagsugod sa seksyon sa stack nga hugna nga pahunong sa impormasyon
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Nagaras luna alang sa unwinder internal nga basahon-pagtuman.
    // Kini gihubit ingong `struct object` sa $ GCC/makarelaks-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Makarelaks info registration/deregistration buluhaton.
    // Tan-awa ang mga dokumento sa libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // magparehistro makarelaks info sa module tuboy
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister sa pagsira
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-piho nga registration init/uninit rutina
    pub mod mingw_init {
        // Ang mga butang sa pagsugod sa MinGW (crt0.o/dllcrt0.o) mag-awhag sa mga global konstruktor sa mga seksyon nga .ctors ug .dtors sa pagsugod ug paggawas.
        // Sa kaso sa DLLs, kini mao ang gibuhat sa diha nga ang DLL nga loaded ug gihubaran.
        //
        // linker ang matang sa mga seksyon, nga nagsiguro nga ang atong callbacks nahimutang sa katapusan sa listahan.
        // Tungod kay constructors mga modagan sa reverse aron, kini nagsiguro nga ang atong callbacks mao ang una ug katapusan nga mga gipatay.
        //
        //

        #[link_section = ".ctors.65535"] // .ctor. *: Mga pagsugod sa callback sa C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . C termination callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}