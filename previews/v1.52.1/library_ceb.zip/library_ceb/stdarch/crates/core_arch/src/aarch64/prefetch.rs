#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Kitaa ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Dad-a sa ang cache linya nga naglangkob address `p` paggamit sa gihatag `rw` ug `locality`.
///
/// Ang `rw` kinahanglan usa sa:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): ang prefetch ang pag-andam alang sa usa ka mabasa.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): ang prefetch ang pag-andam alang sa usa ka isulat.
///
/// Ang `locality` kinahanglan sa usa sa:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Streaming o non-temporal prefetch, alang sa data nga gigamit sa makausa lamang.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Ikuha sa lebel sa 3 cache.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Dad-a sa ngadto sa ang-ang 2 cache.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Dad-a sa ngadto sa ang-ang 1 cache.
///
/// Ang mga instruksyon prefetch handumanan signal sa sistema sa panumduman nga handumanan accesses gikan sa usa ka espesipikong address mao ang lagmit nga mahitabo sa duol sa future.
/// Ang handumanan sistema makatubag pinaagi sa mga buhat nga gipaabot sa pagpadali sa handumanan access sa diha nga sila mahitabo, sama sa preloading ang tinudlong address ngadto sa usa o labaw pa tagoanan.
///
/// Tungod kay ang kini nga mga signal mga pahiwatig ra, balido alang sa usa ka partikular nga CPU aron matambalan ang bisan unsa o tanan nga mga panudlo nga prefetch ingon usa ka NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Gigamit namon ang `llvm.prefetch` instrinsic nga adunay `cache type` =1 (data cache).
    // `rw` ug `strategy` gibase sa mga parameter sa pagpaandar.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}