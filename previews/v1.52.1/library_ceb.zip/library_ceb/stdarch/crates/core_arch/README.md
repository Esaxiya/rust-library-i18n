`core::arch` - core librarya intrinsics arkitektura-piho nga ni Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Ang `core::arch` module nagpatuman sa intrinsics nga nagsalig sa arkitektura (pananglitan SIMD).

# Usage 

`core::arch` magamit ingon bahin sa `libcore` ug kini gi-export usab sa `libstd`.Mas gusto ang paggamit niini pinaagi sa `core::arch` o `std::arch` kaysa pinaagi sa niining crate.
Ang mga dili malig-on nga dagway kanunay nga magamit sa gabii nga Rust pinaagi sa `feature(stdsimd)`.

Ang paggamit sa `core::arch` pinaagi sa niining crate nanginahanglan matag gabii nga Rust, ug mahimo (ug kini) kanunay mabuak.Ang mga kaso ra nga kinahanglan nimo hunahunaon nga gamiton kini pinaagi sa crate nga:

* kon kamo kinahanglan nga re-pagtipon `core::arch` sa imong kaugalingon, pananglitan, uban sa partikular nga target-bahin nakahimo nga dili nakahimo alang sa `libcore`/`libstd`.
Note: kung kinahanglan nimo kini nga tipon usab alang sa usa ka dili sukaranan nga target, palihug gusto nga gamiton ang `xargo` ug paghiusa pag-usab sa `libcore`/`libstd` nga angay sa baylo nga gamiton kini nga crate.
  
* gamit ang pipila ka mga dagway nga mahimo`g dili magamit bisan sa luyo sa dili lig-on nga mga dagway sa Rust.kita mosulay sa paghupot niini nga mga sa usa ka minimum.
Kon imong gikinahanglan aron sa paggamit sa pipila niini nga mga bahin, palihug abli sa usa ka isyu aron nga kita ibutyag kanila sa matag gabii Rust ug kamo makahimo sa paggamit kanila gikan didto.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` panguna nga gipanghatag sa ilalum sa mga termino sa pareho nga lisensya sa MIT ug Lisensya nga Apache (Bersyon 2.0), nga adunay mga bahin nga gitabunan sa lainlaing mga lisensya nga sama sa BSD.

Tan-awa ang LICENSE-APACHE, ug LICENSE-MIT alang sa mga detalye.

# Contribution

Gawas kon kamo tin-aw nga estado kon dili, sa bisan unsa nga kontribusyon tinuyo gisumiter alang sa paglakip sa `core_arch` pinaagi kanimo, ingon sa gihubit sa lisensya Apache-2.0, mahimong duha lisensyado nga ingon sa ibabaw, nga walay bisan unsa nga dugang nga mga termino o mga kahimtang sa.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












