# Naghatag sa stdarch

Ang `stdarch` crate labaw pa sa kaandam nga modawat mga amot!Una na tingali gusto nga susihon ang repository ug sa pagsiguro nga ang mga pagsulay nahitabo alang kaninyo:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Diin `<your-target-arch>` mao ang target triple ingon sa gigamit sa `rustup`, eg `x86_x64-unknown-linux-gnu` (nga walay bisan unsa nga nag-unang `nightly-` o susama nga mga).
Usab hinumdumi nga tipiganan kini nagkinahanglan sa matag gabii channel sa Rust!
Sa tinuud ang mga pagsulay sa ibabaw nanginahanglan sa gabii nga rust aron mahimong default sa imong sistema, aron mahibal-an nga gamiton ang `rustup default nightly` (ug `rustup default stable` aron ibalik).

Kon sa bisan unsa sa mga lakang sa ibabaw wala sa trabaho, [please let us know][new]!

Sunod nga mahimo nimo ang [find an issue][issues] aron makatabang, gipili namon ang pipila nga mga tag sa [`help wanted`][help] ug [`impl-period`][impl] nga mahimo`g magamit ang pipila nga tabang. 
nga kamo mahimo nga labing interesado sa [#40][vendor], pagpatuman sa tanan nga vendor intrinsics sa x86.Ang kana nga isyu nakakuha pipila ka maayong mga panudlo bahin sa kung diin magsugod!

Kon na kamo sa kinatibuk-ang mga pangutana mobati nga gawasnon sa [join us on gitter][gitter] ug mangutana sa palibot!Mobati nga gawasnon sa ping sa bisan@BurntSushi o@alexcrichton uban sa mga pangutana.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Sa unsa nga paagi sa pagsulat mga panig-ingnan alang sa stdarch intrinsics

Adunay pipila nga mga bahin nga kinahanglan mapagan alang sa gihatag nga intrinsic aron molihok nga maayo ug ang pananglitan kinahanglan ipadagan ra sa `cargo test --doc` kung ang bahin gisuportahan sa CPU.

Ingon usa ka sangputanan, ang default `fn main` nga gihimo sa `rustdoc` dili molihok (sa kadaghanan nga mga kaso).
Hunahunaa ang paggamit sa mosunud ingon usa ka panudlo aron masiguro nga ang imong pananglitan molihok sama sa gilauman.

```rust
/// # // kinahanglan kita cfg_target_feature aron sa pagsiguro sa panig-ingnan mao lamang
/// # // gipadagan sa `cargo test --doc` kung gisuportahan sa CPU ang dagway
/// # #![feature(cfg_target_feature)]
/// # // Kinahanglan namon ang target_feature aron magamit ang intrinsic
/// # #![feature(target_feature)]
/// #
/// # // Ang rustdoc pinaagi sa default naggamit `extern crate stdarch`, apan kinahanglan namon ang
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Ang tinuud nga punoan nga kalihokan
/// # fn main() {
/// #     // Dagan lang kini kung gisuportahan ang `<target feature>`
/// #     kon cfg_feature_enabled! ("<target feature>"){
/// #         // Paghimo usa ka function nga `worker` nga ipadagan ra kung ang target nga bahin
/// #         // gisuportahan ug gisiguro nga ang `target_feature` gipalihok alang sa imong trabahante
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         dili luwas fn worker() {
/// // Isulat ang imong panig-ingnan dinhi.Cebuano News piho nga intrinsics magabuhat dinhi!Lakaw ihalas nga!
///
/// #         }
///
/// #         dili luwas { worker(); }
/// #     }
/// # }
```

Kon ang pipila sa mga sa ibabaw syntax dili motan-aw sa mga, ang [Documentation as tests] seksyon sa [Rust Book] naghulagway sa `rustdoc` syntax na man.
Sama sa naandan, mobati nga gawasnon sa [join us on gitter][gitter] ug pangutan-a kami kung naigo nimo ang bisan unsang mga snag, ug salamat sa imong pagtabang nga mapaayo ang dokumentasyon sa `stdarch`!

# Mga Panudlo sa alternatibo nga Pagsulay

Kasagaran girekomenda nga gamiton nimo ang `ci/run.sh` aron mapadagan ang mga pagsulay.
Apan kini dili unta pagtrabaho alang kaninyo, eg kon ikaw sa Windows.

Sa kaso nga ikaw mahulog balik sa nagaagay nga `cargo +nightly test` ug `cargo +nightly test --release -p core_arch` alang sa pagsulay sa code nga kaliwatan.
Mubo nga sulat nga kini nga mga nagkinahanglan sa matag gabii toolchain nga-instalar ug sa `rustc` nga mahibalo bahin sa imong target triple ug CPU niini.
Sa partikular nga kamo kinahanglan nga ibutang sa `TARGET` palibot baryable sama sa imong alang sa `ci/run.sh`.
Dugang pa nga imong gikinahanglan aron sa `RUSTCFLAGS` (panginahanglan sa `C`) sa pagpaila sa mga bahin target, eg `RUSTCFLAGS="-C -target-features=+avx2"`.
Ikaw mahimo usab nga gibutang sa `-C -target-cpu=native` kon ikaw "just" pagpalambo sa batok sa imong kasamtangan nga CPU.

Pasidan-an nga kung gamiton nimo kini nga mga alternatibo nga panudlo, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], pananglitan
pahamatngon kaliwatan pagsulay mahimong mapakyas tungod kay ang disassembler nga si kanila sa lahi nga paagi, eg
mahimo kini makamugna `vaesenc` imbis nga mga panudlo sa `aesenc` bisan kung managsama ang ilang pamatasan.
Ingon usab kini nga mga panudlo nagpatuman dili kaayo mga pagsulay kaysa sa naandan nga buhaton, busa ayaw katingala nga kung sa katapusan imong paghangyo pipila ka mga sayup mahimo magpakita alang sa mga pagsulay nga wala masakop dinhi.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






