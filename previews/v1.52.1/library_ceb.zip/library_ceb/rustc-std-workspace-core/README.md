# Ang `rustc-std-workspace-core` crate

Kini crate mao ang usa ka shim ug walay sulod crate nga lamang nag-agad sa `libcore` ug reexports sa tanan sa mga sulod niini.
Ang crate mao ang crux sa paghatag gahum sa mga sumbanan nga librarya sa magdepende sa crates gikan sa crates.io

Ang Crates sa crates.io nga ang sukaranan nga librarya nagsalig sa kinahanglan nga pagsalig sa `rustc-std-workspace-core` crate gikan sa crates.io, nga wala`y sulod.

Kita sa paggamit sa `[patch]` sa mopalabaw kini sa niini nga crate sa tipiganan niini.
Ingon sa usa ka resulta, crates sa crates.io magakabig sa usa ka pagsalig edge sa `libcore`, ang bersyon gihubit sa tipiganan niini.
Nga kinahanglan sa tanang mga pagsalig sulab aron sa pagsiguro sa Cargo nagtukod crates malampuson!

Hinumdomi nga ang crates sa crates.io kinahanglan nga magsalig sa niining crate nga adunay ngalan nga `core` alang sa tanan nga magamit nga husto.Aron mahimo kana mahimo nila gamiton:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Pinaagi sa paggamit sa mga `package` yawi sa crate giilisan og ngalan nga sa `core`, nga nagpasabot kini nga tan-awon sama sa

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kung gisangpit sa Cargo ang tagtipon, gitagbaw ang gipakita nga direktibo nga `extern crate core` nga giindyeksyon sa tagtipon.




