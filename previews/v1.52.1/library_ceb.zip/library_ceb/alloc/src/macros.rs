/// Naghimo usa ka [`Vec`] nga sulud sa mga argumento.
///
/// `vec!` nagtugot sa `Vec`s nga gipasabut sa parehas nga syntax sama sa mga gipahayag nga laray.
/// Adunay duha ka porma sa kini nga macro:
///
/// - Paghimo usa ka [`Vec`] nga adunay sulud nga gihatag nga lista sa mga elemento:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Paghimo usa ka [`Vec`] gikan sa usa ka gihatag nga elemento ug gidak-on:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Hinumdomi nga dili sama sa mga gipahayag sa array nga kini nga syntax nagsuporta sa tanan nga mga elemento nga nagpatuman sa [`Clone`] ug ang ihap sa mga elemento dili kinahanglan magpadayon.
///
/// Kini gamiton `clone` sa pagsundog sa usa ka ekspresyon, mao nga ang usa ka kinahanglan nga mag-amping sa paggamit niini uban sa matang nga may usa ka nonstandard `Clone` pagpatuman.
/// Pananglitan, `vec![Rc::new(1);5] `maghimo usa ka vector nga lima nga pakisayran sa parehas nga kahon nga integer nga kantidad, dili lima nga pakisayran nga nagtudlo sa independente nga mga kahon nga integer.
///
///
/// Ingon usab, hinumdomi nga gitugotan ang `vec![expr; 0]`, ug naghimo usa ka walay sulod nga vector.
/// Susihon ra gihapon niini ang `expr`, bisan pa, ug dayon ihulog ang resulta nga kantidad, busa paghunahunaon ang mga epekto.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): uban ang cfg(test) ang adunay kinaiyanhon nga pamaagi nga `[T]::into_vec`, nga gikinahanglan alang sa kini nga kahulugan sa macro, dili magamit.
// Hinuon gamita ang `slice::into_vec` function nga magamit lamang sa cfg(test) NB tan-awa ang slice::hack module sa slice.rs alang sa dugang nga kasayuran
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Naghimo usa ka `String` gamit ang interpolation sa mga runtime expression.
///
/// Ang una nga argumento nga nadawat sa `format!` usa ka format string.Kinahanglan kini usa ka literal nga pisi.Ang gahum sa pormat nga pormat naa sa sulud nga `{}` s.
///
/// Ang mga dugang nga parameter nga gipasa sa `format!` pulihan ang mga "{}` sulud sa pormat sa pag-format sa han-ay nga gihatag gawas kung ginganlan o gigamit ang mga parameter nga posisyonal;tan-awa ang [`std::fmt`] alang sa dugang nga kasayuran.
///
///
/// Ang usa ka kasagarang gamit sa `format!` mao ang concatenation ug interpolation of strings.
/// Ang parehas nga kombensiyon gigamit uban ang [`print!`] ug [`write!`] macros, depende sa gilaraw nga padulnganan sa pisi.
///
/// Aron mabalhin ang usa ka kantidad sa usa ka pisi, gamita ang pamaagi nga [`to_string`].Gigamit niini ang [`Display`] formatting trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` Ang panics kung ang usa ka pag-format nga pagpatuman sa trait mobalik usa ka sayup.
/// Gipasabut niini ang usa ka sayup nga pagpatuman sanglit ang `fmt::Write for String` wala gyud mobalik bisan usa nga sayup.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Pilit ang node sa AST sa usa ka ekspresyon aron mapaayo ang mga diagnostic sa posisyon sa sumbanan.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}