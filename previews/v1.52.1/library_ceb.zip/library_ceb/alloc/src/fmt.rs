//! Mga kagamitan alang sa pag-format ug pag-print sa `String`s.
//!
//! Kini nga module adunay sulud nga suporta sa runtime alang sa [`format!`] syntax extension.
//! Ang kini nga makro gipatuman sa tag-compiler aron magpagawas mga tawag sa kini nga modyul aron ma-format ang mga argumento sa pagkahuman sa mga pisi.
//!
//! # Usage
//!
//! Gilaraw ang [`format!`] macro nga pamilyar sa mga naggikan sa C's `printf`/`fprintf` function o Python's `str.format` function.
//!
//! Ang pipila ka mga pananglitan sa [`format!`] extension mao ang:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" nga adunay mga nag-una nga zero
//! ```
//!
//! Gikan niini, mahimo nimo makita nga ang una nga lantugi usa ka format string.Kini ang gikinahanglan sa tighipos alang niini aron mahimong usa ka hilo literal;dili kini mahimo nga usa ka variable nga gipasa (aron mahimo ang pagsusi sa pagka-tinuod).
//! Pagkahuman nga gitapos sa tagkomposo ang format string ug mahibal-an kung ang lista sa mga argumento nga gihatag angay nga ipasa sa kini nga format string.
//!
//! Aron mabalhin ang usa ka kantidad sa usa ka pisi, gamita ang pamaagi nga [`to_string`].Gigamit niini ang [`Display`] formatting trait.
//!
//! ## Mga sukdanan sa posisyon
//!
//! Gitugotan ang matag argumento sa pag-format nga ipaila kung unsang kantidad nga argumento ang girekomenda niini, ug kung nawala kini giisip nga "the next argument".
//! Pananglitan, ang format string `{} {} {}` magkinahanglan tulo nga mga parameter, ug kini i-format sa parehas nga han-ay sa gihatag kanila.
//! Ang format string `{2} {1} {0}`, bisan pa, mag-format sa mga argumento sa reverse order.
//!
//! Ang mga butang mahimo`g usa ka gamay nga maliputon sa higayon nga magsugod ka sa pag-interling sa duha ka lahi nga posisyonal nga mga specifier.Ang "next argument" specifier mahimong hunahunaon ingon usa ka iterator sa lantugi.
//! Sa matag higayon nga makita ang usa ka "next argument" specifier, ang iterator mouswag.Kini mosangpot sa pamatasan nga sama niini:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ang panloob nga iterator sa lantugi wala pauswag sa oras nga makita ang una nga `{}`, busa gipatik niini ang una nga lantugi.Pagkahuman sa pagkab-ot sa ikaduha nga `{}`, ang iterator miabante sa ikaduha nga lantugi.
//! Sa tinuud, ang mga parameter nga tin-aw nga nagngalan sa ilang argumento dili makaapekto sa mga parameter nga dili magngalan sa usa ka argumento sa mga termino sa posisyonal nga mga specifier.
//!
//! Gikinahanglan ang usa ka format string aron magamit ang tanan nga mga argumento, kung dili kini usa ka sayup sa oras nga pagtipon.Mahimo ka magtumong sa parehas nga lantugi labi pa sa kausa ka porma sa format.
//!
//! ## Ginganlan nga mga parameter
//!
//! Ang Rust mismo wala`y sama sa Python nga katumbas sa ginganlan nga mga parameter sa usa ka function, apan ang [`format!`] macro usa ka extension sa syntax nga nagtugot niini nga magamit ang mga ginganlan nga mga parameter.
//! Ang mga gihinganlan nga parameter gilista sa katapusan sa lista sa lantugi ug adunay syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Pananglitan, ang mosunud nga [`format!`] nga ekspresyon tanan gigamit nga ginganlan argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Dili balido nga ibutang ang mga posisyonal nga parameter (ang mga wala`y ngalan) pagkahuman sa mga pangatarungan nga adunay mga ngalan.Sama sa mga posisyonal nga parameter, dili balido ang paghatag mga ginganlan nga mga parameter nga wala magamit sa format string.
//!
//! # Mga Parameter sa Pag-format
//!
//! Ang matag argumento nga gi-format mahimo nga mabalhin sa usa ka gidaghanon sa mga parameter sa pag-format (katugbang sa `format_spec` sa [the syntax](#syntax)). Kini nga mga parameter nakaapekto sa representasyon sa string kung unsa ang gi-format.
//!
//! ## Width
//!
//! ```
//! // Ang tanan niini nga print "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Kini usa ka parameter alang sa "minimum width" nga kinahanglan kuhaon ang format.
//! Kung ang pisi sa bili dili pun-on kini daghang mga karakter, nan ang padding nga gitino sa fill/alignment magamit aron makuha ang gikinahanglan nga wanang (tan-awa sa ubus).
//!
//! Ang kantidad alang sa gilapdon mahimo usab igahatag ingon usa ka [`usize`] sa lista sa mga parameter pinaagi sa pagdugang usa ka postfix `$`, nga gipakita nga ang ikaduha nga argumento usa ka [`usize`] nga nagpiho sa gilapdon.
//!
//! Ang pag-refer sa us aka lantugi nga adunay dolyar nga syntax dili makaapekto sa counter nga "next argument", busa kasagaran usa ka maayong ideya nga mag-refer sa mga argumento pinaagi sa posisyon, o gamiton ang mga ginganlan nga argumento.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ang opsyonal pagkahubog kinaiya ug pagpahiangay gihatag kasagaran inubanan sa mga sa sukaranan [`width`](#width).Kinahanglan kini ipasabut sa wala pa ang `width`, pagkahuman gyud sa `:`.
//! Gipakita niini nga kung ang kantidad nga gi-format labi ka gamay kaysa `width` ang pipila nga dugang nga mga karakter maimprinta sa libot niini.
//! Ang pagpuno moabut sa mga mosunud nga lahi alang sa lainlaing paglinya:
//!
//! * `[fill]<` - Ang lantugi gibilin sa wala sa linya sa mga haligi nga `width`
//! * `[fill]^` - ang lantugi gitaliwad-an sa mga haligi nga `width`
//! * `[fill]>` - ang argumento husto nga gipahiangay sa mga haligi sa `width`
//!
//! Ang default [fill/alignment](#fillalignment) alang sa dili mga numero usa ka wanang ug nakahanay sa wala.Ang default alang sa mga numeric formatter usa usab ka karakter sa kawanangan apan adunay pag-align sa tuo.
//! Kung ang `0` flag (tan-awa sa ubus) gitino alang sa mga numero, nan ang gipasabut nga pagpuno nga karakter mao ang `0`.
//!
//! Hinumdomi nga ang paglinya mahimong dili ipatuman sa pipila nga mga lahi.Sa partikular, dili kini sa kinatibuk-an gipatuman alang sa `Debug` trait.
//! Ang usa ka maayong paagi aron maseguro nga magamit ang padding mao ang pag-format sa imong pagsulud, pagkahuman ibutang ang sangputanan nga string aron makuha ang imong output:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Kumusta Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Kini ang tanan nga mga bandila nga nagbag-o sa kinaiya sa formatter.
//!
//! * `+` - Gilaraw kini alang sa mga tipo sa numero ug gipakita nga ang pirma kinahanglan kanunay nga ipatik.Ang mga positibo nga karatula wala gyud ma-print pinaagi sa default, ug ang negatibo nga timaan giimprinta lamang pinaagi sa default alang sa `Signed` trait.
//! Gipakita sa kini nga bandila nga ang husto nga timaan (`+` o `-`) kinahanglan kanunay nga ipatik.
//! * `-` - Karon wala gigamit
//! * `#` - Gipakita sa kini nga bandila nga kinahanglan gamiton ang "alternate" nga porma sa pag-print.Ang mga puli nga porma mao ang:
//!     * `#?` - pretty-print ang [`Debug`] formatting
//!     * `#x` - nag-una ang lantugi sa usa ka `0x`
//!     * `#X` - nag-una ang lantugi sa usa ka `0x`
//!     * `#b` - nag-una ang lantugi sa usa ka `0b`
//!     * `#o` - nag-una ang lantugi sa usa ka `0o`
//! * `0` - Gigamit kini aron ipakita ang alang sa mga format sa integer nga ang padding sa `width` pareho nga kinahanglan buhaton sa usa ka `0` nga karakter ingon usab adunay pagkahibalo sa pag-sign.
//! Ang usa ka format sama sa `{:08}` maghatag `00000001` alang sa integer `1`, samtang ang parehas nga format maghatag `-0000001` alang sa integer `-1`.
//! Timan-i nga ang negatibo nga bersyon adunay usa nga mas dyutay kaysa sa positibo nga bersyon.
//!         Hinumdomi nga ang mga padding zeros kanunay gibutang pagkahuman sa karatula (kung adunay) ug sa wala pa ang mga digit.Kung gigamit kauban ang bandila nga `#`, adunay parehas nga lagda nga gigamit: ang mga padding zeros gisal-ot pagkahuman sa unahan apan sa wala pa ang mga digit.
//!         Ang prefiks gilakip sa tibuuk nga gilapdon.
//!
//! ## Precision
//!
//! Alang sa mga dili lahi nga numero, mahimo kini ikonsiderar nga "maximum width".
//! Kung ang sangputanan nga pisi mas taas kaysa sa kini nga gilapdon, nan kini maputol hangtod sa daghang mga kini nga karakter ug ang pinutol nga kantidad nga ibuga sa husto nga `fill`, `alignment` ug `width` kung ang mga parameter nga gitakda.
//!
//! Alang sa hinungdanon nga mga lahi, wala kini tagda.
//!
//! Alang sa mga lahi nga naglutaw-punto, gipakita niini kung pila ka mga digit pagkahuman sa decimal point ang kinahanglan i-print.
//!
//! Adunay tulo nga posible nga paagi aron mahibal-an ang gitinguha nga `precision`:
//!
//! 1. Usa ka integer `.N`:
//!
//!    ang integer `N` mismo mao ang katukma.
//!
//! 2. Usa ka integer o ngalan gisundan sa dolyar nga sign `.N$`:
//!
//!    gamita ang format *argument*`N` (nga kinahanglan usa ka `usize`) ingon ka eksakto.
//!
//! 3. Usa ka asterisk `.*`:
//!
//!    `.*` nagpasabut nga kini nga `{...}` adunay kalabutan sa *duha* nga mga input sa format kaysa usa: ang una nga input naghupot sa `usize` nga katukma, ug ang ikaduha naghupot sa kantidad aron ma-print.
//!    Mubo nga sulat nga sa niini nga kaso, kon ang usa migamit sa format hilo `{<arg>:<spec>.*}`, nan ang `<arg>` bahin nagtumong sa* bili * sa pag-imprinta, ug ang mga `precision` kinahanglan moabut sa input nga nag-una `<arg>`.
//!
//! Pananglitan, ang mosunud nga pagtawag sa tanan nga pag-print parehas nga butang nga `Hello x is 0.01000`:
//!
//! ```
//! // Kumusta {arg 0 ("x")} ang {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Kumusta {arg 1 ("x")} ang {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Kumusta {arg 0 ("x")} ang {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ang {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ang {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Kumusta {next arg ("x")} ang {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Samtang kini:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! i-print ang tulo nga magkalainlain nga mga butang:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Sa pila ka mga sinultian sa pagprograma, ang pamatasan sa mga gimbuhaton sa pag-format sa string nagsalig sa setting sa lugar sa operating system.
//! Ang mga pag-andar sa format nga gihatag sa sumbanan nga librarya sa Rust wala'y bisan unsang konsepto sa lokal ug maggama sa parehas nga mga sangputanan sa tanan nga mga sistema dili igsapayan ang pag-configure sa gumagamit.
//!
//! Pananglitan, ang mosunud nga kodigo kanunay mag-print `1.5` bisan kung ang lokal nga sistema naggamit usa ka decimal separator gawas sa us aka tuldok.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Ang literal nga mga karakter `{` ug `}` mahimong naglakip sa usa ka hilo pinaagi sa nag-unang kanila uban sa mao gihapon nga kinaiya.Pananglitan, ang karakter nga `{` nakaikyas nga adunay `{{` ug ang karakter nga `}` nakaikyas nga adunay `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Aron katingbanan, dinhi makit-an nimo ang bug-os nga gramatika sa mga pisi sa format.
//! Ang syntax alang sa gigamit nga sinultian sa pag-format gikuha gikan sa ubang mga sinultian, busa kinahanglan dili kini labi ka alien.Ang mga argumento gi-format sa sama sa syntax nga sama sa Python, nga nagpasabut nga ang mga lantugi gilibutan sa `{}` imbis sa C-like `%`.
//! Ang tinuud nga gramatika alang sa pag-format syntax mao ang:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Sa gramatika sa taas, ang `text` mahimong wala sulud bisan unsang `'{'` o `'}'` nga mga karakter.
//!
//! # Pag-format sa traits
//!
//! Kung naghangyo nga ang usa ka argumento ma-format sa usa ka piho nga tipo, sa tinuud naghangyo ka nga ang usa ka argumento nagpasabot sa usa ka partikular nga trait.
//! Gitugotan niini ang daghang mga tinuud nga lahi nga ma-format pinaagi sa `{:x}` (sama sa [`i8`] ingon man [`isize`]).Ang karon nga pagmapa sa mga tipo sa traits mao ang:
//!
//! * *wala* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] nga adunay mas gamay nga kaso nga hexadecimal integers
//! * `X?` ⇒ [`Debug`] nga adunay taas nga kaso nga hexadecimal integers
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ang gipasabut niini mao ang bisan unsang lahi sa lantugi nga nagpatuman sa [`fmt::Binary`][`Binary`] trait mahimo dayon ma-format sa `{:b}`.Ang mga pagpatuman gihatag alang sa mga traits alang sa usa ka ihap sa mga primitive nga tipo sa standard library usab.
//!
//! Kung wala gitino nga format (sama sa `{}` o `{:6}`), kung ingon niana ang gigamit nga format nga trait mao ang [`Display`] trait.
//!
//! Kung nagpatuman sa usa ka format nga trait alang sa imong kaugalingon nga tipo, kinahanglan nimo ipatuman ang usa ka pamaagi sa pirma:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ang among naandan nga tipo
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ang imong tipo ipasa ingon `self` by-reference, ug pagkahuman ang pagpaandar kinahanglan ibuga ang output sa `f.buf` stream.Naa sa matag format ang pagpatuman sa trait aron husto nga sundon ang gihangyo nga mga parameter sa pag-format.
//! Ang mga kantidad sa kini nga mga parameter malista sa mga natad sa [`Formatter`] struct.Aron matabangan kini, nagahatag usab ang [`Formatter`] nga istraktura pipila nga mga pamaagi sa pagtabang.
//!
//! Dugang pa, ang pagbalik bili sa niini nga function mao ang [`fmt::Result`] nga mao ang usa ka matang alyas sa [`Result`]`<(): [`std::Error`]`> `.
//! Ang mga pagpatuman sa pag-format kinahanglan nga masiguro nga sila nagpakaylap mga sayup gikan sa [`Formatter`] (pananglitan, sa pagtawag sa [`write!`]).
//! Bisan pa, dili gyud nila kinahanglan ibalik ang mga kasaypanan nga maabtik.
//! Kana mao, ang usa ka pagpatuman sa pag-format kinahanglan ug mahimo ra nga makabalik usa ka sayup kung ang nakapasar nga [`Formatter`] mobalik usa ka sayup.
//! Tungod kini, sukwahi sa mahimo isugyot sa pirma sa pag-andar, ang pag-format sa string usa ka dili masayup nga operasyon.
//! Ang pagpaandar ra niini mao ra ang nagbalik sa usa ka sangputanan tungod kay ang pagsulat sa nagpahiping sapa mahimong maglikay ug kinahanglan kini maghatag usa ka paagi aron mapakaylap ang kamatuuran nga adunay usa ka sayup nga nahimo nga pag-back up sa stack.
//!
//! Ang usa ka pananglitan sa pagpatuman sa pag-format sa traits sama sa:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Ang kantidad nga `f` nagpatuman sa `Write` trait, nga kung unsa ang gisulat!nagpaabut ang macro.
//!         // Hinumdomi nga ang kini nga pag-format wala magtagad sa lainlaing mga bandila nga gihatag sa mga pisi sa pormat.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ang lainlaing traits nagtugot sa lainlaing mga porma sa output sa usa ka lahi.
//! // Ang kahulogan sa format niini nga mao ang sa pag-imprinta sa kadako sa usa ka vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Igrespeto ang mga bandila sa pag-format pinaagi sa paggamit sa pamaagi sa helper `pad_integral` sa Formatter nga butang.
//!         // Tan-awa ang dokumentasyon sa pamaagi alang sa mga detalye, ug ang pagpaandar nga `pad` mahimong magamit sa mga pad string.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ang kini nga duha nga pag-format sa traits adunay managlahi nga katuyoan:
//!
//! - [`fmt::Display`][`Display`] gipatuman ang pagpatuman nga ang tipo mahimo nga matinud-anon nga girepresentar ingon usa ka UTF-8 string sa tanan nga mga oras.Wala kini ** gilauman nga ang tanan nga mga lahi nagpatuman sa [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] Ang pagpatuman kinahanglan ipatuman alang sa **tanan** nga publiko nga mga lahi.
//!   Ang output kasagarang magrepresentar sa sulud nga estado ingon matinuohon kutob sa mahimo.
//!   Ang katuyoan sa [`Debug`] trait aron mapadali ang pag-debug sa Rust code.Sa kadaghanan nga mga kaso, ang paggamit sa `#[derive(Debug)]` igo ug girekomenda.
//!
//! Ang pipila nga mga pananglitan sa output gikan sa pareho nga traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # May kalabutan nga macros
//!
//! Adunay usa ka ihap sa mga may kalabutan nga macros sa pamilyang [`format!`].Ang gipatuman karon mao ang:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Kini ug [`writeln!`] duha nga macros nga gigamit aron ibuga ang pormat nga pormat sa usa ka gipunting nga sapa.Kini gigamit sa pagpugong sa intermediate alokasyon sa mga kuldas format ug sa baylo direkta isulat ang output.
//! Sa ilalum sa hood, kini nga function sa tinuud nagsangpit sa [`write_fmt`] function nga gihubit sa [`std::io::Write`] trait.
//! Pananglitan sa paggamit mao ang:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Kini ug [`println!`] nagpagawas sa ilang output sa stdout.Sa susama sa [`write!`] macro, ang katuyoan sa mga macros nga likayan ang mga tunga nga gahin sa pag-imprinta sa output.Pananglitan sa paggamit mao ang:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ang [`eprint!`] ug [`eprintln!`] macros parehas sa [`print!`] ug [`println!`], matag usa, gawas sa ilang gibuga ang ilang output sa stderr.
//!
//! ### `format_args!`
//!
//! Kini usa ka makuryuso nga makro nga gigamit aron luwas nga maagian ang palibot sa usa ka opaque nga butang nga naglaragway sa format string.Ang kini nga butang wala magkinahanglan bisan unsang alokasyon nga tapok aron mugnaon, ug ang impormasyon ra niini ang gipunting sa stack.
//! Ubos sa hood, ang tanan nga mga may kalabutan nga macros gipatuman sa mga termino niini.
//! Una, pipila ka pananglitan nga paggamit mao ang:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Ang sangputanan sa [`format_args!`] macro usa ka kantidad sa tipo nga [`fmt::Arguments`].
//! Kini nga istraktura mahimong maipasa sa mga gimbuhaton nga [`write`] ug [`format`] sa sulud niini nga modyul aron maproseso ang format string.
//! Ang katuyoan sa kini nga makro aron labi pa nga mapugngan ang mga tunga nga alokasyon kung makig-atubang sa mga pormat sa pag-format.
//!
//! Pananglitan, ang usa ka library sa pag-log mahimong magamit ang sagad nga syntax sa pag-format, apan kini sa sulud moagi sa palibot sa kini nga istraktura hangtod mahibal-an kung asa kinahanglan moadto ang output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ang pagpaandar sa `format` nagkinahanglan usa ka [`Arguments`] nga istruktura ug gibalik ang sangputanan nga gi-format nga pisi.
///
///
/// Ang pananglitan sa [`Arguments`] mahimo og [`format_args!`] macro.
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Palihug hinumdomi nga ang paggamit sa [`format!`] mahimong labi ka gusto.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}