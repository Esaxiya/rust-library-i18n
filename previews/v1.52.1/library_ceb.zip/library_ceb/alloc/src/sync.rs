#![stable(feature = "rust1", since = "1.0.0")]

//! Mga panudlo sa pag-ihap sa hilisgutan nga luwas sa thread.
//!
//! Tan-awa ang dokumentasyon sa [`Arc<T>`][Arc] alang sa daghang mga detalye.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Usa ka malumo nga utlanan sa kantidad sa mga pakisayran nga mahimong mahimo sa usa ka `Arc`.
///
/// Ang pag-adto sa taas sa kini nga utlanan magwagtang sa imong programa (bisan kung dili kinahanglan) sa _exactly_ `MAX_REFCOUNT + 1` nga mga pakisayran.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Dili gisuportahan sa ThreadSanitizer ang mga koral sa memorya.
// Aron malikayan ang sayup nga positibo nga mga report sa Arc/Weak implementasyon gamita ang mga atomic load alang sa pagsabay.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Usa ka hilo-luwas nga pakisayran-ihap pointer.Ang 'Arc' nagpasabut sa 'Atomically Reference Counted'.
///
/// Ang matang `Arc<T>` naghatag mipakigbahin pagpanag-iya sa usa ka bili sa matang `T`, gigahin sa mohon.Ang pagsangpit sa [`clone`][clone] sa `Arc` naghimo usa ka bag-ong pananglitan sa `Arc`, nga nagpunting sa parehas nga alokasyon sa tinapok sama sa gigikanan nga `Arc`, samtang nagdugang ang usa ka ihap sa pakisayran.
/// Kung ang katapusan nga `Arc` pointer sa usa ka gihatag nga paggahin nadaot, ang kantidad nga gitipigan sa kanang alokasyon (kanunay nga gihisgutan nga "inner value") nahulog usab.
///
/// Ang gipaambit nga mga pakisayran sa Rust dili motugot sa pagbag-o pinaagi sa default, ug ang `Arc` wala`y gawas: dili ka sa kasagaran makakuha usa ka mabalhin nga pakisayran sa usa ka butang sa sulud sa `Arc`.Kung kinahanglan nimo nga mutate pinaagi sa `Arc`, gamita ang [`Mutex`][mutex], [`RwLock`][rwlock], o usa sa mga lahi nga [`Atomic`][atomic].
///
/// ## Higti Safety
///
/// Dili sama sa [`Rc<T>`], ang `Arc<T>` naggamit mga operasyon sa atomiko alang sa pag-ihap sa reperensiya.Kini nagpasabut nga kini luwas sa thread.Disbentaha mao nga atomic operasyon mas mahal pa kay sa ordinaryo nga handumanan accesses.Kung wala ka nag-ambitay nga mga alokasyon nga naihap sa pakigsulti taliwala sa mga sulud, hunahunaa ang paggamit sa [`Rc<T>`] alang sa labi ka gamay nga overhead.
/// [`Rc<T>`] usa ka luwas nga default, tungod kay ang tigkompuno makadakup sa bisan unsang pagsulay nga magpadala usa ka [`Rc<T>`] taliwala sa mga sulud.
/// Bisan pa, mahimong pilion sa usa ka librarya ang `Arc<T>` aron mahatagan ang labi nga kaarang ang mga tagpamalit sa librarya.
///
/// `Arc<T>` ipatuman ang [`Send`] ug [`Sync`] basta ang `T` nagpatuman sa [`Send`] ug [`Sync`].
/// Ngano nga dili nimo mahimo nga ibutang ang usa ka non-thread-safe nga type `T` sa usa ka `Arc<T>` aron mahimo kini nga luwas sa thread?Kini mahimo nga usa ka gamay nga kontra-intuitive sa una: pagkahuman sa tanan, dili ba ang punto sa kahilwasan sa `Arc<T>` thread?Ang yawi mao kini: gihimo sa `Arc<T>` nga luwas ang thread nga adunay daghang pagpanag-iya sa parehas nga datos, apan wala kini nagdugang kahilwasan sa thread sa datos niini.
///
/// Hunahunaa ang `Arc <` ['RefCell<T>`]`> `.
/// [`RefCell<T>`] dili [`Sync`], ug kung ang `Arc<T>` kanunay [`Send`], `Arc <` ['RefCell<T>`]`> `mahimo usab.
/// Apan pud kita adunay usa ka problema:
/// [`RefCell<T>`] dili luwas luwas;gisubay niini ang ihap sa pagpangutang gamit ang mga dili atomic nga operasyon.
///
/// Sa katapusan, kini nagpasabut nga tingali kinahanglan nimo ipares ang `Arc<T>` sa usa ka klase nga [`std::sync`] type, kasagaran [`Mutex<T>`][mutex].
///
/// ## Paglapas sa mga siklo nga adunay `Weak`
///
/// Ang pamaagi nga [`downgrade`][downgrade] mahimong magamit aron makahimo usa ka dili tag-iya nga [`Weak`] pointer.Ang usa ka [`Weak`] pointer mahimo nga [`pag-upgrade`][pag-upgrade] d sa usa ka `Arc`, apan kini ibalik ang [`None`] kung ang kantidad nga gitipig sa paggahin nahulog na.
/// Sa laing pagkasulti, ang `Weak` pointers dili magpadayon nga buhi ang kantidad sa sulud sa alokasyon;bisan pa, gipadayon nila * ang paggahin (ang backing store alang sa kantidad) nga buhi.
///
/// Ang usa ka siklo sa taliwala sa `Arc` pointers dili gyud mapakyas.
/// Tungod niini nga hinungdan, gigamit ang [`Weak`] aron masira ang mga siklo.Pananglitan, ang usa ka kahoy nga adunay lig-on `Arc` pointers gikan sa ginikanan binurotan ngadto sa mga anak, ug [`Weak`] pointers gikan sa mga bata balik sa ngadto sa ilang mga ginikanan.
///
/// # Mga pakisayran sa pag-clone
///
/// Ang paghimo sa usa ka bag-ong pakisayran gikan sa adunay na nga panudlo nga naihap sa pakisayran gihimo gamit ang `Clone` trait nga gipatuman alang sa [`Arc<T>`][Arc] ug [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ang duha nga mga syntax sa ubus managsama.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // Ang a, b, ug foo tanan nga mga Arcs nga nagtudlo sa parehas nga lokasyon sa memorya
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` awtomatikong dereferences sa `T` (pinaagi sa [`Deref`][deref] trait), mao nga kamo motawag `ni T` mga pamaagi sa usa ka bili sa matang `Arc<T>`.Aron malikayan ang mga bangga sa ngalan sa mga pamaagi sa `T`, ang mga pamaagi sa `Arc<T>` mismo adunay kalabotan nga mga gimbuhaton, gitawag nga gigamit ang [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Ang mga pagpatuman sa traits sama sa `Clone` mahimo usab tawgon gamit ang hingpit nga kwalipikado nga syntax.
/// Ang ubang mga tawo gusto sa paggamit sa bug-os nga mga kwalipikado nga syntax, samtang ang uban gusto sa paggamit sa pamaagi-tawag syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax sa tawag sa pamaagi
/// let arc2 = arc.clone();
/// // Hingpit nga kwalipikado nga syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] dili awtomatikong pag-undang sa `T`, tungod kay ang pagkahulog sa sulud mahimo nga nahulog.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Pagpakigbahin sa pila nga dili mabalhin nga datos taliwala sa mga sulud:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Hinumdomi nga dili namon ** gipadagan ang kini nga mga pagsulay dinhi.
// Ang windows magtutukod og super malipayon kon ang usa ka lugas nga hilo mamatay inigkamatay sa nag-unang nga hilo ug dayon mogawas sa samang higayon (usa ka butang deadlocks) aron kita lang sa paglikay niining bug-os pinaagi sa dili sa nagaagay nga niini nga mga pagsulay.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Pagpakigbahin usa ka mabalhin nga [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Kitaa ang [`rc` documentation][rc_examples] alang sa daghang mga pananglitan sa pag-ihap sa pakisayran sa kadaghanan.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` usa ka bersyon sa [`Arc`] nga adunay paghisgot nga dili pagpanag-iya sa gidumala nga paggahin.
/// Gi-access ang alokasyon pinaagi sa pagtawag sa [`upgrade`] sa `Weak` pointer, nga ningbalik usa ka ['Option`]`<`[`Arc`]`<T>> `.
///
/// Tungod kay ang usa ka pakisayran sa `Weak` dili maihap padulong sa pagpanag-iya, dili niini mapugngan ang kantidad nga gitipig sa alokasyon gikan sa pagkahulog, ug ang `Weak` mismo wala`y garantiya bahin sa kantidad nga naa pa.
///
/// Mao kini ang kini mobalik [`None`] sa diha nga [`upgrade`] d.
/// Hinuon hinumdomi nga ang usa ka pakisayran nga `Weak`*dili* nagpugong sa paggahin mismo (ang backing store) gikan sa pag-deallocated.
///
/// Usa ka `Weak` pointer mao ang mapuslanon alang sa pagtuman sa usa ka temporaryo nga paghisgot sa alokasyon nakahimo sa [`Arc`] nga walay pagpugong sa iyang sulod nga bili gikan sa nagpatulo sa.
/// Gigamit usab kini aron mapugngan ang mga lingin nga pakisayran taliwala sa mga pointers nga [`Arc`], tungod kay ang pagtag-iya sa us aka tag-iya nga mga pakisayran dili gyud tugotan nga mahulog ang bisan unsang [`Arc`].
/// Pananglitan, ang usa ka punoan mahimo`g adunay kusug nga [`Arc`] mga panudlo gikan sa mga node sa ginikanan ngadto sa mga anak, ug mga panudlo nga `Weak` gikan sa mga bata balik sa ilang mga ginikanan.
///
/// Ang kasagaran nga paagi aron makakuha usa ka `Weak` pointer mao ang pagtawag sa [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Kini usa ka `NonNull` aron tugotan ang pag-optimize sa gidak-on sa kini nga tipo sa mga enum, apan dili kini kinahanglan nga usa ka balido nga panudlo.
    //
    // `Weak::new` gitakda kini sa `usize::MAX` aron dili kinahanglan nga maghatag og wanang sa tapok.
    // Dili kana ang kantidad nga maangkon sa usa ka tinuud nga pointer tungod kay ang RcBox adunay pag-align labing menos 2.
    // Posible ra kini kung `T: Sized`;wala'y sukod ang `T` nga wala maglabad.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Kini ang repr(C) to future-proof batok sa posible nga pag-usab sa uma, nga makabalda sa kung luwas nga luwas nga [into|from]_raw() sa mga mabalhin nga mga sulud nga sulud.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // ang kantidad nga usize::MAX naglihok ingon usa ka sentinel alang sa temporaryo nga "locking" ang abilidad sa pag-upgrade sa mga huyang nga pointers o pag-downgrade sa mga kusog;gigamit kini aron malikayan ang mga karera sa `make_mut` ug `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Naghimo usa ka bag-ong `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Sugdi ang mahuyang nga ihap sa panudlo ingon 1 nga kung kinsa ang mahuyang nga tudlo nga gihuptan sa tanan nga kusgan nga mga tudlo nga (kinda), tan-awa ang std/rc.rs alang sa dugang nga impormasyon
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Naghimo usa ka bag-ong `Arc<T>` gamit ang usa ka mahuyang nga pakisayran sa kaugalingon.
    /// Ang pagsulay sa pag-upgrade sa mahuyang nga pakisayran sa wala pa mobalik kini nga pag-andar magresulta sa usa ka kantidad nga `None`.
    /// Bisan pa, ang mahuyang nga pakisayran mahimo nga libre nga ma-clone ug tipunan aron magamit sa ulahi nga panahon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Paghimo sa sulud sa estado nga "uninitialized" nga adunay us aka mahuyang nga pakisayran.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mahinungdanon nga dili namon biyaan ang pagpanag-iya sa mahuyang nga pahimangno, o kung dili ang memorya mahimo`g mapalaya sa oras nga mobalik ang `data_fn`.
        // Kon kita gusto nga moagi pagpanag-iya, mahimo kita paghimo sa usa ka dugang nga huyang nga pointer alang sa atong kaugalingon, apan kini moresulta sa dugang nga updates sa mga mahuyang ihap pakisayran nga dili mahimong gikinahanglan kon dili.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Karon mahimo natong mapangita ang husto nga sulud sa sulud ug himuon ang among mahuyang nga pakisayran nga usa ka kusganon nga pakisayran.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ang gisulat sa taas sa natad sa datos kinahanglan nga makita sa bisan unsang mga sulud nga nakamatikod sa usa ka dili zero nga kusog nga ihap.
            // Tungod niini kinahanglan namon ang labing menos nga "Release" nga pag-order aron ma-synchronize ang `compare_exchange_weak` sa `Weak::upgrade`.
            //
            // "Acquire" dili kinahanglan ang pag-order.
            // Kung gikonsiderar ang posible nga mga pamatasan sa `data_fn` kinahanglan ra namon nga tan-awon kung unsa ang mahimo niini sa usa ka pakisayran sa usa ka dili ma-upgrade nga `Weak`:
            //
            // - Mahimo kini *clone* ang `Weak`, pagdugang sa mahuyang nga ihap sa pakisayran.
            // - Mahimo niini ihulog ang mga clone, nga maminusan ang mahuyang nga ihap sa pakisayran (apan dili gyud ma-zero)
            //
            // Kini nga mga epekto wala mag-apektar sa amon sa bisan unsang paagi, ug wala`y uban pang mga epekto nga mahimo`g posible nga luwas ang code lang.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Lig-on nga mga pakisayran kinahanglan sa kinatibuk-iya sa usa ka mipakigbahin huyang nga reperensiya, mao nga dili modagan sa destructor alang sa atong daan nga mahuyang nga pakisayran.
        //
        mem::forget(weak);
        strong
    }

    /// Naghimo usa ka bag-ong `Arc` nga adunay uninitialized nga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Naghimo usa ka bag-ong `Arc` nga adunay uninitialized nga sulud, uban ang memorya nga napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Naghimo usa ka bag-ong `Pin<Arc<T>>`.
    /// Kung ang `T` wala ipatuman ang `Unpin`, kung ingon niana ang `data` ma-pin sa memorya ug dili mabalhin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Naghimo usa ka bag-ong `Arc<T>`, nagbalik usa ka sayup kung napakyas ang paggahin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Sugdi ang mahuyang nga ihap sa panudlo ingon 1 nga kung kinsa ang mahuyang nga tudlo nga gihuptan sa tanan nga kusgan nga mga tudlo nga (kinda), tan-awa ang std/rc.rs alang sa dugang nga impormasyon
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Naghimo usa ka bag-ong `Arc` nga adunay uninitialized nga sulud, ningbalik usa ka sayup kung napakyas ang paggahin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Naghimo usa ka bag-ong `Arc` nga adunay uninitialized nga sulud, uban ang memorya nga napuno sa `0` bytes, nga nagbalik usa ka sayup kung napakyas ang paggahin.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Gibalik ang sulud nga kantidad, kung ang `Arc` adunay eksaktong usa ka kusug nga pakisayran.
    ///
    /// Kung dili, ang usa ka [`Err`] gibalik nga adunay parehas nga `Arc` nga gipasa.
    ///
    ///
    /// Kini molampos bisan kung adunay mga talagsaon nga mahuyang nga pakisayran.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Paghimo usa ka mahuyang nga tudlo aron malimpyohan ang gipasabut nga kusganon nga huyang nga pakisayran
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Nagpatindog usa ka bag-ong hiyas nga giihap sa pag-ihap sa atomiko nga wala isulat ang mga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Nagpatindog usa ka bag-ong hiyas nga giihap sa pag-ihap sa atomiko nga wala isulat ang mga sulud, nga ang panumduman napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Nakabig sa `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang sulud nga kantidad naa gyud sa pasiunang estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Nakabig sa `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang sulud nga kantidad naa gyud sa pasiunang estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Natapos ang `Arc`, gibalik ang giputos nga pointer.
    ///
    /// Aron malikayan ang usa ka memory leak ang pointer kinahanglan nga ibalik sa usa ka `Arc` gamit ang [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Naghatag usa ka hilaw nga puntos sa datos.
    ///
    /// Ang mga ihap dili apektado sa bisan unsang paagi ug ang `Arc` dili mahurot.
    /// Ang panudlo balido hangtod nga adunay daghang ihap sa `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // KALUWASAN: Dili kini makaagi sa Deref::deref o RcBoxPtr::inner tungod kay
        // gikinahanglan kini aron mapadayon ang raw/mut nga pagpanan-aw ingon pananglit
        // `get_mut` makasulat pinaagi sa pointer pagkahuman makuha ang Rc pinaagi sa `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Naghimo usa ka `Arc<T>` gikan sa usa ka hilaw nga pahimangno.
    ///
    /// Ang hilaw nga pointer kinahanglan nga gibalik kaniadto sa usa ka tawag sa [`Arc<U>::into_raw`][into_raw] diin ang `U` kinahanglan adunay parehas nga gidak-on ug paghanay sa `T`.
    /// Kini gamay nga hinungdan kung ang `U` mao ang `T`.
    /// Hinumdomi nga kung ang `U` dili `T` apan adunay parehas nga kadako ug paghanay, kini sa panguna sama sa pagbalhin sa mga pakisayran sa lainlaing mga lahi.
    /// Tan-awa ang [`mem::transmute`][transmute] alang sa dugang nga kasayuran kung unsang mga pagdili ang magamit sa kini nga kaso.
    ///
    /// Kinahanglan nga masiguro sa naggamit sa `from_raw` usa ka piho nga kantidad nga `T` kausa ra nahulog.
    ///
    /// function Kini mao ang dili luwas tungod kay sayop nga paggamit mahimong mosangpot sa handumanan unsafety, bisan kon ang mibalik `Arc<T>` wala gayud Naablihan.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pag-usab balik sa usa ka `Arc` aron malikayan ang pagtulo.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ang dugang nga mga tawag sa `Arc::from_raw(x_ptr)` mahimong dili luwas sa memorya.
    /// }
    ///
    /// // handumanan sa gibuhian sa diha nga `x` migula sa kasangkaran sa ibabaw, mao nga `x_ptr` karon nagbitay!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Balihon ang offset aron makapangita ang orihinal nga ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Nagmugna sa usa ka bag-o nga [`Weak`] pointer sa alokasyon niini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // OK Kini nga Pagpapahulay tungod kay gisusi namon ang kantidad sa CAS sa ubos.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // check kon ang huyang nga counter karon "locked";kung mao, pagtuyok.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kini nga code karon wala magtagad sa posibilidad sa pag-awas
            // ngadto sa usize::MAX;sa kinatibuk-an parehas nga kinahanglan nga ipasibo ang Rc ug Arc aron maatubang ang pag-awas.
            //

            // Dili sama sa uban sa Clone(), kita kinahanglan nga kini mahimo nga usa ka Batoni ang pagbasa sa pagpahiangay sa uban sa isulat gikan sa `is_unique`, sa pagkaagi nga ang mga hitabo sa wala pa isulat nga mahitabo sa dili pa kini mabasa.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Siguruha nga dili kami maghimo usa ka nagbitay nga Luya
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Nakuha ang numero nga [`Weak`] nga mga panudlo sa kini nga paggahin.
    ///
    /// # Safety
    ///
    /// Ang kini nga pamaagi sa iyang kaugalingon luwas, apan ang paggamit niini sa tama nanginahanglan dugang nga pag-amping.
    /// Ang usa pa nga sulud mahimong mag-usab sa huyang nga pag-ihap sa bisan unsang oras, lakip ang posibilidad taliwala sa pagtawag sa kini nga pamaagi ug paglihok sa sangputanan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Kini nga pangatarungan mahibal-an tungod kay wala namon nabahin ang `Arc` o `Weak` taliwala sa mga sulud.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Kung ang mahuyang nga ihap karon naka-lock, ang kantidad sa ihap mao ang 0 sa wala pa kuhaa ang kandado.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Nakuha ang ihap sa kusgan nga mga panudlo nga (`Arc`) sa kini nga paggahin.
    ///
    /// # Safety
    ///
    /// Ang kini nga pamaagi sa iyang kaugalingon luwas, apan ang paggamit niini sa tama nanginahanglan dugang nga pag-amping.
    /// Ang usa pa nga sulud mahimong mag-usab sa kusganon nga pag-ihap sa bisan unsang oras, lakip ang posibilidad taliwala sa pagtawag sa kini nga pamaagi ug paglihok sa sangputanan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Kini nga pangatarungan mahibal-an tungod kay wala namon mapaambit ang `Arc` taliwala sa mga sulud.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Nagdugang ang kusganon nga ihap sa pakisayran sa `Arc<T>` nga adunay kalabotan sa gihatag nga puntos pinaagi sa usa.
    ///
    /// # Safety
    ///
    /// Kinahanglan nga makuha ang pointer pinaagi sa `Arc::into_raw`, ug ang kauban nga pananglitan sa `Arc` kinahanglan nga balido (ie
    /// ang kusug nga pag-ihap kinahanglan labing menos 1) alang sa gidugayon sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Kini nga pangatarungan mahibal-an tungod kay wala namon mapaambit ang `Arc` taliwala sa mga sulud.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Ipabilin ang Arc, apan ayaw paghikap sa refcount pinaagi sa pagputos sa ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Karon dugangi ang refcount, apan ayaw usab paghulog sa bag-ong refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ang mga pagbuut sa lig-on nga ihap sa pakisayran sa `Arc<T>` nga adunay kalabotan sa gihatag nga pointer usa.
    ///
    /// # Safety
    ///
    /// Kinahanglan nga makuha ang pointer pinaagi sa `Arc::into_raw`, ug ang kauban nga pananglitan sa `Arc` kinahanglan nga balido (ie
    /// ang kusug nga pag-ihap kinahanglan labing menos 1) kung gigamit kini nga pamaagi.
    /// Kini nga pamaagi mahimong gamiton sa pagpagawas sa katapusang `Arc` ug pagpaluyo storage, apan **dili** nga gitawag human sa katapusan nga `Arc` nga gipagawas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ang mga gipanghimatuud mahibal-an tungod kay wala namon nabahin ang `Arc` taliwala sa mga sulud.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ok kini nga kawalay kasigurohan tungod kay samtang buhi kini nga arko gigarantiyahan namon nga ang sulud nga pointer balido.
        // Dugang pa, nahibal-an namon nga ang istruktura nga `ArcInner` mismo mao ang `Sync` tungod kay ang sulud nga datos `Sync` usab, busa ok kami nga paghulam sa usa ka dili mabalhin nga tudlo sa kini nga mga sulud.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non-inlined bahin sa `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Gub-a ang datos sa kini nga oras, bisan kung dili namon mahimo nga libre ang alokasyon sa kahon mismo (mahimo pa nga adunay mga mahuyang nga panudlo nga naghigda).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Ihulog ang huyang nga ref nga kolektibong gihuptan sa tanan nga kusug nga mga pakisayran
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Gibalik ang `true` kung ang duha nga `Arc`s nagpunting sa parehas nga alokasyon (sa usa ka ugat nga parehas sa [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Naggahin sa usa ka `ArcInner<T>` nga adunay igong wanang alang sa usa ka posible nga wala gisulud nga sulud nga kantidad diin ang kantidad adunay gihatag nga layout.
    ///
    /// Ang pag-andar `mem_to_arcinner` gitawag uban ang data pointer ug kinahanglan ibalik ang usa ka (posible nga tambok)-paghatag alang sa `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Kalkula ang layout gamit ang gihatag nga layout sa kantidad.
        // Kaniadto, ang layout gikalkulo sa ekspresyon nga `&*(ptr as* const ArcInner<T>)`, apan naghimo kini usa ka sayup nga reperensiya (tan-awa ang #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Naggahin sa usa ka `ArcInner<T>` nga adunay igong wanang alang sa usa ka posible nga wala gisulud nga sulud nga kantidad diin ang kantidad adunay gihatag nga layout, nga nagbalik usa ka sayup kung napakyas ang paggahin.
    ///
    ///
    /// Ang pag-andar `mem_to_arcinner` gitawag uban ang data pointer ug kinahanglan ibalik ang usa ka (posible nga tambok)-paghatag alang sa `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Kalkula ang layout gamit ang gihatag nga layout sa kantidad.
        // Kaniadto, ang layout gikalkulo sa ekspresyon nga `&*(ptr as* const ArcInner<T>)`, apan naghimo kini usa ka sayup nga reperensiya (tan-awa ang #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Ig-una ang ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Naghatag sa usa ka `ArcInner<T>` nga adunay igong wanang alang sa usa ka wala`y sukod nga sulud nga kantidad.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Paghatag alang sa `ArcInner<T>` gamit ang gihatag nga kantidad.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopyaha ang kantidad ingon mga byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libre ang alokasyon nga dili ihulog ang sulud niini
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Naghatag usa ka `ArcInner<[T]>` nga adunay gihatag nga gitas-on.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopyaha ang mga elemento gikan sa hiwa sa bag-ong gigahin nga Arc <\[T\]>
    ///
    /// Dili luwas tungod kay ang nanawag kinahanglan manag-iya o magbugkos sa `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Naghimo usa ka `Arc<[T]>` gikan sa usa ka iterator nga nahibal-an nga adunay usa ka piho nga gidak-on.
    ///
    /// Dili matino ang kinaiya kung sayup ang sukod.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic nga guwardya samtang gi-clone ang mga elemento sa T.
        // Sa panghitabo sa usa ka panic, ang mga elemento nga gisulat sa bag-ong ArcInner ihulog, pagkahuman buhian ang memorya.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Itudlo ang una nga elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tin-aw ang tanan.Kalimtan ang guwardiya aron dili kini makalaya sa bag-ong ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Espesyalista nga trait gigamit alang sa `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Naghimo usa ka clone sa `Arc` pointer.
    ///
    /// Naghimo kini usa pa nga tudlo sa parehas nga alokasyon, nagdugang ang kusug nga ihap sa pakisayran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Maayo ang paggamit dinhi sa usa ka relaks nga pag-order, tungod kay ang kahibalo sa orihinal nga pakisayran nagpugong sa ubang mga sulud nga sayup nga gitangtang ang butang.
        //
        // Sama sa gipatin-aw sa [Boost documentation][1], Ang pagdugang sa referral nga counter kanunay mahimo nga gihimo sa memorya_order_relaxed: Ang mga bag-ong pakisayran sa usa ka butang mahimo ra maporma gikan sa usa ka na na nga pakisayran, ug ang pagpasa sa usa ka na nga pakisayran gikan sa usa ka sulud sa usa pa kinahanglan nga maghatag bisan unsang kinahanglanon nga paghiusa.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Bisan pa kinahanglan naton magbantay batok sa daghang mga refcount kung adunay us aka tawo nga `mem: : nakalimot` sa Arcs.
        // Kung dili naton kini buhaton maihap ang ihap ug ang mga mogamit mogamit pagkahuman nga libre.
        // Gisulud namon ang `isize::MAX` sa pangagpas nga wala'y ~2 bilyon nga mga thread nga nagdugang sa pag-ihap sa pakisayran sa usa ka higayon.
        //
        // Kini nga branch dili gyud makuha sa bisan unsang makatarunganon nga programa.
        //
        // Nag-abort kami tungod kay ang ingon nga programa grabe nga pagkadaut, ug wala kami igsapayan nga suportahan kini.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Naghimo sa usa ka mutable pakisayran ngadto sa gihatag `Arc`.
    ///
    /// Kung adunay uban nga mga panudlo nga `Arc` o [`Weak`] sa parehas nga paggahin, unya ang `make_mut` maghimo usa ka bag-ong alokasyon ug ipangayo ang [`clone`][clone] sa sulud nga kantidad aron masiguro ang talagsaon nga pagpanag-iya.
    /// Gitawag usab kini nga clone-on-sulat.
    ///
    /// Hinumdomi nga kini lahi sa pamatasan sa [`Rc::make_mut`] nga nagpalayo sa bisan unsang nahabilin nga mga panudlo nga `Weak`.
    ///
    /// Tan-awa usab ang [`get_mut`][get_mut], nga mapakyas kaysa pag-clone.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Dili ma-clone bisan unsa
    /// let mut other_data = Arc::clone(&data); // Dili ma-clone ang sulud nga datos
    /// *Arc::make_mut(&mut data) += 1;         // Pag-clone sa sulud nga datos
    /// *Arc::make_mut(&mut data) += 1;         // Dili ma-clone bisan unsa
    /// *Arc::make_mut(&mut other_data) *= 2;   // Dili ma-clone bisan unsa
    ///
    /// // Karon ang `data` ug `other_data` nagpunting sa lainlaing mga alokasyon.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Hinumdomi nga pareho kami nga adunay usa ka kusgan nga reperensya ug usa ka mahuyang nga pakisayran
        // Sa ingon, ang pagpagawas sa among kusug nga pakisayran dili ra, sa kaugalingon niini, hinungdan nga mabalhin ang memorya.
        //
        // Gamita ang Pagkuha aron maseguro nga makita namon ang bisan unsang pagsulat sa `weak` nga nahinabo sa wala pa buhian ang mga sulat (ie, decrement) hangtod sa `strong`.
        // Tungod kay kita naghupot sa usa ka huyang nga ihap, walay higayon sa ArcInner sa iyang kaugalingon mahimong deallocated.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Adunay usa pa nga kusgan nga tudlo nga adunay, busa kinahanglan naton i-clone.
            // Pauna nga gigahin ang panumduman aron direkta nga masulat ang cloned nga kantidad.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ang pagpahayahay igo na sa taas tungod kay kini sa panukaranan usa ka pag-optimize: kanunay kaming nagdagan nga nahulog ang mga mahuyang nga panudlo.
            // Pinakagrabe nga kaso, nahuman ang paggahin namon usa ka bag-ong Arc nga dili kinahanglan.
            //

            // Gikuha namon ang katapusang kusgan nga ref, apan adunay dugang nga mahuyang nga ref nga nahabilin.
            // Igbalhin namon ang mga sulud sa usa ka bag-ong Arc, ug ibalibad ang ubang mga mahuyang nga ref.
            //

            // Hinumdomi nga dili posible alang sa pagbasa sa `weak` nga maghatag usize::MAX (ie, naka-lock), tungod kay ang mahuyang nga ihap mahimo ra ma-lock sa usa ka sulud nga adunay kusug nga pakisayran.
            //
            //

            // Pag-materialize sa among kaugalingon nga gipakita nga huyang nga pointer, aron malimpyohan niini ang ArcInner kung gikinahanglan.
            //
            let _weak = Weak { ptr: this.ptr };

            // Mahimo ra kawaton ang datos, ang nahabilin ra mao ang Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Kami ra ang nag-usa nga pakisayran sa bisan unsang lahi;maibalik ang lig-on nga ihap sa ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Sama sa `get_mut()`, ang kawalay kasigurohan ok ra tungod kay ang among pakisayran talagsaon sa pagsugod, o nahimong usa sa pag-clone sa mga sulud.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Gibalik ang usa ka mabalhin nga pakisayran sa gihatag nga `Arc`, kung wala`y uban pang mga panudlo nga `Arc` o [`Weak`] sa parehas nga paggahin.
    ///
    ///
    /// Gibalik ang [`None`] kung dili, tungod kay dili kini luwas nga mutate ang usa nga gipaambit nga kantidad.
    ///
    /// Tan-awa usab ang [`make_mut`][make_mut], nga mahimo [`clone`][clone] sa sulud nga kantidad kung adunay uban pang mga panudlo.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ok kini nga kawalay kasigurohan tungod kay gigarantiyahan namon nga ang tudlo nga gibalik mao ra ang *tudlo* nga mahibalik sa T.
            // Ang among ihap sa pakisayran garantiya nga mahimong 1 sa kini nga punto, ug kinahanglan namon nga ang Arc mismo mahimong `mut`, busa gibalik namon ang posible nga reperensya sa sulud nga datos.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Nagbalik usa ka mabalhin nga pakisayran sa gihatag nga `Arc`, nga wala`y bisan unsang tseke.
    ///
    /// Tan-awa usab ang [`get_mut`], nga luwas ug angayan nga mga tseke.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ang bisan unsang uban pang mga `Arc` o [`Weak`] nga mga panudlo sa parehas nga paggahin dili kinahanglan nga tangtangon alang sa gidugayon sa nauli nga hulam.
    ///
    /// Kini ang hinungdan kung wala ang ingon nga mga panudlo, pananglitan pananglitan pagkahuman sa `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Nag-amping kami nga *dili* maghimo usa ka pakisayran nga naglangkob sa "count" nga mga natad, tungod kay kini alyas nga adunay dungan nga pag-access sa mga ihap sa pakisayran (pananglitan
        // ni `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tinoa kung kini ba ang talagsaon nga pakisayran (lakip ang mahuyang nga mga ref) sa nagpahiping datos.
    ///
    ///
    /// Hinumdomi nga kinahanglan niini ang pag-lock sa huyang nga ihap sa ref.
    fn is_unique(&mut self) -> bool {
        // i-lock ang mahuyang nga ihap sa pointer kung makita nga kami ang nag-inusara nga mahuyang nga tudlo sa pointer.
        //
        // Ang nakuha nga label dinhi nagsiguro sa usa ka nahinabo-sa wala pa ang bisan unsang pagsulat sa `strong` (sa partikular sa `Weak::upgrade`) sa wala pa ang decrement sa ihap sa `weak` (pinaagi sa `Weak::drop`, nga gigamit ang pagpagawas).
        // Kung ang gi-upgrade nga huyang nga ref wala gyud gihulog, ang CAS dinhi mapakyas mao nga wala kami igsapayan nga magkasabay.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Kinahanglan kini usa ka `Acquire` aron magkasabay sa pagkunhod sa `strong` counter sa `drop`-ang pag-access ra nga mahitabo kung adunay apan ang katapusang reperensiya nahulog.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ang pagpagawas nga pagsulat dinhi nagsabay sa pagbasa sa `downgrade`, nga epektibo nga nagpugong sa gibasa sa itaas nga `strong` gikan sa pagkahuman pagkahuman sa pagsulat.
            //
            //
            self.inner().weak.store(1, Release); // buhian ang kandado
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Gitulo ang `Arc`.
    ///
    /// Pagminusan niini ang kusug nga ihap sa pakisayran.
    /// Kung ang kusganon nga ihap sa pakisayran naabot sa zero unya ang uban ra nga mga pakisayran (kung adunay) mao ang [`Weak`], busa `drop` namon ang sulud nga kantidad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Wala`y bisan unsang giimprinta
    /// drop(foo2);   // Mga print "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Tungod kay `fetch_sub` na atomic, dili kita kinahanglan nga mosibo sa ubang mga hilo gawas kon kita moadto sa panas sa butang.
        // Ang parehas nga lohika nga gigamit sa ubos nga `fetch_sub` sa ihap sa `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // koral Kini ang gikinahanglan aron sa pagpugong sa reordering sa paggamit sa mga data ug sa pagtangtang sa mga data.
        // Tungod kay kini nagtimaan `Release`, ang pagkunhod sa mga pakisayran ihap synchronizes uban sa niini nga `Acquire` koral.
        // Kini paagi nga ang paggamit sa mga data mahitabo sa dili pa pagkunhod sa paghisgot ihap, nga mahitabo sa wala pa kini koral, nga mahitabo sa atubangan sa pagtangtang sa mga data.
        //
        // Ingon sa gipatin-aw sa [Boost documentation][1],
        //
        // > Kini mao ang importante sa pagpatuman sa bisan unsa nga posible nga access sa butang sa usa ka
        // > hilo (pinaagi sa usa ka adunay na pakisayran) aron * mahitabo sa wala pa ang pagtangtang
        // > ang butang sa usa ka lahi nga sulud.Kini nakab-ot sa usa ka "release"
        // > operasyon pagkahuman ihulog usa ka pakisayran (bisan unsang pag-access sa butang
        // > pinaagi sa kini nga pakisayran kinahanglan klaro nga nahitabo kaniadto), ug an
        // > "acquire" operasyon sa wala pa pagtangtang sa butang.
        //
        // Sa partikular, samtang ang sulud sa usa ka Arc kasagaran dili mabalhin, posible nga adunay sulud nga sulatan sa usa ka butang sama sa usa ka Mutex<T>.
        // Tungod kay ang usa ka Mutex wala makuha kung kini gitangtang, dili kami makasalig sa lohika sa pag-synchronize aron makahimo pagsulat sa sulud nga Usa nga makita sa usa ka destructor nga nagdagan sa sulud nga B.
        //
        //
        // Hinumdomi usab nga ang koral nga Naangkon dinhi mahimo nga pulihan sa usa ka Pagkuha nga lulan, nga makapaayo sa paghimo sa mga sitwasyon nga labi ka pag-indigay.Kitaa ang [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Gisulayan nga ipaubus ang `Arc<dyn Any + Send + Sync>` sa usa ka konkreto nga tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Naghimo usa ka bag-ong `Weak<T>`, nga wala paggahin bisan unsang memorya.
    /// Ang pagtawag sa [`upgrade`] sa pagbalik nga kantidad kanunay naghatag [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Magtatabang type sa pagtugot sa access sa mga pakisayran importante nga walay mga pag bisan unsa nga pangangkon mahitungod sa kapatagan data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Gibalik ang usa ka hilaw nga panudlo sa butang nga `T` nga gitudlo sa kini nga `Weak<T>`.
    ///
    /// Ang panudlo balido ra kung adunay pila ka kusug nga pakisayran.
    /// Ang pointer mahimo nga nagbitay, dili nakahanay o bisan [`null`] kung dili.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Parehas nga nagtudlo sa parehas nga butang
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ang kusgan dinhi nagbuhi niini, mao nga mahimo naton nga ma-access ang butang.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Apan dili na.
    /// // Mahimo naton ang weak.as_ptr(), apan ang pag-access sa pointer mosangput sa wala matino nga pamatasan.
    /// // assert_eq! ("hello", dili luwas {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kung ang pointer nagbitay, ibalik namon ang sentinel direkta.
            // Dili kini mahimo nga usa ka balido nga adres sa payload, tungod kay ang payload labing menos nga nakahanay ingon sa ArcInner (usize).
            ptr as *const T
        } else {
            // KALUWASAN: kung ang_dangling mobalik nga bakak, nan ang tudlo dili madaut.
            // Ang payload mahimong ihulog sa kini nga punto, ug kinahanglan namon ipadayon ang pagkamatuud, busa gamiton ang hilaw nga pagmaniobra sa pointer.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Gikonsumo ang `Weak<T>` ug gihimo kini nga usa ka hilaw nga puntos.
    ///
    /// Gibalhin niini ang mahuyang nga pahimangno ngadto sa usa ka hilaw nga pahimangno, samtang gipadayon pa ang pagpanag-iya sa usa ka mahuyang nga pakisayran (ang mahuyang nga ihap dili gibag-o sa kini nga operasyon).
    /// Mahimo kini ibalik sa `Weak<T>` nga adunay [`from_raw`].
    ///
    /// Ang parehas nga mga pagdili sa pag-access sa target sa pointer ingon sa [`as_ptr`] magamit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Gikabig ang usa ka hilaw nga pahimangno kaniadto nga gihimo sa [`into_raw`] balik sa `Weak<T>`.
    ///
    /// Mahimo kini gamiton aron luwas makuha ang usa ka kusgan nga pakisayran (pinaagi sa pagtawag sa [`upgrade`] sa ulahi) o aron mabalhin ang huyang nga ihap pinaagi sa paghulog sa `Weak<T>`.
    ///
    /// Gikinahanglan ang pagpanag-iya sa us aka mahuyang nga pakisayran (gawas sa mga panudlo nga gihimo sa [`new`], tungod kay wala`y kini bisan unsa; ang pamaagi molihok pa usab sa kanila).
    ///
    /// # Safety
    ///
    /// Ang pointer kinahanglan nga naggikan sa [`into_raw`] ug kinahanglan nga tag-iya usab ang potensyal nga mahuyang nga pakisayran niini.
    ///
    /// Gitugotan ang kusog nga ihap nga 0 sa oras nga pagtawag niini.
    /// Bisan pa niana, kini nagkinahanglan pagpanag-iya sa usa ka huyang nga paghisgot karon girepresentahan ingon sa usa ka hilaw nga pointer (sa mga mahuyang ihap dili giusab pinaagi sa operasyon niini) ug busa kini kinahanglan nga gikauban sa usa ka miaging tawag sa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Pagkunhod sa katapusan nga mahuyang nga ihap.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tan-awa ang Weak::as_ptr alang sa konteksto kung giunsa makuha ang input pointer.

        let ptr = if is_dangling(ptr as *mut T) {
            // Kini usa ka nagbitay nga Luya.
            ptr as *mut ArcInner<T>
        } else {
            // Kung dili man, gigarantiyahan namon nga ang pointer naggikan sa usa ka wala`y katapusan nga Hinay.
            // KALUWASAN: ang data_offset luwas tawgon, tungod kay ang mga ptr nagpasabut usa ka tinuud (mahimo nga nahulog) T.
            let offset = unsafe { data_offset(ptr) };
            // Sa ingon, gibaliktad namon ang offset aron makuha ang tibuuk nga RcBox.
            // KALUWASAN: ang pointer naggikan sa usa ka Maluya, busa kini nga offset luwas.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: kita karon nabawi ang orihinal nga Huyang pointer, aron sa pagmugna sa Huyang.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Mga pagsulay sa pag-upgrade sa `Weak` pointer sa usa ka [`Arc`], pagpalangan sa paghulog sa sulud nga kantidad kung malampuson.
    ///
    ///
    /// Gibalik ang [`None`] kung ang sulud nga kantidad nahulog na.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Gub-a ang tanan nga kusgan nga mga panudlo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Gigamit namon ang usa ka CAS loop aron madugangan ang kusug nga ihap imbis nga usa ka fetch_add tungod kay ang kini nga pag-andar dili gyud kuhaon ang ihap sa pakisayran gikan sa zero ngadto sa usa.
        //
        //
        let inner = self.inner()?;

        // Ang nagpahayahay nga pag-load tungod kay ang bisan unsang pagsulat sa 0 nga mahimo namong maobserbahan nga mobiya sa uma sa usa ka permanente nga estado nga zero (mao nga ang "stale" nga pagbasa sa 0 maayo), ug bisan unsang uban pang kantidad nga gikumpirma pinaagi sa CAS sa ubos.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Kitaa ang mga komentaryo sa `Arc::clone` kung ngano nga gibuhat namon kini (alang sa `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Maayo ang pagpahulay alang sa kaso sa pagkapakyas tungod kay wala kami bisan unsa nga gilauman bahin sa bag-ong estado.
            // Kinahanglan ang pagbaton aron ang kaso sa kalampusan aron magdungan sa `Arc::new_cyclic`, kung ang pasiunang kantidad mahimo`g mapasugod pagkahuman nga gihimo ang mga pakisayran sa `Weak`.
            // Sa kana nga kaso, gilauman namon nga maobserbahan ang hingpit nga napatik nga kantidad.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // wala gisusi sa taas
                Err(old) => n = old,
            }
        }
    }

    /// Nakuha ang numero sa kusgan nga mga panudlo nga (`Arc`) nga nagtudlo sa kini nga paggahin.
    ///
    /// Kung ang `self` gihimo gamit ang [`Weak::new`], ibalik niini ang 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Nakakuha og usa ka pagbana-bana sa gidaghanon sa mga `Weak` pointers nga nagtudlo sa kini nga paggahin.
    ///
    /// Kon `self` gilalang sa paggamit [`Weak::new`], o kon walay mga pagpabiling lig-on pointers, kini mobalik 0.
    ///
    /// # Accuracy
    ///
    /// Tungod sa mga detalye sa pagpatuman, ang gibalik nga kantidad mahimo nga off sa 1 sa bisan diin nga direksyon kung ang ubang mga sulud nagmaniobra sa bisan unsang mga `Arc` o`Weak`s nga nagtudlo sa parehas nga alokasyon.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Tungod kay kita naobserbahan nga may labing menos usa ka lig-on nga pointer human sa pagbasa sa mga mahuyang ihap, kita nasayud nga ang bug-os nga maluya nga pakisayran (karon sa matag higayon nga sa bisan unsa nga lig-on nga mga pakisayran nga mga buhi) pa gihapon sa palibot sa dihang among naobserbahan sa mga mahuyang ihap, ug busa luwas nga kuhaan niini.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Gibalik ang `None` kung ang pointer nagbitay ug wala gigahin nga `ArcInner`, (ie, kaniadtong `Weak` gihimo sa `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Nag-amping kami nga *dili* maghimo usa ka pakisayran nga naglangkob sa "data" nga natad, tungod kay ang umahan mahimo nga mutate dungan (pananglitan, kung ang katapusan nga `Arc` nahulog, ang natad sa datos mahulog sa lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Gibalik ang `true` kung ang duha nga `Weak` nagtudlo sa parehas nga alokasyon (parehas sa [`ptr::eq`]), o kung pareho nga wala magtudlo sa bisan unsang alokasyon (tungod kay gihimo kini nga `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Tungod kay gitandi niini ang mga panudlo nagpasabut kini nga ang `Weak::new()` managsama sa matag usa, bisan kung wala nila itudlo ang bisan unsang alokasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Pagtandi sa `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Naghimo usa ka clone sa `Weak` pointer nga nagtudlo sa parehas nga gahin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Kitaa ang mga komento sa Arc::clone() kung ngano nga kini relaks.
        // Kini makahimo sa paggamit sa usa ka fetch_add (wala magtagad sa lock) tungod kay ang huyang nga ihap lamang giyawihan diin *walay laing* huyang nga mga tambag sa paglungtad.
        //
        // (Mao nga dili namon mapadagan kini nga code sa kana nga kaso).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Kitaa ang mga komentaryo sa Arc::clone() kung ngano nga gibuhat namon kini (alang sa mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Naghimo usa ka bag-ong `Weak<T>`, nga wala paggahin panumduman.
    /// Ang pagtawag sa [`upgrade`] sa pagbalik nga kantidad kanunay naghatag [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Gitulo ang `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Wala`y bisan unsang giimprinta
    /// drop(foo);        // Mga print "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Kung nahibal-an naton nga kita ang katapusang mahuyang nga pahimangno, kung ingon niini ang oras aron hingpit nga makalihok ang datos.Kitaa ang diskusyon sa Arc::drop() bahin sa mga pag-order sa memorya
        //
        // Kini dili nga gikinahanglan sa pagsusi alang sa giyawihan estado dinhi, tungod kay ang mga mahuyang ihap lamang giyawihan kon may tukma sa usa ka huyang nga ref, nga nagpasabot nga drop lamang sunod modagan SA nga ang pagpabiling huyang nga ref, nga mahimo lamang mahitabo human sa lock ang gipagawas.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Gihimo namon kini nga pagdadalubhasa dinhi, ug dili ingon usa ka labi ka kadaghanan nga pag-optimize sa `&T`, tungod kay kung dili kini makadugang usa ka gasto sa tanan nga mga pagsusi sa pagkaparehas sa mga ref
/// Giingon namon nga ang `Arc`s gigamit sa pagtipig daghang mga kantidad, nga hinay nga i-clone, apan mabug-at usab aron masusi kung parehas, hinungdan nga dali ning mabayran ang gasto.
///
/// Kini usab nga mas lagmit nga adunay duha ka `Arc` clones, nga punto sa sa mao gihapon nga bili, kay sa duha ka `&T`s.
///
/// Mahimo ra naton kini kung ang `T: Eq` ingon usa ka `PartialEq` mahimong tinuyo nga dili molihok.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Pagkaparehas alang sa duha ka `Arc`s.
    ///
    /// Duha ka `Arc`s patas kon ang ilang sulod nga mga mithi managsama, bisan kon sila gitipigan sa lain-laing mga alokasyon.
    ///
    /// Kon `T` usab implementar `Eq` (nga nagpasabot reflexivity sa pagkasama), duha ka `Arc`s nga punto sa sa mao gihapon nga alokasyon mao ang kanunay nga managsama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Kaangayan alang sa duha ka `Arc`s.
    ///
    /// Duha ka `Arc` ang dili managsama kung ang sulud nga mga kantidad dili parehas.
    ///
    /// Kon `T` usab implementar `Eq` (nga nagpasabot reflexivity sa pagkasama), duha ka `Arc`s nga punto sa sa mao gihapon nga bili mao ang dili gayud managsama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Bahag nga pagtandi alang sa duha nga `Arc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `partial_cmp()` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mas gamay kaysa pagtandi alang sa duha nga `Arc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `<` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Mas gamay pa o katumbas sa' pagtandi alang sa duha nga `Arc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `<=` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Labing kadako nga pagtandi alang sa duha nga `Arc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `>` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Labaw sa o katumbas sa' pagtandi alang sa duha nga `Arc`.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `>=` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Pagtandi alang sa duha nga `Arc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `cmp()` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Naghimo usa ka bag-ong `Arc<T>`, nga adunay kantidad nga `Default` alang sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Paghatag usa ka hiwa nga naihap sa pakisayran ug pun-a kini pinaagi sa pag-clone sa mga item sa 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Paggahin og usa ka pakisayran-giisip `str` ug pagkopya `v` ngadto sa niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Paggahin og usa ka pakisayran-giisip `str` ug pagkopya `v` ngadto sa niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Pagbalhin sa usa ka kahon nga butang sa usa ka bag-o, alokasyon nga naihap sa pakisayran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Paghatag usa ka hiwa nga naihap sa pakisayran ug ibalhin ang mga butang sa `v` ngadto niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Tugoti ang Vec nga buhian ang memorya niini, apan dili gub-a ang mga sulud niini
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Gikuha ang matag elemento sa `Iterator` ug gikolekta kini sa usa ka `Arc<[T]>`.
    ///
    /// # Mga kinaiya sa paghimo
    ///
    /// ## Ang kinatibuk-ang kaso
    ///
    /// Sa kinatibuk-ang kaso, ang pagpangolekta ngadto sa `Arc<[T]>` ang gihimo sa unang pagkolekta ngadto sa usa ka `Vec<T>`.Kana kung nagsulat sa mosunud:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ninglihok kini ingon kung nagsulat kami:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ang una nga hugpong sa mga paggahin mahitabo dinhi.
    ///     .into(); // Ang ikaduha nga paggahin alang sa `Arc<[T]>` mahitabo dinhi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Gigahin kini kutob sa kinahanglanon alang sa pagtukod sa `Vec<T>` ug pagkahuman igahin kini makausa alang sa paghimo sa `Vec<T>` ngadto sa `Arc<[T]>`.
    ///
    ///
    /// ## Iterator nga nahibal-an ang gitas-on
    ///
    /// Kung ang imong `Iterator` nagpatuman sa `TrustedLen` ug usa ka eksaktong sukat, usa ka alokasyon ang himuon alang sa `Arc<[T]>`.Pananglitan:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Usa ra nga alokasyon ang nahinabo dinhi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Ang espesyalista nga trait gigamit alang sa pagkolekta sa `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Kini ang kaso alang sa usa ka `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Kita kinahanglan aron sa pagsiguro nga ang iterator adunay usa ka tukma nga gitas-on ug kita adunay.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Mobalik sa normal nga pagpatuman.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kuhaa ang offset sa sulud sa usa ka `ArcInner` alang sa payload sa likod sa usa ka pointer.
///
/// # Safety
///
/// Ang tudlo kinahanglan magtudlo sa (ug adunay balido nga metadata alang) us aka una nga balido nga pananglitan sa T, apan ang T gitugotan nga ihulog.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ihanay ang wala`y sukod nga kantidad hangtod sa katapusan sa ArcInner.
    // Tungod kay ang RcBox mao ang repr(C), kanunay kini ang katapusan nga natad sa memorya.
    // KALUWASAN: tungod kay ang mahimo ra nga wala`y kadako nga mga lahi nga mahimo mao ang mga hiwa, trait nga mga butang,
    // ug extern matang, ang input sa kaluwasan kinahanglanon mao karon igo sa pagtagbaw sa mga gikinahanglan sa align_of_val_raw;kini usa ka detalye sa pagpatuman sa sinultian nga mahimong dili masaligan sa gawas sa std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}