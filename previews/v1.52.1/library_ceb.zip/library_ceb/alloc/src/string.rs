//! Usa ka UTF-8 - nga naka-encode, mapatubo nga lubid.
//!
//! Ang modyul adunay sulud nga [`String`] nga tipo, ang [`ToString`] trait alang sa pagkabig sa mga lubid, ug daghang mga lahi sa sayup nga mahimong sangputanan gikan sa pagtrabaho kauban ang [`String`] s.
//!
//!
//! # Examples
//!
//! Adunay daghang mga paagi aron makahimo usa ka bag-ong [`String`] gikan sa usa ka string nga literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! kamo makahimo sa paghimo sa usa ka bag-o nga [`String`] gikan sa usa ka kasamtangan nga sa usa ka pinaagi sa concatenating sa
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Kung adunay ka usa ka vector nga balido nga UTF-8 bytes, mahimo ka makagawas usa ka [`String`].Mahimo usab nimo ang baliktad.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Nahibal-an namon nga kini nga mga byte balido, busa gamiton namon ang `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Usa ka UTF-8 - nga naka-encode, mapatubo nga lubid.
///
/// Ang tipo nga `String` mao ang kasagaran nga tipo sa pisi nga adunay tag-iya sa mga sulud sa sulud.Kini adunay suod nga relasyon sa gihulam nga katugbang niini, ang primitive [`str`].
///
/// # Examples
///
/// Makahimo ka usa ka `String` gikan sa [a literal string][`str`] nga adunay [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Mahimo nimo idugtong ang usa ka [`char`] sa usa ka `String` nga adunay pamaagi nga [`push`], ug idugang ang usa ka [`&str`] sa pamaagi nga [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Kung adunay ka vector nga UTF-8 bytes, makahimo ka usa ka `String` gikan niini gamit ang [`from_utf8`] nga pamaagi:
///
/// ```
/// // pipila ka mga byte, sa usa ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nahibal-an namon nga kini nga mga byte balido, busa gamiton namon ang `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Ang `string` kanunay adunay balido nga UTF-8.Adunay kini pipila nga mga implikasyon, ang una niini kung kinahanglan nimo ang usa nga dili UTF-8 nga pisi, hunahunaa ang [`OsString`].Kini parehas, apan kung wala ang UTF-8 pagpugong.Ang ikaduha nga gipasabut mao nga dili ka mahimo`g indeks sa usa ka `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Gilaraw ang pag-index aron mahimong usa ka kanunay nga operasyon sa oras, apan ang UTF-8 nga pag-encode dili magtugot nga mahimo namon kini.Dugang pa, dili kini tin-aw kung unsang lahi nga butang ang kinahanglan ibalik sa indeks: usa ka byte, usa ka codepoint, o usa ka grapheme cluster.
/// Ang mga pamaagi nga [`bytes`] ug [`chars`] ibalik ang mga iterator sa nahauna nga duha, matag usa.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Ang 'String`nagpatuman sa [`Deref`]`<Target=str>`, ug busa mapanunod ang tanan nga mga pamaagi sa [` str`].Dugang pa, kini nga paagi nga kamo makahimo sa moagi sa usa ka `String` sa usa ka function nga nagkinahanglan og usa ka [`&str`] pinaagi sa paggamit sa usa ka ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Maghimo kini usa ka [`&str`] gikan sa `String` ug ipasa kini. Kini nga pagkakabig dili kaayo mahal, ug sa ingon sa kadaghanan, ang mga gimbuhaton modawat sa [`&str`] s ingon mga argumento gawas kung kinahanglan nila ang `String` sa pipila ka piho nga hinungdan.
///
/// Sa piho nga mga kaso ang Rust wala`y igo nga kasayuran aron mahimo kini nga pagkakabig, nga naila nga pagpugos sa [`Deref`].Sa mosunud nga pananglitan ang usa ka string slice [`&'a str`][`&str`] nagpatuman sa trait `TraitExample`, ug ang function `example_func` nagkuha bisan unsa nga nagpatuman sa trait.
/// Sa kini nga kaso ang Rust kinahanglan nga maghimo duha nga implicit nga pagkakabig, diin wala`y mahimo ang Rust.
/// Tungod niana nga hinungdan, ang mosunud nga panig-ingnan dili magtipon.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Adunay duha nga kapilian nga molihok hinoon.Ang unang nga sa pag-usab sa linya sa `example_func(&example_string);` sa `example_func(example_string.as_str());`, sa paggamit sa mga pamaagi [`as_str()`] sa tin-aw nga kinuha sa pisi ad-ad nga adunay sulod sa pisi.
/// Ang ikaduha nga paagi nagbag-o sa `example_func(&example_string);` ngadto sa `example_func(&*example_string);`.
/// Sa kini nga kaso, gipagawas namon ang `String` sa usa ka [`str`][`&str`], pagkahuman gipunting ang [`str`][`&str`] balik sa [`&str`].
/// Ang ikaduhang paagi labi ka idiomatiko, bisan pa parehas nga molihok aron tin-aw nga himuon ang pagkakabig kaysa pagsalig sa implisit nga pagkakabig.
///
/// # Representation
///
/// Ang usa ka `String` gilangkuban sa tulo nga mga sangkap: usa ka pointer sa pipila ka mga byte, usa ka gitas-on, ug usa ka kapasidad.Ang puntero nagpunting sa usa ka sulud nga buffer nga gigamit sa `String` aron tipigan ang datos niini.gitas-on mao ang gidaghanon sa mga bytes karon gitipigan sa buffer, ug ang kapasidad mao ang gidak-on sa buffer sa bytes.
///
/// Ingon niana, ang gitas-on kanunay nga dili kaayo o katumbas sa kapasidad.
///
/// Kini nga buffer kanunay gitipig sa tinapok.
///
/// Mahimo nimo kini tan-awon sa mga pamaagi nga [`as_ptr`], [`len`], ug [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME I-update kini kung ang stabil nga vector_into_raw_parts
/// // Pugong nga awtomatikong ihulog ang datos sa String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // istorya adunay napulog siyam ka byte
/// assert_eq!(19, len);
///
/// // Mahimo namon nga tukuron usab ang usa ka String nga wala sa ptr, len, ug kapasidad.
/// // Dili kini luwas tungod kay responsable kita sa pagsiguro nga ang mga sangkap husto:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Kung ang usa ka `String` adunay igo nga kapasidad, ang pagdugang mga elemento dili kini igahin usab.Pananglitan, hunahunaa kini nga programa:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Kini ang mogawas sa mosunud:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Sa una, wala kami bisan usa nga panumduman nga gigahin, apan sa among pagdugang sa hilo, gipadako niini ang angay nga katakus.Kung gamiton hinoon namon ang [`with_capacity`] nga pamaagi aron igahin ang husto nga kapasidad sa una:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Nagtapos kami uban ang lainlaing output:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Dinhi, dili kinahanglan nga mogahin dugang nga panumduman sa sulud sa loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Usa ka posible nga sayop nga bili sa dihang pagkabig sa usa ka `String` gikan sa usa ka UTF-8 Byte vector.
///
/// Kini nga tipo mao ang tipo sa sayup alang sa [`from_utf8`] nga pamaagi sa [`String`].
/// Gidisenyo kini sa us aka paagi aron maampingong malikayan ang mga reallocation: ang pamaagi nga [`into_bytes`] ibalik ang byte vector nga gigamit sa pagsulay sa pagkakabig.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Ang [`Utf8Error`] matang nga gihatag sa [`std::str`] nagrepresentar sa usa ka sayup nga mahitabo sa diha nga ang pagkabig sa usa ka ad-ad sa [`u8`] sa ngadto sa usa ka [`&str`].
/// Niini nga pagsabut, kini usa ka analogue sa `FromUtf8Error`, ug mahimo ka makakuha usa gikan sa `FromUtf8Error` pinaagi sa [`utf8_error`] nga pamaagi.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// // ang pipila dili balido nga mga byte, sa usa ka vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Usa ka posible nga kantidad sa sayup kung gibag-o ang usa ka `String` gikan sa usa ka UTF-16 byte slice.
///
/// Kini nga tipo mao ang tipo sa sayup alang sa [`from_utf16`] nga pamaagi sa [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Naghimo usa ka bag-ong walay sulod nga `String`.
    ///
    /// Tungod kay ang `String` wala`y sulod, dili kini igahin ang bisan unsang inisyal nga buffer.Samtang kini nagpasabut nga kini nga inisyal nga operasyon dili mahal, mahimo kini hinungdan sa sobra nga paggahin sa ulahi kung magdugang ka datos.
    ///
    /// Kung adunay ka ideya kung unsang datos ang gihuptan sa `String`, hunahunaa ang pamaagi nga [`with_capacity`] aron mapugngan ang sobra nga paggahin usab.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Naghimo usa ka bag-ong walay sulod nga `String` nga adunay usa ka partikular nga kapasidad.
    ///
    /// Ang `String` adunay sulud nga buffer aron mapugngan ang ilang datos.
    /// Ang kapasidad mao ang gitas-on sa kana nga buffer, ug mahimong mapangutana sa pamaagi nga [`capacity`].
    /// Kini nga pamaagi nagmugna sa usa ka walay sulod nga `String`, apan usa uban sa usa ka inisyal nga buffer nga naghupot `capacity` bytes.
    /// Kini mapuslanon kung mahimo nimo idugang ang usa ka hugpong nga datos sa `String`, nga minusan ang gidaghanon sa mga reallocation nga kinahanglan niini buhaton.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Kung ang gihatag nga kapasidad mao ang `0`, wala`y paggahin nga mahitabo, ug kini nga pamaagi parehas sa pamaagi nga [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Ang String walay sulud nga mga char, bisan kung adunay kini kapasidad nga labaw pa
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tanan kini nahuman nga wala nag-relocal ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... apan kini mahimo`g himuaan ang pisi
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): uban ang cfg(test) ang adunay kinaiyanhon nga pamaagi nga `[T]::to_vec`, nga gikinahanglan alang sa kini nga paghubit sa pamaagi, dili magamit.
    // Tungod kay wala namon kinahanglana kini nga pamaagi alang sa mga katuyoan sa pagsulay, igbutang ko ra kini NB tan-awa ang slice::hack module sa slice.rs alang sa dugang nga kasayuran
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Gikabig ang usa ka vector nga mga byte sa usa ka `String`.
    ///
    /// Ang usa ka hilo ([`String`]) hinimo sa bytes ([`u8`]), ug usa ka vector sa bytes ([`Vec<u8>`]) nga hinimo sa bytes, mao nga kini nga function kinabig sa taliwala sa duha ka.
    /// Dili tanan nga mga byte slice balido nga `String`s, bisan pa: kinahanglan sa `String` nga kini balido nga UTF-8.
    /// `from_utf8()` pagsusi aron masiguro nga ang mga byte balido nga UTF-8, ug pagkahuman buhaton ang pagkakabig.
    ///
    /// Kung nakasiguro ka nga ang byte slice balido nga UTF-8, ug dili nimo gusto nga maabut ang overhead sa validity check, adunay usa ka dili luwas nga bersyon sa kini nga function, ang [`from_utf8_unchecked`], nga adunay parehas nga pamatasan apan gilaktawan ang tseke.
    ///
    ///
    /// Magbantay kini nga pamaagi aron dili kopyahon ang vector, alang sa kaayohan.
    ///
    /// Kung kinahanglan nimo ang [`&str`] imbis nga `String`, hunahunaa ang [`str::from_utf8`].
    ///
    /// Ang balihon sa kini nga pamaagi mao ang [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Gibalik ang [`Err`] kung ang slice dili UTF-8 nga adunay usa ka paghulagway kung ngano nga ang gihatag nga mga byte dili UTF-8.Ang vector nga imong gibalhin kauban usab.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // pipila ka mga byte, sa usa ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Nahibal-an namon nga kini nga mga byte balido, busa gamiton namon ang `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Sayup nga mga byte:
    ///
    /// ```
    /// // ang pipila dili balido nga mga byte, sa usa ka vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Tan-awa ang mga doc alang sa [`FromUtf8Error`] alang sa daghang mga detalye kung unsa ang mahimo nimo sa kini nga sayup.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Gikabig ang usa ka hiwa nga mga byte sa usa ka pisi, lakip ang dili wasto nga mga karakter.
    ///
    /// Ang mga lubid gihimo sa bytes ([`u8`]), ug usa ka slice sa bytes ([`&[u8]`][byteslice]) nga gihimo sa bytes, busa ang kini nga kalihokan nakabig taliwala sa duha.Dili tanan nga mga byte slice mga balido nga mga pisi, bisan pa: kinahanglan ang mga lubid aron mahimong balido nga UTF-8.
    /// Sa panahon sa kini nga pagkakabig, ilisan sa `from_utf8_lossy()` ang bisan unsang dili balido nga han-ay sa UTF-8 nga [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], nga ingon niini:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Kung nakasiguro ka nga ang byte slice balido nga UTF-8, ug dili nimo gusto nga maabut ang overhead sa pagkakabig, adunay usa ka dili luwas nga bersyon sa kini nga pag-andar, [`from_utf8_unchecked`], nga adunay parehas nga pamatasan apan gilaktawan ang mga tseke.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ang ninglihok nga pagbalik sa usa ka [`Cow<'a, str>`].Kung ang among byte slice dili balido nga UTF-8, nan kinahanglan namon nga isal-ot ang mga baylo nga karakter, nga magbag-o sa kadako sa pisi, ug busa, nanginahanglan usa ka `String`.
    /// Apan kung balido na ang UTF-8, dili na namon kinahanglan bag-o nga alokasyon.
    /// Gitugotan kami sa kini nga tipo sa pagbalik aron makontrol ang pareho nga mga kaso.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // pipila ka mga byte, sa usa ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Sayup nga mga byte:
    ///
    /// ```
    /// // ang pila dili balido nga mga byte
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Pag-decode sa usa ka UTF-16 - nga naka-encode nga vector `v` sa usa ka `String`, nga ibalik ang [`Err`] kung ang `v` adunay sulud nga dili husto nga datos.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Wala kini buhata pinaagi sa pagkolekta: : <Result<_, _>> () alang sa mga hinungdan sa paghimo.
        // FIXME: ang pagpaandar mahimong mapasayon pag-usab kung sirado ang #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Pag-decode sa usa ka UTF-16 - nga naka-encode nga slice `v` ngadto sa usa ka `String`, nga gipuli ang dili husto nga datos sa [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Dili sama sa [`from_utf8_lossy`] nga nagbalik usa ka [`Cow<'a, str>`], ang `from_utf16_lossy` mobalik usa ka `String` tungod kay ang UTF-16 sa UTF-8 nga pagkakabig nanginahanglan usa ka alokasyon sa memorya.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Nabungkag ang usa ka `String` sa mga hilaw nga sangkap niini.
    ///
    /// Mobalik sa hilaw pointer sa nagpahiping data, ang gitas-on sa pisi (sa bytes), ug ang gigahin nga kapasidad sa mga data (sa bytes).
    /// Kini ang parehas nga mga argumento sa parehas nga han-ay sa mga argumento sa [`from_raw_parts`].
    ///
    /// Pagkahuman sa pagtawag sa kini nga pag-andar, ang tigpatawag mao ang responsable alang sa memorya nga kaniadto gidumala sa `String`.
    /// Ang paagi ra aron mahimo kini mao ang pag-usab sa hilaw nga pointer, gitas-on, ug kapasidad balik sa usa ka `String` nga adunay [`from_raw_parts`] function, nga gitugotan ang destructor nga himuon ang paglimpiyo.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Naghimo usa ka bag-ong `String` gikan sa usa ka gitas-on, kapasidad, ug pointer.
    ///
    /// # Safety
    ///
    /// Kini labi ka dili luwas, tungod sa gidaghanon sa mga nag-imbitar nga dili gisusi:
    ///
    /// * Ang panumduman sa `buf` kinahanglan kaniadto nga gigahin sa parehas nga tagahatag nga gigamit sa sumbanan nga librarya, nga adunay kinahanglan nga paglinya nga eksakto nga 1.
    /// * `length` kinahanglan nga mas mubu o managsama sa `capacity`.
    /// * `capacity` kinahanglan nga husto nga kantidad.
    /// * Ang una nga `length` bytes sa `buf` kinahanglan nga balido nga UTF-8.
    ///
    /// Ang paglapas niini mahimong hinungdan sa mga problema sama sa pagdaut sa internal nga istruktura sa datos sa tagahatag.
    ///
    /// Ang pagpanag-iya sa `buf` ang epektibo nga gibalhin ngadto sa `String` nga unya deallocate, reallocate o sa pag-usab sa mga sulod sa handumanan mitudlo ngadto sa pointer sa kabubut-on.
    /// Siguruha nga wala`y lain nga magamit ang pointer pagkahuman pagtawag sa kini nga pag-andar.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME I-update kini kung ang stabil nga vector_into_raw_parts
    ///     // Pugong nga awtomatikong ihulog ang datos sa String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Gikabig ang usa ka vector nga mga byte sa usa ka `String` nga wala gisusi nga ang pisi adunay sulud nga UTF-8.
    ///
    /// Tan-awa ang luwas nga bersyon, [`from_utf8`], alang sa dugang nga mga detalye.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// function Kini mao ang dili luwas tungod kay kini wala pagsusi nga ang bytes milabay sa niini balido UTF-8.
    /// Kon kini pagpugos ang nakalapas, mahimong kini ang hinungdan sa mga isyu handumanan unsafety uban sa future tiggamit sa `String`, ingon sa uban nga mga sumbanan nga librarya nagaangkon nga `String`s mga balido UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // pipila ka mga byte, sa usa ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Gikabig ang usa ka `String` ngadto sa usa ka byte vector.
    ///
    /// Gikonsumo niini ang `String`, busa dili namon kinahanglan nga kopyahon ang mga sulud niini.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Nakuha ang usa ka hiwa sa pisi nga adunay sulud nga tibuuk nga `String`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Gibag-o ang usa ka `String` sa usa ka mutable string slice.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Appends sa usa ka gihatag hilo ad-ad ngadto sa katapusan sa niini nga `String`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Mibalik kini `ni String` kapasidad, sa mga bytes.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Gisiguro nga ang kapasidad sa `String` nga kini labing menos `additional` bytes nga labi ka daghan kaysa sa gitas-on niini.
    ///
    /// Ang kapasidad mahimo nga madugangan labaw pa sa `additional` bytes kung kini gipili, aron mapugngan ang kanunay nga pag-relocate.
    ///
    ///
    /// Kung dili nimo gusto kini nga pamatasan "at least", tan-awa ang pamaagi nga [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Mahimong dili gyud niini madugangan ang kapasidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Ang s karon adunay gitas-on nga 2 ug adunay kapasidad nga 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tungod kay adunay na kami dugang nga 8 nga kapasidad, nga gitawag kini ...
    /// s.reserve(8);
    ///
    /// // ... dili tinuud nga nagdugang.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Gisiguro nga ang kapasidad sa `String` nga kini mao ang `additional` bytes nga labi ka daghan kaysa sa gitas-on niini.
    ///
    /// Hunahunaa ang paggamit sa [`reserve`] nga pamaagi gawas kung hingpit nga nahibal-an nimo ang labaw pa sa tighatag.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa `usize`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Mahimong dili gyud niini madugangan ang kapasidad:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Ang s karon adunay gitas-on nga 2 ug adunay kapasidad nga 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Tungod kay adunay na kami dugang nga 8 nga kapasidad, nga gitawag kini ...
    /// s.reserve_exact(8);
    ///
    /// // ... dili tinuud nga nagdugang.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Gisulayan ang pagreserba sa kapasidad alang sa labing menos nga `additional` daghang mga elemento nga isal-ot sa gihatag nga `String`.
    /// Ang pagkolekta mahimong magreserba sa daghang wanang aron malikayan ang kanunay nga pag-relocate.
    /// Pagkahuman pagtawag sa `reserve`, ang kapasidad mahimong labi ka daghan o katumbas sa `self.len() + additional`.
    /// Wala`y gihimo kung igo na ang kapasidad.
    ///
    /// # Errors
    ///
    /// Kung ang kapasidad nag-awas, o ang taghatag nagreport sa usa ka kapakyasan, nan usa ka sayup ang gibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pag-pre-reserba sa memorya, paggawas kung dili namon mahimo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Karon nahibal-an namon nga dili kini mahimo OOM taliwala sa among komplikado nga trabaho
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Gipaningkamutan nga makareserba ang minimum nga kapasidad alang sa eksaktong `additional` nga daghang mga elemento nga isal-ot sa gihatag nga `String`.
    ///
    /// Human sa pagtawag `reserve_exact`, kapasidad mahimong mas dako pa kay sa o itanding `self.len() + additional`.
    /// Wala`y gihimo kung ang kapasidad igo na.
    ///
    /// Hinumdomi nga ang tagahatag mahimo nga hatagan ang koleksyon labi ka daghang wanang kaysa sa gihangyo niini.
    /// Busa, ang kapasidad dili masaligan nga mahimong ensakto nga dyutay.
    /// Gipalabi ang `reserve` kung gipaabut ang mga pagsal-ot sa future.
    ///
    /// # Errors
    ///
    /// Kung ang kapasidad nag-awas, o ang taghatag nagreport sa usa ka kapakyasan, nan usa ka sayup ang gibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pag-pre-reserba sa memorya, paggawas kung dili namon mahimo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Karon nahibal-an namon nga dili kini mahimo OOM taliwala sa among komplikado nga trabaho
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Gipakubus ang kapasidad sa kini nga `String` aron itugma ang gitas-on niini.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Gipakubus ang kapasidad sa kini nga `String` nga adunay mas ubos nga gihigot.
    ///
    /// Ang kapasidad magpabilin labing menos sama kadako sa pareho sa gitas-on ug sa gitagana nga kantidad.
    ///
    ///
    /// Kung ang karon nga kapasidad mas gamay kaysa sa labing ubos nga utlanan, kini usa ka no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Nagdugang sa gihatag nga [`char`] sa katapusan sa kini nga `String`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Gibalik ang usa ka byte slice sa mga sulud nga `String`.
    ///
    /// Ang balihon sa kini nga pamaagi mao ang [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Gipamub-an kini nga `String` sa gitino nga gitas-on.
    ///
    /// Kung ang `new_len` mas daghan kaysa karon nga gitas-on sa string, wala kini epekto.
    ///
    ///
    /// Timan-i nga kini nga pamaagi adunay walay epekto sa gigahin kapasidad sa sa pisi
    ///
    /// # Panics
    ///
    /// Panics kon `new_len` wala mohigda sa usa ka [`char`] utlanan.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Gikuha ang katapusang karakter gikan sa string buffer ug gibalik kini.
    ///
    /// Gibalik ang [`None`] kung kini nga `String` walay sulod.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Gikuha ang usa ka [`char`] gikan sa kini nga `String` sa usa ka byte nga posisyon ug gibalik kini.
    ///
    /// Kini usa ka operasyon nga *O*(*n*), tungod kay nanginahanglan kini pagkopya sa matag elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `idx` mas dako kaysa o managsama sa gitas-on sa `String`, o kung dili kini mohigda sa usa ka utlanan nga [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Kuhaa ang tanan nga mga posporo sa pattern `pat` sa `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ang mga panagsama mamatikdan ug tangtangon sa ingon usab, busa sa mga kaso diin ang mga sundanan magsapaw, ang una nga sundanan ra ang tangtangon:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // KALUWASAN: ang pagsugod ug pagtapos naa sa utf8 byte nga mga utlanan matag usa
        // ang Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Gipadayon lamang ang mga karakter nga gitino sa prediksyon.
    ///
    /// Sa laing pagkasulti, tangtanga ang tanan nga mga karakter `c` sa ingon nga ibalik sa `f(c)` ang `false`.
    /// Kini nga pamaagi naglihok sa lugar, pagbisita sa matag karakter eksakto nga kausa sa orihinal nga han-ay, ug gipreserba ang pagkahan-ay sa mga nahabilin nga karakter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ang ensakto nga pagkahan-ay mahimong mapuslanon alang sa pagsubay sa gawas nga estado, sama sa usa ka indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Itudlo ang idx sa sunod nga char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Gisal-ot ang usa ka karakter sa kini nga `String` sa usa ka byte nga posisyon.
    ///
    /// Kini mao ang usa ka Oh *(* n *) operasyon ingon nga kini nagkinahanglan sa pagkopya sa matag elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `idx` mas daghan kaysa sa gitas-on sa `String`, o kung dili kini mohigda sa usa ka [`char`] nga utlanan.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Gisulud ang usa ka hiwa sa pisi sa kini nga `String` sa usa ka byte nga posisyon.
    ///
    /// Kini mao ang usa ka Oh *(* n *) operasyon ingon nga kini nagkinahanglan sa pagkopya sa matag elemento sa buffer.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `idx` mas daghan kaysa sa gitas-on sa `String`, o kung dili kini mohigda sa usa ka [`char`] nga utlanan.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Nagbalik usa ka mabalhin nga pakisayran sa mga sulud niining `String`.
    ///
    /// # Safety
    ///
    /// function Kini mao ang dili luwas tungod kay kini wala pagsusi nga ang bytes milabay sa niini balido UTF-8.
    /// Kon kini pagpugos ang nakalapas, mahimong kini ang hinungdan sa mga isyu handumanan unsafety uban sa future tiggamit sa `String`, ingon sa uban nga mga sumbanan nga librarya nagaangkon nga `String`s mga balido UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Gibalik ang gitas-on sa kini nga `String`, sa mga byte, dili sa [`char`] s o graphemes.
    /// Sa laing mga pulong, kini dili mahimo nga kon unsa ang usa ka tawo giisip sa gitas-on sa pisi.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Gibalik ang `true` kung kini nga `String` adunay usa ka gitas-on nga zero, ug kung ingon man ang `false`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Magabugha sa pisi ngadto sa duha ka sa mga gihatag nga Byte index.
    ///
    /// Gibalik ang usa ka bag-ong gigahin nga `String`.
    /// `self` adunay bytes `[0, at)`, ug ang gibalik nga `String` adunay bytes `[at, len)`.
    /// `at` kinahanglan naa sa utlanan sa usa ka UTF-8 code point.
    ///
    /// Hinumdomi nga ang kapasidad sa `self` dili mausab.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `at` wala sa usa ka `UTF-8` code point border, o kung kini lapas sa katapusan nga code point sa hilo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Giputol kini `String`, gikuha ang tanan nga sulud.
    ///
    /// Samtang kini gipasabut nga ang `String` adunay usa ka gitas-on nga zero, dili kini gihikap ang kapasidad niini.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Naghimo usa ka draining iterator nga gikuha ang gitino nga sakup sa `String` ug nagahatag sa gikuha nga `chars`.
    ///
    ///
    /// Note: Gikuha ang range sa elemento bisan kung ang iterator dili masunog hangtod sa katapusan.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang pagsugod nga punto o ang katapusan nga punto dili paghigda sa usa ka [`char`] nga utlanan, o kung wala sila mga utlanan.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Kuhaa ang kutub hangtod sa β gikan sa pisi
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ang usa ka tibuuk nga han-ay nagwagtang sa pisi
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Kaluwas sa memorya
        //
        // Ang bersyon sa String sa Drain wala`y mga isyu sa kahilwasan sa memorya sa bersyon nga vector.
        // Ang datos yano ra nga mga byte.
        // Tungod kay ang laing pagtangtang mahitabo sa Drop, kon ang Drain iterator ang leaked, ang pagtangtang dili mahitabo.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Dad-a sa duha ka dungan nga nagapangutang.
        // Ang &mut String dili ma-access hangtud matapos ang pag-ulit, sa Drop.
        let self_ptr = self as *mut _;
        // KALUWASAN: Gibuhat sa `slice::range` ug `is_char_boundary` ang mga angay nga tseke sa utlanan.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Gikuha ang gitino nga sakup sa pisi, ug giilisan kini sa gihatag nga hilo.
    /// Ang gihatag nga pisi dili kinahanglan parehas sa gitas-on sa sakup.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang pagsugod nga punto o ang katapusan nga punto dili paghigda sa usa ka [`char`] nga utlanan, o kung wala sila mga utlanan.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Puli ang range hangtod sa β gikan sa pisi
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Kaluwas sa memorya
        //
        // Ang Change_range wala`y mga isyu sa kahilwasan sa memorya sa usa ka vector Splice.
        // sa bersyon sa vector.Ang datos yano ra nga mga byte.

        // WARNING: Ang pagsulud sa kini nga variable mahimo`g unsound (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WARNING: Ang pagsulud sa kini nga variable mahimo`g unsound (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ang paggamit sa `range` pag-usab mahimong dili lig-on nga (#81138) Giisip namon nga ang mga utlanan nga gireport sa `range` nagpabilin nga pareho, apan ang usa ka kontra nga pagpatuman mahimong magbag-o taliwala sa mga tawag
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Mga kinabig niini nga `String` ngadto sa usa ka [`Box`]`<`[`str`] `>`.
    ///
    /// Ihulog niini ang bisan unsang sobra nga kapasidad.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Mobalik usa ka hiwa sa [`u8`] mga byte nga gisulayan nga pagkabig sa usa ka `String`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // ang pipila dili balido nga mga byte, sa usa ka vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Gibalik ang mga byte nga gisulayan nga pagkabig sa usa ka `String`.
    ///
    /// Maayong paagi kini nga pamaagi aron malikayan ang paggahin.
    /// Pag-ut-ut niini ang sayup, pagbalhin sa mga byte, aron ang usa ka kopya sa mga byte dili kinahanglan buhaton.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // ang pipila dili balido nga mga byte, sa usa ka vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Pagkuha usa ka `Utf8Error` aron makakuha dugang nga mga detalye bahin sa kapakyasan sa pagkakabig.
    ///
    /// Ang [`Utf8Error`] matang nga gihatag sa [`std::str`] nagrepresentar sa usa ka sayup nga mahitabo sa diha nga ang pagkabig sa usa ka ad-ad sa [`u8`] sa ngadto sa usa ka [`&str`].
    /// Sa kini nga pagsabut, kini usa ka analogue sa `FromUtf8Error`.
    /// Tan-awa ang dokumentasyon niini alang sa daghang mga detalye sa paggamit niini.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// // ang pipila dili balido nga mga byte, sa usa ka vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ang una nga byte dili balido dinhi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Tungod kay gibalik-balik namon ang mga `String`s, malikayan namon ang bisan usa ka paggahin pinaagi sa pagkuha sa una nga pisi gikan sa iterator ug idugang kini sa tanan nga mosunud nga mga pisi.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Tungod kay gisubli namon ang mga CoW, mahimo namon malikayan ang (potentially) bisan usa ka alokasyon pinaagi sa pagkuha sa una nga aytem ug idugang kini sa tanan nga mosunud nga mga butang.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Usa ka sayon nga impl nga nagdelegar sa impl alang sa `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Naghimo usa ka walay sulod nga `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Gipatuman ang `+` operator alang sa concatenating duha nga mga lubid.
///
/// Gikonsumo niini ang `String` sa wala nga bahin ug gigamit pag-usab ang buffer niini (gipadako kini kung kinahanglan).
/// Gihimo kini aron malikayan ang paggahin usa ka bag-ong `String` ug pagkopya sa tibuuk nga sulud sa matag operasyon, nga mosangput sa *O*(*n*^ 2) oras sa pagdagan kung nagtukod usa ka *n*-byte nga pisi pinaagi sa gibalikbalik nga pagsumpay.
///
///
/// Ang pisi sa tuo nga kamot hinulaman ra;ang mga sulud niini gikopya sa giuli nga `String`.
///
/// # Examples
///
/// Ang pagdugtong sa duha nga `String` mao ang mag-una sa kantidad ug manghulam sa ikaduha:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` gibalhin ug dili na magamit dinhi.
/// ```
///
/// Kon kamo gusto nga aron sa pagbantay sa paggamit sa unang `String`, nga kamo mahimo clone kini ug append sa clone sa baylo:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` balido pa dinhi.
/// ```
///
/// Ang mga hiwa nga `&str` mahimo`g buhaton pinaagi sa pagkabig sa una sa usa ka `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Gipatuman ang `+=` operator alang sa pagdugang sa usa ka `String`.
///
/// Kini adunay parehas nga pamatasan sa pamaagi nga [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Usa ka tipo nga alias alang sa [`Infallible`].
///
/// alyas Kini nga anaa alang sa naglakaw pagkaangay, ug mahimo nga sa ngadto-ngadto deprecated.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Usa ka trait alang sa pagkabig sa usa ka kantidad sa usa ka `String`.
///
/// Kini nga trait awtomatikong gipatuman alang sa bisan unsang tipo nga nagpatuman sa [`Display`] trait.
/// Ingon niana, ang `ToString` dili kinahanglan nga ipatuman nga direkta:
/// [`Display`] kinahanglan ipatuman hinoon, ug makuha nimo ang pagpatuman sa `ToString` nga libre.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Mga kinabig sa gihatag nga bili sa usa ka `String`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Sa pagpatuman niini, ang `to_string` nga paagi panics kon ang `Display` pagpatuman mobalik sa usa ka sayop.
/// Gipakita niini ang usa ka sayup nga pagpatuman sa `Display` tungod kay ang `fmt::Write for String` wala gyud mobalik bisan usa nga sayup.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Ang usa ka sagad nga sumbanan mao ang dili paglinya sa mga heneral nga gimbuhaton.
    // Bisan pa, ang pagtangtang sa `#[inline]` gikan sa kini nga pamaagi hinungdan sa dili mabaliwala nga mga pag-us-os.
    // Tan-awa ang <https://github.com/rust-lang/rust/pull/74852>, ang katapusang pagsulay nga kini kuhaon.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Gikabig ang usa ka `&mut str` ngadto sa usa ka `String`.
    ///
    /// Ang sangputanan gigahin sa tinapok.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ang pagbira sa pagsulay sa libstd, nga hinungdan sa mga sayup dinhi
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Nakabig ang gihatag nga kahon nga `str` nga hiwa sa usa ka `String`.
    /// Kini bantog nga ang `str` slice gipanag-iya.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Nakabig ang gihatag nga `String` sa usa ka kahon nga kahon nga `str` nga gipanag-iya.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Gikabig ang usa ka hiwa sa pisi sa usa ka lainlaing gihulaman.
    /// Wala`y gihimo nga alokasyon nga tapok, ug ang pisi dili gikopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Gikabig ang usa ka String sa usa ka Tag-iya nga lahi.
    /// Wala`y gihimo nga alokasyon nga tapok, ug ang pisi dili gikopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Gikabig ang usa ka pakisayran sa String sa usa ka lainlaing gihulam.
    /// Wala`y gihimo nga alokasyon nga tapok, ug ang pisi dili gikopya.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Gikabig ang gihatag nga `String` sa usa ka vector `Vec` nga naghupot sa mga kantidad nga lahi nga `u8`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Usa ka draining iterator alang sa `String`.
///
/// Ang kini nga istraktura gimugna sa [`drain`] nga pamaagi sa [`String`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Gigamit ingon&'usa ka mut String sa destructor
    string: *mut String,
    /// Pagsugod sa bahin aron makuha
    start: usize,
    /// Katapusan sa bahin aron makuha
    end: usize,
    /// Karon nga nahabilin nga sakup aron makuha
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Paggamit Vec::drain.
            // "Reaffirm" gisusi sa mga utlanan aron malikayan nga gisulud usab ang panic code.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Gibalik ang nahabilin (sub) nga hilo sa kini nga iterator ingon usa ka hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: dili kompromiso nga AsRef impls sa ubos kung nagpalig-on.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Dili pagkomento kung nagpalig-on sa `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>alang sa Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> para sa Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}