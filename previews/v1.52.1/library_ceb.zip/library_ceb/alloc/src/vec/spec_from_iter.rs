use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Espesyalista nga trait gigamit alang sa Vec::from_iter
///
/// ## Ang graph sa delegasyon:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ang usa ka kasagarang kaso mao ang pagpasa sa usa ka vector sa usa ka kalihokan nga gilakip usab dayon sa usa ka vector.
        // Mahimo naton kini nga mubuut circuit kung ang IntoIter wala pa gyud mauswag.
        // Kung kini gipauswag Mahimo usab naton gamiton ang memorya ug ibalhin ang datos sa atubangan.
        // Apan gibuhat ra namo kini kung ang sangputanan nga Vec wala`y daghan nga wala magamit nga kapasidad kaysa paghimo niini pinaagi sa generic FromIterator nga pagpatuman.
        //
        // Ang kana nga limitasyon dili kinahanglan nga estrikto tungod kay ang pamatasan sa paggahin sa Vec tinuyo nga wala matino.
        // Apan kini usa ka konserbatibo nga kapilian.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // kinahanglan magdelegar sa spec_extend() tungod kay ang extend() mismo nagdelegar sa spec_from alang sa mga walay sulod nga Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Kini migamit `iterator.as_slice().to_vec()` sukad spec_extend kinahanglan sa dugang nga mga lakang sa rason mahitungod sa katapusan nga gitas-on nga kapasidad + ug sa ingon pagbuhat sa labaw pa nga buhat.
// `to_vec()` direkta nga naggahin sa husto nga kantidad ug gipuno kini nga ensakto.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): uban ang cfg(test) ang adunay kinaiyanhon nga pamaagi nga `[T]::to_vec`, nga gikinahanglan alang sa kini nga paghubit sa pamaagi, dili magamit.
    // Hinuon gamita ang `slice::to_vec` function nga magamit lamang sa cfg(test) NB tan-awa ang slice::hack module sa slice.rs alang sa dugang nga kasayuran
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}