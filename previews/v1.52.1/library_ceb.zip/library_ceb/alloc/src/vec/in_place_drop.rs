use core::ptr::{self};
use core::slice::{self};

// Ang usa ka helper nga istruktura alang sa sulud nga paglibut nga nahulog sa destinasyon nga hiwa sa pag-ulit, ie ang ulo.
// Ang gigikanan nga hiwa (ang ikog) gihulog sa IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}