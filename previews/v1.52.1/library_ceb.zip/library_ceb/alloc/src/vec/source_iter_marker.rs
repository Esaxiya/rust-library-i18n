use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Espesyalista nga marka alang sa pagkolekta sa usa ka iterator pipeline sa usa ka Vec samtang gigamit usab ang gigahin nga gigikanan, ie
/// pagpatuman sa pipeline sa lugar.
///
/// Ang ginikanan nga SourceIter nga trait kinahanglan alang sa espesyalista nga pag-andar aron ma-access ang alokasyon nga gamiton pag-usab.
/// Apan kini dili igo alang sa specialization nga mahimong balido.
/// Makita ang dugang nga mga utlanan sa impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Ang std-internal SourceIter/InPlaceIterable traits gipatuman ra sa mga kadena sa Adapter <Adapter<Adapter<IntoIter>>> (tanan gipanag-iya sa core/std).
// Ang dugang nga mga utlanan sa mga pagpatuman sa adapter (lapas sa `impl<I: Trait> Trait for Adapter<I>`) nagsalig ra sa ubang traits nga gimarkahan na ingon nga espesyalista traits (Kopya, TrustedRandomAccess, FusedIterator).
//
// I.e. ang marker dili mosalig sa mga kinabuhi sa mga klase nga gitagana sa gumagamit.Modulo ang lungag sa Kopya, diin ang daghang uban pa nga pagdala sa pagdala nakasalig na.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Dugang nga mga kinahanglanon nga dili nagpahayag pinaagi sa trait bounds.Kita mosalig sa const eval sa baylo:
        // a) walay mga ZST tungod kay wala`y alokasyon nga gamiton pag-usab ug ang pointer arithmetic nga panic b) kadako nga pareha sa gikinahanglan sa Alloc nga kontrata c) mga panagsama nga panagsama sama sa gikinahanglan sa kontrata sa Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback sa mas generic implementar
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gamita ang try-fold sukad
        // - mas maayo kini nga pag-vector alang sa pipila nga mga adapter sa iterator
        // - dili sama sa kadaghanan sa internal nga mga pamaagi sa subli, mokabat lamang kini nga usa ka &mut kaugalingon
        // - Gitugotan kami nga sulud ang sulud sa pagsulat pinaagi sa mga sulud niini ug ibalik kini sa katapusan
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // nagmalampuson ang pag-ulit, ayaw paghulog
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // susihon kung ang kontrata sa SourceIter gipadayon nga pahimangno: kung dili sila mahimo nga dili naton kini nahimo sa kini nga punto
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // susiha ang InPlaceIterable nga kontrata.Posible ra kini kung giuswag sa iterator ang gigikanan nga punoan sa tanan.
        // Kung naggamit kini dili gisusi nga pag-access pinaagi sa TrustedRandomAccess nan ang gigikanan nga pointer magpabilin sa una nga posisyon niini ug dili namon kini magamit ingon pakisayran
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // drop sa bisan unsa nga nahibilin nga mga prinsipyo sa ikog sa tinubdan apan sa pagpugong sa tinulo sa alokasyon sa iyang kaugalingon sa makausa IntoIter moadto sa kasangkaran kon ang tinulo panics nan kita usab tulo sa bisan unsa nga mga elemento nga nakolekta sa dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ang kontrata nga InPlaceIterable dili mapamatud-an nga husto dinhi tungod kay ang try_fold adunay usa ka eksklusibo nga pakisayran sa gigikanan nga pointer nga mahimo ra naton nga masusi kung naa pa ba sa range
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}