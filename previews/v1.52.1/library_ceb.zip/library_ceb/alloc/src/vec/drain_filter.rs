use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Usa ka iterator nga naggamit us aka pagsira aron mahibal-an kung kinahanglan ba nga tangtangon ang usa ka elemento.
///
/// Ang kini nga istraktura gimugna sa [`Vec::drain_filter`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Ang indeks sa butang nga susihon sa sunod nga pagtawag sa `next`.
    pub(super) idx: usize,
    /// Ang gidaghanon sa mga butang nga nahurot sa (removed) hangtod karon.
    pub(super) del: usize,
    /// Ang orihinal nga gitas-on sa `vec` sa wala pa ang draining.
    pub(super) old_len: usize,
    /// Ang predicate sa pagsulay sa pagsala.
    pub(super) pred: F,
    /// Ang usa ka bandila nga nagpakita usa ka panic ang nahinabo sa prediksyon sa pagsulay sa pagsala.
    /// Gigamit kini ingon usa ka hint sa pagpatuman sa drop aron mapugngan ang pagkonsumo sa nahabilin sa `DrainFilter`.
    /// Sa bisan unsa nga unprocessed mga butang nga backshifted sa `vec`, apan walay dugang pa nga mga butang nga nagpatulo o gisulayan sa mga filter predicate.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Nagbalik usa ka pakisayran sa nagpahiping tagahatag.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Update sa index * human ang predicate gitawag.
                // Kung ang indeks gi-update sa wala pa ug ang predicate nga panics, ang elemento sa kini nga indeks mahimong ma-leak.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Kini usa ka medyo gubot nga estado, ug wala`y usa ka tin-aw nga tama nga buhaton.
                        // Dili namon gusto nga ipadayon ang pagsulay nga ipatuman ang `pred`, mao nga gibalhin ra namo ang backshift sa tanan nga wala maproseso nga mga elemento ug gisulti sa mga vector nga anaa pa sila.
                        //
                        // Gikinahanglan ang backshift aron mapugngan ang us aka double-drop sa katapusang malampuson nga nahuman nga butang sa wala pa ang usa ka panic sa predicate.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Gisulayan nga ut-uton ang bisan unsang nahabilin nga mga elemento kung wala pa mag-panic ang predicate sa filter.
        // I-backshift namon ang bisan unsang nahabilin nga mga elemento kung nahadlok na kami o kung ang konsumo dinhi panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}