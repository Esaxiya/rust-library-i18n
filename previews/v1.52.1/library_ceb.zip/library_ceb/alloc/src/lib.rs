//! # Ang Rust nga punoan nga alokasyon ug librarya sa mga koleksyon
//!
//! Naghatag ang librarya niini nga mga smart point ug koleksyon alang sa pagdumala sa mga kantidad nga gitagana nga tapok.
//!
//! librarya Kini, sama sa libcore, kasagaran dili kinahanglan nga gamiton direkta sukad sulod niini mao ang pag-eksport sa [`std` crate](../std/index.html).
//! Ang Crates nga naggamit sa `#![no_std]` nga hiyas bisan pa niana kasagaran dili magsalig sa `std`, mao nga hinoon gamiton nila kini nga crate.
//!
//! ## Mga hatagan bili
//!
//! Ang matang [`Box`] mao ang usa ka Smart matang pointer.Mahimong usa ra ang tag-iya sa usa ka [`Box`], ug ang tag-iya mahimong magdesisyon nga mutate ang mga sulud, nga mabuhi sa tapok.
//!
//! Ang kini nga tipo mahimong ipadala taliwala sa mga sulud nga episyente sama sa kadako sa kantidad nga `Box` parehas sa usa ka pointer.
//! Ang mga istruktura sa datos nga sama sa kahoy kanunay nga gitukod nga adunay mga kahon tungod kay ang matag node kanunay adunay usa ka tag-iya, ang ginikanan.
//!
//! ## Mga panudlo nga giihap nga pakisayran
//!
//! Ang tipo nga [`Rc`] usa ka non-threadsafe nga naihap nga tudlo nga tibuuk nga tipo nga gituyo alang sa pagpaambit sa memorya sa sulud sa usa ka sulud
//! Ang usa ka [`Rc`] pointer nagputos sa usa ka tipo, `T`, ug gitugotan lang ang pag-access sa `&T`, usa ka gipaambit nga reperensiya.
//!
//! Mapuslanon kini nga tipo kung ang napanunod nga pagkabag-o (sama sa paggamit sa [`Box`]) sobra nga nagpugong alang sa usa ka aplikasyon, ug kanunay gipares sa mga [`Cell`] o [`RefCell`] nga mga lahi aron matugotan ang pagbag-o.
//!
//!
//! ## Atomiko nga gihisgotan ang giihap nga mga panudlo
//!
//! Ang tipo nga [`Arc`] mao ang katumbas sa threadsafe sa [`Rc`] nga tipo.Naghatag kini sa tanan nga parehas nga pagpaandar sa [`Rc`], gawas nga kinahanglan niini nga ang sulud nga sulud nga `T` mapaambit.
//! Ingon kadugangan, ang [`Arc<T>`][`Arc`] mismo mapadala samtang ang [`Rc<T>`][`Rc`] dili.
//!
//! Gitugotan kini nga tipo alang sa gipaambit nga pag-access sa sulud nga datos, ug kanunay gipares sa mga primitibo sa pag-synchronize sama sa mga mutexes aron tugutan ang pagbag-o sa mga gipaambit nga mga gigikanan.
//!
//! ## Collections
//!
//! Ang mga pagpatuman sa labing kasagarang katuyoan nga mga istruktura sa datos gihubit sa kini nga librarya.Gi-export usab kini pinaagi sa [standard collections library](../std/collections/index.html).
//!
//! ## Mga interface sa tapok
//!
//! Gihubit sa module nga [`alloc`](alloc/index.html) ang interface nga ubos ang lebel sa default nga tighatag sa kalibutan.Dili kini katugma sa libc allocator API.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Sa teknikal nga paagi, kini usa ka bug sa rustdoc: nakita sa rustdoc ang dokumentasyon sa `#[lang = slice_alloc]` blocks alang sa `&[T]`, nga adunay usab dokumentasyon nga gigamit kini nga bahin sa `core`, ug nagsalimoang nga ang tampok-gate dili gipalihok.
// Maayo, dili kini pagsusi alang sa tampok nga ganghaan alang sa mga doc gikan sa ubang crates, apan tungod kay mahimo ra kini makita alang sa mga lang butang, dili kini angay nga ayohon.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Tugoti sa pagsulay niini nga librarya

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Modyul nga adunay sulud nga macros nga gigamit sa ubang mga modyul (kinahanglan nga iupod sa wala pa ang ubang mga modyul).
#[macro_use]
mod macros;

// Mga tinapok nga gihatag alang sa ubos-level nga mga pamaagi nga alokasyon

pub mod alloc;

// Mga klase nga primitive gamit ang mga tambak sa taas

// Kinahanglan nga adunay kondisyon nga pagbatbat ang mod gikan sa `boxed.rs` aron malikayan ang pagdoble sa mga lang-item kung nagtukod sa pagsulay nga CFG;apan kinahanglan usab nga tugotan ang code nga adunay mga deklarasyon nga `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}