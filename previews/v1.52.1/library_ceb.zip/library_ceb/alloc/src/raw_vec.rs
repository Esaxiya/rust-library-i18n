#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Ang mga sulud sa bag-ong memorya wala mahibal-an.
    Uninitialized,
    /// Ang bag-ong memorya gigarantiyahan nga ma-zero.
    Zeroed,
}

/// Usa ka ubos nga lebel nga magamit alang sa labi ka ergonomikal nga paggahin, pag-usab sa pag-usab, ug pag-deallocate sa usa ka buffer memory sa tambak nga dili mabalaka bahin sa tanan nga mga kaso sa kanto nga nahilambigit.
///
/// Maayo kini nga tipo alang sa pagtukod sa imong kaugalingon nga mga istruktura sa datos sama sa Vec ug VecDeque.
/// Sa partikular:
///
/// * Naghimo `Unique::dangling()` sa mga lahi nga wala`y gidak-on.
/// * Naghimo `Unique::dangling()` sa zero-haba nga gahin.
/// * Paglikay nga buhian ang `Unique::dangling()`.
/// * Naabtan ang tanan nga pag-awas sa mga pag-ihap sa kapasidad (gipasiugda kini hangtod sa "capacity overflow" panics).
/// * Ang mga guwardiya batok sa 32-bit nga mga sistema nga naggahin labaw pa sa isize::MAX bytes.
/// * Pagbantay batok sa pag-awas sa imong gitas-on.
/// * Nagtawag sa `handle_alloc_error` alang sa sayup nga mga paggahin.
/// * Adunay sulud nga `ptr::Unique` ug sa ingon gitugutan ang mogamit sa tanan nga may kalabutan nga mga benepisyo.
/// * Gigamit ang sobra nga gibalik gikan sa tagahatag aron magamit ang labing kadaghan nga magamit nga kapasidad.
///
/// Kini nga tipo dili bisan pa susihon ang panumduman nga gidumala niini.Kung nahulog kini *buhian* ang panumduman niini, apan dili * kini pagsulay nga ihulog ang mga sulud niini.
/// Naa ra sa taggamit sa `RawVec` ang pagdumala sa tinuud nga mga butang *gitipig* sa sulud sa usa ka `RawVec`.
///
/// Hinumdomi nga ang sobra sa usa ka zero-size nga mga klase kanunay nga walay katapusan, busa ang `capacity()` kanunay nga ibalik ang `usize::MAX`.
/// Kini nagpasabut nga kinahanglan ka mag-amping sa paglibut sa kini nga tipo sa usa ka `Box<[T]>`, tungod kay ang `capacity()` dili makahatag sa gitas-on.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Anaa kini tungod kay ang `#[unstable]` `const fn`s dili kinahanglan nga magpahiuyon sa `min_const_fn` ug busa dili usab sila matawag nga`min_const_fn`s.
    ///
    /// Kung imong gibag-o ang `RawVec<T>::new` o mga pagsalig, palihug pag-amping nga dili ipaila ang bisan unsang butang nga makalapas sa `min_const_fn`.
    ///
    /// NOTE: Mahimo namon malikayan ang kini nga pag-hack ug susihon ang pagsunud sa pipila nga hiyas nga `#[rustc_force_min_const_fn]` nga nanginahanglan pagsunud sa `min_const_fn` apan dili kinahanglan nga tugutan ang pagtawag niini sa `stable(...) const fn`/user code nga dili mahimo ang `foo` kung adunay ang `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Naghimo labing kadaghan nga posible nga `RawVec` (sa tinapok sa sistema) nga wala paggahin.
    /// Kung ang `T` adunay positibo nga gidak-on, nan naghimo kini usa ka `RawVec` nga adunay kapasidad `0`.
    /// Kung ang `T` wala`y sukod sa sukat, nan naghimo kini usa ka `RawVec` nga adunay kapasidad `usize::MAX`.
    /// Mapuslanon alang sa pagpatuman sa nadugay nga alokasyon.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Naghimo usa ka `RawVec` (sa tumpok sa sistema) nga adunay eksakto nga kinahanglanon nga kapasidad ug paghanay alang sa usa ka `[T; capacity]`.
    /// Kini mao ang katumbas sa pagtawag `RawVec::new` sa diha nga `capacity` mao `0` o `T` mao ang zero-kadako.
    /// Hinumdomi nga kung ang `T` zero-kadako kini gipasabut nga dili ka *makakuha* usa ka `RawVec` nga adunay gihangyo nga kapasidad.
    ///
    /// # Panics
    ///
    /// Panics kung ang gihangyo nga kapasidad molapas sa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Sama sa `with_capacity`, apan gigarantiyahan ang buffer zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Gibag-o usab ang usa ka `RawVec` gikan sa usa ka pointer ug kapasidad.
    ///
    /// # Safety
    ///
    /// Ang `ptr` kinahanglan igahin (sa sistema nga tapok), ug uban ang gihatag nga `capacity`.
    /// Ang `capacity` dili molapas sa `isize::MAX` alang sa kadako nga mga lahi.(usa ra nga kabalak-an sa mga 32-bit nga sistema).
    /// Ang ZST vectors mahimong adunay kapasidad hangtod sa `usize::MAX`.
    /// Kung ang `ptr` ug `capacity` gikan sa usa ka `RawVec`, nan kini gigarantiyahan.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs mga amang.Laktaw ngadto:
    // - 8 kung ang gidak-on sa elemento 1, tungod kay ang bisan kinsa nga magtagana nga magbun-og lagmit nga magtingub sa usa ka hangyo nga dili moubos sa 8 bytes hangtod sa labing menos 8 bytes.
    //
    // - 4 kung ang mga elemento kasarangan ang kadako (<=1 KiB).
    // - Kung dili, aron malikayan ang pag-usik-usik sa daghang wanang sa labing mub-an nga Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Sama sa `new`, apan ang parameter sa pagpili sa tagahatag alang sa gipabalik nga `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` nagpasabot nga "unallocated".Ang mga tipo nga wala`y gidak-on wala tagda.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Sama sa `with_capacity`, apan ang parameter sa pagpili sa tagahatag alang sa gipabalik nga `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Sama sa `with_capacity_zeroed`, apan ang parameter sa pagpili sa tagahatag alang sa gipabalik nga `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Gikabig ang usa ka `Box<[T]>` ngadto sa usa ka `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Gikabig ang tibuuk nga buffer ngadto sa `Box<[MaybeUninit<T>]>` uban ang gipiho nga `len`.
    ///
    /// Hinumdomi nga kini husto nga pagbag-o sa bisan unsang mga pagbag-o nga `cap` nga mahimong nahimo.(Kitaa ang paghulagway sa tipo alang sa mga detalye.)
    ///
    /// # Safety
    ///
    /// * `len` kinahanglan nga labaw pa kay o itanding sa labing bag-o lang mihangyo kapasidad, ug
    /// * `len` kinahanglan mubu o katumbas sa `self.capacity()`.
    ///
    /// Hinumdomi, nga ang gihangyo nga kapasidad ug `self.capacity()` mahimo nga magkalainlain, tungod kay ang usa ka tagahatag mahimo nga mag-overallocate ug ibalik ang labi ka daghan nga memory block kaysa gihangyo.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Susihon ang katinlo sa usa ka katunga sa kinahanglanon sa kahilwasan (dili namon masusi ang uban pa nga katunga).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Gilikayan namon ang `unwrap_or_else` dinhi tungod kay gipamubu niini ang gidaghanon nga gihimo nga LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Gibag-o usab ang usa ka `RawVec` gikan sa usa ka pointer, kapasidad, ug tagahatag.
    ///
    /// # Safety
    ///
    /// Ang `ptr` kinahanglan igahin (pinaagi sa gihatag nga taghatag `alloc`), ug uban ang gihatag nga `capacity`.
    /// Ang `capacity` dili molapas sa `isize::MAX` alang sa kadako nga mga lahi.
    /// (usa ra nga kabalak-an sa mga 32-bit nga sistema).
    /// Ang ZST vectors mahimong adunay kapasidad hangtod sa `usize::MAX`.
    /// Kung ang `ptr` ug `capacity` gikan sa usa ka `RawVec` nga gihimo pinaagi sa `alloc`, nan kini gigarantiyahan.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Nakakuha usa ka hilaw nga tudlo sa pagsugod sa paggahin.
    /// Hinumdomi nga kini mao ang `Unique::dangling()` kung ang `capacity == 0` o `T` zero-size.
    /// Sa kaniadto nga kaso, kinahanglan ka magbantay.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Nakuha ang kapasidad sa paggahin.
    ///
    /// Kanunay kini nga `usize::MAX` kung ang `T` wala`y sukod sa gidak-on.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Nagbalik usa ka gipaambit nga pakisayran sa tagahatag nga nagpaluyo sa kini nga `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Adunay kami gitagana nga tipik sa memorya, aron mahimo namon nga ma-bypass ang mga pagsusi sa runtime aron makuha ang among karon nga layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Gisiguro nga ang buffer adunay sulud labing gamay nga igo nga wanang aron mapugngan ang mga elemento nga `len + additional`.
    /// Kung wala pa kini igo nga kapasidad, igahatag usab ang igo nga wanang plus komportable nga wanang sa wanang aron ma-amortize ang *O*(1) nga pamatasan.
    ///
    /// Limitahan ang kini nga pamatasan kung kini kinahanglan nga hinungdan sa panic.
    ///
    /// Kung ang `len` milapas sa `self.capacity()`, mahimo kini mapakyas sa aktwal nga paggahin sa gihangyo nga wanang.
    /// Kini mao ang dili tinuod nga luwas, apan ang dili luwas code * * isulat nga nagsalig sa sa kinaiya sa niini nga function aron sa pagguba.
    ///
    /// Maayo kini alang sa pagpatuman sa usa ka kadaghanan nga pagduso nga operasyon sama sa `extend`.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad molapas sa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // gitangtang o gi-panic ang reserba kung ang len milapas sa `isize::MAX` busa luwas kini nga buhaton nga wala ma-check karon.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Parehas sa `reserve`, apan ningbalik sa mga sayup imbis nga magpanic o mag-abort.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Gisiguro nga ang buffer adunay sulud labing gamay nga igo nga wanang aron mapugngan ang mga elemento nga `len + additional`.
    /// Kung wala pa kini, ibalhin usab ang minimum nga posible nga kantidad nga kinahanglan nga memorya.
    /// Sa katibuk-an mao gyud kini ang eksaktong kantidad sa kinahanglan nga memorya, apan sa prinsipyo libre ang naghatag sa labaw sa gipangayo namo.
    ///
    ///
    /// Kung ang `len` milapas sa `self.capacity()`, mahimo kini mapakyas sa aktwal nga paggahin sa gihangyo nga wanang.
    /// Kini mao ang dili tinuod nga luwas, apan ang dili luwas code * * isulat nga nagsalig sa sa kinaiya sa niini nga function aron sa pagguba.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad molapas sa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Parehas sa `reserve_exact`, apan ningbalik sa mga sayup imbis nga magpanic o mag-abort.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Gipakubus ang paggahin hangtod sa gitino nga kantidad.
    /// Kung ang gihatag nga kantidad mao ang 0, sa tinuud hingpit nga molihok.
    ///
    /// # Panics
    ///
    /// Panics kung ang gihatag nga kantidad *labi ka daghan* kaysa sa karon nga kapasidad.
    ///
    /// # Aborts
    ///
    /// Aborts sa OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Mobalik kung ang buffer kinahanglan nga motubo aron matuman ang gikinahanglan nga dugang nga kapasidad.
    /// Nag-una nga gigamit aron mahimo ang posible nga mga inlining nga reserba nga tawag nga wala`y pagsulud sa `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Kini nga pamaagi kasagarang gisugdan sa makadaghan.Mao nga gusto namon nga kini mahimo`g gamay kutob sa mahimo, aron mapaayo ang mga oras sa pagtipon.
    // Apan gusto usab namon nga ang kadaghanan sa mga sulud niini mahimo`g maisip nga statically computable kutob sa mahimo, aron mas paspas ang pagpadagan sa nahimo nga code.
    // Busa, kini nga pamaagi maampingong gisulat aron ang tanan nga code nga nagsalig sa `T` naa sa sulud niini, samtang ang kadaghanan sa code nga dili mosalig sa `T` kutob sa mahimo naa sa mga function nga dili generic nga labaw sa `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Kini nagsiguro sa pagtawag konteksto.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Tungod kay gibalik namon ang usa ka kapasidad nga `usize::MAX` kung ang `elem_size` mao
            // 0, ang pag-adto dinhi kinahanglan nagpasabut nga ang `RawVec` sobra ra.
            return Err(CapacityOverflow);
        }

        // Wala gyud kita mahimo bahin sa kini nga mga tseke, sa kasubo.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Gagarantiyahan niini ang kusog nga pagtubo.
        // Ang pagdoble dili mahimong mag-awas tungod kay ang `cap <= isize::MAX` ug ang lahi sa `cap` mao ang `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` dili generic nga labaw sa `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ang mga pagpugong sa kini nga pamaagi parehas ra sa mga naa sa `grow_amortized`, apan kini nga pamaagi sagad nga dili masubsob kanunay mao nga dili kaayo kini kritikal.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Tungod kay gibalik namon ang usa ka kapasidad nga `usize::MAX` kung ang gidak-on sa tipo
            // 0, ang pag-adto dinhi kinahanglan nagpasabut nga ang `RawVec` sobra ra.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` dili generic nga labaw sa `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ang kini nga kalihokan gawas sa `RawVec` aron maminusan ang mga oras sa pagtipon.Tan-awa ang komentaryo sa taas `RawVec::grow_amortized` alang sa mga detalye.
// (Ang parameter nga `A` dili hinungdanon, tungod kay ang gidaghanon sa lainlaing mga lahi nga `A` nga nakita sa praktis labi ka gamay kaysa sa numero nga `T` nga lahi.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Susihon ang sayup dinhi aron maminusan ang gidak-on sa `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Gisusi sa taghatag alang sa pagkaparehas sa pagkahanay
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Gipalaya ang memorya nga gipanag-iya sa `RawVec`*nga wala* gisulayan nga ihulog ang mga sulud niini.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Ang function sa sentral alang sa pagdumala sa sayup nga reserba.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kinahanglan namon garantiya ang mosunud:
// * Dili namon iggahin ang `> isize::MAX` byte-size nga mga butang.
// * Dili namon gipaawas ang `usize::MAX` ug tinuud nga naghatag gamay.
//
// Sa 64-bit kinahanglan ra namon nga susihon kung unsa ang pag-overflow tungod kay ang pagsulay sa paggahin sa `> isize::MAX` bytes siguradong mapakyas.
// Sa 32-bit ug 16-bit kinahanglan naton nga dugangan ang usa ka dugang nga guwardiya alang niini kung nagdagan kami sa usa ka platform nga mahimong magamit ang tanan nga 4GB sa wanang sa gumagamit, pananglitan, PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Usa ka sentral nga katungdanan nga responsable sa pag-asoy sa mga pag-agas sa kapasidad
// Masiguro niini nga ang pagmando sa code nga adunay kalabotan sa mga panics gamay ra tungod kay adunay usa ra ka lokasyon ang panics kaysa usa ka hugpong sa tibuuk nga module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}