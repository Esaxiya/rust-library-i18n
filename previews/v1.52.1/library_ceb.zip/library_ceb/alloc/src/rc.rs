//! Mga panudlo sa pag-ihap sa us aka sulud nga sulud.Ang 'Rc' nagpasabot alang sa 'Reference
//! Counted'.
//!
//! Naghatag ang tipo nga [`Rc<T>`][`Rc`] nga gipaambit nga pagpanag-iya sa usa ka kantidad nga tipo `T`, nga gigahin sa tambak.
//! Ang pagsangpit sa [`clone`][clone] sa [`Rc`] naghimo usa ka bag-ong tudlo sa parehas nga paggahin sa tapok.
//! Kung ang katapusan nga [`Rc`] pointer sa usa ka gihatag nga paggahin nadaot, ang kantidad nga gitipigan sa kanang alokasyon (kanunay nga gihisgutan nga "inner value") nahulog usab.
//!
//! Ang gipaambit nga mga pakisayran sa Rust dili motugot sa pagbag-o pinaagi sa default, ug ang [`Rc`] wala`y gawas: dili ka sa kasagaran makakuha usa ka mabalhin nga pakisayran sa usa ka butang sa sulud sa [`Rc`].
//! Kung kinahanglan nimo ang pagkabag-o, pagbutang usa ka [`Cell`] o [`RefCell`] sa sulud sa [`Rc`];tan-awa ang [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] naggamit pag-ihap nga dili atomiko nga pakisayran.
//! Kini nagpasabut nga ang overhead mubu kaayo, apan ang [`Rc`] dili mapadala taliwala sa mga sulud, ug tungod niini ang [`Rc`] wala ipatuman ang [`Send`][send].
//! Ingon usa ka sangputanan, susihon sa taghugpong Rust ang *sa pagtipon sa oras* nga wala nimo gipadala ang [`Rc`] taliwala sa mga sulud.
//! Kung kinahanglan nimo ang multi-thread, pag-ihap sa reperensya sa atomic, gamita ang [`sync::Arc`][arc].
//!
//! Ang pamaagi nga [`downgrade`][downgrade] mahimong magamit aron makahimo usa ka dili tag-iya nga [`Weak`] pointer.
//! Ang usa ka [`Weak`] pointer mahimo nga [`pag-upgrade`][pag-upgrade] d sa usa ka [`Rc`], apan ibalik niini ang [`None`] kung ang kantidad nga gitipig sa paggahin nahulog na.
//! Sa laing pagkasulti, ang `Weak` pointers dili magpadayon nga buhi ang kantidad sa sulud sa alokasyon;bisan pa, gipadayon nila * ang paggahin (ang backing store alang sa sulud nga kantidad) nga buhi.
//!
//! Ang usa ka siklo sa taliwala sa [`Rc`] pointers dili gyud mapakyas.
//! Tungod niini nga hinungdan, gigamit ang [`Weak`] aron masira ang mga siklo.
//! Pananglitan, ang usa ka punoan mahimo`g adunay kusug nga [`Rc`] mga panudlo gikan sa mga node sa ginikanan ngadto sa mga anak, ug mga panudlo nga [`Weak`] gikan sa mga bata balik sa ilang mga ginikanan.
//!
//! `Rc<T>` awtomatiko nga pag-undang sa `T` (pinaagi sa [`Deref`] trait), aron mahimo nimong tawagan ang mga pamaagi sa "T` sa usa ka kantidad nga tipo nga [`Rc<T>`][`Rc`].
//! Aron malikayan ang mga bangga sa ngalan sa mga pamaagi sa `T`, ang mga pamaagi sa [`Rc<T>`][`Rc`] mismo adunay kalabotan nga mga gimbuhaton, gitawag nga gigamit ang [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Ang mga pagpatuman sa traits sama sa `Clone` mahimo usab tawgon gamit ang hingpit nga kwalipikado nga syntax.
//! Ang ubang mga tawo gusto sa paggamit sa bug-os nga mga kwalipikado nga syntax, samtang ang uban gusto sa paggamit sa pamaagi-tawag syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax sa tawag sa pamaagi
//! let rc2 = rc.clone();
//! // Hingpit nga kwalipikado nga syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] dili awtomatikong pag-undang sa `T`, tungod kay ang pagkahulog sa sulud mahimo nga nahulog.
//!
//! # Mga pakisayran sa pag-clone
//!
//! Ang paghimo sa usa ka bag-ong pakisayran sa parehas nga alokasyon ingon usa ka adunay na nga giihap nga panudlo nga giihap nga pointer gihimo gamit ang `Clone` trait nga gipatuman alang sa [`Rc<T>`][`Rc`] ug [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ang duha nga mga syntax sa ubus managsama.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ug b parehas nga nagtudlo sa parehas nga lokasyon sa memorya ingon foo.
//! ```
//!
//! Ang `Rc::clone(&from)` syntax mao ang labi ka idiomatiko tungod kay kini labi ka tataw nga gipasabut ang gipasabut sa code.
//! Sa panig-ingnan sa ibabaw, kini nga syntax mas sayon sa pagtan-aw nga kini nga code mao ang pagmugna sa usa ka bag-o nga pakisayran kay sa pagkopya sa tibuok sulod sa Foo.
//!
//! # Examples
//!
//! Hunahunaa ang usa ka sitwasyon diin ang usa ka hugpong nga `Gadget` gipanag-iya sa usa ka gihatag nga `Owner`.
//! Gusto namon nga ipunting ang among `Gadget` sa ilang `Owner`.Dili namon kini mahimo uban ang talagsaon nga pagpanag-iya, tungod kay labaw pa sa usa ka gadget ang mahimong mahisakop sa parehas nga `Owner`.
//! [`Rc`] Gitugotan kami nga ipaambit ang usa ka `Owner` taliwala sa daghang `Gadget`s, ug magpadayon ang `Owner` nga gigahin samtang ang bisan unsang `Gadget` nga puntos dinhi.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... uban pang mga uma
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... uban pang mga uma
//! }
//!
//! fn main() {
//!     // Paghimo usa ka pakisayran nga giihap nga `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Paghimo `Gadget` nga iya sa `gadget_owner`.
//!     // Ang pag-clone sa `Rc<Owner>` naghatag kanamo usa ka bag-ong tudlo sa parehas nga alokasyon nga `Owner`, nga nagdugang sa ihap sa pakisayran sa proseso.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Paglabay sa among lokal nga variable `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Bisan pa nahulog ang `gadget_owner`, nakapag-print gihapon kami sa ngalan sa `Owner` sa `Gadget`s.
//!     // Tungod kay nahulog ra kami usa ka `Rc<Owner>`, dili ang `Owner` nga gipunting niini.
//!     // Hangtud nga adunay uban nga `Rc<Owner>` nga nagtudlo sa parehas nga `Owner` nga paggahin, kini magpabilin nga buhi.
//!     // Ang projection sa uma nga `gadget1.owner.name` molihok tungod kay ang `Rc<Owner>` awtomatikong wala pagdawat sa `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Sa pagtapos sa pagpaandar, ang `gadget1` ug `gadget2` nadaut, ug kauban nila ang katapusan nga giihap nga mga pakisayran sa among `Owner`.
//!     // Ang Gadget Man karon naguba usab.
//!     //
//! }
//! ```
//!
//! Kung ang pagbag-o sa among mga kinahanglanon, ug kinahanglan usab nga makaagi kami gikan sa `Owner` hangtod `Gadget`, makasinati kami og mga problema.
//! Ang usa ka [`Rc`] pointer gikan sa `Owner` hangtod `Gadget` nagpaila sa usa ka siklo.
//! Kini nagpasabut nga ang ilang mga ihap sa pakisayran dili gyud makaabut sa 0, ug ang paggahin dili gyud madaut:
//! usa ka leak sa panumduman.Aron makalibut dinhi, mahimo namon magamit ang [`Weak`] pointers.
//!
//! Ang Rust sa tinuud naghimo niini nga medyo lisud aron mahimo kini nga loop sa una nga lugar.Aron matapos ang duha nga kantidad nga nagtudlo sa usag usa, ang usa niini kinahanglan mabalhin.
//! Kini mao ang lisud nga, tungod kay [`Rc`] nagpatuman sa panumdoman sa kaluwasan pinaagi sa lamang sa paghatag sa mipakigbahin nga mga pakisayran ngadto sa bili niini wraps, ug kini dili motugot sa direkta nga mutasyon.
//! Kita kinahanglan nga wrap sa bahin sa bili gusto kita sa motransporm sa usa ka [`RefCell`], nga naghatag og *sulod mutability*: usa ka pamaagi aron makab-ot mutability pinaagi sa usa ka mipakigbahin pakisayran.
//! [`RefCell`] nagpatuman sa mga lagda sa pagpangutang sa Rust sa runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... uban pang mga uma
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... uban pang mga uma
//! }
//!
//! fn main() {
//!     // Paghimo usa ka pakisayran nga giihap nga `Owner`.
//!     // Hinumdomi nga gibutang namon ang 'Tag-iya's vector sa `Gadget`s sa sulud sa usa ka `RefCell` aron mahimo namon kini nga mutate pinaagi sa usa ka gipaambit nga reperensya.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Paghimo `Gadget` nga iya sa `gadget_owner`, sama kaniadto.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Idugang ang mga `Gadget`s sa ilang `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamikong paghulam natapos dinhi.
//!     }
//!
//!     // Iterate sa atong `Gadget`s, pag-imprinta sa ilang mga detalye sa gawas.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` usa ka `Weak<Gadget>`.
//!         // Tungod kay ang mga panudlo nga `Weak` dili makagarantiyahan nga adunay pa nga alokasyon, kinahanglan naton nga tawagan ang `upgrade`, nga mobalik sa usa ka `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Sa kini nga kaso nahibal-an namon nga ang paggahin naa pa, mao nga `unwrap` ra namon ang `Option`.
//!         // Sa usa ka labi ka komplikado nga programa, mahimo nimo nga kinahanglan ang pagdumala sa sayup nga sayup alang sa `None` nga sangputanan.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Sa pagtapos sa pagpaandar, ang `gadget_owner`, `gadget1`, ug `gadget2` nadaut.
//!     // Wala na karon mga kusug nga (`Rc`) nga tudlo sa mga gadget, busa nadaut sila.
//!     // Wala niini ang ihap sa pakisayran sa Gadget Man, busa nadaut usab siya.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Kini ang repr(C) to future-proof batok sa posible nga pag-usab sa uma, nga makabalda sa kung luwas nga luwas nga [into|from]_raw() sa mga mabalhin nga mga sulud nga sulud.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Usa ka sulud nga panudlo nga nag-ihap sa pakisayran.Ang 'Rc' nagpasabot alang sa 'Reference
/// Counted'.
///
/// Tan-awa ang [module-level documentation](./index.html) alang sa dugang nga mga detalye.
///
/// Ang mga kinaiyanhon nga pamaagi sa `Rc` tanan nga adunay kalabutan nga mga gimbuhaton, nga nagpasabut nga kinahanglan nimo sila tawagan ingon pananglit, [`Rc::get_mut(&mut value)`][get_mut] imbis nga `value.get_mut()`.
/// Naglikay kini nga magkasumpaki sa mga pamaagi sa sulud nga tipo nga `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ok kini nga kawalay kasigurohan tungod kay samtang buhi kini nga Rc gigarantiyahan namon nga ang sulud nga pointer balido.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Naghimo usa ka bag-ong `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Adunay usa ka implicit nga mahuyang nga pointer nga gipanag-iya sa tanan nga mga kusug nga tudlo, nga nagsiguro nga ang mahuyang nga destructor dili gyud makalaya sa paggahin samtang ang kusgan nga destructor nagdagan, bisan kung ang mahuyang nga pointer gitipig sa sulud sa kusgan.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Naghimo usa ka bag-ong `Rc<T>` gamit ang usa ka mahuyang nga pakisayran sa kaugalingon.
    /// Ang pagsulay sa pag-upgrade sa mahuyang nga pakisayran sa wala pa mobalik kini nga pag-andar magresulta sa usa ka kantidad nga `None`.
    ///
    /// Bisan pa, ang mahuyang nga pakisayran mahimo nga libre nga ma-clone ug tipunan aron magamit sa ulahi nga panahon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... dugang nga mga uma
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Paghimo sa sulud sa estado nga "uninitialized" nga adunay us aka mahuyang nga pakisayran.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Mahinungdanon nga dili namon biyaan ang pagpanag-iya sa mahuyang nga pahimangno, o kung dili ang memorya mahimo`g mapalaya sa oras nga mobalik ang `data_fn`.
        // Kon kita gusto nga moagi pagpanag-iya, mahimo kita paghimo sa usa ka dugang nga huyang nga pointer alang sa atong kaugalingon, apan kini moresulta sa dugang nga updates sa mga mahuyang ihap pakisayran nga dili mahimong gikinahanglan kon dili.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Lig-on nga mga pakisayran kinahanglan sa kinatibuk-iya sa usa ka mipakigbahin huyang nga reperensiya, mao nga dili modagan sa destructor alang sa atong daan nga mahuyang nga pakisayran.
        //
        mem::forget(weak);
        strong
    }

    /// Naghimo usa ka bag-ong `Rc` nga adunay uninitialized nga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Naghimo usa ka bag-ong `Rc` nga adunay uninitialized nga sulud, uban ang memorya nga napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Naghimo usa ka bag-ong `Rc<T>`, nagbalik usa ka sayup kung napakyas ang alokasyon
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Adunay usa ka implicit nga mahuyang nga pointer nga gipanag-iya sa tanan nga mga kusug nga tudlo, nga nagsiguro nga ang mahuyang nga destructor dili gyud makalaya sa paggahin samtang ang kusgan nga destructor nagdagan, bisan kung ang mahuyang nga pointer gitipig sa sulud sa kusgan.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Naghimo usa ka bag-ong `Rc` nga adunay uninitialized nga sulud, ningbalik usa ka sayup kung napakyas ang alokasyon
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Naghimo usa ka bag-ong `Rc` nga adunay uninitialized nga sulud, uban ang memorya nga napuno sa `0` bytes, nga nagbalik usa ka sayup kung napakyas ang alokasyon
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Nagtukod sa usa ka bag-o nga `Pin<Rc<T>>`.
    /// Kung ang `T` wala ipatuman ang `Unpin`, kung ingon niana ang `value` ma-pin sa memorya ug dili mabalhin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Gibalik ang sulud nga kantidad, kung ang `Rc` adunay eksaktong usa ka kusug nga pakisayran.
    ///
    /// Kung dili, ang usa ka [`Err`] gibalik nga adunay parehas nga `Rc` nga gipasa.
    ///
    ///
    /// Kini molampos bisan kung adunay mga talagsaon nga mahuyang nga pakisayran.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopyahon ang sulud nga butang

                // Isulat sa Weaks nga dili sila mahimong gipasiugda sa decrementing sa lig-on nga ihap, ug unya kuhaa ang bug-os nga "strong weak" pointer samtang usab pagdumala drop katarungan pinaagi sa lang sa pagmugna sa usa ka peke nga Maluya.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Naghimo usa ka bag-ong hiwa nga naihap sa pakisayran nga adunay wala`y sulod nga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Naghimo usa ka bag-ong slice nga naihap sa pakisayran nga adunay wala nahibal-an nga sulud, nga ang panumduman napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Nakabig sa `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang sulud nga kantidad naa gyud sa pasiunang estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Nakabig sa `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang sulud nga kantidad naa gyud sa pasiunang estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Natapos ang `Rc`, gibalik ang giputos nga pointer.
    ///
    /// Aron malikayan ang usa ka memory leak ang pointer kinahanglan nga ibalik sa usa ka `Rc` gamit ang [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Naghatag usa ka hilaw nga puntos sa datos.
    ///
    /// Ang mga ihap dili apektado sa bisan unsang paagi ug ang `Rc` dili mahurot.
    /// Ang panudlo balido hangtod nga adunay mga makusog nga ihap sa `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // KALUWASAN: Dili kini makaagi sa Deref::deref o Rc::inner tungod kay
        // gikinahanglan kini aron mapadayon ang raw/mut nga pagpanan-aw ingon pananglit
        // `get_mut` makasulat pinaagi sa pointer pagkahuman makuha ang Rc pinaagi sa `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Naghimo usa ka `Rc<T>` gikan sa usa ka hilaw nga pahimangno.
    ///
    /// Ang hilaw nga pointer kinahanglan nga gibalik kaniadto sa usa ka tawag sa [`Rc<U>::into_raw`][into_raw] diin ang `U` kinahanglan adunay parehas nga gidak-on ug paghanay sa `T`.
    /// Kini gamay nga hinungdan kung ang `U` mao ang `T`.
    /// Hinumdomi nga kung ang `U` dili `T` apan adunay parehas nga kadako ug paghanay, kini sa panguna sama sa pagbalhin sa mga pakisayran sa lainlaing mga lahi.
    /// Tan-awa ang [`mem::transmute`][transmute] alang sa dugang nga kasayuran kung unsang mga pagdili ang magamit sa kini nga kaso.
    ///
    /// Kinahanglan nga masiguro sa naggamit sa `from_raw` usa ka piho nga kantidad nga `T` kausa ra nahulog.
    ///
    /// Ang kini nga pag-andar dili luwas tungod kay ang dili husto nga paggamit mahimong mosangput sa pagkadili malig-on sa memorya, bisan kung ang giuli nga `Rc<T>` wala gyud ma-access.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pag-usab balik sa usa ka `Rc` aron malikayan ang pagtulo.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ang dugang nga mga tawag sa `Rc::from_raw(x_ptr)` mahimong dili luwas sa memorya.
    /// }
    ///
    /// // handumanan sa gibuhian sa diha nga `x` migula sa kasangkaran sa ibabaw, mao nga `x_ptr` karon nagbitay!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Balihon ang offset aron makapangita ang orihinal nga RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Nagmugna sa usa ka bag-o nga [`Weak`] pointer sa alokasyon niini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Siguruha nga dili kami maghimo usa ka nagbitay nga Luya
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Nakuha ang numero nga [`Weak`] nga mga panudlo sa kini nga paggahin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Nakuha ang ihap sa kusgan nga mga panudlo nga (`Rc`) sa kini nga paggahin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Gibalik ang `true` kung wala'y uban pang mga panudlo nga `Rc` o [`Weak`] sa kini nga paggahin.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Gibalik ang usa ka mabalhin nga pakisayran sa gihatag nga `Rc`, kung wala`y uban pang mga panudlo nga `Rc` o [`Weak`] sa parehas nga paggahin.
    ///
    ///
    /// Gibalik ang [`None`] kung dili, tungod kay dili kini luwas nga mutate ang usa nga gipaambit nga kantidad.
    ///
    /// Tan-awa usab ang [`make_mut`][make_mut], nga mahimo [`clone`][clone] sa sulud nga kantidad kung adunay uban pang mga panudlo.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Nagbalik usa ka mabalhin nga pakisayran sa gihatag nga `Rc`, nga wala`y bisan unsang tseke.
    ///
    /// Tan-awa usab ang [`get_mut`], nga luwas ug angayan nga mga tseke.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ang bisan unsang uban pang mga `Rc` o [`Weak`] nga mga panudlo sa parehas nga paggahin dili kinahanglan nga tangtangon alang sa gidugayon sa nauli nga hulam.
    ///
    /// Kini ang hinungdan kung wala ang ingon nga mga panudlo, pananglitan pananglitan pagkahuman sa `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Nag-amping kami nga *dili* maghimo usa ka pakisayran nga naglangkob sa mga natad sa "count", tungod kay magkasumpaki kini sa mga pag-access sa mga ihap sa pakisayran (pananglitan
        // ni `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Gibalik ang `true` kung ang duha nga `Rc` nagpunting sa parehas nga alokasyon (sa usa ka ugat nga parehas sa [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Naghimo usa ka mabalhin nga pakisayran sa gihatag nga `Rc`.
    ///
    /// Kon adunay uban nga mga `Rc` pointers sa mao gihapon nga alokasyon, unya `make_mut` ang [`clone`] sa sulod nga bili sa usa ka bag-o nga alokasyon aron sa pagsiguro sa talagsaon nga pagpanag-iya.
    /// Gitawag usab kini nga clone-on-sulat.
    ///
    /// Kung wala'y uban pang mga panudlo nga `Rc` sa kini nga paggahin, unya ang mga panudlo nga [`Weak`] sa kini nga paggahin matangtang.
    ///
    /// Tan-awa usab ang [`get_mut`], nga mapakyas kaysa pag-clone.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Dili ma-clone bisan unsa
    /// let mut other_data = Rc::clone(&data);    // Dili ma-clone ang sulud nga datos
    /// *Rc::make_mut(&mut data) += 1;        // Pag-clone sa sulud nga datos
    /// *Rc::make_mut(&mut data) += 1;        // Dili ma-clone bisan unsa
    /// *Rc::make_mut(&mut other_data) *= 2;  // Dili ma-clone bisan unsa
    ///
    /// // Karon ang `data` ug `other_data` nagpunting sa lainlaing mga alokasyon.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ang mga tudlo mawala na:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Kinahanglan nga i-clone ang datos, adunay uban pang mga Rcs.
            // Pauna nga gigahin ang panumduman aron direkta nga masulat ang cloned nga kantidad.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Mahimo ra kawaton ang datos, ang nahabilin ra mao ang Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Kuhaa ang gipakita nga kusganon nga ref (dili kinahanglan nga maghimo usa ka peke nga Maluya dinhi-nahibal-an namon nga ang ubang mga Weaks mahimo nga maghinlo alang kanamo)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ok kini nga kawalay kasigurohan tungod kay gigarantiyahan namon nga ang tudlo nga gibalik mao ra ang *tudlo* nga mahibalik sa T.
        // Ang among ihap sa pakisayran gigarantiyahan nga mahimong 1 sa kini nga punto, ug kinahanglan namon ang `Rc<T>` mismo nga mahimong `mut`, busa gibalik namon ang posible nga reperensya sa paggahin.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Gisulayan nga ipaubus ang `Rc<dyn Any>` sa usa ka konkreto nga tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Naggahin sa usa ka `RcBox<T>` nga adunay igong wanang alang sa usa ka posible nga wala gisulud nga sulud nga kantidad diin ang kantidad adunay gihatag nga layout.
    ///
    /// Ang pag-andar `mem_to_rcbox` gitawag uban ang data pointer ug kinahanglan ibalik ang usa ka (posible nga tambok)-paghatag alang sa `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Kalkula ang layout gamit ang gihatag nga layout sa kantidad.
        // Kaniadto, ang layout gikalkulo sa ekspresyon nga `&*(ptr as* const RcBox<T>)`, apan naghimo kini usa ka sayup nga reperensiya (tan-awa ang #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Naggahin sa usa ka `RcBox<T>` nga adunay igong wanang alang sa usa ka posible nga wala gisulud nga sulud nga kantidad diin ang kantidad adunay gihatag nga layout, nga nagbalik usa ka sayup kung napakyas ang paggahin.
    ///
    ///
    /// Ang pag-andar `mem_to_rcbox` gitawag uban ang data pointer ug kinahanglan ibalik ang usa ka (posible nga tambok)-paghatag alang sa `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Kalkula ang layout gamit ang gihatag nga layout sa kantidad.
        // Kaniadto, ang layout gikalkulo sa ekspresyon nga `&*(ptr as* const RcBox<T>)`, apan naghimo kini usa ka sayup nga reperensiya (tan-awa ang #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Paghatag alang sa layout.
        let ptr = allocate(layout)?;

        // Ig-una ang RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Naghatag sa usa ka `RcBox<T>` nga adunay igong wanang alang sa usa ka wala`y sukod nga sulud nga kantidad
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Paghatag alang sa `RcBox<T>` gamit ang gihatag nga kantidad.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopyaha ang kantidad ingon mga byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libre ang alokasyon nga dili ihulog ang sulud niini
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Naghatag usa ka `RcBox<[T]>` nga adunay gihatag nga gitas-on.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopyaha ang mga elemento gikan sa hiwa sa bag-ong gigahin nga Rc <\[T\]>
    ///
    /// Dili luwas tungod kay ang nanawag kinahanglan manag-iya o magbugkos sa `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Naghimo usa ka `Rc<[T]>` gikan sa usa ka iterator nga nahibal-an nga adunay usa ka piho nga gidak-on.
    ///
    /// Dili matino ang kinaiya kung sayup ang sukod.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic nga guwardya samtang gi-clone ang mga elemento sa T.
        // Sa panghitabo sa usa ka panic, ang mga elemento nga gisulat sa bag-ong RcBox mahulog, pagkahuman buhian ang memorya.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Itudlo ang una nga elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tin-aw ang tanan.Kalimtan ang guwardiya aron dili kini makalaya sa bag-ong RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Espesyalista nga trait gigamit alang sa `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Gitulo ang `Rc`.
    ///
    /// Pagminusan niini ang kusug nga ihap sa pakisayran.
    /// Kung ang kusganon nga ihap sa pakisayran naabot sa zero unya ang uban ra nga mga pakisayran (kung adunay) mao ang [`Weak`], busa `drop` namon ang sulud nga kantidad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Wala`y bisan unsang giimprinta
    /// drop(foo2);   // Mga print "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // gubaon ang sulud nga butang
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // tangtanga ang gipakita nga "strong weak" pointer karon nga nadaut namon ang sulud.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Naghimo usa ka clone sa `Rc` pointer.
    ///
    /// Naghimo kini usa pa nga tudlo sa parehas nga alokasyon, nagdugang ang kusug nga ihap sa pakisayran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Naghimo usa ka bag-ong `Rc<T>`, nga adunay kantidad nga `Default` alang sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Pag-hack aron matugotan ang pag-espesyalisar sa `Eq` bisan kung ang `Eq` adunay pamaagi.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Gihimo namon kini nga pagdadalubhasa dinhi, ug dili ingon usa ka labi ka kadaghanan nga pag-optimize sa `&T`, tungod kay kung dili kini makadugang usa ka gasto sa tanan nga mga pagsusi sa pagkaparehas sa mga ref
/// Giingon namon nga ang `Rc`s gigamit sa pagtipig daghang mga kantidad, nga hinay nga i-clone, apan bug-at usab aron masusi kung parehas, hinungdan nga dali nga mabayran kini nga gasto.
///
/// Labi usab nga adunay posibilidad nga adunay duha ka `Rc` clone, nga nagpunting sa parehas nga kantidad, kaysa sa duha nga `&T`s.
///
/// Mahimo ra naton kini kung ang `T: Eq` ingon usa ka `PartialEq` mahimong tinuyo nga dili molihok.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Pagkaparehas alang sa duha ka `Rc`s.
    ///
    /// Duha ka `Rc` ang managsama kung managsama ang sulud nga panagsama, bisan kung gitipig kini sa lainlaing paggahin.
    ///
    /// Kon `T` usab implementar `Eq` (nga nagpasabot reflexivity sa pagkasama), duha ka `Rc`s nga punto sa sa mao gihapon nga alokasyon mao ang kanunay nga managsama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Dili managsama alang sa duha nga `Rc`s.
    ///
    /// Duha ka `Rc` ang dili managsama kung ang panloob nga kantidad dili parehas.
    ///
    /// Kung gipatuman usab sa `T` ang `Eq` (nagpasabot nga reflexivity of equality), ang duha nga `Rc` nga nagtudlo sa parehas nga paggahin dili gyud parehas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Bahag nga pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `partial_cmp()` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mas gamay kaysa pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `<` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Mas gamay pa o katumbas sa' pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `<=` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Labi ka daghan kaysa pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `>` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Labaw sa o katumbas sa' pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `>=` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Pagtandi alang sa duha nga `Rc`s.
    ///
    /// Gitandi ang duha pinaagi sa pagtawag sa `cmp()` sa ilang sulud nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Paghatag usa ka hiwa nga naihap sa pakisayran ug pun-a kini pinaagi sa pag-clone sa mga item sa 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Pag-alok sa usa ka hiwa nga gikutip sa panudlo nga gikutip ug kopyaha ang `v` niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Pag-alok sa usa ka hiwa nga gikutip sa panudlo nga gikutip ug kopyaha ang `v` niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Pagbalhin sa usa ka kahon nga butang sa usa ka bag-o, giihap nga pakisayran, paggahin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Paghatag usa ka hiwa nga naihap sa pakisayran ug ibalhin ang mga butang sa `v` ngadto niini.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Tugoti ang Vec nga buhian ang memorya niini, apan dili gub-a ang mga sulud niini
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Gikuha ang matag elemento sa `Iterator` ug gikolekta kini sa usa ka `Rc<[T]>`.
    ///
    /// # Mga kinaiya sa paghimo
    ///
    /// ## Ang kinatibuk-ang kaso
    ///
    /// Sa kinatibuk-an nga kaso, ang pagkolekta sa `Rc<[T]>` gihimo pinaagi sa una nga pagkolekta sa usa ka `Vec<T>`.Kana kung nagsulat sa mosunud:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ninglihok kini ingon kung nagsulat kami:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ang una nga hugpong sa mga paggahin mahitabo dinhi.
    ///     .into(); // Ang ikaduha nga paggahin alang sa `Rc<[T]>` mahitabo dinhi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Kini mogahin ingon nga sa daghan nga mga panahon sama sa gikinahanglan alang sa pagtukod sa `Vec<T>` ug unya kini paggahin sa makausa alang sa milingi sa `Vec<T>` ngadto sa `Rc<[T]>`.
    ///
    ///
    /// ## Iterator nga nahibal-an ang gitas-on
    ///
    /// Sa diha nga ang imong `Iterator` implementar `TrustedLen` ug sa usa ka tukma nga gidak-on, usa ka ka alokasyon nga gihimo alang sa `Rc<[T]>`.Pananglitan:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Usa ra nga alokasyon ang nahinabo dinhi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Ang espesyalista nga trait gigamit alang sa pagkolekta sa `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Kini ang kaso alang sa usa ka `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Kita kinahanglan aron sa pagsiguro nga ang iterator adunay usa ka tukma nga gitas-on ug kita adunay.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Mobalik sa normal nga pagpatuman.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` usa ka bersyon sa [`Rc`] nga adunay paghisgot nga dili pagpanag-iya sa gidumala nga paggahin.Gi-access ang alokasyon pinaagi sa pagtawag sa [`upgrade`] sa `Weak` pointer, nga nagbalik usa ka [`Option`]`<`[`Rc`]`<T>>`.
///
/// Tungod kay ang usa ka pakisayran sa `Weak` dili maihap padulong sa pagpanag-iya, dili niini mapugngan ang kantidad nga gitipig sa alokasyon gikan sa pagkahulog, ug ang `Weak` mismo wala`y garantiya bahin sa kantidad nga naa pa.
/// Mao kini ang kini mobalik [`None`] sa diha nga [`upgrade`] d.
/// Hinuon hinumdomi nga ang usa ka pakisayran nga `Weak`*dili* nagpugong sa paggahin mismo (ang backing store) gikan sa pag-deallocated.
///
/// Ang usa ka `Weak` pointer mapuslanon alang sa pagpadayon sa usa ka temporaryo nga reperensya sa alokasyon nga gidumala sa [`Rc`] nga dili mapugngan ang pagkahulog sa sulud niini.
/// Gigamit usab kini aron mapugngan ang mga lingin nga pakisayran taliwala sa mga pointers nga [`Rc`], tungod kay ang pagtag-iya sa us aka tag-iya nga mga pakisayran dili gyud tugotan nga mahulog ang bisan unsang [`Rc`].
/// Pananglitan, ang usa ka punoan mahimo`g adunay kusug nga [`Rc`] mga panudlo gikan sa mga node sa ginikanan ngadto sa mga anak, ug mga panudlo nga `Weak` gikan sa mga bata balik sa ilang mga ginikanan.
///
/// Ang kasagaran nga paagi aron makakuha usa ka `Weak` pointer mao ang pagtawag sa [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Kini usa ka `NonNull` aron tugotan ang pag-optimize sa gidak-on sa kini nga tipo sa mga enum, apan dili kini kinahanglan nga usa ka balido nga panudlo.
    //
    // `Weak::new` gitakda kini sa `usize::MAX` aron dili kinahanglan nga maghatag og wanang sa tapok.
    // Dili kana ang kantidad nga maangkon sa usa ka tinuud nga pointer tungod kay ang RcBox adunay pag-align labing menos 2.
    // Posible ra kini kung `T: Sized`;wala'y sukod ang `T` nga wala maglabad.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Naghimo usa ka bag-ong `Weak<T>`, nga wala paggahin bisan unsang memorya.
    /// Ang pagtawag sa [`upgrade`] sa pagbalik nga kantidad kanunay naghatag [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Magtatabang type sa pagtugot sa access sa mga pakisayran importante nga walay mga pag bisan unsa nga pangangkon mahitungod sa kapatagan data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Gibalik ang usa ka hilaw nga panudlo sa butang nga `T` nga gitudlo sa kini nga `Weak<T>`.
    ///
    /// Ang panudlo balido ra kung adunay pila ka kusug nga pakisayran.
    /// Ang pointer mahimo nga nagbitay, dili nakahanay o bisan [`null`] kung dili.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Parehas nga nagtudlo sa parehas nga butang
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ang kusgan dinhi nagbuhi niini, mao nga mahimo naton nga ma-access ang butang.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Apan dili na.
    /// // Mahimo naton ang weak.as_ptr(), apan ang pag-access sa pointer mosangput sa wala matino nga pamatasan.
    /// // assert_eq! ("hello", dili luwas {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kung ang pointer nagbitay, ibalik namon ang sentinel direkta.
            // Dili kini mahimo nga usa ka balido nga adres sa payload, tungod kay ang payload labing menos nga nakahanay sa RcBox (usize).
            ptr as *const T
        } else {
            // KALUWASAN: kung ang_dangling mobalik nga bakak, nan ang tudlo dili madaut.
            // Ang payload mahimong ihulog sa kini nga punto, ug kinahanglan namon ipadayon ang pagkamatuud, busa gamiton ang hilaw nga pagmaniobra sa pointer.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Gikonsumo ang `Weak<T>` ug gihimo kini nga usa ka hilaw nga puntos.
    ///
    /// Gibalhin niini ang mahuyang nga pahimangno ngadto sa usa ka hilaw nga pahimangno, samtang gipadayon pa ang pagpanag-iya sa usa ka mahuyang nga pakisayran (ang mahuyang nga ihap dili gibag-o sa kini nga operasyon).
    /// Mahimo kini ibalik sa `Weak<T>` nga adunay [`from_raw`].
    ///
    /// Ang parehas nga mga pagdili sa pag-access sa target sa pointer ingon sa [`as_ptr`] magamit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Gikabig ang usa ka hilaw nga pahimangno kaniadto nga gihimo sa [`into_raw`] balik sa `Weak<T>`.
    ///
    /// Mahimo kini gamiton aron luwas makuha ang usa ka kusgan nga pakisayran (pinaagi sa pagtawag sa [`upgrade`] sa ulahi) o aron mabalhin ang huyang nga ihap pinaagi sa paghulog sa `Weak<T>`.
    ///
    /// Gikinahanglan ang pagpanag-iya sa us aka mahuyang nga pakisayran (gawas sa mga panudlo nga gihimo sa [`new`], tungod kay wala`y kini bisan unsa; ang pamaagi molihok pa usab sa kanila).
    ///
    /// # Safety
    ///
    /// Ang pointer kinahanglan nga naggikan sa [`into_raw`] ug kinahanglan nga tag-iya usab ang potensyal nga mahuyang nga pakisayran niini.
    ///
    /// Gitugotan ang kusog nga ihap nga 0 sa oras nga pagtawag niini.
    /// Bisan pa niana, kini nagkinahanglan pagpanag-iya sa usa ka huyang nga paghisgot karon girepresentahan ingon sa usa ka hilaw nga pointer (sa mga mahuyang ihap dili giusab pinaagi sa operasyon niini) ug busa kini kinahanglan nga gikauban sa usa ka miaging tawag sa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Pagkunhod sa katapusan nga mahuyang nga ihap.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tan-awa ang Weak::as_ptr alang sa konteksto kung giunsa makuha ang input pointer.

        let ptr = if is_dangling(ptr as *mut T) {
            // Kini usa ka nagbitay nga Luya.
            ptr as *mut RcBox<T>
        } else {
            // Kung dili man, gigarantiyahan namon nga ang pointer naggikan sa usa ka wala`y katapusan nga Hinay.
            // KALUWASAN: ang data_offset luwas tawgon, tungod kay ang mga ptr nagpasabut usa ka tinuud (mahimo nga nahulog) T.
            let offset = unsafe { data_offset(ptr) };
            // Sa ingon, gibaliktad namon ang offset aron makuha ang tibuuk nga RcBox.
            // KALUWASAN: ang pointer naggikan sa usa ka Maluya, busa kini nga offset luwas.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: kita karon nabawi ang orihinal nga Huyang pointer, aron sa pagmugna sa Huyang.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Mga pagsulay sa pag-upgrade sa `Weak` pointer sa usa ka [`Rc`], pagpalangan sa paghulog sa sulud nga kantidad kung malampuson.
    ///
    ///
    /// Gibalik ang [`None`] kung ang sulud nga kantidad nahulog na.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Gub-a ang tanan nga kusgan nga mga panudlo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Nakuha ang numero sa kusgan nga mga panudlo nga (`Rc`) nga nagtudlo sa kini nga paggahin.
    ///
    /// Kung ang `self` gihimo gamit ang [`Weak::new`], ibalik niini ang 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Nakuha ang numero sa mga panudlo nga `Weak` nga nagtudlo sa kini nga paggahin.
    ///
    /// Kung wala magpabilin nga kusug nga mga tudlo, kini mobalik zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ibawas ang gipasabut nga huyang nga ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Gibalik ang `None` kung ang pointer nagbitay ug wala gigahin nga `RcBox`, (ie, kaniadtong `Weak` gihimo sa `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Nag-amping kami nga *dili* maghimo usa ka pakisayran nga naglangkob sa "data" nga natad, tungod kay ang umahan mahimo nga mutate dungan (pananglitan, kung ang katapusan nga `Rc` nahulog, ang natad sa datos mahulog sa lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Gibalik ang `true` kung ang duha nga `Weak` nagtudlo sa parehas nga alokasyon (parehas sa [`ptr::eq`]), o kung pareho nga wala magtudlo sa bisan unsang alokasyon (tungod kay gihimo kini nga `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Tungod kay gitandi niini ang mga panudlo nagpasabut kini nga ang `Weak::new()` managsama sa matag usa, bisan kung wala nila itudlo ang bisan unsang alokasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Pagtandi sa `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Gitulo ang `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Wala`y bisan unsang giimprinta
    /// drop(foo);        // Mga print "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ang mahuyang nga ihap magsugod sa 1, ug moadto ra sa zero kung nawala ang tanan nga kusgan nga mga panudlo.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Naghimo usa ka clone sa `Weak` pointer nga nagtudlo sa parehas nga gahin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Naghimo usa ka bag-ong `Weak<T>`, naggahin og memorya alang sa `T` nga wala kini gipili.
    /// Ang pagtawag sa [`upgrade`] sa pagbalik nga kantidad kanunay naghatag [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Gisusi namon_add dinhi aron maluwas ang mem::forget nga luwas.Sa partikular
// kon ikaw mem::forget RCS (o Weaks), ang ref-ihap mahimo magaawas, ug unya ang imong mahimo sa pagluwas sa alokasyon samtang talagsaong RCS (o Weaks) ania.
//
// Nag-abort kami tungod kay kini usa ka grabe nga senaryo nga wala kami igsapayan kung unsa ang mahitabo-wala`y tinuud nga programa ang kinahanglan makasinati niini.
//
// Kini kinahanglan nga adunay gipasagdan sa overhead tungod kay dili nimo kinahanglan nga ma-clone kini labi sa Rust salamat sa pagpanag-iya ug mga move-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Gusto namon nga ihulog sa sobra nga pag-awas imbis ihulog ang kantidad.
        // Ang ihap sa pakisayran dili gyud mahimong zero kung kini gitawag;
        // bisan pa, gisal-ot namon ang usa ka aborsyon dinhi aron ipahibalo ang LLVM sa usa ka laktod nga pagkulang nga na-optimize.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Gusto namon nga ihulog sa sobra nga pag-awas imbis ihulog ang kantidad.
        // Ang ihap sa pakisayran dili gyud mahimong zero kung kini gitawag;
        // bisan pa, gisal-ot namon ang usa ka aborsyon dinhi aron ipahibalo ang LLVM sa usa ka laktod nga pagkulang nga na-optimize.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kuhaa ang offset sa sulud sa usa ka `RcBox` alang sa payload sa likod sa usa ka pointer.
///
/// # Safety
///
/// Ang tudlo kinahanglan magtudlo sa (ug adunay balido nga metadata alang) us aka una nga balido nga pananglitan sa T, apan ang T gitugotan nga ihulog.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ihanay ang wala`y sukod nga kantidad hangtod sa katapusan sa RcBox.
    // Tungod kay ang RcBox mao ang repr(C), kanunay kini ang katapusan nga natad sa memorya.
    // KALUWASAN: tungod kay ang mahimo ra nga wala`y kadako nga mga lahi nga mahimo mao ang mga hiwa, trait nga mga butang,
    // ug extern matang, ang input sa kaluwasan kinahanglanon mao karon igo sa pagtagbaw sa mga gikinahanglan sa align_of_val_raw;kini usa ka detalye sa pagpatuman sa sinultian nga mahimong dili masaligan sa gawas sa std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}