use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ang pagsulat sa usa ka pagsulay sa panagsama tali sa mga taghatag sa ikatulo nga partido ug `RawVec` usa ka gamay nga limbong tungod kay ang `RawVec` API wala ibutyag ang mga sayup nga pamaagi sa paggahin, busa dili namon masusi kung unsa ang nahinabo kung nahuman na ang tighatag (lapas sa pagkakita sa usa ka panic).
    //
    //
    // Hinunoa, kini nga matarung tseke nga ang `RawVec` mga paagi sa pagbuhat sa labing menos go pinaagi sa Allocator API sa diha nga kini reserves storage.
    //
    //
    //
    //
    //

    // Ang usa ka amang nga taghatag nga nag-ut-ut sa usa ka pirmi nga kantidad nga gasolina sa wala pa ang mga pagsulay sa paggahin nagsugod nga pagkawang.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (hinungdan sa usa ka realloc, sa ingon naggamit 50 + 150=200 nga mga yunit sa gasolina)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Una, ang `reserve` naggahin sama sa `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Ang 97 labaw pa sa doble sa 7, busa ang `reserve` kinahanglan molihok sama sa `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Ang 3 mas mubu sa katunga sa 12, busa ang `reserve` kinahanglan molambo nga kusog.
        // Sa pagsulat niini nga pagsulay mao ang pagtubo nga hinungdan mao ang 2, busa ang bag-ong kapasidad mao ang 24, bisan pa, ang hinungdan nga motubo nga 1.5 OK ra usab.
        //
        // Tungod niini ang `>= 18` nagpahayag.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}