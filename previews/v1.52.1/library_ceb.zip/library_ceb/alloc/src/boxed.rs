//! Usa ka tipo sa pointer alang sa alokasyon nga tapok.
//!
//! [`Box<T>`], kaswal nga gipunting ingon usa ka 'box', naghatag labing yano nga porma sa paggahin nga tapok sa Rust.Gihatag sa mga kahon ang pagpanag-iya alang sa kini nga paggahin, ug ihulog ang ilang mga sulud kung wala na sila sa sakup.Gisiguro usab sa mga kahon nga dili gyud sila mogahin labaw pa sa `isize::MAX` bytes.
//!
//! # Examples
//!
//! Pagbalhin sa usa ka kantidad gikan sa stack sa tumpok pinaagi sa paghimo sa usa ka [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Pagbalhin sa usa ka kantidad gikan sa usa ka [`Box`] balik sa stack sa [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Paghimo usa ka recursive nga istruktura sa datos:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Ig-print niini ang `Cons (1, Cons(2, Nil))`.
//!
//! Ang mga recursive nga istruktura kinahanglan kinahanglan nga boxed, tungod kay kung ang kahulugan sa `Cons` ingon niini:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Dili kini molihok.Kini tungod kay ang kadak-an sa usa ka `List` nagsalig kung pila ka mga elemento ang naa sa lista, ug busa wala kami nahibal-an kung unsang kadaghan nga memorya ang igahin alang sa usa ka `Cons`.Pinaagi sa pagpaila sa usa ka [`Box<T>`], nga adunay gihubit nga gidak-on, nahibal-an namon kung unsa ka dako ang kinahanglan nga `Cons`.
//!
//! # Layout sa memorya
//!
//! Alang sa mga wala`y sukod nga kantidad nga kantidad, usa ka [`Box`] ang mogamit sa [`Global`] nga tagahatag alang sa paggahin niini.Balido ang pagbag-o sa parehas nga paagi taliwala sa usa ka [`Box`] ug usa ka hilaw nga pointer nga gigahin sa taghatag nga [`Global`], nga gihatag nga ang [`Layout`] nga gigamit sa tagahatag mao ang husto alang sa tipo.
//!
//! Mas tukma, ang usa ka `value:*mut T` nga gigahin uban ang tighatag nga [`Global`] nga adunay `Layout::for_value(&* value)` mahimong mabalhin sa usa ka kahon gamit ang [`Box::<T>::from_raw(value)`].
//! Sa kasukwahi, ang panumduman nga nagpaluyo sa usa ka `value:*mut T` nga nakuha gikan sa [`Box::<T>::into_raw`] mahimong makigsabutsabot gamit ang [`Global`] nga tagahatag nga adunay [`Layout::for_value(&* value)`].
//!
//! Alang sa mga zero-kadako nga kantidad, ang `Box` pointer kinahanglan pa usab nga [valid] alang sa mga pagbasa ug pagsulat ug igo nga nakahanay.
//! Sa partikular, ang paglabay sa bisan unsang nakahanay nga non-zero integer nga literal sa usa ka hilaw nga pahimangno naghimo usa ka balido nga panudlo, apan ang usa ka pointer nga nagtudlo sa kaniadto nga gigahin nga panumduman nga sukad napagawas dili na balido.
//! Ang girekomenda nga paagi aron makahimo usa ka Kahon sa usa ka ZST kung dili magamit ang `Box::new` mao ang paggamit sa [`ptr::NonNull::dangling`].
//!
//! Hangtud nga `T: Sized`, ang usa ka `Box<T>` gigarantiyahan nga girepresentar ingon usa ka tudlo ug kauban usab sa ABI nga adunay mga C pointer (ie ang C type `T*`).
//! Kini gipasabut nga kung adunay ka extern "C" Rust nga mga gimbuhaton nga tawgon gikan sa C, mahimo nimong ipasabut ang mga gimbuhaton sa Rust gamit ang mga `Box<T>` type, ug gamiton ang `T*` nga katugbang nga tipo sa kilid sa C.
//! Ingon usa ka pananglitan, hunahunaa kini nga C header nga nagdeklara sa mga gimbuhaton nga naghimo ug nagguba sa usa ka klase nga kantidad nga `Foo`:
//!
//! ```c
//! /* C ulohan */
//!
//! /* Gibalik ang pagpanag-iya sa nanawag */
//! struct Foo* foo_new(void);
//!
//! /* Gikuha ang pagpanag-iya sa nanawag;no-op kung gisangpit sa Null */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Ang kining duha nga gimbuhaton mahimong ipatuman sa Rust sama sa mosunud.Dinhi, ang `struct Foo*` nga tipo gikan sa C gihubad sa `Box<Foo>`, nga nakuha ang mga pagpugong sa pagpanag-iya.
//! Hinumdomi usab nga ang dili mabalhin nga argumento sa `foo_delete` girepresenta sa Rust ingon `Option<Box<Foo>>`, tungod kay ang `Box<Foo>` dili mahimong null.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Bisan kung ang `Box<T>` adunay parehas nga representasyon ug C ABI ingon usa ka C pointer, wala kini gipasabut nga mahimo nimong mabag-o ang usa ka arbitraryong `T*` sa usa ka `Box<T>` ug gipaabut nga molihok ang mga butang.
//! `Box<T>` ang mga mithi kanunay nga hingpit nga makahanay, dili mga panudlo.Labut pa, ang tiglaglag alang sa `Box<T>` mosulay nga buhian ang kantidad sa tibuuk nga taghatag sa kalibutan.Sa kinatibuk-an, ang labing kaayo nga praktis mao ang paggamit ra sa `Box<T>` alang sa mga panudlo nga naggikan sa tibuuk kalibutan nga tagahatag.
//!
//! **Mahinungdanon.** Labing menos sa karon, kinahanglan nimo nga likayan ang paggamit sa mga `Box<T>` nga lahi alang sa mga gimbuhaton nga gihubit sa C apan gisangpit gikan sa Rust.Sa kana nga mga kaso, kinahanglan nimo nga direktang i-mirror ang mga tipo sa C kutob sa mahimo.
//! Ang paggamit sa mga lahi sama sa `Box<T>` diin ang kahulugan sa C gigamit ra ang `T*` mahimong mosangpot sa wala matino nga pamatasan, sama sa gihulagway sa [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Usa ka tipo sa pointer alang sa alokasyon nga tapok.
///
/// Tan-awa ang [module-level documentation](../../std/boxed/index.html) alang sa daghan pa.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Gigahin ang memorya sa tapok ug dayon gibutang ang `x` niini.
    ///
    /// Dili kini tinuud nga gigahin kung ang `T` wala`y sukod sa gidak-on.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Naghimo usa ka bag-ong kahon nga adunay uninitialized nga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Naghimo usa ka bag-ong `Box` nga adunay uninitialized nga sulud, uban ang memorya nga napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Naghimo usa ka bag-ong `Pin<Box<T>>`.
    /// Kung ang `T` wala ipatuman ang `Unpin`, kung ingon niana ang `x` ma-pin sa memorya ug dili mabalhin.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Naggahin sa memorya sa tapok dayon gibutang ang `x` niini, nga nagbalik usa ka sayup kung pakyas ang alokasyon
    ///
    ///
    /// Dili kini tinuud nga gigahin kung ang `T` wala`y sukod sa gidak-on.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Naghimo usa ka bag-ong kahon nga adunay uninitialized nga mga sulud sa tapok, nga nagbalik usa ka sayup kung napakyas ang alokasyon
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Nagpatindog usa ka bag-ong `Box` nga adunay uninitialized nga sulud, nga ang panumduman napuno sa `0` bytes sa tambak
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Gigahin ang memorya sa gihatag nga taghatag unya ibutang ang `x` niini.
    ///
    /// Dili kini tinuud nga gigahin kung ang `T` wala`y sukod sa gidak-on.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Naggahin sa memorya sa gihatag nga tig-alokar dayon gibutang ang `x` niini, nga gibalik ang usa ka sayup kung napakyas ang alokasyon
    ///
    ///
    /// Dili kini tinuud nga gigahin kung ang `T` wala`y sukod sa gidak-on.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Naghimo usa ka bag-ong kahon nga adunay uninitialized nga sulud sa gihatag nga tagahatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Gipalabi ang pagpares kaysa sa pag-unwrap_or_else tungod kay ang pagsira usahay dili makalinya.
        // Kana makapadako sa kadako sa code.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Naghimo usa ka bag-ong kahon nga adunay uninitialized nga sulud sa gihatag nga tagahatag, nga nagbalik usa ka sayup kung napakyas ang alokasyon
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Naghimo usa ka bag-ong `Box` nga adunay uninitialized nga sulud, nga ang panumduman napuno sa `0` bytes sa gihatag nga tagahatag.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Gipalabi ang pagpares kaysa sa pag-unwrap_or_else tungod kay ang pagsira usahay dili makalinya.
        // Kana makapadako sa kadako sa code.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Naghimo usa ka bag-ong `Box` nga adunay uninitialized nga sulud, nga ang panumduman napuno sa `0` bytes sa gihatag nga tagahatag, nga nagbalik usa ka sayup kung napakyas ang alokasyon,
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Naghimo usa ka bag-ong `Pin<Box<T, A>>`.
    /// Kung ang `T` wala ipatuman ang `Unpin`, kung ingon niana ang `x` ma-pin sa memorya ug dili mabalhin.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Gikabig ang usa ka `Box<T>` ngadto sa usa ka `Box<[T]>`
    ///
    /// Ang kini nga pagkakabig dili igahin sa tambak ug mahitabo sa lugar.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Gikonsumo ang `Box`, gibalik ang gibug-aton nga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Naghimo usa ka bag-ong hiwa nga may kahon nga adunay wala hiuyon nga mga sulud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Naghimo usa ka bag-ong hiwa nga may kahon nga adunay wala hiuyon nga mga sulud, nga ang panumduman napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Naghimo usa ka bag-ong hiwa nga may kahon nga adunay uninitialized nga sulud sa gihatag nga taghatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Naghimo usa ka bag-ong hiwa nga may kahon nga adunay uninitialized nga sulud sa gihatag nga taghatag, nga ang panumduman napuno sa `0` bytes.
    ///
    ///
    /// Tan-awa ang [`MaybeUninit::zeroed`][zeroed] alang sa mga pananglitan sa tama ug dili husto nga paggamit sa kini nga pamaagi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Nakabig sa `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang kantidad naa gyud sa una nga estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Nakabig sa `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Sama sa [`MaybeUninit::assume_init`], naa ra sa tagatawag ang paggarantiya nga ang mga kantidad naa gyud sa usa ka pasiunang estado.
    ///
    /// Ang pagtawag niini kung ang sulud wala pa hingpit nga napasugod hinungdan sa gilayon nga wala matino nga pamatasan.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Gipalabi ang pasiuna:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Naghimo usa ka kahon gikan sa usa ka hilaw nga puntos.
    ///
    /// Pagkahuman sa pagtawag sa kini nga pag-andar, ang hilaw nga pointer gipanag-iya sa resulta nga `Box`.
    /// Sa piho nga paagi, ang `Box` destructor tawgon ang destructor sa `T` ug libre ang gigahin nga memorya.
    /// Aron kini luwas, ang panumduman kinahanglan nga gigahin sumala sa [memory layout] nga gigamit sa `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas tungod kay ang dili husto nga paggamit mahimong mosangput sa mga problema sa memorya.
    /// Pananglitan, mahimo`g mahitabo ang usa ka doble nga gawasnon kung ang kalihokan gihatagan kaduha sa parehas nga hilaw nga pahimangno.
    ///
    /// Ang mga kondisyon sa kahilwasan gihulagway sa seksyon nga [memory layout].
    ///
    /// # Examples
    ///
    /// Paghimo usab usa ka `Box` nga kaniadto gibag-o sa usa ka hilaw nga pahimangno gamit ang [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Kinamut nga pagmugna usa ka `Box` gikan sa paggasgas pinaagi sa paggamit sa tibuuk nga taghatag:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Sa kinatibuk-an gikinahanglan ang .write aron malikayan ang pagsulay nga gubaon ang miaging (uninitialized) nga mga sulud sa `ptr`, bisan alang sa kini nga yano nga pananglitan ang `*ptr = 5` mahimo usab nga molihok.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Naghimo usa ka kahon gikan sa usa ka hilaw nga puntos sa gihatag nga tighatag.
    ///
    /// Pagkahuman sa pagtawag sa kini nga pag-andar, ang hilaw nga pointer gipanag-iya sa resulta nga `Box`.
    /// Sa piho nga paagi, ang `Box` destructor tawgon ang destructor sa `T` ug libre ang gigahin nga memorya.
    /// Aron kini luwas, ang panumduman kinahanglan nga gigahin sumala sa [memory layout] nga gigamit sa `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Kini nga kalihokan dili luwas tungod kay ang dili husto nga paggamit mahimong mosangput sa mga problema sa memorya.
    /// Pananglitan, mahimo`g mahitabo ang usa ka doble nga gawasnon kung ang kalihokan gihatagan kaduha sa parehas nga hilaw nga pahimangno.
    ///
    /// # Examples
    ///
    /// Paghimo usab usa ka `Box` nga kaniadto gibag-o sa usa ka hilaw nga pahimangno gamit ang [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Kinamut nga pagmugna usa ka `Box` gikan sa paggaslas pinaagi sa paggamit sa tighatag sa sistema:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Sa kinatibuk-an gikinahanglan ang .write aron malikayan ang pagsulay nga gubaon ang miaging (uninitialized) nga mga sulud sa `ptr`, bisan alang sa kini nga yano nga pananglitan ang `*ptr = 5` mahimo usab nga molihok.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Gikonsumo ang `Box`, nga gibalik ang usa ka giputos nga hilaw nga pointer.
    ///
    /// Ang puntero nga husto nga makahanay ug dili null.
    ///
    /// Pagkahuman sa pagtawag sa kini nga pag-andar, ang tigpatawag mao ang responsable alang sa memorya nga kaniadto gidumala sa `Box`.
    /// Sa partikular, kinahanglan nga gubaon sa nanawag ang `T` ug buhian ang memorya, nga gikonsidera ang [memory layout] nga gigamit sa `Box`.
    /// Ang labing kadali nga paagi aron mahimo kini mao ang pag-usab sa hilaw nga pointer balik sa usa ka `Box` nga adunay [`Box::from_raw`] function, nga gitugotan ang `Box` destructor nga buhaton ang paglimpyo.
    ///
    ///
    /// Note: kini usa ka kauban nga pagpaandar, nga nagpasabut nga kinahanglan nimo kini tawgon nga `Box::into_raw(b)` imbis nga `b.into_raw()`.
    /// Kini aron wala`y panagbangi sa usa ka pamaagi sa sulud nga tipo.
    ///
    /// # Examples
    /// Pag-usab sa hilaw nga pointer balik sa usa ka `Box` nga adunay [`Box::from_raw`] alang sa awtomatikong paglimpiyo:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Pagpanlimpyo sa manwal pinaagi sa dayag nga pagpadagan sa destructor ug pag-usab sa memorya:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Gikonsumo ang `Box`, gibalik ang usa ka giputos nga hilaw nga pointer ug ang tagahatag.
    ///
    /// Ang puntero nga husto nga makahanay ug dili null.
    ///
    /// Pagkahuman sa pagtawag sa kini nga pag-andar, ang tigpatawag mao ang responsable alang sa memorya nga kaniadto gidumala sa `Box`.
    /// Sa partikular, kinahanglan nga gubaon sa nanawag ang `T` ug buhian ang memorya, nga gikonsidera ang [memory layout] nga gigamit sa `Box`.
    /// Ang labing kadali nga paagi aron mahimo kini mao ang pag-usab sa hilaw nga pointer balik sa usa ka `Box` nga adunay [`Box::from_raw_in`] function, nga gitugotan ang `Box` destructor nga buhaton ang paglimpyo.
    ///
    ///
    /// Note: kini usa ka kauban nga pagpaandar, nga nagpasabut nga kinahanglan nimo kini tawgon nga `Box::into_raw_with_allocator(b)` imbis nga `b.into_raw_with_allocator()`.
    /// Kini aron wala`y panagbangi sa usa ka pamaagi sa sulud nga tipo.
    ///
    /// # Examples
    /// Pag-usab sa hilaw nga pointer balik sa usa ka `Box` nga adunay [`Box::from_raw_in`] alang sa awtomatikong paglimpiyo:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Pagpanlimpyo sa manwal pinaagi sa dayag nga pagpadagan sa destructor ug pag-usab sa memorya:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Ang kahon giila ingon usa ka "unique pointer" sa Stacked Borrows, apan sa sulud kini usa ka hilaw nga tudlo alang sa tipo nga sistema.
        // Ang paghimo niini diretso sa usa ka hilaw nga pahimangno dili maila ingon "releasing" ang talagsaon nga tudlo aron pagtugot sa mga alias nga hilaw nga mga pag-access, busa ang tanan nga mga pamaagi sa hilaw nga pahimangno kinahanglan moagi sa `Box::leak`.
        //
        // Ang pagtuyok *nga* sa usa ka hilaw nga pahimangno nagalihok nga husto.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Nagbalik usa ka pakisayran sa nagpahiping tagahatag.
    ///
    /// Note: kini usa ka kauban nga pagpaandar, nga nagpasabut nga kinahanglan nimo kini tawgon nga `Box::allocator(&b)` imbis nga `b.allocator()`.
    /// Kini aron wala`y panagbangi sa usa ka pamaagi sa sulud nga tipo.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Nag-ut-ut ug gipagawas ang `Box`, nga nagbalik usa ka mabalhin nga pakisayran, `&'a mut T`.
    /// Hinumdomi nga ang tipo nga `T` kinahanglan mabuhi pa sa pinili nga kinabuhi nga `'a`.
    /// Kung ang tipo adunay static nga mga pakisayran ra, o wala gyud, nan kini mahimong mapili nga `'static`.
    ///
    /// Ang kini nga gimbuhaton labi nga mapuslanon alang sa datos nga mabuhi sa nahabilin nga kinabuhi sa programa.
    /// Ang paghulog sa gibalik nga reperensiya hinungdan sa usa ka pagtulo sa memorya.
    /// Kung dili kini madawat, ang pakisayran kinahanglan una nga giputos sa [`Box::from_raw`] function nga naghimo usa ka `Box`.
    ///
    /// Kini nga `Box` mahimo dayon nga ihulog nga maayo nga makaguba sa `T` ug buhian ang gigahin nga panumduman.
    ///
    /// Note: kini usa ka kauban nga pagpaandar, nga nagpasabut nga kinahanglan nimo kini tawgon nga `Box::leak(b)` imbis nga `b.leak()`.
    /// Kini aron wala`y panagbangi sa usa ka pamaagi sa sulud nga tipo.
    ///
    /// # Examples
    ///
    /// Yano nga paggamit:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Dili kadako nga datos:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Gikabig ang usa ka `Box<T>` ngadto sa usa ka `Pin<Box<T>>`
    ///
    /// Ang kini nga pagkakabig dili igahin sa tambak ug mahitabo sa lugar.
    ///
    /// Magamit usab kini pinaagi sa [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Dili mahimo ang paglihok o pag-ilis sa sulud sa usa ka `Pin<Box<T>>` kung `T: !Unpin`, busa luwas nga i-pin kini diretso nga wala`y dugang nga kinahanglanon.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ayaw pagbuhat bisan unsa, ang pagtulo gihimo karon sa nagtipig.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Naghimo usa ka `Box<T>`, nga adunay kantidad nga `Default` alang sa T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Nagbalik usa ka bag-ong kahon nga adunay usa ka `clone()` nga sulud sa kini nga kahon.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Parehas ang kantidad
    /// assert_eq!(x, y);
    ///
    /// // Apan sila mga talagsaon nga mga butang
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Pauna nga gigahin ang panumduman aron direkta nga masulat ang cloned nga kantidad.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Kinopya ang mga sulud sa `gigikanan` sa `self` nga wala paghimo usa ka bag-ong gahin.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Parehas ang kantidad
    /// assert_eq!(x, y);
    ///
    /// // Ug wala`y nahinabo nga paggahin
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // naghimo kini usa ka kopya sa datos
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Gikabig ang usa ka generic type `T` ngadto sa `Box<T>`
    ///
    /// Ang pagkakabig naggahin sa tapok ug gibalhin ang `t` gikan sa stack ngadto niini.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Gikabig ang usa ka `Box<T>` ngadto sa usa ka `Pin<Box<T>>`
    ///
    /// Ang kini nga pagkakabig dili igahin sa tambak ug mahitabo sa lugar.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Gikabig ang usa ka `&[T]` ngadto sa usa ka `Box<[T]>`
    ///
    /// Ang kini nga pagkakabig naggahin sa tambak ug naghimo usa ka kopya sa `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // paghimo sa usa ka&[u8] nga magamit aron makahimo usa ka Kahon <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Gikabig ang usa ka `&str` ngadto sa usa ka `Box<str>`
    ///
    /// Ang kini nga pagkakabig naggahin sa tambak ug naghimo usa ka kopya sa `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Gikabig ang usa ka `Box<str>` ngadto sa usa ka `Box<[u8]>`
    /// Ang kini nga pagkakabig dili igahin sa tambak ug mahitabo sa lugar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // paghimo usa ka Kahon<str>nga gamiton aron makahimo usa ka Kahon <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // paghimo sa usa ka&[u8] nga magamit aron makahimo usa ka Kahon <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Gikabig ang usa ka `[T; N]` ngadto sa usa ka `Box<[T]>`
    /// Gibalhin sa kini nga pagkakabig ang han-ay sa panumduman nga bag-ong gitagana.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Gisulayan nga ipaubos ang kahon sa us aka konkreto nga tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Gisulayan nga ipaubos ang kahon sa us aka konkreto nga tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Gisulayan nga ipaubos ang kahon sa us aka konkreto nga tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Dili mahimo nga makuha ang sulud nga Uniq nga diretso gikan sa Kahon, hinonoa iglabay namon kini sa usa ka * const nga nag-alyas sa Talagsaon
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Pag-espesyalisar alang sa kadako nga `Ako nga naggamit sa` I pagpatuman sa `last()` imbis nga default.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}