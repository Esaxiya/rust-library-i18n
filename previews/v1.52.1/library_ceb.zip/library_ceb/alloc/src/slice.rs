//! Usa ka dinamiko-kadako nga pagtan-aw sa usa ka kadugtong nga han-ay, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Ang mga hiwa usa ka pagtan-aw sa usa ka bloke sa memorya nga girepresenta ingon usa ka pointer ug usa ka gitas-on.
//!
//! ```
//! // paghiwa sa usa ka Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // pagpugos sa usa ka laray sa usa ka hiwa
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Ang mga hiwa mahimong mabalhin o mapaambit.
//! Ang mipakigbahin matang ad-ad mao ang `&[T]`, samtang ang mutable matang ad-ad mao ang `&mut [T]`, diin `T` nagrepresentar sa matang nga elemento.
//! Pananglitan, mahimo nimong mutate ang bloke sa memorya nga gitudlo sa usa ka mabalhin nga hiwa sa:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ania ang pipila ka mga butang nga sulud sa kini nga modyul:
//!
//! ## Structs
//!
//! Daghang mga struktura nga mapuslanon alang sa mga hiwa, sama sa [`Iter`], nga nagrepresentar sa pag-ulit sa usa ka hiwa.
//!
//! ## Mga Pagpatuman sa Trait
//!
//! Daghang mga pagpatuman sa kasagarang traits alang sa mga hiwa.Ang pila ka pananglitan kauban:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], alang sa mga hiwa nga ang tipo sa elemento mao ang [`Eq`] o [`Ord`].
//! * [`Hash`] - alang sa mga hiwa nga ang tipo sa elemento mao ang [`Hash`].
//!
//! ## Iteration
//!
//! Ang mga hiwa nagpatuman sa `IntoIterator`.Nagahatag ang iterator og mga pakisayran sa mga elemento sa hiwa.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Ang mutable slice naghatag mutable nga mga pakisayran sa mga elemento:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ang kini nga iterator nagahatag mutable nga mga pakisayran sa mga elemento sa slice, busa samtang ang elemento nga elemento sa hiwa nga `i32`, ang elemento nga elemento sa iterator mao ang `&mut i32`.
//!
//!
//! * [`.iter`] ug [`.iter_mut`] ang mga tin-aw nga pamaagi aron mabalik ang mga default iterator.
//! * Ang dugang nga mga pamaagi nga ibalik ang mga iterator mao ang [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ug daghan pa.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Daghan sa mga gigamit sa kini nga modyul gigamit ra sa pagsulud sa pagsulay.
// Mas limpyo nga patayon na lang ang wala magamit nga pahimangno kaysa pagpaayo niini.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Panguna nga pamaagi sa pag-uswag sa hiwa
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) kinahanglan alang sa pagpatuman sa `vec!` macro sa pagsulay sa NB, tan-awa ang `hack` module sa kini nga file alang sa dugang nga mga detalye.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) kinahanglan alang sa pagpatuman sa `Vec::clone` sa panahon sa pagsulay sa NB, tan-awa ang `hack` module sa kini nga file alang sa dugang nga mga detalye.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Uban sa cfg(test) `impl [T]` dili anaa, kini nga mga tulo ka mga gimbuhaton mao ang tinuod nga mga pamaagi nga anaa sa `impl [T]` apan dili sa `core::slice::SliceExt`, kita kinahanglan sa paghatag sa niini nga mga gimbuhaton alang sa `test_permutations` test
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Dili namon kinahanglan nga idugang ang hilisgutan nga hilisgutan sa kini tungod kay gigamit kini sa `vec!` macro nga kadaghanan ug hinungdan sa pag-usab sa hingpit.
    // Kitaa ang #71204 alang sa mga sangputanan sa paghisgot ug perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // mga butang markang initialized sa laang sa ubos
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) gikinahanglan alang sa LLVM aron makuha ang mga pagsusi sa mga utlanan ug adunay labi ka maayo nga codegen kaysa sa zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ang mga vector gigahin ug gisugdan sa taas hangtod sa labing menos kini nga gitas-on.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // gigahin sa taas nga adunay kapasidad nga `s`, ug ipasugod sa `s.len()` sa ptr::copy_to_non_overlapping sa ubos.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Natahi ang hiwa.
    ///
    /// matang Kini mao ang lig-on (ie, dili reorder patas nga mga elemento) ug *Oh*(*n*\*log(* n*)) labing-kaso.
    ///
    /// Kung magamit, gipili ang dili malig-on nga paghan-ay tungod kay sa kasagaran kini labi ka tulin kaysa malig-on nga paghan-ay ug wala kini paggahin handumanan nga auxiliary.
    /// Kitaa ang [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm usa ka adaptive, iterative merge sort nga gidasig sa [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Kini gidisenyo nga kaayo sa pagpuasa sa mga kaso diin ang mga ad-ad mao ang dul-an sa lainlainon, o naglangkob sa duha ka o labaw pa lainlainon han-ay concatenated ang usa human sa usa.
    ///
    ///
    /// Usab, kini naggahin temporaryo storage katunga sa gidak-on sa `self`, apan sa mubo nga mga hiwa sa usa ka non-gahin pagsal-ot matang gigamit sa baylo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Giihap ang hiwa nga adunay pagpaandar sa kumpare.
    ///
    /// matang Kini mao ang lig-on (ie, dili reorder patas nga mga elemento) ug *Oh*(*n*\*log(* n*)) labing-kaso.
    ///
    /// Ang pag-andar sa kumpare kinahanglan kinahanglan nga ipasabut ang usa ka kinatibuk-an nga pag-order alang sa mga elemento sa hiwa.Kung ang pag-order dili total, ang pagkasunud-sunod sa mga elemento wala matino.
    /// Ang usa ka order usa ka kinatibuk-ang han-ay kung kini (alang sa tanan nga `a`, `b` ug `c`):
    ///
    /// * kinatibuk ug antisymmetric: gayud sa usa sa `a < b`, `a == b` o `a > b` tinuod, ug
    /// * Transitive, `a < b` ug `b < c` nagpasabot `a < c`.Ang parehas kinahanglan nga maghupot alang sa parehas nga `==` ug `>`.
    ///
    /// Pananglitan, samtang ang [`f64`] wala ipatuman ang [`Ord`] tungod kay `NaN != NaN`, mahimo namon gamiton ang `partial_cmp` ingon among paglihok sa paghan-ay kung nahibal-an namon nga ang hiwa wala sulud usa ka `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Kung magamit, gipili ang dili malig-on nga paghan-ay tungod kay sa kasagaran kini labi ka tulin kaysa malig-on nga paghan-ay ug wala kini paggahin handumanan nga auxiliary.
    /// Kitaa ang [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm usa ka adaptive, iterative merge sort nga gidasig sa [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Kini gidisenyo nga kaayo sa pagpuasa sa mga kaso diin ang mga ad-ad mao ang dul-an sa lainlainon, o naglangkob sa duha ka o labaw pa lainlainon han-ay concatenated ang usa human sa usa.
    ///
    /// Usab, kini naggahin temporaryo storage katunga sa gidak-on sa `self`, apan sa mubo nga mga hiwa sa usa ka non-gahin pagsal-ot matang gigamit sa baylo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // balik nga paghan-ay
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Giihap ang hiwa nga adunay usa ka hinungdan nga pagpaandar sa pagkuha.
    ///
    /// Ang kini nga klase malig-on (ie, dili usab maghan-ay og parehas nga mga elemento) ug *O*(*m*\* * n *\* log(*n*)) labing kadaotan nga kaso, diin ang mahinungdanong pagpaandar mao ang *O*(*m*).
    ///
    /// Alang sa mga mahal nga punoan nga yawi (pananglitan
    /// mga gimbuhaton nga dili yano nga pag-access sa kabtangan o paninugdang mga operasyon), ang [`sort_by_cached_key`](slice::sort_by_cached_key) lagmit nga labi ka kusog, tungod kay wala niini gibalhin ang mga yawi sa elemento.
    ///
    ///
    /// Kung magamit, gipili ang dili malig-on nga paghan-ay tungod kay sa kasagaran kini labi ka tulin kaysa malig-on nga paghan-ay ug wala kini paggahin handumanan nga auxiliary.
    /// Kitaa ang [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm usa ka adaptive, iterative merge sort nga gidasig sa [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Kini gidisenyo nga kaayo sa pagpuasa sa mga kaso diin ang mga ad-ad mao ang dul-an sa lainlainon, o naglangkob sa duha ka o labaw pa lainlainon han-ay concatenated ang usa human sa usa.
    ///
    /// Usab, kini naggahin temporaryo storage katunga sa gidak-on sa `self`, apan sa mubo nga mga hiwa sa usa ka non-gahin pagsal-ot matang gigamit sa baylo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Giihap ang hiwa nga adunay usa ka hinungdan nga pagpaandar sa pagkuha.
    ///
    /// Sa panahon sa paghan-ay, ang yawi nga pag-andar gitawag kausa ra matag elemento.
    ///
    /// matang Kini mao ang lig-on (ie, dili reorder patas nga mga elemento) ug *Oh*(*m*\* * n + *n*\*log(* n *)) labing-kaso, diin ang mga yawe function mao Oh*(*m*) .
    ///
    /// Alang sa yano nga mga punoan nga yawi (pananglitan, mga gimbuhaton nga mga pag-access sa kabtangan o sukaranan nga operasyon), ang [`sort_by_key`](slice::sort_by_key) lagmit nga mas tulin.
    ///
    /// # Karon nga pagpatuman
    ///
    /// Ang karon nga algorithm gipasukad sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, nga naghiusa sa dali nga average nga kaso sa randomized quicksort uban ang labing dali nga labing daotan nga kaso sa heapsort, samtang ang pagkab-ot sa linear nga oras sa mga hiwa nga adunay piho nga mga sundanan.
    /// Naggamit kini pipila nga pag-randomize aron malikayan ang mga kaso nga naguba, apan adunay usa ka nakapirming seed aron kanunay maghatag deterministikong pamatasan.
    ///
    /// Sa labing daotan nga kaso, ang algorithm naggahin sa temporaryo nga pagtipig sa usa ka `Vec<(K, usize)>` ang gitas-on sa usa ka hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Magtatabang macro alang sa pag-index sa atong vector sa kinagamyan nga posible nga matang, sa pagpakunhod alokasyon.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Ang mga elemento sa `indices` talagsaon, tungod kay gi-index kini, busa ang bisan unsang matang mahimong malig-on kalabut sa orihinal nga hiwa.
                // Gigamit namon ang `sort_unstable` dinhi tungod kay nagkinahanglan kini og gamay nga alokasyon sa memorya.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Gikopya ang `self` sa usa ka bag-ong `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Dinhi, ang `s` ug `x` mahimong usbon nga independente.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Gikopya ang `self` sa usa ka bag-ong `Vec` nga adunay taghatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Dinhi, ang `s` ug `x` mahimong usbon nga independente.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, tan-awa ang `hack` module sa kini nga file alang sa dugang nga mga detalye.
        hack::to_vec(self, alloc)
    }

    /// Gikabig ang `self` sa usa ka vector nga wala`y mga clone o paggahin.
    ///
    /// Ang sangputanan nga vector mahimong mabalhin sa usa ka kahon pinaagi sa `Vec<T>pamaagi nga `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` dili na magamit tungod kay kini nakabig ngadto sa `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, tan-awa ang `hack` module sa kini nga file alang sa dugang nga mga detalye.
        hack::into_vec(self)
    }

    /// Naghimo usa ka vector pinaagi sa pagsubli sa usa ka hiwa nga `n` nga mga panahon.
    ///
    /// # Panics
    ///
    /// Kini nga pagpaandar mahimong panic kung ang kapasidad mag-awas.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Usa ka panic sa pag-awas:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Kung ang `n` mas dako kaysa zero, mahimo kini mabahin ingon `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ang numero nga girepresenta sa labing wala nga '1' nga gamay sa `n`, ug ang `rem` ang nahabilin nga bahin sa `n`.
        //
        //

        // Gigamit ang `Vec` aron ma-access ang `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Ang pagsubli gihimo pinaagi sa pagdoble sa `buf` expn`-beses.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Kung `m > 0`, adunay nahabilin nga mga piraso hangtod sa labing wala nga '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` adunay kapasidad nga `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=N, 2 ^ expn`) pagsubli ang gibuhat pinaagi sa pagkopya sa unang `rem` pagbalik-balik gikan sa `buf` sa iyang kaugalingon.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Kini dili nagsapaw sukad sa `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` katumbas sa `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Gipatay ang usa ka hiwa nga `T` sa usa ka kantidad nga `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Nag-flatt sa usa ka hiwa nga `T` sa usa ka kantidad nga `Self::Output`, nga gibutang ang usa ka gihatag nga separator taliwala sa matag usa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Nag-flatt sa usa ka hiwa nga `T` sa usa ka kantidad nga `Self::Output`, nga gibutang ang usa ka gihatag nga separator taliwala sa matag usa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Gibalik ang usa ka vector nga sulud usa ka kopya sa kini nga hiwa diin ang matag byte mapa sa iyang ASCII sa taas nga kaso nga katumbas.
    ///
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mapataas ang kantidad nga naa sa lugar, gamita ang [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Nagbalik usa ka vector nga sulud usa ka kopya sa kini nga hiwa diin ang matag byte mapa sa iyang ASCII ubos nga kaso nga katumbas.
    ///
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron ibubo ang kantidad nga naa sa lugar, gamita ang [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits alang sa mga hiwa sa piho nga klase sa datos
////////////////////////////////////////////////////////////////////////////////

/// Ang helper trait alang sa [`[T]: : concat`](hiwa::concat).
///
/// Note: ang parameter nga `Item` type dili gigamit sa kini nga trait, apan gitugotan niini ang mga impls nga mahimong labi ka generic.
/// Kung wala kini, nakuha namon kini nga sayup:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Kini tungod kay adunay paglungtad nga mga `V` nga lahi nga adunay daghang mga `Borrow<[_]>` impls, ingon nga daghang `T` nga mga lahi ang magamit:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ang sangputanan nga tipo pagkahuman sa concatenation
    type Output;

    /// Pagpatuman sa [`[T]: : concat`](hiwa::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait alang sa [`[T]: : apil`](hiwa::apil)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ang sangputanan nga tipo pagkahuman sa concatenation
    type Output;

    /// Pagpatuman sa [`[T]: : apil`](hiwa::apil)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kasagaran nga pagpatuman sa trait alang sa mga hiwa
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ihulog ang bisan unsa nga target nga dili mapapas
        target.truncate(self.len());

        // target.len <= self.len tungod sa truncate sa taas, busa ang mga hiwa dinhi kanunay nga naa sa-utlanan.
        //
        let (init, tail) = self.split_at(target.len());

        // gamiton pag-usab ang sulud nga mga kantidad allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Gisal-ot ang `v[0]` sa pre-sorted nga pagkasunodsunod nga `v[1..]` aron ang tibuuk nga `v[..]` mahimong gihan-ay.
///
/// Kini ang integral nga subroutine nga pagsulud nga lahi.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Adunay tulo nga paagi aron mapatuman ang pagsulud dinhi:
            //
            // 1. Ipuli ang mga kasikbit nga elemento hangtod moabut ang una sa katapusan nga destinasyon niini.
            //    Bisan pa, niining paagiha gikopya namon ang datos sa labi pa sa kinahanglan.
            //    Kung ang mga elemento dako nga istraktura (mahal nga kopyahon), kini nga pamaagi mahimong hinay.
            //
            // 2. Iterate hangtod makit-an ang husto nga lugar alang sa una nga elemento.
            // Pagkahuman ibalhin ang mga elemento nga nagsunod niini aron adunay lugar alang niini ug sa katapusan ibutang kini sa nahabilin nga lungag.
            // Kini usa ka maayong pamaagi.
            //
            // 3. Kopyaha ang una nga elemento sa usa ka temporaryo nga pagbag-o.Iterate hangtud nga ang husto nga dapit kay kini makaplagan.
            // Samtang nagpadayon kami, kopyaha ang matag giagian nga elemento sa slot nga nauna niini.
            // Sa katapusan, kopyahon ang datos gikan sa temporaryo nga pagbag-o ngadto sa nahabilin nga lungag.
            // Kini nga pamaagi maayo kaayo.
            // Gipakita sa mga benchmark ang gamay nga mas maayo nga pasundayag kaysa sa ika-2 nga pamaagi.
            //
            // Ang tanan nga mga pamaagi gi-benchmark, ug ang ika-3 nagpakita labing kaayo nga mga sangputanan.Mao nga gipili namo kana.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ang tungatunga nga estado sa proseso sa pagsulud kanunay gisubay sa `hole`, nga nagsilbi duha nga katuyoan:
            // 1. Gipanalipdan ang integridad sa `v` gikan sa panics sa `is_less`.
            // 2. Pun-a ang nahabilin nga lungag sa `v` sa katapusan.
            //
            // Kaluwas sa Panic:
            //
            // Kon `is_less` panics sa bisan unsa nga punto sa panahon sa proseso, `hole` ang na nagatulo ug pun-on ang lungag sa `v` sa `tmp`, sa ingon pagsiguro nga `v` gihapon naghupot sa tanan nga butang kini sa sinugdanan gihimo gayud sa makausa.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` nahulog ug sa ingon gikopya ang `tmp` sa nahabilin nga lungag sa `v`.
        }
    }

    // Kung nahulog, mga kopya gikan sa `src` ngadto sa `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ang non-pagkunhod nga pagmando nga nagpadagan sa `v[..mid]` ug `v[mid..]` gamit ang `buf` ingon temporaryo nga pagtipig, ug gitipig ang resulta sa `v[..]`.
///
/// # Safety
///
/// Ang duha ka hiwa kinahanglan nga wala`y laman ug ang `mid` kinahanglan naa sa mga utlanan.
/// Ang buffer `buf` kinahanglan adunay igo nga gitas-on aron makuptan ang usa ka kopya sa labi ka mubu nga hiwa.
/// Ingon usab, ang `T` kinahanglan dili usa ka lahi nga gidak-on sa tipo.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ang proseso sa paghiusa una nga gikopya ang labi ka mubo nga pagdagan sa `buf`.
    // Unya kini misubay sa bag-ong gikopya run ug ang na run sa unahan (o pinabali), sa pagtandi sa ilang sunod nga wala masunog elemento ug sa pagkopya sa mas ubos nga (o mas dako) sa usa ngadto sa `v`.
    //
    // Sa diha nga ang mubo nga run ang bug-os nga mangaut-ut, ang proseso gihimo.Kung ang mas dugay nga pagdagan nahurot una, nan kinahanglan naton kopyahon ang nahabilin sa mas mubo nga pagdagan sa nahabilin nga lungag sa `v`.
    //
    // Ang tunga nga estado sa proseso kanunay gisubay sa `hole`, nga nagsilbi sa duha nga katuyoan:
    // 1. Gipanalipdan ang integridad sa `v` gikan sa panics sa `is_less`.
    // 2. Pun-a ang nahabilin nga lungag sa `v` kung ang mas dugay nga pagdagan nahurot una.
    //
    // Kaluwas sa Panic:
    //
    // Kung ang `is_less` panics sa bisan unsang punto sa proseso, ang `hole` mahulog ug pun-on ang lungag sa `v` sa wala maisip nga sakup sa `buf`, sa ingon gisiguro nga ang `v` naghupot pa sa matag butang nga kini una nga gikuptan sa eksakto nga kausa.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ang wala nga pagdagan labi ka mubo.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Sa una, kini nga mga panudlo nagpunting sa mga pagsugod sa ilang mga array.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Pag-ut-ut ang labing gamay nga bahin.
            // Kung managsama, gusto ang wala nga dagan aron mapadayon ang kalig-on.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ang husto nga pagdagan mas mubu.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Sa sinugdanan, kini nga mga panudlo nagpunting sa katapusan sa ilang mga array.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Pag-ut-ut ang labi ka daghang bahin.
            // Kung parehas, gusto ang tama nga dagan aron mapadayon ang kalig-on.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Sa katapusan, nahulog ang `hole`.
    // Kung ang labi ka mubu nga pagdagan dili hingpit nga nahurot, bisan unsa nga nahabilin niini karon makopya sa lungag sa `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kung nahulog, kopyahon ang range `start..end` hangtod `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` dili usa ka zero-size nga klase, busa okay ra nga bahinon pinaagi sa gidak-on niini.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ang kini nga paghiusa naghulam sa pipila (apan dili tanan) nga mga ideya gikan sa TimSort, nga gihulagway sa detalye nga [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Ang algorithm nagpaila hugot nga mikunsad ug non-mikunsad subsequences, nga gitawag natural nga midagan.Adunay usa ka stack sa mga pending pending nga mahimo pa nga iusa.
/// Ang matag bag-ong nakit-an nga pagdalagan gitulod sa stack, ug pagkahuman ang pipila nga mga pares sa mga kasikbit nga pagdagan gitapo hangtod nga matagbaw ang kining duha ka mga invariant:
///
/// 1. alang sa matag `i` sa `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. alang sa matag `i` sa `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Gisiguro sa mga nagdapit nga ang kinatibuk-ang oras sa pagdagan mao ang *O*(*n*\*log(* n*)) labing daotan nga kaso.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ang mga hiwa hangtod sa kini nga gitas-on mahimo`g pagkahan-ay gamit ang pagsulud nga sulud.
    const MAX_INSERTION: usize = 20;
    // Talagsa ra kaayo nga mga dagan ang gipadako gamit ang pagsulud nga lahi aron molapas sa labing ka daghan sa kini nga mga elemento.
    const MIN_RUN: usize = 10;

    // Ang pagsulud wala makahuluganon nga pamatasan sa mga wala`y gidak-on nga lahi.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Ang mga mubo nga pag-array mahimo nga paghan-ay sa lugar pinaagi sa pagsulud sa pagsulud aron malikayan ang paggahin.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Paggahin usa ka buffer aron magamit ingon usa ka panumduman nga wala.Gipadayon namon ang gitas-on 0 aron mapadayon namon ang mabaw nga mga kopya sa mga sulud sa `v` nga dili ibutang sa peligro ang mga dtor nga modagan sa mga kopya kung `is_less` panics.
    //
    // Kung naghiusa sa duha nga gipili nga dagan, ang buffer nga kini adunay usa ka kopya sa labi ka mubu nga pagdagan, nga kanunay adunay gitas-on sa labing `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Aron mahibal-an ang natural nga pagdagan sa `v`, giagian namon kini paatras.
    // Tingali ingon kana usa ka katingad-an nga paghukum, apan hunahunaa ang katinuud nga ang paghiusa kanunay nga moadto sa atbang nga direksyon nga (forwards).
    // Pinauyon sa mga benchmark, ang paghiusa sa unahan labi ka kadali kaysa paghiusa sa atras.
    // Sa pagtapos, pag-ila sa midagan pinaagi sa milabang sa naglakaw improb performance.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Pangitaa ang sunod nga natural nga pagdagan, ug balihon kini kung kini estrikto nga pagkanaug.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Isulud ang daghang mga elemento sa pagdagan kung kini mubu ra.
        // Ang pagsulud sa pagsulud labi ka dali kaysa paghiusa sa mga mubo nga han-ay, mao nga kini nakapaayo sa pagpauswag.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Itulak kini nga pagdagan sa stack.
        runs.push(Run { start, len: end - start });
        end = start;

        // Paghiusa ang pipila nga mga pares nga katupad nga pagdagan aron matagbaw ang mga nag-imbitar.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Sa katapusan, eksakto nga usa ka pagdagan kinahanglan magpabilin sa stack.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Gisusi ang stack sa mga dagan ug giila ang sunod nga pares sa mga pagdagan aron paghiusa.
    // Labi ka piho, kung ang `Some(r)` ibalik, kana nagpasabut nga ang `runs[r]` ug `runs[r + 1]` kinahanglan isumpay sa sunod.
    // Kung ang algorithm kinahanglan magpadayon sa pagtukod usa ka bag-ong pagdagan hinoon, ibalik ang `None`.
    //
    // Ang TimSort dili maayo alang sa mga pagpatuman sa buggy niini, sama sa gihulagway dinhi:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Ang hinungdan sa istorya mao: kinahanglan naton ipatuman ang mga invariant sa top upat nga dagan sa stack.
    // Ang pagpatuman sa kanila sa nag-una sa tulo ra dili igo aron masiguro nga ang mga nagdapit magpadayon alang sa *tanan* nga pagdagan sa stack.
    //
    // Kini nga pag-andar husto nga pagsusi sa mga invariant alang sa top upat nga pagdagan.
    // Dugang pa, kon sa ibabaw modagan magsugod sa index 0, kini kanunay mangayo sa usa ka iusa operasyon hangtud nga ang pundok mao ang bug-os nga nahugno, aron sa pagkompleto sa matang.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}