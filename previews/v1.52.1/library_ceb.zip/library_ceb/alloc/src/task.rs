#![stable(feature = "wake_trait", since = "1.51.0")]
//! Matang ug Traits alang sa pagtrabaho uban sa asynchronous buluhaton.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ang pagpatuman sa pagpukaw sa usa ka buluhaton sa usa ka tigpatuman.
///
/// Kini nga trait mahimong magamit aron makahimo usa ka [`Waker`].
/// Mahimo ipasabut sa usa ka tigpatuman ang usa ka pagpatuman sa niining trait, ug gamiton kana aron matukod ang usa ka Waker aron mapasa ang mga buluhaton nga gipatuman sa kana nga tigpatuman.
///
/// Kini trait mao ang usa ka handumanan-luwas ug ergonomic alternatibo sa pagtukod sa usa ka [`RawWaker`].
/// Gisuportahan niini ang kasagaran nga laraw sa tigpatuman diin ang datos nga gigamit aron makamata ang usa ka buluhaton gitipig sa usa ka [`Arc`].
/// Ang pipila nga mga tigpatuman (labi na ang alang sa mga naka-embed nga sistema) dili makagamit sa kini nga API, hinungdan nga adunay [`RawWaker`] ingon usa ka kapilian alang sa mga kana nga sistema.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Usa ka sukaranan nga pagpaandar sa `block_on` nga nagkinahanglan usa ka future ug gipadagan kini hangtod mahuman ang karon nga sulud.
///
/// **Note:** Kini nga pananglitan gipamaligya ang pagkahusto alang sa kayano.
/// Aron sa pagpugong sa deadlocks, produksyon-grade implementar usab kinahanglan aron sa pagdumala sa intermediate tawag sa `thread::unpark` ingon man sa dugmonan mga pag-ampo.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Usa ka tigmata nga nakamata sa karon nga thread kung gitawag.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Pagdagan ang usa ka future hangtod makumpleto ang karon nga sulud.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pagbuno sa future mao nga kini mahimong polled.
///     let mut fut = Box::pin(fut);
///
///     // Paghimo usa ka bag-ong konteksto nga maipasa sa future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Dagan ang future hangtod mahuman.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Pukawa kini nga buluhaton.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Pagmata kini nga buluhaton nga wala mangaut-ut ang tigmata.
    ///
    /// Kung gisuportahan sa usa ka tigpatuman ang usa ka labi ka barato nga paagi sa pagmata nga wala mahurot ang tigmata, kinahanglan nga ipatigbabaw kini nga pamaagi.
    /// Pinaagi sa remate, kini clones sa [`Arc`] ug nagtawag [`wake`] sa clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KALUWASAN: Kini luwas tungod kay ang hilaw nga tawo nga luwas nga matukod
        // usa ka RawWaker gikan sa Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ang kini nga pribado nga katungdanan alang sa pagtukod sa usa ka RawWaker gigamit labi pa
// isulud kini sa `From<Arc<W>> for RawWaker` impl, aron masiguro nga ang kahilwasan sa `From<Arc<W>> for Waker` dili mosalig sa tama nga trait nga pagpadala, sa baylo nga parehas nga impls nga nagtawag sa kini nga pag-andar direkta ug tin-aw.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Dungag sa pakisayran ihap sa arko sa clone niini.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Pagmata pinaagi sa kantidad, pagbalhin sa Arc ngadto sa Wake::wake function
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Pagmata pinaagi sa pakisayran, ibalot ang nagmata sa ManwalDrop aron malikayan ang paghulog niini
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Pagminus sa ihap sa pakisayran sa Arc sa drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}