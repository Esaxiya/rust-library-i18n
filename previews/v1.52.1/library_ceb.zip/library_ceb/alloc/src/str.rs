//! Unicode mga hiwa sa pisi.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Ang tipo nga `&str` usa sa duha ka punoan nga tipo sa pisi, ang usa `String`.
//! Dili sama sa katugbang nga `String`, ang mga sulud niini gihulaman.
//!
//! # Panguna nga Paggamit
//!
//! Usa ka punoan nga deklarasyon sa pisi nga tipo nga `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Dinhi gideklara namon ang usa ka string nga literal, naila usab nga usa ka slice sa pisi.
//! Ang mga stral literal adunay usa ka static nga kinabuhi, nga nagpasabut nga ang string `hello_world` gigarantiyahan nga mahimong balido sa gidugayon sa tibuuk nga programa.
//!
//! Mahimo namon nga tin-aw nga gipiho ang kinabuhi usab sa `hello_world`:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Daghan sa mga gigamit sa kini nga modyul gigamit ra sa pagsulud sa pagsulay.
// Mas limpyo nga patayon na lang ang wala magamit nga pahimangno kaysa pagpaayo niini.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: Ang `str` sa `Concat<str>` dili makahuluganon dinhi.
/// Ang kini nga lahi nga parameter sa trait naglungtad lamang aron mahimo ang usa pa nga impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ang mga galong nga adunay gidak-on nga gidak-on sa gidak-on nagpadagan labi pa ka espesyalista ang mga kaso nga adunay gamay nga gitas-on sa separator
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // arbitraryong non-zero size fallback
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Gi-optimize ang pagpatuman sa pag-apil nga molihok alang sa parehas nga Vec<T>(T: Kopya) ug sulud nga mga vector sa String Karon nga (2018-05-13) adunay usa ka bug nga adunay tipo nga pagkagusto ug pag-espesyalisar (tan-awa ang isyu nga #36262) Tungod niini nga hinungdan SliceConcat<T>dili espesyalista alang sa T: Kopyaha ug SliceConcat<str>mao ra ang naggamit sa kini nga gimbuhaton.
// Gibilin kini sa lugar kung kanus-a kini gitakda.
//
// ang mga utlanan alang sa String-join mao ang S: Pahulam<str>ug alang sa Vec-apil Borrow <[T]> [T] ug Str duha impl AsRef <[T]> alang sa pipila T
// => s.borrow().as_ref() ug kanunay kami adunay mga hiwa
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ang una nga hiwa usa ra nga wala`y bulag nga nag-una niini
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kuwentahon ang ensakto nga kinatibuk-ang gitas-on sa gisalmutan nga Vec kung mag-awas ang pagkalkula sa `len`, mag-panic kami nga mahutdan usab sa memorya ug ang nahabilin nga pag-andar nagkinahanglan sa tibuuk nga Vec nga giandam alang sa kaluwasan
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // pag-andam usa ka wala mahibal-an nga buffer
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopya ang separator ug mga hiwa nga wala`y utlanan nga mga tseke nga makamugna mga loop nga adunay mga hardcoded offset alang sa gagmay nga mga separator nga mahimo`g daghan nga mahimo`g mahimo (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Ang usa ka katingad-an nga pagpatuman sa paghulam mahimong ibalik ang lainlaing mga hiwa alang sa pagkalkula sa gitas-on ug ang tinuud nga kopya.
        //
        // Siguruha nga dili namon ibutyag ang wala nahibal-an nga mga byte sa nanawag.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Mga pamaagi alang sa mga hiwa sa pisi.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Gikabig ang usa ka `Box<str>` sa usa ka `Box<[u8]>` nga wala gikopya o gigahin.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Gipulihan ang tanan nga mga posporo sa usa ka sumbanan sa lain nga pisi.
    ///
    /// `replace` nagmugna usa ka bag-ong [`String`], ug gikopya ang datos gikan sa kini nga hiwa sa sulod niini.
    /// Samtang gibuhat kini, gisulayan niini nga makit-an ang mga posporo sa usa ka sundanan.
    /// Kung nakit-an kini, gipulihan kini sa kapuli nga hiwa sa pisi.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Kung dili parehas ang sundanan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Gipulihan ang una nga N nga posporo sa usa ka sumbanan sa lain nga string.
    ///
    /// `replacen` nagmugna usa ka bag-ong [`String`], ug gikopya ang datos gikan sa kini nga hiwa sa sulod niini.
    /// Samtang gibuhat kini, gisulayan niini nga makit-an ang mga posporo sa usa ka sundanan.
    /// Kung nakit-an kini, gipulihan kini sa pagpuli nga hiwa sa labing kadaghan nga `count` ka beses.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Kung dili parehas ang sundanan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Hinaot nga maibanan ang oras sa paghatag usab
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Gibalik ang katumbas nga gagmay nga gagmay sa kini nga hiwa sa pisi, ingon usa ka bag-ong [`String`].
    ///
    /// 'Lowercase' gihubit sumala sa mga termino sa Unicode Derived Core Property `Lowercase`.
    ///
    /// Tungod kay ang pipila ka mga karakter mahimo nga mapalapdan sa daghang mga karakter sa pagbag-o sa kaso, kini nga pag-andar mobalik sa usa ka [`String`] imbis nga pagbag-o ang parameter sa lugar.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Usa ka malimbongon nga pananglitan, nga adunay sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // apan sa katapusan sa usa ka pulong, kini ς, dili σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Ang mga sinultian nga wala`y kaso wala mausab:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mga mapa sa σ, gawas sa katapusan sa usa ka pulong diin kini mapa ngadto sa ς.
                // Kini ra ang kondisyonal nga (contextual) apan ang pagmapa nga wala`y sinultian sa `SpecialCasing.txt`, busa lisud kini nga pag-code kaysa adunay usa ka generic nga "condition" nga mekanismo.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // alang sa kahulugan sa `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Gibalik ang katumbas nga uppercase sa kini nga slice sa pisi, ingon usa ka bag-ong [`String`].
    ///
    /// 'Uppercase' gihubit sumala sa mga termino sa Unicode Derived Core Property `Uppercase`.
    ///
    /// Tungod kay ang pipila ka mga karakter mahimo nga mapalapdan sa daghang mga karakter sa pagbag-o sa kaso, kini nga pag-andar mobalik sa usa ka [`String`] imbis nga pagbag-o ang parameter sa lugar.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Ang mga script nga wala`y kaso wala mausab:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ang usa ka karakter mahimong daghan:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Gikabig ang usa ka [`Box<str>`] sa usa ka [`String`] nga wala gikopya o gigahin.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Naghimo usa ka bag-ong [`String`] pinaagi sa pagsubli sa usa ka string `n` nga mga panahon.
    ///
    /// # Panics
    ///
    /// Kini nga pagpaandar mahimong panic kung ang kapasidad mag-awas.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Usa ka panic sa pag-awas:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Nagpauli usa ka kopya sa kini nga pisi diin ang matag karakter gi-mapa sa iyang katumbas nga ASCII sa taas nga kaso.
    ///
    ///
    /// Ang mga letra nga ASCII 'a' hangtod 'z' mapa sa 'A' hangtod 'Z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron mapataas ang kantidad nga naa sa lugar, gamita ang [`make_ascii_uppercase`].
    ///
    /// Aron mapadako ang mga karakter nga ASCII agig dugang sa mga dili ASCII nga mga karakter, gamita ang [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() gipreserba ang UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Nagbalik usa ka kopya sa kini nga pisi diin ang matag karakter gi-mapa sa iyang ASCII nga mas ubos nga kaso nga katumbas.
    ///
    ///
    /// Ang mga letra nga ASCII 'A' hangtod 'Z' mapa sa 'a' hangtod 'z', apan ang dili letra nga ASCII dili mausab.
    ///
    /// Aron ibubo ang kantidad nga naa sa lugar, gamita ang [`make_ascii_lowercase`].
    ///
    /// Aron lowercase ASCII karakter sa dugang sa mga dili-ASCII mga karakter, sa paggamit sa [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() gipreserba ang UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Gikabig ang usa ka kahon nga hiwa sa mga byte sa usa ka hiwa nga boxed string nga wala gisusi nga ang pisi adunay sulud nga UTF-8.
///
///
/// # Examples
///
/// Panguna nga gamit:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}