//! Mga API sa paggahin sa memorya

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Kini ang mga simbolo nga mahika nga tawagan ang tibuuk kalibutan nga tagahatag.Ang rustc naghimo kanila aron tawagan ang `__rg_alloc` ug uban pa.
    // kung adunay usa ka `#[global_allocator]` nga hiyas (ang pagpadako sa code nga gipasabut sa macro nga naghimo sa kana nga mga gimbuhaton), o aron tawagan ang mga default nga pagpatuman sa libstd (`__rdl_alloc` etc.
    //
    // sa `library/std/src/alloc.rs`) kung dili.
    // Ang rustc fork sa LLVM usab espesyal nga mga kaso sa kini nga mga ngalan sa pagpaandar aron ma-optimize kini sama sa `malloc`, `realloc`, ug `free`, matag usa.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Ang taghatag sa memorya sa tibuuk kalibutan.
///
/// Ang kini nga tipo nagpatuman sa [`Allocator`] trait pinaagi sa pagpasa sa mga tawag sa tagatala nga narehistro sa `#[global_allocator]` nga hiyas kung adunay usa, o default sa `std` crate.
///
///
/// Note: samtang kini nga tipo dili malig-on, ang pagpaandar nga gihatag niini mahimong ma-access pinaagi sa [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Igahin ang memorya sa tibuuk kalibutan nga tagahatag.
///
/// Ang pagpaandar nga kini gipauna nga nagtawag sa pamaagi nga [`GlobalAlloc::alloc`] sa tagahatag nga narehistro sa `#[global_allocator]` nga hiyas kung adunay usa, o default sa `std` crate.
///
///
/// Kini nga pag-andar gilauman nga mawala gikan sa pabor sa `alloc` nga pamaagi sa [`Global`] type kung kini ug ang [`Allocator`] trait mahimong lig-on.
///
/// # Safety
///
/// Kitaa ang [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Pagbalhin sa panumduman uban ang tibuuk nga tagahatag.
///
/// Ang pagpaandar nga kini gipauna nga nagtawag sa pamaagi nga [`GlobalAlloc::dealloc`] sa tagahatag nga narehistro sa `#[global_allocator]` nga hiyas kung adunay usa, o default sa `std` crate.
///
///
/// Kini nga pag-andar gilauman nga mawala gikan sa pabor sa `dealloc` nga pamaagi sa [`Global`] type kung kini ug ang [`Allocator`] trait mahimong lig-on.
///
/// # Safety
///
/// Kitaa ang [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Pag-usab sa memorya sa tibuuk nga taghatag.
///
/// Ang pagpaandar nga kini gipauna nga nagtawag sa pamaagi nga [`GlobalAlloc::realloc`] sa tagahatag nga narehistro sa `#[global_allocator]` nga hiyas kung adunay usa, o default sa `std` crate.
///
///
/// Kini nga pag-andar gilauman nga mawala gikan sa pabor sa `realloc` nga pamaagi sa [`Global`] type kung kini ug ang [`Allocator`] trait mahimong lig-on.
///
/// # Safety
///
/// Kitaa ang [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Pag-alok sa memorya nga zero-initialized sa tibuuk nga taghatag sa kalibutan.
///
/// Ang pagpaandar nga kini nagpauna sa pagtawag sa [`GlobalAlloc::alloc_zeroed`] nga pamaagi sa taghatag nga narehistro sa `#[global_allocator]` nga hiyas kung adunay usa, o ang default nga `std` crate.
///
///
/// Kini nga pag-andar gilauman nga mawala gikan sa pabor sa `alloc_zeroed` nga pamaagi sa [`Global`] type kung kini ug ang [`Allocator`] trait mahimong lig-on.
///
/// # Safety
///
/// Kitaa ang [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // KALUWASAN: Ang `layout` dili gidak-on sa gidak-on,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // KALUWASAN: Parehas sa `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // KALUWASAN: Ang `new_size` dili-zero ingon ang `old_size` mas daghan kaysa o katumbas sa `new_size`
            // sama sa gikinahanglan sa mga kondisyon sa kahilwasan.Ang uban pang mga kondisyon kinahanglan ipadayon sa nanawag
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` tingali gisusi alang sa `new_size >= old_layout.size()` o susama nga butang.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KALUWASAN: tungod kay ang `new_layout.size()` kinahanglan labi ka daghan sa o managsama sa `old_size`,
            // pareho ang daan ug bag-ong alokasyon sa memorya nga balido alang sa pagbasa ug pagsulat alang sa `old_size` bytes.
            // Ingon usab, tungod kay ang daan nga alokasyon wala pa makalihok, dili kini mahimong magsapaw sa `new_ptr`.
            // Sa ingon, ang tawag sa `copy_nonoverlapping` luwas.
            // Ang kontrata sa kahilwasan alang sa `dealloc` kinahanglan nga ipadayon sa nanawag.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // KALUWASAN: Ang `layout` dili gidak-on sa gidak-on,
            // uban pang mga kondisyon kinahanglan ipadayon sa nanawag
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALUWASAN: tanan nga mga kondisyon kinahanglan ipadayon sa nanawag
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALUWASAN: tanan nga mga kondisyon kinahanglan ipadayon sa nanawag
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // KALUWASAN: ang mga kondisyon kinahanglan ipadayon sa nanawag
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // KALUWASAN: Ang `new_size` dili zero.Ang uban pang mga kondisyon kinahanglan ipadayon sa nanawag
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` tingali gisusi alang sa `new_size <= old_layout.size()` o susama nga butang.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // KALUWASAN: tungod kay ang `new_size` kinahanglan mas gamay kaysa o managsama sa `old_layout.size()`,
            // pareho ang daan ug bag-ong alokasyon sa memorya nga balido alang sa pagbasa ug pagsulat alang sa `new_size` bytes.
            // Ingon usab, tungod kay ang daan nga alokasyon wala pa makalihok, dili kini mahimong magsapaw sa `new_ptr`.
            // Sa ingon, ang tawag sa `copy_nonoverlapping` luwas.
            // Ang kontrata sa kahilwasan alang sa `dealloc` kinahanglan nga ipadayon sa nanawag.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Ang tagatagana alang sa talagsaon nga mga panudlo.
// Kini nga paglihok kinahanglan dili magpahulay.Kung buhaton kini, mapakyas ang MIR codegen.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Kini nga pirma kinahanglan managsama sa `Box`, kung dili man adunay mahitabo nga ICE.
// Kung ang usa ka dugang nga parameter sa `Box` gidugang (sama sa `A: Allocator`), kini kinahanglan usab nga idugang dinhi.
// Pananglitan kung ang `Box` gibag-o sa `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, kini nga pag-andar kinahanglan usab nga mabag-o usab sa `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Pagdumala sa sayup sa pagdumala

extern "Rust" {
    // Kini ang simbolo sa salamangka aron tawagan ang tagdumala sa sayup sa paglibut sa kalibutan.
    // Ang rustc naghimo niini aron tawagan ang `__rg_oom` kung adunay usa ka `#[alloc_error_handler]`, o aron tawagan ang mga default nga pagpatuman sa ubus sa (`__rdl_oom`) kung dili.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Pag-abort sa sayup nga pagkagahin sa memorya o pagkapakyas.
///
/// Ang mga nanawag sa mga alokasyon sa memorya nga mga API nga nagtinguha nga ihulog ang pagkalkula ingon tubag sa usa ka sayup nga alokasyon giawhag nga tawagan kini nga pag-andar, kaysa direkta nga ipangayo ang `panic!` o pareho.
///
///
/// Ang default nga pamatasan sa kini nga pag-andar mao ang pag-print sa usa ka mensahe sa naandan nga sayup ug ihunong ang proseso.
/// Mahimo kini pulihan sa [`set_alloc_error_hook`] ug [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Alang sa gigahin nga pagsulay ang `std::alloc::handle_alloc_error` mahimong magamit nga direkta.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // gitawag pinaagi sa namugna `__rust_alloc_error_handler`

    // kung wala`y `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // kung adunay usa ka `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Pag-espesyalista sa mga clone sa pauna nga gigahin, wala`y pahimangno nga panumduman.
/// Gigamit sa `Box::clone` ug `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ang paggahin *una* mahimong magtugot sa optimizer nga maghimo sa wala ma-clone nga kantidad nga kantidad, laktawan ang lokal ug pagbalhin.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Kanunay namon nga makopya ang lugar nga wala`y labot ang usa ka lokal nga kantidad.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}