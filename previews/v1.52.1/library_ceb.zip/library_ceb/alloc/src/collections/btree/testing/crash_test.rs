use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Usa ka blueprint alang sa crash test dummy nga mga higayon nga nagsubay sa mga piho nga hitabo.
/// Ang ubang mga higayon mahimo nga gihulma, giporma sa panic sa pipila ka mga punto.
/// Ang mga hitabo mao ang `clone`, `drop` o pipila nga dili nagpaila nga `query`.
///
/// Ang mga dummies sa pag-crash test giila ug gisugo sa usa ka id, aron sila magamit ingon mga yawi sa usa ka BTreeMap.
/// Ang pagpatuman nga gituyo nga gigamit dili nagsalig sa bisan unsang gihubit sa crate, gawas sa `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Nakahimo usa ka laraw sa crash test dummy.Gitino sa `id` ang pagkahan-ay ug pagkaparehas sa mga pananglitan.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Naghimo usa ka pananglitan sa usa ka crash test dummy nga nagtala kung unsang mga hitabo nga nasinati ug kapilian nga panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Mobalik kung pila ka beses nga na-clone ang mga pananglitan sa dummy.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Mobalik kung pila ka beses nga nahulog ang mga higayon.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Mobalik kung pila ka beses nga higayon sa dummy nga gisangpit ang ilang miyembro nga `query`.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Ang pila nga wala nagpaila nga pangutana, nga ang sangputanan gihatag na.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}