use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Usa ka kauban nga kinahanglan nga gipangita, sama sa `Bound::Included(T)`.
    Included(T),
    /// Usa ka eksklusibo nga gipangita, sama sa `Bound::Excluded(T)`.
    Excluded(T),
    /// Usa ka unconditional inclusive bound, sama sa `Bound::Unbounded`.
    AllIncluded,
    /// Usa ka walay kondisyon nga eksklusibo nga gihigot.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tinan-awan sa usa ka gihatag nga yawe sa usa ka (sub) kahoy nga gipangulohan sa binurotan, hubag, recursively.
    /// Gibalik ang usa ka `Found` nga adunay kuptanan sa parehas nga KV, kung adunay.
    /// Kung dili, ibalik ang usa ka `GoDown` nga adunay kuptanan sa dahon nga edge diin nahisakop ang yawi.
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo pinaagi sa yawi, sama sa kahoy sa usa ka `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Ang pagkanaug sa pinakaduol nga node diin ang edge nga nagtugma sa ubos nga gilis sa range lainlain gikan sa edge nga nagtugma sa taas nga utlanan, ie, ang pinakaduol nga node nga adunay labing menos usa ka yawe nga sulud sa sulud.
    ///
    ///
    /// Kung nakit-an, ibalik ang usa ka `Ok` nga adunay kana nga node, ang pares nga mga indeks sa edge diha niini nga nagtangtang sa sakup, ug ang katugbang nga paris sa mga utlanan alang sa pagpadayon sa pagpangita sa mga node sa bata, kung ang node naa sa sulud.
    ///
    /// Kung wala nakit-an, ibalik ang usa ka `Err` nga adunay dahon nga edge nga katugbang sa tibuuk nga sakup.
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo sa yawi.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Kinahanglan nga likayan ang pagsulud sa kini nga mga variable.
        // Giisip namon nga ang mga utlanan nga gireport sa `range` nagpabilin nga pareho, apan ang usa ka kontra nga pagpatuman mahimong mausab taliwala sa mga tawag nga (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Nakit-an ang usa ka edge sa node nga nagtangtang sa ubos nga gilis sa usa ka sakup.
    /// Gibalik usab ang ubos nga gigapos aron magamit alang sa pagpadayon sa pagpangita sa parehas nga node sa bata, kung ang `self` usa ka internal node.
    ///
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo sa yawi.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Pag-clone sa `find_lower_bound_edge` alang sa taas nga utlanan.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Nagpangita usa ka gihatag nga yawi sa node, nga wala`y recursion.
    /// Gibalik ang usa ka `Found` nga adunay kuptanan sa parehas nga KV, kung adunay.
    /// Kung dili, ibalik ang usa ka `GoDown` nga adunay kuptanan sa edge kung diin makit-an ang yawi (kung ang node naa sa sulud) o kung diin mahimong masulud ang yawi.
    ///
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo pinaagi sa yawi, sama sa kahoy sa usa ka `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Gibalik ang indeks sa KV sa node diin naa ang yawi (o us aka katumbas), o ang indeks nga edge kung diin nahisakop ang yawi.
    ///
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo pinaagi sa yawi, sama sa kahoy sa usa ka `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Nakapangita usa ka indeks nga edge sa node nga nagtangtang sa ubos nga gilis sa usa ka sakup.
    /// Gibalik usab ang ubos nga gigapos aron magamit alang sa pagpadayon sa pagpangita sa parehas nga node sa bata, kung ang `self` usa ka internal node.
    ///
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo sa yawi.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Pag-clone sa `find_lower_bound_index` alang sa taas nga utlanan.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}