use core::marker::PhantomData;
use core::ptr::NonNull;

/// Ang mga modelo usa ka paghulam sa us aka talagsaon nga pakisayran, kung nahibal-an nimo nga ang paghulam ug ang tanan nga mga kaliwatan niini (ie, tanan nga mga panudlo ug pakisayran nga nakuha gikan niini) dili na magamit sa pila ka punto, pagkahuman gusto nimo gamiton ang orihinal nga talagsaon nga reperensya. .
///
///
/// Kasagaran gihatagan sa checker sa panghulam ang kini nga pagpatong sa mga gihulam alang kanimo, apan ang pipila nga mga pag-agay sa pagkontrol nga nagtuman sa kini nga pag-stack sobra ka komplikado alang sa tagsunod.
/// Gitugotan ka sa usa ka `DormantMutRef` nga susihon ang paghulam sa imong kaugalingon, samtang gipahayag pa ang nakasalansan nga kinaiya niini, ug pag-encapsulate sa hilaw nga pointer code nga kinahanglan aron mahimo kini nga wala matino ang pamatasan.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Pagdakup usa ka talagsaon nga pahulam, ug dayon rebondi kini.
    /// Alang sa tagtipon, ang tibuok kinabuhi nga bag-ong pakisayran parehas sa tibuok kinabuhi nga orihinal nga pakisayran, apan ikaw promise nga gamiton kini sa usa ka mubu nga panahon.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KALUWASAN: gihuptan namon ang pagpangutang sa tibuuk 'a pinaagi sa `_marker`, ug gibutyag namon
        // lamang paghisgot niini, mao nga kini mao ang talagsaon.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Mobalik sa talagsaon nga pahulam nga una nga nakuha.
    ///
    /// # Safety
    ///
    /// Ang paghulam kinahanglan natapos na, ie, ang pakisayran nga gibalik sa `new` ug tanan nga mga panudlo ug pakisayran nga gikan niini, kinahanglan dili na gamiton.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KALUWASAN: ang among kaugalingon nga mga kondisyon sa kahilwasan nagpasabut nga kini nga pakisayran na usab nga talagsaon.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;