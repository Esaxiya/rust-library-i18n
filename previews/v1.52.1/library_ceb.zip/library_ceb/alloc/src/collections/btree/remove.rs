use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Gikuha ang usa ka pares nga key-value gikan sa kahoy, ug gibalik ang pares, ingon man ang dahon nga edge nga katumbas sa kanhing pares.
    /// Posible nga gihaw-asan niini ang usa ka root node nga sulud, diin ang magtawag kinahanglan nga mag-pop gikan sa mapa nga nagkupot sa kahoy.
    /// Kinahanglan usab nga maminusan sa nanawag ang gitas-on sa mapa.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Kinahanglan naton nga kalimtan nga temporaryo ang tipo sa bata, tungod kay wala`y lahi nga tipo sa node alang sa diha-diha nga mga ginikanan sa usa ka dahon.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // KALUWASAN: Ang `new_pos` mao ang dahon nga gisugdan namon o usa ka igsoon.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Kung naghiusa ra kami, ang ginikanan (kung adunay) mikunhod, apan ang paglaktaw sa mosunud nga lakang kung dili dili magbayad sa mga benchmark.
            //
            // KALUWASAN: Dili namon gub-on o ayohon pag-usab ang dahon diin naa ang `pos`
            // pinaagi sa pagdumala sa ginikanan niini nga recursively;sa labing daotan gub-on o susihon namon ang ginikanan pinaagi sa apohan, sa ingon pag-ilis ang link sa ginikanan sa sulud sa dahon.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Kuhaa ang usa ka sikbit nga KV gikan sa dahon ug pagkahuman ibalik kini puli sa elemento nga gihangyo namon nga tangtangon.
        //
        // Labi ang wala nga kasikbit nga KV, alang sa mga hinungdan nga gilista sa `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Ang sulud nga node mahimong gikawat gikan o gisagol.
        // Balik sa tuo aron makapangita kung diin nahuman ang orihinal nga KV.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}