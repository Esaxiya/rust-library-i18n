// Kini usa ka pagsulay sa usa ka pagpatuman nga nagsunod sa sulundon
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Tungod kay ang Rust sa tinuud wala`y mga gisaligan nga lahi ug polymorphic recursion, gihimo namon ang daghang dili pagsalig.
//

// Ang usa ka punoan nga katuyoan sa kini nga modyul mao ang paglikay sa pagkakumplikado pinaagi sa pagtratar sa kahoy ingon usa ka generic (kung lain ang porma) nga sulud ug likayan ang pag-atubang sa kadaghanan sa mga nagdapit sa B-Tree.
//
// Ingon niana, dili kini igsapayan sa modyul kung ang mga entry gisunod, unsang mga node ang mahimong underfull, o bisan kung unsa ang gipasabut sa underfull.Bisan pa, nagsalig kami sa pila ka mga invariant:
//
// - Ang mga punoan kinahanglan adunay parehas nga depth/height.Kini nagpasabut nga ang matag agianan padulong sa usa ka dahon gikan sa usa ka gihatag nga node adunay eksaktong parehas nga gitas-on.
// - Ang usa ka node nga adunay gitas-on nga `n` adunay mga key nga `n`, mga kantidad nga `n`, ug mga ngilit nga `n + 1`.
//   Nagpasabut kini nga bisan ang usa ka walay sulod nga node adunay labing menos usa ka edge.
//   Kay sa usa ka dahon binurotan, hubag, "having an edge" nagpasabot lamang nga kita sa pag-ila sa usa ka posisyon sa binurotan, hubag, kay dahon sulab mao ang walay sulod ug wala magkinahanglan data nga representasyon.
// Sa usa ka sulud nga node, ang usa ka edge pareho nga nagpaila sa usa ka posisyon ug adunay sulud nga usa ka pointer sa usa ka node sa bata.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ang nagpahiping representasyon sa mga leaf node ug bahin sa representasyon sa mga internal node.
struct LeafNode<K, V> {
    /// Gusto namon nga mag-covariant sa `K` ug `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ang indeks sa node niini ngadto sa `edges` array sa parent node.
    /// `*node.parent.edges[node.parent_idx]` kinahanglan parehas nga butang sa `node`.
    /// Gagarantiyahan lang nga mapasugod kini kung ang `parent` wala`y null.
    parent_idx: MaybeUninit<u16>,

    /// Ang gidaghanon sa mga yawi ug gipabili sa mga node store.
    len: u16,

    /// Ang mga array nga nagtipig sa tinuud nga datos sa node.
    /// Ang nahauna nga mga elemento nga `len` sa matag array ang gisugdan ug husto.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Gipauna ang usa ka bag-ong lugar nga `LeafNode`.
    unsafe fn init(this: *mut Self) {
        // Ingon usa ka kinatibuk-ang palisiya, gibiyaan namon ang mga natad nga wala`y pahinungod kung mahimo kini, tungod kay kini kinahanglan parehas nga labi ka dali ug kadali sa pagsubay sa Valgrind.
        //
        unsafe {
            // parent_idx, mga yawi, ug vals tanan tingaliUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Naghimo usa ka bag-ong kahon nga `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ang nagpahiping representasyon sa mga internal node.Sama sa `LeafNode`s, kini kinahanglan itago sa likud sa 'BoxedNode`s aron mapugngan ang paghulog sa wala mahibal-an nga mga yawi ug mithi.
/// Ang bisan unsang tudlo sa usa ka `InternalNode` mahimong direkta nga igasalibay sa usa ka tudlo sa nagpahiping `LeafNode` nga bahin sa node, nga gitugotan ang code nga molihok sa dahon ug sa sulud nga mga node nga kasagaran nga dili kinahanglan nga susihon usab kung kinsa sa duha ang gipunting sa usa ka pointer.
///
/// Ang pagpanag-iya niini gipaandar sa paggamit sa `repr(C)`.
///
#[repr(C)]
// gdb_providers.py naggamit kini nga ngalan sa tipo alang sa pagsusi.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ang mga panudlo sa mga bata sa kini nga node.
    /// `len + 1` sa mga kini giisip nga pasiuna ug balido, gawas nga sa hapit na ang katapusan, samtang ang punoan gihuptan pinaagi sa matang sa pagpangutang nga `Dying`, ang pipila sa mga panudlo nga kini nagbitay.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Naghimo usa ka bag-ong kahon nga `InternalNode`.
    ///
    /// # Safety
    /// Ang usa ka invariant sa sulud nga mga node mao nga sila adunay labing menos usa ka una ug balido nga edge.
    /// Ang kini nga pag-andar dili mag-set up sa ingon usa ka edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Kinahanglan ra namon nga unahon ang datos;ang mga ngilit tingaliUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Usa ka madumala, dili null nga tudlo sa usa ka node.Kini usa man nga tag-iya sa pointer sa `LeafNode<K, V>` o tag-iya sa pointer sa `InternalNode<K, V>`.
///
/// Bisan pa, ang `BoxedNode` wala`y kasayuran kung kinsa sa duha nga lahi sa mga node nga tinuod nga sulud niini, ug, bahin tungod sa kakulang niini nga kasayuran, dili usa ka bulag nga lahi ug wala`y makaguba.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ang node sa gamot sa usa ka tag-iya nga kahoy.
///
/// Hinumdomi nga wala kini usa ka makaguba, ug kinahanglan nga limpyohan sa kamut.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Nagpauli usa ka bag-ong tag-iya nga kahoy, nga adunay kaugalingon nga root node nga sa sinugdan wala`y laman.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` kinahanglan dili zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Nagbag-o nga makahulam sa gipanag-iya root node.
    /// Dili sama sa `reborrow_mut`, luwas kini tungod kay ang bili sa pagbalik dili magamit aron madaut ang ugat, ug wala`y mahimo`g uban pang mga pakisayran sa kahoy.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Gamay nga mabalhin nga makahulam sa gipanag-iya root node.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Dili mabalhin nga pagbalhin sa usa ka pakisayran nga nagtugot sa traversal ug nagtanyag mga makadaot nga pamaagi ug gamay pa.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Nagdugang usa ka bag-ong internal node nga adunay us aka edge nga nagtudlo sa miaging root node, himua kanang bag-ong node ang root node, ug ibalik kini.
    /// Kini nagdugang sa gitas-on sa 1 ug sukwahi sa `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, gawas nga nakalimtan na namon nga naa kami sa sulod karon:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Gikuha ang sulud nga node sa gamot, gigamit ang una nga anak ingon bag-ong root node.
    /// Ingon nga kini gituyo aron lamang tawgon kung ang root node adunay usa ka anak, wala`y pagpanglimpyo nga gihimo sa bisan unsang mga yawi, mithi ug uban pang mga bata.
    ///
    /// Gimubu niini ang gitas-on sa 1 ug sukwahi sa `push_internal_level`.
    ///
    /// Gikinahanglan ang eksklusibo nga pag-access sa `Root` nga butang apan dili sa root node;
    /// dili niini mapapas ang ubang mga pagdumala o pakisayran sa root node.
    ///
    /// Panics kung wala`y lebel sa sulud, ie, kung ang root node usa ka dahon.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // KALUWAS: gipahayag namon nga sulud.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KALUWASAN: eksklusibo nga gihulaman namon ang `self` ug ang tipo sa paghulam eksklusibo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KALUWASAN: ang una nga edge kanunay gisugdan.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Ang `NodeRef` kanunay nga covariant sa `K` ug `V`, bisan kung ang `BorrowType` `Mut`.
// Kini sayup nga teknikal, apan dili mahimo nga sangputanan ang bisan unsang dili pagkalig-on tungod sa sulud nga paggamit sa `NodeRef` tungod kay nagpabilin kami nga hingpit nga labaw sa `K` ug `V`.
//
// Bisan pa, bisan kanus-a ang usa ka publiko nga tipo nagputos sa `NodeRef`, siguruha nga kini adunay husto nga kalainan.
//
/// Usa ka pakisayran sa usa ka node.
///
/// Kini nga tipo adunay usa ka ihap sa mga parameter nga nagkontrol kung giunsa kini molihok:
/// - `BorrowType`: Usa ka tipo sa dummy nga naghulagway sa lahi nga panghulam ug nagdala sa tibuok kinabuhi.
///    - Kung kini ang `Immut<'a>`, ang `NodeRef` molihok nga hapit sama sa `&'a Node`.
///    - Kung kini ang `ValMut<'a>`, ang `NodeRef` molihok nga hapit sama sa `&'a Node` bahin sa mga yawi ug istraktura sa kahoy, apan gitugotan usab ang daghang mga mutable referensya sa mga kantidad sa tibuuk nga kahoy nga magkauban.
///    - Kung kini ang `Mut<'a>`, ang `NodeRef` naglihok nga hapit sama sa `&'a mut Node`, bisan kung ang mga pamaagi sa pagsal-ot nagtugot sa usa ka mabalhin nga tudlo sa usa ka kantidad nga magkauban.
///    - Kung kini ang `Owned`, ang `NodeRef` molihok nga hapit sama sa `Box<Node>`, apan wala`y usa nga makaguba, ug kinahanglan nga limpyohan nga kamut.
///    - Kung kini ang `Dying`, ang `NodeRef` molihok pa usab hapit sama sa `Box<Node>`, apan adunay mga pamaagi aron madaut ang kahoy sa hinayhinay, ug ang mga yano nga pamaagi, bisan wala gimarkahan nga dili luwas tawagan, mahimo`g maghangyo sa UB kung dili husto ang pagtawag niini.
///
///   Tungod kay ang bisan unsang `NodeRef` nagtugot sa pag-navigate sa puno, ang `BorrowType` epektibo nga magamit sa tibuuk nga kahoy, dili ra sa node mismo.
/// - `K` ug `V`: Kini ang mga lahi sa yawi ug kantidad nga gitipig sa mga node.
/// - `Type`: Mahimo kini `Leaf`, `Internal`, o `LeafOrInternal`.
/// Kung kini ang `Leaf`, ang `NodeRef` nagpunting sa usa ka leaf node, kung kini ang `Internal` ang `NodeRef` nagpunting sa usa ka internal nga node, ug kung kini ang `LeafOrInternal` ang `NodeRef` mahimong magtudlo sa bisan unsang lahi nga node.
///   `Type` ginganlan `NodeType` kung gigamit sa gawas sa `NodeRef`.
///
/// Parehas ang `BorrowType` ug `NodeType` nga nagpugong kung unsang mga pamaagi ang among gipatuman, aron pahimuslan ang kahilwasan sa static type.Adunay mga limitasyon sa paagi nga magamit namon ang ingon nga mga pagdili:
/// - Alang sa matag parameter sa lahi, mahimo ra namon ipasabut ang usa ka pamaagi sa kasagaran o alang sa usa ka piho nga lahi.
/// Pananglitan, dili namon mahibal-an ang usa ka pamaagi sama sa `into_kv` sa kasagaran alang sa tanan nga `BorrowType`, o kausa alang sa tanan nga lahi nga nagdala sa tibuok kinabuhi, tungod kay gusto namon nga ibalik ang mga reperensya nga `&'a`.
///   Tungod niini, gihubit ra namon kini alang sa labing dyutay nga kusug nga tipo `Immut<'a>`.
/// - Dili kami makakuha og implicit nga pagpamugos gikan sa giingon nga `Mut<'a>` hangtod `Immut<'a>`.
///   Busa, kinahanglan naton tataw nga tawagan ang `reborrow` sa labi ka kusug nga `NodeRef` aron maabut ang usa ka pamaagi sama sa `into_kv`.
///
/// Ang tanan nga mga pamaagi sa `NodeRef` nga ningbalik usa ka klase nga pakisayran, bisan kinsa:
/// - Dad-a ang `self` sa kantidad, ug ibalik ang tibuok kinabuhi nga gidala sa `BorrowType`.
///   Usahay, aron magamit ang ingon nga pamaagi, kinahanglan naton tawagan ang `reborrow_mut`.
/// - Dad-a ang `self` pinaagi sa pakisayran, ug ibalik sa (implicitly) ang tibuok kinabuhi sa reperensiya nga hulip sa tibuok kinabuhi nga gidala sa `BorrowType`.
/// Nianang paagiha, garantiya sa nanghulam nga checker nga ang `NodeRef` nagpabilin nga nahulam basta gigamit ang gibalik nga reperensiya.
///   Ang mga pamaagi nga pagsuporta isuksok ang kini nga lagda pinaagi sa pagpabalik sa usa ka hilaw nga puntos, ie, usa ka pakisayran nga wala`y bisan unsang kinabuhi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Ang ihap sa mga lebel nga ang node ug ang lebel sa mga dahon magkabulag, usa ka kanunay nga node nga dili hingpit nga mahulagway sa `Type`, ug nga ang node mismo wala magtipig.
    /// Kinahanglan lang naton tipigan ang kataas sa root node, ug kuhaon ang matag taas nga node gikan niini.
    /// Kinahanglan nga zero kung `Type` ang `Leaf` ug dili zero kung `Type` ang `Internal`.
    ///
    ///
    height: usize,
    /// Ang tudlo sa dahon o internal node.
    /// Ang gipasabut sa `InternalNode` nagsiguro nga ang panudlo balido sa bisan unsang paagi.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// I-unpack ang usa ka reperensiya sa node nga giputos ingon `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Gibutyag ang datos sa usa ka sulud nga node.
    ///
    /// Nagpauli usa ka hilaw nga ptr aron malikayan nga dili mabalido ang ubang mga pakisayran sa node nga kini.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KALUWASAN: ang tipo nga static node mao ang `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nanghulam sa eksklusibong pag-access sa datos sa usa ka sulud nga node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Makita ang gitas-on sa node.Kini ang ihap sa mga yawi o mithi.
    /// Ang gidaghanon sa mga ngilit mao ang `len() + 1`.
    /// Hinumdomi nga, bisan kung luwas ka, ang pagtawag sa kini nga pag-andar mahimo`g adunay epekto nga dili mabalibaran ang mga mutable nga pakisayran nga gihimo sa dili luwas nga code.
    ///
    pub fn len(&self) -> usize {
        // Sa hinungdanon, gi-access ra namon ang `len` nga natad dinhi.
        // Kung ang BorrowType mao ang marker::ValMut, mahimong adunay mga labi nga mabalhin nga mga pakisayran sa mga kantidad nga dili namon kinahanglan nga dili balido.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Gibalik ang ihap sa mga lebel nga bulag sa node ug dahon.
    /// Ang gitas-on sa zero mao ang gipasabut sa node usa ka dahon mismo.
    /// Kung hulagway nimo ang mga kahoy nga adunay gamot sa taas, giingon sa numero kung diin makita ang taas nga node.
    /// Kung hulagway nimo ang mga kahoy nga adunay mga dahon sa taas, isulti sa numero kung unsa kataas ang gitas-on sa kahoy sa ibabaw sa node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Temporaryo nga pagkuha usa pa, dili mabalhin nga pakisayran sa parehas nga node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Gibutyag ang bahin sa dahon sa bisan unsang dahon o internal node.
    ///
    /// Nagpauli usa ka hilaw nga ptr aron malikayan nga dili mabalido ang ubang mga pakisayran sa node nga kini.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ang node kinahanglan nga balido alang sa labing menos nga bahin sa LeafNode.
        // Dili kini usa ka pakisayran sa tipo sa NodeRef tungod kay wala kami nahibal-an kung kini kinahanglan ba nga talagsaon o gipaambit.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Makita ang ginikanan sa karon nga node.
    /// Gibalik ang `Ok(handle)` kung ang karon nga node tinuod nga adunay ginikanan, diin ang `handle` nagpunting sa edge sa ginikanan nga nagtudlo sa karon nga node.
    ///
    /// Gibalik ang `Err(self)` kung ang karon nga node wala`y ginikanan, nga gibalik ang orihinal nga `NodeRef`.
    ///
    /// Gipangita ka sa ngalan sa pamaagi og mga litrato nga mga kahoy nga adunay root node sa taas.
    ///
    /// `edge.descend().ascend().unwrap()` ug `node.ascend().unwrap().descend()` kinahanglan pareho, sa kalampusan, wala'y buhaton.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kinahanglan namon nga gamiton ang mga hilaw nga panudlo sa mga node tungod kay, kung ang BorrowType mao ang marker::ValMut, mahimong adunay mga labi ka mutable nga mga reperensiya sa mga kantidad nga dili namon kinahanglan nga dili balido.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Hinumdomi nga ang `self` kinahanglan nga dili pang-nempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Hinumdomi nga ang `self` kinahanglan nga dili pang-nempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Gibutyag ang bahin sa dahon sa bisan unsang dahon o internal node sa usa ka dili mabalhin nga kahoy.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KALUWASAN: wala`y mga mutable referensya sa kini nga kahoy nga gihulaman ingon `Immut`.
        unsafe { &*ptr }
    }

    /// Nanghulam usa ka panan-aw sa mga yawe nga gitipig sa node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Susama sa `ascend`, nakakuha usa ka pakisayran sa node's node sa ginikanan, apan gi-translocate usab ang karon nga node sa proseso.
    /// Dili kini luwas tungod kay ang karon nga node mahimong ma-access bisan kung gi-deallocate.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Dili malig-on nga gipahayag sa nag-compiler ang static nga kasayuran nga kini nga node usa ka `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Dili malig-on nga gipahayag sa nag-compiler ang static nga kasayuran nga kini nga node usa ka `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Temporaryo nga pagkuha usa pa, mabalhin nga pakisayran sa parehas nga node.Paglikay, tungod kay kini nga pamaagi peligroso kaayo, doblehon sanglit dili kini dayon makita nga peligro.
    ///
    /// Tungod kay ang mga mabalhin nga panudlo mahimong maglibotlibot bisan diin sa punoan sa kahoy, ang gipabalik nga tuldok dali nga magamit aron himuon ang orihinal nga panudlo nga nakabitay, wala`y utlanan, o dili balido sa ilalum sa mga gipatong nga mga lagda.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ikonsiderar ang pagdugang usa pa nga lahi nga parameter sa `NodeRef` nga nagpugong sa paggamit sa mga pamaagi sa pag-navigate sa mga gihulma nga mga panudlo, nga nagpugong sa kini nga dili kasiguroan.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Manghulam eksklusibo nga pag-access sa bahin sa dahon sa bisan unsang dahon o internal node.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KALUWASAN: adunay kami eksklusibo nga pag-access sa tibuuk nga node.
        unsafe { &mut *ptr }
    }

    /// Nagtanyag eksklusibo nga pag-access sa dahon nga bahin sa bisan unsang dahon o internal node.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KALUWASAN: adunay kami eksklusibo nga pag-access sa tibuuk nga node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nanghulam sa eksklusibong pag-access sa usa ka elemento sa yawe nga lugar sa pagtipig.
    ///
    /// # Safety
    /// `index` naa sa utlanan nga 0..KAHUSAYON
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KALUWASAN: ang magtawag dili makatawag sa dugang nga mga pamaagi sa kaugalingon
        // hangtod nga nahulog ang hinungdan nga reperensiya sa hiwa tungod kay kami adunay talagsaon nga pag-access sa tibuok kinabuhi nga pagpangutang.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Nanghulam sa eksklusibong pag-access sa usa ka elemento o tipik sa lugar nga tipiganan sa kantidad sa node.
    ///
    /// # Safety
    /// `index` naa sa utlanan nga 0..KAHUSAYON
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KALUWASAN: ang magtawag dili makatawag sa dugang nga mga pamaagi sa kaugalingon
        // hangtod nga nahulog ang reperensya sa hiwa sa kantidad, tungod kay kami adunay talagsaon nga pag-access sa tibuok kinabuhi nga pagpangutang.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nanghulam sa eksklusibong pag-access sa usa ka elemento o tipik sa lugar nga tipiganan sa node alang sa mga sulud nga edge.
    ///
    /// # Safety
    /// `index` naa sa mga utlanan nga 0..KAHUSAYAN + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KALUWASAN: ang magtawag dili makatawag sa dugang nga mga pamaagi sa kaugalingon
        // hangtod nga nahulog ang reperensya sa hiwa sa edge, tungod kay adunay kami talagsaon nga pag-access sa tibuok kinabuhi nga pagpangutang.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ang node adunay labaw pa sa `idx` nga inisyal nga mga elemento.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Naghimo lang kami usa ka pakisayran sa usa ka elemento nga gusto namon, aron malikayan ang pag-aliasing sa mga wala`y labot nga mga pakisayran sa ubang mga elemento, labi na ang mga mibalik sa nanawag sa naunang mga pag-ulit.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kinahanglan naton pugson ang mga wala`y sukod nga mga tudlo sa array tungod sa isyu nga Rust nga #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nanghulam sa eksklusibong pag-access sa gitas-on sa node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Gitakda ang link sa node sa iyang ginikanan nga edge, nga wala gipanghimatuud ang ubang mga pakisayran sa node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Giklaro ang link sa ugat sa iyang ginikanan nga edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Nagdugang usa ka pares nga key-value sa katapusan sa node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ang matag butang nga gibalik sa `range` usa ka balido nga indeks sa edge alang sa node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nagdugang usa ka pares nga key-value, ug usa ka edge aron moadto sa tuo sa kanang pares, sa katapusan sa node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Gisusi kung ang usa ka node usa ka `Internal` node o usa ka `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Usa ka pakisayran sa usa ka piho nga pares sa key-value o edge sulud sa usa ka node.
/// Ang `Node` parameter kinahanglan usa ka `NodeRef`, samtang ang `Type` mahimo nga `KV` (nagpasabut sa usa ka kuptanan sa usa ka pares nga key-value) o `Edge` (nagpasabut sa usa ka kuptanan sa usa ka edge).
///
/// Hinumdomi nga bisan ang `Leaf` nodes mahimo nga adunay `Edge` nga pagdumala.
/// Hinuon nga nagrepresentar sa usa ka pointer sa usa ka node sa bata, kini nagrepresentar sa mga wanang diin moadto ang mga panudlo sa bata taliwala sa mga pares nga key-value.
/// Pananglitan, sa usa ka node nga adunay gitas-on nga 2, adunay 3 posible nga mga lokasyon sa edge, usa sa wala sa node, usa taliwala sa duha nga pares, ug usa sa tuo nga node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Dili namon kinahanglan ang bug-os nga kinatibuk-an nga `#[derive(Clone)]`, tungod kay ang bugtong higayon nga `Node` mahimong `Klone`able kung kini usa ka dili mabalhin nga pakisayran ug busa `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Gikuha ang node nga adunay sulud nga edge o pares nga key-value nga gipunting niini nga pagdumala.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Gibalik ang posisyon sa kini nga kuptanan sa node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Naghimo usa ka bag-ong kuptanan sa usa ka pares nga key-value sa `node`.
    /// Dili luwas tungod kay kinahanglan nga masiguro sa nanawag nga `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Mahimo nga usa ka publiko nga pagpatuman sa PartialEq, apan gigamit ra sa kini nga modyul.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Temporaryo nga pagkuha usa pa, dili mabalhin nga kuptanan sa parehas nga lokasyon.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Dili namon magamit ang Handle::new_kv o Handle::new_edge tungod kay wala namon nahibal-an ang among lahi
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Dili malig-on nga gipahayag sa nag-compiler ang static nga kasayuran nga ang node sa kuptanan usa ka `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Temporaryo nga pagkuha usa pa, mabalhin nga kuptanan sa parehas nga lokasyon.
    /// Paglikay, tungod kay kini nga pamaagi peligroso kaayo, doblehon sanglit dili kini dayon makita nga peligro.
    ///
    ///
    /// Alang sa mga detalye, tan-awa ang `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Dili namon magamit ang Handle::new_kv o Handle::new_edge tungod kay wala namon nahibal-an ang among lahi
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Naghimo usa ka bag-ong kuptanan sa usa ka edge sa `node`.
    /// Dili luwas tungod kay kinahanglan nga masiguro sa nanawag nga `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Gihatagan usa ka indeks sa edge diin gusto namon isulud sa usa ka node nga puno sa kapasidad, makalkulo ang usa ka makatarunganon nga indeks sa KV sa usa ka split point ug kung diin himuon ang pagsulud.
///
/// Ang katuyoan sa split point alang sa yawe ug kantidad niini nga matapos sa usa ka node sa ginikanan;
/// ang mga yawi, mithi ug ngilit sa wala sa split point mahimong wala nga bata;
/// ang mga yawi, mithi ug ngilit sa tuo sa split point mahimong tama nga bata.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Gisulayan sa isyu sa Rust nga #74834 nga ipatin-aw ang kini nga mga simetriko nga balaod.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gisal-ot ang usa ka bag-ong pares nga key-value taliwala sa mga pares nga key-value sa tuo ug wala sa kini nga edge.
    /// Gipasabut sa kini nga pamaagi nga adunay igo nga wanang sa node alang sa bag-ong pares nga angay.
    ///
    /// Ang gipabalik nga pointer nagpunting sa gisukip nga kantidad.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gisal-ot ang usa ka bag-ong pares nga key-value taliwala sa mga pares nga key-value sa tuo ug wala sa kini nga edge.
    /// Kini nga pamaagi nagbulag sa node kung wala`y igong sulud.
    ///
    /// Ang gipabalik nga pointer nagpunting sa gisukip nga kantidad.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Gikay-ong ang punoan sa ginikanan ug indeks sa node sa bata nga gisumpay niini nga edge.
    /// Kini mapuslanon kung ang paghan-ay sa mga ngilit nabag-o,
    fn correct_parent_link(self) {
        // Paghimo backpointer nga wala gipanghimatuud ang ubang mga pakisayran sa node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Gisal-ot ang usa ka bag-ong pares nga key-value ug usa ka edge nga moadto sa tuo sa kanang bag-ong pares taliwala sa edge ug ang key-value pares sa tuo niining edge.
    /// Gipasabut sa kini nga pamaagi nga adunay igo nga wanang sa node alang sa bag-ong pares nga angay.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Gisal-ot ang usa ka bag-ong pares nga key-value ug usa ka edge nga moadto sa tuo sa kanang bag-ong pares taliwala sa edge ug ang key-value pares sa tuo niining edge.
    /// Kini nga pamaagi nagbulag sa node kung wala`y igong sulud.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gisal-ot ang usa ka bag-ong pares nga key-value taliwala sa mga pares nga key-value sa tuo ug wala sa kini nga edge.
    /// Gibahinbahin sa kini nga pamaagi ang node kung wala`y igong sulud, ug gisulayan nga isulud ang bahin sa split off sa parent node nga recursively, hangtod nga naabut ang gamot.
    ///
    ///
    /// Kung ang gibalik nga sangputanan usa ka `Fit`, ang node sa hawakan niini mahimo`g node sa edge o usa ka katigulangan.
    /// Kung ang gibalik nga sangputanan usa ka `Split`, ang `left` nga uma mahimong ugat node.
    /// Ang gipabalik nga pointer nagpunting sa gisukip nga kantidad.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Makita ang node nga gitudlo sa kini nga edge.
    ///
    /// Gipangita ka sa ngalan sa pamaagi og mga litrato nga mga kahoy nga adunay root node sa taas.
    ///
    /// `edge.descend().ascend().unwrap()` ug `node.ascend().unwrap().descend()` kinahanglan pareho, sa kalampusan, wala'y buhaton.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Kinahanglan namon nga gamiton ang mga hilaw nga panudlo sa mga node tungod kay, kung ang BorrowType mao ang marker::ValMut, mahimong adunay mga labi ka mutable nga mga reperensiya sa mga kantidad nga dili namon kinahanglan nga dili balido.
        // Wala`y kabalaka sa pag-access sa taas nga kapatagan tungod kay ang kantidad gikopya.
        // Pagbantay nga, sa higayon nga ang node pointer gihatagan gahum, gi-access namon ang mga sulud nga sulud nga adunay usa ka pakisayran (Rust isyu #73987) ug gipanghimatuud ang bisan unsang uban pang mga pakisayran o sa sulud sa laray, kinahanglan adunay bisan kinsa nga anaa sa palibut.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Dili namon matawag nga bulag ang mga pamaagi sa yawi ug kantidad, tungod kay ang pagtawag sa ikaduha wala magpanghimatuud sa pakisayran nga gibalik sa nahauna.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Puli ang yawi ug kantidad nga gitumod sa hawakan sa KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Nagtabang sa pagpatuman sa `split` alang sa usa ka piho nga `NodeType`, pinaagi sa pag-amping sa datos sa dahon.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Gibahin ang nagpahiping node sa tulo nga bahin:
    ///
    /// - binurotan, hubag ang truncated sa naglakip lamang sa mga parisan yawi-bili sa mga nahibilin sa kuptanan niini.
    /// - Ang yawi ug kantidad nga gitudlo sa kini nga kuptanan gikuha.
    /// - Ang tanan nga mga pares nga key-value sa tuo sa kini nga kuptanan gibutang sa usa ka bag-ong gigahin nga node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Gikuha ang pares nga key-value nga gitudlo sa kini nga gunitanan ug ibalik kini, kauban ang edge nga nahugno sa pares nga key-value.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Gibahin ang nagpahiping node sa tulo nga bahin:
    ///
    /// - Ang node giputol nga sulud lamang sulud sa mga sulud ug mga pares nga key-value sa wala sa kini nga kuptanan.
    /// - Ang yawi ug kantidad nga gitudlo sa kini nga kuptanan gikuha.
    /// - Ang tanan nga mga ngilit ug pares nga key-value sa tuo sa kini nga kuptanan gibutang sa usa ka bag-ong gigahin nga node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Nagrepresenta sa usa ka sesyon alang sa pagtimbang-timbang ug paghimo sa usa ka operasyon sa pagbalanse sa palibot sa usa ka sulud nga pares nga key-value.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nagpili usa ka konteksto sa pagbalanse nga naglambigit sa node ingon usa ka bata, sa ingon taliwala sa KV dayon sa wala o sa tuo sa parent node.
    /// Gibalik ang usa ka `Err` kung wala`y ginikanan.
    /// Panics kung ang ginikanan walay sulod.
    ///
    /// Gipalabi ang wala nga kilid, aron mahimo`g labing kaayo kung ang gihatag nga node bisan unsang paagiha wala`y pulos, nagpasabut dinhi nga kini adunay mas gamay nga mga elemento kaysa sa wala nga igsoon ug kaysa sa tuo nga igsoon niini, kung adunay kini.
    /// Sa kana nga kaso, ang paghiusa sa wala nga igsoon labi ka dali, tungod kay kinahanglan ra naton nga balhinon ang mga elemento sa node, imbes nga ibalhin kini sa tuo ug maglihok labi pa sa mga elemento sa N sa atubangan.
    /// Ang pagpangawat gikan sa wala nga igsoon usa usab ka kasagarang mas paspas, tungod kay kinahanglan ra naton nga ibalhin ang mga elemento sa N sa node sa tuo, imbis nga ibalhin ang labing menos nga mga elemento sa igsoon sa wala.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Gibalik kung posible ba ang paghiusa, ie, kung adunay igo nga lugar sa usa ka node aron paghiusa ang sentral nga KV nga adunay parehas nga mga kasikbit nga mga node sa bata.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Naghimo usa ka paghiusa ug gipasagdan ang usa ka pagsira kung unsa ang ibalik.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KALUWASAN: ang gitas-on sa mga node nga gihiusa usa sa ubus sa gitas-on
                // sa node sa kini nga edge, sa ingon labaw sa zero, busa sila sulud.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Gihiusa ang pares nga key-value sa ginikanan ug parehas nga kasikbit nga mga node sa bata sa wala nga node sa bata ug gibalik ang ningkubit nga node sa ginikanan.
    ///
    ///
    /// Panics gawas kung `.can_merge()` kami.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Gihiusa ang pares sa key-value sa ginikanan ug parehas nga kasikbit nga mga node sa bata sa wala nga node sa bata ug gibalik ang node sa bata.
    ///
    ///
    /// Panics gawas kung `.can_merge()` kami.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Gihiusa ang pares nga key-value sa ginikanan ug parehas nga kasikbit nga mga node sa bata sa wala nga node sa bata ug gibalik ang kuptanan sa edge sa kanang node sa bata diin natapos ang gisubay nga bata nga edge,
    ///
    ///
    /// Panics gawas kung `.can_merge()` kami.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Gikuha ang usa ka pares nga key-value gikan sa wala nga bata ug gibutang kini sa key-value storage sa ginikanan, samtang giduso ang tigulang nga key-value pares sa tama nga bata.
    ///
    /// Gibalik ang usa ka kuptanan sa edge sa tuo nga bata nga katugbang diin natapos ang orihinal nga edge nga gitino sa `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Gikuha ang usa ka pares nga key-value gikan sa tuo nga bata ug gibutang kini sa key-value storage sa ginikanan, samtang giduso ang tigulang nga key-value pares sa wala nga bata.
    ///
    /// Mibalik sa usa ka kuptanan sa edge sa wala nga bata nga bungat sa `track_left_edge_idx`, nga wala mobalhin.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Kini ang pagpangawat parehas sa `steal_left` apan gikawat ang daghang mga elemento sa usa ka higayon.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Siguruha nga makapangawat kami nga luwas.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pagbalhin sa datos sa dahon.
            {
                // Himua ang lugar alang sa gikawat nga mga elemento sa husto nga bata.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Igbalhin ang mga elemento gikan sa wala nga bata ngadto sa tuo.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Igbalhin ang labing wala nga gikawat nga pares sa ginikanan.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Igbalhin ang pares sa key-value sa ginikanan sa tama nga anak.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Himua ang lugar alang sa mga kinawat nga ngilit.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Pagpangawat mga ngilit.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ang symmetric clone nga `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Siguruha nga makapangawat kami nga luwas.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pagbalhin sa datos sa dahon.
            {
                // Igbalhin ang labing kinawat nga pares sa ginikanan.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Igbalhin ang pares sa key-value sa ginikanan sa wala nga bata.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Igbalhin ang mga elemento gikan sa tuo nga bata pakadto sa wala.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Pun-a ang gintang kung diin kaniadto mga kinawat nga elemento.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Pagpangawat mga ngilit.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Pun-a ang gintang kung diin kaniadto ang mga kinawat nga ngilit.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Gikuha ang bisan unsang static nga kasayuran nga nagpahayag nga kini nga node usa ka `Leaf` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Gikuha ang bisan unsang static nga kasayuran nga nagpahayag nga kini nga node usa ka `Internal` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Gisusi kung ang nagpahiping node usa ka `Internal` node o usa ka `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Igbalhin ang suffix pagkahuman sa `self` gikan sa usa ka node ngadto sa lain pa.Kinahanglan nga walay sulod ang `right`.
    /// Ang una nga edge sa `right` nagpabilin nga wala mausab.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resulta sa pagsulud, kung kinahanglan ang usa ka node aron mapalapdan lapas sa kapasidad niini.
pub struct SplitResult<'a, K, V, NodeType> {
    // Gibag-o nga node sa naa na nga kahoy nga adunay mga elemento ug ngilit nga nahisakop sa wala sa `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Ang pipila ka mga yawi ug bili nabulag, nga igasulud sa bisan diin.
    pub kv: (K, V),
    // Gipanag-iya, wala`y apil, bag-ong node nga adunay mga elemento ug ngilit nga nahisakop sa tuo nga `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kung ang mga referral nga node sa kini nga klase sa pagpangutang gitugotan ang pag-agi sa ubang mga node sa kahoy.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Dili kinahanglan ang traversal, nahinabo nga gigamit ang sangputanan sa `borrow_mut`.
        // Pinaagi sa pag-disable sa traversal, ug paghimo lang bag-ong mga pakisayran sa mga ugat, nahibal-an namon nga ang matag pakisayran sa `Owned` type naa sa root node.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Gisal-ot ang usa ka kantidad sa usa ka hiwa nga gisugdan nga mga elemento nga gisundan sa usa ka wala nahibal-an nga elemento.
///
/// # Safety
/// Ang hiwa adunay labaw pa sa `idx` nga mga elemento.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Gikuha ug gibalik ang usa ka kantidad gikan sa usa ka hiwa sa tanan nga gisugdan nga mga elemento, gibiyaan ang usa nga nagsunod nga wala mahibal-an nga elemento.
///
///
/// # Safety
/// Ang hiwa adunay labaw pa sa `idx` nga mga elemento.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Gibag-o ang mga elemento sa usa ka slice `distance` nga posisyon sa wala.
///
/// # Safety
/// Ang hiwa adunay labing menos nga mga elemento nga `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Gibag-o ang mga elemento sa usa ka slice `distance` nga posisyon sa tuo.
///
/// # Safety
/// Ang hiwa adunay labing menos nga mga elemento nga `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Mibalhin ang tanan nga mga prinsipyo gikan sa usa ka ad-ad sa initialized elemento sa usa ka ad-ad sa uninitialized elemento, nga nagbilin sa luyo `src` ingon sa tanan uninitialized.
///
/// Nagtrabaho sama sa `dst.copy_from_slice(src)` apan wala magkinahanglan `T` nga mahimong `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;