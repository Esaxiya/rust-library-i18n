use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Temporaryong mogawas usa pa, dili mabalhin nga katumbas sa parehas nga sakup.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Nakapangita ang lahi nga mga sidsid sa dahon nga nagtangtang sa usa nga gipunting sa usa ka punoan.
    /// Gibalik ang bisan usa ka parisan sa lainlaing mga pagdumala sa parehas nga kahoy o usa ka parisan nga walay sulod nga mga kapilian.
    ///
    /// # Safety
    ///
    /// Gawas kung ang `BorrowType` usa ka `Immut`, ayaw gamita ang mga duplicate nga hawakan aron mabisita ang parehas nga KV kaduha.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Katumbas sa `(root1.first_leaf_edge(), root2.last_leaf_edge())` apan labi ka episyente.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Nakit-an ang pares nga mga ngilit sa dahon nga nagtangtang sa us aka piho nga sakup sa usa ka kahoy.
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo pinaagi sa yawi, sama sa kahoy sa usa ka `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // KALUWASAN: ang among tipo sa paghulam dili mabalhin.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Nakapangita ang pares nga mga ngilit sa dahon nga nagtangtang sa us aka puno nga kahoy.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Gibahin ang usa ka talagsaon nga pakisayran sa usa ka parisan nga mga ngilit sa dahon nga nagtangtang sa usa nga gitakda nga sakup.
    /// Ang sangputanan dili piho nga mga pakisayran nga nagtugot sa pagbag-o sa (some), nga kinahanglan gamiton nga maayo.
    ///
    /// Ang sangputanan makahuluganon lamang kung ang kahoy gisugo pinaagi sa yawi, sama sa kahoy sa usa ka `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Ayaw gamita ang mga duplicate nga hawakan aron makabisita sa parehas nga KV kaduha.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Gibahin ang usa ka talagsaon nga pakisayran sa usa ka parisan nga mga ngilit sa dahon nga nagtangtang sa tibuuk nga sukod sa kahoy.
    /// Ang mga sangputanan dili piho nga mga pakisayran nga nagtugot sa pagbag-o (sa mga kantidad lamang), busa kinahanglan gamiton nga mainampingon.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Gindoble namon ang root NodeRef dinhi-dili gyud namon duawon ang parehas nga KV kaduha, ug dili matapos ang mga nagsapawan nga mga pakisayran sa kantidad.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Gibahin ang usa ka talagsaon nga pakisayran sa usa ka parisan nga mga ngilit sa dahon nga nagtangtang sa tibuuk nga sukod sa kahoy.
    /// Ang mga sangputanan dili piho nga mga pakisayran nga nagtugot sa kadaghan nga makadaot nga mutasyon, mao nga kinahanglan gamiton kini uban ang labing kaibutang pag-amping.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Gindoble namon ang root NodeRef dinhi-dili gyud namon kini mai-access sa paagiha nga nagsapaw sa mga pakisayran nga nakuha gikan sa gamot.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Gihatagan usa ka hawakan nga edge, gibalik ang [`Result::Ok`] nga adunay usa ka kuptanan sa silingan nga KV sa tuo nga kilid, nga naa sa parehas nga node sa dahon o sa usa ka node sa katigulangan.
    ///
    /// Kung ang dahon nga edge mao ang katapusan sa usa ka kahoy, ibalik ang [`Result::Err`] nga adunay root node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Gihatagan usa ka dahon nga kuptanan sa edge, giuli ang [`Result::Ok`] nga adunay usa ka kuptanan sa silingan nga KV sa wala nga kilid, nga naa sa parehas nga node sa dahon o sa usa ka node sa katigulangan.
    ///
    /// Kung ang dahon nga edge mao ang una sa kahoy, ibalik ang [`Result::Err`] nga adunay root node.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Gihatagan usa ka sulud nga pagdumala sa edge, giuli ang [`Result::Ok`] nga adunay usa ka kuptanan sa silingan nga KV sa tuo nga kilid, nga naa sa parehas nga internal node o sa usa ka node sa katigulangan.
    ///
    /// Kung ang sulud nga edge mao ang katapusang usa sa kahoy, ibalik ang [`Result::Err`] nga adunay root node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gihatagan usa ka dahon nga edge kuptanan sa usa ka himatyon nga kahoy, gibalik ang sunod nga dahon nga edge sa tuo nga kilid, ug ang pares nga key-value sa taliwala, nga naa sa parehas nga node sa dahon, sa usa ka node sa katigulangan, o wala.
    ///
    ///
    /// Ang kini nga pamaagi nakigsabot usab sa bisan unsang node(s) nga naabut sa katapusan sa.
    /// Nagpasabut kini nga kung wala na ang pares nga key-value, ang tibuuk nga nahabilin sa kahoy mahimo`g malihok ug wala na`y mahibilin.
    ///
    /// # Safety
    /// Ang gihatag nga edge kinahanglan dili kaniadto gibalik sa counterpart `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Gihatag ang usa ka dahon nga edge kuptanan sa usa ka himatyon nga kahoy, gibalik ang sunod nga dahon nga edge sa wala nga kilid, ug ang pares nga key-value sa taliwala, nga naa sa parehas nga node sa dahon, sa usa ka node sa katigulangan, o wala.
    ///
    ///
    /// Ang kini nga pamaagi nakigsabot usab sa bisan unsang node(s) nga naabut sa katapusan sa.
    /// Nagpasabut kini nga kung wala na ang pares nga key-value, ang tibuuk nga nahabilin sa kahoy mahimo`g malihok ug wala na`y mahibilin.
    ///
    /// # Safety
    /// Ang gihatag nga edge kinahanglan dili kaniadto gibalik sa counterpart `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Nakigsabot sa us aka tumpok nga mga node gikan sa dahon hangtod sa gamot.
    /// Kini ra ang paagi aron mabalhin ang nahabilin sa usa ka punoan pagkahuman sa `deallocating_next` ug `deallocating_next_back` nga nagkutkot sa duha ka kilid sa kahoy, ug naigo ang parehas nga edge.
    /// Ingon nga kini gituyo aron lamang tawgon kung ang tanan nga mga yawi ug kantidad gipabalik, wala`y pagpanglimpyo nga gihimo sa bisan unsang mga yawi o kantidad.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gibalhin ang dahon nga edge kuptanan sa sunod nga dahon nga edge ug ibalik ang mga pakisayran sa yawi ug kantidad sa taliwala.
    ///
    ///
    /// # Safety
    /// Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Gibalhin ang dahon nga edge kuptanan sa miaging dahon nga edge ug gibalik ang mga pakisayran sa yawi ug kantidad sa taliwala.
    ///
    ///
    /// # Safety
    /// Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gibalhin ang dahon nga edge kuptanan sa sunod nga dahon nga edge ug ibalik ang mga pakisayran sa yawi ug kantidad sa taliwala.
    ///
    ///
    /// # Safety
    /// Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Mas dali ang paghimo sa kini nga katapusan, sumala sa mga benchmark.
        kv.into_kv_valmut()
    }

    /// Gibalhin ang dahon nga edge kuptanan sa miaging dahon ug gibalik ang mga pakisayran sa yawi ug kantidad sa taliwala.
    ///
    ///
    /// # Safety
    /// Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Mas dali ang paghimo sa kini nga katapusan, sumala sa mga benchmark.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gibalhin ang dahon nga edge kuptanan sa sunod nga dahon nga edge ug ibalik ang yawi ug kantidad sa taliwala, nga gibalhin ang bisan unsang node nga nahabilin samtang gibiyaan ang katugbang nga edge sa iyang node nga nagbitay.
    ///
    /// # Safety
    /// - Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    /// - Kana nga KV wala kaniadto gibalik sa katugbang `next_back_unchecked` sa bisan unsang kopya sa mga kuptanan nga gigamit sa paglatas sa kahoy.
    ///
    /// Ang luwas ra nga paagi aron makapadayon ang na-update nga kuptanan mao ang pagtandi niini, ihulog kini, tawagan kini nga pamaagi nga napailalom usab sa mga kondisyon sa kahilwasan niini, o tawagan ang katugbang nga `next_back_unchecked` nga gipailalom sa mga kondisyon sa pagkaluwas.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Gibalhin ang dahon nga edge kuptanan sa miaging dahon nga edge ug ibalik ang yawi ug kantidad sa taliwala, nga gibalhin ang bisan unsang node nga nahabilin samtang gibiyaan ang katugbang nga edge sa iyang node nga nagbitay.
    ///
    /// # Safety
    /// - Kinahanglan adunay usa pa nga KV sa direksyon nga gibiyahe.
    /// - Ang kana nga dahon nga edge dili kaniadto gibalik sa katugbang `next_unchecked` sa bisan unsang kopya sa mga kuptanan nga gigamit sa pag-agi sa kahoy.
    ///
    /// Ang luwas ra nga paagi aron makapadayon ang na-update nga kuptanan mao ang pagtandi niini, ihulog kini, tawagan kini nga pamaagi nga napailalom usab sa mga kondisyon sa kahilwasan niini, o tawagan ang katugbang nga `next_unchecked` nga gipailalom sa mga kondisyon sa kahilwasan.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Gibalik ang labing wala nga dahon nga edge sa o sa ilawom sa usa ka node, sa ato pa, ang edge nga kinahanglan nimo una kung mag-navigate sa unahan (o katapusan kung mag-navigate sa likod).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Gibalik ang tuo nga dahon nga edge sa o sa ilawom sa usa ka node, sa lain nga pagkasulti, ang edge nga imong kinahanglan nga katapusan kung mag-navigate sa unahan (o una kung mag-navigate paatras).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ang mga pagbisita sa mga leaf node ug internal KVs sa han-ay sa mga pagsaka nga mga yawe, ug gibisita usab ang mga internal node ingon usa ka tibuuk sa usa ka giladmon nga una nga pagkahan-ay, gipasabut nga ang mga internal nga node nag-una sa ilang tagsatagsa nga mga KV ug mga node sa ilang bata.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Nagtinguha ang gidaghanon sa mga elemento sa usa ka (sub) kahoy.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Gibalik ang dahon nga edge nga labing duul sa usa ka KV alang sa unahan nga nabigasyon.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Gibalik ang dahon nga edge nga labing duul sa usa ka KV alang sa atrasadong nabigasyon.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}