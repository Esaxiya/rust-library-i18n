use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Nagdugang sa tanan nga mga pares nga key-value gikan sa paghiusa sa duha nga nagasaka nga iterator, nga nagdugang usa ka variable nga `length` sa agianan.Ang naulahi naghimo nga dali alang sa nanawag aron malikayan ang usa ka leak kung ang usa ka drop handler nag-panic.
    ///
    /// Kung ang pareho nga mga iterator naghimo sama nga yawi, kini nga pamaagi naghulog sa pares gikan sa wala nga iterator ug gidugtong ang pares gikan sa tuo nga iterator.
    ///
    /// Kung gusto nimo ang kahoy matapos sa usa ka istrikto nga pagkay-ay nga han-ay, sama sa alang sa `BTreeMap`, ang parehas nga iterator kinahanglan maghimo mga yawe sa istrikto nga pagkay-ay nga han-ay, ang matag usa labi ka daghan sa tanan nga mga yawe sa kahoy, lakip ang bisan unsang mga yawe nga naa na sa punoan sa pagsulud.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Giandam namon ang paghiusa sa `left` ug `right` sa usa ka gihan-ay nga han-ay sa linear nga oras.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Samtang, naghimo kami usa ka kahoy gikan sa han-ay nga han-ay sa han-ay nga oras.
        self.bulk_push(iter, length)
    }

    /// Giduso ang tanan nga mga pares nga key-value sa katapusan sa kahoy, nga nagdugang usa ka variable nga `length` sa agianan.
    /// Ang naulahi naghimo nga labing kadali alang sa nanawag nga makalikay sa usa ka leak kung ang iterator nag-panic.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Itereate ang tanan nga pares sa key-value, itulod kini sa mga node sa tama nga lebel.
        for (key, value) in iter {
            // Sulayi nga iduso ang pares nga key-value sa karon nga node sa dahon.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Wala`y nahabilin nga wanang, tungas ug itulak didto.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Nakit-an ang usa ka node nga adunay wala nga wanang, iduso dinhi.
                                open_node = parent;
                                break;
                            } else {
                                // Pagsaka usab.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Naa kami sa taas, paghimo usa ka bag-ong root node ug pagduso didto.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Igduso ang pares sa key-value ug bag-ong tuo nga subtree.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Pag-adto usab sa tuo nga labi nga dahon.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Pagdugang sa gitas-on matag pag-iterate, aron masiguro nga ang mapa nahulog ang mga nadugtong nga elemento bisan kung gipaabante ang mga panicker sa iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Usa ka iterator alang sa paghiusa sa duha nga gihan-ay nga han-ay sa usa
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Kon ang duha ka mga yawe managsama, mobalik ang yawe-bili paris gikan sa too nga tinubdan.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}