use core::intrinsics;
use core::mem;
use core::ptr;

/// Gipulihan niini ang kantidad sa luyo sa `v` nga talagsaon nga reperensya pinaagi sa pagtawag sa may kalabutan nga pagpaandar.
///
///
/// Kung ang usa ka panic mahitabo sa pagsira sa `change`, ang tibuuk nga proseso pagakuhaon.
#[allow(dead_code)] // ipadayon ingon ilustrasyon ug alang sa paggamit sa future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Gipulihan niini ang kantidad sa luyo sa `v` nga talagsaon nga reperensya pinaagi sa pagtawag sa may kalabutan nga pagpaandar, ug gibalik ang resulta nga nakuha sa dalan.
///
///
/// Kung ang usa ka panic mahitabo sa pagsira sa `change`, ang tibuuk nga proseso pagakuhaon.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}