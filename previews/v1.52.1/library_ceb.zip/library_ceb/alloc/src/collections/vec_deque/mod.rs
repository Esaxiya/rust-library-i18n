//! Ang usa ka doble nga natapos nga pila nga gipatuman sa usa ka nagtubo nga buffer sa singsing.
//!
//! Ang pila nga kini adunay *O*(1) amortized insert ug pagtangtang gikan sa pareho nga tumoy sa sulud.
//! Adunay usab kini *O*(1) pag-indeks sama sa usa ka vector.
//! Ang sulud nga mga elemento dili kinahanglan nga mahimong makopya, ug ang pila igapadala kung ang sulud nga tipo ipadala.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Labing kadaghan nga posible nga gahum sa duha

/// Ang usa ka doble nga natapos nga pila nga gipatuman sa usa ka nagtubo nga buffer sa singsing.
///
/// Ang "default" nga paggamit sa kini nga tipo ingon usa ka pila mao ang paggamit sa [`push_back`] aron madugang sa pila, ug [`pop_front`] aron makuha gikan sa pila.
///
/// [`extend`] ug [`append`] itulod sa likud sa niining paagiha, ug ang pag-iterate sa `VecDeque` mag-una sa likod.
///
/// Tungod kay ang `VecDeque` usa ka singsing nga buffer, ang mga elemento niini dili kinahanglan magkadugtong sa memorya.
/// Kung gusto nimong ma-access ang mga elemento ingon usa ka hiwa, sama sa episyente nga paghan-ay, mahimo nimo gamiton ang [`make_contiguous`].
/// Gipalibut niini ang `VecDeque` aron ang mga elemento niini dili maputos, ug ibalik ang usa ka mutable slice sa karon-magkadugtong nga han-ay sa elemento.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ang ikog ug ulo mao ang tudlo sa buffer.
    // Kanunay nga gipunting sa tail ang una nga elemento nga mabasa, ang Head kanunay nga nagpunting diin ang data kinahanglan isulat.
    //
    // Kung ikog==ulo ang buffer wala`y sulod.Ang gitas-on sa ringbuffer gihubit ingon ang gilay-on sa taliwala sa duha.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Gipadagan ang destructor alang sa tanan nga mga butang sa hiwa kung kini nahulog (naandan o sa panahon sa pag-aliw).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // gamita ang drop alang sa [T]
            ptr::drop_in_place(front);
        }
        // Gidumala sa RawVec ang translocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Naghimo usa ka walay sulod nga `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally labi ka kombenyente
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally labi ka kombenyente
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Alang sa mga lahi nga wala`y gidak-on sa kadako, kanunay kami naa sa maximum nga kapasidad
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Himua ang ptr sa usa ka hiwa
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Himua ang ptr sa usa ka mut slice
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Nagbalhin usa ka elemento gikan sa buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Nagsulat usa ka elemento sa buffer, gibalhin kini.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Gibalik ang `true` kung ang buffer naa sa bug-os nga kapasidad.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Gibalik ang indeks sa nagpahiping buffer alang sa usa ka gihatag nga lohikal nga indeks sa elemento.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Gibalik ang indeks sa nagpahiping buffer alang sa usa ka gihatag nga lohikal nga elemento index + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Gibalik ang indeks sa nagpahiping buffer alang sa usa ka gihatag nga lohikal nga indeks sa elemento, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Nakopya sa us aka kadugtong nga bloke sa panumduman nga len gikan sa src hangtod sa dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Nakopya sa us aka kadugtong nga bloke sa panumduman nga len gikan sa src hangtod sa dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Nakopya ang usa ka potensyal nga balot sa panumduman nga len dugay gikan sa src hangtod sa dest.
    /// (abs(dst - src) Ang + len) kinahanglan dili labaw sa cap() (Kinahanglan adunay labing usa nga padayon nga nagsapaw-sapaw nga rehiyon taliwala sa src ug dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // Ang src dili ibalot, dili igputos ang dst
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst sa wala pa ang src, ang src dili maputos, giputos
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Ang src sa wala pa dst, ang src dili maputos, giputos
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst sa wala pa ang src, ang src nagputos, ang dst dili maputos
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Ang src sa wala pa ang dst, ang src nagputos, ang dst dili maputos
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst sa wala pa ang src, ang src nagputos, giputos ang dst
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Ang src sa wala pa dst, src nagputos, giputos sa dst
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Nag-frobs sa mga seksyon sa ulo ug ikog sa palibot aron mahuptan ang katinuud nga nag-reallocate ra kami.
    /// Dili luwas tungod kay nagsalig kini sa daan nga_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Igbalhin ang labing mubu nga kadugtong nga seksyon sa ring buffer nga TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo.....
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Usa ka Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Naghimo usa ka walay sulod nga `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Naghimo usa ka walay sulod nga `VecDeque` nga adunay wanang alang sa labing menos nga mga elemento nga `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 tungod kay ang ringbuffer kanunay nga gibiyaan nga wala`y sulod ang usa ka wanang
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Naghatag usa ka pakisayran sa elemento sa gihatag nga indeks.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Naghatag usa ka mabalhin nga pakisayran sa elemento sa gihatag nga indeks.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Nagbalhin sa mga elemento sa mga indeks nga `i` ug `j`.
    ///
    /// `i` ug `j` mahimong managsama.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang bisan kinsa nga indeks wala sa mga utlanan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Gipabalik ang gidaghanon sa mga elemento nga mahimo sa `VecDeque` nga wala magkaput sa pag-usab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Gireserba ang minimum nga kapasidad alang sa ensakto nga `additional` daghang mga elemento nga isal-ot sa gihatag nga `VecDeque`.
    /// Wala`y gihimo kung ang kapasidad igo na.
    ///
    /// Hinumdomi nga ang tagahatag mahimo nga hatagan ang koleksyon labi ka daghang wanang kaysa sa gihangyo niini.
    /// Tungod niana ang kapasidad dili masaligan nga mahimong ensakto nga dyutay.
    /// Gipalabi ang [`reserve`] kung gipaabut ang mga pagsal-ot sa future.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Gireserba ang kapasidad alang sa labing menos nga `additional` daghang mga elemento nga isal-ot sa gihatag nga `VecDeque`.
    /// Ang pagkolekta mahimong magreserba sa daghang wanang aron malikayan ang kanunay nga pag-relocate.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Gipaningkamutan nga makareserba ang minimum nga kapasidad alang sa eksaktong `additional` nga daghang mga elemento nga isal-ot sa gihatag nga `VecDeque<T>`.
    ///
    /// Pagkahuman pagtawag sa `try_reserve_exact`, ang kapasidad mahimong labi ka daghan o katumbas sa `self.len() + additional`.
    /// Wala`y gihimo kung ang kapasidad igo na.
    ///
    /// Hinumdomi nga ang tagahatag mahimo nga hatagan ang koleksyon labi ka daghang wanang kaysa sa gihangyo niini.
    /// Busa, ang kapasidad dili masaligan nga mahimong ensakto nga dyutay.
    /// Gipalabi ang `reserve` kung gipaabut ang mga pagsal-ot sa future.
    ///
    /// # Errors
    ///
    /// Kon ang kapasidad moawas `usize`, o ang allocator report sa usa ka kapakyasan, nan sa usa ka sayop nga mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pag-pre-reserba sa memorya, paggawas kung dili namon mahimo
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Karon nahibal-an namon nga dili kini mahimo nga OOM(Out-Of-Memory) taliwala sa among komplikado nga trabaho
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // komplikado kaayo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Gisulayan ang pagreserba sa kapasidad alang sa labing menos nga `additional` daghang mga elemento nga isal-ot sa gihatag nga `VecDeque<T>`.
    /// Ang pagkolekta mahimong magreserba sa daghang wanang aron malikayan ang kanunay nga pag-relocate.
    /// Pagkahuman pagtawag sa `try_reserve`, ang kapasidad mahimong labi ka daghan o katumbas sa `self.len() + additional`.
    /// Wala`y gihimo kung igo na ang kapasidad.
    ///
    /// # Errors
    ///
    /// Kon ang kapasidad moawas `usize`, o ang allocator report sa usa ka kapakyasan, nan sa usa ka sayop nga mibalik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pag-pre-reserba sa memorya, paggawas kung dili namon mahimo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Karon nahibal-an namon nga dili kini mahimo OOM taliwala sa among komplikado nga trabaho
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // komplikado kaayo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Gipili ang kapasidad sa `VecDeque` kutob sa mahimo.
    ///
    /// Kini mahulog sa labing kaduol kutob sa mahimo sa gitas-on apan mahimo pa ipahibalo sa tagahatag sa `VecDeque` nga adunay luna alang sa pipila pa nga mga elemento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Gipakubus ang kapasidad sa `VecDeque` nga adunay mas ubos nga utlanan.
    ///
    /// Ang kapasidad magpabilin labing menos sama kadako sa pareho sa gitas-on ug sa gitagana nga kantidad.
    ///
    ///
    /// Kung ang karon nga kapasidad mas gamay kaysa sa labing ubos nga utlanan, kini usa ka no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Dili kita kinahanglan mabalaka bahin sa usa ka pag-awas tungod kay ang `self.len()` o `self.capacity()` dili mahimo nga `usize::MAX`.
        // +1 ingon ang ringbuffer kanunay nga gibiyaan nga wala`y sulod ang usa ka wanang.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Adunay tulo nga mga kaso sa interes:
            //   Ang tanan nga mga elemento wala sa gitinguha nga mga utlanan Ang mga elemento magkadugtong, ug ang ulo wala sa gusto nga mga hangganan Ang mga elemento dili sigurado, ug ang ikog wala sa gusto nga mga utlanan
            //
            //
            // Sa tanan nga ubang mga oras, ang mga posisyon sa elemento dili maapektohan.
            //
            // Gipasabut nga ang mga elemento sa ulo kinahanglan ibalhin.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Pagbalhin sa mga elemento gikan sa dili gusto nga mga utlanan (posisyon pagkahuman sa target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Gipamub-an ang `VecDeque`, gipadayon ang una nga mga elemento sa `len` ug gihulog ang nahabilin.
    ///
    ///
    /// Kung ang `len` mas daghan kaysa karon nga gitas-on sa `VecDeque`, wala kini epekto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Gipadagan ang destructor alang sa tanan nga mga butang sa hiwa kung kini nahulog (naandan o sa panahon sa pag-aliw).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Luwas tungod kay:
        //
        // * Ang bisan unsang hiwa nga gipasa sa `drop_in_place` balido;ang ikaduha nga kaso adunay `len <= front.len()` ug ang pagbalik sa `len > self.len()` nagsiguro nga `begin <= back.len()` sa una nga kaso
        //
        // * Ang ulo sa VecDeque gibalhin sa wala pa pagtawag sa `drop_in_place`, busa wala`y gihulog nga kantidad kaduha kung `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Siguruha nga ang ikaduha nga katunga nahulog bisan kung ang usa ka destructor sa una nga panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Gibalik ang usa ka iterator sa atubang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Gibalik ang us aka iterator sa atubang nga nagpabalik sa mga mutable nga pakisayran.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // KALUWASAN: Ang sulud nga kalig-on sa kahilwasan sa `IterMut` natukod tungod kay ang
        // `ring` gihimo namon ang usa ka dili mapugngan nga hiwa sa tibuok kinabuhi '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Gibalik ang usa ka parisan nga hiwa nga adunay sulud, sa han-ay, ang mga sulud sa `VecDeque`.
    ///
    /// Kung ang [`make_contiguous`] kaniadto gitawag, ang tanan nga mga elemento sa `VecDeque` naa sa una nga hiwa ug ang ikaduha nga hiwa mahimong wala`y sulod.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Gibalik ang usa ka parisan nga hiwa nga adunay sulud, sa han-ay, ang mga sulud sa `VecDeque`.
    ///
    /// Kung ang [`make_contiguous`] kaniadto gitawag, ang tanan nga mga elemento sa `VecDeque` naa sa una nga hiwa ug ang ikaduha nga hiwa mahimong wala`y sulod.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Gibalik ang gidaghanon sa mga elemento sa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Gibalik ang `true` kung ang `VecDeque` wala`y sulod.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Naghimo usa ka iterator nga naglangkob sa gitino nga sakup sa `VecDeque`.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang punto sa pagsugod labi ka daghan kaysa sa katapusan nga punto o kung ang katapusan nga punto labi ka daghan kaysa sa gitas-on sa vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ang usa ka tibuuk nga sakup naglangkob sa tanan nga sulud
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ang gipaambit nga pakisayran nga naa kanamo sa &self gipadayon sa '_ sa Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Naghimo usa ka iterator nga naglangkob sa gitino nga mutable range sa `VecDeque`.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang punto sa pagsugod labi ka daghan kaysa sa katapusan nga punto o kung ang katapusan nga punto labi ka daghan kaysa sa gitas-on sa vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ang usa ka tibuuk nga sakup naglangkob sa tanan nga sulud
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // KALUWASAN: Ang sulud nga kalig-on sa kahilwasan sa `IterMut` natukod tungod kay ang
        // `ring` gihimo namon ang usa ka dili mapugngan nga hiwa sa tibuok kinabuhi '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Naghimo usa ka draining iterator nga gitangtang ang gitino nga sakup sa `VecDeque` ug nagahatag sa gikuha nga mga butang.
    ///
    /// Hinumdomi 1: Ang han-ay sa elemento gikuha bisan kung ang iterator wala mahurot hangtod sa katapusan.
    ///
    /// Hinumdomi 2: Dili matino kung pila ka mga elemento ang gikuha gikan sa deque, kung ang kantidad nga `Drain` dili mahulog, apan ang gihulaman nga gihuptan niini matapos na (pananglitan, tungod sa `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang punto sa pagsugod labi ka daghan kaysa sa katapusan nga punto o kung ang katapusan nga punto labi ka daghan kaysa sa gitas-on sa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ang usa ka tibuuk nga han-ay naghawan sa tanan nga sulud
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Kaluwas sa memorya
        //
        // Kung una nga gihimo ang Drain, gipamub-an ang gigikanan nga gigikanan aron maseguro nga wala`y uninitialized o gibalhin gikan sa mga elemento nga ma-access sa tanan kung ang moguba sa Drain dili gyud makadagan.
        //
        //
        // Ang Drain ptr::read nga mogawas sa mga kantidad aron makuha.
        // Sa diha nga nahuman na, ang mga nabilin nga data nga kopyahon balik aron sa pagtabon sa lungag, ug ang mga prinsipyo head/tail ipahiuli husto.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Ang mga elemento sa deque gibahin sa tulo nga mga bahin:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Gitago namon ang drain_tail ingon self.head, ug drain_head ug self.head ingon pagkahuman sa_tail ug pagkahuman sa ulohan sa Drain.
        // Giputol usab niini ang epektibo nga han-ay sa ingon nga kung ang Drain na-leak, nakalimtan namon ang bahin sa mga mahimo`g lihok nga mga kantidad pagkahuman sa pagsugod sa drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" bahin sa mga kantidad pagkahuman sa pagsugod sa drain hangtod matapos ang drain nga nahuman ug gipadagan ang Drain destructor.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Sa hinungdanon, naghimo ra kami nga gipaambit nga mga pakisayran gikan sa `self` dinhi ug mabasa gikan niini.
                // Dili kami mosulat sa `self` o magbasol usab sa usa ka mabalhin nga pakisayran.
                // Tungod niini ang hilaw nga panudlo nga gihimo namon sa taas, alang sa `deque`, nagpabilin nga balido.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Giklaro ang `VecDeque`, gikuha ang tanan nga mga kantidad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Gibalik ang `true` kung ang `VecDeque` adunay sulud nga elemento nga parehas sa gihatag nga kantidad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Naghatag usa ka pakisayran sa panguna nga elemento, o `None` kung ang `VecDeque` wala`y sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Naghatag usa ka mutable nga pakisayran sa panguna nga elemento, o `None` kung ang `VecDeque` wala`y sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Naghatag usa ka pakisayran sa luyo nga elemento, o `None` kung ang `VecDeque` walay sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Naghatag usa ka mabalhin nga pakisayran sa luyo nga elemento, o `None` kung ang `VecDeque` walay sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Gikuha ang una nga elemento ug giuli kini, o `None` kung ang `VecDeque` wala`y sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Gikuha ang katapusang elemento gikan sa `VecDeque` ug gibalik kini, o `None` kung kini wala`y sulod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Nag-andam usa ka elemento sa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Nagdugang usa ka elemento sa likud sa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Gikonsiderar ba namon ang `head == 0` nga gipasabut
        // kanang `self` kadugangan?
        self.tail <= self.head
    }

    /// Gikuha ang usa ka elemento gikan sa bisan diin sa `VecDeque` ug gibalik kini, nga gipulihan kini sa una nga elemento.
    ///
    ///
    /// Dili kini mapreserbar ang pag-order, apan mao ang *O*(1).
    ///
    /// Gibalik ang `None` kung ang `index` wala sa mga utlanan.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Gikuha ang usa ka elemento gikan sa bisan diin sa `VecDeque` ug gibalik kini, nga gipulihan kini sa katapusang elemento.
    ///
    ///
    /// Dili kini mapreserbar ang pag-order, apan mao ang *O*(1).
    ///
    /// Gibalik ang `None` kung ang `index` wala sa mga utlanan.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Gisulud ang usa ka elemento sa `index` sulud sa `VecDeque`, nga gibalhin ang tanan nga mga elemento nga adunay mga indeks nga labi ka daghan o katumbas sa `index` padulong sa likud.
    ///
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `index` mas daghan kaysa sa gitas-on sa 'VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Igbalhin ang labing dyutay nga gidaghanon sa mga elemento sa ring buffer ug ipasok ang gihatag nga butang
        //
        // Labing daghan nga len/2, 1 nga mga elemento ang ibalhin. O(min(n, n-i))
        //
        // Adunay tulo nga punoan nga mga kaso:
        //  Ang mga elemento managsama
        //      - espesyal nga kaso kung ang ikog mao ang 0 Ang mga elemento dili sigurado ug ang pagsulud naa sa bahin sa ikog Ang mga elemento dili sigurado ug ang pagsulud naa sa seksyon sa ulo
        //
        //
        // Alang sa matag usa nga adunay duha pa nga mga kaso:
        //  Ang pagsal-ot mas duol sa ikog Ang isulud mas duul sa ulo
        //
        // Yawi: H, self.head
        //      T, self.tail o, Valid nga elemento I, Pag-insert elemento A, Ang elemento nga kinahanglan pagkahuman sa punto nga pagsal-ot M, Gipasabut ang elemento nga gibalhin
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Usa ka oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // kadungan, isulud nga duul sa ikog:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // kadungan, isuksok nga duul sa ikog ug ikog mao ang 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Gibalhin na ang ikog, busa gikopya ra namon ang mga elemento nga `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // kadungan, isuksok nga duul sa ulo:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // dili sigurado, isuksok nga duul sa ikog, seksyon sa ikog:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // dili sigurado, isuksok nga duul sa ulo, seksyon sa ikog:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopyaha ang mga elemento hangtod sa bag-ong ulo
                    self.copy(1, 0, self.head);

                    // kopyaha ang katapusang elemento sa wala`y sulod nga lugar sa ilawom sa buffer
                    self.copy(0, self.cap() - 1, 1);

                    // ibalhin ang mga elemento gikan sa idx hangtod sa katapusan nga wala`y labot ang ^ elemento
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // dili sigurado, ang pagsulud mas duol sa ikog, seksyon sa ulo, ug naa sa indeks nga zero sa sulud nga buffer:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopyahon ang mga elemento hangtod sa bag-ong ikog
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopyaha ang katapusang elemento sa wala`y sulod nga lugar sa ilawom sa buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // dili sigurado, isuksok nga duul sa ikog, seksyon sa ulo:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopyahon ang mga elemento hangtod sa bag-ong ikog
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopyaha ang katapusang elemento sa wala`y sulod nga lugar sa ilawom sa buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // ibalhin ang mga elemento gikan sa idx-1 hangtod matapos nga wala`y labot ang ^ elemento
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // dili sigurado, isuksok nga duul sa ulo, seksyon sa ulo:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Ang ikog tingali gibag-o busa kinahanglan naton nga makalkulo pag-usab
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Gikuha ug gibalik ang elemento sa `index` gikan sa `VecDeque`.
    /// Bisan asa nga katapusan mao ang mas duol sa pagtangtang punto nga mibalhin sa paghimo sa lawak, ug ang tanan nga mga apektado nga mga elemento nga mibalhin sa bag-ong mga posisyon.
    ///
    /// Gibalik ang `None` kung ang `index` wala sa mga utlanan.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Adunay tulo nga punoan nga mga kaso:
        //  Ang mga elemento dili magkadugtong Ang mga elemento dili sigurado ug ang pagtangtang sa bahin sa ikog Ang mga elemento dili sigurado ug ang pagtangtang naa sa seksyon sa ulo
        //
        //      - espesyal nga kaso kung ang mga elemento magkadugtong sa teknikal, apan self.head =0
        //
        // Alang sa matag usa nga adunay duha pa nga mga kaso:
        //  Ang pagsal-ot mas duol sa ikog Ang isulud mas duul sa ulo
        //
        // Yawi: H, self.head
        //      T, self.tail o, Valid nga elemento x, Elemento nga gimarkahan alang sa pagtangtang sa R, Nagpaila nga elemento nga gikuha M, nagpasabut nga elemento nga gibalhin
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // kadungan, kuhaa nga duul sa ikog:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // kadungan, kuhaa nga duul sa ulo:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // dili sigurado, kuhaa nga duul sa ikog, seksyon sa ikog:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // dili magkaparehas, kuhaa nga duul sa ulo, seksyon sa ulo:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, kuhaa mas duol sa ulo, ikog nga seksyon:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // o quasi-discontiguous, kuhaa sa tupad sa ulo, seksyon sa ikog:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // pagdrawing sa mga elemento sa seksyon sa ikog
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Gipugngan ang pag-agay.
                    if self.head != 0 {
                        // kopyaha ang una nga elemento sa wanang sa lugar
                        self.copy(self.cap() - 1, 0, 1);

                        // ibalhin ang mga elemento sa ulohan nga seksyon sa likod
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // dili matugkad, tangtang nga duul sa ikog, seksyon sa ulo:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // pagdrawing sa mga elemento hangtod sa idx
                    self.copy(1, 0, idx);

                    // kopyaha ang katapusang elemento sa wanang sa lugar
                    self.copy(0, self.cap() - 1, 1);

                    // ibalhin ang mga elemento gikan sa ikog hangtod sa katapusan, wala`y labot ang ulahi
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Gibahin ang `VecDeque` sa duha sa gihatag nga indeks.
    ///
    /// Gibalik ang usa ka bag-ong gigahin nga `VecDeque`.
    /// `self` adunay mga elemento nga `[0, at)`, ug ang giuli nga `VecDeque` adunay mga elemento nga `[at, len)`.
    ///
    /// Hinumdomi nga ang kapasidad sa `self` dili mausab.
    ///
    /// Ang elemento sa index 0 mao ang atubangan sa pila.
    ///
    /// # Panics
    ///
    /// Panics kung `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` naa sa unang katunga.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // kuhaa ra ang tanan sa ikaduha nga tunga.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` naa sa ikaduhang tunga, kinahanglan nga hinungdan sa mga elemento nga gilaktawan namon sa una nga bahin.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Paglimpyo kung diin ang mga katapusan sa buffer
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Gibalhin ang tanan nga mga elemento sa `other` sa `self`, gibiyaan nga wala`y sulod ang `other`.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong ihap sa mga elemento sa kaugalingon nagaawas us aka `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// Gipadayon lamang ang mga elemento nga gitino sa prediksyon.
    ///
    /// Sa laing pagkasulti, tangtanga ang tanan nga mga elemento nga `e` sa ingon nga ang `f(&e)` mobalik nga bakak.
    /// Kini nga pamaagi naglihok sa lugar, pagbisita sa matag elemento nga eksakto kausa sa orihinal nga han-ay, ug gipreserba ang pagkahan-ay sa mga nahabilin nga elemento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ang ensakto nga pagkahan-ay mahimong mapuslanon alang sa pagsubay sa gawas nga estado, sama sa usa ka indeks.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Kini mahimo nga panic o abort
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Doble ang gidak-on sa buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Gibag-o ang `VecDeque` sa lugar aron ang `len()` katumbas sa `new_len`, bisan pinaagi sa pagtangtang sa sobra nga mga elemento gikan sa likud o pinaagi sa pagdugang sa mga elemento nga namugna pinaagi sa pagtawag sa `generator` sa likud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Gihusay usab ang sulud nga pagtipig sa kini nga deque mao nga kini usa ka magkadugtong nga hiwa, nga pagkahuman ibalik.
    ///
    /// Kini nga pamaagi dili paggahin ug dili pagbag-o sa han-ay sa gisal-ot nga mga elemento.Ingon nga kini nagdala sa us aka mutable slice, mahimo kini magamit aron mabag-o ang usa ka deque.
    ///
    /// Sa higayon nga ang internal nga storage mao kasikbit, ang [`as_slices`] ug [`as_mut_slices`] mga pamaagi mobalik sa tibuok sulod sa `VecDeque` sa usa lang ka ad-ad.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Paghan-ay sa sulud sa usa ka deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // paghan-ay sa deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // paghan-ay kini sa balikbalik nga pagkahan-ay
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Pagkuha sa dili mabalhin nga pag-access sa kadugangan nga hiwa.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // makasiguro kita karon nga ang `slice` adunay sulud nga tanan nga mga elemento sa deque, samtang adunay dili mabalhin nga pag-access sa `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // adunay igo nga libre nga wanang aron kopyahon ang ikog sa usa ka higayon, kini gipasabut nga una namon nga gibalhin ang ulo sa likod, ug pagkahuman kopyahon ang ikog sa tama nga posisyon.
            //
            //
            // gikan sa: DEFGH .... ABC
            // sa: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Karon wala namon gikonsiderar .... ABCDEFGH
            // nga mahimong magdugtong tungod kay ang `head` mahimong `0` sa kini nga kaso.
            // Samtang gusto naton nga usbon kini dili kini hinungdan tungod kay pipila ka mga lugar ang nagpaabut sa `is_contiguous` nga gipasabut nga mahimo ra naton hiwaan ang paggamit sa `buf[tail..head]`.
            //
            //

            // adunay igo nga libre nga wanang aron kopyahon ang ulo sa usa ka higayon, kini gipasabut nga una namon nga ibalhin ang ikog sa unahan, ug dayon kopyahon ang ulo sa husto nga posisyon.
            //
            //
            // gikan sa: FGH .... ABCDE
            // sa: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ang libre mas gamay kaysa sa parehas nga ulo ug ikog, kini nagpasabut nga hinayhinay naton nga "swap" ang ikog ug ang ulo.
            //
            //
            // gikan sa: EFGHI ... ABCD o HIJK.ABCDEFG
            // sa: ABCDEFGHI ... o ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Ang kinatibuk-ang problema ingon og kini GHIJKLM ... ABCDEF, sa wala pa ang bisan unsang pagbaylo sa ABCDEFM ... GHIJKL, pagkahuman sa 1 nga pagpasa sa mga swap ABCDEFGHIJM ... KL, ibaylo hangtod nga ang wala nga edge makaabot sa temp store
                //                  - unya pagsugod usab ang algorithm sa usa ka bag-ong tindahan nga (smaller) Usahay maabut ang temp store kung ang tuo nga edge naa sa katapusan sa buffer, kini nagpasabut nga naigo namon ang husto nga han-ay nga adunay labi ka gamay nga mga swap!
                //
                // E.g
                // EF..ABCD ABCDEF .., pagkahuman sa upat ra nga swap nahuman na kami
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Gilibot ang doble nga natapos nga pila nga `mid` nga mga lugar sa wala.
    ///
    /// Equivalently,
    /// - Gilibut ang butang `mid` sa una nga posisyon.
    /// - Ig-una ang una nga mga item nga `mid` ug iduso kini hangtod sa katapusan.
    /// - Gilibut ang mga lugar nga `len() - mid` sa tuo.
    ///
    /// # Panics
    ///
    /// Kung ang `mid` mas daghan kaysa `len()`.
    /// Hinumdomi nga ang `mid == len()` naghimo _not_ panic ug us aka no-op nga pagtuyok.
    ///
    /// # Complexity
    ///
    /// Gikinahanglan ang `*O*(min(mid, len() - mid))` nga oras ug wala'y dugang nga wanang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Gilibut ang doble nga natapos nga pila nga mga lugar nga `k` sa tuo.
    ///
    /// Equivalently,
    /// - Gilibut ang una nga butang sa posisyon nga `k`.
    /// - Itapot ang katapusang mga butang nga `k` ug itulod kini sa atubang.
    /// - Gilibut ang mga lugar nga `len() - k` sa wala.
    ///
    /// # Panics
    ///
    /// Kung ang `k` mas daghan kaysa `len()`.
    /// Hinumdomi nga ang `k == len()` naghimo _not_ panic ug us aka no-op nga pagtuyok.
    ///
    /// # Complexity
    ///
    /// Gikinahanglan ang `*O*(min(k, len() - k))` nga oras ug wala'y dugang nga wanang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // KALUWASAN: ang mosunud nga duha nga pamaagi nagkinahanglan nga ang kantidad sa pagtuyok
    // dili moubus sa katunga sa gitas-on sa deque.
    //
    // `wrap_copy` nagkinahanglan nga `min(x, cap() - x) + copy_len <= cap()`, apan kaysa `min` dili gyud molabaw sa katunga sa kapasidad, dili igsapayan ang x, busa maayo ang pagtawag dinhi tungod kay nagtawag kami nga adunay butang nga mas mubu sa katunga sa gitas-on, nga dili molabaw sa katunga sa kapasidad.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Gipangita sa binary ang kini nga gisunod ang `VecDeque` alang sa usa ka gihatag nga elemento.
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.
    /// Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    ///
    /// # Examples
    ///
    /// Nagpangita usa ka serye sa upat nga mga elemento.
    /// Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Kung gusto nimong isal-ot ang usa ka butang sa usa ka pinagsunod nga `VecDeque`, samtang gipadayon ang pagkahan-ay sa han-ay:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Duha pagpangita niini nga lainlainon `VecDeque` uban sa usa ka comparator function.
    ///
    /// Ang pagpaandar sa kumpare kinahanglan ipatuman ang usa ka han-ay nga uyon sa han-ay nga han-ay sa nagpahiping `VecDeque`, nga ibalik ang usa ka code sa pag-order nga nagpakita kung ang argumento niini `Less`, `Equal` o `Greater` kaysa sa gitinguha nga target.
    ///
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    /// # Examples
    ///
    /// Nagpangita usa ka serye sa upat nga mga elemento.Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Gipangita sa binary ang kini nga pinagsunod nga `VecDeque` nga adunay usa ka hinungdanon nga function sa pagkuha.
    ///
    /// Gihunahuna nga ang `VecDeque` gihan-ay sa yawi, pananglitan sa [`make_contiguous().sort_by_key()`](#method.make_contiguous) nga gigamit ang parehas nga pagpaandar sa yawi.
    ///
    ///
    /// Kung makit-an ang kantidad unya ibalik ang [`Result::Ok`], nga adunay sulud nga indeks sa parehas nga elemento.
    /// Kung adunay daghang mga posporo, nan ang bisan kinsa sa mga posporo mahibalik.
    /// Kung ang bili dili makit-an unya ibalik ang [`Result::Err`], nga adunay sulud nga indeks diin ang usa ka parehas nga elemento mahimong isal-ot samtang nagpadayon sa han-ay nga han-ay.
    ///
    /// # Examples
    ///
    /// Nagtan-aw sa usa ka serye sa upat nga mga elemento sa usa ka hiwa nga mga pares nga gihan-ay sa ilang ikaduha nga mga elemento.
    /// Ang una nakit-an, nga adunay us aka tinuud nga gitino nga posisyon;ang ikaduha ug ang ikatulo dili makit-an;ang ikaupat mahimo`g motugma sa bisan unsang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Gibag-o ang `VecDeque` sa lugar aron ang `len()` parehas sa new_len, bisan pinaagi sa pagtangtang sa sobra nga mga elemento gikan sa likud o pinaagi sa pagdugang mga clone nga `value` sa likud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Gibalik ang indeks sa nagpahiping buffer alang sa usa ka gihatag nga lohikal nga indeks sa elemento.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ang kadak-an kanunay usa ka kusog nga 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Kwentaha ang gidaghanon sa mga elemento nga nahabilin aron mabasa sa buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ang kadak-an kanunay usa ka kusog nga 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Kanunay nga nabahin sa tulo nga mga seksyon, pananglitan: kaugalingon: [a b c|d e f] uban pa: [0 1 2 3|4 5] atubangan=3, tunga=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Dili mahimo nga gamiton ang Hash::hash_slice sa mga hiwa nga gibalik sa pamaagi nga as_slices tungod kay ang ilang gitas-on mahimo nga magkalainlain kung dili managsama nga mga deque.
        //
        //
        // Gagarantiyahan lamang ni Hasher ang katumbas alang sa eksaktong parehas nga hugpong sa mga tawag sa mga pamaagi niini.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Gikonsumo ang `VecDeque` sa usa ka atubang nga iterator nga naghatag mga elemento pinaagi sa kantidad.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Kini nga kalihokan kinahanglan parehas sa moral sa:
        //
        //      alang sa butang sa iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Himua ang [`Vec<T>`] nga usa ka [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Naglikay kini sa pag-relocate kung mahimo, apan ang mga kondisyon alang kana istrikto, ug mahimo`g usbon, ug busa dili kini pagsalig gawas kung ang `Vec<T>` naggikan sa `From<VecDeque<T>>` ug wala maibalhin usab.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Wala'y tinuud nga paggahin alang sa mga ZST nga mabalaka bahin sa kapasidad, apan ang `VecDeque` dili makadumala sama ka taas sa `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Kinahanglan naton nga pagbag-ohon kung ang kapasidad dili gahum sa duha, gamay ra kaayo o wala`y bisan usa ka libre nga wanang.
            // Gihimo namon kini samtang naa pa sa `Vec` busa ang mga butang ihulog sa panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Himua ang [`VecDeque<T>`] nga usa ka [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dili gyud kini kinahanglan nga mogahin usab, apan kinahanglan buhaton ang paglihok sa datos nga *O*(*n*) kung ang sirkular nga buffer dili mahitabo sa pagsugod sa paggahin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Kini usa mao ang *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Kini nagkinahanglan data rearranging.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}