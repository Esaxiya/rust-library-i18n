//! Usa ka prayoridad nga pila nga gipatuman sa usa ka binunok nga binary.
//!
//! Ang pagsal-ot ug pagsulud sa labing kadaghan nga elemento adunay pagkakumplikado sa oras nga *O*(log(*n*)).
//! Ang pagsusi sa labing kadaghan nga elemento mao ang *O*(1).Ang pagbag-o sa usa ka vector sa usa ka binun-og nga binary mahimo`g buhaton sa lugar, ug adunay pagkakumplikado nga *O*(*n*).
//! Ang usa ka binunok nga binary mahimo usab mabag-o sa usa ka gihan-ay nga vector sa lugar, nga gitugotan nga magamit kini alang sa usa ka *O*(*n*\*log(* n*)) in-place heapsort.
//!
//! # Examples
//!
//! Kini usa ka labi ka daghan nga pananglitan nga nagpatuman sa [Dijkstra's algorithm][dijkstra] aron masulbad ang [shortest path problem][sssp] sa usa ka [directed graph][dir_graph].
//!
//! Gipakita niini kung giunsa gamiton ang [`BinaryHeap`] nga adunay mga naandan nga lahi.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Ang priyoridad nga pila depende sa `Ord`.
//! // Tin-aw nga gipatuman ang trait mao nga ang pila naglinya usa ka min-heap imbis nga usa ka max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Timan-i nga gibalhin namon ang pag-order sa mga gasto.
//!         // Sa kaso sa usa ka kurbata gitandi namon ang mga posisyon, kini nga lakang kinahanglan aron mahimo ang pagpatuman sa `PartialEq` ug `Ord` nga parehas.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` kinahanglan ipatuman usab.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ang matag node girepresentar ingon usa ka `usize`, alang sa usa ka labi ka mubo nga pagpatuman.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Ang labing mub-an nga algorithm sa dalan sa Dijkstra.
//!
//! // Pagsugod sa `start` ug gamita ang `dist` aron masubay ang karon labing kadali nga distansya sa matag node.Ang kini nga pagpatuman dili epektibo sa memorya tungod kay mahimo nga ibilin ang mga duplicate node sa pila.
//! //
//! // Gigamit usab niini ang `usize::MAX` ingon usa ka sentinel nga kantidad, alang sa usa ka mas simple nga pagpatuman.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=karon nga labing mubo nga distansya gikan sa `start` hangtod `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Naa kami sa `start`, nga adunay zero nga gasto
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Susihon ang utlanan nga adunay mas ubos nga mga node sa gasto una (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Puli nga makapadayon kami sa pagpangita sa tanan nga labing mub-an nga mga agianan
//!         if position == goal { return Some(cost); }
//!
//!         // Mahinungdanon ingon tingali nakakita kami usa ka labi ka maayo nga paagi
//!         if cost > dist[position] { continue; }
//!
//!         // Alang sa matag node nga maabut naton, tan-awa kung makakaplag kami usa ka paagi nga adunay mas mubu nga gasto nga moagi sa kini nga node
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Kung mao, idugang kini sa utlanan ug pagpadayon
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Pagpahulay, nakakaplag kami karon usa ka labi ka maayo nga paagi
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Dili maabut ang katuyoan
//!     None
//! }
//!
//! fn main() {
//!     // Kini ang gitudlo nga graph nga among gamiton.
//!     // Ang mga numero sa node katugbang sa lainlaing mga estado, ug ang mga gibug-aton sa edge nagsimbolo sa gasto sa pagbalhin gikan sa usa ka node ngadto sa lain.
//!     //
//!     // Hinumdomi nga ang mga sidsid us aka paagi.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Ang grapiko girepresenta ingon usa ka lista sa katugyanan diin ang matag indeks, nga katugbang sa usa ka node nga kantidad, adunay lista sa mga mogawas nga ngilit.
//!     // Gipili alang sa kaepektibo niini.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Usa ka prayoridad nga pila nga gipatuman sa usa ka binunok nga binary.
///
/// Kini mahimo`g usa ka max-heap.
///
/// Kini usa ka sayup sa lohika alang sa usa ka butang nga usbon sa us aka paagi nga ang pag-order sa aytem nga may kalabutan sa bisan unsang uban nga butang, ingon sa gitino sa `Ord` trait, nagbag-o samtang kini naa sa tinapok.
///
/// Kasagaran posible ra kini pinaagi sa `Cell`, `RefCell`, kalibutanon nga estado, I/O, o dili luwas nga code.
/// Ang pamatasan nga sangputanan sa usa ka sayup nga lohika wala matino, apan dili magresulta sa dili matino nga pamatasan.
/// Mahimo`g maupod ang panics, dili husto nga mga sangputanan, pag-abort, pag-agas sa memorya, ug dili pagtapos.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Gitugotan kami nga maglikay sa usa ka tin-aw nga pirma sa tipo (nga mahimong `BinaryHeap<i32>` sa kini nga pananglitan).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Mahimo namon gamiton ang pagsilip aron tan-awon ang sunod nga butang sa tapok.
/// // Sa kini nga kaso, wala pa mga butang didto busa wala kami makuha.
/// assert_eq!(heap.peek(), None);
///
/// // Idugang naton ang pila nga mga iskor ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Karon gipakita sa peek ang labing hinungdanon nga butang sa tambak.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Mahimo naton masusi ang gitas-on sa usa ka tapok.
/// assert_eq!(heap.len(), 3);
///
/// // Mahimo namon nga iterado ang mga butang sa tambak, bisan kung ibalik kini sa usa ka sulud nga pagkasunud.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Kung gipahimutang naton kini nga mga marka, kinahanglan sila mobalik nga han-ay.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Mahimo naton malimpyohan ang tinapok sa bisan unsang nahabilin nga mga butang.
/// heap.clear();
///
/// // Ang tinapok kinahanglan nga karon wala`y sulod.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Ang bisan unsang `std::cmp::Reverse` o usa ka naandan nga pagpatuman `Ord` mahimong magamit aron mahimo ang `BinaryHeap` usa ka min-heap.
/// Kini ang hinungdan nga ibalik sa `heap.pop()` ang labing gamay nga kantidad imbis ang labing dako.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Ibaligya ang mga kantidad sa `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Kung gi-pop namon kini nga mga iskor karon, kinahanglan sila mobalik sa reverse order.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Pagkomplikado sa oras
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Ang kantidad alang sa `push` usa ka gipaabot nga gasto;ang pamaagi sa pagdokumento naghatag usa ka labi ka detalyado nga pagtuki.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Ang istruktura nga pagputos sa usa ka mabalhin nga pakisayran sa labing kadaghan nga butang sa usa ka `BinaryHeap`.
///
///
/// Kini nga `struct` gihimo sa pamaagi nga [`peek_mut`] sa [`BinaryHeap`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // KALUWASAN: Ang PeekMut gisugdan ra alang sa mga wala`y sulod nga mga tinapok.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: Ang PeekMut gisugdan ra alang sa mga wala`y sulod nga mga tinapok
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: Ang PeekMut gisugdan ra alang sa mga wala`y sulod nga mga tinapok
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Gikuha ang gisilip nga kantidad gikan sa tinapok ug giuli kini.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Naghimo usa ka walay sulod nga `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Naghimo usa ka walay sulod nga `BinaryHeap` ingon usa ka max-heap.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Naghimo usa ka walay sulod nga `BinaryHeap` nga adunay usa ka piho nga kapasidad.
    /// Nag-una kini nga igo nga panumduman alang sa mga elemento nga `capacity`, aron ang `BinaryHeap` dili kinahanglan nga i-reallocate hangtod nga adunay sulud nga dili moubus sa daghang mga kantidad.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Mobalik usa ka mabalhin nga pakisayran sa labing kadaghan nga butang sa binuntog nga binary, o `None` kung kini wala`y sulod.
    ///
    /// Note: Kung ang kantidad nga `PeekMut` leak, ang tapok mahimo nga sa usa ka dili pareho nga kahimtang.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Pagkomplikado sa oras
    ///
    /// Kung ang butang giusab unya ang labing daotan nga pagkakumplikado sa oras nga kaso mao ang *O*(log(*n*)), kung dili kini ang *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Gikuha ang labing kadaghan nga butang gikan sa binary heap ug gibalik kini, o `None` kung kini wala`y sulod.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Pagkomplikado sa oras
    ///
    /// Ang labing daotan nga gasto sa kaso nga `pop` sa usa ka tapok nga adunay sangkap nga *n* mao ang *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // KALUWASAN: Ang !self.is_empty() nagpasabot self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Nagduso sa usa ka butang sa binunok nga binary.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Pagkomplikado sa oras
    ///
    /// Ang gipaabot nga kantidad nga `push`, nga nag-average sa matag posible nga paghan-ay sa mga elemento nga giduso, ug sa igo nga gidaghanon sa mga pagduso, mao ang *O*(1).
    ///
    /// Kini ang labing makahuluganon nga sukatan sa gasto kung ang pagduso sa mga elemento nga wala * naa sa bisan unsang gihan-ay nga sundanan.
    ///
    /// Ang pagkakumplikado sa oras modunot kung ang mga elemento giduso sa kadaghanan nga nagasaka nga han-ay.
    /// Sa labing daotan nga kaso, ang mga elemento giduso sa pagsaka sa han-ay nga han-ay ug ang amortisadong gasto matag pagduso mao ang *O*(log(*n*)) batok sa usa ka tapok nga adunay mga sangkap nga *n*.
    ///
    /// Ang labing daotan nga gasto sa kaso sa usa ka *single* nga tawag sa `push` mao ang *O*(*n*).Ang labing daotan nga kaso mahitabo kung ang kapasidad nahurot ug nagkinahanglan usa ka sukod.
    /// Ang gasto sa pag-usab sa gidak-on gihatagan bayad sa miaging mga numero.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // KALUWASAN: Tungod kay giduso namon ang usa ka bag-ong butang gipasabut kini
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Gikonsumo ang `BinaryHeap` ug gibalik ang usa ka vector sa gihan-ay nga (ascending) nga han-ay.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // KALUWASAN: Ang `end` gikan sa `self.len() - 1` hangtod 1 (parehas nga kauban),
            //  busa kini kanunay usa ka balido nga indeks aron ma-access.
            //  Kini luwas nga ma-access ang index 0 (ie `ptr`), tungod kay
            //  1 <=katapusan <self.len(), nga nagpasabut self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // KALUWASAN: Ang `end` gikan sa `self.len() - 1` hangtod sa 1 (parehas nga kauban) busa:
            //  0 <1 <=katapusan <= self.len(), 1 <self.len() Nga nagpasabut nga 0 <katapusan ug katapusan <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Ang mga pagpatuman sa sift_up ug sift_down naggamit dili luwas nga mga bloke aron mabalhin ang usa ka elemento gikan sa vector (gibiyaan ang usa ka lungag), ibalhin ang uban ug ibalhin ang gikuha nga elemento balik sa vector sa katapusan nga lokasyon sa lungag.
    //
    // Gigamit ang tipo nga `Hole` aron irepresentar kini, ug siguruha nga ang lungag napuno sa katapusan sa iyang nasakup, bisan sa panic.
    // Ang paggamit sa usa ka lungag makaminusan ang kanunay nga hinungdan itandi sa paggamit og mga swap, nga adunay duha ka beses nga daghang paglihok.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Kinahanglan nga garantiya sa nanawag nga `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Kuhaa ang kantidad sa `pos` ug paghimo usa ka lungag.
        // KALUWASAN: Gihatag sa garantiya sa nagtawag nga pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // KALUWASAN: hole.pos()> pagsugod>=0, nga nagpasabut nga hole.pos()> 0
            //  ug busa ang hole.pos(), 1 dili mahimo nga mag-underflow.
            //  Gagarantiyahan niini ang ginikanan nga <hole.pos() busa kini usa ka balido nga indeks ug usab!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // KALUWASAN: Parehas sa taas
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Pagkuha usa ka elemento sa `pos` ug ibalhin kini sa tinapok, samtang ang mga anak niini mas daghan.
    ///
    ///
    /// # Safety
    ///
    /// Kinahanglan nga garantiya sa nanawag nga `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // KALUWASAN: Gihatag sa garantiya sa nanawag nga pos <katapusan <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Pag-invariant sa loop: bata==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // itandi sa labi kadaghan sa duha nga bata nga KALIGTASAN: bata <katapusan, 1 <self.len() ug bata + 1 <katapusan <= self.len(), busa sila balido nga mga indeks.
            //
            //  bata==2 *hole.pos() + 1!= hole.pos() ug bata + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 o 2* Ang hole.pos() + 2 mahimong mag-awas kung ang T usa ka ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // kung nakaayos na kita, hunong na.
            // KALuwas-an: ang bata karon bisan ang tigulang nga bata o ang tigulang nga bata + 1
            //  Napamatud-an na namon nga pareho ang <self.len() ug!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // KALUWASAN: parehas sa taas.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // KALuwas-an: &&mubu nga sirkito, nga nagpasabut nga sa
        //  ikaduha nga kondisyon tinuod na kana nga bata==katapusan, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // KALUWASAN: ang bata napamatud-an nga usa ka balido nga indeks ug
            //  bata==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Kinahanglan nga garantiya sa nanawag nga `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // KALUWASAN: ang pos <len gigarantiyahan sa nanawag ug
        //  klaro nga len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Pagkuha usa ka elemento sa `pos` ug ibalhin kini hangtod nga mag-abut ang tapok, ug ayagon kini hangtod sa posisyon niini.
    ///
    ///
    /// Note: Kini mas tulin kung ang elemento nahibal-an nga dako/kinahanglan nga duul sa ilawom.
    ///
    /// # Safety
    ///
    /// Kinahanglan nga garantiya sa nanawag nga `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // KALUWASAN: Gihatag sa garantiya sa nagtawag nga pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Pag-invariant sa loop: bata==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // KALUWASAN: bata <katapusan, 1 <self.len() ug
            //  bata + 1 <katapusan <= self.len(), mao nga adunay sila balido nga mga indeks.
            //  bata==2 *hole.pos() + 1!= hole.pos() ug bata + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 o 2* Ang hole.pos() + 2 mahimong mag-awas kung ang T usa ka ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // KALUWASAN: Parehas sa taas
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // KALUWASAN: bata==katapusan, 1 <self.len(), busa kini usa ka balido nga indeks
            //  ug bata==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // KALUWASAN: pos ang posisyon sa lungag ug napamatud-an na
        //  aron mahimong usa ka balido nga indeks.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // KALUWASAN: n magsugod gikan sa self.len()/2 ug moubus sa 0.
            //  Ang nag-usa ra nga kaso kanus-a! (N <self.len()) kung self.len() ==0, apan kini gisalikway sa kondisyon sa loop.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Gibalhin ang tanan nga mga elemento sa `other` sa `self`, gibiyaan nga wala`y sulod ang `other`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` Gikuha ang mga operasyon sa O(len1 + len2) ug mga 2 *(len1 + len2) nga mga pagtandi sa pinakagrabe nga kaso samtang ang `extend` nagkuha sa mga operasyon sa O(len2* log(len1)) ug mga 1 *len2* log_2(len1) nga mga pagtandi sa pinakagrabe nga kaso, nga giisip nga len1>= len2.
        // Alang sa labi ka daghang mga tinapok, ang punto sa crossover wala na pagsunod sa kini nga pangatarungan ug natino sa empiriko.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Nagbalik usa ka iterator nga nagkuha og mga elemento sa tambok nga pagkahan-ay.
    /// Ang nakuha nga mga elemento gikuha gikan sa orihinal nga tumpok.
    /// Ang nahabilin nga mga elemento kuhaon sa drop sa heap order.
    ///
    /// Note:
    /// * `.drain_sorted()` mao ang *O*(*n*\*log(* n*)); labi ka mahinay kaysa `.drain()`.
    ///   Kinahanglan nimo gamiton ang naulahi alang sa kadaghanan nga mga kaso.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // gitangtang ang tanan nga mga elemento sa han-ay sa mga tinapok
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Gipadayon lamang ang mga elemento nga gitino sa prediksyon.
    ///
    /// Sa laing pagkasulti, tangtanga ang tanan nga mga elemento `e` nga ingon mabalik sa `f(&e)` ang `false`.
    /// Ang mga elemento giduaw sa wala magkasunod (ug dili matino) nga han-ay.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // itago ra ang mga numero
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Mipauli ang usa ka iterator nga nagbisita sa tanan nga mga kantidad sa nagpahiping vector, sa dili makatarunganon nga pagkahan-ay.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ig-print ang 1, 2, 3, 4 sa dili tinuud nga han-ay
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Nagbalik usa ka iterator nga nagkuha og mga elemento sa tambok nga pagkahan-ay.
    /// Ang kini nga pamaagi nag-ut-ot sa orihinal nga tinapok.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Gibalik ang labing kadaghan nga butang sa binary heap, o `None` kung kini wala`y sulod.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Pagkomplikado sa oras
    ///
    /// Ang gasto *O*(1) sa labi ka grabe nga kaso.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Gibalik ang ihap sa mga elemento nga mahimo sa binary heap nga dili mapugngan.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Gireserba ang minimum nga kapasidad alang sa ensakto nga `additional` daghang mga elemento nga isal-ot sa gihatag nga `BinaryHeap`.
    /// Wala`y gihimo kung ang kapasidad igo na.
    ///
    /// Hinumdomi nga ang tagahatag mahimo nga hatagan ang koleksyon labi ka daghang wanang kaysa sa gihangyo niini.
    /// Tungod niana ang kapasidad dili masaligan nga mahimong ensakto nga dyutay.
    /// Gipalabi ang [`reserve`] kung gipaabut ang mga pagsal-ot sa future.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa `usize`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Gireserba ang kapasidad alang sa labing menos nga `additional` daghang mga elemento nga isal-ot sa `BinaryHeap`.
    /// Ang pagkolekta mahimong magreserba sa daghang wanang aron malikayan ang kanunay nga pag-relocate.
    ///
    /// # Panics
    ///
    /// Panics kung ang bag-ong kapasidad moawas sa `usize`.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Gisalikway ang labi ka dugang nga kapasidad kutob sa mahimo.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Gisalibay ang kapasidad nga adunay mas ubos nga gihigot.
    ///
    /// Ang kapasidad magpabilin labing menos sama kadako sa pareho sa gitas-on ug sa gitagana nga kantidad.
    ///
    ///
    /// Kung ang karon nga kapasidad mas gamay kaysa sa labing ubos nga utlanan, kini usa ka no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Gikonsumo ang `BinaryHeap` ug gibalik ang nagpahiping vector sa arbitraryong pagkahan-ay.
    ///
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // I-print sa pila ka han-ay
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Gibalik ang gitas-on sa binary heap.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Gisusi kung ang binary heap wala`y sulod.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Giklaro ang binunok nga binary, nga gibalik ang usa ka iterator sa gikuha nga mga elemento.
    ///
    /// Gikuha ang mga elemento sa arbitraryong han-ay.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Gitulo ang tanan nga mga butang gikan sa binary heap.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Ang lungag nagrepresentar sa usa ka lungag sa usa ka slice ie, usa ka indeks nga wala`y balido nga kantidad (tungod kay gibalhin kini gikan o gidoble).
///
/// Sa drop, ibalik sa `Hole` ang hiwa pinaagi sa pagpuno sa posisyon sa lungag sa kantidad nga orihinal nga gikuha.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Paghimo usa ka bag-ong `Hole` sa index `pos`.
    ///
    /// Dili luwas tungod kay ang pos kinahanglan naa sa sulud sa data slice.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos kinahanglan sa sulud sa hiwa
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Nagbalik usa ka pakisayran sa gikuha nga elemento.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Nagbalik usa ka pakisayran sa elemento sa `index`.
    ///
    /// Dili luwas tungod kay ang indeks kinahanglan naa sa sulud sa data slice ug dili parehas sa pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Pagbalhin sa lungag sa bag-ong lokasyon
    ///
    /// Dili luwas tungod kay ang indeks kinahanglan naa sa sulud sa data slice ug dili parehas sa pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // pun-a usab ang lungag
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Usa ka iterator sa mga elemento sa usa ka `BinaryHeap`.
///
/// Kini nga `struct` gimugna sa [`BinaryHeap::iter()`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Kuhaa pabor sa `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Usa ka tag-iya nga iterator sa mga elemento sa usa ka `BinaryHeap`.
///
/// Kini nga `struct` gimugna sa [`BinaryHeap::into_iter()`] (gihatag sa `IntoIterator` trait).
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Usa ka draining iterator sa mga elemento sa usa ka `BinaryHeap`.
///
/// Kini nga `struct` gimugna sa [`BinaryHeap::drain()`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Usa ka draining iterator sa mga elemento sa usa ka `BinaryHeap`.
///
/// Kini nga `struct` gimugna sa [`BinaryHeap::drain_sorted()`].
/// Tan-awa ang dokumentasyon niini alang sa daghan pa.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Gikuha ang mga elemento sa tapok sa han-ay sa mga tinapok.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Gikabig ang usa ka `Vec<T>` ngadto sa usa ka `BinaryHeap<T>`.
    ///
    /// Nahimo kini nga pagkabig sa lugar, ug adunay pagkakumplikado sa oras nga *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Gikabig ang usa ka `BinaryHeap<T>` ngadto sa usa ka `Vec<T>`.
    ///
    /// Kini nga pagkakabig wala nanginahanglan paglihok sa data o paggahin, ug adunay kanunay nga pagkakumplikado sa oras.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Naghimo us aka us aka iterator, kana mao, usa nga nagpalihok sa matag kantidad gikan sa binuntog nga binary sa dili tinuud nga pagkahan-ay.
    /// Ang binary heap dili magamit pagkahuman sa pagtawag niini.
    ///
    /// # Examples
    ///
    /// Panguna nga gamit:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ig-print ang 1, 2, 3, 4 sa dili tinuud nga han-ay
    /// for x in heap.into_iter() {
    ///     // x adunay type i32, dili &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}