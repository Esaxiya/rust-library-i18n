//! Ang paggahin Prelude
//!
//! Ang katuyoan sa kini nga modyul aron maibanan ang mga pag-import sa sagad nga gigamit nga mga butang sa `alloc` crate pinaagi sa pagdugang usa ka pag-import sa glob sa tumoy sa mga modyul.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;