//! Undang panics alang sa Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ang matang sa mga payload nga ang Miri engine propagates pinaagi sa pagbadbad sa lanot nga alang kanato.
// Kinahanglan adunay kadako nga pointer.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Gihatag sa gawas ang gimbuhaton sa gawas aron magsugod sa pag-untay.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ang payload moagi kita sa `miri_start_panic` mahimong gayud sa argumento kita sa `cleanup` sa ubos.
    // Ingon niana giusa ra naton kini nga kahon, aron makakuha usa ka butang nga sama kadako sa pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Sa pagbawi sa nagpahiping `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}