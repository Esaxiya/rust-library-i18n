//! Undang kay emscripten * target.
//!
//! Bisan tuod ang naandan undang ni Rust pagpatuman alang sa Unix platform tawag ngadto sa libunwind Apis direkta, sa Emscripten kita sa baylo pagtawag ngadto sa C++ pagbadbad sa lanot nga Apis.
//! Kini mao ang lang sa usa ka expedience sukad ni Emscripten Runtime kanunay nagpatuman sa mga Apis ug dili pagpatuman libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Kini motakdo sa Layout sa std::type_info sa C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Ang nag-una nga `\x01` byte dinhi sa tinuud usa ka mahiwagang signal sa LLVM aron *dili* mag-apply bisan unsang uban pang mangling sama sa pag-unlapi nga adunay karakter nga `_`.
    //
    //
    // Ang kini nga simbolo mao ang vtable nga gigamit sa C++ `std::type_info`.
    // Ang mga butang sa tipo nga `std::type_info`, mga tipo sa paghulagway, adunay usa ka pointer sa kini nga lamesa.
    // Type descriptors mga pakisayran sa mga istruktura C++ EH gihubit sa ibabaw ug nga kita pagtukod sa ubos.
    //
    // Mubo nga sulat nga ang tinuod nga gidak-on mao ang mas dako pa kay sa 3 usize, apan kita kinahanglan lamang sa atong vtable sa punto ngadto sa ikatulo nga elemento.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info alang sa usa ka rust_panic klase
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Kasagaran gamiton namon ang .as_ptr().add(2) apan dili kini molihok sa us aka konteksto nga konstitusyon.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Tuyo nga wala kini gigamit nga normal nga ngalan nga laraw sa mangling tungod kay dili namon gusto nga ang C++ makahimo makahimo o makadakup sa Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Gikinahanglan kini tungod kay ang C++ code mahimong makuha ang among execption nga adunay std::exception_ptr ug ibalik kini sa daghang mga higayon, posible bisan sa uban pa nga sulud.
    //
    //
    caught: AtomicBool,

    // Kinahanglan kini usa ka Kapilian tungod kay ang kinabuhi sa butang nagsunod sa C++ semantics: kung ang catch_unwind ibalhin ang Box gikan sa eksepsyon kinahanglan pa nga ibilin ang butang nga eksepsyon sa usa ka balido nga estado tungod kay ang destructor niini pagatawgon pa sa __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try sa pagkatinuod naghatag kanato og usa ka pointer sa gambalay niini.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Tungod kay cleanup() dili gitugotan sa panic, kita lang makahunong sa baylo.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}