//! Ang pagpatuman sa panics nga gipaluyohan sa libgcc/libunwind (sa pipila nga porma).
//!
//! Kay background sa gawas handling ug stak pagbadbad sa lanot palihog tan-awa "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ug mga dokumento nalambigit gikan niini.
//! Kini mao usab ang maayo mabasa:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Usa ka mubo nga summary
//!
//! Gawas handling mahitabo sa duha ka hugna: usa ka search nga bahin ug sa usa ka cleanup nga bahin.
//!
//! Sa parehas nga hugna ang paglaktaw naglakaw sa mga frame sa taas gikan sa taas hangtod sa ubos nga gamit ang kasayuran gikan sa stack frame nga pahuwam ang mga seksyon sa mga modyul sa karon nga proseso (ang "module" dinhi nagtumong sa usa ka module sa OS, ie, usa ka mapaandar o usa ka dinamikong librarya)
//!
//!
//! Alang sa matag frame sa stack, gisangpit niini ang nahilambigit nga "personality routine", nga ang address gitipig usab sa seksyon nga pagpahawa sa impormasyon.
//!
//! Sa bahin search, ang trabaho sa usa ka personalidad nga rutina mao ang pagsusi sa gawas butang nga gitambog, ug sa paghukom kon kini kinahanglan nga nadakpan sa nga pundok nga bayanan.Sa higayon nga ang handler bayanan nga giila, pagpanglimpyo nga bahin nagsugod.
//!
//! Sa pagpanglimpyo nga bahin, ang unwinder nagpanalangin sa matag personalidad rutina pag-usab.
//! Kini nga panahon nga kini mohukom nga (kon sa bisan unsa nga) panginahanglan sa pagpanglimpyo code nga modagan alang sa kasamtangan nga pundok frame.Kon mao, ang pagpugong sa ang gibalhin ngadto sa usa ka espesyal nga branch sa function sa lawas, ang "landing pad", nga nagpanalangin destructors, nagahilway sa handumanan, ug uban pa
//! Sa katapusan sa sa landing pad, pagpugong sa ang gibalhin ngadto sa mga unwinder ug pagbadbad sa lanot nga mibalik.
//!
//! Sa higayon nga ang stack wala maablanga hangtod sa lebel sa handler frame, ang paghunong sa paghunong ug ang katapusang naandan nga personalidad nga pagbalhin sa pagpugong sa catch block.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// gawas klase ilhanan ni Rust.
// Kini gigamit sa mga naandan nga buluhaton personalidad sa pagtino kon ang gawas gitambog pinaagi sa ilang kaugalingong Runtime.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // Moz\0 taya-vendor, pinulongan
    0x4d4f5a_00_52555354
}

// Ang mga id sa rehistro gibayaw gikan sa LLVM's TargetLowering::getExceptionPointerRegister() ug TargetLowering::getExceptionSelectorRegister() alang sa matag arkitektura, pagkahuman mapa sa mga numero sa rehistro sa DWARF pinaagi sa mga lamesa sa kahulugan sa rehistro (kasagaran<arch>RegisterInfo.td, pangitaa sa "DwarfRegNum").
//
// Tan-awa usab sa http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Ang mosunod code gibase sa ni GCC C ug P++ personalidad buluhaton.Alang sa pakisayran, tan-awa ang:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rutasan sa EHABI nga personalidad.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS naggamit sa default rutina sa baylo kay kini naggamit SjLj undang.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces sa bukton motawag sa personalidad rutina sa estado==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Sa kana nga mga kaso gusto namon nga ipadayon ang pagpahuwam sa stack, kung dili ang tanan namong mga backtrace matapos sa __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Gihunahuna sa DWARF nga pagpugong nga ang_Unwind_Context naghupot sa mga butang sama sa pagpaandar ug mga panudlo sa LSDA, bisan pa gibutang kini sa ARM EHABI sa butang nga eksepsyon.
            // Aron mapreserba ang mga pirma sa mga gimbuhaton sama sa _Unwind_GetLanguageSpecificData(), nga gikuha ra ang konteksto sa konteksto, ang GCC nga mga naandan nga personalidad nagtago sa usa ka pointer sa exception_object sa konteksto, gamit ang lokasyon nga gitagana alang sa "scratch register" (r12) sa ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Ang mas prinsipyo nga paagi nga sa paghatag sa bug-os nga kahulugan sa bukton_Unwind_Context sa atong libunwind bindings ug pagkuha sa gikinahanglan nga data gikan didto direkta, nakalatas dwarf gimbuhaton pagkaangay.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // Gikinahanglan sa EHABI ang naandan nga personalidad aron ma-update ang kantidad nga SP sa cache nga hadlang sa butang nga eksepsyon.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Sa ARM EHABI ang kalihokan sa personalidad ang responsable sa tinuud nga pag-untay sa usa ka frame nga stack sa wala pa mobalik (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // gihubit sa libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Ang default nga naandan nga personalidad, nga gigamit direkta sa kadaghanan nga mga target ug dili direkta sa Windows x86_64 pinaagi sa SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Sa mga target nga x86_64 MinGW, ang mekanismo sa pag-unwind mao ang SEH bisan pa niana ang data sa pagpahuway sa handler (aka LSDA) naggamit sa pag-encode sa nahiangay nga GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Ang naandan nga kalihokan alang sa kadaghanan sa among mga target.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Ang pagbalik sa address nagpunting sa 1 byte nga nangagi sa panudlo sa tawag, nga mahimo sa sunod nga range sa IP sa lamesa sa sakup nga LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Pagrehistro sa info sa frame
//
// larawan sa matag module ni naglangkob sa usa ka frame makarelaks seksyon info (kasagaran ".eh_frame").Kon ang usa ka module mao loaded/unloaded ngadto sa proseso, ang unwinder kinahanglan gipahibalo bahin sa nahimutangan sa niini nga seksyon sa panumdoman.Ang mga pamaagi sa pagkab-ot nga lainlain sa platform.
// Sa pipila (pananglit, Linux), ang makapugong mahimo makit-an ang mga seksyon sa pagpahuway sa kaugalingon niini (pinaagi sa dinamika nga pag-ihap sa karon nga gikarga nga mga modyul pinaagi sa dl_iterate_phdr() API and finding their ".eh_frame" sections); Ang uban, sama sa Windows, nanginahanglan mga modyul aron aktibo nga marehistro ang ilang mga seksyon sa pagpahawa sa kasayuran pinaagi sa pag-undang sa API.
//
//
// module Kini nga naghubit sa duha ka mga simbolo nga pakisayran ug gitawag gikan sa rsbegin.rs sa pagparehistro sa atong impormasyon sa GCC Runtime.
// Ang pagpatuman sa stack unwinding (sa karon) gipagawas sa libgcc_eh, bisan pa gigamit sa Rust crates ang mga tukma nga Rust nga entry point aron malikayan ang mga potensyal nga panagsangka sa bisan unsang runtime sa GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}