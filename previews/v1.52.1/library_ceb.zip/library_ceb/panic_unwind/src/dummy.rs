//! Ang paghulat alang sa target nga *wasm32*.
//!
//! Karon kita dili pagsuporta niini, mao nga kini mao ang lang stubs.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}