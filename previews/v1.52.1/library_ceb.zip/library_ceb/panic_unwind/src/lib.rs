//! Pagpatuman sa panics pinaagi sa pag-unwind sa stack
//!
//! Kini crate mao ang usa ka pagpatuman sa panics sa Rust paggamit "most native" pundok pagbadbad sa lanot nga mekanismo sa sa plataporma niini nga ang natigum alang sa.
//! Kini hinungdan nga giklasipikar sa tulo nga mga balde nga karon:
//!
//! 1. Ang mga target sa MSVC naggamit SEH sa `seh.rs` file.
//! 2. Emscripten naggamit C++ eksepsiyon sa `emcc.rs` file.
//! 3. Ang tanan nga uban nga mga target sa paggamit libunwind/libgcc sa `gcc.rs` file.
//!
//! Ang daghang mga dokumentasyon bahin sa matag pagpatuman mahimong makit-an sa tagsatagsa nga modyul.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ang wala magamit sa Miri, mao pasidaan kahilom.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // tuboy butang Rust Runtime ni agad sa niini nga mga simbolo, sa ingon sa paghimo kanila sa publiko.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Mga target nga dili pagsuporta sa pagpahulay.
        // - arch=wasm32
        // - os=wala (mga target sa "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gamita ang Miri runtime.
        // Kita sa gihapon kinahanglan nga usab load sa normal nga Runtime sa ibabaw, sama sa rustc naglaum sa pipila ka lang butang gikan didto nga gihubit.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gamita ang tinuod nga Runtime.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler sa libstd nga gitawag sa diha nga ang usa ka panic butang nga nagatulo sa gawas sa `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler sa libstd nga gitawag sa diha nga ang usa ka langyaw nga gawas nga nadakpan.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Entry point alang sa pagpataas sa us aka eksepsyon, mga delegado ra sa pagpatuman nga tukma sa platform.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}