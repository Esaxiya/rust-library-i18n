# Ang `rustc-std-workspace-std` crate

Tan-awa ang dokumento alang sa `rustc-std-workspace-core` crate.