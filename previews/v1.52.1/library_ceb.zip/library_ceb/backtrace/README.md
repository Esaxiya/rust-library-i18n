# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Usa ka librarya alang sa pagkuha mga backtrace sa runtime alang sa Rust.
Kini nga librarya tumong sa pagpalambo sa suporta sa mga sumbanan nga librarya pinaagi sa paghatag sa usa ka programa interface sa buhat uban sa, apan kini usab misuporta lamang dali ra pag-imprinta sa mga kasamtangan nga backtrace sama panics ni libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Sa yano nga pagkuha sa usa ka backtrace ug pagpaundang sa pag-atubang niini hangtod sa ulahi nga panahon, mahimo nimo gamiton ang top-level `Backtrace` nga tipo.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Kung, bisan pa, gusto nimo ang labi ka hilaw nga pag-access sa tinuud nga pag-andar sa pagsubay, mahimo nimong magamit direkta ang mga function nga `trace` ug `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Sulbad kini nga panudlo sa panudlo sa usa ka ngalan nga simbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // padayon sa pag-adto sa sunod nga bayanan
    });
}
```

# License

Ang kini nga proyekto adunay lisensya ilalum sa bisan hain sa

 * Apache Lisensya, Bersyon 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * MIT lisensya ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

sa imong kapilian.

### Contribution

Gawas kung tin-aw nimo nga gipahayag kung dili, ang bisan unsang kontribusyon nga gituyo nga gisumite alang sa paglakip sa backtrace-rs pinaagi kanimo, sama sa gipasabut sa lisensya nga Apache-2.0, kinahanglan adunay duha nga lisensyado sama sa taas, nga wala`y dugang nga mga termino o kondisyon.







