use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Pagsulbad sa usa ka adres sa usa ka simbolo, nga igapasa ang simbolo sa gipiho nga pagsira.
///
/// Pangitaon sa kini nga kalihokan ang gihatag nga adres sa mga lugar sama sa lokal nga lamesa nga simbolo, dinamikong lamesa sa simbolo, o DWARF nga impormasyon sa pag-debug (depende sa gipalihok nga pagpatuman) aron makapangita mga simbolo nga mahimo.
///
///
/// Ang pagtak-op mahimong dili tawagan kung ang resolusyon dili mahimo, ug mahimo usab kini tawgon labi pa sa higayon nga adunay mga gilaraw nga gimbuhaton.
///
/// Simbolo mitugyan nagrepresentar sa pagpatay sa bungat `addr`, pagbalik file/line nagtinagurha alang sa address nga (kon anaa).
///
/// Hinumdomi nga kung adunay ka usa ka `Frame` nan girekomenda nga gamiton ang `resolve_frame` function imbis nga kini.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
/// # Panics
///
/// Ang kini nga pag-andar maningkamot nga dili gyud panic, apan kung ang `cb` naghatag sa panics nan ang pipila nga mga plataporma pugson ang usa ka doble nga panic aron mapapas ang proseso.
/// Ang ubang mga platform paggamit sa usa ka C librarya nga internally naggamit callbacks nga dili mahimo nga unwound, sa pagkaagi nataranta gikan sa `cb` mahimong makamugna og usa ka proseso makahunong.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // tan-awa ra ang sa taas nga bayanan
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Pagsulbad sa usa ka kaniadto nga frame nga nakuha sa usa ka simbolo, nga igapasa ang simbolo sa gipiho nga pagsira.
///
/// Ang funcin nga kini naghimo sa parehas nga pag-andar ingon `resolve` gawas nga nagkinahanglan kini usa ka `Frame` ingon usa ka lantugi imbis nga usa ka adres.
/// Kini makatugot sa pipila plataporma implementar sa backtracing sa paghatag og mas tukma nga impormasyon simbolo o impormasyon mahitungod sa inline bayanan alang sa panig-ingnan.
///
/// Girekomenda nga gamiton kini kung mahimo nimo.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
/// # Panics
///
/// Ang kini nga pag-andar maningkamot nga dili gyud panic, apan kung ang `cb` naghatag sa panics nan ang pipila nga mga plataporma pugson ang usa ka doble nga panic aron mapapas ang proseso.
/// Ang ubang mga platform paggamit sa usa ka C librarya nga internally naggamit callbacks nga dili mahimo nga unwound, sa pagkaagi nataranta gikan sa `cb` mahimong makamugna og usa ka proseso makahunong.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // tan-awa ra ang sa taas nga bayanan
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Ang mga kantidad sa IP gikan sa mga stack frame kasagaran (always?) ang panudlo *pagkahuman* ang tawag nga mao ang tinuud nga pagsubay sa stack.
// Nagsimbolo kini sa mga hinungdan sa filename/line gidaghanon nga mahimong usa sa unahan ug tingali ngadto sa walay kapuslanan kon kini duol sa katapusan sa function.
//
// Kini makita nga sa kanunay kanunay mao ang kaso sa tanan nga mga platform, busa kanunay namon nga gikuha ang usa gikan sa usa ka resolusyon nga ip aron masulbad kini sa naunang panudlo sa tawag imbis nga ang panudlo ibalik ra.
//
//
// Maayo nga dili naton kini buhaton.
// Minithi nga kita nagkinahanglan callers sa `resolve` Apis dinhi sa kamut sa pagbuhat sa -1 ug asoy nga sila gusto nga impormasyon nahimutangan alang sa *miaging* pahamatngon, dili ang kasamtangan.
// Minithi gusto usab kita ibutyag sa `Frame` kon kita gayod ang address sa sunod nga pagtudlo o sa kasamtangan nga.
//
// Sa pagkakaron bisan kung kini usa ka matahum nga kabalaka sa niche mao nga kanunay ra namon gikuhaan ang usa.
// Kinahanglan magpadayon sa pagtrabaho ang mga konsumante ug pagkuha maayo nga mga sangputanan, busa kinahanglan nga igoigo kita.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Parehas sa `resolve`, dili luwas lang tungod kay wala kini naka-synchronize.
///
/// function Kini nga wala dungan guarentees apan anaa sa diha nga ang `std` bahin sa niini nga crate wala tinigum, hinipos sa.
/// Kitaa ang pag-andar sa `resolve` alang sa daghang mga dokumentasyon ug pananglitan.
///
/// # Panics
///
/// Tan-awa ang impormasyon sa `resolve` alang sa caveats sa `cb` nataranta.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Parehas sa `resolve_frame`, dili luwas lang tungod kay wala kini naka-synchronize.
///
/// function Kini nga wala dungan guarentees apan anaa sa diha nga ang `std` bahin sa niini nga crate wala tinigum, hinipos sa.
/// Kitaa ang pag-andar sa `resolve_frame` alang sa daghang mga dokumentasyon ug pananglitan.
///
/// # Panics
///
/// Makita ang kasayuran sa `resolve_frame` alang sa mga pahimangno sa `cb` kalisang.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Usa ka trait nga nagrepresentar sa resolusyon sa usa ka simbolo sa usa ka file.
///
/// Kini nga trait ang mitugyan ingon nga usa ka trait butang ngadto sa pagsira nga gihatag ngadto sa function `backtrace::resolve`, ug kini halos gipadala ingon nga kini ni wala mailhi nga pagpatuman anaa sa luyo niini.
///
///
/// Ang usa ka simbolo makahatag kasayuran sa konteksto bahin sa usa ka kalihokan, sama pananglit sa ngalan, filename, numero sa linya, ensakto nga adres, ug uban pa.
/// Dili tanan nga kasayuran kanunay magamit sa usa ka simbolo, bisan pa, busa ang tanan nga mga pamaagi ibalik ang usa ka `Option`.
///
///
pub struct Symbol {
    // TODO: kini nga bug-os nga kinabuhi kinahanglan magpadayon sa katapusan hangtod sa `Symbol`,
    // apan kana karon usa ka nagbag-o nga pagbag-o.
    // Kay karon kini mao ang luwas tungod kay `Symbol` lamang sa walay katapusan gitunol pinaagi sa paghisgot ug dili mahimong clone.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Gibalik ang ngalan sa kini nga kalihokan.
    ///
    /// Ang mipauli gambalay mahimong gamiton sa pag-pangutana sa nagkalain-laing mga kabtangan mahitungod sa ngalan nga simbolo:
    ///
    ///
    /// * Ang pagpatuman sa `Display` mag-print sa nawala nga simbolo.
    /// * Ang hilaw `str` bili sa simbolo mahimong makuha (kon kini ni balido utf-8).
    /// * Ang hilaw nga bytes alang sa ngalan simbolo mahimong makuha.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Gibalik ang pagsugod nga adres sa kini nga pag-andar.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Gibalik ang hilaw nga filename ingon usa ka slice.
    /// Kini labi nga mapuslanon alang sa mga palibot sa `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Mibalik ang gidaghanon column alang sa diin kini nga simbolo karon pagtuman.
    ///
    /// Lamang gimli karon naghatag og usa ka bili dinhi ug bisan unya kon `filename` mobalik `Some`, ug mao nga kini mao unya ingon subject sa susama nga caveats.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Gibalik ang numero sa linya kung diin kini nga simbolo karon gipatuman.
    ///
    /// Kini nga pagbalik bili mao ang kasagaran `Some` kon `filename` mobalik `Some`, ug mao ang sa ingon hilisgutan sa susama nga caveats.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Gibalik ang ngalan sa file diin gipasabut ang kini nga pag-andar.
    ///
    /// Karon lang kini magamit kung gigamit ang libbacktrace o gimli (pananglitan
    /// unix platform sa ubang mga) ug sa diha nga ang usa ka duha ang gihipos sa debuginfo.
    /// Kon dili sa mga kahimtang nga nahimamat nan kini lagmit mobalik `None`.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Tingali ang usa ka gianalisar C++ simbolo, kon parsing sa mangled simbolo sama sa napakyas Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Siguruha nga ipadayon ang kini nga zero-kadako, aron ang bahin sa `cpp_demangle` wala`y gasto kung dili kini kapusan.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Usa ka wrapper sa palibot sa usa ka ngalan nga simbolo sa paghatag og ergonomic accessors sa demangled ngalan, ang hilaw bytes, ang hilaw nga hilo, ug uban pa
///
// Tugoti ang patay nga code alang kung ang dagway nga `cpp_demangle` dili gipalihok.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Nagmugna sa usa ka bag-o nga ngalan nga simbolo gikan sa hilaw nga nahiilalum bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Gibalik ang hilaw nga ngalan sa simbolo nga (mangled) ingon usa ka `str` kung ang simbolo balido nga utf-8.
    ///
    /// Gamita ang pagpatuman sa `Display` kung gusto nimo ang nadaot nga bersyon.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Gibalik ang hilaw nga ngalan sa simbolo ingon usa ka lista sa mga byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Mahimo kini nga i-print kung ang na-demangled nga simbolo dili tinuod nga balido, busa pagdumala ang sayup dinhi nga maayo pinaagi sa dili pagsabwag niini sa gawas.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Mosulay sa pagbawi nga cached panumdoman gigamit sa symbolicate pakigpulong.
///
/// Kini nga pamaagi mosulay sa pagbuhi sa bisan unsa nga global nga data istruktura nga kon dili na cached sa tibuok kalibutan o sa hilo nga kasagaran nagrepresentar sa gianalisar dwarf nga impormasyon o susama nga mga.
///
///
/// # Caveats
///
/// Samtang kini nga pag-andar kanunay nga magamit dili kini tinuod nga pagbuhat bisan unsa sa kadaghanan nga mga pagpatuman.
/// Ang mga librarya sama sa dbghelp o libbacktrace wala maghatag mga kahimanan aron makigsabot ang estado ug madumala ang gigahin nga panumduman.
/// Kay karon ang `gimli-symbolize` bahin sa niini nga crate mao lamang ang bahin diin kini nga function adunay bisan unsa nga epekto.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}