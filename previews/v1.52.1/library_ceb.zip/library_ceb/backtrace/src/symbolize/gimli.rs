//! Pagsuporta alang sa simbolo nga gigamit ang `gimli` crate sa crates.io
//!
//! Kini ang default nga pagpatuman sa simbolo alang sa Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Ang static nga pagkinabuhi usa ka bakak aron mabungkag ang kakulang sa suporta alang sa mga hinugdan nga alang sa kaugalingon.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Kinabig sa 'nagahunong kinabuhi sukad sa mga simbolo kinahanglan lamang manghulam `map` ug `stash` ug kita pagpanalipod kanila sa ubos.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Alang sa pag-load sa mga lumad nga librarya sa Windows, tan-awa ang pipila nga paghisgot sa rust-lang/rust#71060 alang sa lainlaing mga pamaagi dinhi.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Ang mga librariya nga MinGW karon wala pagsuporta sa ASLR (rust-lang/rust#16514), apan ang mga DLL mahimo gihapon ibalhin sa sulud sa wanang sa address.
            // Mopatim-aw nga ang mga adres sa impormasyon sa pag-debug tanan ingon kung ang librarya niini gikarga sa "image base", nga usa ka uma sa mga header sa COFF file.
            // Tungod kay kini mao ang debuginfo daw sa paglista kita parse ang simbolo lamesa ug tindahan pakigpulong ingon nga kon ang library nga giluwanan sa "image base" ingon man.
            //
            // Ang librarya mahimong dili ma-load sa "image base", bisan pa.
            // (lagmit adunay uban pa nga mahimong ma-load didto?) Dinhi magsugod ang dula nga `bias`, ug kinahanglan naton mahibal-an ang kantidad sa `bias` dinhi.Bisan pa dili kini tin-aw kung giunsa kini makuha gikan sa usa ka gipas-an nga module.
            // Unsay kita adunay, Apan, ang aktwal nga load address (`modBaseAddr`).
            //
            // Ingon usa ka gamay nga pag-cop-out sa karon gisulat namon ang file, gibasa ang kasayuran sa header sa file, pagkahuman ihulog ang mmap.Kini mao ang usik tungod kay kita tingali reopen sa mmap sa ulahi, apan kini kinahanglan nga motrabaho pag-ayo nga igo alang sa karon.
            //
            // Kung adunay na kami `image_base` (gitinguha nga lokasyon sa pag-load) ug ang `base_addr` (tinuud nga lokasyon sa pag-load) mahimo namon punan ang `bias` (kalainan sa taliwala sa tinuud ug gusto) ug unya ang gipahayag nga adres sa matag bahin mao ang `image_base` tungod kay kana ang giingon sa file.
            //
            //
            // Sa pagkakaron nagpakita nga dili lahi sa ELF/MachO mahimo naton nga buhaton sa usa ka bahin matag librarya, gamit ang `modBaseSize` ingon tibuuk nga gidak-on.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS naggamit sa format nga file nga Mach-O ug naggamit mga piho nga DYLD nga API aron makarga ang usa ka lista sa mga lumad nga librarya nga bahin sa aplikasyon.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Dad-a sa ang ngalan sa niini nga librarya nga katumbas sa dalan sa diin sa load niini ingon man.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ig-load ang header sa imahe sa librarya ug idelegar sa `object` aron maparehas ang tanan nga mga mando sa pag-load aron mahibal-an namon ang tanan nga mga bahin nga nahilakip dinhi.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Pagsunud sa mga bahin ug pagrehistro mga naila nga rehiyon alang sa mga bahin nga nakit-an namon.
            // Dugangan nga pagrekord sa mga bahin sa teksto bahin sa kasayuran alang sa pagproseso sa ulahi, tan-awa ang mga komento sa ubus.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Tinoa ang "slide" alang sa librarya nga ninghuman nga bias nga gigamit namon aron mahibal-an kung diin ang mga butang sa memorya gi-load.
            // Kini usa ka gamay nga usa ka katingad-an nga pagkwenta bisan pa ug kini ang sangputanan sa pagsulay sa pipila ka mga butang sa ihalas ug nakita kung unsa ang nagpilit.
            //
            // Ang kinatibuk-ang ideya mao nga ang `bias` plus usa ka bahin ni `stated_virtual_memory_address` mahimong diin sa aktuwal nga luna address sa bahin nagpuyo.
            // Ang uban nga mga butang nga kita mosalig sa bisan mao nga ang usa ka tinuod nga address minus ang `bias` mao ang index sa pagtan-aw sa simbolo lamesa ug debuginfo.
            //
            // Hinuon, nahimo nga alang sa mga librarya nga gikarga sa system kini nga mga kalkulasyon dili husto.Hinuon, alang sa mga napatuman nga lumad, husto kini.
            // Pagtaas sa pipila nga lohika gikan sa gigikanan sa LLDB adunay kini espesyal nga casing alang sa una nga seksyon nga `__TEXT` nga gikarga gikan sa file offset 0 nga adunay gidak-on nga nonzero.
            // Alang sa bisan unsang hinungdan kung kini anaa kini nagpakita nga gipasabut nga ang lamesa nga simbolo adunay kalabutan sa vmaddr slide alang sa librarya.
            // Kung wala kini *wala* unya ang simbolo nga simbolo adunay kalabutan sa slide sa vmaddr plus ang gipahayag nga adres sa segment.
            //
            // Aron mahuptan ang kini nga kahimtang kung dili kami * makakaplag usa ka seksyon sa teksto sa file nga gi-offset og zero, gipataas namon ang bias sa gipahayag nga adres sa una nga mga seksyon sa teksto ug gipaminusan usab ang tanan nga gipahayag nga mga adres sa kantidad nga ingon niana.
            //
            // Nga paagi nga ang simbolo sa lamesa mao ang kanunay makita paryente sa pagpihig nga kantidad sa librarya ni.
            // Kini makita nga adunay husto nga mga sangputanan alang sa pagsimbolo pinaagi sa lamesa nga simbolo.
            //
            // Sa tinuud dili ako hingpit nga sigurado kung kini husto o kung adunay uban pa nga kinahanglan ipakita kung giunsa kini buhaton.
            // Sa pagkakaron bisan kung kini ingon nga molihok nga igo nga (?) ug kinahanglan kanunay namon nga kini masamok sa paglabay sa panahon kung kinahanglan.
            //
            // Alang sa pipila sa dugang impormasyon tan-awa #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Uban pang Unix (pananglitan
        // Linux) plataporma sa paggamit Elf nga ingon sa usa ka format butang file ug kasagaran pagpatuman sa usa ka API nga gitawag `dl_iterate_phdr` sa load lumad nga mga librarya.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` kinahanglan nga usa ka balido nga mga panudlo.
        // `vec` kinahanglan nga usa ka balido nga pointer sa usa ka `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 dili tinuud nga gisuportahan ang impormasyon sa pag-debug, apan ang sistema sa pagtukod magbutang sa impormasyon sa pag-debug sa agianan `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ang tanan nga uban pa kinahanglan nga mogamit ELF, apan dili mahibal-an kung giunsa ang pag-load sa mga lumad nga librarya.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Sa tanan nga nailhan mipakigbahin librarya nga loaded.
    libraries: Vec<Library>,

    /// Ang mga cache sa pagmapa diin gihuptan namon ang na-parse nga kasayuran sa dwarf.
    ///
    /// Kini nga lista nga adunay usa ka malig-on nga kapasidad alang sa iyang bug-os nga liftime nga dili nagdugang.
    /// Ang `usize` nga elemento sa matag pares usa ka indeks sa `libraries` sa taas diin ang `usize::max_value()` nagrepresentar sa karon nga maipatuman.
    ///
    /// Ang `Mapping` ang katugbang nga gianalisar dwarf nga impormasyon.
    ///
    /// Hinumdomi nga kini sa panguna usa ka LRU cache ug magbag-o kami sa mga butang dinhi samtang gisimbolo namon ang mga adres.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Ang mga bahin sa kini nga librarya gikarga sa memorya, ug diin gikarga.
    segments: Vec<LibrarySegment>,
    /// Ang "bias" sa kini nga librarya, kasagaran diin kini gikarga sa memorya.
    /// Kini nga kantidad gidugang sa gipahayag nga adres sa matag segment aron makuha ang tinuud nga virtual nga adres sa memorya nga gikarga ang bahin.
    /// Ingon kadugangan kini nga bias gikuha gikan sa tinuud nga mga adres sa virtual memory aron i-index sa debuginfo ug sa lamesa nga simbolo.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Ang gipahayag nga adres sa kini nga bahin sa object file.
    /// Kini mao ang dili tinuod nga diin ang mga bahin nga loaded, apan hinoon address niini nga plus sa nga naglangkob sa librarya ni `bias` mao ang dapit diin sa pagpangita niini.
    ///
    stated_virtual_memory_address: usize,
    /// Ang gidak-on sa bahin sa panumdoman.
    len: usize,
}

// luwas tungod kay kini mao ang gikinahanglan nga externally dungan
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // luwas tungod kay kini mao ang gikinahanglan nga externally dungan
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Usa ka gamay kaayo, yano ra kaayo nga cache sa LRU alang sa mga mapping nga impormasyon sa pag-debug.
        //
        // Ang hit rate kinahanglan nga hataas kaayo, tungod kay ang kasagaran nga stack dili motabok taliwala sa daghang gipaambit nga mga librarya.
        //
        // Ang `addr2line::Context` istruktura mao ang pretty mahal sa paghimo.
        // Ang gasto gilauman nga ma-amortize sa sunod nga mga pangutana nga `locate`, nga magamit ang mga istruktura nga gitukod sa pagtukod sa `addr2line: : Context`s aron makakuha og nindot nga mga pagpadali.
        //
        // Kon wala kami niini nga cache, nga amortisasyon dili mahitabo, ug symbolicating backtraces nga ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Una, sulayi kung kini nga `lib` adunay bisan unsang segment nga adunay sulud nga `addr` (pagdumala sa relokasyon).Kung kini nga tseke molabay unya makapadayon kami sa ubus ug sa tinuud hubaron ang adres.
                //
                // Mubo nga sulat nga kita sa paggamit sa `wrapping_add` dinhi sa paglikay sa awas tseke.Nakita sa ihalas nga ang pag-ihap sa bias sa SVMA + nag-awas.
                // Kini daw usa ka gamay talagsaon nga mahitabo apan adunay dili usa ka dako nga kantidad nga atong buhaton mahitungod niini sa uban nga labaw pa kay sa tingali lang wala magtagad sa mga bahin tungod kay sila lagmit na nagtudlo sa ngadto sa kawanangan.
                //
                // Kini orihinal nga miabut sa rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Karon nahibal-an naton nga ang `lib` adunay sulud nga `addr`, mahimo naton mapun-an ang bias nga makit-an ang gipahayag nga virutal memory address.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: pagkahuman sa kini nga kondisyon nga nahuman nga wala`y sayo nga pagbalik
        // gikan sa usa ka sayup, ang pagsulud sa cache alang sa kini nga agianan naa sa indeks 0.

        if let Some(idx) = idx {
            // Kung ang pagmapa naa na sa cache, ibalhin kini sa atubangan.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Sa diha nga ang mapping dili sa cache, paghimo sa usa ka bag-o nga mapping, sal-ot kini sa atubangan sa cache, ug wagtangon ang labing karaan nga entry cache kon gikinahanglan.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ayaw tulo sa `'static` tibuok kinabuhi, ang imong sigurado kini scoped sa lang sa atong mga kaugalingon
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Lugwayan ang tibuok kinabuhi nga `sym` hangtod `'static` tungod kay sa kaduha kinahanglanon kita dinhi, apan kini kanunay nga mogawas ingon usa ka pakisayran busa wala`y pakigsulti sa kini ang kinahanglan nga ipadayon bisan pa sa kini nga bayanan.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Sa katapusan, pagkuha sa usa ka cached mapping o paghimo sa usa ka bag-o nga mapping alang sa file niini, ug pagtimbang-timbang sa dwarf info sa pagpangita sa file/line/name alang sa address niini.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Nakit-an namon ang kasayuran sa bayanan alang sa kini nga simbolo, ug ang bayanan sa `addr2line` sa sulud adunay tanan nga mga dili maayo nga detalye.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Wala makapangita kasayuran sa pag-debug, apan nakit-an namon kini sa simbolo nga lamesa sa duwende nga maipatuman.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}