use core::ffi::c_void;
use core::fmt;

/// Gisusi ang karon nga call-stack, gipasa ang tanan nga aktibo nga mga frame sa pagsira nga gihatag aron makalkulo ang usa ka stack trace.
///
/// function Kini mao ang workhorse sa librarya niini sa pagkuwenta sa pundok timailhan alang sa usa ka programa.Ang gihatag nga pagsira `cb` ang mitugyan higayon sa usa ka `Frame` nga nagrepresentar sa impormasyon mahitungod sa nga tawag bayanan sa pundok.
/// Ang pagsira gihatagan mga frame sa usa ka top-down fashion (labing bag-o nga gitawag nga mga pag-andar).
///
/// Ang kantidad sa pagbalik sa pagsira usa ka timailhan kung kinahanglan magpadayon ang backtrace.Ang usa ka pagbalik nga kantidad nga `false` tapuson ang backtrace ug mobalik dayon.
///
/// Sa higayon nga ang usa ka `Frame` ang naangkon mo lagmit gusto sa pagtawag `backtrace::resolve` sa kinabig sa `ip` (pahamatngon pointer) o simbolo address ngadto sa usa ka `Symbol` nga pinaagi niini ang mga ngalan ug/o filename/linya nga gidaghanon mahimong nakat-onan.
///
///
/// Hinumdomi nga kini usa ka medyo ubos nga lebel nga pag-andar ug kung gusto nimo, pananglitan, pagkuha usa ka backtrace aron masusi sa ulahi, nan ang `Backtrace` nga tipo mahimong labi nga angay.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
/// # Panics
///
/// Ang kini nga pag-andar maningkamot nga dili gyud panic, apan kung ang `cb` naghatag sa panics nan ang pipila nga mga plataporma pugson ang usa ka doble nga panic aron mapapas ang proseso.
/// Ang ubang mga platform paggamit sa usa ka C librarya nga internally naggamit callbacks nga dili mahimo nga unwound, sa pagkaagi nataranta gikan sa `cb` mahimong makamugna og usa ka proseso makahunong.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ipadayon ang backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Parehas sa `trace`, dili luwas lang tungod kay wala kini naka-synchronize.
///
/// function Kini nga wala dungan guarentees apan anaa sa diha nga ang `std` bahin sa niini nga crate wala tinigum, hinipos sa.
/// Kitaa ang pag-andar sa `trace` alang sa daghang mga dokumentasyon ug pananglitan.
///
/// # Panics
///
/// Makita ang kasayuran sa `trace` alang sa mga pahimangno sa `cb` kalisang.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Ang usa ka trait nga nagrepresentar sa usa ka bayanan sa usa ka backtrace, nga gihatag sa pagpaandar sa `trace` niining crate.
///
/// Ang pagsira sa function sa pagsubay hatagan mga frame, ug ang frame hapit nga gipadala tungod kay ang nagpahiping pagpatuman dili kanunay nga nahibal-an hangtod sa runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Gibalik ang karon nga panudlo sa panudlo sa kini nga bayanan.
    ///
    /// Kasagaran kini ang sunod nga panudlo nga ipatuman sa frame, apan dili tanan nga pagpatuman gilista kini nga adunay 100% katukma (apan sa kinatibuk-an hapit kini duul).
    ///
    ///
    /// Kini girekomendar sa nahitabo niini nga bili sa `backtrace::resolve` aron sa pagpabalik niini ngadto sa usa ka ngalan nga simbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Gibalik ang karon nga stack pointer sa kini nga frame.
    ///
    /// Sa kaso nga dili makuha sa usa ka backend ang stack pointer alang sa kini nga frame, usa ka null pointer ang ibalik.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Mibalik ang sugod simbolo address sa bayanan sa niini nga function.
    ///
    /// Kini mosulay sa balikon kadto nga mga pahamatngon pointer mibalik sa `ip` sa pagsugod sa function, pagbalik nga bili.
    ///
    /// Sa pipila nga mga kaso, bisan pa, ang mga backends ibalik ra ang `ip` gikan sa kini nga function.
    ///
    /// Ang gibalik nga kantidad usahay magamit kung ang `backtrace::resolve` napakyas sa `ip` nga gihatag sa taas.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Gibalik ang base address sa module nga gisakup-an sa frame.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Kinahanglan kini nga una, aron masiguro nga mas gihatagan prayoridad ni Miri ang host platform
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // gigamit ra sa simbolo nga dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}