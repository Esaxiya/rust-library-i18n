use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Pagrepresentar sa usa ka tag-iya ug naa sa kaugalingon nga backtrace.
///
/// Ang kini nga istraktura mahimong magamit aron makuha ang usa ka backtrace sa lainlaing mga punto sa usa ka programa ug sa ulahi gamiton aron masusi kung unsa ang backtrace niadtong panahona.
///
///
/// `Backtrace` gisuportahan ang maanyag nga pag-print sa mga backtrace pinaagi sa pagpatuman sa `Debug`.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Bayanan dinhi gilista gikan sa taas-sa-ubos sa binugkos
    frames: Vec<BacktraceFrame>,
    // Ang indeks nga among gituohan mao ang tinuud nga pagsugod sa backtrace, nga gitangtang ang mga frame sama sa `Backtrace::new` ug `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Nakuha nga bersyon sa usa ka frame sa usa ka backtrace.
///
/// Ang kini nga lahi gibalik ingon usa ka lista gikan sa `Backtrace::frames` ug nagrepresentar sa usa ka stack frame sa usa ka nakuha nga backtrace.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Nakuha nga bersyon sa usa ka simbolo sa usa ka backtrace.
///
/// matang Kini nga mibalik ingon nga usa ka listahan gikan sa `BacktraceFrame::symbols` ug nagrepresentar sa metadata alang sa usa ka simbolo sa usa ka backtrace.
///
/// # Gikinahanglan nga mga dagway
///
/// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Misuhot sa usa ka backtrace sa callsite sa niini nga function, pagbalik sa usa ka gipanag-iya nga representasyon.
    ///
    /// function Kini mao ang mapuslanon alang sa nagrepresentar sa usa ka backtrace ingon nga usa ka butang sa Rust.Kini mibalik nga bili mahimong gipadala sa tibuok hilo ug imprinta sa laing dapit, ug ang katuyoan sa niini nga bili mao ang bug-os nga kaugalingon nga anaa.
    ///
    /// Hinumdomi nga sa pipila nga mga plataporma nga nakakuha usa ka hingpit nga backtrace ug pagsulbad niini mahimo`g labi ka mahal.
    /// Kung ang gasto sobra ra kaayo alang sa imong aplikasyon girekomenda nga gamiton hinoon ang `Backtrace::new_unresolved()` nga makalikay sa lakang sa paglutas sa simbolo (nga kasagarang labing taas) ug gitugotan ang pagpatangtang niana sa ulahi nga petsa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // gusto sa pagsiguro nga adunay usa ka frame dinhi sa balhina
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Susama sa `new` gawas nga dili niini masulbad ang bisan unsang mga simbolo, nakuha ra niini ang backtrace ingon usa ka lista sa mga adres.
    ///
    /// Sa ulahi nga panahon ang `resolve` function mahimong tawagan aron masulbad ang mga simbolo sa kini nga backtrace ngadto sa mabasa nga mga ngalan.
    /// Ang kini nga paglihok naglungtad tungod kay ang proseso sa pagresolba usahay magkinahanglan us aka hinungdanon nga oras samtang ang bisan usa nga backtrace mahimo ra nga talagsa ra maimprinta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // walay mga ngalan nga simbolo
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // mga ngalan sa simbolo karon
    /// ```
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    ///
    #[inline(never)] // gusto sa pagsiguro nga adunay usa ka frame dinhi sa balhina
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Gibalik ang mga frame gikan kung kanus-a nakuha ang kini nga backtrace.
    ///
    /// Ang una nga pagsulud sa kini nga slice lagmit ang function `Backtrace::new`, ug ang katapusan nga frame lagmit usa ka butang bahin sa kung giunsa nagsugod kini nga sulud o ang panguna nga pagpaandar.
    ///
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Kon kini nga backtrace gimugna gikan sa `new_unresolved` nan kini nga function ang pagsulbad sa tanan nga mga pakigpulong sa backtrace sa ilang simbolikong ngalan.
    ///
    ///
    /// Kung kini nga backtrace kaniadto nga nasulbad o nahimo pinaagi sa `new`, kini nga kalihokan wala`y gihimo.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Parehas sa `Frame::ip`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Parehas sa `Frame::symbol_address`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Parehas sa `Frame::module_base_address`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Gibalik ang lista sa mga simbolo nga kini nga bayanan katumbas.
    ///
    /// Kasagaran adunay ra usa ka simbolo matag bayanan, apan usahay kung ang usa ka gidaghanon sa mga gimbuhaton gilakip sa usa ka bayanan daghang mga simbolo ang ibalik.
    /// Ang unang simbolo gilista ang "innermost function", samtang ang katapusan nga simbolo mao ang tumoy sa (miaging caller).
    ///
    /// Timan-i nga kon kini nga bayanan gikan sa usa ka masulbad backtrace nan kini mobalik sa usa ka walay sulod nga listahan.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Parehas sa `Symbol::name`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Parehas sa `Symbol::addr`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Parehas sa `Symbol::filename`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Parehas sa `Symbol::lineno`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Parehas sa `Symbol::colno`
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Sa diha nga ang pag-imprinta sa mga dalan kita mosulay sa paghukas sa mga cwd kon kini anaa, kon dili kita lang-imprinta sa dalan sama sa-mao.
        // Hinumdomi nga gihimo ra usab namon kini alang sa mubo nga format, tungod kay kung puno kini tingali gusto naton i-print ang tanan.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}