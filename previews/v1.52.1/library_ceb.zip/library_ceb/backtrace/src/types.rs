//! Mga lahi sa pagsalig sa plataporma.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Usa ka plataporma independente nga representasyon sa usa ka hilo.
/// Kung nagtrabaho kauban ang `std` gipaayo girekomenda ang mga pamaagi sa kasayon alang sa paghatag mga pagkakabig sa mga `std` nga lahi.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Usa ka hiwa, kasagaran gihatag sa Unix platform.
    Bytes(&'a [u8]),
    /// Wide kuldas kasagaran gikan sa Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy kinabig ngadto sa usa ka `Cow<str>`, ang mogahin kon `Bytes` dili balido UTF-8 o kon `BytesOrWideString` mao `Wide`.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Naghatag og usa ka `Path` representasyon sa `BytesOrWideString`.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}