use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Ang dl_iterate_phdr nagkinahanglan usa ka callback nga makadawat usa ka dl_phdr_info pointer alang sa matag DSO nga na-link sa proseso.
    // Gisiguro usab sa dl_iterate_phdr nga ang dinamikong linker naka-lock gikan sa pagsugod hangtod pagkahuman sa pag-ulit.
    // Kung ang callback mobalik usa ka dili-zero nga kantidad ang iterasyon sayo nga natapos.
    // 'data' ipasa ingon ang ikatulong argumento sa callback sa matag tawag.
    // 'size' naghatag sa gidak-on sa dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kinahanglan namon nga pag-parse ang build ID ug pipila ka punoan nga datos sa header sa programa nga nagpasabut nga kinahanglan namon ang us aka butang gikan sa spec sa ELF usab.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Karon kita adunay sa pagkopya sa, gamay alang sa gamay, ang istruktura sa dl_phdr_info matang nga gigamit ni fuchsia kasamtangan nga dinamikong linker.
// Chromium usab kini ABI utlanan ingon man sa crashpad.
// Eventully gusto kita gusto sa pagbalhin niini nga mga kaso sa paggamit sa Elf-search apan gusto kita kinahanglan nga mohatag og nga diha sa SDK ug nga wala pa nahimo.
//
// Mao kini ang atong (ug sila) mga giugbok nga may sa paggamit niini nga pamaagi nga makamatay sa usa ka hugot nga tinakdoan sa fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Wala kami paagi aron mahibal-an ang pagsusi kung ang e_phoff ug e_phnum balido.
    // Kinahanglan nga masiguro kini sa libc alang kanamo bisan pa mao nga luwas ka nga maghimo usa ka hiwa dinhi.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr nagrepresentar sa usa ka 64-gamay Elf nga programa header sa endianness sa target arkitektura.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Ang Phdr nagrepresentar sa usa ka balido nga header sa programa nga ELF ug ang mga sulud niini.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Wala kami paagi sa pagsusi kung husto ang p_addr o p_memsz.
    // ni Fuchsia libc parses sa mga mubo nga mga sulat sa unang Apan pinaagi sa hiyas nga dinhi niini nga mga header kinahanglan balido.
    //
    // Ang NoteIter wala magkinahanglan sa sukaranan nga datos nga mahimong balido apan kini kinahanglan nga ang mga utlanan nga mahimong balido.
    // Gisalig namon nga ang libc nagsiguro nga kini ang kaso alang kanamo dinhi.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Ang tipo sa mubo nga sulat alang sa mga build ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr nagrepresentar sa usa ka Elf mubo nga sulat header sa endianness sa target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Ang nota nagrepresentar sa usa ka ELF note (header + sulud).
// Ang ngalan nahibilin sama sa usa ka u8 ad-ad tungod kay kini mao ang dili kanunay bili gi-undang ug rust kini sayon igo sa pagsusi nga ang mga bytes pagpares sa eitherway.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter lets kaninyo nga luwas iterate sa ibabaw sa usa ka mubo nga sulat nga bahin.
// Natapos kini sa higayon nga adunay usa ka sayup nga nahinabo o wala na mga sulat.
// Kung mag-iterate ka sa dili husto nga datos molihok kini nga ingon wala`y nakit-an nga mga nota.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Kini usa ka invariant sa pagpaandar nga gihatag sa panudlo ug gidak-on nga nagtimaan sa usa ka balido nga han-ay sa mga byte nga mabasa tanan.
    // Ang sulod sa niini nga mga bytes mahimong bisan unsa nga butang apan ang laing kinahanglan nga balido alang niini nga luwas.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to mipahigayon ug assessment sa 'x' sa 'to'-Byte paglaray, pagtalay mapahitas 'to' mao ang usa ka gahum sa 2.
// Ningsunud kini sa us aka sumbanan nga sumbanan sa C/C ++ ELF parsing code diin (x + to, 1)&-to gigamit.
// Rust wala himoa nga negate kamo usize sa ingon sa paggamit sa akong
// 2's-komplemento nga pagkakabig aron mahimo kana.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ut-ot gidaghanon bytes gikan sa ad-ad (kon karon) ug dugang nagsiguro nga ang katapusan nga ad-ad mao ang properlly ilaray.
// Kung ang usa ka ihap sa mga gihangyo nga byte sobra ra kaayo o ang tipik dili ma-realign pagkahuman tungod sa dili igo nga nahabilin nga mga byte nga adunay, Wala mauli ug ang hiwa wala mabag-o.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// function Kini nga walay tinuod nga invariants ang caller kinahanglan sakdagon sa ubang mga kay tingali nga 'bytes' kinahanglan nga ilaray alang sa performance (ug sa pipila ka mga architectures husto).
// Ang mga kantidad sa natad sa Elf_Nhdr mahimo nga wala`y pulos apan ang kini nga pag-andar dili masiguro ang bisan unsa nga butang.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Kini luwas kung adunay igo nga wanang ug gikumpirma ra namon nga sa kung pahayag sa taas busa dili kini luwas.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Hinumdomi nga sice_of: :<Elf_Nhdr>() kanunay nga nakahanay sa 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Susihon kung naabut na namon ang katapusan.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Gipadala namon ang us aka nhdr apan gihunahuna namon nga maayo ang sangputanan nga istruktura.
        // Wala kami pagsalig sa namesz o descsz ug wala kami gihimo nga dili luwas nga mga desisyon pinauyon sa lahi.
        //
        // Mao nga bisan kung makagawas kita sa kompleto nga basura kinahanglan gihapon kita nga luwas.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Gipasabut nga ang usa ka bahin mahimo.
const PERM_X: u32 = 0b00000001;
/// Gipasabut nga ang usa ka bahin mahimo`g masulat.
const PERM_W: u32 = 0b00000010;
/// Gipasabut nga mabasa ang usa ka bahin.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Nagrepresentar sa usa ka bahin sa ELF sa oras nga pag-undang.
struct Segment {
    /// Gihatag ang runtime virtual address sa mga sulud niini nga bahin.
    addr: usize,
    /// Naghatag kadako sa memorya sa mga sulud sa kini nga bahin.
    size: usize,
    /// Naghatag ang module virtual address sa niini nga bahin sa Elf file.
    mod_rel_addr: usize,
    /// Naghatag mga permiso nga nakit-an sa ELF file.
    /// Kini nga mga Permissions dili kinahanglan nga ang mga Permissions karon sa Runtime Apan.
    flags: Perm,
}

/// Lets sa usa ka iterate sa ibabaw sa hugna gikan sa usa ka DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Nagrepresenta sa usa ka ELF DSO (Dynamic Shared Object).
/// Kini nga tipo nagpasabut sa datos nga gitipig sa tinuud nga DSO kaysa paghimo sa kaugalingon nga kopya.
struct Dso<'a> {
    /// Ang dinamikong linker kanunay naghatag kanamo usa ka ngalan, bisan kung wala`y ngalan ang ngalan.
    /// Sa kaso sa punoan nga maipatuman kini nga ngalan mahimong walay sulod.
    /// Sa kaso sa usa ka mipakigbahin butang kini nga ang soname (tan-awa sa DT_SONAME).
    name: &'a str,
    /// Sa Fuchsia halos sa tanan nga mga binaries adunay build ID apan kini mao ang dili usa ka higpit nga requierment.
    /// Walay paagi sa pagpares sa DSO impormasyon uban sa usa ka tinuod nga Elf file sa human niini kon walay build_id aron nagkinahanglan kita nga ang matag DSO adunay usa dinhi.
    ///
    /// Ang DSO nga wala`y build_id wala tagda.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Mobalik usa ka iterator sa mga Segment sa kini nga DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ang kini nga mga sayup nag-encode sa mga isyu nga mitungha samtang gipagawas ang kasayuran bahin sa matag DSO.
///
enum Error {
    /// NameError paagi nga nahitabo sa usa ka sayop samtang pagkabig sa usa ka C nga estilo hilo ngadto sa usa ka rust hilo.
    ///
    NameError(core::str::Utf8Error),
    /// Nagpasabut ang BuildIDError nga wala kami nakit-an nga usa ka build ID.
    /// Mahimo kini tungod kay ang DSO wala`y build ID o tungod kay ang bahin nga adunay sulud nga build ID daotan.
    ///
    BuildIDError,
}

/// Nagtawag sa bisan 'dso' o 'error' alang sa matag DSO nga na-link sa proseso pinaagi sa dinamikong linker.
///
///
/// # Arguments
///
/// * `visitor` - Ang usa ka DsoPrinter nga adunay usa sa mga mokaon mga pamaagi nga gitawag foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr Mosiguro nga info.name motudlo sa usa ka balido nga lokasyon.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// function Kini imprenta sa Fuchsia symbolizer markup alang sa tanan nga impormasyon nga anaa sa usa ka DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}