//! Usa ka module aron makatabang sa pagdumala sa dbghelp bindings sa Windows
//!
//! Ang mga backtrace sa Windows (labing menos alang sa MSVC) kadaghanan gipadagan pinaagi sa `dbghelp.dll` ug sa lainlaing mga gimbuhaton nga sulud niini.
//! Ang kini nga mga gimbuhaton sa pagkakaron gikarga *dinamiko* kaysa pag-link sa `dbghelp.dll` nga statically.
//! Kini karon gihimo sa sumbanan nga librarya (ug naa sa teyorya nga gikinahanglan didto), apan kini usa ka paningkamot aron matabangan nga maminusan ang mga pagsalig sa static dll sa usa ka librarya tungod kay ang mga backtrace kasagarang matahum nga kapilian.
//!
//! Nga nga miingon, `dbghelp.dll` hapit sa kanunay malampuson luwan sa Windows.
//!
//! Hinumdomi nga tungod kay gi-load namon ang tanan nga kini nga suporta dili gyud namon magamit ang hilaw nga mga kahulugan sa `winapi`, apan kinahanglan namon ipasabut ang mga tipo sa tudlo sa pagpaandar sa among kaugalingon ug gamiton kana.
//! Kita dili gusto nga sa sa mga bulohaton sa tighulad winapi, mao nga kita adunay usa ka Cargo bahin `verify-winapi` nga nagpahayag nga ang tanan nga bindings pagpares sa mga anaa sa winapi ug niini nga bahin ang nakahimo sa CI.
//!
//! Sa kataposan, inyong timan-i dinhi nga ang dll alang sa `dbghelp.dll` wala gidiskarga, ug nga karon tinuyo.
//! Ang panghunahuna mao nga mahimo naton kini sa tibuuk kalibutan nga pag-cache ug gamiton kini taliwala sa mga pagtawag sa API, paglikay sa mahal nga loads/unloads.
//! Kung kini usa ka problema alang sa mga tigpagawas sa leak o usa ka butang nga ingon niana mahimo kaming makatabok sa taytayan sa among pag-abut didto.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Pagtrabaho sa palibot sa `SymGetOptions` ug `SymSetOptions` nga wala diha winapi mismo.
// Kung dili man kini magamit ra kung kami adunay doble nga pagsusi sa mga lahi kontra winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Wala pa gihubit sa winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Gihubit kini sa winapi, apan kini sayup (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Wala pa gihubit sa winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Gigamit ang kini nga makro aron mahibal-an ang usa ka istraktura nga `Dbghelp` nga sulud sa sulud adunay sulud nga mga point point sa pag-andar nga mahimo namon ma-load
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Ang gikarga nga DLL alang sa `dbghelp.dll`
            dll: HMODULE,

            // Ang matag function pointer alang sa matag pagpaandar nga mahimo namon gamiton
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Sa sinugdan wala kita loaded sa DLL
            dll: 0 as *mut _,
            // Ang pagsugod sa tanan nga mga gimbuhaton gitakda sa zero aron isulti nga kinahanglan nila nga kusog nga makarga.
            //
            $($name: 0,)*
        };

        // Ang typedef sa kahamugaway alang sa matag klase sa pagpaandar.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pagsulay sa pag-abli `dbghelp.dll`.
            /// Mibalik kalampusan kon kini nga mga buhat o sayop kon `LoadLibraryW` mapakyas.
            ///
            /// Ang Panics kung gi-load na ang librarya.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Pag-andar alang sa matag pamaagi nga gusto namon gamiton.
            // Kung gitawag kini basahon man ang caching function pointer o i-load kini ug ibalik ang gikarga nga kantidad.
            // Gipanghimatuud nga molampos ang mga karga.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Convenience proxy sa paggamit sa pagpanglimpyo buhok sa pakisayran dbghelp gimbuhaton.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ig-una ang tanan nga kinahanglanon nga suporta aron ma-access ang mga function sa `dbghelp` API gikan sa crate.
///
///
/// Hinumdomi nga ang kini nga pag-andar **luwas**, sa sulud kini adunay kaugalingon nga paghiusa.
/// Hinumdomi usab nga luwas tawgon kini nga pag-andar sa daghang beses nga recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Unang butang nga atong kinahanglan nga buhaton mao ang sa pagpahiangay sa niini nga function.Matawag kini nga dungan gikan sa ubang mga sulud o recursively sulud sa usa ka sulud.
        // Mubo nga sulat nga kini ni lisud kay sa nga bisan tungod kay ang atong paggamit dinhi, `dbghelp`, * usab nga mga panginahanglan nga synchronized uban sa tanan nga uban nga mga callers sa `dbghelp` sa niini nga proseso.
        //
        // Kasagaran wala gyud daghang mga tawag sa `dbghelp` sulud sa parehas nga proseso ug tingali luwas natong mahunahuna nga kita ra ang nag-access niini.
        // Adunay, bisan pa, usa ka panguna nga uban pa nga taggamit nga kinahanglan namon mabalaka bahin sa kung unsa ang ironically sa among kaugalingon, apan sa standard nga librarya.
        // Ang Rust standard librarya nagdepende sa niini nga crate alang sa backtrace suporta, ug kini crate usab anaa sa crates.io.
        // Kini gipasabut nga kung ang sumbanan nga librarya nagpatik sa usa ka panic backtrace mahimo kini nga lumba sa kini nga crate nga gikan sa crates.io, hinungdan sa mga segfault.
        //
        // Sa tabang pagsulbad niini nga dungan problema paggamit sa atong usa ka Windows-piho nga limbong, tikas dinhi (kini mao ang, human sa tanan, ang usa ka Windows-piho nga restriction bahin sa dungan).
        // Naghimo kami usa ka *session-local* nga ginganlan mutex aron mapanalipdan kini nga tawag.
        // Ang katuyoan dinhi mao nga ang sukaranan nga librarya ug kini nga crate dili kinahanglan nga ipaambit ang mga API nga lebel sa Rust aron ma-synchronize dinhi apan mahimo nga molihok sa likud sa mga talan-awon aron masiguro nga magkahiusa sila.
        //
        // Nga paagi sa diha nga kini nga function gitawag pinaagi sa sumbanan nga mga librarya o pinaagi crates.io mahimo kita nga sa mao usab nga mutex ang naangkon.
        //
        // Busa ang tanang nga mao ang pag-ingon nga ang unang butang nga atong buhaton dinhi mao nga kita atomically paghimo sa usa ka `HANDLE` nga mao ang usa ka ginganlan si mutex sa Windows.
        // Nagdungan kami og dyutay sa uban pang mga sulud nga nagbahinbahin sa kini nga pag-andar nga piho ug gisiguro nga usa ra nga kuptanan ang gihimo matag pananglitan sa kini nga pag-andar.
        // Timan-i nga ang kuptanan wala sirado sa makausa kini gitipigan diha sa global.
        //
        // Pagkahuman nga naadto namon ang kandado yano ra namong nakuha kini, ug ang among `Init` nga pagdumala nga among gihatag mao ang responsable sa paghulog niini sa ulahi.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Karon nga kitang tanan luwas nga nakagsabay, sugdan gyud naton ang pagproseso sa tanan.
        // Una kinahanglan naton nga masiguro nga ang `dbghelp.dll` sa tinuud na-load sa kini nga proseso.
        // Gihimo namon kini nga dinamiko aron malikayan ang usa ka static nga pagsalig.
        // Gibuhat kini sa kasaysayan aron magtrabaho sa palibot ang mga katingad-an nga mga isyu sa pag-link ug gituyo sa paghimo nga mga binary labi ka madaladala tungod kay kini kadaghanan usa ra nga magamit sa pag-debug.
        //
        //
        // Sa higayon nga na giablihan namo `dbghelp.dll` kita kinahanglan nga motawag sa pipila ka gimbuhaton Initialization diha niini, ug nga nadestino nga mas ubos.
        // lamang nato kini sa makausa, bisan, mao nga na kita sa usa ka global nga boolean nga nagpakita kon kita gibuhat pa o dili.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Sa pagsiguro nga ang `SYMOPT_DEFERRED_LOADS` flag mao ang, tungod kay sumala sa kaugalingon nga docs ni MSVC mahitungod niini: "This is the fastest, most efficient way to use the symbol handler.", mao nga ang ni sa pagbuhat niana!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sa tinuud gisugdan ang mga simbolo sa MSVC.Hinumdomi nga kini mahimo`g mapakyas, apan wala naton kini tagda.
        // Adunay dili sa usa ka tonelada sa wala pa arte alang niini kada se, apan LLVM internally daw sa dili sa pagbalik bili dinhi ug usa sa mga librarya sanitizer sa LLVM iimprenta sa usa ka makahahadlok nga pasidaan kon kini mapakyas apan sa panguna manumbaling niini sa kadugayan.
        //
        //
        // Ang usa ka kaso nga kini daghan nga moabut alang sa Rust mao ang sumbanan nga librarya ug kini nga crate sa crates.io pareho nga gusto nga makigkompetensya alang sa `SymInitializeW`.
        // Ang sumbanan nga librarya sa kasaysayan gusto nga initialize unya pagpanglimpyo ang kadaghanan sa mga panahon, apan karon nga kini sa paggamit niini nga crate kini nagpasabot nga ang usa ka tawo og sa Initialization una ug ang usa sa pagkuha sa nga Initialization.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}