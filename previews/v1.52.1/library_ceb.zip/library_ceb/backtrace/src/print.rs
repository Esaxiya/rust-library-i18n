#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Usa ka formatter alang sa mga backtrace.
///
/// Ang kini nga tipo mahimong magamit sa pag-print sa usa ka backtrace dili igsapayan kung diin gikan ang backtrace mismo.
/// Kon ikaw adunay usa ka matang `Backtrace` unya sa iyang `Debug` pagpatuman na naggamit niini nga pag-imprenta format.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Ang mga estilo sa pag-print nga mahimo namon i-print
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Nag-print sa usa ka terser nga backtrace nga sulud nga sulud ra adunay kasayuran nga kasayuran
    Short,
    /// Iimprenta sa usa ka backtrace nga naglakip sa tanan nga posible nga impormasyon
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Create sa usa ka bag-o nga `BacktraceFmt` nga mosulat output sa gihatag `fmt`.
    ///
    /// Ang `format` argumento nga pagkontrolar sa mga estilo diin ang backtrace naimprenta ug ang `print_path` argumento nga gigamit sa pag-imprinta sa mga `BytesOrWideString` higayon sa filenames.
    /// Ang kini nga tipo mismo wala maghimo bisan unsang pag-print sa mga filename, apan kini nga callback gikinahanglan aron mahimo kini.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Nag-print usa ka pasiuna alang sa backtrace nga hapit na maimprinta.
    ///
    /// Kini ang gikinahanglan sa pipila ka platform sa backtraces nga sa bug-os symbolicated sa ulahi, ug kon dili kini kinahanglan lang nga ang unang pamaagi sa pagtawag kanimo human sa paghimo sa usa ka `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Nagdugang usa ka bayanan sa output sa backtrace.
    ///
    /// Gibalik kini sa usa ka pananglitan sa RAII sa usa ka `BacktraceFrameFmt` nga mahimong magamit sa tinuud nga pag-print sa usa ka frame, ug sa pagkaguba motaas niini ang frame counter.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Mokompleto sa backtrace output.
    ///
    /// Karon kini usa ka no-op apan gidugang alang sa future pagkaangay sa mga format sa backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Karon usa ka no-op-- lakip na niini ang hook aron pagtugot alang sa mga pagdugang future.
        Ok(())
    }
}

/// Usa ka formatter alang ra sa usa ka bayanan sa usa ka backtrace.
///
/// Kini nga tipo gihimo pinaagi sa pagpaandar sa `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Nag-print usa ka `BacktraceFrame` uban ang frame formatter.
    ///
    /// Kini nga recursively i-print ang tanan nga mga pananglitan `BacktraceSymbol` sulud sa `BacktraceFrame`.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Nag-print sa usa ka `BacktraceSymbol` sulud sa usa ka `BacktraceFrame`.
    ///
    /// # Gikinahanglan nga mga dagway
    ///
    /// Ang kini nga pag-andar nagkinahanglan sa `std` nga bahin sa `backtrace` crate aron mapagan, ug ang `std` nga dagway gipaandar pinaagi sa default.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: kini dili mao ang daku nga kita dili matapos sa pag-imprinta sa bisan unsa
            // nga adunay mga dili ngalan nga filename.
            // Salamat hapit ang tanang mga butang mao ang utf8 mao nga kini dili kaayo kaayo daotan.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Agi sa usa ka hilaw nga masubay `Frame` ug `Symbol`, kasagaran gikan sa sulod sa hilaw nga callbacks niini nga crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Nagdugang usa ka hilaw nga bayanan sa output sa backtrace.
    ///
    /// Kini nga pamaagi, dili sama sa kaniadto, gikuha ang hilaw nga mga lantugi kung sakaling maggikan sila sa lainlaing mga lokasyon.
    /// Hinumdomi nga kini mahimong tawgon daghang beses alang sa usa ka bayanan.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Nagdugang usa ka hilaw nga bayanan sa output sa backtrace, lakip ang kasayuran sa haligi.
    ///
    /// Kini nga pamaagi, sama sa miaging, nagkinahanglan sa mga hilaw nga mga argumento sa kaso sila nga tinubdan gikan sa lain-laing mga dapit.
    /// Hinumdomi nga kini mahimong tawgon daghang beses alang sa usa ka bayanan.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia dili sa pagsimbolo sa sulod sa usa ka proseso mao nga kini adunay usa ka espesyal nga format nga mahimong gigamit sa pagsimbolo sa ulahi.
        // Isulat nga sa baylo nga sa pag-imprinta adres sa atong kaugalingon nga format dinhi.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Dili kinahanglan i-print ang mga frame nga "null", kini gipasabut lamang nga ang sistema sa backtrace medyo naghinamhinam nga masubli ang layo kaayo.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sa pagpakunhod TCB gidak-on sa Sgx sakop, dili kita gusto sa pagpatuman sa simbolo sa kalihukan resolusyon.
        // Hinuon, mahimo namon maimprinta ang offset sa adres dinhi, nga mahimong mapangita sa ulahi aron matul-id ang pagpaandar.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Ig-print ang indeks sa frame ingon man ang opsyonal nga tudlo nga panudlo sa frame.
        // Kon kita sa unahan sa unang simbolo sa niini nga bayanan bisan kita lang imprinta angay nga whitespace.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Sunod sa isulat sa ngalan simbolo, sa paggamit sa laing formatting alang sa dugang nga impormasyon kon kita sa usa ka bug-os nga backtrace.
        // Dinhi usab kita sa pagdumala sa mga simbolo nga wala sa usa ka ngalan,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ug ang katapusan, i-print ang numero nga filename/line kung magamit kini.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line giimprinta sa mga linya ilalom sa simbolo nga ngalan, busa giimprinta ang pipila nga angay nga kaputi aron maisa ang husto nga paglinya sa among kaugalingon.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Pagtugyan sa among sulud nga callback aron i-print ang filename ug i-print ang numero sa linya.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Pagdugang numero sa kolum, kung adunay.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Kita lamang sa pag-atiman mahitungod sa unang simbolo sa usa ka frame
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}