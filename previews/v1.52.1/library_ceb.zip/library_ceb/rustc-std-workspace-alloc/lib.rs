#![feature(no_core)]
#![no_core]

// Tan-awa ang rustc-std-workspace-core alang sa ngano nga kini crate gikinahanglan.

// Usab sa ngalan sa crate sa paglikay sa nagkasumpakiay sa sa alloc module sa liballoc.
extern crate alloc as foo;

pub use foo::*;