`core::arch` - Основне карактеристике архитектуре основне библиотеке З0Руст0З
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Модул Кс00Кс имплементира карактеристике зависне од архитектуре (нпр. СИМД).

# Usage 

`core::arch` је доступан као део Кс01Кс и поново га извози Кс00Кс.Радије га користите путем Кс02Кс или Кс03Кс него преко овог З0црате0З.
Нестабилне функције су често доступне у ноћном З0Руст0З преко Кс00Кс.

Коришћење Кс00Кс преко овог З0црате0З захтева ноћни З0Руст0З и може се (и може) често кварити.Једини случајеви у којима бисте требали размотрити употребу путем овог З0црате0З су:

* ако требате сами да прекомпајлирате Кс01Кс, нпр. са омогућеним одређеним циљним карактеристикама које нису омогућене за Кс00Кс.
Note: ако требате да га прекомпајлирате за нестандардни циљ, радије користите Кс00Кс и поновно састављање Кс01Кс по потреби, уместо да користите овај З0црате0З.
  
* користећи неке функције које можда неће бити доступне чак и иза нестабилних З0Руст0З карактеристика.Трудимо се да их сведе на минимум.
Ако требате да користите неке од ових функција, отворите издање како бисмо их могли изложити у ноћном З0Руст0З, а ви их можете користити одатле.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` се примарно дистрибуира под условима МИТ лиценце и З0Апацхе0З лиценце (верзија Кс00Кс), са деловима покривеним различитим БСД-сличним лиценцама.

Погледајте ЛИЦЕНСЕ-З0АПАЦХЕ0З и ЛИЦЕНСЕ-МИТ за детаље.

# Contribution

Ако изричито не наведете другачије, било који допринос који сте намерно поднели за уврштавање у Кс00Кс, како је дефинисано у лиценци З0Апацхе0З-2.0, биће двоструко лиценциран као горе, без икаквих додатних услова или услова.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












