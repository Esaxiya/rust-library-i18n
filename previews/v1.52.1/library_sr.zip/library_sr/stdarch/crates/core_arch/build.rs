use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Користи се за напомену нашим Кс00Кс напоменама да су сви интимни елементи симд-а доступни за тестирање њиховог кодегена, јер су неки постављени иза додатног Кс01Кс који тренутно нема никакав еквивалент у Кс02Кс.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}