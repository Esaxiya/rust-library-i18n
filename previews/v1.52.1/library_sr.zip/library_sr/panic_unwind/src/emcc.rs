//! Одмотавање за *емсцриптен* циљ.
//!
//! Док се уобичајена имплементација одмотавања З0Руст0З за платформе Кс00Кс директно позива на либунвинд АПИ-је, на Емсцриптен уместо тога позивамо Ц ++ АПИ-је за одмотавање.
//! Ово је само сврсисходност јер Емсцриптеново време извршавања увек примењује те АПИ-је и не примењује либунвинд.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Ово одговара распореду Кс00Кс у Ц ++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Водећи бајт Кс00Кс овде је заправо магични сигнал ЛЛВМ-у да *не* примени било које друго руковање попут префикса са знаком Кс01Кс.
    //
    //
    // Овај симбол је втабле који користи Ц ++ Кс00Кс.
    // Објекти типа Кс00Кс, дескриптори типа, имају показивач на ову табелу.
    // На дескрипторе типова упућују се горе дефинисаним Ц ++ ЕХ структурама и које ми конструишемо у наставку.
    //
    // Имајте на уму да је стварна величина већа од 3 величине, али нам је потребан само наш втабле да укаже на трећи елемент.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info за час руст_паниц
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Обично бисмо користили Кс00Кс, али ово не функционише у контексту цонст.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Ово намерно не користи уобичајену шему манглинга имена, јер не желимо да Ц ++ може да произведе или ухвати З0Руст0З З0паницс0З.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // То је неопходно јер Ц ++ код може да ухвати нашу изузетак са Кс00Кс и врати га више пута, можда чак и у другу нит.
    //
    //
    caught: AtomicBool,

    // Ово мора бити опција, јер животни век објекта прати семантику Ц ++: када цатцх_унвинд помери оквир из изузетка, и даље мора оставити објекат изузетка у важећем стању, јер ће његов деструктор и даље позивати __цка_енд_цатцх.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try заправо нам даје показивач на ову структуру.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Будући да Кс00Кс није дозвољен за З0паниц0З, ми само прекидамо.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}