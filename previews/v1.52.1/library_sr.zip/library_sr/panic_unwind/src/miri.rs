//! Одмотавање З0паницс0З за Мири.
use alloc::boxed::Box;
use core::any::Any;

// Тип корисног терета који Мири мотор шири одмотавањем за нас.
// Мора бити величине показивача.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Мири-обезбеђена спољна функција за почетак одмотавања.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Корисни терет који преносимо на Кс00Кс биће управо аргумент који добијамо у доњем Кс01Кс.
    // Дакле, само га једном упакујемо, да добијемо нешто величине показивача.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Опоравите основни Кс00Кс.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}