//! Либцоре З0прелуде0З
//!
//! Овај модул је намењен корисницима либцоре-а који се такође не повезују са либстд.
//! Овај модул се подразумевано увози када се Кс00Кс користи на исти начин као и З0прелуде0З стандардне библиотеке.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Верзија језгра З0прелуде0З из 2015. године.
///
/// Погледајте Кс00Кс за више.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Верзија језгра З0прелуде0З из 2018. године.
///
/// Погледајте Кс00Кс за више.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Верзија језгра З0прелуде0З из 2021. године.
///
/// Погледајте Кс00Кс за више.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Додајте још ствари.
}