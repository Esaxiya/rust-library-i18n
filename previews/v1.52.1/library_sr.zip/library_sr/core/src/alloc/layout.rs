use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Иако се ова функција користи на једном месту и њена примена би могла бити подвучена, претходни покушаји да се то учини успорили су З0рустц0З:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Изглед блока меморије.
///
/// Пример Кс00Кс описује одређени распоред меморије.
/// Изградите Кс00Кс као улазни податак који ћете дати алокатору.
///
/// Сви распореди имају придружену величину и поравнање снаге два.
///
/// (Имајте на уму да положаји *не* морају да имају величину која није нула, иако Кс00Кс захтева да сви захтеви за меморијом не буду различити од нуле.
/// Позивалац мора или осигурати да су испуњени овакви услови, користити посебне додељиваче са лабавијим захтевима или користити блажи интерфејс Кс00Кс.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // величина траженог блока меморије, мерено у бајтовима.
    size_: usize,

    // поравнање захтеваног блока меморије, мерено у бајтовима.
    // осигуравамо да је ово увек снага два, јер АПИ-ји попут Кс00Кс то захтевају и разумно је ограничење које се намеће конструкторима Лаиоут-а.
    //
    //
    // (Међутим, ми аналогно не захтевамо `алигн>=Кс00Кс
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Конструише Кс01Кс из задатих Кс02Кс и Кс00Кс или враћа Кс03Кс ако није испуњен било који од следећих услова:
    ///
    /// * `align` не сме бити нула,
    ///
    /// * `align` мора бити степен двоје,
    ///
    /// * `size`, када се заокружи на најближи вишекратник Кс00Кс, не сме се прелити (тј. заокружена вредност мора бити мања или једнака Кс01Кс).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (повер-оф-тво подразумева поравнање!=0.)

        // Заокружена величина је:
        //   сизе_роундед_уп=(величина + поравнање, 1)&! (поравнање, 1);
        //
        // Одозго знамо да се поравна!=0.
        // Ако се додавање (поравнање, 1) не прелије, тада ће заокруживање бити у реду.
        //
        // Супротно томе,&-маскирање са! (Алигн, 1) одузима само битове ниског реда.
        // Према томе, ако дође до преливања са збиром,&-маска не може одузети довољно да поништи тај прелив.
        //
        //
        // Горе наведено подразумева да је провера прекорачења збрајања и неопходна и довољна.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕЗБЕДНОСТ: услови за Кс00Кс су били
        // горе проверено.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Ствара изглед, заобилазећи све провере.
    ///
    /// # Safety
    ///
    /// Ова функција није сигурна јер не проверава предуслове из Кс00Кс.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕЗБЕДНОСТ: позивалац мора осигурати да је Кс00Кс већи од нуле.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Минимална величина у бајтовима за меморијски блок овог распореда.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Минимално поравнање бајтова за меморијски блок овог распореда.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Конструише Кс01Кс погодан за држање вредности типа Кс00Кс.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕЗБЕДНОСТ: поравнање је загарантовано од стране З0Руст0З снаге два и
        // комбинација сизе + алигн гарантовано се уклапа у наш адресни простор.
        // Као резултат, овде користите непроверени конструктор да бисте избегли уметање кода који З0паницс0З ако није довољно добро оптимизован.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Израђује изглед који описује запис који би могао да се користи за додељивање потпорне структуре за Кс00Кс (што може бити З0 Портраит0З или други неодређени тип попут реза).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗБЕДНОСТ: погледајте образложење Кс00Кс зашто ово користи небезбедну варијанту
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Израђује изглед који описује запис који би могао да се користи за додељивање потпорне структуре за Кс00Кс (што може бити З0 Портраит0З или други неодређени тип попут реза).
    ///
    /// # Safety
    ///
    /// Ову функцију је сигурно назвати само ако су испуњени следећи услови:
    ///
    /// - Ако је Кс01Кс Кс00Кс, ову функцију је увек сигурно назвати.
    /// - Ако је неодређени реп Кс00Кс:
    ///     - Кс01Кс, тада дужина реза реза мора бити инцијализовани цели број, а величина *целокупне вредности*(динамичка дужина репа + префикс статичке величине) мора одговарати Кс00Кс.
    ///     - Кс01Кс, тада втабле део показивача мора усмерити на важећи втабле за тип Кс02Кс стечен присилом без величине, а величина *целокупне вредности*(динамичка дужина репа + префикс статичке величине) мора да стане у Кс00Кс.
    ///
    ///     - Кс01Кс Кс00Кс, тада је ову функцију увек сигурно назвати, али може З0паниц0З или на други начин вратити погрешну вредност, јер распоред спољног типа није познат.
    ///     Ово је исто понашање као Кс00Кс у односу на реп спољног типа.
    ///     - у супротном, конзервативно није дозвољено позивање ове функције.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕЗБЕДНОСТ: прослеђујемо предуслове ових функција позиваоцу
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗБЕДНОСТ: погледајте образложење Кс00Кс зашто ово користи небезбедну варијанту
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ствара Кс00Кс који је висећи, али добро поравнат за овај изглед.
    ///
    /// Имајте на уму да вредност показивача може потенцијално представљати важећи показивач, што значи да се не сме користити као вредност контролне вредности Кс00Кс.
    /// Типови који се лено додељују морају да прате иницијализацију на неки други начин.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕЗБЕДНОСТ: гарантовано поравнање није различито од нуле
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Ствара изглед који описује запис који може садржати вредност истог изгледа као Кс00Кс, али који је такође поравнат са поравнањем Кс01Кс (мерено у бајтовима).
    ///
    ///
    /// Ако Кс01Кс већ задовољава прописано поравнање, тада враћа Кс00Кс.
    ///
    /// Имајте на уму да овај метод не додаје никакво попуњавање укупној величини, без обзира на то да ли враћени изглед има другачије поравнање.
    /// Другим речима, ако Кс01Кс има величину 16, Кс00Кс ће *и даље* имати величину 16.
    ///
    /// Приказује грешку ако комбинација Кс01Кс и датог Кс02Кс крши услове наведене у Кс00Кс.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Враћа количину додатака коју морамо уметнути након Кс00Кс да бисмо били сигурни да ће следећа адреса задовољити Кс01Кс (мерено у бајтовима).
    ///
    /// нпр. ако је Кс00Кс 9, тада Кс01Кс враћа 3, јер је то најмањи број бајтова попуњавања потребан за добијање 4-поравнате адресе (под претпоставком да одговарајући меморијски блок почиње на 4-поравнатој адреси).
    ///
    ///
    /// Повратна вредност ове функције нема значење ако Кс00Кс није снага два.
    ///
    /// Имајте на уму да корисност враћене вредности захтева да Кс01Кс буде мањи или једнак поравнању почетне адресе за цео додељени блок меморије.Један од начина да се задовољи ово ограничење је осигурати Кс00Кс.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Заокружена вредност је:
        //   лен_роундед_уп=(лен + поравнање, 1)&! (поравнање, 1);
        // а затим враћамо разлику у попуњавању: `len_rounded_up - len`.
        //
        // Користимо модуларну аритметику кроз:
        //
        // 1. загарантовано је да је алигн> 0, тако да алигн, 1 увек важи.
        //
        // 2.
        // `len + align - 1` може се прелити за највише Кс00Кс, па ће&-маска са Кс02Кс осигурати да у случају преливања Кс01Кс и сам буде 0.
        //
        //    Тако враћено подметање, када се дода у Кс01Кс, даје 0, што тривијално задовољава поравнање Кс00Кс.
        //
        // (Наравно, покушаји да се доделе блокови меморије чија величина и допуна се преливају на горе наведени начин требало би да доведу до тога да додељивач ионако доведе до грешке.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Ствара изглед заокруживањем величине овог распона до вишеструког поравнања распореда.
    ///
    ///
    /// Ово је еквивалентно додавању резултата Кс00Кс тренутној величини изгледа.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ово се не може прелити.Цитирање из инваријанта Лаиоут-а:
        // > `size`, када се заокружи на најближи вишекратник Кс00Кс,
        // > не сме се прелити (тј. заокружена вредност мора бити мања од
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Ствара изглед који описује запис за Кс01Кс инстанце Кс00Кс, са одговарајућом количином облога између сваке како би се осигурало да свака инстанца добије тражену величину и поравнање.
    /// По успеху враћа Кс00Кс где је Кс01Кс распоред низа, а Кс02Кс растојање између почетка сваког елемента низа.
    ///
    /// При аритметичком преливању враћа Кс00Кс.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ово се не може прелити.Цитирање из инваријанта Лаиоут-а:
        // > `size`, када се заокружи на најближи вишекратник Кс00Кс,
        // > не сме се прелити (тј. заокружена вредност мора бити мања од
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕЗБЕДНОСТ: Кс00Кс је већ познато да је ваљан и аллоц_сизе је био
        // подстављен већ.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Ствара изглед који описује запис за Кс01Кс праћен Кс00Кс, укључујући сва неопходна подметача како би се осигурало да ће Кс02Кс бити правилно поравнан, али *без пратећих облога*.
    ///
    /// Да бисте се подударали са распоредом Ц представљања Кс00Кс, требало би да позовете Кс01Кс након проширења изгледа са свим пољима.
    /// (Не постоји начин да се подудара са подразумеваним распоредом приказа З0Руст0З Кс00Кс
    ///
    /// Имајте на уму да ће поравнање резултујућег изгледа бити максимално поравнање Кс01Кс и Кс00Кс, како би се осигурало поравнање оба дела.
    ///
    /// Приказује Кс00Кс, где је Кс01Кс изглед уједињеног записа, а Кс02Кс је релативно место, у бајтовима, почетка Кс03Кс уграђеног у спојени запис (под претпоставком да сам запис започиње са одмаком 0).
    ///
    ///
    /// При аритметичком преливању враћа Кс00Кс.
    ///
    /// # Examples
    ///
    /// Да бисте израчунали изглед Кс00Кс структуре и помаке поља из распореда њених поља:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не заборавите да завршите са Кс00Кс!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // тестирајте да ли ради
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Ствара распоред који описује запис за Кс01Кс инстанце Кс00Кс, без уметања између сваке инстанце.
    ///
    /// Имајте на уму да, за разлику од Кс00Кс, Кс01Кс не гарантује да ће поновљене инстанце Кс02Кс бити правилно поравнате, чак и ако је дата инстанца Кс03Кс правилно поравнана.
    /// Другим речима, ако се распоред који враћа Кс00Кс користи за додељивање низа, није загарантовано да ће сви елементи у низу бити правилно поравнати.
    ///
    /// При аритметичком преливању враћа Кс00Кс.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Ствара изглед који описује запис за Кс00Кс праћен Кс01Кс без додатних облога између њих.
    /// Будући да није уметнуто никакво попуњавање, поравнање Кс00Кс је ирелевантно и уопште није уграђено * у резултујући распоред.
    ///
    ///
    /// При аритметичком преливању враћа Кс00Кс.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Ствара изглед који описује запис за Кс00Кс.
    ///
    /// При аритметичком преливању враћа Кс00Кс.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметри дати Кс00Кс или неком другом конструктору Кс01Кс не задовољавају његова документована ограничења.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ово нам треба за имплм низ грешака З0 Портраит0З)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}