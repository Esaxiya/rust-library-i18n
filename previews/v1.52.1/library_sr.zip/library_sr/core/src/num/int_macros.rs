macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Најмања вредност коју може представити овај целобројни тип.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Највећа вредност коју може представити овај целобројни тип.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Величина овог целобројног типа у битовима.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Конвертује одрезак низа у датој основи у цео број.
        ///
        /// Очекује се да ће низ бити опционални знак Кс00Кс или Кс01Кс праћен цифрама.
        /// Водећи и пратећи размаци представљају грешку.
        /// Цифре су подскуп ових знакова, у зависности од Кс00Кс:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ова функција З0паницс0З ако Кс00Кс није у опсегу од 2 до 36.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Враћа број јединица у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Даје број нула у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Даје број водећих нула у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Даје број пратећих нула у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Враћа број водећих у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Приказује број пратећих у бинарном представљању Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Помјера битове улијево за одређену количину, Кс00Кс, обавијајући скраћене битове на крај резултирајућег цијелог броја.
        ///
        ///
        /// Имајте на уму да ово није иста операција као Кс00Кс мењач!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Помера битове удесно за одређену количину, Кс00Кс, премотавајући скраћене битове на почетак резултујућег целог броја.
        ///
        ///
        /// Имајте на уму да ово није иста операција као Кс00Кс мењач!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Обрне редослед бајтова целог броја.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека је м=Кс00Кс;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Обрне редослед битова у целом броју.
        /// Најмањи бит постаје најзначајнији бит, други најмање значајан бит постаје други најзначајнији бит итд.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека је м=Кс00Кс;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Претвара цели број из великог ендијана у ендианност циља.
        ///
        /// На великом ендиану ово је не-оп.На малом ендиану бајтови се замењују.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако цфг! (таргет_ендиан=Кс00Кс){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } остало {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Претвара цели број из малог ендијана у ендианност циља.
        ///
        /// На малом ендиану ово је не-оп.На великом ендиану бајтови се замењују.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако цфг! (таргет_ендиан=Кс00Кс){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } остало {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Претвара Кс00Кс у велики ендиан из циљане ендианзије.
        ///
        /// На великом ендиану ово је не-оп.На малом ендиану бајтови се замењују.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако цфг! (таргет_ендиан=Кс00Кс){
        ///     assert_eq!(n.to_be(), n)
        /// } елсе Кс00Кс
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // или не бити?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Претвара Кс00Кс у мали ендиан из циљане ендианзије.
        ///
        /// На малом ендиану ово је не-оп.На великом ендиану бајтови се замењују.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако цфг! (таргет_ендиан=Кс00Кс){
        ///     assert_eq!(n.to_le(), n)
        /// } елсе Кс00Кс
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Означено сабирање целих бројева.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је дошло до преливања.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено сабирање целих бројева.Израчунава Кс00Кс, под претпоставком да не може доћи до преливања.
        /// То резултира недефинисаним понашањем када
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Означено целобројно одузимање.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је дошло до преливања.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Неозначено одузимање целог броја.Израчунава Кс00Кс, под претпоставком да не може доћи до преливања.
        /// То резултира недефинисаним понашањем када
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Означено множење целих бројева.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је дошло до преливања.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено множење целих бројева.Израчунава Кс00Кс, под претпоставком да не може доћи до преливања.
        /// То резултира недефинисаним понашањем када
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Означена целобројна подела.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако Кс02Кс или дељење резултира преливањем.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // БЕЗБЕДНОСТ: див са нулом и ИНТ_МИН су претходно проверени
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Проверена еуклидска подела.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако Кс02Кс или дељење резултира преливањем.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Означени остатак целог броја.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако Кс02Кс или дељење резултира преливањем.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // БЕЗБЕДНОСТ: див са нулом и ИНТ_МИН су претходно проверени
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Проверени Еуклидов остатак.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако Кс02Кс или дељење резултира преливањем.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Проверена негација.
        /// Израчунава Кс01Кс, враћа Кс02Кс ако је Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Означена смена улево.
        /// Израчунава Кс01Кс, враћа Кс02Кс ако је Кс03Кс већи или једнак броју битова у Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Провера смене удесно.
        /// Израчунава Кс01Кс, враћа Кс02Кс ако је Кс03Кс већи или једнак броју битова у Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена апсолутна вредност.
        /// Израчунава Кс01Кс, враћа Кс02Кс ако је Кс00Кс.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Проверена потенцијација.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је дошло до преливања.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // пошто је екп!=0, коначно екп мора бити 1.
            // Одвојено се позабавите завршним битом експонента, јер накнадно квадрирање базе није потребно и може проузроковати непотребно преливање.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Засићено сабирање целобројних.
        /// Израчунава Кс00Кс, засићујући се на нумеричким границама уместо да преплави.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Засићено целобројно одузимање.
        /// Израчунава Кс00Кс, засићујући се на нумеричким границама уместо да преплави.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Засићујућа целобројна негација.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је Кс02Кс уместо преливања.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Засићујућа апсолутна вредност.
        /// Израчунава Кс00Кс, враћа Кс01Кс ако је Кс02Кс уместо да преплави.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Засићено целобројно множење.
        /// Израчунава Кс00Кс, засићујући се на нумеричким границама уместо да преплави.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Засићено целобројно потенцирање.
        /// Израчунава Кс00Кс, засићујући се на нумеричким границама уместо да преплави.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Умотавање Кс00Кс додатка.
        /// Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Умотавање Кс00Кс одузимања.
        /// Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Умотавање Кс00Кс множења.
        /// Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Обмотавање Кс01Кс одељења.Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// Једини случај када се такво премотавање може догодити је када се подели Кс01Кс на потписан тип (где је Кс02Кс негативна минимална вредност за тип);ово је еквивалентно Кс00Кс, позитивној вредности која је превелика за представљање у типу.
        /// У таквом случају, ова функција враћа сам Кс00Кс.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Умотавање евклидске поделе.
        /// Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// До умотавања ће доћи само у Кс00Кс на потписаном типу (где је Кс01Кс негативна минимална вредност за тип).
        /// Ово је еквивалентно Кс00Кс, позитивној вредности која је превелика за представљање у типу.
        /// У овом случају, овај метод враћа сам Кс00Кс.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Обмотавање остатка Кс01Кс.Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// До таквог заокруживања заправо никада не долази математички;Артефакти имплементације чине Кс00Кс неважећим за Кс01Кс на потписаном типу (где је Кс02Кс негативна минимална вредност).
        ///
        /// У таквом случају, ова функција враћа Кс00Кс.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Умотавање еуклидског остатка.Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// До умотавања ће доћи само у Кс00Кс на потписаном типу (где је Кс01Кс негативна минимална вредност за тип).
        /// У овом случају, ова метода враћа 0.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Обмотавање негације Кс01Кс.Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// Једини случај када се такво премотавање може догодити је када се негира Кс00Кс на потписаном типу (где је Кс01Кс негативна минимална вредност за тип);ово је позитивна вредност која је превелика за представљање у типу.
        /// У таквом случају, ова функција враћа сам Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// З0Паниц0З-без битног помака улево;даје Кс00Кс, где Кс01Кс уклања све битове високог реда Кс02Кс због којих би помак премашио битвидтх типа.
        ///
        /// Имајте на уму да ово *није* исто што и ротирање улево;РХС заокретног помака улево је ограничен на опсег типа, уместо да се битови померени из ЛХС враћају на други крај.
        ///
        /// Сви примитивни целобројни типови имплементирају Кс00Кс функцију, која уместо тога може бити оно што желите.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // БЕЗБЕДНОСТ: маскирање бит-величином типа осигурава да се не померамо
            // ван граница
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// З0Паниц0З-без битног помака удесно;даје Кс00Кс, где Кс01Кс уклања све битове високог реда Кс02Кс због којих би помак премашио битвидтх типа.
        ///
        /// Имајте на уму да ово *није* исто што и ротирање удесно;РХС заокретног помака удесно је ограничен на опсег типа, уместо да се битови померени из ЛХС враћају на други крај.
        ///
        /// Сви примитивни целобројни типови имплементирају Кс00Кс функцију, која уместо тога може бити оно што желите.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // БЕЗБЕДНОСТ: маскирање бит-величином типа осигурава да се не померамо
            // ван граница
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Умотавање апсолутне вредности Кс01Кс.Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// Једини случај када се такво умотавање може догодити је када се узме апсолутна вредност негативне минималне вредности за тип;ово је позитивна вредност која је превелика за представљање у типу.
        /// У таквом случају, ова функција враћа сам Кс00Кс.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Израчунава апсолутну вредност Кс00Кс без икаквог умотавања или панике.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Обмотавање потенцијације Кс00Кс.
        /// Израчунава Кс00Кс, обавијајући се на граници типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // пошто је екп!=0, коначно екп мора бити 1.
            // Одвојено се позабавите завршним битом експонента, јер накнадно квадрирање базе није потребно и може проузроковати непотребно преливање.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Израчунава Кс01Кс + Кс00Кс
        ///
        /// Враћа скуп сабирања заједно са логичком логиком која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа умотана вредност.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Израчунава Кс01Кс, Кс00Кс
        ///
        /// Враћа скуп одузимања заједно са логичком логиком која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа умотана вредност.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Израчунава множење Кс01Кс и Кс00Кс.
        ///
        /// Враћа скуп множења заједно са логичком логиком која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа умотана вредност.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, тачно));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Израчунава делилац када је Кс01Кс подељен са Кс00Кс.
        ///
        /// Враћа скуп делиоца заједно са логичком вредности која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, онда се враћа селф.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Израчунава количник еуклидске поделе Кс00Кс.
        ///
        /// Враћа скуп делиоца заједно са логичком вредности која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа Кс00Кс.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Израчунава остатак када се Кс01Кс подели са Кс00Кс.
        ///
        /// Приказује скуп остатака након дељења заједно са логичком логиком која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа 0.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Преливени Еуклидов остатак.Израчунава Кс00Кс.
        ///
        /// Приказује скуп остатака након дељења заједно са логичком логиком која показује да ли ће доћи до аритметичког преливања.
        /// Ако би дошло до преливања, тада се враћа 0.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Негатира селф, преплављен ако је то једнако минималној вредности.
        ///
        /// Враћа скуп негиране верзије селф-а заједно са логичком логиком која показује да ли се догодило преливање.
        /// Ако је Кс01Кс минимална вредност (нпр. Кс00Кс за вредности типа Кс03Кс), тада ће се минимална вредност поново вратити и Кс02Кс ће се вратити у случају преливања.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Пребацује се улево од Кс00Кс битова.
        ///
        /// Враћа кору померене верзије селфа заједно са логичком логиком која показује да ли је вредност померања била већа или једнака броју битова.
        /// Ако је вредност помака превелика, тада је вредност маскирана Кс00Кс где је Н број битова и та вредност се затим користи за извођење смене.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0к10, тачно));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Помера се само удесно за Кс00Кс битове.
        ///
        /// Враћа кору померене верзије селфа заједно са логичком логиком која показује да ли је вредност померања била већа или једнака броју битова.
        /// Ако је вредност помака превелика, тада је вредност маскирана Кс00Кс где је Н број битова и та вредност се затим користи за извођење смене.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0к1, тачно));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Израчунава апсолутну вредност Кс00Кс.
        ///
        /// Враћа скуп апсолутне верзије селфа заједно са логичком логиком која показује да ли се догодило преливање.
        /// Ако је селф минимална вредност
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// тада ће се минимална вредност поново вратити и труе ће се вратити за случај преливања.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Подиже себе до снаге Кс00Кс, користећи потенцирање квадратом.
        ///
        /// Враћа скуп експоненцирања заједно са З0боол0З који указује да ли се догодило преливање.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, тачно));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Огребите простор за чување резултата оверфловинг_мул.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // пошто је екп!=0, коначно екп мора бити 1.
            // Одвојено се позабавите завршним битом експонента, јер накнадно квадрирање базе није потребно и може проузроковати непотребно преливање.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Подиже себе до снаге Кс00Кс, користећи потенцирање квадратом.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // пошто је екп!=0, коначно екп мора бити 1.
            // Одвојено се позабавите завршним битом експонента, јер накнадно квадрирање базе није потребно и може проузроковати непотребно преливање.
            //
            //
            acc * base
        }

        /// Израчунава количник Еуклидове поделе Кс01Кс са Кс00Кс.
        ///
        /// Ово израчунава цели број Кс02Кс тако да Кс01Кс, са Кс00Кс.
        ///
        ///
        /// Другим речима, резултат је Кс01Кс заокружен на цео број Кс02Кс такав да је Кс00Кс.
        /// Ако је Кс00Кс, ово је једнако заокружењу према нули (подразумевано у З0Руст0З);
        /// ако је Кс00Кс, ово је једнако округлој ка +/-бесконачности.
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0 или ако подела резултира преливањем.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// нека је б=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 Кс00Кс, Кс09Кс);//7>=Кс03Кс* Кс04Кс Кс01Кс, Кс010Кс);//Кс05Кс>=4 *Кс06Кс Кс02Кс, 2);//Кс07Кс>=Кс08Кс* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Израчунава најмањи ненегативни остатак Кс00Кс.
        ///
        /// То се ради као да је употребљен еуклидски алгоритам поделе-дати Кс01Кс, Кс02Кс и Кс00Кс.
        ///
        ///
        /// # Panics
        ///
        /// Ова функција ће З0паниц0З ако је Кс00Кс 0 или ако подела резултира преливањем.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// нека је б=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Израчунава апсолутну вредност Кс00Кс.
        ///
        /// # Понашање преливања
        ///
        /// Апсолутна вредност
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// не може се представити као
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// а покушај израчунавања изазваће преливање.
        /// То значи да ће код у режиму отклањања грешака покренути З0паниц0З у овом случају и оптимизовани код ће се вратити
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// без З0паниц0З.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Имајте на уму да горњи#[инлине] значи да семантика преливања одузимања зависи од З0црате0З у који смо уграђени.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Приказује број који представља знак Кс00Кс.
        ///
        ///  - `0` ако је број нула
        ///  - `1` ако је број позитиван
        ///  - `-1` ако је број негативан
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Приказује Кс00Кс ако је Кс01Кс позитиван и Кс02Кс ако је број нула или негативан.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Приказује Кс00Кс ако је Кс01Кс негативан и Кс02Кс ако је број нула или позитиван.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Вратите меморијски приказ овог целог броја као бајтни низ у биг-ендиан Кс00Кс редоследу бајтова.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Вратите меморијски приказ овог целог броја као бајтни низ у мало-енданском редоследу бајтова.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Вратите меморијски приказ овог целог броја као бајтни низ у матичном редоследу бајтова.
        ///
        /// Како се користи изворни циљ циљне платформе, преносни код уместо тога треба да користи Кс01Кс или Кс00Кс, према потреби.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     бајтова, ако је цфг! (таргет_ендиан=Кс00Кс){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } остало {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗБЕДНОСТ: цонст звук јер су цели бројеви обични стари типови података тако да увек можемо
        // претворити их у низове бајтова
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // БЕЗБЕДНОСТ: цели бројеви су обични стари типови података тако да их увек можемо трансформисати
            // низови бајтова
            unsafe { mem::transmute(self) }
        }

        /// Вратите меморијски приказ овог целог броја као бајтни низ у матичном редоследу бајтова.
        ///
        ///
        /// [`to_ne_bytes`] треба дати предност овоме кад год је то могуће.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// нека бајтови=Кс00Кс;
        /// assert_eq!(
        ///     бајтова, ако је цфг! (таргет_ендиан=Кс00Кс){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } остало {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // БЕЗБЕДНОСТ: цели бројеви су обични стари типови података тако да их увек можемо трансформисати
            // низови бајтова
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Створите целобројну вредност од њене репрезентације као бајт низа у великом ендиану.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користите Кс00Кс;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * улаз=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Створите целобројну вредност од њене репрезентације као бајт низа у малом ендиану.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користите Кс00Кс;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * улаз=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Створите целобројну вредност од њене меморијске репрезентације као бајт низа у изворном ендианнесс-у.
        ///
        /// Како се користи изворни ендијанс циљне платформе, преносиви код вероватно жели да користи Кс01Кс или Кс00Кс, према потреби.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } остало {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// користите Кс00Кс;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * улаз=одмор;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗБЕДНОСТ: цонст звук јер су цели бројеви обични стари типови података тако да увек можемо
        // преобразити их
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // БЕЗБЕДНОСТ: цели бројеви су обични стари типови података тако да их увек можемо трансформисати
            unsafe { mem::transmute(bytes) }
        }

        /// Нови код би радије требало да се користи
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Приказује најмању вредност коју овај целобројни тип може представити.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Нови код би радије требало да се користи
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Враћа највећу вредност која може бити представљена овим целобројним типом.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}