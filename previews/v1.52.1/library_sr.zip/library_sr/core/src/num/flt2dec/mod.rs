/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// иако је ово опсежно документовано, ово је у принципу приватно и објављено је само за тестирање.
// не излажите нас.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Алгоритми генерисања цифара.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Минимална величина бафера потребна за најкраћи режим.
///
/// Извођење је помало нетривијално, али ово је плус плус максималан број значајних децималних цифара из алгоритама за форматирање са најкраћим резултатом.
///
/// Тачна формула је Кс00Кс.
pub const MAX_SIG_DIGITS: usize = 17;

/// Када Кс00Кс садржи децималне цифре, повећајте последњу цифру и проширите пренос.
/// Даје следећу цифру када проузрокује промену дужине.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // д [и + 1..н] је све деветке
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 заокружује на 1000..000 са повећаним експонентом
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // заокружује се празан бафер (помало чудно, али разумно)
            Some(b'1')
        }
    }
}

/// Форматирани делови.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Дати број нула цифара.
    Zero(usize),
    /// Буквални број до 5 цифара.
    Num(u16),
    /// Дословна копија датих бајтова.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Приказује тачну дужину бајта датог дела.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Записује део у испоручени бафер.
    /// Приказује број записаних бајтова или Кс00Кс ако ме успремник није довољан.
    /// (И даље може оставити делимично написане бајтове у међуспремнику; немојте се ослањати на то.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Форматирани резултат који садржи један или више делова.
/// То се може записати у бајтни бафер или претворити у додељени низ.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Бајтни пресек који представља знак, било Кс01Кс, Кс02Кс или Кс00Кс.
    pub sign: &'static str,
    /// Форматирани делови који ће се приказати након знака и опционалног додавања нуле.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Приказује тачну дужину бајта комбинованог форматираног резултата.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Записује све форматиране делове у испоручени бафер.
    /// Приказује број записаних бајтова или Кс00Кс ако ме успремник није довољан.
    /// (И даље може оставити делимично написане бајтове у међуспремнику; немојте се ослањати на то.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Формати дају децималне цифре Кс00Кс у децимални облик са најмање датим бројем делимичних цифара.
///
/// Резултат се чува у испорученом низу делова и враћа се део исписаних делова.
///
/// `frac_digits` може бити мањи од броја стварних делимичних цифара у Кс00Кс;
/// биће занемарено и исписане пуне цифре.Користи се само за испис додатних нула након генерираних цифара.
/// Стога Кс00Кс од 0 значи да ће штампати само дате цифре и ништа друго.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ако постоји ограничење на позицији последње цифре, претпоставља се да је Кс00Кс препуњен виртуелним нулама.
    // број виртуелних нула, Кс01Кс, једнак је Кс02Кс, тако да положај последње цифре Кс03Кс није већи од Кс00Кс:
    //
    //
    //                       |<-virtual->|
    //       | <----буф----> |нуле |екп
    //    0. 1 2 3 4 5 6 7 8 9 Кс00Кс Кс01Кс Кс02Кс к 10
    //    |                  |           |
    // 10 ^ екп Кс01Кс Кс00Кс
    //
    // `nzeroes` израчунава се појединачно за сваки случај како би се избегло преливање.
    //

    if exp <= 0 {
        // децимална тачка је пре приказаних цифара: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // децимална тачка је унутар приказаних цифара: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // децимална запета је после приказаних цифара: Кс01Кс или Кс00Кс.
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Форматира дате децималне цифре Кс00Кс у експоненцијални облик са најмање датим бројем значајних цифара.
///
/// Када је Кс03Кс Кс01Кс, експоненту ће бити префикс Кс02Кс;иначе је то Кс00Кс.
/// Резултат се чува у испорученом низу делова и враћа се део исписаних делова.
///
/// `min_digits` може бити мањи од броја стварних значајних цифара у Кс00Кс;
/// биће занемарено и исписане пуне цифре.Користи се само за испис додатних нула након генерираних цифара.
/// Дакле, Кс00Кс значи да ће штампати само дате цифре и ништа друго.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 к 10 ^ екп=Кс00Кс к 10 ^ (екп-1)
    let exp = exp as i32 - 1; // избегавајте преливање када је екп Кс00Кс
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Опције форматирања потписа.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Штампа Кс00Кс само за негативне вредности које нису нула.
    Minus, // -inf Кс00Кс 0 0 1 инф нан
    /// Штампа Кс00Кс само за било какве негативне вредности (укључујући негативну нулу).
    MinusRaw, // -inf Кс00Кс Кс01Кс 0 1 инф нан
    /// Штампа Кс00Кс за негативне вредности које нису нула, или Кс01Кс у супротном.
    MinusPlus, // -inf Кс00Кс +0 +0 +1 + инф нан
    /// Штампа Кс00Кс за било које негативне вредности (укључујући негативну нулу) или Кс01Кс у супротном.
    MinusPlusRaw, // -inf Кс00Кс Кс01Кс +0 +1 + инф нан
}

/// Враћа низ статичких бајтова који одговара знаку који треба форматирати.
/// То може бити Кс01Кс, Кс02Кс или Кс00Кс.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Форматира дати број са помичном зарезом у децимални облик са најмање датим бројем делимичних цифара.
/// Резултат се чува у испорученом низу делова, док се дати бајт бајта користи као огреботина.
/// `upper` је тренутно неискоришћен, али је остављен за одлуку З0футуре0З да промени случај не коначних вредности, тј. Кс01Кс и Кс00Кс.
///
/// Први део који се приказује је увек Кс00Кс (који може бити празан низ ако није приказан ниједан знак).
///
/// `format_shortest` треба да буде основна функција генерисања цифара.
/// Требало би да врати део бафера који је иницијализован.
/// Вероватно бисте желели Кс00Кс за ово.
///
/// `frac_digits` може бити мањи од броја стварних делимичних цифара у Кс00Кс;
/// биће занемарено и исписане пуне цифре.Користи се само за испис додатних нула након генерираних цифара.
/// Стога Кс00Кс од 0 значи да ће штампати само дате цифре и ништа друго.
///
/// Бајтни бафер треба да буде дугачак најмање Кс00Кс бајтова.
/// Требало би да буду доступна најмање 4 дела, због најгорег случаја као што је Кс01Кс са Кс00Кс.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Форматира дати број са помичном зарезом у децимални облик или експоненцијални облик, у зависности од резултујућег експонента.
/// Резултат се чува у испорученом низу делова, док се дати бајт бајта користи као огреботина.
/// `upper` користи се за одређивање случаја не коначних вредности (Кс00Кс и Кс02Кс) или случаја експонентног префикса (Кс01Кс или Кс03Кс).
/// Први део који се приказује је увек Кс00Кс (који може бити празан низ ако није приказан ниједан знак).
///
/// `format_shortest` треба да буде основна функција генерисања цифара.
/// Требало би да врати део бафера који је иницијализован.
/// Вероватно бисте желели Кс00Кс за ово.
///
/// Кс01Кс је скуп Кс02Кс такав да је број форматиран као децимални само када је Кс00Кс.
/// Имајте на уму да је ово *привидни* Кс01Кс уместо стварног Кс00Кс!Стога било који одштампани експонент у експоненцијалном облику не може бити у овом опсегу, избегавајући било какву забуну.
///
///
/// Бајтни бафер треба да буде дугачак најмање Кс00Кс бајтова.
/// Требало би да буде доступно најмање 6 делова, због најгорег случаја као што је Кс00Кс.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Даје прилично грубу апроксимацију (горња граница) за максималну величину бафера израчунату из датог декодираног експонента.
///
/// Тачно ограничење је:
///
/// - када је Кс01Кс, максимална дужина је Кс00Кс.
/// - када је Кс01Кс, максимална дужина је Кс00Кс.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` је мање од Кс01Кс, што је пак мање од Кс00Кс.
/// Користимо чињенице Кс01Кс и Кс00Кс, што је довољно за наше сврхе.
///
/// Зашто нам је ово потребно?Функције Кс00Кс ће попунити читав бафер, осим ако нису ограничене ограничењем последње цифре, али могуће је да је тражени број цифара смешно велик (рецимо, 30.000 цифара).
///
/// Велика већина бафера биће попуњена нулама, тако да не желимо унапред да доделимо сав бафер.
/// Сходно томе, за било који дати аргумент,
/// 826 бајтова бафера треба да буде довољно за Кс00Кс.Упоредите ово са стварним бројем у најгорем случају: 770 бајтова (када је Кс01Кс).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Формати дају број са покретном тачком у експоненцијални облик са тачно датим бројем значајних цифара.
/// Резултат се чува у испорученом низу делова, док се дати бајт бајта користи као огреботина.
/// `upper` користи се за одређивање великих слова префикса експонента (Кс00Кс или Кс01Кс).
/// Први део који се приказује је увек Кс00Кс (који може бити празан низ ако није приказан ниједан знак).
///
/// `format_exact` треба да буде основна функција генерисања цифара.
/// Требало би да врати део бафера који је иницијализован.
/// Вероватно бисте желели Кс00Кс за ово.
///
/// Бајтни бафер треба да има најмање Кс00Кс бајтова, осим ако је Кс01Кс толико велик да ће икада бити записан само фиксни број цифара.
/// (Тачка превртања за Кс01Кс је око 800, па би требало да буде довољно 1000 бајтова.) Требало би да буде доступно најмање 6 делова, због најгорег случаја као што је Кс00Кс.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Формати дају број с помичним зарезом у децимални облик са тачно датим бројем делимичних цифара.
/// Резултат се чува у испорученом низу делова, док се дати бајт бајта користи као огреботина.
/// `upper` је тренутно неискоришћен, али је остављен за одлуку З0футуре0З да промени случај не коначних вредности, тј. Кс01Кс и Кс00Кс.
/// Први део који се приказује је увек Кс00Кс (који може бити празан низ ако није приказан ниједан знак).
///
/// `format_exact` треба да буде основна функција генерисања цифара.
/// Требало би да врати део бафера који је иницијализован.
/// Вероватно бисте желели Кс00Кс за ово.
///
/// Бајтни бафер требао би бити довољан за излаз, осим ако је Кс00Кс толико велик да ће икада бити записан само фиксни број цифара.
/// (Тачка превртања Кс01Кс је око 800, а требало би бити довољно 1000 бајтова.) Требало би да буду доступна најмање 4 дела, због најгорег случаја као што је Кс02Кс са Кс00Кс.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // *могуће је* да је Кс00Кс смешно велик.
            // `format_exact` у овом случају ће окончати приказивање цифара много раније, јер смо строго ограничени Кс00Кс.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ограничење није могло да се испуни, па би ово требало да изгледа као нула без обзира на то да ли је Кс00Кс.
                // ово не укључује случај да је ограничење испуњено тек након коначног заокруживања;то је уобичајен случај са Кс00Кс.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // БЕЗБЕДНОСТ: управо смо иницијализовали елементе Кс00Кс.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}