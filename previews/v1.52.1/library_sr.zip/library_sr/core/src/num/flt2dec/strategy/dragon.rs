//! Готово директан (али мало оптимизован) З0Руст0З превод слике 3 у " Брзо и тачно штампање бројева са покретним зарезима` [^ 1].
//!
//!
//! [^1]: Burger, РГ и Дибвиг, РК 1996. Штампање бројева са покретном зарезом
//!   брзо и тачно.СИГПЛАН Не.31, 5 (мај, 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// прерачунати низови `Дигита` за 10 ^ (2 ^ н)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// употребљиво само када је Кс01Кс;Кс02Кс би требао бити Кс00Кс
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Најкраћи начин примене за Драгон.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // познато је да је број Кс00Кс за форматирање:
    // - једнако Кс00Кс;
    // - претходи Кс00Кс у оригиналном типу;и
    // - а затим Кс00Кс у оригиналном типу.
    //
    // очигледно, Кс00Кс и Кс02Кс не могу бити нула.(за бесконачности користимо вредности изван опсега.) такође претпостављамо да је генерисана најмање једна цифра, тј. Кс01Кс такође не може бити нула.
    //
    // то такође значи да ће се било који број између Кс00Кс и Кс01Кс пресликати на тачно тачан број са помичном зарезом, укључујући границе када је оригинална мантиса била парна (тј. Кс02Кс).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` је Кс00Кс
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // процените Кс01Кс на основу оригиналних улаза који задовољавају Кс00Кс.
    // чврсто везани Кс00Кс који задовољава Кс01Кс израчунава се касније.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // претворити Кс00Кс у разломљени облик тако да:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // поделити Кс02Кс са Кс01Кс.сада Кс00Кс.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // поправити када је Кс00Кс (или Кс01Кс).
    // ми заправо не модификујемо Кс00Кс, јер уместо тога можемо прескочити почетно множење.
    // сада Кс00Кс и спремни смо за генерисање цифара.
    //
    // имајте на уму да Кс01Кс *може* бити нула, када Кс00Кс.
    // у овом случају ће се одмах покренути услов заокруживања (Кс00Кс доле).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // еквивалентно скалирању Кс00Кс за 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кеш Кс00Кс за генерисање цифара.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инваријанте, где су Кс00Кс до сада генерисане цифре:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (дакле Кс01Кс) где је Кс00Кс скраћеница за `д [и] * 10 ^ (ји) + ...
        // + д [ј-1] * 10 + Кс00Кс.

        // генериши једну цифру: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ово је поједностављени опис модификованог змајевог алгоритма.
        // многи посредни изводи и аргументи потпуности су изостављени због погодности.
        //
        // започните са модификованим инваријантима, пошто смо ажурирали Кс00Кс:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // претпоставимо да је Кс02Кс најкраћи приказ између Кс03Кс и Кс00Кс, тј. Кс01Кс задовољава оба следећа, али Кс04Кс не:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (бијективност: цифре заокружују до Кс00Кс);и
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (последња цифра је тачна).
        //
        // други услов је поједностављен на Кс00Кс.
        // решавање инваријаната у терминима Кс00Кс, Кс01Кс и Кс02Кс даје једноставнију верзију првог услова: `-plus < mant < minus`.
        // од Кс01Кс, имамо тачно најкраћу представу када су Кс02Кс и Кс00Кс.
        // (први постаје Кс00Кс када је оригинална мантиса уједначена.)
        //
        // када друга не држи (`2 * мант> скала`), морамо повећати последњу цифру.
        // ово је довољно за обнављање тог стања: већ знамо да генерација цифара гарантује Кс00Кс.
        // у овом случају први услов постаје Кс00Кс.
        // од Кс01Кс након генерације имамо Кс00Кс.
        // (опет, ово постаје Кс00Кс када је оригинална мантиса уједначена.)
        //
        // укратко:
        // - зауставите и заокружите Кс00Кс (задржите цифре какве јесу) када Кс01Кс (или Кс02Кс).
        // - зауставите и заокружите Кс00Кс (повећајте последњу цифру) када Кс01Кс (или Кс02Кс).
        // - настави да генеришеш у супротном.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // имамо најкраћу заступљеност, пређите на заокруживање

        // вратити инваријанте.
        // то чини да се алгоритам увек завршава: Кс00Кс и Кс01Кс се увек повећавају, али Кс02Кс се исече модуло Кс03Кс и Кс04Кс је фиксиран.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // заокруживање се дешава када и) је покренут само услов заокруживања, или ии) оба услова су покренута и прекид везе преферира заокруживање.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ако заокруживање промени дужину, требало би променити и експонент.
        // чини се да је врло тешко испунити овај услов (могуће немогуће), али ми смо овде само сигурни и доследни.
        //
        // БЕЗБЕДНОСТ: ту меморију смо иницијализовали горе.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // БЕЗБЕДНОСТ: ту меморију смо иницијализовали горе.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Тачна и фиксна примена режима за Драгон.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // процените Кс01Кс на основу оригиналних улаза који задовољавају Кс00Кс.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // поделити Кс02Кс са Кс01Кс.сада Кс00Кс.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // поправити када Кс01Кс, где Кс00Кс.
    // да бисмо задржали бигнум фиксне величине, заправо користимо Кс00Кс.
    // ми заправо не модификујемо Кс00Кс, јер уместо тога можемо прескочити почетно множење.
    // опет са најкраћим алгоритмом, Кс00Кс може бити нула, али ће на крају бити заокружен.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // еквивалентно скалирању Кс00Кс за 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ако радимо са ограничењем од последње цифре, треба да скратимо бафер пре стварног приказивања како бисмо избегли двоструко заокруживање.
    //
    // имајте на уму да морамо поново повећати бафер када се догоди заокруживање!
    let mut len = if k < limit {
        // Упс, не можемо да произведемо ни *једну* цифру.
        // ово је могуће када, рецимо, имамо нешто попут Кс00Кс и заокружено је на 10.
        // враћамо празан бафер, са изузетком каснијег случаја заокруживања који се јавља када Кс00Кс и мора да произведе тачно једну цифру.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кеш Кс00Кс за генерисање цифара.
        // (ово може бити скупо, па их немојте израчунавати када је бафер празан.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // следеће цифре су све нуле, овде се заустављамо, не *не* покушајте да извршите заокруживање!него попуните преостале цифре.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // БЕЗБЕДНОСТ: ту меморију смо иницијализовали горе.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // заокруживање ако се зауставимо у средини цифара ако су следеће цифре тачно 5000 ..., проверите претходну цифру и покушајте да заокружите на пару (тј. избегавајте заокруживање када је претходна цифра парна).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // БЕЗБЕДНОСТ: Кс00Кс је иницијализован.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ако заокруживање промени дужину, требало би променити и експонент.
        // али затражен је фиксни број цифара, зато немојте мењати бафер ...
        // БЕЗБЕДНОСТ: ту меморију смо иницијализовали горе.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... осим ако од нас није тражена фиксна прецизност.
            // такође морамо да проверимо да, ако је оригинални бафер био празан, додатна цифра се може додати само када је Кс00Кс (случај З0едге0З).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // БЕЗБЕДНОСТ: ту меморију смо иницијализовали горе.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}