//! Декодира вредност са покретном зарезом у појединачне делове и опсеге грешака.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодирана непотписана коначна вредност, таква да:
///
/// - Оригинална вредност је једнака Кс00Кс.
///
/// - Било који број од Кс00Кс до Кс01Кс заокруживаће се на првобитну вредност.
/// Опсег укључује само када је Кс01Кс Кс00Кс.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Скалирана мантиса.
    pub mant: u64,
    /// Доњи опсег грешака.
    pub minus: u64,
    /// Горњи опсег грешака.
    pub plus: u64,
    /// Подељени експонент у основи 2.
    pub exp: i16,
    /// Тачно када је обухваћен опсег грешака.
    ///
    /// У ИЕЕЕ 754, ово је тачно када је оригинална мантиса била парна.
    pub inclusive: bool,
}

/// Декодирана непотписана вредност.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Бесконачности, било позитивне било негативне.
    Infinite,
    /// Нула, било позитивна или негативна.
    Zero,
    /// Коначни бројеви са даље декодираним пољима.
    Finite(Decoded),
}

/// Тип са покретном тачком који се може `декодирати`д.
pub trait DecodableFloat: RawFloat + Copy {
    /// Минимална позитивна нормализована вредност.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Приказује знак (тачно када је негативно) и вредност Кс00Кс из датог броја са покретном зарезом.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // комшије: (мант, 2, екп)-(мант, екп)-(мант + 2, екп)
            // Float::integer_decode увек чува експонент, па се мантиса скалира за субнормалне.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // суседи: (макмант, екп, 1)-(миннорммант, екп)-(миннорммант + 1, екп)
                // где је макмант=миннорммант * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // комшије: (мант, 1, екп)-(мант, екп)-(мант + 1, екп)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}