//! Константе за 16-битни тип с потписом цијелог броја.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Нови код треба да користи придружене константе директно на примитивном типу.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }