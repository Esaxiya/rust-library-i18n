//! Битно петљање на позитивним ИЕЕЕ 754 пловцима.Негативни бројеви нису и не треба их руковати.
//! Нормалне плутајући бројеви тачака имају канонски представљање као (фрац, екп) тако да вредност 2 <sup>екп</sup> * (1 + Кс00Кс где је Н број битова.
//!
//! Субнормали су мало различити и чудни, али примењује се исти принцип.
//!
//! Овде их, међутим, представљамо као (сиг, к) са ф позитивно, тако да је вредност ф *
//! 2 <sup>е</sup> .Поред тога што Кс00Кс чини експлицитним, ово мења експонент такозваним мантисса помаком.
//!
//! Другим речима, обично пловци се пишу као Кс01Кс, али овде се пишу као Кс00Кс:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Кс00Кс називамо **делимичним приказом**, а Кс01Кс **интегралним приказом**.
//!
//! Многе функције у овом модулу обрађују само нормалне бројеве.Рутине дец2флт конзервативно иду универзално исправним спорим путем (алгоритам М) за врло мале и врло велике бројеве.
//! За тај алгоритам потребан је само Кс00Кс који обрађује субнормале и нуле.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Помоћник З0 Портраит0З како би се избегло дуплицирање у основи свих кодова конверзије за Кс01Кс и Кс00Кс.
///
/// Зашто је то потребно погледајте у коментару на документ родитељског модула.
///
/// **Никада** не би требало да буде имплементирано за друге типове или да се користи изван дец2флт модула.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Тип који користе Кс01Кс и Кс00Кс.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Изводи сирову трансмутацију у цео број.
    fn to_bits(self) -> Self::Bits;

    /// Изводи сирову трансмутацију из целог броја.
    fn from_bits(v: Self::Bits) -> Self;

    /// Приказује категорију у коју спада овај број.
    fn classify(self) -> FpCategory;

    /// Враћа мантису, експонент и знак као целе бројеве.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Декодира пловак.
    fn unpack(self) -> Unpacked;

    /// Емитира из малог целог броја који се може тачно представити.
    /// З0Паниц0З ако цели број не може бити представљен, други код у овом модулу осигурава да се то никада не догоди.
    fn from_int(x: u64) -> Self;

    /// Добија вредност 10 <sup>е</sup> из унапред израчунате табеле.
    /// З0Паницс0З за Кс00Кс.
    fn short_fast_pow10(e: usize) -> Self;

    /// Шта говори име.
    /// Лакше је кодирати него жонглирати са стварима и надати се да ће ЛЛВМ константа то преклопити.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Конзервативна веза на децималне цифре улаза који не могу произвести прелив или нулу или
    /// субнормали.Вероватно децимални експонент максималне нормалне вредности, отуда и назив.
    const MAX_NORMAL_DIGITS: usize;

    /// Када најзначајнија децимална цифра има вредност места већу од ове, број се сигурно заокружује на бесконачност.
    ///
    const INF_CUTOFF: i64;

    /// Када најзначајнија децимална цифра има вредност места мању од ове, број се сигурно заокружује на нулу.
    ///
    const ZERO_CUTOFF: i64;

    /// Број битова у експоненту.
    const EXP_BITS: u8;

    /// Број битова у значењу и *укључујући* скривени бит.
    const SIG_BITS: u8;

    /// Број битова у значењу,*искључујући* скривени бит.
    const EXPLICIT_SIG_BITS: u8;

    /// Максимални правни експонент у делимичном представљању.
    const MAX_EXP: i16;

    /// Минимални правни експонент у делимичном представљању, искључујући субнормале.
    const MIN_EXP: i16;

    /// `MAX_EXP` за интегрално представљање, односно са примењеном сменом.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` кодирано (тј. са оффсет пристрасношћу)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` за интегрално представљање, односно са примењеном сменом.
    const MIN_EXP_INT: i16;

    /// Максимални нормализовани значај у интегралном представљању.
    const MAX_SIG: u64;

    /// Минимални нормализовани значај у интегралном представљању.
    const MIN_SIG: u64;
}

// Углавном заобилазно решење за Кс00Кс.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Враћа мантису, експонент и знак као целе бројеве.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Експонентна пристрасност + помак мантисе
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // ркруппе није сигуран да ли се Кс00Кс правилно заокружује на свим платформама.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Враћа мантису, експонент и знак као целе бројеве.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Експонентна пристрасност + помак мантисе
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // ркруппе није сигуран да ли се Кс00Кс правилно заокружује на свим платформама.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Претвара Кс00Кс у најближи тип пловног строја.
/// Не обрађује субнормалне резултате.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f је 64 бит, тако да ке има мантису померање од 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-битни значај заокружите на Кс00Кс битове са пола-до-чак.
/// Не обрађује преливање експонента.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Прилагодите смену мантиссе
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Обрнуто од Кс00Кс за нормализоване бројеве.
/// З0Паницс0З ако значење или експонент нису важећи за нормализоване бројеве.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Уклоните скривени бит
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Подесите експонент за пристраност експонента и помак мантисе
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Оставите знак за бит на 0 Кс00Кс, сви наши бројеви су позитивни
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Конструисати субнормално.Мантиса од 0 је дозвољена и конструише нулу.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Кодирани експонент је 0, знаковни бит је 0, тако да морамо само да реинтерпретирамо битове.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Приближно бигнум са Фп.Заокружује унутар Кс00Кс УЛП са пола до уједначења.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Одсекли смо све битове пре индекса Кс00Кс, тј. Ефективно померамо удесно за износ од Кс01Кс, па је ово уједно и експонент који нам треба.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Округли Кс00Кс у зависности од скраћених битова.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Проналази највећи број с помичном зарезом строго мањи од аргумента.
/// Не обрађује субнормале, нулу или потцјењивање експонента.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Нађите најмањи број с помичном зарезом строго већи од аргумента.
// Ова операција је засићујућа, тј. Кс00Кс==инф.
// За разлику од већине кода у овом модулу, ова функција обрађује нулу, субнормале и бесконачности.
// Међутим, као и сви остали кодови овде, он се не бави НаН и негативним бројевима.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Чини се да је ово превише добро да би било истина, али успева.
        // 0.0 је кодиран као реч са нулом.Субнормали су 0к000м ... м где је м мантиса.
        // Конкретно, најмањи субнормал је 0к0 ... 01, а највећи 0к000Ф ... Ф.
        // Најмањи нормални број је 0к0010 ... 0, тако да и овај угаони случај функционише.
        // Ако прираштај преплави мантису, преносни бит повећава експонент како желимо, а битови мантисе постају нула.
        // Због скривене конвенције о битовима, и ово је управо оно што желимо!
        // Коначно, Кс01Кс + 1=7ефф ... ф + 1=7фф0 ... 0=Кс00Кс.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}