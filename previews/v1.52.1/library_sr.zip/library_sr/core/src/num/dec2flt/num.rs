//! Услужне функције за бигнуме које немају превише смисла претворити се у методе.

// ФИКСМЕ Име овог модула је помало жалосно, јер и други модули увозе Кс00Кс.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Тестирајте да ли одсецање свих битова мање значајних од Кс00Кс уводи релативну грешку мању, једнаку или већу од Кс01Кс УЛП.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <Кс00Кс УЛП
        return Less;
    }
    // Ако су сви преостали битови нула, то је=Кс00Кс УЛП, у супротном> Кс01Кс Ако више нема битова (халф_бит==0), доље такође исправно враћа Екуал.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Претвара АСЦИИ низ који садржи само децималне цифре у Кс00Кс.
///
/// Не врши провере за прекомерне или неважеће знакове, па ако позивалац није пажљив, резултат је лажан и може З0паниц0З (мада то неће бити Кс00Кс).
/// Поред тога, празни низови се третирају као нула.
/// Ова функција постоји јер
///
/// 1. коришћење Кс01Кс на Кс02Кс захтева Кс00Кс, што је лоше, и
/// 2. састављање резултата Кс00Кс и Кс01Кс сложеније је од целокупне ове функције.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Претвара низ АСЦИИ цифара у бигнум.
///
/// Као и Кс00Кс, и ова функција се ослања на парсер за уклањање нецифрених бројева.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Распакује бигнум у 64-битни цели број.З0Паницс0З ако је број превелик.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Издваја низ битова.

/// Индекс 0 је најмање значајан бит, а опсег је полуотворен као и обично.
/// З0Паницс0З ако се затражи да извуче више битова него што се уклапа у тип повратка.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}