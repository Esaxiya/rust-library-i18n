//! Типови грешака за конверзију у интегралне типове.

use crate::convert::Infallible;
use crate::fmt;

/// Тип грешке враћен је када провјерена конверзија интегралног типа не успије.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Пре се подударајте, а не присиљавајте, како бисте били сигурни да ће код попут Кс01Кс горе наставити да ради када Кс02Кс постане псеудоним Кс00Кс.
        //
        //
        match never {}
    }
}

/// Грешка која се може вратити приликом рашчлањивања целог броја.
///
/// Ова грешка се користи као тип грешке за функције Кс01Кс на примитивним целобројним типовима, као што је Кс00Кс.
///
/// # Потенцијални узроци
///
/// Између осталих узрока, Кс00Кс се може бацити због водећег или пратећег празног простора у низу, на пример, када је добијен из стандардног улаза.
///
/// Коришћење Кс00Кс методе осигурава да не остане празнина пре рашчлањивања.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Енум за чување различитих врста грешака које могу довести до неуспеха рашчлањивања целог броја.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Вредност која се рашчлањује је празна.
    ///
    /// Између осталих узрока, ова варијанта ће се конструисати приликом рашчлањивања празног низа.
    Empty,
    /// Садржи неважећу цифру у свом контексту.
    ///
    /// Између осталих узрока, ова варијанта ће се конструисати приликом рашчлањивања низа који садржи знак који није АСЦИИ.
    ///
    /// Ова варијанта се такође прави када се Кс00Кс или Кс01Кс погрешно постави у низ или самостално или усред броја.
    ///
    ///
    InvalidDigit,
    /// Цео број је превелик за чување у циљном целобројном типу.
    PosOverflow,
    /// Цео број је премали за чување у циљном целобројном типу.
    NegOverflow,
    /// Вредност је била Нула
    ///
    /// Ова варијанта ће се емитовати када низ рашчлањивања има вредност нула, што би било противзаконито за типове који нису нула.
    ///
    Zero,
}

impl ParseIntError {
    /// Избацује детаљан узрок неуспешног рашчлањивања целог броја.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}