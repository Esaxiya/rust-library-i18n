//! Константе специфичне за Кс00Кс тип са покретном тачком са једном прецизношћу.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Математички значајни бројеви дати су у подмодулу Кс00Кс.
//!
//! За константе дефинисане директно у овом модулу (за разлику од оних дефинисаних у Кс00Кс подмодулу), нови код уместо тога треба да користи придружене константе дефинисане директно на типу Кс01Кс.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Полупречник или основа унутрашњег представљања Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // предвиђени начин
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Број значајних цифара у основи 2.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // предвиђени начин
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Приближан број значајних цифара у основи 10.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // предвиђени начин
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] вредност за Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// То је разлика између Кс00Кс и следећег већег броја који се може представити.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // предвиђени начин
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Најмања коначна вредност Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // предвиђени начин
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Најмања позитивна нормална вредност Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // предвиђени начин
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Највећа коначна вредност Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // предвиђени начин
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Један већи од минималне могуће нормалне снаге 2 експонента.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // предвиђени начин
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Максимална могућа снага од 2 експонента.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // предвиђени начин
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Минимална могућа нормална снага од 10 експонената.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // предвиђени начин
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Максимална могућа снага од 10 експонената.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // предвиђени начин
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Није број Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // предвиђени начин
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Инфинити Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // предвиђени начин
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Негативна бесконачност Кс00Кс.
/// Уместо тога користите Кс00Кс.
///
/// # Examples
///
/// ```rust
/// // застарјели начин
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // предвиђени начин
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Основне математичке константе.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: заменити математичким константама из цматх-а.

    /// Архимедова константа Кс00Кс
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Константа пуног круга Кс00Кс
    ///
    /// Једнако 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Еулер-ов број Кс00Кс
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Полупречник или основа унутрашњег представљања Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Број значајних цифара у основи 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Приближан број значајних цифара у основи 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] вредност за Кс00Кс.
    ///
    /// То је разлика између Кс00Кс и следећег већег броја који се може представити.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Најмања коначна вредност Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Најмања позитивна нормална вредност Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Највећа коначна вредност Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Један већи од минималне могуће нормалне снаге 2 експонента.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Максимална могућа снага од 2 експонента.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Минимална могућа нормална снага од 10 експонената.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Максимална могућа снага од 10 експонената.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Није број Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Инфинити Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Негативна бесконачност Кс00Кс.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Приказује Кс01Кс ако је ова вредност Кс00Кс.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Кс00Кс је јавно недоступан у либцореу због забринутости због преносивости, тако да је ова примена за приватну употребу.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Приказује Кс00Кс ако је ова вредност позитивна или негативна бесконачност, а Кс01Кс у супротном.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Приказује Кс01Кс ако овај број није ни бесконачан ни Кс00Кс.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Нема потребе да посебно обрађујете НаН: ако је селф НаН, поређење није тачно, тачно по жељи.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Приказује Кс01Кс ако је број Кс00Кс.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Вредности између Кс00Кс и Кс01Кс су субнормалне.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Приказује Кс02Кс ако број није нула, бесконачан, Кс01Кс или Кс00Кс.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Вредности између Кс00Кс и Кс01Кс су субнормалне.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Враћа категорију броја са помичним зарезом.
    /// Ако ће се тестирати само једно својство, обично је брже користити одређени предикат.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Враћа Кс01Кс ако Кс02Кс има позитиван предзнак, укључујући Кс00Кс, `НаН` са позитивним битом знака и позитивном бесконачношћу.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Враћа Кс01Кс ако Кс02Кс има негативан предзнак, укључујући Кс00Кс, `НаН` с негативним предзнаком бита и негативном бесконачношћу.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // ИЕЕЕ754 каже: Кс00Кс је истинит ако и само ако к има негативан предзнак.
        // исСигнМинус се односи и на нуле и НаН.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Узима реципрочни Кс00Кс броја, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Претвара радијане у степене.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Користите константу за бољу прецизност.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Претвара степене у радијане.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Приказује максимум од два броја.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ако је један од аргумената НаН, онда се враћа други аргумент.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Враћа минимум од два броја.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ако је један од аргумената НаН, онда се враћа други аргумент.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Заокружује се према нули и претвара у било који примитивни целобројни тип, под претпоставком да је вредност коначна и да одговара том типу.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Вредност мора:
    ///
    /// * Не бити Кс00Кс
    /// * Не будите бесконачни
    /// * Будите представљиви у повратном типу Кс00Кс, након одсецања његовог делимичног дела
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Сирова трансмутација у Кс00Кс.
    ///
    /// Ово је тренутно идентично са Кс00Кс на свим платформама.
    ///
    /// Погледајте Кс00Кс за неке расправе о преносивости ове операције (готово да нема проблема).
    ///
    /// Имајте на уму да се ова функција разликује од Кс00Кс ливења, које покушава да сачува *нумеричку* вредност, а не вредност у битовима.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() није ливење!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // БЕЗБЕДНОСТ: Кс00Кс је обичан стари тип података тако да га увек можемо трансформисати
        unsafe { mem::transmute(self) }
    }

    /// Сирова трансмутација из Кс00Кс.
    ///
    /// Ово је тренутно идентично са Кс00Кс на свим платформама.
    /// Испоставило се да је ово невероватно преносно из два разлога:
    ///
    /// * Флоатс и Интс имају исти ендианнесс на свим подржаним платформама.
    /// * ИЕЕЕ-754 врло прецизно одређује распоред битова пловака.
    ///
    /// Међутим, постоји једно упозорење: пре верзије ИЕЕЕ-754 из 2008., како интерпретирати НаН сигнални бит заправо није одређено.
    /// Већина платформи (посебно Кс00Кс и АРМ) одабрала је интерпретацију која је на крају била стандардизована 2008. године, али неке нису (нарочито МИПС).
    /// Као резултат, сви сигнални НаН-ови на Кс01Кс су тихи НаН-ови на Кс00Кс и обрнуто.
    ///
    /// Уместо да покушава да сачува унакрсну платформу за сигнализацију, ова имплементација фаворизује очување тачних битова.
    /// То значи да ће се сачувати сва корисна оптерећења кодирана у НаН-има, чак и ако се резултат ове методе пошаље мрежом са Кс00Кс машине на Кс01Кс.
    ///
    ///
    /// Ако резултатима ове методе манипулише само иста архитектура која их је произвела, онда не постоји забринутост за преносивост.
    ///
    /// Ако улаз није НаН, онда нема разлога за преносивост.
    ///
    /// Ако вам није стало до сигналности (врло вероватно), онда нема разлога за преносљивост.
    ///
    /// Имајте на уму да се ова функција разликује од Кс00Кс ливења, које покушава да сачува *нумеричку* вредност, а не вредност у битовима.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // БЕЗБЕДНОСТ: Кс00Кс је обичан стари тип података тако да га увек можемо трансформисати
        // Испоставило се да су сигурносни проблеми сНаН-а пренапухани!Ура!
        unsafe { mem::transmute(v) }
    }

    /// Вратите меморијски приказ овог броја са покретном зарезом као низ бајтова у биг-енд Кс00Кс редоследу бајтова.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Вратите меморијски приказ овог броја с покретном зарезом као низ бајтова у мало-енданском редоследу бајтова.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Вратите меморијски приказ овог броја с покретном зарезом као низ бајтова у изворном редоследу бајтова.
    ///
    /// Како се користи изворни циљ циљне платформе, преносни код уместо тога треба да користи Кс01Кс или Кс00Кс, према потреби.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Вратите меморијски приказ овог броја с покретном зарезом као низ бајтова у изворном редоследу бајтова.
    ///
    ///
    /// [`to_ne_bytes`] треба дати предност овоме кад год је то могуће.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // БЕЗБЕДНОСТ: Кс00Кс је обичан стари тип података тако да га увек можемо трансформисати
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Направите вредност са покретном тачком од њене репрезентације као бајт низа у великом ендиан-у.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Направите вредност са покретном тачком од њене репрезентације као бајт низа у малом ендиану.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Направите вредност са покретном тачком од њене репрезентације као бајт низа у изворном ендиан-у.
    ///
    /// Како се користи изворни ендијанс циљне платформе, преносиви код вероватно жели да користи Кс01Кс или Кс00Кс, према потреби.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Враћа поредак између себе и других вредности.
    /// За разлику од стандардног делимичног поређења између бројева са покретном зарезом, ово поређење увек даје редослед у складу са предикатом тоталОрдер како је дефинисано у ИЕЕЕ 754 (ревизија 2008) стандарда са помичном тачком.
    /// Вредности су поредане следећим редоследом:
    /// - Негативни тихи НаН
    /// - Негативна сигнализација НаН
    /// - Негативна бесконачност
    /// - Негативни бројеви
    /// - Негативни субнормални бројеви
    /// - Негативна нула
    /// - Позитивна нула
    /// - Позитивни субнормални бројеви
    /// - Позитивни бројеви
    /// - Позитивна бесконачност
    /// - Позитивна сигнализација НаН
    /// - Позитиван тихи НаН
    ///
    /// Имајте на уму да се ова функција не слаже увек са Кс01Кс и Кс02Кс имплементацијама Кс00Кс.Конкретно, негативну и позитивну нулу сматрају једнаким, док Кс03Кс не.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // У случају негатива, преокрените све битове, осим знака, да бисте постигли сличан изглед као комплементарне целине двоје
        //
        // Зашто ово ради?ИЕЕЕ 754 пловци састоје се од три поља:
        // Знаковни бит, експонент и мантиса.Скуп експонентних и мантисиних поља у целини има својство да је њихов битни редослед једнак нумеричкој величини где је величина дефинисана.
        // Величина обично није дефинисана на вредностима НаН, али ИЕЕЕ 754 тоталОрдер дефинише вредности НаН такође да следе битни редослед.То доводи до редоследа објашњеног у коментару на документ.
        // Међутим, приказ величине је исти за негативне и позитивне бројеве-само се знаковни бит разликује.
        // Да бисмо лако упоредили пловке као потписане целе бројеве, морамо преокренути битове експонента и мантиссе у случају негативних бројева.
        // Бројеве ефикасно претварамо у Кс00Кс облик.
        //
        // Да бисмо извршили окретање, конструишемо маску и КСОР против ње.
        // Без грана израчунавамо Кс00Кс маску на основу негативно потписаних вредности: померање десног знака продужава цели број, па Кс01Кс маску претварамо у знаковне битове, а затим претварамо у непотписане да бисмо потиснули још један нулти бит.
        //
        // На позитивним вредностима, маска је нула, тако да је не-оп.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Ограничите вредност на одређени интервал, осим ако није НаН.
    ///
    /// Приказује Кс02Кс ако је Кс03Кс већи од Кс01Кс и Кс04Кс ако је Кс05Кс мањи од Кс00Кс.
    /// У супротном ово враћа Кс00Кс.
    ///
    /// Имајте на уму да ова функција враћа НаН ако је и почетна вредност била НаН.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс, Кс01Кс НаН или Кс02Кс НаН.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}