//! Примена СипХасх-а.

#![allow(deprecated)] // типови у овом модулу су застарели

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Примена СипХасх-а 1-3.
///
/// Ово је тренутно задата функција хеширања коју користи стандардна библиотека (нпр. Кс00Кс је користи подразумевано).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Примена СипХасх-а 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Примена СипХасх-а 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// СипХасх је функција хеширања за општу намену: ради добром брзином (конкурентна Спооки-у и Цити-у) и омогућава јако Кс00Кс хеширање.
///
/// Ово вам омогућава да кључете своје хеш табеле из јаког РНГ-а, као што је Кс00Кс.
///
/// Иако се сматра да је алгоритам СипХасх генерално јак, није намењен за криптографске сврхе.
/// Као таква, сва криптографска употреба ове примене је Кс00Кс.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // колико бајтова смо обрадили
    state: State,  // хасх Стате
    tail: u64,     // непрерађени бајтови ле
    ntail: usize,  // колико бајтова у репу је валидно
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, Кс00Кс и Кс02Кс, Кс03Кс приказују се у паровима у алгоритму, а симд имплементације СипХасх-а користиће З0вецторс0З од Кс04Кс и Кс01Кс.
    //
    // Постављајући их овим редоследом у структури, преводилац може сам да покупи само неколико симд оптимизација.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Учитава цео број жељеног типа из бајт тока, ЛЕ редоследом.
/// Користи Кс00Кс да омогући компајлеру да генерише најефикаснији начин за учитавање са могуће неусклађене адресе.
///
///
/// Небезбедно јер: непроверено индексирање на Кс00Кс
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Учитава Кс00Кс користећи до 7 бајтова бајтног пресека.
/// Изгледа неспретно, али сви позиви Кс01Кс који се јављају (преко Кс02Кс) имају фиксне величине и избегавају позивање Кс00Кс, што је добро за брзину.
///
///
/// Небезбедно јер: непроверено индексирање на почетку..старт + лен
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // индекс тренутног бајта (из ЛСБ-а) на излазу Кс00Кс
    let mut out = 0;
    if i + 3 < len {
        // БЕЗБЕДНОСТ: Кс01Кс не може бити већи од Кс00Кс, а позивалац мора да гарантује
        // да је индекс старт..старт + лен у границама.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // БЕЗБЕДНОСТ: исто као горе.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // БЕЗБЕДНОСТ: исто као горе.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Ствара нови Кс00Кс са два почетна тастера постављена на 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Ствара Кс00Кс који се откључава са испоручених тастера.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Ствара нови Кс00Кс са два почетна тастера постављена на 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Ствара Кс00Кс који се откључава са испоручених тастера.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: нису дефинисане методе целобројних хеширања (`врите_у *`, Кс00Кс)
    // за овај тип.
    // Могли бисмо их додати, копирати имплементацију Кс04Кс у Кс01Кс и додати методе Кс05Кс у Кс02Кс, Кс03Кс и Кс00Кс.
    //
    // Ово би у великој мери убрзало целобројно распршивање тих хешира, по цену лаганог успоравања брзина компајлирања на неким референтним вредностима.
    // Погледајте Кс00Кс за детаље.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // БЕЗБЕДНОСТ: Гарантује се да Кс01Кс неће бити већи од Кс00Кс
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Пуферни реп је сада испран, обрадите нови улаз.
        let len = length - needed;
        let left = len & 0x7; // лен% 8

        let mut i = needed;
        while i < len - left {
            // БЕЗБЕДНОСТ: јер је Кс00Кс највећи умножак од 8 испод
            // `len`, и зато што Кс03Кс почиње са Кс04Кс где је Кс05Кс Кс01Кс, гарантује се да је Кс02Кс мањи или једнак Кс00Кс.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // БЕЗБЕДНОСТ: Кс01Кс је сада Кс00Кс,
        // па је Кс02Кс=Кс03Кс=Кс01Кс, што је по дефиницији једнако Кс00Кс.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Ствара Кс00Кс са два почетна тастера постављена на 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}