use crate::marker::Unsize;

/// З0Траит0З који указује да је ово показивач или омот за један, при чему се може одредити величина на показивачу.
///
/// Погледајте Кс00Кс и Кс01Кс за више детаља.
///
/// За уграђене типове показивача, показивачи на Кс00Кс ће се присилити на показиваче на Кс01Кс ако Кс02Кс претварањем из танког показивача у масни показивач.
///
/// За прилагођене типове, присила овде делује присиљавањем Кс00Кс на Кс01Кс под условом да постоји импл Кс02Кс.
/// Такав импл се може написати само ако Кс01Кс има само једно поље које није фантомдата које укључује Кс00Кс.
/// Ако је тип тог поља Кс00Кс, мора да постоји имплементација Кс01Кс.
/// Присиљавање ће деловати присиљавањем Кс01Кс поља у Кс02Кс и попуњавањем осталих поља из Кс03Кс да би се створио Кс00Кс.
/// Ово ће се ефикасно спустити на поље показивача и присилити на то.
///
/// Генерално, за паметне показиваче ћете применити Кс00Кс, са опционалним Кс01Кс везаним на сам Кс02Кс.
/// За типове омотача који директно уграђују Кс02Кс попут Кс03Кс и Кс01Кс, можете директно применити Кс00Кс.
///
/// Ово ће омогућити принуде типа као што је Кс00Кс.
///
/// [`Unsize`][unsize] користи се за обележавање типова који се могу присилити на ДСТ ако су иза показивача.Компајлер га аутоматски примењује.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut Т-> Кс00Кс У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut Т-> Кс00Кс
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut Т-> * мут У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut Т-> * цонст У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * цонст У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *мут Т->* мут У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *мут Т->* цонст У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *цонст Т->* цонст У
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ово се користи за заштиту објеката како би се проверило да ли се може примати тип пријемника методе.
///
/// Пример примене З0 Портраит0З:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut Т-> Кс00Кс У
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *цонст Т->* цонст У
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *мут Т->* мут У
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}