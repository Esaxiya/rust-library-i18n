/// Користи се за непроменљиве операције преусмеравања, попут Кс00Кс.
///
/// Поред тога што се користи за експлицитне операције преусмеравања са оператором Кс01Кс Кс02Кс у непроменљивим контекстима, преводилац их у многим околностима такође имплицитно користи.
/// Овај механизам се назива Кс00Кс.
/// У променљивом контексту користи се Кс00Кс.
///
/// Примена Кс01Кс за паметне показиваче чини приступ подацима иза њих погодним, због чега примењују Кс00Кс.
/// С друге стране, правила која се тичу Кс00Кс и Кс01Кс су конципирана посебно за смештај паметних показивача.
/// Због тога ** ** Дереф` треба примењивати само за паметне показиваче ** како би се избегла забуна.
///
/// Из сличних разлога **овај З0 Портраит0З никада не би требало да пропадне**.Неуспех током преусмеравања референци може бити крајње збуњујући када се имплицитно позива на Кс00Кс.
///
/// # Више о принуди Кс00Кс
///
/// Ако Кс02Кс имплементира Кс00Кс, а Кс03Кс је вредност типа Кс01Кс, тада:
///
/// * У непроменљивом контексту, Кс01Кс (где Кс02Кс није ни референца ни необрађени показивач) је еквивалентан Кс00Кс.
/// * Вредности типа Кс01Кс приморане су на вредности типа Кс00Кс
/// * `T` имплицитно имплементира све Кс01Кс методе типа Кс00Кс.
///
/// За више детаља посетите Кс03Кс, као и референтне одељке о Кс01Кс, Кс02Кс и Кс00Кс.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура са једним пољем којем је могуће преусмерити референцу на структуру.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Добијени тип након преусмеравања.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Одбацује вредност.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Користи се за променљиве операције преусмеравања, као у Кс00Кс.
///
/// Поред тога што се користи за експлицитне операције преусмеравања са оператором Кс01Кс Кс02Кс у променљивом контексту, у многим околностима преводилац их имплицитно користи.
/// Овај механизам се назива Кс00Кс.
/// У непроменљивом контексту користи се Кс00Кс.
///
/// Примена Кс01Кс за паметне показиваче чини мутирање података иза њих погодним, због чега примењују Кс00Кс.
/// С друге стране, правила која се тичу Кс00Кс и Кс01Кс су конципирана посебно за смештај паметних показивача.
/// Због тога би **`ДерефМут` требало применити само за паметне показиваче** како би се избегла забуна.
///
/// Из сличних разлога,**овај З0 Портраит0З никада не би требало да пропадне**.Неуспех током преусмеравања референци може бити крајње збуњујући када се имплицитно позива на Кс00Кс.
///
/// # Више о принуди Кс00Кс
///
/// Ако Кс02Кс имплементира Кс00Кс, а Кс03Кс је вредност типа Кс01Кс, тада:
///
/// * У променљивом контексту, Кс01Кс (где Кс02Кс није ни референца ни необрађени показивач) је еквивалентан Кс00Кс.
/// * Вредности типа Кс01Кс приморане су на вредности типа Кс00Кс
/// * `T` имплицитно имплементира све Кс01Кс методе типа Кс00Кс.
///
/// За више детаља посетите Кс03Кс, као и референтне одељке о Кс01Кс, Кс02Кс и Кс00Кс.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура са једним пољем која се може променити дереференцирањем структуре.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Променљиво преусмерава вредност.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Означава да се структура може користити као пријемник методе, без Кс00Кс функције.
///
/// Ово имплементирају стдлиб типови показивача попут Кс01Кс, Кс02Кс, Кс03Кс и Кс00Кс.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}