//! Оператери који се могу оверлоадабле.
//!
//! Имплементација ових З0траитс0З вам омогућава да преоптеретите одређене операторе.
//!
//! Неке од ових З0траитс0З увози З0прелуде0З, тако да су доступне у сваком програму З0Руст0З.Преоптерећени могу бити само оператори подржани З0траитс0З.
//! На пример, оператор сабирања Кс00Кс може се преоптеретити кроз Кс01Кс З0 Портраит0З, али с обзиром да оператор додељивања Кс02Кс нема подршку З0 Портраит0З, не постоји начин да се преоптерети његова семантика.
//! Поред тога, овај модул не пружа ниједан механизам за стварање нових оператора.
//! Ако су потребна безочна преоптерећења или прилагођени оператори, требало би да се окренете макросима или додатцима компајлера да бисте проширили синтаксу З0Руст0З.
//!
//! Имплементације оператора З0траитс0З не би требало да изненађују у њиховом контексту, имајући у виду њихова уобичајена значења и Кс00Кс.
//! На пример, када примењује Кс00Кс, операција треба да има неку сличност са множењем (и да дели очекивана својства попут асоцијативности).
//!
//! Имајте на уму да оператери Кс01Кс и Кс02Кс имају кратки спој, тј. Они свој други операнд процењују само ако он доприноси резултату.Будући да З0траитс0З ово понашање не могу применити, Кс00Кс и Кс03Кс нису подржани као оперативи који се могу пренијети.
//!
//! Многи оператори узимају своје операнде по вредности.У генеричком контексту који укључује уграђене типове, то обично није проблем.
//! Међутим, употреба ових оператора у генеричком коду захтева одређену пажњу ако се вредности морају поново користити, за разлику од допуштања операторима да их троше.Једна од могућности је повремена употреба Кс00Кс.
//! Друга опција је ослањање на укључене типове који пружају додатне имплементације оператора за референце.
//! На пример, за кориснички дефинисани тип Кс00Кс који би требало да подржава додавање, вероватно је добра идеја да и Кс01Кс и Кс02Кс имплементирају З0траитс0З Кс03Кс и Кс04Кс тако да генерички код може бити написан без непотребног клонирања.
//!
//!
//! # Examples
//!
//! Овај пример креира структуру Кс01Кс која имплементира Кс02Кс и Кс00Кс, а затим демонстрира сабирање и одузимање две `Тачке`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Погледајте примере примене у документацији за сваки З0 Портраит0З.
//!
//! Кс01Кс, Кс02Кс и Кс05Кс З0траитс0З су имплементирани по типовима који се могу позивати као функције.Имајте на уму да Кс06Кс узима Кс03Кс, Кс04Кс Кс07Кс и Кс08Кс Кс00Кс.
//! Они одговарају три врсте метода које се могу позвати на инстанци: позив-по-референци, позив-по-променљивој-референци и позив-по-вредности.
//! Најчешћа употреба ових З0траитс0З је деловање граница на функције вишег нивоа које узимају функције или затварања као аргументе.
//!
//! Узимање Кс00Кс као параметра:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Узимање Кс00Кс као параметра:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Узимање Кс00Кс као параметра:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` троши своје ухваћене променљиве, па се не може покренути више од једном
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Покушај поновног позива на Кс01Кс ће довести до грешке Кс02Кс за Кс00Кс
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` у овом тренутку се више не може позивати
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;