/// Верзија оператора позива која узима непроменљиви пријемник.
///
/// Примери Кс00Кс могу се позивати више пута без стања мутације.
///
/// *Овај З0 Портраит0З Кс01Кс не треба мешати са Кс02Кс Кс00Кс.*
///
/// `Fn` имплементира се аутоматски затварачима који узимају само непроменљиве референце на ухваћене променљиве или уопште не бележе ништа, као и Кс00Кс Кс01Кс (са неким упозорењима, погледајте њихову документацију за више детаља).
///
/// Поред тога, за било који тип Кс03Кс који примењује Кс00Кс, Кс02Кс такође примењује Кс01Кс.
///
/// Будући да су и Кс01Кс и Кс02Кс суперсретине Кс00Кс, било која инстанца Кс03Кс може се користити као параметар где се очекује Кс04Кс или Кс05Кс.
///
/// Користите Кс00Кс као везан када желите да прихватите параметар функцијског типа и требате га позивати више пута и без мутирајућих стања (нпр. Када га истовремено позивате).
/// Ако вам нису потребни тако строги захтеви, користите Кс00Кс или Кс01Кс као ограничења.
///
/// Погледајте Кс00Кс за неке додатне информације о овој теми.
///
/// Такође треба напоменути посебну синтаксу за Кс00Кс З0траитс0З (нпр
/// `Fn(usize, bool) -> усизе`).Они који су заинтересовани за техничке детаље могу се позвати на Кс00Кс.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Позивање затварања
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Коришћење Кс00Кс параметра
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // тако да се З0регек0З може ослонити на тај Кс00Кс
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Обавља операцију позива.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Верзија оператора позива која узима променљиви пријемник.
///
/// Примери Кс00Кс могу се позивати више пута и могу мутирати стање.
///
/// `FnMut` примењује се аутоматски затварачима који узимају променљиве референце на ухваћене променљиве, као и све типове који примењују Кс00Кс, нпр. Кс01Кс Кс02Кс (јер је Кс03Кс суперсраит Кс04Кс).
/// Поред тога, за било који тип Кс03Кс који примењује Кс00Кс, Кс02Кс такође примењује Кс01Кс.
///
/// Будући да је Кс02Кс суперсретит Кс00Кс, било која инстанца Кс03Кс се може користити тамо где се очекује Кс04Кс, а пошто је Кс05Кс подпортрет Кс01Кс, било која инстанца Кс06Кс се може користити тамо где се очекује Кс07Кс.
///
/// Користите Кс00Кс као везу када желите да прихватите параметар функцијског типа и требате га више пута позивати, а истовремено му дозволити да мутира стање.
/// Ако не желите да параметар мутира стање, користите Кс01Кс као везан;ако не морате да га зовете више пута, користите Кс00Кс.
///
/// Погледајте Кс00Кс за неке додатне информације о овој теми.
///
/// Такође треба напоменути посебну синтаксу за Кс00Кс З0траитс0З (нпр
/// `Fn(usize, bool) -> усизе`).Они који су заинтересовани за техничке детаље могу се позвати на Кс00Кс.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Позивање заменљивог хватања затварања
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Коришћење Кс00Кс параметра
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // тако да се З0регек0З може ослонити на тај Кс00Кс
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Обавља операцију позива.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Верзија оператора позива која узима прималац вредности.
///
/// Примери Кс01Кс се могу позивати, али се можда неће моћи позивати више пута.Због тога, ако је о типу познато само то што имплементира Кс00Кс, може се позвати само једном.
///
/// `FnOnce` имплементира се аутоматски затварачима који могу трошити ухваћене променљиве, као и сви типови који примењују Кс00Кс, нпр. Кс01Кс Кс02Кс (јер је Кс03Кс суперсраит Кс04Кс).
///
///
/// Будући да су и Кс01Кс и Кс02Кс подсетнице Кс00Кс, било која инстанца Кс03Кс или Кс04Кс може се користити тамо где се очекује Кс05Кс.
///
/// Користите Кс00Кс као везу када желите да прихватите параметар функцијског типа и ако га требате позвати само једном.
/// Ако параметар требате позивати више пута, користите Кс01Кс као везан;ако вам је такође потребан да не бисте мутирали стање, користите Кс00Кс.
///
/// Погледајте Кс00Кс за неке додатне информације о овој теми.
///
/// Такође треба напоменути посебну синтаксу за Кс00Кс З0траитс0З (нпр
/// `Fn(usize, bool) -> усизе`).Они који су заинтересовани за техничке детаље могу се позвати на Кс00Кс.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Коришћење Кс00Кс параметра
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` троши своје ухваћене променљиве, па се не може покренути више од једном.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Покушај поновног позива на Кс01Кс ће довести до грешке Кс02Кс за Кс00Кс.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` у овом тренутку се више не може позивати
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // тако да се З0регек0З може ослонити на тај Кс00Кс
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Враћени тип након коришћења оператора позива.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Обавља операцију позива.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}