/// З0 Портраит0З за прилагођавање понашања оператора Кс00Кс.
///
/// Тип који примењује Кс00Кс је онај који има канонски начин да га види у смислу дихотомије Кс01Кс.
/// Овај З0 Портраит0З омогућава и издвајање тих вредности успеха или неуспеха из постојеће инстанце и стварање нове инстанце из вредности успеха или неуспеха.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Тип ове вредности када се сматра успешном.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Тип ове вредности када се сматра неуспешним.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Примењује оператер Кс01Кс.Повратак Кс02Кс значи да би извршење требало да се настави нормално, а резултат Кс03Кс је вредност Кс00Кс.
    /// Повратак Кс01Кс значи да би извршење требало да З0бранцх0З изврши у најунутарњији затварајући Кс00Кс, или да се врати из функције.
    ///
    /// Ако се врати резултат Кс00Кс, вредност Кс01Кс ће бити Кс02Кс у типу повратка опсега који обухвата (који сам мора да примени Кс03Кс).
    ///
    /// Конкретно, враћа се вредност Кс00Кс, где је Кс01Кс тип повратка функције која обухвата.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Обмотајте вредност грешке да бисте конструисали састављени резултат.
    /// На пример, Кс00Кс и Кс01Кс су еквивалентни.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Обмотајте ОК вредност да бисте конструисали композитни резултат.
    /// На пример, Кс00Кс и Кс01Кс су еквивалентни.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}