use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Омотач око сировог не-нулл Кс00Кс који указује да је власник овог омотача референт.
/// Корисно за изградњу апстракција попут Кс01Кс, Кс02Кс, Кс03Кс и Кс00Кс.
///
/// За разлику од Кс01Кс, Кс02Кс се понаша као Кс03Кс да је био пример Кс00Кс.
/// Примењује Кс01Кс ако је Кс02Кс Кс00Кс.
/// Такође подразумева врсту снажног удруживања која гарантује инстанцу Кс00Кс:
/// референт показивача не би требало модификовати без јединствене путање до свог Уникуе-а.
///
/// Ако нисте сигурни да ли је тачно користити Кс01Кс у своје сврхе, размислите о употреби Кс00Кс, који има слабију семантику.
///
///
/// За разлику од Кс00Кс, показивач увек мора бити не-нулл, чак и ако показивач никада није дереференциран.
/// То је тако да енуми могу користити ову забрањену вредност као дискриминант-Кс01Кс има исту величину као Кс00Кс.
/// Међутим, показивач може и даље висјети ако није дереференциран.
///
/// За разлику од Кс01Кс, Кс02Кс је коваријантан у односу на Кс00Кс.
/// Ово би увек требало бити тачно за било који тип који испуњава јединствене псеудониме захтеве.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: овај маркер нема последица за одступање, али је неопходан
    // да дропцк схвати да логично поседујемо Кс00Кс.
    //
    // За детаље погледајте:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` показивачи су Кс00Кс ако је Кс01Кс Кс02Кс јер су подаци на које се позивају необележени.
/// Имајте на уму да овај непроменљиви инваријант није присиљен системом типова;апстракција која користи Кс00Кс мора да је примени.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` показивачи су Кс00Кс ако је Кс01Кс Кс02Кс јер су подаци на које се позивају необележени.
/// Имајте на уму да овај непроменљиви инваријант није присиљен системом типова;апстракција која користи Кс00Кс мора да је примени.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Ствара нови Кс00Кс који је висећи, али добро поравнат.
    ///
    /// Ово је корисно за иницијализацију типова који се лено додељују, као што то чини Кс00Кс.
    ///
    /// Имајте на уму да вредност показивача потенцијално може представљати важећи показивач на Кс00Кс, што значи да се не сме користити као вредност сентинела Кс01Кс.
    /// Типови који се лено додељују морају да прате иницијализацију на неки други начин.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗБЕДНОСТ: Кс00Кс враћа важећи, не нулл показивач.Тхе
        // Стога се поштују услови за позивање Кс00Кс.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Ствара нови Кс00Кс.
    ///
    /// # Safety
    ///
    /// `ptr` мора бити не-нулл.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс није нулл.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ствара нови Кс00Кс ако Кс01Кс није нулл.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗБЕДНОСТ: Показивач је већ проверен и није нулл.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Преузима основни показивач Кс00Кс.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Преусмеравање садржаја.
    ///
    /// Резултирајући животни век је везан за себе, тако да се ово понаша Кс00Кс да је заправо био примерак Т који се позајмљује.
    /// Ако је потребан дужи век трајања Кс01Кс, користите Кс00Кс.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за референцу.
        unsafe { &*self.as_ptr() }
    }

    /// Измењива дереференцирање садржаја.
    ///
    /// Резултирајући животни век је везан за себе, тако да се ово понаша Кс00Кс да је заправо био примерак Т који се позајмљује.
    /// Ако је потребан дужи век трајања Кс01Кс, користите Кс00Кс.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за променљиву референцу.
        unsafe { &mut *self.as_ptr() }
    }

    /// Емитује показивач другог типа.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕЗБЕДНОСТ: Кс00Кс ствара нову јединственост и потребе
        // задати показивач да није нулл.
        // Будући да преносимо селф као показивач, он не може бити нулл.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗБЕДНОСТ: Променљива референца не може бити ништавна
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}