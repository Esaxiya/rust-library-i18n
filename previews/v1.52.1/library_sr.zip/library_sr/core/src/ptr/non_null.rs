use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` али не-нула и коваријантна.
///
/// Ово је често исправно користити приликом изградње структура података користећи сирове показиваче, али је на крају опасније за употребу због његових додатних својстава.Ако нисте сигурни да ли бисте требали користити Кс01Кс, само користите Кс00Кс!
///
/// За разлику од Кс01Кс, показивач увек мора бити не-нулл, чак и ако показивач никада није дереференциран.То је тако да енуми могу користити ову забрањену вредност као дискриминант-Кс02Кс има исту величину као Кс00Кс.
/// Међутим, показивач може и даље висјети ако није дереференциран.
///
/// За разлику од Кс00Кс, Кс02Кс је изабран за коваријантну у односу на Кс01Кс.То омогућава употребу Кс03Кс приликом израде коваријантних типова, али уводи ризик од неразумности ако се користи у типу који заправо не би требао бити коваријантни.
/// (Супротан избор је направљен за Кс00Кс иако је технички неразумност могла да буде узрокована само позивањем небезбедних функција.)
///
/// Коваријанција је исправна за већину сигурних апстракција, као што су Кс00Кс, Кс01Кс, Кс02Кс, Кс03Кс и Кс04Кс.То је случај јер пружају јавни АПИ који следи уобичајена дељена КСОР променљива правила З0Руст0З.
///
/// Ако ваш тип не може сигурно бити коваријантан, морате осигурати да садржи неко додатно поље за пружање непроменљивости.Често ће ово поље бити Кс01Кс типа Кс02Кс или Кс00Кс.
///
/// Приметите да Кс02Кс има Кс03Кс инстанцу за Кс00Кс.Међутим, ово не мења чињеницу да је мутирање кроз (показивач изведен из а) заједничке референце недефинисано понашање, осим ако се мутација догоди унутар Кс01Кс.Исто важи и за стварање променљиве референце из заједничке референце.
///
/// Када користите овај примерак Кс01Кс без Кс00Кс, ваша је одговорност да обезбедите да се Кс02Кс никада не позове и да се Кс03Кс никада не користи за мутацију.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` показивачи нису Кс00Кс јер подаци на које се позивају могу бити отуђени.
// НБ, овај импл је непотребан, али би требало да пружи боље поруке о грешкама.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` показивачи нису Кс00Кс јер подаци на које се позивају могу бити отуђени.
// НБ, овај импл је непотребан, али би требало да пружи боље поруке о грешкама.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Ствара нови Кс00Кс који је висећи, али добро поравнат.
    ///
    /// Ово је корисно за иницијализацију типова који се лено додељују, као што то чини Кс00Кс.
    ///
    /// Имајте на уму да вредност показивача потенцијално може представљати важећи показивач на Кс00Кс, што значи да се не сме користити као вредност сентинела Кс01Кс.
    /// Типови који се лено додељују морају да прате иницијализацију на неки други начин.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗБЕДНОСТ: Кс00Кс враћа величину која није нула и која се затим излива
        // а * мут Т.
        // Стога Кс00Кс није ништаван и поштују се услови за позивање Кс01Кс.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Приказује дељене референце на вредност.За разлику од Кс00Кс, ово не захтева да вредност мора бити иницијализована.
    ///
    /// За променљиви примерак погледајте Кс00Кс.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити правилно поравнат.
    ///
    /// * То мора бити Кс01Кс у смислу дефинисаном у Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///
    ///   Конкретно, током трајања овог животног века, меморија на коју показује показивач не сме бити мутирана (осим унутар Кс00Кс).
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за референцу.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Приказује јединствене референце на вредност.За разлику од Кс00Кс, ово не захтева да вредност мора бити иницијализована.
    ///
    /// За заједнички примерак погледајте Кс00Кс.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити правилно поравнат.
    ///
    /// * То мора бити Кс01Кс у смислу дефинисаном у Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///
    ///   Конкретно, током овог животног века, меморији на коју показује показивач не сме се приступити (читати или писати) преко било ког другог показивача.
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за референцу.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Ствара нови Кс00Кс.
    ///
    /// # Safety
    ///
    /// `ptr` мора бити не-нулл.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс није нулл.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ствара нови Кс00Кс ако Кс01Кс није нулл.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗБЕДНОСТ: Показивач је већ означен и није нулл
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Обавља исту функционалност као Кс00Кс, осим што се враћа показивач Кс01Кс, за разлику од сировог Кс02Кс показивача.
    ///
    ///
    /// Погледајте документацију Кс00Кс за више детаља.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕЗБЕДНОСТ: Резултат Кс00Кс није нула јер Кс01Кс јесте.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Разложите (могуће широки) показивач на компоненте адресе и метаподатака.
    ///
    /// Показивач се касније може реконструисати са Кс00Кс.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Преузима основни показивач Кс00Кс.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Враћа заједничку референцу на вредност.Ако вредност може бити неиницијализована, уместо ње се мора користити Кс00Кс.
    ///
    /// За променљиви примерак погледајте Кс00Кс.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити правилно поравнат.
    ///
    /// * То мора бити Кс01Кс у смислу дефинисаном у Кс00Кс.
    ///
    /// * Показивач мора усмерити на иницијализовану инстанцу Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///
    ///   Конкретно, током трајања овог животног века, меморија на коју показује показивач не сме бити мутирана (осим унутар Кс00Кс).
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    /// (Део о иницијализацији још увек није у потпуности одлучен, али док није, једини сигуран приступ је осигурати да се они заиста иницијализују.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за референцу.
        unsafe { &*self.as_ptr() }
    }

    /// Враћа јединствену референцу на вредност.Ако вредност може бити неиницијализована, уместо ње се мора користити Кс00Кс.
    ///
    /// За заједнички примерак погледајте Кс00Кс.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити правилно поравнат.
    ///
    /// * То мора бити Кс01Кс у смислу дефинисаном у Кс00Кс.
    ///
    /// * Показивач мора усмерити на иницијализовану инстанцу Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///
    ///   Конкретно, током овог животног века, меморији на коју показује показивач не сме се приступити (читати или писати) преко било ког другог показивача.
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    /// (Део о иницијализацији још увек није у потпуности одлучен, али док није, једини сигуран приступ је осигурати да се они заиста иницијализују.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да Кс00Кс испуњава све
        // захтеви за променљиву референцу.
        unsafe { &mut *self.as_ptr() }
    }

    /// Емитује показивач другог типа.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕЗБЕДНОСТ: Кс00Кс је показивач Кс01Кс који нужно није нулл
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Ствара не-нулл сирови пресек од танког показивача и дужине.
    ///
    /// Аргумент Кс00Кс је број **елемената**, а не број бајтова.
    ///
    /// Ова функција је сигурна, али преусмеравање повратне вредности није сигурно.
    /// Погледајте документацију Кс00Кс за сигурносне захтеве за резање.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // креирајте показивач пресека када започињете показивачем на први елемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Имајте на уму да овај пример вештачки демонстрира употребу ове методе, али `лет слице=Кс00Кс
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕЗБЕДНОСТ: Кс00Кс је показивач Кс01Кс који нужно није нулл
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Приказује дужину не-нулл сировог кришка.
    ///
    /// Враћена вредност је број **елемената**, а не број бајтова.
    ///
    /// Ова функција је сигурна, чак и када не-нулл сирови пресек не може бити преусмерен у одрезак, јер показивач нема важећу адресу.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Приказује не-нулл показивач на бафер пресека.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕЗБЕДНОСТ: Знамо да Кс00Кс није нулл.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Враћа сирови показивач на бафер пресека.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Враћа заједничку референцу на део могуће неиницијализованих вредности.За разлику од Кс00Кс, ово не захтева да вредност мора бити иницијализована.
    ///
    /// За променљиви примерак погледајте Кс00Кс.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити Кс00Кс за читање за Кс01Кс много бајтова и мора бити правилно поравнан.То посебно значи:
    ///
    ///     * Читав опсег меморије овог пресека мора бити садржан у једном додељеном објекту!
    ///       Резови се никада не могу проширити на више додељених објеката.
    ///
    ///     * Показивач мора бити поравнат чак и за резове нулте дужине.
    ///     Један од разлога за то је што се оптимизације распореда набрајања могу ослонити на поравнање референци (укључујући резове било које дужине) и оне које нису нуле да би се разликовале од осталих података.
    ///
    ///     Помоћу Кс00Кс можете добити показивач који је употребљив као Кс01Кс за кришке нулте дужине.
    ///
    /// * Укупна величина Кс01Кс пресека не сме бити већа од Кс00Кс.
    ///   Погледајте сигурносну документацију за Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///   Конкретно, током трајања овог животног века, меморија на коју показује показивач не сме бити мутирана (осим унутар Кс00Кс).
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    ///
    /// Такође погледајте Кс00Кс.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Враћа јединствену референцу на део могуће неиницијализованих вредности.За разлику од Кс00Кс, ово не захтева да вредност мора бити иницијализована.
    ///
    /// За заједнички примерак погледајте Кс00Кс.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Када позивате овај метод, морате бити сигурни да је све следеће тачно:
    ///
    /// * Показивач мора бити Кс00Кс за читање и писање за Кс01Кс много бајтова и мора бити правилно поравнат.То посебно значи:
    ///
    ///     * Читав опсег меморије овог пресека мора бити садржан у једном додељеном објекту!
    ///       Резови се никада не могу проширити на више додељених објеката.
    ///
    ///     * Показивач мора бити поравнат чак и за резове нулте дужине.
    ///     Један од разлога за то је што се оптимизације распореда набрајања могу ослонити на поравнање референци (укључујући резове било које дужине) и оне које нису нуле да би се разликовале од осталих података.
    ///
    ///     Помоћу Кс00Кс можете добити показивач који је употребљив као Кс01Кс за кришке нулте дужине.
    ///
    /// * Укупна величина Кс01Кс пресека не сме бити већа од Кс00Кс.
    ///   Погледајте сигурносну документацију за Кс00Кс.
    ///
    /// * Морате применити Заслањајућа правила З0Руст0З, јер је враћени век трајања Кс00Кс произвољно изабран и не одражава нужно стварни век трајања података.
    ///   Конкретно, током овог животног века, меморији на коју показује показивач не сме се приступити (читати или писати) преко било ког другог показивача.
    ///
    /// Ово важи чак и ако се резултат ове методе не користи!
    ///
    /// Такође погледајте Кс00Кс.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ово је сигурно јер Кс00Кс важи за читање и писање за много бајтова Кс01Кс.
    /// // Имајте на уму да позивање Кс00Кс овде није дозвољено јер се садржај може неиницијализовати.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Враћа сирови показивач на елемент или подрезану, без провере граница.
    ///
    /// Позивање ове методе са индексом изван граница или када Кс00Кс није могуће преусмерити је *[недефинисано понашање]* чак и ако се резултујући показивач не користи.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕЗБЕДНОСТ: позивалац осигурава да Кс00Кс није могуће преусмерити и да је Кс01Кс у границама.
        // Као последица, резултујући показивач не може бити НУЛЛ.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕЗБЕДНОСТ: Јединствени показивач не може бити ништаван, па су услови за
        // new_unchecked() поштују се.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗБЕДНОСТ: Променљива референца не може бити ништавна.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕЗБЕДНОСТ: Референца не може бити ништавна, па су услови за
        // new_unchecked() поштују се.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}