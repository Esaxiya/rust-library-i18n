#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Пружа тип метаподатака показивача било ког упереног типа.
///
/// # Метаподаци показивача
///
/// Типови сирових показивача и референтни типови у З0Руст0З могу се сматрати израђеним из два дела:
/// показивач података који садржи меморијску адресу вредности и неке метаподатке.
///
/// За типове статичке величине (који примењују Кс01Кс З0траитс0З), као и за типове Кс02Кс, каже се да су показивачи " танки`: метаподаци су нулте величине, а њихов тип је Кс00Кс.
///
///
/// Каже се да су показивачи на Кс00Кс " широки`или " масни`, они имају метаподатке који нису нулте величине:
///
/// * За структуре чије је последње поље ДСТ, метаподаци су метаподаци за последње поље
/// * За тип Кс01Кс, метаподаци су дужина у бајтовима као Кс00Кс
/// * За типове кришки попут Кс01Кс, метаподаци су дужина у ставкама као Кс00Кс
/// * За З0 Портраит0З објекте попут Кс00Кс, метаподаци су Кс01Кс (нпр. Кс02Кс)
///
/// У З0футуре0З, језик З0Руст0З може добити нове врсте типова који имају различите метаподатке показивача.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Кс00Кс З0 Портраит0З
///
/// Поента овог З0 Портраит0З је његов придружени тип Кс00Кс, а то је Кс01Кс или Кс02Кс или Кс03Кс како је горе описано.
/// Аутоматски се примењује за сваки тип.
/// Може се претпоставити да се примењује у генеричком контексту, чак и без одговарајуће границе.
///
/// # Usage
///
/// Сирови показивачи могу се раставити на компоненте података и адресе метаподатака помоћу њихове Кс00Кс методе.
///
/// Алтернативно, само метаподаци се могу издвојити помоћу функције Кс00Кс.
/// Референца се може проследити на Кс00Кс и имплицитно изнудити.
///
/// Показивач Кс01Кс се може саставити из адресе и метаподатака са Кс02Кс или Кс00Кс.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Тип метаподатака у показивачима и референце на Кс00Кс.
    #[lang = "metadata_type"]
    // NOTE: Задржите З0 Портраит0З З0боундс0З у Кс00Кс
    //
    // у Кс00Кс синхронизовано са онима овде:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Показатељи на типове који имплементирају овај псеудоним З0 Портраит0З су " танки`.
///
/// То укључује статички типове `Величине` и типове Кс00Кс.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: немојте то стабилизовати пре него што З0 Портраит0З псеудоними буду стабилни у језику?
pub trait Thin = Pointee<Metadata = ()>;

/// Издвојите компоненту метаподатака показивача.
///
/// Вредности типа Кс01Кс, Кс02Кс или Кс03Кс могу се директно проследити овој функцији пошто се имплицитно присиљавају на Кс00Кс.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕЗБЕДНОСТ: Приступ вредности из Кс00Кс уније је сигуран јер је * цонст Т
    // и ПтрЦомпонентс<T>имају исте распореде меморије.
    // Само З0стд0З може дати ову гаранцију.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Формира Кс00Кс сирови показивач од адресе података и метаподатака.
///
/// Ова функција је сигурна, али враћени показивач није нужно сигуран за дереференцирање.
/// За кришке погледајте документацију Кс00Кс ради сигурносних захтева.
/// За З0 Портраит0З објекте, метаподаци морају доћи из показивача на исти основни избрисани тип.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕЗБЕДНОСТ: Приступ вредности из Кс00Кс уније је сигуран јер је * цонст Т
    // и ПтрЦомпонентс<T>имају исте распореде меморије.
    // Само З0стд0З може дати ову гаранцију.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Обавља исту функционалност као Кс00Кс, осим што се враћа сирови Кс01Кс показивач, за разлику од сировог Кс02Кс показивача.
///
///
/// Погледајте документацију Кс00Кс за више детаља.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕЗБЕДНОСТ: Приступ вредности из Кс00Кс уније је сигуран јер је * цонст Т
    // и ПтрЦомпонентс<T>имају исте распореде меморије.
    // Само З0стд0З може дати ову гаранцију.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ручни импл потребан да би се избегао везани Кс00Кс.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Потребан је ручни импл да би се избегао везани Кс00Кс.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метаподаци за тип објекта Кс00Кс З0 Портраит0З.
///
/// То је показивач на втабле (виртуелна табела позива) који представља све потребне информације за манипулисање конкретним типом смештеним у З0 Портраит0З објекту.
/// Втабле који садржи:
///
/// * величина величине
/// * поравнање типа
/// * показивач на тип Кс00Кс импл (може бити не-оп за обичне-старе податке)
/// * упућује на све методе за примену типа З0 Портраит0З
///
/// Имајте на уму да су прва три посебна јер су неопходна за додељивање, испуштање и ослобађање било ког објекта З0 Портраит0З.
///
/// Ову структуру је могуће именовати параметром типа који није Кс00Кс З0 Портраит0З објекат (на пример Кс01Кс), али не и добити значајну вредност те структуре.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Уобичајени префикс свих втаблес.Следе показивачи функција за методе З0 Портраит0З.
///
/// Приватни детаљи имплементације Кс00Кс итд.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Враћа величину типа придруженог овом втаблеу.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Враћа поравнање типа повезаног са овом втабле.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Враћа величину и поравнање заједно као Кс00Кс
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕЗБЕДНОСТ: компајлер је емитовао овај втабле за бетон типа З0Руст0З који
        // познато је да има важећи распоред.Исто образложење као и код Кс00Кс.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ручни импулси потребни да би се избегле границе Кс00Кс.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}