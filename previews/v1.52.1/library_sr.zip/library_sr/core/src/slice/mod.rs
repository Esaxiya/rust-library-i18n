// ignore-tidy-filelength

//! Управљање резовима и манипулација.
//!
//! За више детаља погледајте Кс00Кс.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Чиста примена З0руст0З мемцхр, преузето са З0руст0З-мемцхр
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ова функција је јавна само зато што не постоји други начин за јединствено тестирање гомиле.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Приказује број елемената у пресеку.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // БЕЗБЕДНОСТ: цонст звук јер трансмутирамо поље дужине у величину (која мора бити)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // БЕЗБЕДНОСТ: ово је сигурно јер Кс00Кс и Кс01Кс имају исти распоред.
            // Само Кс00Кс може дати ову гаранцију.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Замените са Кс00Кс када је то стабилно.
            // Од овог писања ово узрокује Кс00Кс грешку.
            //

            // БЕЗБЕДНОСТ: Приступ вредности из Кс00Кс уније је сигуран јер је * цонст Т
            // и ПтрЦомпонентс<T>имају исте распореде меморије.
            // Само З0стд0З може дати ову гаранцију.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Приказује Кс00Кс ако је пресек дужине 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Приказује први елемент пресека или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Враћа променљиви показивач на први елемент пресека или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Враћа први и све остале елементе реза или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Враћа први и све остале елементе реза или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Враћа последњи и све остале елементе реза или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Враћа последњи и све остале елементе реза или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Враћа последњи елемент пресека или Кс00Кс ако је празан.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Приказује променљиви показивач на последњу ставку у пресеку.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Враћа референцу на елемент или подрезану зависно од врсте индекса.
    ///
    /// - Ако му се да позиција, враћа референцу на елемент на тој позицији или Кс00Кс ако је ван граница.
    ///
    /// - Ако му је дат опсег, враћа подрезаницу која одговара том опсегу или Кс00Кс ако је ван граница.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Враћа променљиву референцу на елемент или подрезу у зависности од врсте индекса (погледајте Кс01Кс) или Кс00Кс ако је индекс ван граница.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Враћа референцу на елемент или подрезану, без провере граница.
    ///
    /// За сигурну алтернативу погледајте Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позивање ове методе са индексом изван граница је *[недефинисано понашање]* чак и ако се резултујућа референца не користи.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЕЗБЕДНОСТ: позивалац мора поштовати већину безбедносних захтева за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Враћа променљиву референцу на елемент или подрезану, без провере граница.
    ///
    /// За сигурну алтернативу погледајте Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позивање ове методе са индексом изван граница је *[недефинисано понашање]* чак и ако се резултујућа референца не користи.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЕЗБЕДНОСТ: позивалац мора поштовати безбедносне захтеве за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Враћа сирови показивач на бафер пресека.
    ///
    /// Позиватељ мора осигурати да пресек наџиви показивач који ова функција враћа, иначе ће на крају указати на смеће.
    ///
    /// Позивалац такође мора осигурати да меморија на коју показује показивач Кс00Кс никада не буде уписана (осим унутар Кс01Кс) користећи овај показивач или било који показивач изведен из њега.
    /// Ако требате мутирати садржај пресека, користите Кс00Кс.
    ///
    /// Измена контејнера на који се позива овај пресек може довести до прерасподеле његовог међуспремника, што би такође учинило неважећим све показиваче на њега.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Враћа несигурни променљиви показивач у бафер пресека.
    ///
    /// Позиватељ мора осигурати да пресек наџиви показивач који ова функција враћа, иначе ће на крају указати на смеће.
    ///
    /// Измена контејнера на који се позива овај пресек може довести до прерасподеле његовог међуспремника, што би такође учинило неважећим све показиваче на њега.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Враћа два необрађена показивача који обухватају пресек.
    ///
    /// Враћени опсег је полуотворен, што значи да крајњи показивач показује *један прошли* последњи елемент пресека.
    /// На овај начин, празан рез је представљен са два једнака показивача, а разлика између два показивача представља величину пресека.
    ///
    /// Погледајте Кс00Кс за упозорења о коришћењу ових показивача.Крајњи показивач захтева додатни опрез, јер не указује на важећи елемент у пресеку.
    ///
    /// Ова функција је корисна за интеракцију са страним интерфејсима који користе два показивача за упућивање на низ елемената у меморији, као што је то уобичајено у Ц ++.
    ///
    ///
    /// Такође може бити корисно проверити да ли се показивач на елемент односи на елемент овог пресека:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // БЕЗБЕДНОСТ: Овде је Кс00Кс сигуран, јер:
        //
        //   - Оба показивача су део истог објекта, јер се рачуна и показивање директно поред објекта.
        //
        //   - Величина пресека никада није већа од Кс00Кс бајтова, као што је овде наведено:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Не укључује се премотавање, јер се кришке не премотавају крај краја адресног простора.
        //
        // Погледајте документацију Кс00Кс.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Враћа два несигурна променљива показивача који се протежу на пресеку.
    ///
    /// Враћени опсег је полуотворен, што значи да крајњи показивач показује *један прошли* последњи елемент пресека.
    /// На овај начин, празан рез је представљен са два једнака показивача, а разлика између два показивача представља величину пресека.
    ///
    /// Погледајте Кс00Кс за упозорења о коришћењу ових показивача.
    /// Крајњи показивач захтева додатни опрез, јер не указује на важећи елемент у пресеку.
    ///
    /// Ова функција је корисна за интеракцију са страним интерфејсима који користе два показивача за упућивање на низ елемената у меморији, као што је то уобичајено у Ц ++.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // БЕЗБЕДНОСТ: Погледајте Кс00Кс горе како бисте сазнали зашто је Кс01Кс овде безбедан.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Замењује два елемента у пресеку.
    ///
    /// # Arguments
    ///
    /// * а, Индекс првог елемента
    /// * б, Индекс другог елемента
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако су Кс00Кс или Кс01Кс ван граница.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Не можете узети две променљиве позајмице од једног З0вецтор0З, па уместо тога користите сирове показиваче.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // БЕЗБЕДНОСТ: Кс00Кс и Кс01Кс су направљени од сигурних променљивих референци и референци
        // елементима у пресеку и због тога се гарантује да су валидни и поравнати.
        // Имајте на уму да је приступ елементима иза Кс00Кс и Кс01Кс проверен и да ће З0паниц0З бити изван граница.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Преокреће редослед елемената у пресеку, на месту.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // За врло мале типове сви појединци који читају у нормалном путу имају лоше резултате.
        // Можемо боље, с обзиром на ефикасан неуједначени Кс00Кс, учитавањем већег дела и преокретом регистра.
        //

        // У идеалном случају ЛЛВМ би то учинио за нас, јер боље од нас зна да ли су неусклађена читања ефикасна (с обзиром да се то мења између различитих верзија АРМ-а) и која би била најбоља величина дела.
        // Нажалост, од ЛЛВМ Кс00Кс Кс01Кс он само одмотава петљу, па то морамо сами да урадимо.
        // (Хипотеза: обрнуто је проблематично јер се странице могу различито поравнати-биће, када је дужина непарна-тако да нема начина да се емитују пре-и постлудији да би се користио потпуно поравнати СИМД у средини.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Користите својствени Кс00Кс за преокрет у8 у величини
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // БЕЗБЕДНОСТ: Овде треба проверити неколико ствари:
                //
                // - Имајте на уму да је Кс00Кс 4 или 8 због горе наведене провере цфг.Дакле, Кс01Кс је позитиван.
                // - Индексирање индексом Кс00Кс је у реду јер гаранција петље гарантира
                //   `i + chunk - 1 < ln / 2`
                //   <=> Кс00Кс.
                // - Индексирање индексом Кс00Кс је у реду:
                //   - `i + chunk > 0` је тривијално тачно.
                //   - Провера петље гарантује:
                //     `i + chunk - 1 < ln / 2`
                //     <=> Кс00Кс, стога одузимање не подлеже.
                // - Позиви Кс00Кс и Кс01Кс су у реду:
                //   - `pa` указује на индекс Кс02Кс где Кс03Кс (види горе) и Кс04Кс указују на индекс Кс01Кс, тако да су оба најмање Кс05Кс много бајтова удаљена од краја Кс00Кс.
                //
                //   - Било која иницијализована меморија је важећи Кс00Кс.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Користите ротацију за 16 за преокрет у16 у Кс00Кс
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // БЕЗБЕДНОСТ: Несврстани Кс01Кс се може прочитати из Кс02Кс ако је Кс00Кс
                // (и очигледно Кс00Кс), јер је сваки елемент 2 бајта и читамо 4.
                //
                // `i + chunk - 1 < ln / 2` # док услов
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Будући да је мања од дужине подељене са 2, онда мора бити у границама.
                //
                // То такође значи да се услов Кс00Кс увек поштује, осигуравајући да се показивач Кс01Кс може безбедно користити.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // БЕЗБЕДНОСТ: Кс00Кс је инфериоран у поређењу са половином дужине пресека
            // приступ Кс00Кс и Кс01Кс је сигуран (Кс02Кс почиње у 0 и неће ићи даље од Кс03Кс).
            // Добијени показивачи Кс00Кс и Кс01Кс су стога важећи и поравнати и могу се читати и писати на њих.
            //
            //
            unsafe {
                // Небезбедна замена да бисте избегли ограничења приликом сигурне замене.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Враћа итератор преко пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Враћа итератор који омогућава модификовање сваке вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Враћа итератор преко свих суседних Кс01Кс дужине Кс00Кс.
    /// Преклапање Кс00Кс.
    /// Ако је пресек краћи од Кс00Кс, итератор не враћа вредности.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ако је пресек краћи од Кс00Кс:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Комадићи су кришке и не преклапају се.Ако Кс01Кс не подели дужину пресека, тада последњи део неће имати дужину Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који враћа делове увек тачно Кс01Кс елемената и Кс02Кс за исти итератор, али почев од краја пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Комадићи су променљиве кришке и не преклапају се.Ако Кс01Кс не подели дужину пресека, тада последњи део неће имати дужину Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који враћа делове увек тачно Кс01Кс елемената и Кс02Кс за исти итератор, али почев од краја пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Комадићи су кришке и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    ///
    /// Због тога што сваки комад има тачно Кс01Кс елементе, компајлер често може да оптимизује резултујући код боље него у случају Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који такође враћа остатак као мањи део, и Кс01Кс за исти итератор, али почиње на крају пресека.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Комадићи су променљиве кришке и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    ///
    /// Због тога што сваки комад има тачно Кс01Кс елементе, компајлер често може да оптимизује резултујући код боље него у случају Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који такође враћа остатак као мањи део, и Кс01Кс за исти итератор, али почиње на крају пресека.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Дијели кришку на кришку низова елемената `Н`, под претпоставком да нема остатка.
    ///
    ///
    /// # Safety
    ///
    /// Ово се може назвати само када
    /// - Пресек се тачно дели на делове `Н` елемената (звани Кс00Кс.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // БЕЗБЕДНОСТ: Комади од 1 елемента никада немају остатак
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // БЕЗБЕДНОСТ: Дужина пресека Кс00Кс је вишекратник од 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ово би било неразумно:
    /// // нека комади: &[[_;5]]=Кс00Кс//Дужина пресека није вишеструка од 5 лет цхункс:&[[_;0]]=Кс01Кс//Комади нулте дужине никада нису дозвољени
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЕЗБЕДНОСТ: Наш предуслов је управо оно што је потребно да се ово назове
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЕЗБЕДНОСТ: Убацили смо комад Кс00Кс елемената у
        // делић Кс00Кс многих делова Кс01Кс елемената.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Раздељује пресек у пресек низа `Н`-елемената, почевши од почетка пресека, и остатак пресека дужине строго мање од Кс00Кс.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // БЕЗБЕДНОСТ: Већ смо се успаничили за нулу и то осигуравамо конструкцијом
        // да је дужина подреза вишеструка од Н.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Раздељује рез у део " поља Н-елемената`, почевши од краја пресека, и остатак у дужини која је строго мања од Кс00Кс.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // БЕЗБЕДНОСТ: Већ смо се успаничили за нулу и то осигуравамо конструкцијом
        // да је дужина подреза вишеструка од Н.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Делови су референце на низ и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    ///
    /// Овај метод је главни генерички еквивалент Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Дијели кришку на кришку низова елемената `Н`, под претпоставком да нема остатка.
    ///
    ///
    /// # Safety
    ///
    /// Ово се може назвати само када
    /// - Пресек се тачно дели на делове `Н` елемената (звани Кс00Кс.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // БЕЗБЕДНОСТ: Комади од 1 елемента никада немају остатак
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // БЕЗБЕДНОСТ: Дужина пресека Кс00Кс је вишекратник од 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ово би било неразумно:
    /// // нека комади: &[[_;5]]=Кс00Кс//Дужина пресека није вишеструка од 5 лет цхункс:&[[_;0]]=Кс01Кс//Комади нулте дужине никада нису дозвољени
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЕЗБЕДНОСТ: Наш предуслов је управо оно што је потребно да се ово назове
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЕЗБЕДНОСТ: Убацили смо комад Кс00Кс елемената у
        // делић Кс00Кс многих делова Кс01Кс елемената.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Раздељује пресек у пресек низа `Н`-елемената, почевши од почетка пресека, и остатак пресека дужине строго мање од Кс00Кс.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // БЕЗБЕДНОСТ: Већ смо се успаничили за нулу и то осигуравамо конструкцијом
        // да је дужина подреза вишеструка од Н.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Раздељује рез у део " поља Н-елемената`, почевши од краја пресека, и остатак у дужини која је строго мања од Кс00Кс.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // БЕЗБЕДНОСТ: Већ смо се успаничили за нулу и то осигуравамо конструкцијом
        // да је дужина подреза вишеструка од Н.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Враћа итератор преко Кс00Кс елемената пресека одједном, почевши од почетка пресека.
    ///
    /// Делови су променљиве референце низа и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    ///
    /// Овај метод је главни генерички еквивалент Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0. Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Враћа итератор који се преклапа са Кс00Кс од Кс01Кс елемената пресека, почевши од почетка пресека.
    ///
    ///
    /// Ово је цонст генерички еквивалент Кс00Кс.
    ///
    /// Ако је Кс01Кс већа од величине пресека, неће вратити Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    /// Ова провера ће се највероватније променити у грешку времена компајлирања пре него што се овај метод стабилизује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Даје итератор преко Кс00Кс елемената пресека одједном, почевши од краја пресека.
    ///
    /// Комадићи су кришке и не преклапају се.Ако Кс01Кс не подели дужину пресека, тада последњи део неће имати дужину Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који враћа делове увек тачно Кс01Кс елемената и Кс02Кс за исти итератор, али почев од почетка пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Даје итератор преко Кс00Кс елемената пресека одједном, почевши од краја пресека.
    ///
    /// Комадићи су променљиве кришке и не преклапају се.Ако Кс01Кс не подели дужину пресека, тада последњи део неће имати дужину Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који враћа делове увек тачно Кс01Кс елемената и Кс02Кс за исти итератор, али почев од почетка пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Даје итератор преко Кс00Кс елемената пресека одједном, почевши од краја пресека.
    ///
    /// Комадићи су кришке и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    /// Због тога што сваки комад има тачно Кс01Кс елементе, компајлер често може да оптимизује резултујући код боље него у случају Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који такође враћа остатак као мањи део, и Кс01Кс за исти итератор, али почев од почетка пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Даје итератор преко Кс00Кс елемената пресека одједном, почевши од краја пресека.
    ///
    /// Комадићи су променљиве кришке и не преклапају се.
    /// Ако Кс00Кс не подели дужину пресека, тада ће изоставити последњих до Кс01Кс елемената и моћи ће се преузети из функције Кс02Кс итератора.
    ///
    /// Због тога што сваки комад има тачно Кс01Кс елементе, компајлер често може да оптимизује резултујући код боље него у случају Кс00Кс.
    ///
    /// Погледајте Кс00Кс за варијанту овог итератора који такође враћа остатак као мањи део, и Кс01Кс за исти итератор, али почев од почетка пресека.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Враћа итератор преко пресјека који производи непреклапајуће покрете елемената користећи предикат да их одвоји.
    ///
    /// Предикат се позива на два елемента која следе сами за собом, што значи да се предикат позива на Кс00Кс и Кс01Кс, затим на Кс02Кс и Кс03Кс и тако даље.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Овом методом се могу издвојити разврстане подлицице:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Враћа итератор преко пресека који производи непреклапајуће променљиве покрете елемената који користе предикат да их одвоје.
    ///
    /// Предикат се позива на два елемента која следе сами за собом, што значи да се предикат позива на Кс00Кс и Кс01Кс, затим на Кс02Кс и Кс03Кс и тако даље.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Овом методом се могу издвојити разврстане подлицице:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Дели један одсечак на два у индексу.
    ///
    /// Прва ће садржати све индексе из Кс00Кс (искључујући сам индекс Кс01Кс), а друга ће садржати све индексе из Кс02Кс (изузимајући сам индекс Кс03Кс).
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // БЕЗБЕДНОСТ: Кс01Кс и Кс02Кс су унутар Кс00Кс, који
        // испуњава захтеве Кс00Кс.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Дели један променљиви део на два индекса.
    ///
    /// Прва ће садржати све индексе из Кс00Кс (искључујући сам индекс Кс01Кс), а друга ће садржати све индексе из Кс02Кс (изузимајући сам индекс Кс03Кс).
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // БЕЗБЕДНОСТ: Кс01Кс и Кс02Кс су унутар Кс00Кс, који
        // испуњава захтеве Кс00Кс.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Подијели један дио на два у индексу, без провјере граница.
    ///
    /// Прва ће садржати све индексе из Кс00Кс (искључујући сам индекс Кс01Кс), а друга ће садржати све индексе из Кс02Кс (изузимајући сам индекс Кс03Кс).
    ///
    ///
    /// За сигурну алтернативу погледајте Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позивање ове методе са индексом изван граница је *[недефинисано понашање]* чак и ако се резултујућа референца не користи.Позиватељ мора осигурати да Кс00Кс.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // БЕЗБЕДНОСТ: Позиватељ мора да провери да ли је Кс00Кс
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Подијели један промјењиви дио на два у индексу, без провјере граница.
    ///
    /// Прва ће садржати све индексе из Кс00Кс (искључујући сам индекс Кс01Кс), а друга ће садржати све индексе из Кс02Кс (изузимајући сам индекс Кс03Кс).
    ///
    ///
    /// За сигурну алтернативу погледајте Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позивање ове методе са индексом изван граница је *[недефинисано понашање]* чак и ако се резултујућа референца не користи.Позиватељ мора осигурати да Кс00Кс.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // БЕЗБЕДНОСТ: Позиватељ мора да провери да ли је Кс00Кс.
        //
        // `[ptr; mid]` и Кс00Кс се не преклапају, тако да је враћање променљиве референце у реду.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс.
    /// Подударни елемент није подударан.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ако се подудара први елемент, празан одсечак биће прва ставка коју врати итератор.
    /// Слично томе, ако се подудара последњи елемент у пресеку, празан пресек биће последња ставка коју је вратио итератор:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ако су два подударна елемента директно суседна, између њих ће бити празан рез:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Враћа итератор преко променљивих подлицица одвојених елементима који се подударају са Кс00Кс.
    /// Подударни елемент није подударан.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс.
    /// Подударни елемент налази се на крају претходне подреза као завршивач.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ако се подудара последњи елемент пресека, тај елемент ће се сматрати завршником претходног пресека.
    ///
    /// Тај ће пресек бити последња ставка коју је вратио итератор.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Враћа итератор преко променљивих подлицица одвојених елементима који се подударају са Кс00Кс.
    /// Подударни елемент садржан је у претходној подрези као завршивач.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс, почевши од краја пресека и радећи уназад.
    /// Подударни елемент није подударан.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Као и код Кс00Кс, ако се подудара први или последњи елемент, празан пресек биће прва (или последња) ставка коју је итератор вратио.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Враћа итератор преко променљивих потклица раздвојених елементима који се подударају са Кс00Кс, почевши од краја пресека и радећи уназад.
    /// Подударни елемент није подударан.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс, ограничен на враћање највише Кс01Кс ставки.
    /// Подударни елемент није подударан.
    ///
    /// Последњи враћени елемент, ако постоји, садржаће остатак пресека.
    ///
    /// # Examples
    ///
    /// Одштампајте пресек подељен једном бројевима који су дељиви са 3 (тј. Кс00Кс, Кс01Кс):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс, ограничен на враћање највише Кс01Кс ставки.
    /// Подударни елемент није подударан.
    ///
    /// Последњи враћени елемент, ако постоји, садржаће остатак пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс ограниченим на враћање највише Кс01Кс ставки.
    /// Ово почиње на крају пресека и делује уназад.
    /// Подударни елемент није подударан.
    ///
    /// Последњи враћени елемент, ако постоји, садржаће остатак пресека.
    ///
    /// # Examples
    ///
    /// Испишите исечак подељен једном, почевши од краја, бројевима дељивима са 3 (тј. Кс00Кс, Кс01Кс):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Враћа итератор преко подрезика одвојених елементима који се подударају са Кс00Кс ограниченим на враћање највише Кс01Кс ставки.
    /// Ово почиње на крају пресека и делује уназад.
    /// Подударни елемент није подударан.
    ///
    /// Последњи враћени елемент, ако постоји, садржаће остатак пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Приказује Кс00Кс ако пресек садржи елемент са датом вредношћу.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ако немате Кс00Кс, већ само Кс01Кс такав да је Кс02Кс (нпр
    /// `Стринг: Позајми<str>`), можете користити Кс00Кс:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // парче Кс00Кс
    /// assert!(v.iter().any(|e| e == "hello")); // претражујте са Кс00Кс
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Приказује Кс00Кс ако је Кс01Кс префикс пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Увек враћа Кс00Кс ако је Кс01Кс празан део:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Приказује Кс00Кс ако је Кс01Кс суфикс пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Увек враћа Кс00Кс ако је Кс01Кс празан део:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Враћа подрезану са уклоњеним префиксом.
    ///
    /// Ако пресек започиње са Кс01Кс, враћа подрезану након префикса, умотану у Кс00Кс.
    /// Ако је Кс00Кс празан, једноставно враћа оригинални пресек.
    ///
    /// Ако пресек не започне са Кс01Кс, враћа Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Овој функцији ће бити потребно поновно писање ако и када СлицеПаттерн постане софистициранији.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Враћа подрезану са уклоњеним суфиксом.
    ///
    /// Ако се пресек завршава са Кс01Кс, враћа подрезаницу пре суфикса, умотану у Кс00Кс.
    /// Ако је Кс00Кс празан, једноставно враћа оригинални пресек.
    ///
    /// Ако се пресек не завршава са Кс01Кс, враћа Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Овој функцији ће бити потребно поновно писање ако и када СлицеПаттерн постане софистициранији.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Бинарни претражи овај сортирани рез за дати елемент.
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.
    /// Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    ///
    /// Такође погледајте Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента.
    /// Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ако желите да уметнете ставку у сортирани З0вецтор0З, а да притом задржите редослед сортирања:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Бинарни претражује овај сортирани комад помоћу функције упоређивања.
    ///
    /// Функција упоређивања треба да имплементира редослед који је у складу са редоследом сортирања основног пресека, враћајући код налога који показује да ли је његов аргумент Кс00Кс, Кс01Кс или Кс02Кс жељени циљ.
    ///
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    /// Такође погледајте Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента.Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // БЕЗБЕДНОСТ: позив чине безбедним следеће инваријанте:
            // - `mid >= 0`
            // - `mid < size`: Кс00Кс је ограничен везаним за Кс01Кс.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Разлог зашто користимо Кс00Кс контролни ток, а не подударање, је тај што подударање преуређује операције поређења, што је осетљиво на перформансе.
            //
            // Ово је Кс01Кс асм за Кс00Кс: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Бинарни претражује овај сортирани комад помоћу функције екстракције кључа.
    ///
    /// Претпоставља да је пресек сортиран по кључу, на пример са Кс00Кс користећи исту функцију извлачења кључа.
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.
    /// Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    ///
    /// Такође погледајте Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента у парчету парова сортираних по њиховим другим елементима.
    /// Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // З0Линт0З Кс02Кс је дозвољен јер је Кс03Кс у З0црате0З Кс01Кс и као такав још не постоји приликом израде Кс00Кс.
    //
    // везе ка низводном З0црате0З: Кс00Кс.Будући да су примитиви документовани само у либстд Кс01Кс, то у пракси никада не доводи до прекинутих веза.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Сортира рез, али можда неће сачувати редослед једнаких елемената.
    ///
    /// Ова сорта је нестабилна (тј. Може преуредити једнаке елементе), на месту (тј. Не додељује) и *О*(*н*\* Кс00Кс најгори случај.
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на Кс00Кс од Орсона Петерса, који комбинује брзи просечни случај рандомизираног брзог сортирања са брзим најгорим случајем прекомерне сорте, док истовремено постиже линеарно време на резовима са одређеним обрасцима.
    /// Користи рандомизацију да би избегао изрођене случајеве, али са фиксним З0сеед0З да увек пружи детерминистичко понашање.
    ///
    /// Типично је брже од стабилног сортирања, осим у неколико посебних случајева, нпр. Када се пресек састоји од неколико спојених сортираних секвенци.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Сортира рез уз функцију упоређивања, али можда неће сачувати редослед једнаких елемената.
    ///
    /// Ова сорта је нестабилна (тј. Може преуредити једнаке елементе), на месту (тј. Не додељује) и *О*(*н*\* Кс00Кс најгори случај.
    ///
    /// Функција упоређивања мора дефинисати укупан редослед елемената у пресеку.Ако редослед није укупан, редослед елемената је неодређен.Поруџбина је укупна поруџбина ако јесте (за све Кс00Кс, Кс01Кс и Кс02Кс):
    ///
    /// * укупно и антисиметрично: тачно један од Кс00Кс, Кс01Кс или Кс02Кс је тачан, и
    /// * транзитивни, Кс02Кс и Кс03Кс подразумева Кс01Кс.Исто мора да важи и за Кс04Кс и за Кс00Кс.
    ///
    /// На пример, иако Кс02Кс не примењује Кс03Кс јер је Кс01Кс, можемо користити Кс04Кс као функцију сортирања када знамо да пресек не садржи Кс00Кс.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на Кс00Кс од Орсона Петерса, који комбинује брзи просечни случај рандомизираног брзог сортирања са брзим најгорим случајем прекомерне сорте, док истовремено постиже линеарно време на резовима са одређеним обрасцима.
    /// Користи рандомизацију да би избегао изрођене случајеве, али са фиксним З0сеед0З да увек пружи детерминистичко понашање.
    ///
    /// Типично је брже од стабилног сортирања, осим у неколико посебних случајева, нпр. Када се пресек састоји од неколико спојених сортираних секвенци.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обрнуто сортирање
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Сортира рез уз функцију извлачења кључа, али можда неће сачувати редослед једнаких елемената.
    ///
    /// Ова сорта је нестабилна (тј. Може преуређивати једнаке елементе), на месту (тј. Не додељује) и *О*(м\* * н *\* Кс00Кс најгори случај, где је кључна функција *О*(*м*).
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на Кс00Кс од Орсона Петерса, који комбинује брзи просечни случај рандомизираног брзог сортирања са брзим најгорим случајем прекомерне сорте, док истовремено постиже линеарно време на резовима са одређеним обрасцима.
    /// Користи рандомизацију да би избегао изрођене случајеве, али са фиксним З0сеед0З да увек пружи детерминистичко понашање.
    ///
    /// Због своје кључне стратегије позивања, Кс00Кс ће вероватно бити спорији од Кс01Кс у случајевима када је кључна функција скупа.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Преређајте рез тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Преређајте рез са функцијом упоређивања тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Преређајте пресек помоћу функције извлачења кључа тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Преређајте рез тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    ///
    /// Ово преуређивање има додатно својство да ће било која вредност на позицији Кс01Кс бити мања или једнака било којој вредности на позицији Кс00Кс.
    /// Поред тога, ово преуређивање је нестабилно (тј
    /// било који број једнаких елемената може завршити на положају Кс00Кс), уместо њега (тј
    /// не додељује), а *О*(*н*) најгори случај.
    /// Ова функција је/позната и као Кс00Кс у другим библиотекама.
    /// Враћа трострук од следећих вредности: сви елементи мањи од оног у датом индексу, вредност у датом индексу и сви елементи већи од оног у датом индексу.
    ///
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на делу брзог избора истог алгоритма за брзо сортирање који се користи за Кс00Кс.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// З0Паницс0З када је Кс00Кс, што значи да је увек З0паницс0З на празним кришкама.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Нађите медијану
    /// v.select_nth_unstable(2);
    ///
    /// // Једино нам је загарантовано да ће кришка бити једно од следећег, на основу начина сортирања по наведеном индексу.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Преређајте рез са функцијом упоређивања тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    ///
    /// Ово преуређивање има додатно својство да ће било која вредност на положају Кс00Кс бити мања или једнака било којој вредности на положају Кс01Кс помоћу функције упоређивања.
    /// Поред тога, ово преуређивање је нестабилно (тј. Било који број једнаких елемената може завршити на положају Кс00Кс), на месту (тј. Не додељује) и *О*(*н*) у најгорем случају.
    /// Ова функција је у другим библиотекама позната и као Кс00Кс.
    /// Враћа триплет следећих вредности: сви елементи мањи од оног у датом индексу, вредност датог индекса и сви елементи већи од оног датог индекса, користећи предвиђену функцију упоређивања.
    ///
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на делу брзог избора истог алгоритма за брзо сортирање који се користи за Кс00Кс.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// З0Паницс0З када је Кс00Кс, што значи да је увек З0паницс0З на празним кришкама.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Нађите медијану као да је пресек сортиран у опадајућем редоследу.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Једино нам је загарантовано да ће кришка бити једно од следећег, на основу начина сортирања по наведеном индексу.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Преређајте пресек помоћу функције извлачења кључа тако да елемент на Кс00Кс буде у крајњем сортираном положају.
    ///
    /// Ово преуређивање има додатно својство да ће било која вредност на положају Кс00Кс бити мања или једнака било којој вредности на положају Кс01Кс помоћу функције извлачења кључа.
    /// Поред тога, ово преуређивање је нестабилно (тј. Било који број једнаких елемената може завршити на положају Кс00Кс), на месту (тј. Не додељује) и *О*(*н*) у најгорем случају.
    /// Ова функција је у другим библиотекама позната и као Кс00Кс.
    /// Враћа трострук од следећих вредности: сви елементи мањи од оног у датом индексу, вредност у датом индексу и сви елементи већи од оног у датом индексу, користећи предвиђену функцију извлачења кључа.
    ///
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на делу брзог избора истог алгоритма за брзо сортирање који се користи за Кс00Кс.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// З0Паницс0З када је Кс00Кс, што значи да је увек З0паницс0З на празним кришкама.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Врати медијану као да је низ сортиран према апсолутној вредности.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Једино нам је загарантовано да ће кришка бити једно од следећег, на основу начина сортирања по наведеном индексу.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Премешта све узастопне поновљене елементе на крај пресека према примени Кс00Кс З0 Портраит0З.
    ///
    ///
    /// Приказује два одсечка.Прва не садржи узастопне поновљене елементе.
    /// Други садржи све дупликате без наведеног редоследа.
    ///
    /// Ако је кришка сортирана, прва враћена кришка не садржи дупликате.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Премешта све осим првог од узастопних елемената на крај пресека задовољавајући дату релацију једнакости.
    ///
    /// Приказује два одсечка.Прва не садржи узастопне поновљене елементе.
    /// Други садржи све дупликате без наведеног редоследа.
    ///
    /// Функцији Кс00Кс се прослеђују референце на два елемента из пресека и она мора да утврди да ли се елементи упоређују једнако.
    /// Елементи се прослеђују у супротном редоследу од њиховог редоследа у пресеку, па ако Кс02Кс врати Кс00Кс, Кс01Кс се премешта на крај пресека.
    ///
    ///
    /// Ако је кришка сортирана, прва враћена кришка не садржи дупликате.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Иако имамо променљиву референцу на Кс00Кс, не можемо извршити *произвољне* промене.Позиви Кс01Кс могу бити З0паниц0З, тако да морамо осигурати да је пресек стално у исправном стању.
        //
        // Начин на који то решавамо је коришћењем замена;вршимо итерацију над свим елементима, мењајући се у ходу тако да на крају елементи које желимо да задржимо буду напред, а они које желимо да одбацимо позади.
        // Затим можемо да поделимо кришку.
        // Ова операција је и даље Кс00Кс.
        //
        // Пример: Почињемо у овом стању, где Кс00Кс представља " следеће
        // прочитајте "и Кс00Кс представља" нект_врите`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Упоређујући Кс00Кс са сопственим [в-1], ово није дупликат, па замењујемо Кс01Кс и Кс02Кс (нема ефекта као р==в), а затим повећавамо и р и в, остављајући нам:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Упоређујући Кс00Кс са селф [в-1], ова вредност је дупликат, па повећавамо Кс01Кс, али све остало остављамо непромењеним:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Упоређујући Кс00Кс са сопственим [в-1], ово није дупликат, зато замените Кс01Кс и Кс02Кс и унапредите р и в:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Није дупликат, поновите:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Дупликат, Кс00Кс пресека.Сплит ат в.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // БЕЗБЕДНОСТ: услов Кс01Кс гарантује Кс02Кс и Кс00Кс
        // су мање од Кс01Кс, дакле налазе се унутар Кс00Кс.
        // `prev_ptr_write` показује на један елемент пре Кс00Кс, али Кс01Кс почиње на 1, тако да Кс02Кс никада није мањи од 0 и налази се унутар пресека.
        // Ово испуњава захтеве за преусмеравање Кс01Кс, Кс04Кс и Кс02Кс и за употребу Кс03Кс, Кс05Кс и Кс00Кс.
        //
        //
        // `next_write` такође се повећава највише једном по петљи, што значи да се ниједан елемент не прескаче када можда треба заменити.
        //
        // `ptr_read` и Кс02Кс никада не упућују на исти елемент.Ово је потребно да би Кс00Кс, Кс01Кс били сигурни.
        // Објашњење је једноставно да је Кс00Кс увек истинит, па самим тим и Кс01Кс.
        //
        //
        //
        //
        //
        unsafe {
            // Избегавајте провере граница помоћу сирових показивача.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Премешта све осим првог од узастопних елемената на крај пресека који се разрешава у исти кључ.
    ///
    ///
    /// Приказује два одсечка.Прва не садржи узастопне поновљене елементе.
    /// Други садржи све дупликате без наведеног редоследа.
    ///
    /// Ако је кришка сортирана, прва враћена кришка не садржи дупликате.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Ротира рез на месту тако да се први Кс00Кс елементи пресека померају до краја, док се последњи Кс01Кс елементи померају напред.
    /// Након позивања Кс00Кс, елемент који је претходно имао индекс Кс01Кс постаће први елемент у пресеку.
    ///
    /// # Panics
    ///
    /// Ова функција ће З0паниц0З ако је Кс00Кс већа од дужине пресека.Имајте на уму да Кс01Кс ради Кс02Кс З0паниц0З и да се не окреће.
    ///
    /// # Complexity
    ///
    /// Траје линеарно (за Кс00Кс време.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Ротирање подреза:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // БЕЗБЕДНОСТ: Опсег Кс01Кс је тривијалан
        // важи за читање и писање, како захтева Кс00Кс.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ротира рез на месту тако да се први Кс00Кс елементи пресека померају до краја, док се последњи Кс01Кс елементи померају напред.
    /// Након позивања Кс00Кс, елемент који је претходно имао индекс Кс01Кс постаће први елемент у пресеку.
    ///
    /// # Panics
    ///
    /// Ова функција ће З0паниц0З ако је Кс00Кс већа од дужине пресека.Имајте на уму да Кс01Кс ради Кс02Кс З0паниц0З и да се не окреће.
    ///
    /// # Complexity
    ///
    /// Траје линеарно (за Кс00Кс време.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Ротирање подреза:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // БЕЗБЕДНОСТ: Опсег Кс01Кс је тривијалан
        // важи за читање и писање, како захтева Кс00Кс.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Попуњава Кс01Кс елементима клонирањем Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Попуњава Кс00Кс елементима враћеним позивањем затварања више пута.
    ///
    /// Ова метода користи затварање за стварање нових вредности.Ако више волите Кс01Кс дату вредност, користите Кс00Кс.
    /// Ако желите да користите Кс00Кс З0 Портраит0З за генерисање вредности, можете да додате Кс01Кс као аргумент.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Копира елементе из Кс01Кс у Кс00Кс.
    ///
    /// Дужина Кс01Кс мора бити иста као и Кс00Кс.
    ///
    /// Ако Кс02Кс имплементира Кс01Кс, може бити ефикасније користити Кс00Кс.
    ///
    /// # Panics
    ///
    /// Ова функција ће радити З0паниц0З ако су два реза различите дужине.
    ///
    /// # Examples
    ///
    /// Клонирање два елемента из реза у други:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Будући да резови морају бити исте дужине, изворни пресек сечемо са четири елемента на два.
    /// // З0паниц0З ће ако то не урадимо.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// З0Руст0З намеће да може постојати само једна променљива референца без непроменљивих референци на одређени део података у одређеном опсегу.
    /// Због тога ће покушај употребе Кс00Кс на једном одсеку довести до неуспеха компајлирања:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Да бисмо то заобишли, можемо да користимо Кс00Кс за креирање два различита потреза од пресека:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Копира све елементе из Кс01Кс у Кс00Кс, користећи мемцпи.
    ///
    /// Дужина Кс01Кс мора бити иста као и Кс00Кс.
    ///
    /// Ако Кс02Кс не примењује Кс01Кс, користите Кс00Кс.
    ///
    /// # Panics
    ///
    /// Ова функција ће радити З0паниц0З ако су два реза различите дужине.
    ///
    /// # Examples
    ///
    /// Копирање два елемента из пресека у други:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Будући да резови морају бити исте дужине, изворни пресек сечемо са четири елемента на два.
    /// // З0паниц0З ће ако то не урадимо.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// З0Руст0З намеће да може постојати само једна променљива референца без непроменљивих референци на одређени део података у одређеном опсегу.
    /// Због тога ће покушај употребе Кс00Кс на једном одсеку довести до неуспеха компајлирања:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Да бисмо то заобишли, можемо да користимо Кс00Кс за креирање два различита потреза од пресека:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Стаза кода З0паниц0З стављена је у хладну функцију како не би надимала место позива.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // БЕЗБЕДНОСТ: Кс00Кс важи за Кс01Кс елементе по дефиницији, а Кс02Кс је био
        // проверено да имају исту дужину.
        // Пресеци се не могу преклапати јер су променљиве референце ексклузивне.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Копира елементе из једног дела пресека у други део себе, користећи мемвове.
    ///
    /// `src` је опсег унутар Кс00Кс из којег се може копирати.
    /// `dest` је почетни индекс опсега унутар Кс01Кс у који се копира, а који ће имати исту дужину као Кс00Кс.
    /// Та два опсега могу се преклапати.
    /// Крајеви два опсега морају бити мањи или једнаки Кс00Кс.
    ///
    /// # Panics
    ///
    /// Ова функција ће З0паниц0З ако било који опсег премашује крај пресека или ако је крај Кс00Кс пре почетка.
    ///
    ///
    /// # Examples
    ///
    /// Копирање четири бајта у рез:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // БЕЗБЕДНОСТ: услови за Кс00Кс су сви претходно проверени,
        // као и они за Кс00Кс.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Мења све елементе у Кс01Кс са онима у Кс00Кс.
    ///
    /// Дужина Кс01Кс мора бити иста као и Кс00Кс.
    ///
    /// # Panics
    ///
    /// Ова функција ће радити З0паниц0З ако су два реза различите дужине.
    ///
    /// # Example
    ///
    /// Замјена два елемента преко кришки:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// З0Руст0З намеће да постоји само једна променљива референца на одређени податак у одређеном опсегу.
    ///
    /// Због тога ће покушај употребе Кс00Кс на једном одсеку довести до неуспеха компајлирања:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Да бисмо то заобишли, можемо да користимо Кс00Кс за креирање два различита променљива подреза од пресека:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // БЕЗБЕДНОСТ: Кс00Кс важи за Кс01Кс елементе по дефиницији, а Кс02Кс је био
        // проверено да имају исту дужину.
        // Пресеци се не могу преклапати јер су променљиве референце ексклузивне.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Функција за израчунавање дужина средњег и задњег пресека за Кс00Кс.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Оно што ћемо урадити у вези са Кс00Кс је да откријемо који вишеброј У можемо ставити у најмањи број `Т`.
        //
        // И колико `Т` треба за сваки такав Кс00Кс.
        //
        // Размотримо на пример Т=у8 У=у16.Тада можемо ставити 1 У у 2 Тс.Једноставно.
        // Сада, размотрите на пример случај када сизе_оф: :<T>=16, величина_::::<U>24.</u>
        // Можемо да поставимо 2 Нас на место сваке 3 Тс у Кс00Кс пресеку.
        // Нешто компликованије.
        //
        // Формула за израчунавање овога је:
        //
        // Нас=Кс00Кс/величина_оф: : <U>Тс=Кс01Кс/величина_оф::</u><T>
        //
        // Проширено и поједностављено:
        //
        // Нас=величина_: :<T>/Кс01Кс Тс=величина_::::<U>Кс00Кс</u>
        //
        // Срећом, јер се све ово константно процењује ... перформансе овде нису важне!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // итеративни Стеинов алгоритам И даље бисмо требали направити овај Кс00Кс (и вратити се на рекурзивни алгоритам ако то учинимо), јер ослањање на ллвм за констелацију свега овога је ... па, чини ми се непријатно.
            //
            //

            // БЕЗБЕДНОСТ: Кс00Кс и Кс01Кс су означене као вредности које нису нула.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // уклонити све факторе 2 из б
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // БЕЗБЕДНОСТ: Проверено је да Кс00Кс није нула.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Наоружани овим знањем, можемо да пронађемо колико `У` можемо стати!
        let us_len = self.len() / ts * us;
        // И колико ће `Т-ова бити у пратећем пресеку!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Трансмутирајте рез у одрезак другог типа, осигуравајући да се одржи поравнање типова.
    ///
    /// Ова метода дели рез на три различита пресека: префикс, правилно поравнати средњи пресек новог типа и пресек суфикса.
    /// Метода може учинити средњи пресек највећом могућом дужином за дати тип и улазни пресек, али само перформансе вашег алгоритма треба да зависе од тога, а не његова исправност.
    ///
    /// Допуштено је да се сви улазни подаци врате као пресек или суфикс.
    ///
    /// Ова метода нема сврху када су или улазни елемент Кс00Кс или излазни елемент Кс01Кс нулте величине и вратиће оригинални пресек без ичега раздвајања.
    ///
    /// # Safety
    ///
    /// Овај метод је у суштини Кс00Кс у односу на елементе у враћеном средњем пресеку, тако да се овде примењују и сва уобичајена упозорења која се односе на Кс01Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Имајте на уму да ће се већина ове функције константно процењивати,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // посебно рукујте ЗСТ-овима, што је-немојте их уопште руковати.
            return (self, &[], &[]);
        }

        // Прво, пронађите у ком тренутку поделимо прву и другу кришку.
        // Лако са Кс00Кс.
        let ptr = self.as_ptr();
        // БЕЗБЕДНОСТ: Погледајте Кс00Кс методу за детаљан коментар о безбедности.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // БЕЗБЕДНОСТ: сада је Кс00Кс дефинитивно поравнат, тако да је Кс01Кс доле у реду,
            // пошто позивалац гарантује да можемо безбедно да пребацимо Кс00Кс у Кс01Кс.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Трансмутирајте рез у одрезак другог типа, осигуравајући да се одржи поравнање типова.
    ///
    /// Ова метода дели рез на три различита пресека: префикс, правилно поравнати средњи пресек новог типа и пресек суфикса.
    /// Метода може учинити средњи пресек највећом могућом дужином за дати тип и улазни пресек, али само перформансе вашег алгоритма треба да зависе од тога, а не његова исправност.
    ///
    /// Допуштено је да се сви улазни подаци врате као пресек или суфикс.
    ///
    /// Ова метода нема сврху када су или улазни елемент Кс00Кс или излазни елемент Кс01Кс нулте величине и вратиће оригинални пресек без ичега раздвајања.
    ///
    /// # Safety
    ///
    /// Овај метод је у суштини Кс00Кс у односу на елементе у враћеном средњем пресеку, тако да се овде примењују и сва уобичајена упозорења која се односе на Кс01Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Имајте на уму да ће се већина ове функције константно процењивати,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // посебно рукујте ЗСТ-овима, што је-немојте их уопште руковати.
            return (self, &mut [], &mut []);
        }

        // Прво, пронађите у ком тренутку поделимо прву и другу кришку.
        // Лако са Кс00Кс.
        let ptr = self.as_ptr();
        // БЕЗБЕДНОСТ: Овде се осигуравамо да користимо поравнате показиваче за У за
        // остатак методе.То се постиже преношењем показивача на&[Т] са поравнањем циљаним за У.
        // `crate::ptr::align_offset` позива се са правилно поравнатим и важећим показивачем Кс00Кс (потиче од референце на Кс01Кс) и са величином која је степен две (с обзиром да долази из отуђења за У), задовољавајући његова сигурносна ограничења.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // После овога не можемо поново да користимо Кс02Кс, што би онеспособило његов псеудоним Кс01Кс!БЕЗБЕДНОСТ: видети коментаре за Кс00Кс.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Проверава да ли су елементи овог пресека сортирани.
    ///
    /// Односно, за сваки елемент Кс03Кс и његов следећи елемент Кс00Кс мора да важи Кс01Кс.Ако рез резултира тачно нула или један елемент, враћа се Кс02Кс.
    ///
    /// Имајте на уму да ако је Кс02Кс само Кс00Кс, али не и Кс01Кс, горња дефиниција подразумева да ова функција враћа Кс03Кс ако било које две узастопне ставке нису упоредиве.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Проверава да ли су елементи овог пресека сортирани помоћу дате функције упоређивања.
    ///
    /// Уместо да користи Кс00Кс, ова функција користи задану функцију Кс01Кс за одређивање редоследа два елемента.
    /// Поред тога, еквивалентан је Кс00Кс;погледајте документацију за више информација.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Проверава да ли су елементи овог пресека сортирани помоћу дате функције извлачења кључа.
    ///
    /// Уместо да директно упоређује елементе реза, ова функција упоређује кључеве елемената, како је утврђено у Кс00Кс.
    /// Поред тога, еквивалентан је Кс00Кс;погледајте документацију за више информација.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Враћа индекс партиционе тачке према датом предикату (индекс првог елемента друге партиције).
    ///
    /// Претпоставља се да је пресек подељен према датом предикату.
    /// То значи да су сви елементи за које предикат враћа истину на почетку реза, а сви елементи за које предикат враћа фалсе су на крају.
    ///
    /// На пример, Кс00Кс је подељен под предикатом к% 2!=0 (сви непарни бројеви су на почетку, сви парни на крају).
    ///
    /// Ако овај пресек није партициониран, враћени резултат је неодређен и бесмислен, јер овај метод врши неку врсту бинарног претраживања.
    ///
    /// Такође погледајте Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // БЕЗБЕДНОСТ: Када Кс00Кс, `left <= mid < right`.
            // Због тога се Кс01Кс увек повећава, а Кс02Кс увек смањује, и изабрано је било које од њих.У оба случаја Кс03Кс је задовољан.Стога, ако је Кс04Кс у кораку, Кс00Кс је задовољан у следећем кораку.
            //
            // Дакле, све док је Кс00Кс задовољан и Кс01Кс, а ако је задовољан и овај случај Кс02Кс.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Морамо их изричито исећи на исту дужину
        // како би оптимизатору олакшао избацивање провере граница.
        // Али пошто се на то не може поуздати, имамо и изричиту специјализацију за Т: Цопи.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Ствара празан рез.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Ствара променљив празан рез.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Узорци у резовима, тренутно их користе само Кс01Кс и Кс00Кс.
/// На тачки З0футуре0З, надамо се да ћемо генерализовати Кс00Кс (који је у време писања ограничен на Кс01Кс) на кришке, а затим ће овај З0 Портраит0З бити замењен или укинут.
///
pub trait SlicePattern {
    /// Тип елемента резања на којем се подудара.
    type Item;

    /// Тренутно је потрошачима Кс00Кс потребан комад.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}