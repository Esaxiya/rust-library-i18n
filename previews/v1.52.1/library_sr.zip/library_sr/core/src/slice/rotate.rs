// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ротира опсег Кс00Кс тако да елемент на Кс01Кс постане први елемент.Еквивалентно, окреће опсег Кс02Кс елементе улево или Кс03Кс елементе удесно.
///
/// # Safety
///
/// Наведени опсег мора бити важећи за читање и писање.
///
/// # Algorithm
///
/// Алгоритам 1 се користи за мале вредности Кс01Кс или за велике Кс00Кс.
/// Елементи се померају у своје коначне положаје један по један, почевши од Кс01Кс и напредујући Кс02Кс корацима модуло Кс00Кс, тако да је потребан само један привремени.
/// На крају се враћамо у Кс00Кс.
/// Међутим, ако Кс00Кс није 1, горњи кораци су прескочили елементе.
/// На пример:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Срећом, број прескочених елемената између готових елемената увек је једнак, тако да можемо само надокнадити почетну позицију и направити више кругова (укупан број кругова је Кс00Кс.
///
/// Крајњи резултат је да се сви елементи финализују једном и само једном.
///
/// Алгоритам 2 се користи ако је Кс00Кс велик, али Кс01Кс је довољно мали да стане у међуспремник стека.
/// Елементи Кс01Кс се копирају у бафер, Кс00Кс се примењује на остале, а они на баферу се враћају у рупу на супротној страни одакле су потекли.
///
/// Алгоритми који се могу векторизовати надмашују горе наведено када Кс00Кс постане довољно велик.
/// Алгоритам 1 се може векторизовати сечењем и извођењем више рунди одједном, али има премало рунди док Кс00Кс не постане огроман, а најгори случај једне рунде је увек присутан.
/// Уместо тога, алгоритам 3 користи поновљено замењивање Кс00Кс елемената све док не остане мањи проблем ротирања.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// када се уместо Кс00Кс замена догоди са леве стране.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. доњи алгоритми могу пропасти ако се ови случајеви не провере
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритам 1 Микробенчмарци указују да су просечне перформансе за случајна померања боља све до приближно Кс00Кс, али најлошији учинак прекида чак око 16.
            // 24 је изабран као средина.
            // Ако је величина Кс00Кс већа од 4 `усизе`-а, овај алгоритам такође надмашује остале алгоритме.
            //
            //
            let x = unsafe { mid.sub(left) };
            // почетак првог круга
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` може се наћи пре руку израчунавањем Кс00Кс, али је брже направити једну петљу која израчунава гцд као споредни ефекат, а затим урадити остатак дела
            //
            //
            let mut gcd = right;
            // бенчмаркови откривају да је брже заменити привремене уместо да се једном привремено прочита једно копирање уназад, а затим на самом крају напише то привремено.
            // Ово је вероватно због чињенице да замена или замена привремених времена користи само једну меморијску адресу у петљи, уместо да треба да се управља са две.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // уместо да повећавамо Кс00Кс, а затим проверимо да ли је изван граница, проверавамо да ли ће Кс01Кс изаћи изван граница на следећем кораку.
                // Ово спречава умотавање показивача или Кс00Кс.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // крај првог круга
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // овај условни мора бити овде ако је Кс00Кс
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // завршите комад са више рунди
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` није тип нулте величине, па је у реду поделити са његовом величином.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритам 2 Овде Кс00Кс треба да осигура да је ово на одговарајући начин поравнато за Т
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритам 3 Постоји алтернативни начин замене који укључује проналажење где би била последња замена овог алгоритма и замену помоћу тог последњег дела уместо замене суседних делова као што то ради овај алгоритам, али овај начин је ипак бржи.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритам 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}