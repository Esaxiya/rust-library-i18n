//! Операције на АСЦИИ Кс00Кс.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Проверава да ли су сви бајтови у овом пресеку унутар АСЦИИ опсега.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Проверава да ли су два кришка АСЦИИ подударања која не разликују велика и мала слова.
    ///
    /// Исто као Кс00Кс, али без додељивања и копирања времена.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Претвара овај пресек у свој АСЦИИ еквивалент великим словима уместо њега.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову велику почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Претвара овај рез у његов АСЦИИ мали еквивалент на месту.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову малу почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Приказује Кс00Кс ако је било који бајт у речи Кс01Кс ненасции (>=128).
/// Снарфед из Кс00Кс, који ради нешто слично за валидацију Кс01Кс.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптимизовани АСЦИИ тест који ће користити операције коришћења времена уместо операција бајт-ат-тиме (када је то могуће).
///
/// Алгоритам који овде користимо је прилично једноставан.Ако је Кс00Кс прекратак, само проверимо сваки бајт и завршимо с тим.Иначе:
///
/// - Прочитајте прву реч са несравњеним оптерећењем.
/// - Поравнајте показивач, читајте наредне речи до краја поравнаним оптерећењима.
/// - Прочитајте последњи Кс00Кс из Кс01Кс са несравњеним оптерећењем.
///
/// Ако неко од ових оптерећења произведе нешто за шта Кс00Кс Кс01Кс даје истину, тада знамо да је одговор нетачан.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ако не бисмо добили ништа од примене речи одједном, вратите се скаларној петљи.
    //
    // Такође то радимо за архитектуре где Кс01Кс није довољно поравнање за Кс00Кс, јер је то чудан случај З0едге0З.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Увек читамо прву реч неусклађено, што значи да Кс00Кс јесте
    // 0, поново бисмо прочитали исту вредност за поравнато читање.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕЗБЕДНОСТ: Верификујемо Кс00Кс горе.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ово смо проверили горе, помало имплицитно.
    // Имајте на уму да је Кс01Кс Кс02Кс или Кс00Кс, оба су изричито потврђена горе.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕЗБЕДНОСТ: ворд_птр је (правилно поравнан) птр величине који користимо за читање
    // средњи комад кришке.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` је бајтни индекс Кс00Кс, који се користи за провере на крају петље.
    let mut byte_pos = offset_to_aligned;

    // Провера параноје око поравнања, јер ћемо направити гомилу неусклађених терета.
    // У пракси би ово требало да буде немогуће, изузев грешке у Кс00Кс.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Читајте наредне речи до последње поравнате речи, изузимајући последњу поравнату реч која ће се сама касније урадити у провери репа, како бисте били сигурни да је реп увек један Кс01Кс до додатних З0бранцх0З Кс00Кс.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Проверите да ли је читање у границама
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // И да су наше претпоставке о Кс00Кс тачне.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕЗБЕДНОСТ: Знамо да је Кс00Кс правилно поравнат (због
        // `алигн_оффсет`), и знамо да имамо довољно бајтова између Кс00Кс и краја
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕЗБЕДНОСТ: Знамо тај Кс00Кс, што значи
        // након овог Кс00Кс, Кс01Кс ће бити највише један крај.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Провера исправности да ли је заиста остао само један Кс00Кс.
    // Ово би требало да гарантује наше стање петље.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕЗБЕДНОСТ: Ово се ослања на Кс00Кс, који проверавамо на почетку.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}