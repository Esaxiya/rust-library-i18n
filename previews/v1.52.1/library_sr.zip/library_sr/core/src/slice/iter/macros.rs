//! Макрои које користе итератори пресека.

// Уграђивање ис_емпти и лен прави велику разлику у перформансама
macro_rules! is_empty {
    // Начин на који кодирамо дужину ЗСТ итератора, ово функционише и за ЗСТ и за не-ЗСТ.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Да бисмо се ослободили неких провера граница (погледајте Кс00Кс), израчунавамо дужину на помало неочекиван начин.
// (Тестирано `цодеген/слице-поситион-боундс-цхецк`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // понекад се користимо у небезбедном блоку

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Овај Кс00Кс користи Кс01Кс, јер зависимо од премотавања да бисмо представили дужину дугих ЗСТ итератора пресека.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Знамо да Кс00Кс може бити бољи од Кс01Кс који мора да ради потписано.
            // Постављањем одговарајућих заставица овде можемо то да кажемо ЛЛВМ-у, што му помаже да уклони провере ограничења.
            // БЕЗБЕДНОСТ: Према врсти инваријантне, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Такође рекавши ЛЛВМ-у да су показивачи одвојени тачним вишекратником величине типа, може оптимизовати Кс01Кс до Кс02Кс уместо Кс00Кс.
            //
            // БЕЗБЕДНОСТ: Према типу инваријанта, показивачи су поравнати тако да
            //         растојање између њих мора бити вишекратник величине поинта
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Заједничка дефиниција итератора Кс00Кс и Кс01Кс
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Враћа први елемент и помера почетак итератора напред за 1.
        // Значајно побољшава перформансе у поређењу са уграђеном функцијом.
        // Итератор не сме бити празан.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Враћа последњи елемент и помера крај итератора уназад за 1.
        // Значајно побољшава перформансе у поређењу са уграђеном функцијом.
        // Итератор не сме бити празан.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Смањује итератор када је Т ЗСТ, померајући крај итератора уназад за Кс00Кс.
        // `n` не сме прећи Кс00Кс.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Помоћна функција за креирање реза из итератора.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕЗБЕДНОСТ: итератор је креиран од пресека са показивачем
                // `self.ptr` и дужине Кс00Кс.
                // Ово гарантује да су испуњени сви предуслови за Кс00Кс.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Помоћна функција за померање почетка итератора напред према елементима Кс00Кс, враћајући стари почетак.
            //
            // Небезбедно јер помак не сме бити већи од Кс00Кс.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕЗБЕДНОСТ: позивалац гарантује да Кс01Кс не прелази Кс00Кс,
                    // тако да је овај нови показивач унутар Кс00Кс и загарантовано је да није нулл.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Помоћна функција за померање краја итератора уназад помоћу Кс00Кс елемената, враћајући нови крај.
            //
            // Небезбедно јер помак не сме бити већи од Кс00Кс.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕЗБЕДНОСТ: позивалац гарантује да Кс01Кс не прелази Кс00Кс,
                    // који гарантовано неће преплавити Кс00Кс.
                    // Такође, резултујући показивач је у границама Кс01Кс, који испуњава остале захтеве за Кс00Кс.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // може да се примени са кришкама, али ово избегава провере граница

                // БЕЗБЕДНОСТ: Позиви Кс00Кс су сигурни од почетног показивача пресека
                // мора бити не-нулл, а одсечци преко ЗСТ-а такође морају имати крајњи показивач који није нулл.
                // Позив на Кс00Кс је сигуран јер прво проверимо да ли је итератор празан.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Овај итератор је сада празан.
                    if mem::size_of::<T>() == 0 {
                        // Морамо то учинити на овај начин јер Кс00Кс можда никада неће бити 0, али Кс01Кс може бити (због умотавања).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕЗБЕДНОСТ: крај не може бити 0 ако Т није ЗСТ, јер птр није 0 и енд>=птр
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕЗБЕДНОСТ: У границама смо.Кс00Кс чини праву ствар чак и за ЗСТ-ове.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            // Такође, Кс00Кс избегава проверу граница.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕЗБЕДНОСТ: Гарантовано нам је да смо у границама инваријанта петље:
                        // када Кс00Кс, Кс01Кс враћа Кс02Кс и петља се прекида.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Замењујемо подразумевану имплементацију која користи Кс00Кс, јер ова једноставна имплементација генерише мање ЛЛВМ ИР и бржа је за компајлирање.
            // Такође, Кс00Кс избегава проверу граница.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕЗБЕДНОСТ: Кс01Кс мора бити нижи од Кс02Кс, јер почиње са Кс00Кс
                        // и само се смањује.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс у границама
                // основни рез, тако да Кс01Кс не може прелити Кс00Кс, а враћене референце гарантовано се односе на елемент пресека и на тај начин се гарантује да су валидне.
                //
                // Такође имајте на уму да позивалац такође гарантује да нас више никада неће позвати са истим индексом и да се неће позвати друге методе које ће приступити овој подрези, тако да је ваљано да враћена референца буде променљива у случају
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // може да се примени са кришкама, али ово избегава провере граница

                // БЕЗБЕДНОСТ: Кс00Кс позиви су сигурни, јер почетни показивач пресека мора бити не-нулл,
                // а резови преко ЗСТ-а такође морају имати не-нулл крајњи показивач.
                // Позив на Кс00Кс је сигуран јер прво проверимо да ли је итератор празан.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Овај итератор је сада празан.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕЗБЕДНОСТ: У границама смо.Кс00Кс чини праву ствар чак и за ЗСТ-ове.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}