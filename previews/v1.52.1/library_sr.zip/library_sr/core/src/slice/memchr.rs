// Оригинална примена преузета из З0руст0З-мемцхр.
// Цопиригхт 2015 Андрев Галлант, блусс и Ницолас Коцх

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Користите скраћивање.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Приказује Кс00Кс ако Кс01Кс садржи било који бајт нула.
///
/// Из *Маттерс Цомпутатионал*, Ј. Арндт:
///
/// " Идеја је да се од сваког бајта одузме по један, а затим се траже бајтови где се позајмљивање шири све до најзначајнијих
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Приказује први индекс који се подудара са бајтом Кс01Кс у Кс00Кс.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Брза путања за мале кришке
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Потражите вредност једног бајта читајући истовремено две Кс00Кс речи.
    //
    // Поделите Кс00Кс у три дела
    // - непоравнати почетни део, пре прве адресе поравнате у тексту
    // - тело, скенирај по 2 речи одједном
    // - последњи преостали део, величина <2 речи

    // претрага до поравнате границе
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // претражите тело текста
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЕЗБЕДНОСТ: предикат вхиле гарантује удаљеност од најмање 2 * усизе_битес
        // између офсета и краја реза.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // бреак ако постоји одговарајући бајт
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Пронађите бајт након тачке у којој се петља тела зауставила.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Приказује последњи индекс који се подудара са бајтом Кс01Кс у Кс00Кс.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Потражите вредност једног бајта читајући истовремено две Кс00Кс речи.
    //
    // Сплит Кс00Кс у три дела:
    // - несравњени реп, након последње адресе поравнате у тексту,
    // - тело, скенирано по две речи истовремено,
    // - први преостали бајт, величина <2 речи.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ово зовемо само да бисмо добили дужину префикса и суфикса.
        // У средини увек обрадимо два дела одједном.
        // БЕЗБЕДНОСТ: пребацивање Кс01Кс у Кс02Кс је сигурно, осим због разлика у величини којима се бави Кс00Кс.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Претражите тело текста, уверите се да не прелазимо мин_алигнед_оффсет.
    // офсет је увек поравнат, тако да је довољно само тестирање Кс00Кс и избегава могуће преливање.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЕЗБЕДНОСТ: офсет почиње са леном, Кс00Кс, све док је већи од
        // мин_алигнед_оффсет Кс00Кс преостала удаљеност је најмање 2 * цхунк_битес.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Прекини ако постоји одговарајући бајт.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Пронађите бајт пре тачке у којој се петља тела зауставила.
    text[..offset].iter().rposition(|elt| *elt == x)
}