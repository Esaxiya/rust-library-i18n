#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Верзија Кс00Кс на којој су засновани Уницоде делови метода Кс01Кс и Кс02Кс.
///
/// Нове верзије Уницоде-а се редовно објављују и накнадно се ажурирају сви методи у стандардној библиотеци, у зависности од Уницоде-а.
/// Стога се понашање неких Кс00Кс и Кс01Кс метода и вредност ове константе мењају током времена.
/// Ово се *не* сматра преломном променом.
///
/// Шема нумерисања верзија објашњена је у Кс00Кс.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// За употребу у либаллоц-у, који се не извози у либстд.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;