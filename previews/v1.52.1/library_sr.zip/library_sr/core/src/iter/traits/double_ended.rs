use crate::ops::{ControlFlow, Try};

/// Итератор у стању да избаци елементе са оба краја.
///
/// Нешто што имплементира Кс01Кс има једну додатну способност у односу на нешто што имплементира Кс00Кс: могућност да узме `Предмете` позади, као и сприједа.
///
///
/// Важно је напоменути да и напред и назад раде на истом опсегу и не укрштају се: итерација је готова кад се сретну у средини.
///
/// На сличан начин као протокол Кс01Кс, једном када Кс02Кс врати Кс03Кс са Кс00Кс, позивајући га поново, можда више никада неће вратити Кс04Кс.
/// [`next()`] и Кс00Кс су у ту сврху заменљиви.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Уклања и враћа елемент са краја итератора.
    ///
    /// Враћа Кс00Кс када више нема елемената.
    ///
    /// Документи Кс00Кс садрже више детаља.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Елементи добијени методама `ДоублеЕндедИтератор` могу се разликовати од оних добијених методама``Итератор`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Елементи Кс00Кс унапређују итератор са задње стране.
    ///
    /// `advance_back_by` је обрнута верзија Кс00Кс.Ова метода ће жељно прескочити Кс01Кс елементе почев од позади позивајући Кс02Кс до Кс03Кс пута док се не наиђе на Кс04Кс.
    ///
    /// `advance_back_by(n)` вратиће Кс00Кс ако итератор успешно напредује по елементима Кс01Кс, или Кс02Кс ако се наиђе на Кс03Кс, где је Кс04Кс број елемената помоћу којих је итератор унапређен пре него што понестане елемената (тј.
    /// дужина итератора).
    /// Имајте на уму да је Кс01Кс увек мањи од Кс00Кс.
    ///
    /// Позивање Кс01Кс не троши никакве елементе и увек враћа Кс00Кс.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // прескочен је само Кс00Кс
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Враћа `н`-ти елемент са краја итератора.
    ///
    /// Ово је у основи обрнута верзија Кс00Кс.
    /// Иако као и већина операција индексирања, бројање почиње од нуле, па Кс01Кс враћа прву вредност с краја, Кс00Кс другу и тако даље.
    ///
    ///
    /// Имајте на уму да ће се потрошити сви елементи између краја и враћеног елемента, укључујући враћени елемент.
    /// То такође значи да ће позивање Кс00Кс више пута на исти итератор вратити различите елементе.
    ///
    /// `nth_back()` вратиће Кс00Кс ако је Кс01Кс већа или једнака дужини итератора.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Позивање Кс00Кс више пута не премотава итератор:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Враћа се Кс00Кс ако има мање од Кс01Кс елемената:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ово је обрнута верзија Кс00Кс: узима елементе који почињу са задње стране итератора.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Због кратког споја, преостали елементи су и даље доступни преко итератора.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метода итератора која смањује елементе итератора на једну, коначну вредност, почев од задње стране.
    ///
    /// Ово је обрнута верзија Кс00Кс: узима елементе који почињу са задње стране итератора.
    ///
    /// `rfold()` узима два аргумента: почетну вредност и затварање са два аргумента: Кс00Кс и елемент.
    /// Затварање враћа вредност коју би акумулатор требао имати за следећу итерацију.
    ///
    /// Почетна вредност је вредност коју ће акумулатор имати на првом позиву.
    ///
    /// Након примене овог затварања на сваки елемент итератора, Кс00Кс враћа акумулатор.
    ///
    /// Ова операција се понекад назива Кс01Кс или Кс00Кс.
    ///
    /// Преклапање је корисно кад год имате колекцију нечега и желите из тога произвести једну вредност.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // збир свих елемената а
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Овај пример гради низ, почевши од почетне вредности и настављајући са сваким елементом од позади до предње стране:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Тражи елемент итератора са задње стране који задовољава предикат.
    ///
    /// `rfind()` узима затварач који враћа Кс01Кс или Кс00Кс.
    /// Примењује ово затварање на сваки елемент итератора, почевши од краја, а ако било који од њих врати Кс01Кс, тада Кс02Кс враћа Кс00Кс.
    /// Ако сви врате Кс01Кс, враћа Кс00Кс.
    ///
    /// `rfind()` је кратко спојен;другим речима, зауставиће обраду чим се затварач врати Кс00Кс.
    ///
    /// Будући да Кс00Кс узима референцу, а многи итератори прелазе преко референци, то доводи до могуће збуњујуће ситуације када је аргумент двострука референца.
    ///
    /// Овај ефекат можете видети у примерима испод са Кс00Кс.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Заустављање на првом Кс00Кс:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // и даље можемо да користимо Кс00Кс, јер има више елемената.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}