/// Конверзија са Кс00Кс.
///
/// Имплементацијом Кс00Кс за тип дефинишете како ће се креирати из итератора.
/// Ово је уобичајено за типове који описују неку врсту колекције.
///
/// [`FromIterator::from_iter()`] ретко се назива експлицитно и уместо тога користи се методом Кс00Кс.
///
/// Погледајте Кс00Кс документацију за више примера.
///
/// Такође видети: [`IntoIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Коришћење Кс01Кс за имплицитну употребу Кс00Кс:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Примена Кс00Кс за ваш тип:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Збирка узорака, то је само омот преко Вец-а<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Дајмо му неке методе како бисмо могли да га направимо и додамо му ствари.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и ми ћемо применити ФромИтератор
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Сада можемо направити нови итератор ...
/// let iter = (0..5).into_iter();
///
/// // ... и од тога направите МиЦоллецтион
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // сакупљајте и радове!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Ствара вредност од итератора.
    ///
    /// Погледајте Кс00Кс за више.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Конверзија у Кс00Кс.
///
/// Имплементацијом Кс00Кс за тип дефинишете како ће се претворити у итератор.
/// Ово је уобичајено за типове који описују неку врсту колекције.
///
/// Једна од предности примене Кс01Кс је та што ће ваш тип бити Кс00Кс.
///
///
/// Такође видети: [`FromIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Примена Кс00Кс за ваш тип:
///
/// ```
/// // Збирка узорака, то је само омот преко Вец-а<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Дајмо му неке методе како бисмо могли да га направимо и додамо му ствари.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и применићемо ИнтоИтератор
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Сада можемо направити нову колекцију ...
/// let mut c = MyCollection::new();
///
/// // ... додајте му неке ствари ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... а затим га претворите у Итератор:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Уобичајено је да се Кс00Кс користи као З0 Портраит0З З0боунд0З.Ово омогућава промену типа колекције уноса, све док је и даље итератор.
/// Додатне границе могу се одредити ограничавањем на
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Тип елемената који се понављају.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// У коју врсту итератора претварамо ово?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Ствара итератор од вредности.
    ///
    /// Погледајте Кс00Кс за више.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Проширите колекцију садржајем итератора.
///
/// Итератори производе низ вредности, а колекције се такође могу сматрати низом вредности.
/// Кс00Кс З0 Портраит0З премошћује овај јаз, омогућавајући вам да проширите колекцију тако што ћете укључити садржај тог итератора.
/// Када се колекција проширује већ постојећим кључем, тај унос се ажурира или, у случају колекција које дозвољавају више уноса са једнаким кључевима, тај унос се убацује.
///
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // Можете продужити низ помоћу неких знакова:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Имплементација Кс00Кс:
///
/// ```
/// // Збирка узорака, то је само омот преко Вец-а<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Дајмо му неке методе како бисмо могли да га направимо и додамо му ствари.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // пошто МиЦоллецтион има списак и32-а, имплементирамо Ектенд за Кс00Кс
/// impl Extend<i32> for MyCollection {
///
///     // Ово је мало једноставније са конкретним потписом типа: можемо позвати ектенс на било чему што се може претворити у Итератор који нам даје и32.
///     // Јер су нам потребни и32-и за стављање у МиЦоллецтион.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Имплементација је врло једноставна: прођите кроз итератор и Кс00Кс сваки елемент према себи.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // продужимо нашу колекцију са још три броја
/// c.extend(vec![1, 2, 3]);
///
/// // додали смо ове елементе на крају
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Проширује колекцију садржајем итератора.
    ///
    /// Како је ово једина обавезна метода за овај З0 Портраит0З, Кс00Кс документи садрже више детаља.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // Можете продужити низ помоћу неких знакова:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Проширује колекцију са тачно једним елементом.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Резервише капацитет у збирци за дати број додатних елемената.
    ///
    /// Подразумевана имплементација не ради ништа.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}