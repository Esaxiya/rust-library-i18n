use crate::iter::{FusedIterator, TrustedLen};

/// Ствара итератор који даје елемент тачно једном.
///
/// Ово се обично користи за прилагођавање једне вредности у Кс00Кс других врста итерација.
/// Можда имате итератор који покрива готово све, али потребан вам је додатни посебан случај.
/// Можда имате функцију која ради на итераторима, али требате обрадити само једну вредност.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // један је најусамљенији број
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само један, то је све што добијамо
/// assert_eq!(None, one.next());
/// ```
///
/// Повезивање са другим итератором.
/// Рецимо да желимо да прелиставамо сваку датотеку Кс00Кс директорија, али и конфигурациону датотеку,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // морамо претворити из итератора ДирЕнтри-с у итератор ПатхБуфс-а, па користимо мап
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сада, наш итератор само за нашу конфигурациону датотеку
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // повезати два итератора у један велики итератор
/// let files = dirs.chain(config);
///
/// // ово ће нам дати све датотеке у Кс01Кс као и Кс00Кс
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Итератор који даје елемент тачно једном.
///
/// Овај Кс00Кс је креиран помоћу функције Кс01Кс.Погледајте документацију за више информација.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}