use crate::iter::{FusedIterator, TrustedLen};

/// Ствара нови итератор који бескрајно понавља један елемент.
///
/// Функција Кс00Кс понавља једну вредност изнова и изнова.
///
/// Бесконачни итератори попут Кс01Кс често се користе са адаптерима попут Кс00Кс, како би их учинили коначним.
///
/// Ако тип елемента итератора који вам треба не примењује Кс00Кс или ако поновљени елемент не желите да задржите у меморији, уместо тога можете да користите функцију Кс01Кс.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // број четири 4евер:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // да, још увек четири
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Коначно са Кс00Кс:
///
/// ```
/// use std::iter;
///
/// // тај последњи пример био је превише четворке.Имајмо само четири четворке.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... и сада смо готови
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Итератор који бескрајно понавља елемент.
///
/// Овај Кс00Кс је креиран помоћу функције Кс01Кс.Погледајте документацију за више информација.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}