use crate::iter::{FusedIterator, TrustedLen};

/// Ствара итератор који лено генерише вредност тачно једном позивајући се на предвиђено затварање.
///
/// Ово се обично користи за прилагођавање једног генератора вредности у Кс00Кс других врста итерација.
/// Можда имате итератор који покрива готово све, али потребан вам је додатни посебан случај.
/// Можда имате функцију која ради на итераторима, али требате обрадити само једну вредност.
///
/// За разлику од Кс00Кс, ова функција ће лено генерирати вредност на захтев.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // један је најусамљенији број
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само један, то је све што добијамо
/// assert_eq!(None, one.next());
/// ```
///
/// Повезивање са другим итератором.
/// Рецимо да желимо да прелиставамо сваку датотеку Кс00Кс директорија, али и конфигурациону датотеку,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // морамо претворити из итератора ДирЕнтри-с у итератор ПатхБуфс-а, па користимо мап
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сада, наш итератор само за нашу конфигурациону датотеку
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // повезати два итератора у један велики итератор
/// let files = dirs.chain(config);
///
/// // ово ће нам дати све датотеке у Кс01Кс као и Кс00Кс
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Итератор који даје један елемент типа Кс01Кс применом обезбеђеног затварача Кс00Кс.
///
///
/// Овај Кс00Кс је креиран помоћу функције Кс01Кс.
/// Погледајте документацију за више информација.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}