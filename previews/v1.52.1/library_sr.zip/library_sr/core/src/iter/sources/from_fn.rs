use crate::fmt;

/// Ствара нови итератор где свака итерација позива предвиђено затварање Кс00Кс.
///
/// Ово омогућава стварање прилагођеног итератора са било којим понашањем, без употребе опширније синтаксе стварања наменског типа и примене Кс00Кс З0 Портраит0З за њега.
///
/// Имајте на уму да итератор Кс02Кс не претпоставља претпоставке о понашању затварања, па према томе конзервативно не примењује Кс01Кс нити замењује Кс03Кс у односу на задати Кс00Кс.
///
///
/// Затварање може користити снимке и његово окружење за праћење стања кроз итерације.У зависности од начина на који се користи итератор, ово може захтевати навођење кључне речи Кс00Кс на затварању.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Поново применимо бројач итератора из Кс00Кс:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Повећајте наш број.Због тога смо почели на нули.
///     count += 1;
///
///     // Проверите да ли смо завршили са бројањем или не.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Итератор у коме свака итерација позива предвиђено затварање Кс00Кс.
///
/// Овај Кс00Кс је креиран помоћу функције Кс01Кс.
/// Погледајте документацију за више информација.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}