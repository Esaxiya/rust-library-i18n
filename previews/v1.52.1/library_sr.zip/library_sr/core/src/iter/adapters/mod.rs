use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Овај З0 Портраит0З пружа транзитивни приступ изворној фази у цевоводу интегратора-адаптера под условима који
/// * извор итератора Кс01Кс сам имплементира Кс00Кс
/// * постоји делегирајућа примена овог З0 Портраит0З за сваки адаптер у цевоводу између извора и потрошача цевовода.
///
/// Када је извор власничка структура итератора (обично се назива Кс01Кс), онда ово може бити корисно за специјализоване имплементације Кс00Кс или за опоравак преосталих елемената након што је итератор делимично исцрпљен.
///
///
/// Имајте на уму да имплементације не морају нужно да омогуће приступ најунутарњем извору цевовода.Интермедијарни адаптер са статусом могао би нестрпљиво проценити део цевовода и изложити његову унутрашњу меморију као извор.
///
/// З0 Портраит0З није сигуран јер реализатори морају поштовати додатна сигурносна својства.
/// Погледајте Кс00Кс за детаље.
///
/// # Examples
///
/// Преузимање делимично потрошеног извора:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Фаза извора у цевоводу итератора.
    type Source: Iterator;

    /// Дохватите извор цевовода итератора.
    ///
    /// # Safety
    ///
    /// Имплементације морају вратити исту променљиву референцу за свог века, осим ако је не замени позивалац.
    /// Позивачи могу заменити референцу само када су зауставили итерацију и испустили цевовод итератора након издвајања извора.
    ///
    /// То значи да се адаптери итератора могу ослањати на извор који се неће променити током итерације, али се не могу ослонити на њега у својим Дроп имплементацијама.
    ///
    /// Примена ове методе значи да се адаптери одричу приватног приступа свом извору и могу се ослонити само на гаранције дане на основу типова пријемника метода.
    /// Недостатак ограниченог приступа такође захтева да адаптери морају подржавати јавни АПИ извора чак и када имају приступ његовим унутрашњим компонентама.
    ///
    /// Позиваоци са своје стране морају очекивати да извор буде у било ком стању које је у складу са његовим јавним АПИ-јем, јер адаптери који стоје између њега и извора имају исти приступ.
    /// Конкретно, адаптер је можда потрошио више елемената него што је неопходно.
    ///
    /// Општи циљ ових захтева је омогућити потрошачу цевовода употребу
    /// * све што остане у извору након што је итерација престала
    /// * меморија која је постала неискоришћена унапређивањем конзумирајућег итератора
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Адаптер за итератор који производи излаз све док основни итератор производи Кс00Кс вредности.
///
///
/// Ако се наиђе на грешку, итератор се зауставља и грешка се складишти.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Обрадите дати итератор као да је дао Кс01Кс уместо Кс00Кс.
/// Све грешке зауставиће унутрашњи итератор и укупни резултат ће бити грешка.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}