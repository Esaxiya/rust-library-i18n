//! Конверзија знакова.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Претвара Кс01Кс у Кс00Кс.
///
/// Имајте на уму да су сви [`цхар`] с важећи [`у32`] с и могу се пребацити на један са
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Међутим, обрнуто није тачно: нису сва важећа [`у32`] с важећа [`цхар`] с.
/// `from_u32()` вратиће Кс01Кс ако унос није важећа вредност за Кс00Кс.
///
/// За небезбедну верзију ове функције која игнорише ове провере, погледајте Кс00Кс.
///
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Враћа се Кс01Кс када унос није важећи Кс00Кс:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Претвара Кс01Кс у Кс00Кс, занемарујући валидност.
///
/// Имајте на уму да су сви [`цхар`] с важећи [`у32`] с и могу се пребацити на један са
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Међутим, обрнуто није тачно: нису сва важећа [`у32`] с важећа [`цхар`] с.
/// `from_u32_unchecked()` ће ово игнорисати и слепо пребацити на Кс00Кс, могуће стварајући неважећи.
///
///
/// # Safety
///
/// Ова функција није сигурна, јер може конструисати неважеће Кс00Кс вредности.
///
/// За сигурну верзију ове функције, погледајте функцију Кс00Кс.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс важећа вредност знака.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Цхар се излива на вредност кодне тачке, а затим се нула проширује на 64 бита.
        // Погледајте Кс00Кс
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Цхар се излива на вредност кодне тачке, а затим се проширује на нулу на 128 бита.
        // Погледајте Кс00Кс
        c as u128
    }
}

/// Мапира бајт у 0к00 ..=0кФФ у Кс00Кс чија кодна тачка има исту вредност, у У + 0000 ..=У + 00ФФ.
///
/// Уницоде је дизајниран тако да ефикасно декодира бајтове кодирањем знакова које ИАНА назива ИСО-8859-1.
/// Ово кодирање је компатибилно са АСЦИИ.
///
/// Имајте на уму да се ово разликује од Кс00Кс 8859-1 ака
/// ИСО 8859-1 (са једном цртицом мање), који оставља неке Кс00Кс, вредности бајтова које нису додељене ниједном знаку.
/// ИСО-8859-1 (онај ИАНА) додељује их контролним кодовима Кс00Кс и Кс01Кс.
///
/// Имајте на уму да се ово *такође* разликује од Виндовс-1252 ака
/// кодна страница 1252, што је суперсет Кс00Кс 8859-1 који интерпункцији и разним латиничним словима додељује неке празнине (не све!).
///
/// Да би се ствари додатно збуниле, Кс02Кс Кс00Кс, Кс01Кс и Кс03Кс су псеудоними за суперсет Виндовс-1252 који преостале празнине испуњава одговарајућим контролним кодовима Кс04Кс и Кс05Кс.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Грешка која се може вратити приликом рашчлањивања знака.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // БЕЗБЕДНОСТ: проверено да ли је то законска вредност Уницоде-а
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Тип грешке се враћа када конверзија из Кс00Кс у цхар не успе.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Претвара цифру у датом радику у Кс00Кс.
///
/// Овде се Кс01Кс понекад назива и Кс00Кс.
/// Радијус два означава бинарни број, радикс десет, децимални и радикс шеснаест, хексадецимални, дајући неке заједничке вредности.
///
/// Подржани су произвољни радикси.
///
/// `from_digit()` вратиће Кс00Кс ако улаз није цифра у датом радиксу.
///
/// # Panics
///
/// З0Паницс0З ако му је дат радикс већи од 36.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Децимални 11 је једноцифрена база 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Повратак Кс00Кс када унос није цифра:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Пролазећи велики радикс узрокујући З0паниц0З:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}