//! импл цхар Кс00Кс

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Највиша важећа тачка кода коју Кс00Кс може имати.
    ///
    /// Кс02Кс је Кс00Кс, што значи да је Кс01Кс, али само они у одређеном опсегу.
    /// `MAX` је највиша важећа тачка кода која је важећи Кс00Кс.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` Кс00Кс се користи у Уницодеу да представља грешку у декодирању.
    ///
    /// То се може догодити, на пример, када Кс00Кс даје лоше обликоване бајтове Кс01Кс.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Верзија Кс00Кс на којој су засновани Уницоде делови метода Кс01Кс и Кс02Кс.
    ///
    /// Нове верзије Уницоде-а се редовно објављују и накнадно се ажурирају сви методи у стандардној библиотеци, у зависности од Уницоде-а.
    /// Стога се понашање неких Кс00Кс и Кс01Кс метода и вредност ове константе мењају током времена.
    /// Ово се *не* сматра преломном променом.
    ///
    /// Шема нумерисања верзија објашњена је у Кс00Кс.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Ствара итератор преко Кс01Кс кодираних кодних тачака у Кс00Кс, враћајући неспарене сурогате као `Ерр`с.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Декодер са губицима може се добити заменом Кс00Кс резултата заменским знаком:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// Имајте на уму да су сви `цхар 'важећи [` у32`] с и могу се пребацити на један са
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Међутим, обрнуто није тачно: нису сви важећи [`у32`] с важећи`цхар`с.
    /// `from_u32()` вратиће Кс01Кс ако унос није важећа вредност за Кс00Кс.
    ///
    /// За небезбедну верзију ове функције која игнорише ове провере, погледајте Кс00Кс.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Враћа се Кс01Кс када унос није важећи Кс00Кс:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Претвара Кс01Кс у Кс00Кс, занемарујући валидност.
    ///
    /// Имајте на уму да су сви `цхар 'важећи [` у32`] с и могу се пребацити на један са
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Међутим, обрнуто није тачно: нису сви важећи [`у32`] с важећи`цхар`с.
    /// `from_u32_unchecked()` ће ово игнорисати и слепо пребацити на Кс00Кс, могуће стварајући неважећи.
    ///
    ///
    /// # Safety
    ///
    /// Ова функција није сигурна, јер може конструисати неважеће Кс00Кс вредности.
    ///
    /// За сигурну верзију ове функције, погледајте функцију Кс00Кс.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // БЕЗБЕДНОСТ: позивалац мора одржати уговор о безбедности.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Претвара цифру у датом радику у Кс00Кс.
    ///
    /// Овде се Кс01Кс понекад назива и Кс00Кс.
    /// Радијус два означава бинарни број, радикс десет, децимални и радикс шеснаест, хексадецимални, дајући неке заједничке вредности.
    ///
    /// Подржани су произвољни радикси.
    ///
    /// `from_digit()` вратиће Кс00Кс ако улаз није цифра у датом радиксу.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако му је дат радикс већи од 36.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Децимални 11 је једноцифрена база 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Повратак Кс00Кс када унос није цифра:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Пролазећи велики радикс узрокујући З0паниц0З:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Проверава да ли је Кс00Кс цифра у датом радиксу.
    ///
    /// Овде се Кс01Кс понекад назива и Кс00Кс.
    /// Радијус два означава бинарни број, радикс десет, децимални и радикс шеснаест, хексадецимални, дајући неке заједничке вредности.
    ///
    /// Подржани су произвољни радикси.
    ///
    /// У поређењу са Кс01Кс, ова функција препознаје само знакове Кс02Кс, Кс03Кс и Кс00Кс.
    ///
    /// 'Digit' је дефинисано да садржи само следеће знакове:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// За свеобухватније разумевање Кс01Кс, погледајте Кс00Кс.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако му је дат радикс већи од 36.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Пролазећи велики радикс узрокујући З0паниц0З:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Претвара Кс00Кс у цифру у датом радиксу.
    ///
    /// Овде се Кс01Кс понекад назива и Кс00Кс.
    /// Радијус два означава бинарни број, радикс десет, децимални и радикс шеснаест, хексадецимални, дајући неке заједничке вредности.
    ///
    /// Подржани су произвољни радикси.
    ///
    /// 'Digit' је дефинисано да садржи само следеће знакове:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Враћа Кс00Кс ако се Кс01Кс не односи на цифру у датом радиксу.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако му је дат радикс већи од 36.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Доношење нецифреног броја доводи до неуспеха:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Пролазећи велики радикс узрокујући З0паниц0З:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // код је овде подељен ради побољшања брзине извршавања у случајевима када је Кс00Кс константан и 10 или мањи
        //
        let val = if likely(radix <= 10) {
            // Ако није цифра, створиће се број већи од радик.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Враћа итератор који даје хексадецимални Уницоде излазак знака као `цхар`.
    ///
    /// Ово ће избећи знакове са синтаксом З0Руст0З облика Кс00Кс где је Кс01Кс хексадецимални приказ.
    ///
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ор-инг 1 осигурава да за ц==0 код израчунава да треба отиснути једну цифру и (што је исто) избегава (31, 32) подлив
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // индекс најзначајније хексадецималне цифре
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Проширена верзија Кс00Кс која опционо дозвољава избегавање проширених графемских тачака.
    /// То нам омогућава да боље форматирамо знакове попут неразмакнутих ознака када су на почетку низа.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Враћа итератор који даје дословни излазни код знака као `цхар`.
    ///
    /// Ово ће избећи знакове сличне применама Кс01Кс Кс02Кс или Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Враћа итератор који даје дословни излазни код знака као `цхар`.
    ///
    /// Подразумевано је одабрано са пристрасношћу према стварању литерала који су легални на разним језицима, укључујући З0Ц ++ 0З11 и сличне језике Ц-породице.
    /// Тачна правила су:
    ///
    /// * Картица је заштићена као Кс00Кс.
    /// * Повратак кочије се избегава као Кс00Кс.
    /// * Лине феед се избегава као Кс00Кс.
    /// * Појединачни наводник је избегнут као Кс00Кс.
    /// * Двоструки наводник је избегнут као Кс00Кс.
    /// * Повратна коса црта је избегнута као Кс00Кс.
    /// * Ниједан знак из опсега " АСЦИИ за штампу` Кс01Кс .. укључујући Кс00Кс није избегнут.
    /// * Сви остали знакови добијају хексадецимални Уницоде излазак;види Кс00Кс.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Приказује број бајтова који би овом Кс01Кс требао ако је кодиран у Кс00Кс.
    ///
    /// Тај број бајтова је увек између 1 и 4, укључујући.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Тип Кс01Кс гарантује да је његов садржај Кс00Кс, па можемо упоредити дужину која би трајала да је свака кодна тачка представљена као Кс02Кс у односу на сам Кс03Кс:
    ///
    ///
    /// ```
    /// // као знакови
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // оба се могу представити као три бајта
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // као Кс01Кс, ово двоје је кодирано у Кс00Кс
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // видимо да узимају укупно шест бајтова ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... баш као и Кс00Кс
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Приказује број 16-битних кодних јединица које би овом Кс01Кс биле потребне ако је кодиран у Кс00Кс.
    ///
    ///
    /// Погледајте документацију за Кс00Кс за више објашњења овог концепта.
    /// Ова функција је огледало, али за Кс01Кс уместо за Кс00Кс.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Кодира овај знак као Кс00Кс у обезбеђени бајтни бафер, а затим враћа подрезану бафера која садржи кодирани знак.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако бафер није довољно велик.
    /// Бафер дужине четири је довољно велик да кодира било који Кс00Кс.
    ///
    /// # Examples
    ///
    /// У оба ова примера, Кс00Кс треба два бајта за кодирање.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Премали бафер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // БЕЗБЕДНОСТ: Кс01Кс није сурогат, па је ово валидан Кс00Кс.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Кодира овај знак као Кс00Кс у обезбеђени Кс01Кс међуспремник, а затим враћа подрезану међуспремника који садржи кодирани знак.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако бафер није довољно велик.
    /// Бафер дужине 2 је довољно велик да кодира било који Кс00Кс.
    ///
    /// # Examples
    ///
    /// У оба ова примера, Кс00Кс треба два `у16` за кодирање.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Премали бафер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Приказује Кс00Кс ако овај Кс01Кс има својство Кс02Кс.
    ///
    /// `Alphabetic` је описан у поглављу 4 (Својства карактера) Кс01Кс и наведен у Кс02Кс Кс00Кс.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // љубав је много ствари, али није абецедно
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Приказује Кс00Кс ако овај Кс01Кс има својство Кс02Кс.
    ///
    /// `Lowercase` је описан у поглављу 4 (Својства карактера) Кс01Кс и наведен у Кс02Кс Кс00Кс.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Разне кинеске скрипте и интерпункција немају велика и мала слова, и тако:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Приказује Кс00Кс ако овај Кс01Кс има својство Кс02Кс.
    ///
    /// `Uppercase` је описан у поглављу 4 (Својства карактера) Кс01Кс и наведен у Кс02Кс Кс00Кс.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Разне кинеске скрипте и интерпункција немају велика и мала слова, и тако:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Приказује Кс00Кс ако овај Кс01Кс има својство Кс02Кс.
    ///
    /// `White_Space` је назначено у Кс01Кс Кс00Кс.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // простор који се не ломи
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Приказује Кс01Кс ако овај Кс02Кс задовољава или Кс03Кс или Кс00Кс.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Враћа Кс00Кс ако овај Кс01Кс има општу категорију за контролне кодове.
    ///
    /// Контролни кодови (кодне тачке са општом категоријом Кс03Кс) описани су у поглављу 4 (Својства карактера) Кс01Кс и наведени у Кс02Кс Кс00Кс.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // У + 009Ц, СТРИНГ ТЕРМИНАТОР
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Приказује Кс00Кс ако овај Кс01Кс има својство Кс02Кс.
    ///
    /// `Grapheme_Extend` је описан у Кс01Кс и наведен у Кс02Кс Кс00Кс.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Враћа Кс00Кс ако овај Кс01Кс има једну од општих категорија за бројеве.
    ///
    /// Опште категорије за бројеве (Кс04Кс за децималне цифре, Кс01Кс за словне нумеричке знакове и Кс02Кс за остале нумеричке знакове) наведене су у Кс03Кс Кс00Кс.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Враћа итератор који даје мапирање малих слова овог Кс00Кс као једно или више
    /// `char`s.
    ///
    /// Ако овај Кс01Кс нема мапирање малих слова, итератор даје исти Кс00Кс.
    ///
    /// Ако овај Кс02Кс има мапирање један према један малим словима дато од Кс03Кс Кс01Кс, итератор даје тај Кс00Кс.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ако овај Кс01Кс захтева посебна разматрања (нпр. Више `цхар`-ова), итератор даје`цхар`-ове дане од Кс00Кс.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ова операција врши безусловно мапирање без кројења.Односно, конверзија је независна од контекста и језика.
    ///
    /// У Кс00Кс, поглавље 4 (Својства карактера) говори о мапирању случајева уопште, а поглавље 3 Кс01Кс о задатом алгоритму за конверзију случајева.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Понекад је резултат више знакова:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Знакови који немају и велика и мала слова претварају се у себе.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Враћа итератор који даје пресликавање великих слова овог Кс00Кс као једно или више
    /// `char`s.
    ///
    /// Ако овај Кс01Кс нема пресликавања великих слова, итератор даје исти Кс00Кс.
    ///
    /// Ако овај Кс02Кс има појединачно велико пресликавање дато од Кс03Кс Кс01Кс, итератор даје тај Кс00Кс.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ако овај Кс01Кс захтева посебна разматрања (нпр. Више `цхар`-ова), итератор даје`цхар`-ове дане од Кс00Кс.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ова операција врши безусловно мапирање без кројења.Односно, конверзија је независна од контекста и језика.
    ///
    /// У Кс00Кс, поглавље 4 (Својства карактера) говори о мапирању случајева уопште, а поглавље 3 Кс01Кс о задатом алгоритму за конверзију случајева.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Понекад је резултат више знакова:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Знакови који немају и велика и мала слова претварају се у себе.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Напомена о локалном окружењу
    ///
    /// На турском, еквивалент Кс00Кс у латинском има пет облика уместо два:
    ///
    /// * 'Dotless': И/ı, понекад написано и
    /// * 'Dotted': И/и
    ///
    /// Имајте на уму да је мала тачка Кс00Кс иста као и латиница.Стога:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Вредност Кс04Кс овде се ослања на језик текста: ако смо у Кс01Кс, то би требало да буде Кс02Кс, али ако смо у Кс03Кс, то би требало да буде Кс00Кс.
    /// `to_uppercase()` ово не узима у обзир, и тако:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// држи на више језика.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Проверава да ли је вредност унутар АСЦИИ опсега.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Копира вредност у АСЦИИ еквиваленту великих слова.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// За употребу великих слова на месту користите Кс00Кс.
    ///
    /// За велика слова АСЦИИ знакова поред знакова који нису АСЦИИ, користите Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Копира вредност у АСЦИИ еквиваленту малих слова.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте умањили вредност на месту, користите Кс00Кс.
    ///
    /// Да бисте малим и малим АСЦИИ знаковима додали не-АСЦИИ знакове, користите Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Проверава да ли се две вредности подударају са малим и малим словима у АСЦИИ.
    ///
    /// Еквивалентно Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Претвара овај тип у свој АСЦИИ велики еквивалент на месту.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову велику почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Претвара овај тип у свој АСЦИИ еквивалент малим словима уместо њега.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову малу почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Проверава да ли је вредност АСЦИИ абецедни знак:
    ///
    /// - У + 0041 Кс01Кс ..=У + 005А Кс00Кс, или
    /// - У + 0061 Кс01Кс ..=У + 007А Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Проверава да ли је вредност АСЦИИ велика слова:
    /// У + 0041 Кс01Кс ..=У + 005А Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Проверава да ли је вредност АСЦИИ мала слова:
    /// У + 0061 Кс01Кс ..=У + 007А Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Проверава да ли је вредност АСЦИИ алфанумерички знак:
    ///
    /// - У + 0041 Кс01Кс ..=У + 005А Кс00Кс, или
    /// - У + 0061 Кс01Кс ..=У + 007А Кс00Кс, или
    /// - У + 0030 Кс01Кс ..=У + 0039 Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Проверава да ли је вредност АСЦИИ децимална цифра:
    /// У + 0030 Кс01Кс ..=У + 0039 Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Проверава да ли је вредност АСЦИИ хексадецимална цифра:
    ///
    /// - У + 0030 Кс01Кс ..=У + 0039 Кс00Кс, или
    /// - У + 0041 Кс01Кс ..=У + 0046 Кс00Кс, или
    /// - У + 0061 Кс01Кс ..=У + 0066 Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Проверава да ли је вредност АСЦИИ интерпункцијски знак:
    ///
    /// - У + 0021 ..=У + 002Ф Кс00Кс, или
    /// - У + 003А ..=У + 0040 Кс00Кс, или
    /// - У + 005Б ..=У + 0060 ``[\] ^ _`Кс00Кс, или
    /// - У + 007Б ..=У + 007Е Кс00Кс
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Проверава да ли је вредност АСЦИИ графички знак:
    /// У + 0021 Кс01Кс ..=У + 007Е Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Проверава да ли је вредност АСЦИИ размак:
    /// У + 0020 ПРОСТОР, У + 0009 ХОРИЗОНТАЛНИ ТАБ, У + 000А ПОВРЕДНА ПОТПУНА, У + 000Ц ОБЛИК ФЕЕД-а или У + 000Д ПОВРАТАК ПРИЈЕВОЗА.
    ///
    /// З0Руст0З користи ВхатВГ Инфра Стандард Кс00Кс.Постоји неколико других дефиниција у широкој употреби.
    /// На пример, Кс00Кс укључује У + 000Б ВЕРТИЦАЛ ТАБ, као и све горе наведене знакове, али-из исте спецификације-[подразумевано правило за Кс01Кс у Боурне З0схелл0З][бфс] узима у обзир *само* ПРОСТОР, ХОРИЗОНТАЛНИ ТАБ и ЛИНЕ ФЕЕД као размак.
    ///
    ///
    /// Ако пишете програм који ће обрадити постојећи формат датотеке, проверите која је дефиниција празног простора тог формата пре употребе ове функције.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Проверава да ли је вредност контролни знак АСЦИИ:
    /// У + 0000 НУЛ ..=У + 001Ф СЕПАРАТОР ЈЕДИНИЦЕ, или У + 007Ф БРИСАЊЕ.
    /// Имајте на уму да је већина АСЦИИ празних знакова контролних знакова, али ПРОСТОР није.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Кодира сирову вредност Кс00Кс као Кс01Кс у обезбеђени бајтни ме успремник, а затим враћа подрезану ме успремника која садржи кодирани знак.
///
///
/// За разлику од Кс00Кс, овај метод такође обрађује кодне тачке у сурогат опсегу.
/// (Стварање Кс01Кс у сурогат опсегу је УБ.) Резултат је важећи Кс02Кс, али није важећи Кс00Кс.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// З0Паницс0З ако бафер није довољно велик.
/// Бафер дужине четири је довољно велик да кодира било који Кс00Кс.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Кодира сирову вредност Кс00Кс као Кс01Кс у обезбеђени Кс02Кс међуспремник, а затим враћа подрезану међуспремника који садржи кодирани знак.
///
///
/// За разлику од Кс00Кс, овај метод такође обрађује кодне тачке у сурогат опсегу.
/// (Стварање Кс00Кс у сурогат опсегу је УБ.)
///
/// # Panics
///
/// З0Паницс0З ако бафер није довољно велик.
/// Бафер дужине 2 је довољно велик да кодира било који Кс00Кс.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // БЕЗБЕДНОСТ: свака рука проверава да ли има довољно битова за уписивање
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // БМП пада
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Допунски авиони проваљују у сурогате.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}