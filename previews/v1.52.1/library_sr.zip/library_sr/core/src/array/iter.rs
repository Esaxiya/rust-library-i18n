//! Дефинише итератор за низове у власништву Кс00Кс.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ицератор Кс00Кс по вредности.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ово је низ који понављамо.
    ///
    /// Елементи са индексом Кс00Кс где Кс01Кс још нису дати и важећи су уноси низа.
    /// Елементи са индексима Кс00Кс или Кс01Кс су већ дати и не сме им се више приступити!Ти мртви елементи можда су чак и у потпуно неиницијализованом стању!
    ///
    ///
    /// Дакле, инваријанте су:
    /// - `data[alive]` је жив (тј. садржи важеће елементе)
    /// - `data[..alive.start]` и Кс00Кс су мртви (тј. елементи су већ прочитани и не смеју се више дирати!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Елементи у Кс00Кс који још нису дати.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Ствара нови итератор преко датог Кс00Кс.
    ///
    /// *Напомена*: овај метод ће можда бити застарио у З0футуре0З, након Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Тип Кс01Кс овде је Кс02Кс, уместо Кс00Кс
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕЗБЕДНОСТ: Овде је трансмута заправо сигуран.Документи Кс00Кс
        // promise:
        //
        // > `MaybeUninit<T>` гарантовано је исте величине и поравнања
        // > као Кс00Кс.
        //
        // Документи чак приказују трансмутирање из низа Кс01Кс у низ Кс00Кс.
        //
        //
        // Тиме ова иницијализација задовољава инваријанте.

        // FIXME(LukasKalbertodt): заправо употребите Кс00Кс овде, након што ради са цонст генерицима:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // До тада, можемо да користимо Кс00Кс за креирање битне копије као други тип, а затим заборавимо Кс01Кс да не би био испуштен.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Приказује непроменљиви комад свих елемената који још нису дати.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕЗБЕДНОСТ: Знамо да су сви елементи у Кс00Кс правилно иницијализовани.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Приказује променљиви део свих елемената који још нису дати.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕЗБЕДНОСТ: Знамо да су сви елементи у Кс00Кс правилно иницијализовани.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Узмите следећи индекс са предње стране.
        //
        // Повећање Кс01Кс за 1 одржава инваријанту у односу на Кс00Кс.
        // Међутим, услед ове промене, за кратко време, жива зона више није Кс01Кс, већ Кс00Кс.
        //
        self.alive.next().map(|idx| {
            // Прочитајте елемент из низа.
            // БЕЗБЕДНОСТ: Кс00Кс је индекс бившег Кс01Кс региона
            // низ.Читање овог елемента значи да се Кс00Кс сада сматра мртвим (тј. Не додирујте га).
            // Како је Кс00Кс био почетак живе зоне, жива зона је поново Кс01Кс, обнављајући све инваријанте.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Узмите следећи индекс са задње стране.
        //
        // Смањивање Кс01Кс за 1 задржава инваријанту у односу на Кс00Кс.
        // Међутим, услед ове промене, за кратко време, жива зона више није Кс01Кс, већ Кс00Кс.
        //
        self.alive.next_back().map(|idx| {
            // Прочитајте елемент из низа.
            // БЕЗБЕДНОСТ: Кс00Кс је индекс бившег Кс01Кс региона
            // низ.Читање овог елемента значи да се Кс00Кс сада сматра мртвим (тј. Не додирујте га).
            // Како је Кс00Кс био крај живе зоне, жива зона је сада поново Кс01Кс, обнављајући све инваријанте.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕЗБЕДНОСТ: Ово је сигурно: Кс00Кс враћа тачно потрезањ
        // елемената који још нису исељени и који преостају да се одбаце.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Никада се неће прелити због непроменљивог `ливе.старт <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итератор заиста наводи тачну дужину.
// Број Кс01Кс елемената (који ће и даље бити дати) је дужина опсега Кс00Кс.
// Овај опсег се смањује у дужини у Кс01Кс или Кс00Кс.
// У тим методама се увек смањује са 1, али само ако се врати Кс00Кс.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Имајте на уму да заправо не треба да се подударамо са истим живим дометом, тако да можемо само да клонирамо у офсет 0, без обзира на то где је Кс00Кс.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонирајте све живе елементе.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Напишите клон у нови низ, а затим ажурирајте његов опсег уживо.
            // Ако клонирате З0паницс0З, правилно ћемо испустити претходне ставке.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Штампајте само елементе који још нису уступљени: више не можемо приступити уступљеним елементима.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}