//! Дефинише тип грешке Кс00Кс.

use crate::fmt;

/// Грешке које се могу појавити при покушају тумачења низа Кс00Кс као низа.
///
/// Као такве, Кс00Кс породица функција и метода за [`Стринг`] и [`&стр`] с користе ову грешку, на пример.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Методе овог типа грешке могу се користити за стварање функционалности сличне Кс00Кс без алокације меморије хрпе:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Враћа индекс у датом низу до ког је верификован важећи Кс00Кс.
    ///
    /// То је максимални индекс такав да би Кс01Кс вратио Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::str;
    ///
    /// // неки неважећи бајтови, у З0вецтор0З
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 враћа Утф8Еррор
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // други бајт је овде неважећи
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Пружа више информација о квару:
    ///
    /// * `None`: крај уноса је неочекивано достигнут.
    ///   `self.valid_up_to()` је 1 до 3 бајта од краја уноса.
    ///   Ако се ток бајтова (као што је датотека или мрежна утичница) декодира поступно, ово би могао бити важећи Кс00Кс чија се секвенца бајтова Кс01Кс обухвата више делова.
    ///
    ///
    /// * `Some(len)`: наишао је на неочекивани бајт.
    ///   Наведена дужина је неважеће секвенце бајтова која започиње индексом датим од Кс00Кс.
    ///   Декодирање би требало да се настави након те секвенце (након уметања Кс00Кс) у случају декодирања са губицима.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Грешка враћена када рашчлањивање Кс00Кс помоћу Кс01Кс не успе
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}