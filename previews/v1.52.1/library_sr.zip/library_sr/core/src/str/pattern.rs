//! АПИ низа Паттерн.
//!
//! АПИ образац пружа генерички механизам за употребу различитих типова образаца приликом претраживања низа.
//!
//! За више детаља погледајте З0траитс0З Кс01Кс, Кс02Кс, Кс03Кс и Кс00Кс.
//!
//! Иако је овај АПИ нестабилан, изложен је путем стабилних АПИ-ја типа Кс00Кс.
//!
//! # Examples
//!
//! [`Pattern`] је Кс04Кс у стабилном АПИ-ју за Кс01Кс, Кс02Кс, кришке Кс03Кс и функције и затвараче који имплементирају Кс00Кс.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // узорак цхар
//! assert_eq!(s.find('n'), Some(2));
//! // парче узорака знакова
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // образац затварања
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Узорак низа.
///
/// Кс01Кс изражава да се тип имплементације може користити као образац низа за претрагу у Кс00Кс.
///
/// На пример, и Кс01Кс и Кс02Кс су обрасци који би се подударали у индексу Кс03Кс у низу Кс00Кс.
///
/// Сам З0 Портраит0З делује као креатор за придружени тип Кс00Кс, који обавља стварни посао проналажења појава узорка у низу.
///
///
/// У зависности од врсте узорка, понашање метода попут Кс00Кс и Кс01Кс може се променити.
/// Табела у наставку описује нека од тих понашања.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Повезани претраживач за овај образац
    type Searcher: Searcher<'a>;

    /// Конструише повезани претраживач из Кс00Кс и Кс01Кс за претрагу.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Проверава да ли се образац подудара било где у пласту сена
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Проверава да ли се образац подудара на предњој страни пласта сена
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Проверава да ли се образац подудара на задњем делу пласта сена
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Уклања образац са предње стране пласта сена, ако се подудара.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // БЕЗБЕДНОСТ: Познато је да Кс00Кс враћа важеће индексе.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Уклања образац са задњег дела пласта сена, ако се подудара.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // БЕЗБЕДНОСТ: Познато је да Кс00Кс враћа важеће индексе.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Резултат позивања Кс01Кс или Кс00Кс.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Изражава да је код модела Кс00Кс пронађено подударање узорка.
    ///
    Match(usize, usize),
    /// Изражава да је Кс00Кс одбачен као могуће подударање узорка.
    ///
    /// Имајте на уму да између два `Матцх-а 'може бити више од једног Кс00Кс, не постоји захтев да се они комбинују у један.
    ///
    ///
    Reject(usize, usize),
    /// Изражава да је посећен сваки бајт пласта сена, чиме се завршава понављање.
    ///
    Done,
}

/// Претраживач за образац низа.
///
/// Овај З0 Портраит0З пружа методе за тражење непреклапајућих подударања узорка почевши од предњег Кс00Кс низа.
///
/// Биће имплементиран од повезаних Кс00Кс типова Кс01Кс З0 Портраит0З.
///
/// З0 Портраит0З је означен као небезбедан, јер индекси који се враћају методама Кс00Кс морају да леже на важећим границама Кс01Кс у пласту сена.
/// Ово омогућава потрошачима овог З0 Портраит0З да исеку стог сена без додатних провера времена рада.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// З0Геттер0З за основни низ у коме се тражи
    ///
    /// Увек ће вратити исти Кс00Кс.
    fn haystack(&self) -> &'a str;

    /// Изводи следећи корак претраживања почевши од напред.
    ///
    /// - Приказује Кс00Кс ако се Кс01Кс подудара са шаблоном.
    /// - Приказује Кс00Кс ако Кс01Кс не може да се подудара са узорком, чак делимично.
    /// - Враћа Кс00Кс ако је посећен сваки бајт пласта сена.
    ///
    /// Ток вредности Кс00Кс и Кс01Кс до Кс02Кс садржаће индексне опсеге који су суседни, не преклапају се, покривају цео стог сена и полажу на границе Кс03Кс.
    ///
    ///
    /// Резултат Кс00Кс мора да садржи цео одговарајући образац, међутим резултати Кс01Кс могу се поделити на произвољно много суседних фрагмената.Оба опсега могу имати нулту дужину.
    ///
    /// Као пример, узорак Кс00Кс и пласт сена Кс01Кс могу створити ток
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Проналази следећи резултат Кс01Кс.Погледајте Кс00Кс.
    ///
    /// За разлику од Кс00Кс, не постоји гаранција да ће се враћени опсези овог и Кс01Кс преклапати.
    /// Ово ће вратити Кс00Кс, где је старт_матцх индекс места где започиње меч, а енд_матцх индекс након завршетка меча.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Проналази следећи резултат Кс01Кс.Погледајте Кс02Кс и Кс00Кс.
    ///
    /// За разлику од Кс00Кс, не постоји гаранција да ће се враћени опсези овог и Кс01Кс преклапати.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Обрнути претраживач за низ узорака.
///
/// Овај З0 Портраит0З пружа методе за тражење непреклапајућих подударања узорка почевши од задњег Кс00Кс низа.
///
/// Имплементираће га придружени Кс00Кс типови Кс01Кс З0 Портраит0З ако образац подржава његово тражење са задње стране.
///
///
/// Опсези индекса које враћа овај З0 Портраит0З нису потребни да се тачно подударају са онима унапред тражене обрнуто.
///
/// Из разлога зашто је овај З0 Портраит0З означен као небезбедан, погледајте их као матичне З0 Портраит0З Кс00Кс.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Изводи следећи корак претраживања почевши од позади.
    ///
    /// - Приказује Кс00Кс ако се Кс01Кс подудара са шаблоном.
    /// - Приказује Кс00Кс ако Кс01Кс не може да се подудара са узорком, чак делимично.
    /// - Враћа Кс00Кс ако је посећен сваки бајт пласта сена
    ///
    /// Ток вредности Кс00Кс и Кс01Кс до Кс02Кс садржаће индексне опсеге који су суседни, не преклапају се, покривају цео стог сена и полажу на границе Кс03Кс.
    ///
    ///
    /// Резултат Кс00Кс мора да садржи цео одговарајући образац, међутим резултати Кс01Кс могу се поделити на произвољно много суседних фрагмената.Оба опсега могу имати нулту дужину.
    ///
    /// Као пример, образац Кс03Кс и пласт сена Кс04Кс могу створити ток Кс01Кс, Кс02Кс, Кс00Кс, Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Проналази следећи Кс00Кс резултат.
    /// Погледајте Кс00Кс.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Проналази следећи Кс00Кс резултат.
    /// Погледајте Кс00Кс.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Ознака З0 Портраит0З која изражава да се Кс00Кс може користити за имплементацију Кс01Кс.
///
/// Да би ово постигли, импл. Кс00Кс и Кс01Кс морају да следе следеће услове:
///
/// - Сви резултати Кс00Кс морају бити идентични резултатима Кс01Кс обрнутим редоследом.
/// - `next()` и Кс01Кс треба да се понашају као два краја низа вредности, то јест не могу Кс00Кс.
///
/// # Examples
///
/// `char::Searcher` је Кс00Кс, јер тражење Кс01Кс захтева само гледање једног по једног, који се понаша исто са оба краја.
///
/// `(&str)::Searcher` није Кс01Кс, јер се образац Кс02Кс у пласту сијена Кс03Кс поклапа или са Кс04Кс или са Кс00Кс, у зависности са које се стране претражује.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Импл за цхар
/////////////////////////////////////////////////////////////////////////////

/// Придружени тип за Кс00Кс.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // безбедносни инваријант: Кс00Кс мора бити важећи индекс бајтова Кс01Кс од Кс02Кс. Овај инваријант се може разбити *унутар* нект_матцх и нект_матцх_бацк, међутим морају изаћи прстима на важећим границама тачке кода.
    //
    //
    /// `finger` је тренутни бајтни индекс претраживања унапред.
    /// Замислите да постоји пре бајта у свом индексу, тј
    /// `haystack[finger]` је први бајт пресека који морамо прегледати током претраживања унапред
    ///
    finger: usize,
    /// `finger_back` је тренутни бајтни индекс обрнутог претраживања.
    /// Замислите да постоји после бајта у свом индексу, тј
    /// пласт сена [фингер_бацк, 1] је последњи бајт пресека који морамо прегледати током претраживања унапред (и самим тим први бајт који треба прегледати приликом позивања Кс00Кс.
    ///
    finger_back: usize,
    /// Лик за којим се трага
    needle: char,

    // безбедносна инваријанта: Кс00Кс мора бити мања од 5
    /// Број бајтова Кс01Кс заузима када је кодиран у Кс00Кс.
    utf8_size: usize,
    /// Копија Кс00Кс кодирана у Кс01Кс
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // БЕЗБЕДНОСТ: 1-4 гарантују сигурност Кс00Кс
        // 1. `self.finger` и Кс00Кс се држе на уницоде границама (ово је инваријантно)
        // 2. `self.finger >= 0` пошто почиње од 0 и само се повећава
        // 3. `self.finger < self.finger_back` јер би у супротном цхар Кс01Кс вратио Кс00Кс
        // 4.
        // `self.finger` долази пред крај пласта сена, јер Кс00Кс почиње на крају и само се смањује
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // додати одмак бајта тренутног карактера без поновног кодирања као Кс00Кс
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // узмите пласт сена након последњег пронађеног лика
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // последњи бајт Кс01Кс кодиране игле БЕЗБЕДНОСТ: имамо инваријант који Кс00Кс
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Нови прст је индекс бајта који смо пронашли, плус један, јер смо меморисали последњи бајт карактера.
                //
                // Имајте на уму да нам ово не даје увек прст на граници Кс00Кс.
                // Ако *нисмо* пронашли свој карактер, можда смо индексирали нестални бајт 3-бајтног или 4-бајтног знака.
                // Не можемо једноставно прескочити на следећи важећи почетни бајт, јер ће знак попут ꁁ (У + А041 ИИ СИЛЛАБЛЕ ПА), Кс00Кс Кс01Кс увек тражити други бајт када тражимо трећи.
                //
                //
                // Међутим, ово је потпуно у реду.
                // Иако имамо инваријант да је Кс01Кс на граници Кс02Кс, овај инваријант се не ослања у оквиру ове методе (на њега се ослања у Кс00Кс.
                //
                // Из ове методе излазимо тек када стигнемо до краја низа или ако нешто пронађемо.Када нешто пронађемо, Кс00Кс ће бити постављен на границу Кс01Кс.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // нисам нашао ништа, изађи
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // нека нект_рејецт користи подразумевану имплементацију из претраживача З0 Портраит0З
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // БЕЗБЕДНОСТ: погледајте коментар за Кс00Кс горе
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // одузми помак бајта тренутног карактера без поновног кодирања као Кс00Кс
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // узмите пласт сена, али не укључујући и последњи претраживани лик
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // последњи бајт Кс01Кс кодиране игле БЕЗБЕДНОСТ: имамо инваријант који Кс00Кс
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // претражили смо део који је надокнађен Кс00Кс, додајте Кс01Кс да бисте надокнадили оригинални индекс
                //
                let index = self.finger + index;
                // мемрцхр ће вратити индекс бајта који желимо да пронађемо.
                // У случају АСЦИИ карактера, ово је заиста оно што бисмо желели да буде наш нови прст (Кс00Кс пронађени знак у парадигми обрнуте итерације).
                //
                // За вишебајтне знакове морамо прескочити према броју бајтова који имају више од АСЦИИ
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // померите прст до пре пронађеног карактера (тј. на његовом почетном индексу)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Овде не можемо користити фингер_бацк=индек, сизе + 1.
                // Ако смо пронашли последњи знак различитог карактера (или средњи бајт различитог знака), треба да вратимо фингер_бацк на Кс00Кс.
                // Ово на сличан начин чини да Кс00Кс има потенцијал да више не буде на граници, али то је у реду јер ову функцију излазимо само на граници или када је стог сена у потпуности претражен.
                //
                //
                // За разлику од нект_матцх, овај проблем нема проблем поновљених бајтова у Кс00Кс, јер тражимо последњи бајт, а последњи бајт можемо пронаћи само када претражујемо обрнуто.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // нисам нашао ништа, изађи
                return None;
            }
        }
    }

    // нека нект_рејецт_бацк користи подразумевану имплементацију из претраживача З0 Портраит0З
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Претражује знакове који су једнаки датом Кс00Кс.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Импл за омот МултиЦхарЕк
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Упоредите дужине итератора интерног бајтног пресека да бисте пронашли дужину тренутног знака
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Упоредите дужине итератора интерног бајтног пресека да бисте пронашли дужину тренутног знака
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Импл за&[цхар]
/////////////////////////////////////////////////////////////////////////////

// Todo: Промена/уклањање због двосмислености у значењу.

/// Придружени тип за Кс00Кс.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Претражује знакове који су једнаки било којем од знакова у исечку.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Импл за Ф: Кс00Кс-> З0боол0З
/////////////////////////////////////////////////////////////////////////////

/// Придружени тип за Кс00Кс.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Претражује [`цхар`] који се подударају са датим предикатом.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Импл за&&стр
/////////////////////////////////////////////////////////////////////////////

/// Делегати на Кс00Кс импл.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Импл за Кс00Кс
/////////////////////////////////////////////////////////////////////////////

/// Нераспоређивање претраживања подниза.
///
/// Обрађиваће образац Кс00Кс као враћање празних подударања на свакој граници знакова.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Проверава да ли се образац подудара на предњој страни пласта сена.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Уклања образац са предње стране пласта сена, ако се подудара.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // БЕЗБЕДНОСТ: управо је потврђено да префикс постоји.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Проверава да ли се узорак подудара на задњем делу пласта сена.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Уклања образац са задњег дела пласта сена, ако се подудара.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // БЕЗБЕДНОСТ: управо је потврђено да суфикс постоји.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Двосмерни претраживач подниза
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Придружени тип за Кс00Кс.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // празна игла одбацује сваки знак и подудара се са свим празним низом између њих
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // ТвоВаиСеарцхер производи важеће индексе *Матцх* који се раздвајају на границама знакова све док исправно подудара и стог сена и игла важе Кс00Кс *Одбијања* из алгоритма могу пасти на било који индекс, али ћемо их ручно пребацити до границе следећег знака, тако да су безбедни за Кс01Кс.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // прескочите на следећу границу знака
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // напишите случајеве Кс00Кс и Кс01Кс да подстакнете састављача да та два случаја посебно специјализује.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // прескочите на следећу границу знака
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // испишите Кс02Кс и Кс01Кс, попут Кс00Кс
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Интерно стање двосмерног алгоритма претраживања подниза.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// индекс критичне факторизације
    crit_pos: usize,
    /// критични индекс факторизације за обрнуту иглу
    crit_pos_back: usize,
    period: usize,
    /// `byteset` је продужетак (није део двосмерног алгоритма);
    /// то је 64-битни Кс00Кс где сваки постављени бит Кс01Кс одговара (бајту&63)==ј присутном у игли.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// индекс у иглу пред којом смо се већ поклопили
    memory: usize,
    /// индекс у иглу након чега смо се већ поклопили
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Посебно читљиво објашњење шта се овде догађа може се наћи у књизи Цроцхеморе и Риттер Кс00Кс, поглавље 13.
        // Конкретно погледајте код за Кс00Кс на стр.
        // 323.
        //
        // Оно што се догађа је да имамо неку критичну факторизацију (у, в) игле и желимо да утврдимо да ли је у суфикс&в [.. тачка].
        // Ако јесте, користимо Кс00Кс.
        // Иначе користимо Кс00Кс, који је оптимизован за период када је игла велика.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // случај кратког периода-период је тачно израчунавање одвојеног критичног факторизовања за обрнуту иглу к=у 'в' где | в '|<Кс00Кс.
            //
            // Ово се убрзава већ познатим периодом.
            // Имајте на уму да случај попут к=Кс00Кс може бити урачунат тачно унапред (крит_пос=1, период=3), док се рачуна с приближним периодом обрнуто (црит_пос=2, период=2).
            // Користимо задану обрнуту факторизацију, али задржавамо тачан период.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // случај дугог периода-имамо приближни приказ стварног периода и не користимо меморисање.
            //
            //
            // Приближите период доњом границом Кс00Кс + 1.
            // Критична факторизација је ефикасна за претрагу унапред и уназад.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Лажна вредност која означава да је период дуг
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Једна од главних идеја Двосмерног је да иглу разставимо на две половине, (у, в) и започнемо покушај проналажења в у пласту сена скенирајући слева удесно.
    // Ако се в подудара, покушавамо да се подударамо са скенирањем здесна улево.
    // Колико далеко можемо да скочимо када наиђемо на неусклађеност, све се заснива на чињеници да је (у, в) критична факторизација игле.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` користи Кс00Кс као курсор
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Проверите да ли имамо простора за претрагу у положају + игла_ласт не може да се прелије ако претпоставимо да су кришке ограничене опсегом исизе.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Брзо прескочите велике делове који нису повезани са нашим поднизом
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Погледајте да ли се подудара десни део игле
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Погледајте да ли се поклапа леви део игле
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Пронашли смо утакмицу!
            let match_pos = self.position;

            // Note: додајте Кс00Кс уместо Кс01Кс да бисте имали преклапајуће подударања
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // постављено на Кс00Кс, Кс01Кс за преклапање утакмица
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Прати идеје из Кс00Кс.
    //
    // Дефиниције су симетричне, са Кс03Кс=Кс04Кс и Кс05Кс=Кс01Кс, Кс02Кс, па ако је (у, в) критична факторизација, онда је и Кс00Кс, reverse(u)).
    //
    //
    // За обрнути случај израчунали смо критичку факторизацију к=у 'в' (поље Кс02Кс).Треба нам | у |<Кс00Кс за предњи случај и тако | в '|<Кс01Кс за обрнуто.
    //
    // Да бисмо претражили обрнуто кроз стог сена, претражујемо уназад кроз обрнути иглу обрнутом иглом, подударајући се прво са у, а затим са в.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` користи Кс00Кс као курсор-тако да су Кс01Кс и Кс02Кс независни.
        //
        let old_end = self.end;
        'search: loop {
            // Проверите да ли на крају имамо простора за претрагу, Кс00Кс ће се обмотати кад више нема места, али због ограничења дужине резова никада се неће моћи умотати до краја у стог сена.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Брзо прескочите велике делове који нису повезани са нашим поднизом
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Погледајте да ли се поклапа леви део игле
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Погледајте да ли се подудара десни део игле
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Пронашли смо утакмицу!
            let match_pos = self.end - needle.len();
            // Note: под Кс00Кс уместо Кс01Кс да се преклапајуће утакмице подударају
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Израчунајте максимални суфикс Кс00Кс.
    //
    // Максимални суфикс је могућа критична факторизација (у, в) Кс00Кс.
    //
    // Приказује (`и`, Кс02Кс) где је Кс00Кс почетни индекс в, а Кс01Кс период в.
    //
    // `order_greater` одређује да ли је лексички поредак Кс01Кс или Кс00Кс.
    // Оба налога морају да се израчунају-редослед са највећим Кс00Кс даје критичну факторизацију.
    //
    //
    // За случајеве дугог периода, резултујући период није тачан (прекратак је).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Одговара и у раду
        let mut right = 1; // Одговара ј у раду
        let mut offset = 0; // Одговара к у раду, али почев од 0
        // како би се подударао са индексирањем заснованим на 0.
        let mut period = 1; // Одговара п у раду

        while let Some(&a) = arr.get(right + offset) {
            // `left` биће улазни када је Кс00Кс.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфикс је мањи, период је до сада цео префикс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Напредујте кроз понављање текућег периода.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфикс је већи, почните испочетка са тренутне локације.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Израчунајте максимални суфикс наличја Кс00Кс.
    //
    // Максимални суфикс је могућа критична факторизација (у ', в') Кс00Кс.
    //
    // Приказује Кс00Кс где је Кс01Кс почетни индекс в ', са задње стране;
    // враћа се одмах када се достигне период од Кс00Кс.
    //
    // `order_greater` одређује да ли је лексички поредак Кс01Кс или Кс00Кс.
    // Оба налога морају да се израчунају-редослед са највећим Кс00Кс даје критичну факторизацију.
    //
    //
    // За случајеве дугог периода, резултујући период није тачан (прекратак је).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Одговара и у раду
        let mut right = 1; // Одговара ј у раду
        let mut offset = 0; // Одговара к у раду, али почев од 0
        // како би се подударао са индексирањем заснованим на 0.
        let mut period = 1; // Одговара п у раду
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфикс је мањи, период је до сада цео префикс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Напредујте кроз понављање текућег периода.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфикс је већи, почните испочетка са тренутне локације.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// ТвоВаиСтратеги омогућава алгоритму да или прескочи неподударања што је брже могуће или да ради у режиму у којем релативно брзо емитује одбијенице.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Прескочите на подударање интервала што је брже могуће
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Редовно емитујте одбијенице
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}