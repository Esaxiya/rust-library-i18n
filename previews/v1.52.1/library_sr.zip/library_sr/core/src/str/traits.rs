//! З0Траит0З имплементације за Кс00Кс.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Имплементира уређивање низова.
///
/// Низови су поредани Кс00Кс према њиховим бајт вредностима.
/// Ово наручује Уницоде кодне тачке на основу њихових позиција на графиконима кодова.
/// Ово није нужно исто као Кс00Кс поруџбина, која се разликује у зависности од језика и језика.
/// За сортирање низова према културно прихваћеним стандардима потребни су подаци специфични за локално окружење који су изван домета типа Кс00Кс.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Имплементира операције упоређивања низова.
///
/// Низови се упоређују са Кс00Кс по бајт вредностима.
/// Ово упоређује Уницоде кодне тачке на основу њихових позиција у табеларним кодима.
/// Ово није нужно исто као Кс00Кс поруџбина, која се разликује у зависности од језика и језика.
/// Поређење низова према културно прихваћеним стандардима захтева податке специфичне за локално окружење који су изван домета типа Кс00Кс.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Приказује део целог низа, тј. Враћа Кс01Кс или Кс00Кс.Еквивалентно `&селф [0 ..
/// лен] `или`&мут селф [0 ..
/// len]`.
/// За разлику од других операција индексирања, ово никада не може З0паниц0З.
///
/// Ова операција је *О*(1).
///
/// Пре Кс01Кс, ове операције индексирања и даље су биле подржане директном имплементацијом Кс02Кс и Кс00Кс.
///
/// Еквивалентно Кс01Кс или Кс00Кс.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Враћа одрезак датог низа из опсега бајтова [`бегин`, Кс00Кс).
///
/// Ова операција је *О*(1).
///
/// Пре Кс01Кс, ове операције индексирања и даље су биле подржане директном имплементацијом Кс02Кс и Кс00Кс.
///
/// # Panics
///
/// З0Паницс0З ако Кс02Кс или Кс03Кс не указује на помак почетног бајта знака (како је дефинисано Кс04Кс), ако је Кс01Кс или ако је Кс00Кс.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ово ће З0паниц0З:
/// // бајт 2 лежи у Кс00Кс:
/// // &с [2.3.];
///
/// // бајт 8 лежи унутар Кс00Кс&с [1 ..
/// // 8];
///
/// // бајт 100 је изван низа&с [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: управо проверио да ли су Кс00Кс и Кс01Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            // Такође смо проверили границе знакова, тако да је ово важећи Кс00Кс.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: управо смо проверили да ли су Кс00Кс и Кс01Кс на граници знака.
            // Знамо да је показивач јединствен јер смо га добили од Кс00Кс.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗБЕДНОСТ: позивалац гарантује да је Кс01Кс у границама Кс00Кс
        // који задовољава све услове за Кс00Кс.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗБЕДНОСТ: видети коментаре за Кс00Кс.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // ис_цхар_боундари проверава да ли је индекс у [0, Кс00Кс не може поново да користи Кс01Кс као горе, због проблема са НЛЛ-ом
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗБЕДНОСТ: управо проверио да ли су Кс00Кс и Кс01Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Приказује део датог низа из опсега бајтова [`0`, Кс00Кс).
/// Еквивалентно Кс01Кс или Кс00Кс.
///
/// Ова операција је *О*(1).
///
/// Пре Кс01Кс, ове операције индексирања и даље су биле подржане директном имплементацијом Кс02Кс и Кс00Кс.
///
/// # Panics
///
/// З0Паницс0З ако Кс01Кс не указује на помак почетног бајта знака (како је дефинисано Кс02Кс) или ако Кс00Кс.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Враћа одрезак датог низа из опсега бајтова [`бегин`, Кс00Кс).Еквивалентно `&селф [бегин ..
/// лен] `или`&мут селф [започети ..
/// len]`.
///
/// Ова операција је *О*(1).
///
/// Пре Кс01Кс, ове операције индексирања и даље су биле подржане директном имплементацијом Кс02Кс и Кс00Кс.
///
/// # Panics
///
/// З0Паницс0З ако Кс01Кс не указује на помак почетног бајта знака (како је дефинисано Кс02Кс) или ако Кс00Кс.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗБЕДНОСТ: позивалац гарантује да је Кс01Кс у границама Кс00Кс
        // који задовољава све услове за Кс00Кс.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗБЕДНОСТ: идентично Кс00Кс.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // БЕЗБЕДНОСТ: управо проверио да ли је Кс00Кс на граници знака,
            // и прослеђујемо сигурну референцу, па ће и повратна вредност бити једна.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Приказује део датог низа из опсега бајтова Кс01Кс.Еквивалентно Кс03Кс или Кс02Кс, осим ако Кс04Кс има максималну вредност за Кс00Кс.
///
/// Ова операција је *О*(1).
///
/// # Panics
///
/// З0Паницс0З ако Кс02Кс не указује на помак почетног бајта знака (како је дефинисано Кс05Кс), ако Кс03Кс не указује на помак завршног бајта знака (Кс04Кс је или помак бајта или једнак Кс06Кс), ако је Кс01Кс, или ако је Кс00Кс.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Примењује резање подниза са синтаксом Кс01Кс или Кс00Кс.
///
/// Приказује део датог низа из опсега бајтова Кс00Кс.
/// Еквивалентно Кс01Кс, осим ако Кс02Кс има максималну вредност за Кс00Кс.
///
/// Ова операција је *О*(1).
///
/// # Panics
///
/// З0Паницс0З ако Кс02Кс не показује крајњи помак бајта знака (Кс03Кс је или почетни помак бајта како је дефинисано Кс01Кс, или је једнак Кс04Кс), или ако Кс00Кс.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Анализирајте вредност из низа
///
/// `ФромСтр`-ов Кс00Кс метод се често користи имплицитно, путем [`стр`]-ове Кс01Кс методе.
/// За примере погледајте документацију [`парсе`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` нема параметар трајања, тако да можете рашчланити само типове који сами не садрже параметар трајања.
///
/// Другим речима, можете да рашчланите Кс02Кс са Кс01Кс, али не и Кс00Кс.
/// Можете да рашчланите структуру која садржи Кс01Кс, али не и ону која садржи Кс00Кс.
///
/// # Examples
///
/// Основна примена Кс00Кс на примеру Кс01Кс типа:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Повезана грешка која се може вратити из рашчлањивања.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Анализира низ Кс00Кс да би вратио вредност овог типа.
    ///
    /// Ако је рашчлањивање успело, вратите вредност унутар Кс01Кс, у супротном када је низ лоше форматиран, вратите грешку специфичну за унутрашњост Кс00Кс.
    /// Тип грешке је специфичан за имплементацију З0 Портраит0З.
    ///
    /// # Examples
    ///
    /// Основна употреба са Кс01Кс, типом који примењује Кс00Кс:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Анализирајте Кс00Кс из низа.
    ///
    /// Даје Кс00Кс, јер Кс01Кс може или не мора бити подложан рашчлањивању.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Имајте на уму да је у многим случајевима Кс00Кс метода на Кс01Кс правилнија.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}