//! Манипулација низовима.
//!
//! За више детаља погледајте Кс00Кс модул.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ван граница
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. почети <=крај
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. граница карактера
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // наћи лик
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` мора бити мања од дужине и границе знака
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Приказује дужину Кс00Кс.
    ///
    /// Ова дужина је у бајтовима, а не у ``цхар`] или графемама.
    /// Другим речима, човек можда није оно што сматра дужином жице.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // фанци ф!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Приказује Кс00Кс ако Кс01Кс има дужину од нула бајтова.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Проверава да ли је индексни бајт први бајт у секвенци Кс00Кс кодне тачке или крај низа.
    ///
    ///
    /// Почетак и крај низа (када се `индек==Кс00Кс сматрају границама.
    ///
    /// Приказује Кс01Кс ако је Кс02Кс већи од Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // почетак Кс00Кс
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // други бајт Кс00Кс
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // трећи бајт Кс00Кс
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 и лен су увек у реду.
        // Експлицитно тестирајте на 0, тако да може лако оптимизирати провјеру и прескочити читање података низа за тај случај.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ово је бит магија еквивалентно: б <128 ||б>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Конвертује одрезак низа у бајтни пресек.
    /// Да бисте бајтни пресек претворили назад у низ низа, користите функцију Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // БЕЗБЕДНОСТ: цонст звук јер трансформишемо две врсте са истим распоредом
        unsafe { mem::transmute(self) }
    }

    /// Претвара променљиви пресек низа у променљиви бајтни пресек.
    ///
    /// # Safety
    ///
    /// Позиватељ мора осигурати да је садржај пресека важећи Кс00Кс пре него што се позајмица заврши и да се користи основни Кс01Кс.
    ///
    ///
    /// Коришћење Кс00Кс чији садржај није важећи Кс01Кс је недефинисано понашање.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // БЕЗБЕДНОСТ: ливење са Кс01Кс на Кс02Кс је сигурно од Кс00Кс
        // има исти изглед као Кс00Кс (само либстд може дати ову гаранцију).
        // Преусмјеравање показивача је сигурно јер долази из промјењиве референце која загарантовано вриједи за уписе.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Претвара кришка низа у сирови показивач.
    ///
    /// Како су делови низа део бајтова, необрађени показивач показује на Кс00Кс.
    /// Овај показивач ће усмерити на први бајт пресека низа.
    ///
    /// Позиватељ мора осигурати да враћени показивач никада не буде уписан.
    /// Ако требате мутирати садржај пресека низа, користите Кс00Кс.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Претвара променљиву кришку низа у сирови показивач.
    ///
    /// Како су делови низа део бајтова, необрађени показивач показује на Кс00Кс.
    /// Овај показивач ће усмерити на први бајт пресека низа.
    ///
    /// Ваша је одговорност осигурати да се кришка низа модификује само на начин да остане валидан Кс00Кс.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Враћа подрезан Кс00Кс.
    ///
    /// Ово је непанична алтернатива индексирању Кс00Кс.
    /// Враћа Кс00Кс кад год би еквивалентна операција индексирања била З0паниц0З.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // индекси који нису на границама секвенце Кс00Кс
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ван граница
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Приказује променљиву подклизницу Кс00Кс.
    ///
    /// Ово је непанична алтернатива индексирању Кс00Кс.
    /// Враћа Кс00Кс кад год би еквивалентна операција индексирања била З0паниц0З.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // тачна дужина
    /// assert!(v.get_mut(0..5).is_some());
    /// // ван граница
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Приказује непроверену подклизу Кс00Кс.
    ///
    /// Ово је непроверена алтернатива индексирању Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позиваоци ове функције одговорни су за испуњење ових предуслова:
    ///
    /// * Почетни индекс не сме бити већи од завршног индекса;
    /// * Индекси морају бити у границама оригиналног пресека;
    /// * Индекси морају лежати на границама секвенце Кс00Кс.
    ///
    /// Ако то не успе, враћени исечак низа може се позивати на неваљану меморију или кршити инваријанте саопштене типом Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Приказује променљиву, непроверену подрезу Кс00Кс.
    ///
    /// Ово је непроверена алтернатива индексирању Кс00Кс.
    ///
    /// # Safety
    ///
    /// Позиваоци ове функције одговорни су за испуњење ових предуслова:
    ///
    /// * Почетни индекс не сме бити већи од завршног индекса;
    /// * Индекси морају бити у границама оригиналног пресека;
    /// * Индекси морају лежати на границама секвенце Кс00Кс.
    ///
    /// Ако то не успе, враћени исечак низа може се позивати на неваљану меморију или кршити инваријанте саопштене типом Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ствара одсечак низа од другог одсечка низа, заобилазећи безбедносне провере.
    ///
    /// Ово се углавном не препоручује, користите опрезно!За сигурну алтернативу погледајте Кс01Кс и Кс00Кс.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Овај нови пресек иде од Кс02Кс до Кс01Кс, укључујући Кс03Кс, али искључујући Кс00Кс.
    ///
    /// Да бисте уместо тога добили променљиви пресек низа, погледајте метод Кс00Кс.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Позиваоци ове функције одговорни су за испуњење три предуслова:
    ///
    /// * `begin` не сме прећи Кс00Кс.
    /// * `begin` и Кс00Кс морају бити положаји бајтова унутар пресека низа.
    /// * `begin` и Кс00Кс мора лежати на границама секвенце Кс01Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ствара одсечак низа од другог одсечка низа, заобилазећи безбедносне провере.
    /// Ово се углавном не препоручује, користите опрезно!За сигурну алтернативу погледајте Кс01Кс и Кс00Кс.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Овај нови пресек иде од Кс02Кс до Кс01Кс, укључујући Кс03Кс, али искључујући Кс00Кс.
    ///
    /// Да бисте уместо тога добили непроменљиви пресек низа, погледајте метод Кс00Кс.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Позиваоци ове функције одговорни су за испуњење три предуслова:
    ///
    /// * `begin` не сме прећи Кс00Кс.
    /// * `begin` и Кс00Кс морају бити положаји бајтова унутар пресека низа.
    /// * `begin` и Кс00Кс мора лежати на границама секвенце Кс01Кс.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс;
        // пресек се не може препознати, јер је Кс00Кс сигурна референца.
        // Враћени показивач је сигуран јер импулси Кс00Кс морају да гарантују да јесте.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Подијелите један одсјечак низа на два у индексу.
    ///
    /// Аргумент, Кс00Кс, требао би бити помак бајтова од почетка низа.
    /// Такође мора бити на граници Кс00Кс кодне тачке.
    ///
    /// Два враћена пресека иду од почетка пресека низа до Кс00Кс, а од Кс01Кс до краја низа низа.
    ///
    /// Да бисте уместо тога добили променљиве кришке низа, погледајте метод Кс00Кс.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако се Кс00Кс не налази на граници Кс01Кс кодне тачке или ако је прошао крај последње тачке кода кришка низа.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // ис_цхар_боундари проверава да ли је индекс у [0, .len()]
        if self.is_char_boundary(mid) {
            // БЕЗБЕДНОСТ: управо сам проверио да ли је Кс00Кс на граници знакова.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Поделите једну променљиву кришку низа на две у индексу.
    ///
    /// Аргумент, Кс00Кс, требао би бити помак бајтова од почетка низа.
    /// Такође мора бити на граници Кс00Кс кодне тачке.
    ///
    /// Два враћена пресека иду од почетка пресека низа до Кс00Кс, а од Кс01Кс до краја низа низа.
    ///
    /// Да бисте уместо тога добили непроменљиве делове низа, погледајте метод Кс00Кс.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако се Кс00Кс не налази на граници Кс01Кс кодне тачке или ако је прошао крај последње тачке кода кришка низа.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // ис_цхар_боундари проверава да ли је индекс у [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // БЕЗБЕДНОСТ: управо сам проверио да ли је Кс00Кс на граници знакова.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Враћа итератор преко [`цхар`] с одсечка низа.
    ///
    /// Како се одсечак низа састоји од важећег Кс01Кс, можемо прелазити низ одсека низа до Кс00Кс.
    /// Ова метода враћа такав итератор.
    ///
    /// Важно је запамтити да Кс00Кс представља скаларну вредност Уницоде-а и можда се неће подударати са вашом представом о томе шта је Кс01Кс.
    ///
    /// Понављање гроздова графема може бити оно што заправо желите.
    /// Ову функционалност не пружа стандардна библиотека З0Руст0З, уместо тога проверите Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Запамтите, [`цхар`] с се можда неће подударати са вашом интуицијом о ликовима:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // не Кс00Кс
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Враћа итератор преко [`цхар`] с одсечка низа и њихових положаја.
    ///
    /// Како се одсечак низа састоји од важећег Кс01Кс, можемо прелазити низ одсека низа до Кс00Кс.
    /// Ова метода враћа итератор оба ова [`цхар`]-а, као и њихове позиције бајтова.
    ///
    /// Итератор даје корице.Позиција је прва, а Кс00Кс је друга.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Запамтите, [`цхар`] с се можда неће подударати са вашом интуицијом о ликовима:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // не (0, Кс00Кс)
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // имајте на уму овде 3, последњи знак заузео је два бајта
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Итератор преко бајтова одсечка низа.
    ///
    /// Како се низ низа састоји од низа бајтова, можемо се бајтирати кроз низ крижаних низова.
    /// Ова метода враћа такав итератор.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Дијели низ низа размаком.
    ///
    /// Враћени итератор вратит ће кришке низа које су подрезови изворне кришке низа, одвојене било којом количином размака.
    ///
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    /// Ако уместо тога желите да поделите само размаке АСЦИИ, користите Кс00Кс.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// У обзир се узимају све врсте празних простора:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Дијели низ низа АСЦИИ размаком.
    ///
    /// Враћени итератор вратит ће кришке низова који су подрезови оригиналне кришке низа, одвојене било којом количином размака АСЦИИ.
    ///
    ///
    /// Да бисте уместо тога поделили Уницоде Кс01Кс, користите Кс00Кс.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// У обзир се узимају све врсте АСЦИИ празних простора:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Итератор преко линија низа, као кришке низа.
    ///
    /// Линије се завршавају или новом линијом Кс01Кс или повратом кочије са додавањем линије Кс00Кс.
    ///
    /// Завршни крај реда није обавезан.
    /// Низ који се завршава завршним редом враћаће се истим редовима као иначе идентичан низ без завршног завршетка реда.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Завршни крај реда није потребан:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Итератор преко линија низа.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Враћа итератор Кс01Кс преко низа кодираног као Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Приказује Кс00Кс ако се задати образац подудара са овим подрезом овог низа.
    ///
    /// Враћа Кс00Кс ако није.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Приказује Кс00Кс ако се задати образац подудара са префиксом овог дела низа.
    ///
    /// Враћа Кс00Кс ако није.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Приказује Кс00Кс ако се задати образац подудара са суфиксом овог дела низа.
    ///
    /// Враћа Кс00Кс ако није.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Приказује бајтни индекс првог знака овог одсечка низа који се подудара са узорком.
    ///
    /// Приказује Кс00Кс ако се образац не подудара.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Сложенији обрасци који користе стил и затварање без тачке:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Не налазим образац:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Приказује бајтни индекс за први знак крајњег десног подударања узорка у овом одсечку низа.
    ///
    /// Приказује Кс00Кс ако се образац не подудара.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Сложенији обрасци са затварачима:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Не налазим образац:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Итератор над поднизовима овог дела низа, одвојен знаковима који се подударају са узорком.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор биће Кс00Кс ако образац омогућава обрнуто претраживање, а Кс01Кс претрага даје исте елементе.
    /// Ово важи, на пример, за Кс01Кс, али не и за Кс00Кс.
    ///
    /// Ако образац омогућава обрнуто претраживање, али се његови резултати могу разликовати од претраживања унапред, може се користити Кс00Кс метода.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ако је образац комад знакова, поделите га при свакој појави било ког од знакова:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ако низ садржи више суседних сепаратора, на крају ћете на крају имати празне низове:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Непрекидни сепаратори одвојени су празним низом.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Сепаратори на почетку или на крају низа повезани су празним низовима.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Када се празни низ користи као сепаратор, он раздваја сваки знак у низу, заједно са почетком и крајем низа.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Непрекидни сепаратори могу довести до изненађујућег понашања када се размак користи као сепаратор.Овај код је тачан:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Добија вам Кс00Кс:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// За ово понашање користите Кс00Кс.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Итератор над поднизовима овог дела низа, одвојен знаковима који се подударају са узорком.
    /// Разликује се од итератора који је произвео Кс00Кс у томе што Кс01Кс одговара подударном делу као завршник под низа.
    ///
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ако се подудара са последњим елементом низа, тај елемент ће се сматрати завршником претходног подниза.
    /// Тај подниз ће бити последња ставка коју је вратио итератор.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Итератор над поднизовима датог пресека низа, одвојен знаковима који се подударају са узорком и дају обрнутим редоследом.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор захтева да образац подржава обрнуто претраживање и то ће бити Кс00Кс ако претрага Кс01Кс даје исте елементе.
    ///
    ///
    /// За итерацију са предње стране може се користити Кс00Кс метода.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Итератор над поднизовима датог пресека низа, одвојен знаковима подударним са узорком.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Еквивалентно Кс00Кс, осим што се пратећи подниз прескаче ако је празан.
    ///
    /// [`split`]: str::split
    ///
    /// Ова метода се може користити за низ података који су Кс00Кс, а не Кс01Кс по обрасцу.
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор биће Кс00Кс ако образац омогућава обрнуто претраживање, а Кс01Кс претрага даје исте елементе.
    /// Ово важи, на пример, за Кс01Кс, али не и за Кс00Кс.
    ///
    /// Ако образац омогућава обрнуто претраживање, али се његови резултати могу разликовати од претраживања унапред, може се користити Кс00Кс метода.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Итератор над поднизовима Кс00Кс, одвојен знаковима који се подударају са узорком и дају обрнутим редоследом.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Еквивалентно Кс00Кс, осим што се пратећи подниз прескаче ако је празан.
    ///
    /// [`split`]: str::split
    ///
    /// Ова метода се може користити за низ података који су Кс00Кс, а не Кс01Кс по обрасцу.
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор захтева да образац подржава обрнуто претраживање и биће двоструко завршен ако Кс00Кс претрага да исте елементе.
    ///
    ///
    /// За итерацију са предње стране може се користити Кс00Кс метода.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Итератор над поднизовима датог пресека низа, одвојен узорком, ограничен на враћање највише Кс00Кс ставки.
    ///
    /// Ако се врате поднизови Кс00Кс, последњи подниз (`н`ти подниз) садржаће остатак низа.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор неће бити двоструко завршен, јер није ефикасан за подршку.
    ///
    /// Ако образац омогућава обрнуто претраживање, може се користити Кс00Кс метода.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Итератор над поднизовима овог дела низа, одвојен узорком, почевши од краја низа, ограничен на враћање највише Кс00Кс ставки.
    ///
    ///
    /// Ако се врате поднизови Кс00Кс, последњи подниз (`н`ти подниз) садржаће остатак низа.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор неће бити двоструко завршен, јер није ефикасан за подршку.
    ///
    /// За цепање са предње стране може се користити Кс00Кс метода.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Дијели низ при првом појављивању наведеног граничника и враћа префикс прије граничника и суфикс након граничника.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Дијели низ на посљедњем појављивању наведеног граничника и враћа префикс прије граничника и суфикс након граничника.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Итератор преко дисјунктних подударања узорка унутар датог пресека низа.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор биће Кс00Кс ако образац омогућава обрнуто претраживање, а Кс01Кс претрага даје исте елементе.
    /// Ово важи, на пример, за Кс01Кс, али не и за Кс00Кс.
    ///
    /// Ако образац омогућава обрнуто претраживање, али се његови резултати могу разликовати од претраживања унапред, може се користити Кс00Кс метода.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Итератор преко дисјунктних подударања узорка унутар овог низа низа, дат обрнутим редоследом.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор захтева да образац подржава обрнуто претраживање и то ће бити Кс00Кс ако претрага Кс01Кс даје исте елементе.
    ///
    ///
    /// За итерацију са предње стране може се користити Кс00Кс метода.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Итератор преко дисјунктних подударања узорка унутар овог низа низа, као и индекса на којем подударање започиње.
    ///
    /// За подударања Кс00Кс унутар Кс01Кс која се преклапају, враћају се само индекси који одговарају првом подударању.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор биће Кс00Кс ако образац омогућава обрнуто претраживање, а Кс01Кс претрага даје исте елементе.
    /// Ово важи, на пример, за Кс01Кс, али не и за Кс00Кс.
    ///
    /// Ако образац омогућава обрнуто претраживање, али се његови резултати могу разликовати од претраживања унапред, може се користити Кс00Кс метода.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // само први Кс00Кс
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Итератор преко раздвојених подударања узорка унутар Кс00Кс, давао се обрнутим редоследом заједно са индексом подударања.
    ///
    /// За подударања Кс00Кс унутар Кс01Кс која се преклапају, враћају се само индекси који одговарају последњем поклапању.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Понашање итератора
    ///
    /// Враћени итератор захтева да образац подржава обрнуто претраживање и то ће бити Кс00Кс ако претрага Кс01Кс даје исте елементе.
    ///
    ///
    /// За итерацију са предње стране може се користити Кс00Кс метода.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // само последњи Кс00Кс
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Даје резање низа са уклоњеним празним простором који води и крај.
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Приказује низ низа са уклоњеним празним простором.
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// `start` у овом контексту значи прва позиција тог бајт низа;за језик слева удесно попут енглеског или руског ово ће бити лева страна, а за језике здесна улево попут арапског или хебрејског ово ће бити десна страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Приказује низ низа са уклоњеним празним размаком.
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// `end` у овом контексту значи последња позиција тог бајт низа;за језик слева удесно попут енглеског или руског ово ће бити десна страна, а за језике здесна улево попут арапског или хебрејског ово ће бити лева страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Приказује низ низа са уклоњеним празним простором.
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// 'Left' у овом контексту значи прва позиција тог бајт низа;за језик попут арапског или хебрејског који су " здесна налево`, а не " лево на десно`, ово ће бити Кс00Кс страна, а не лева.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Приказује низ низа са уклоњеним празним размаком.
    ///
    /// 'Whitespace' дефинисан је према условима Уницоде изведеног основног својства Кс00Кс.
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// 'Right' у овом контексту значи последња позиција тог бајт низа;за језик попут арапског или хебрејског који су " здесна налево`, а не " лево на десно`, ово ће бити Кс00Кс, а не десна страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Враћа кришку низа са свим префиксима и суфиксима који се подударају са узорком који је више пута уклоњен.
    ///
    /// Кс01Кс може бити Кс00Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Запамтите најранију познату утакмицу, исправите је испод ако
            // последњи меч је другачији
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕЗБЕДНОСТ: Познато је да Кс00Кс враћа важеће индексе.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Приказује низ низа са свим префиксима који се подударају са узорком који је више пута уклоњен.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// `start` у овом контексту значи прва позиција тог бајт низа;за језик слева удесно попут енглеског или руског ово ће бити лева страна, а за језике здесна улево попут арапског или хебрејског ово ће бити десна страна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // БЕЗБЕДНОСТ: Познато је да Кс00Кс враћа важеће индексе.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Приказује одрезак низа са уклоњеним префиксом.
    ///
    /// Ако низ започиње узорком Кс01Кс, враћа подниз након префикса умотаног у Кс00Кс.
    /// За разлику од Кс00Кс, овај метод уклања префикс тачно једном.
    ///
    /// Ако низ не започиње са Кс01Кс, враћа Кс00Кс.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Приказује одрезак низа са уклоњеним суфиксом.
    ///
    /// Ако се низ завршава узорком Кс01Кс, враћа подниз пре наставка умотаног у Кс00Кс.
    /// За разлику од Кс00Кс, овај метод уклања суфикс тачно једном.
    ///
    /// Ако се низ не завршава са Кс01Кс, враћа Кс00Кс.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Приказује низ низова са свим суфиксима који се подударају са узорком који је више пута уклоњен.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// `end` у овом контексту значи последња позиција тог бајт низа;за језик слева удесно попут енглеског или руског ово ће бити десна страна, а за језике здесна улево попут арапског или хебрејског ово ће бити лева страна.
    ///
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕЗБЕДНОСТ: Познато је да Кс00Кс враћа важеће индексе.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Приказује низ низа са свим префиксима који се подударају са узорком који је више пута уклоњен.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// 'Left' у овом контексту значи прва позиција тог бајт низа;за језик попут арапског или хебрејског који су " здесна налево`, а не " лево на десно`, ово ће бити Кс00Кс страна, а не лева.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Приказује низ низова са свим суфиксима који се подударају са узорком који је више пута уклоњен.
    ///
    /// Кс02Кс може бити Кс00Кс, Кс01Кс, део [`цхар`] с или функција или затварање које одређује да ли се знак подудара.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Усмереност текста
    ///
    /// Низ је низ бајтова.
    /// 'Right' у овом контексту значи последња позиција тог бајт низа;за језик попут арапског или хебрејског који су " здесна налево`, а не " лево на десно`, ово ће бити Кс00Кс, а не десна страна.
    ///
    ///
    /// # Examples
    ///
    /// Једноставни обрасци:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Сложенији образац, користећи затварач:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Анализира овај одсечак низа на други тип.
    ///
    /// Будући да је Кс00Кс тако опћенит, може довести до проблема са закључивањем типа.
    /// Као такав, Кс01Кс је један од ретких случајева када ћете видети синтаксу која је од миља позната као Кс00Кс: `::<>`.
    ///
    /// Ово помаже алгоритму закључивања да конкретно разуме који тип покушавате да рашчланите.
    ///
    /// `parse` може рашчланити на било који тип који имплементира Кс00Кс З0 Портраит0З.
    ///

    /// # Errors
    ///
    /// Вратиће Кс00Кс ако није могуће рашчланити овај одсечак низа на жељени тип.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Основна употреба
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Коришћење Кс01Кс уместо коментарисања Кс00Кс:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Анализа није успела:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Проверава да ли су сви знакови у овом низу унутар АСЦИИ опсега.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Овде можемо сваки бајт третирати као карактер: сви вишебајтни знакови почињу са бајтом који није у асции опсегу, па ћемо се тамо већ зауставити.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Проверава да ли се две жице не подударају са малим и малим словима у АСЦИИ.
    ///
    /// Исто као Кс00Кс, али без додељивања и копирања времена.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Претвара овај низ у његов АСЦИИ еквивалент великог слова уместо њега.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову велику почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // БЕЗБЕДНОСТ: сигурно, јер трансформишемо две врсте са истим распоредом.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Претвара овај низ у његов АСЦИИ еквивалент малим словима уместо њега.
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте вратили нову малу почетну вредност без модификовања постојеће, користите Кс00Кс.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // БЕЗБЕДНОСТ: сигурно, јер трансформишемо две врсте са истим распоредом.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Вратите итератор који избегава сваки знак у Кс01Кс са Кс00Кс.
    ///
    ///
    /// Note: бит ће заштићене само проширене графемске кодне тачке које започињу низ.
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Вратите итератор који избегава сваки знак у Кс01Кс са Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Вратите итератор који избегава сваки знак у Кс01Кс са Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Као итератор:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Коришћење Кс00Кс директно:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Оба су еквивалентна:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Коришћење Кс00Кс:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Ствара празан стр
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ствара празну променљиву стр
    #[inline]
    fn default() -> Self {
        // БЕЗБЕДНОСТ: Празни низ је важећи Кс00Кс.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Именљиви, клонирани фн тип
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // БЕЗБЕДНОСТ: није сигурно
        unsafe { from_utf8_unchecked(bytes) }
    };
}