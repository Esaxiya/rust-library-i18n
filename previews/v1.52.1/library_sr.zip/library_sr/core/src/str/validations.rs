//! Операције повезане са Кс00Кс валидацијом.

use crate::mem;

use super::Utf8Error;

/// Враћа почетни акумулатор кодне тачке за први бајт.
/// Први бајт је посебан, само треба доњих 5 бита за ширину 2, 4 бита за ширину 3 и 3 бита за ширину 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Враћа вредност Кс01Кс ажуриране са бајтом наставка Кс00Кс.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Проверава да ли је бајт Кс00Кс наставак бајта (тј. Започиње битовима Кс01Кс).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Очитава следећу тачку кода из бајт-итератора (под претпоставком да има кодирање налик УТФ-8).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Децоде Кс00Кс
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Мултибајтни случај прати Децоде из комбинације бајтова од: Кс00Кс з] в]
    //
    // NOTE: Перформансе су овде осетљиве на тачну формулацију
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] в] случај
        // 5. бит у Кс01Кс .. Кс00Кс је увек јасан, па Кс02Кс и даље важи
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] кућиште користите само доња 3 бита Кс00Кс
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Очитава последњу тачку кода из бајт-итератора (под претпоставком да има кодирање налик УТФ-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Децоде Кс00Кс
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Мултибајтни случај прати Децоде из комбинације бајтова од: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// користите скраћивање да уклопите Кс00Кс у величину
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Приказује Кс00Кс ако је било који бајт у речи Кс01Кс ненасции (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Шетња кроз Кс00Кс проверавајући да ли је то ваљана секвенца Кс01Кс, враћајући Кс02Кс у том случају или, ако је неваљана, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // били су нам потребни подаци, али није их било: грешка!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Кодирање од 2 бајта је за кодне тачке\у {0080} до\у {07фф} први Кс00Кс 80 последњи ДФ БФ
            // Кодирање од 3 бајта је за кодне тачке\у {0800} до\у {фффф} прве Кс00Кс Кс01Кс 80 последње ЕФ БФ БФ искључујући сурогатне кодне тачке\у {д800} до\у {дффф} ЕД Кс02Кс 80 до ЕД БФ БФ
            // Кодирање од 4 бајта је за кодне тачке\у {1000} 0 до\у {10фф} фф први Кс00Кс 90 80 80 последњи Кс01Кс 8Ф БФ БФ
            //
            // Користите Кс00Кс синтаксу из РФЦ-а
            //
            // https://tools.ietf.org/html/rfc3629
            // УТФ8-1=% к00-7Ф УТФ8-2=% кЦ2-ДФ УТФ8-реп УТФ8-3=Кс01Кс% кА0-БФ УТФ8-реп/% кЕ1-ЕЦ Кс02Кс/Кс03Кс% к80-9Ф УТФ8-реп/% кЕЕ-ЕФ Кс04Кс УТФ8-4=Кс05Кс% к90-БФ Кс06Кс/% кФ1-Ф3 Кс07Кс/Кс08Кс% к80-8Ф Кс00Кс
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // У случају Асции, покушајте да брзо прескочите напред.
            // Када је показивач поравнат, прочитајте 2 речи података по итерацији док не пронађемо реч која садржи не-асции бајт.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // БЕЗБЕДНОСТ: пошто су Кс00Кс и Кс01Кс
                    // вишеструки од Кс01Кс, Кс02Кс је увек поравнат са Кс03Кс, тако да је сигурно преусмерити Кс04Кс и Кс00Кс.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // разбити ако постоји нонасции бајт
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // корак од тачке на којој се зауставила петља словима
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Дати први бајт, одређује колико бајтова има овај Кс00Кс знак.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Маска вредносних битова бајта наставка.
const CONT_MASK: u8 = 0b0011_1111;
/// Вредност битова ознаке (маска ознаке је Кс00Кс) настављеног бајта.
const TAG_CONT_U8: u8 = 0b1000_0000;

// скрати Кс00Кс на дужину која је највише једнака Кс01Кс врати Кс02Кс ако је скраћен, а нова стр.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}