use crate::future::Future;

/// Конверзија у Кс00Кс.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Излаз који ће З0футуре0З произвести по завршетку.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// У коју врсту З0футуре0З претварамо ово?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Ствара З0футуре0З од вредности.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}