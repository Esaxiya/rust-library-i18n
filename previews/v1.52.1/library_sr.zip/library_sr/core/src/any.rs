//! Овај модул имплементира Кс00Кс З0 Портраит0З, који омогућава динамичко куцање било ког типа Кс01Кс кроз време одражавања.
//!
//! `Any` сам се може користити за добијање Кс00Кс и има више функција када се користи као З0 Портраит0З објекат.
//! Као Кс00Кс (позајмљени објекат З0 Портраит0З), он има методе Кс01Кс и Кс02Кс, да тестира да ли је садржана вредност датог типа и да добије референцу на унутрашњу вредност као тип.
//! Као Кс00Кс, постоји и Кс01Кс метода за добијање променљиве референце на унутрашњу вредност.
//! `Box<dyn Any>` додаје метод Кс01Кс, који покушава да претвори у Кс00Кс.
//! Потпуне детаље потражите у документацији Кс00Кс.
//!
//! Имајте на уму да је Кс00Кс ограничен на тестирање да ли је вредност одређеног типа бетона и не може се користити за тестирање да ли нека врста примењује З0 Портраит0З.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Паметни показивачи и Кс00Кс
//!
//! Једно понашање које треба имати на уму када користите Кс01Кс као З0 Портраит0З објекат, посебно код типова попут Кс02Кс или Кс00Кс, јесте да ће једноставно позивање Кс03Кс на вредност произвести Кс04Кс *контејнера*, а не основни З0 Портраит0З објекат.
//!
//! То се може избећи претварањем паметног показивача у Кс01Кс, који ће вратити Кс00Кс објекта.
//! На пример:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Вероватније је да ћете желети ово:
//! let actual_id = (&*boxed).type_id();
//! // ... од овог:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Размотримо ситуацију у којој желимо да одјавимо вредност прослеђену функцији.
//! Знамо вредност на којој радимо имплементира програм за отклањање грешака, али не знамо његову конкретну врсту.Одређеним врстама желимо дати посебан третман: у овом случају исписујемо дужину вредности низа пре њихове вредности.
//! Не знамо конкретан тип наше вредности у време компајлирања, па уместо тога морамо да користимо рефлексију времена извођења.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Логгер функција за било који тип који имплементира отклањање грешака.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Покушајте да претворите нашу вредност у Кс00Кс.
//!     // Ако успе, желимо да изнесемо дужину низа као и његову вредност.
//!     // Ако не, то је друга врста: само је одштампајте без украса.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ова функција жели да одјави свој параметар пре него што започне са радом.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ради неки други посао
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Било који З0 Портраит0З
///////////////////////////////////////////////////////////////////////////////

/// З0 Портраит0З за опонашање динамичког куцања.
///
/// Већина типова имплементира Кс00Кс.Међутим, било који тип који садржи не-"статичну" референцу не садржи.
/// Погледајте Кс00Кс за више детаља.
///
/// [mod]: crate::any
// Овај З0 Портраит0З није небезбедан, иако се ослањамо на специфичности функције Кс01Кс свог искључивог импл-а у несигурном коду (нпр. Кс03Кс).То би обично био проблем, али с обзиром на то да је једина импликација Кс02Кс општа примена, ниједан други код не може применити Кс00Кс.
//
// Вероватно бисмо могли учинити овај З0 Портраит0З небезбедним-не би проузроковао лом, јер контролирамо све примене-али одлучујемо да то не учинимо, јер то у ствари није неопходно и може збунити кориснике око разлике небезбедних З0траитс0З и небезбедних метода (тј. Кс00Кс би и даље било сигурно назвати, али бисмо вероватно желели да га наведемо у документацији).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Добија Кс01Кс од Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Методе продужења за било које З0 Портраит0З објекте.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Уверите се да се резултат нпр. Спајања нити може одштампати и стога користити са Кс00Кс.
// Можда на крају више неће бити потребан ако слање функционише са надоградњом.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Приказује Кс01Кс ако је уоквирени тип исти као Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Набавите Кс00Кс типа са којим је покренута ова функција.
        let t = TypeId::of::<T>();

        // Набавите Кс01Кс типа у З0 Портраит0З објекту Кс00Кс.
        let concrete = self.type_id();

        // Упоредите оба `ТипеИд`-а о једнакости.
        t == concrete
    }

    /// Приказује неку референцу на уоквирену вредност ако је типа Кс00Кс или Кс01Кс ако није.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЕЗБЕДНОСТ: управо смо проверили да ли показујемо тачан тип и можемо се ослонити
            // та провера сигурности меморије јер смо применили Ани за све типове;ниједан други импулс не може постојати јер би се сукобио са нашим импл.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Приказује неку променљиву референцу на уоквирену вредност ако је типа Кс00Кс или Кс01Кс ако није.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЕЗБЕДНОСТ: управо смо проверили да ли показујемо тачан тип и можемо се ослонити
            // та провера сигурности меморије јер смо применили Ани за све типове;ниједан други импулс не може постојати јер би се сукобио са нашим импл.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Преусмерава се на метод дефинисан на типу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ТипеИД и његове методе
///////////////////////////////////////////////////////////////////////////////

/// Кс00Кс представља глобално јединствени идентификатор типа.
///
/// Сваки Кс00Кс је непрозирни објекат који не дозвољава преглед онога што је унутра, али омогућава основне операције као што су клонирање, упоређивање, штампање и приказивање.
///
///
/// Кс01Кс је тренутно доступан само за типове који приписују Кс00Кс, али ово ограничење може бити уклоњено у З0футуре0З.
///
/// Иако Кс03Кс примењује Кс00Кс, Кс01Кс и Кс02Кс, вреди напоменути да ће се хеши и редослед разликовати између издања З0Руст0З.
/// Чувајте се ослањања на њих унутар вашег кода!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Враћа Кс00Кс типа са којим је ова генеричка функција покренута.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Враћа име типа као низ низа.
///
/// # Note
///
/// Ово је намењено за дијагностичку употребу.
/// Тачан садржај и формат враћеног низа нису наведени, осим што су то најбољи опис типа.
/// На пример, међу низовима које би Кс01Кс могао вратити су Кс02Кс и Кс00Кс.
///
///
/// Враћени низ не сме се сматрати јединственим идентификатором типа, јер се више типова може пресликати на исто име типа.
/// Слично томе, не постоји гаранција да ће се сви делови типа појавити у враћеном низу: на пример, спецификатори животног века тренутно нису укључени.
/// Поред тога, излаз се може мењати између верзија компајлера.
///
/// Тренутна имплементација користи исту инфраструктуру као дијагностика компајлера и дебугинфо, али то није загарантовано.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Враћа име типа вредности која је уперена у облику низа низа.
/// Ово је исто као Кс00Кс, али се може користити тамо где тип променљиве није лако доступан.
///
/// # Note
///
/// Ово је намењено за дијагностичку употребу.Тачан садржај и формат низа нису наведени, осим што представљају најбољи опис врсте.
/// На пример, Кс02Кс може да врати Кс03Кс или Кс01Кс, али не и Кс00Кс.
///
/// Поред тога, излаз се може мењати између верзија компајлера.
///
/// Ова функција не решава З0 Портраит0З објекте, што значи да Кс02Кс може вратити Кс01Кс, али не и Кс00Кс.
///
/// Име типа не треба сматрати јединственим идентификатором типа;
/// више типова може да дели исто име типа.
///
/// Тренутна имплементација користи исту инфраструктуру као дијагностика компајлера и дебугинфо, али то није загарантовано.
///
/// # Examples
///
/// Штампа задате целобројне и флоат типове.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}