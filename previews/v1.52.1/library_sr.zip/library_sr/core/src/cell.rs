//! Променљиви контејнери који се могу делити.
//!
//! Сигурност З0Руст0З меморије заснива се на овом правилу: С обзиром на објекат Кс00Кс, могуће је имати само једно од следећег:
//!
//! - Имати неколико непроменљивих референци Кс00Кс на објекат (такође познат као **алиасинг**).
//! - Имати једну променљиву референцу (`&мут Т`) на објекат (такође познату као **променљивост**).
//!
//! Ово намеће компајлер З0Руст0З.Међутим, постоје ситуације у којима ово правило није довољно флексибилно.Понекад је потребно имати више референци на објекат, а опет мутирати.
//!
//! Постоје изменљиви променљиви контејнери који омогућавају променљивост на контролисан начин, чак и у присуству алиаса.И Кс00Кс и Кс01Кс омогућавају ово на један навој.
//! Међутим, ни Кс00Кс ни Кс01Кс нису заштићени нити (не примењују Кс02Кс).
//! Ако требате направити алиас и мутацију између више нити, могуће је користити типове Кс00Кс, Кс01Кс или Кс02Кс.
//!
//! Вредности типова Кс00Кс и Кс01Кс могу се мутирати кроз дељене референце (тј
//! уобичајени тип Кс00Кс), док се већина типова З0Руст0З може мутирати само путем јединствених (`&мут Т`) референци.
//! Кажемо да Кс00Кс и Кс01Кс пружају " унутрашњу променљивост`, за разлику од типичних типова З0Руст0З који показују " наследну променљивост`.
//!
//! Типови ћелија имају два укуса: Кс02Кс и Кс01Кс.Кс03Кс примењује унутрашњу променљивост премештањем вредности у и из Кс00Кс.
//! Да би се користиле референце уместо вредности, мора се користити тип Кс01Кс, који пре закључавања мутације добија закључавање уписа.Кс00Кс пружа методе за преузимање и промену тренутне унутрашње вредности:
//!
//!  - За типове који примењују Кс00Кс, метода Кс01Кс преузима тренутну унутрашњу вредност.
//!  - За типове који примењују Кс00Кс, метода Кс01Кс замењује тренутну унутрашњу вредност са Кс02Кс и враћа замењену вредност.
//!  - За све типове, метода Кс00Кс замењује тренутну унутрашњу вредност и враћа замењену вредност, а метода Кс01Кс троши Кс02Кс и враћа унутрашњу вредност.
//!  Поред тога, Кс00Кс метода замењује унутрашњу вредност, испуштајући замењену вредност.
//!
//! `RefCell<T>` користи животни век З0Руст0З за примену " динамичког позајмљивања`, процеса у коме се може захтевати привремени, ексклузивни, променљиви приступ унутрашњој вредности.
//! Позајмљује за `РефЦелл<T>`с се прате 'током извођења', за разлику од матичних типова референци З0Руст0З који се у потпуности прате статички, у време компајлирања.
//! Будући да су позајмице Кс00Кс динамичне, могуће је покушати позајмити вредност која је већ променљиво позајмљена;када се ово догоди, то резултира нити З0паниц0З.
//!
//! # Када одабрати унутрашњу променљивост
//!
//! Чешћа наслеђена променљивост, где човек мора имати јединствени приступ за мутирање вредности, један је од кључних језичких елемената који омогућава З0Руст0З да снажно расуђује о алиасу показивача, статички спречавајући грешке у паду.
//! Због тога је пожељна наследна променљивост, а унутрашња променљивост је крајње уточиште.
//! Будући да типови ћелија омогућавају мутацију тамо где она иначе не би била дозвољена, постоје случајеви када унутрашња променљивост може бити прикладна или чак *мора* бити употребљена, нпр.
//!
//! * Представљамо мутабилност Кс00Кс нечег непроменљивог
//! * Детаљи примене логички непроменљивих метода.
//! * Мутирајуће имплементације Кс00Кс.
//!
//! ## Представљамо мутабилност Кс00Кс нечег непроменљивог
//!
//! Многи заједнички типови паметних показивача, укључујући Кс01Кс и Кс00Кс, пружају контејнере који се могу клонирати и делити између више страна.
//! Будући да садржане вредности могу бити вишеструко алиасиране, могу се позајмити само са Кс01Кс, а не са Кс00Кс.
//! Без ћелија би било немогуће уопште мутирати податке унутар ових паметних показивача.
//!
//! Тада је врло често стављање Кс00Кс унутар дељених типова показивача како би се поново увела променљивост:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Направите нови блок да бисте ограничили опсег динамичког позајмљивања
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Имајте на уму да ако нисмо дозволили да претходно позајмљивање кеш меморије испадне из опсега, онда би наредно позајмљивање изазвало динамичку нит З0паниц0З.
//!     //
//!     // Ово је главна опасност од употребе Кс00Кс.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Имајте на уму да овај пример користи Кс01Кс, а не Кс00Кс.`РефЦелл<T>`с су за једнонитне сценарије.Размислите о коришћењу Кс02Кс или Кс03Кс ако вам је потребна заједничка променљивост у ситуацији са више нити.
//!
//! ## Детаљи примене логички непроменљивих метода
//!
//! Повремено може бити пожељно да се у АПИ-ју не изложи да се догађа мутација Кс00Кс.
//! То је можда зато што је логично да је операција непроменљива, али нпр. Кеширање приморава имплементацију да изврши мутацију;или зато што морате применити мутацију да бисте применили методу З0 Портраит0З која је првобитно дефинисана да узима Кс00Кс.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Овде иде скупо рачунање
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутирајуће имплементације Кс00Кс
//!
//! Ово је једноставно посебан, али уобичајен случај претходног: скривање променљивости за операције које се чине непроменљивим.
//! Очекује се да метода Кс02Кс неће променити изворну вредност и проглашава се да узима Кс01Кс, а не Кс00Кс.
//! Стога, свака мутација која се догоди у Кс00Кс методи мора да користи типове ћелија.
//! На пример, Кс01Кс одржава своје бројеве референци унутар Кс00Кс.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Променљива меморијска локација.
///
/// # Examples
///
/// У овом примеру можете видети да Кс00Кс омогућава мутацију унутар непроменљиве структуре.
/// Другим речима, омогућава Кс00Кс.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ГРЕШКА: Кс00Кс је непроменљив
/// // my_struct.regular_field =нова_вредност;
///
/// // ДЈЕЛА: иако је Кс02Кс непромјењив, Кс01Кс је Кс00Кс,
/// // који се увек могу мутирати
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Погледајте Кс00Кс за више.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Креира Кс00Кс, са вредностом Кс01Кс за Т.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Ствара нови Кс00Кс који садржи задату вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Поставља садржану вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Мења вредности две ћелије.
    /// Разлика са Кс00Кс је у томе што ова функција не захтева референцу Кс01Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЕЗБЕДНОСТ: Ово може бити ризично ако се зове из засебних нити, али Кс00Кс
        // је Кс00Кс па се ово неће догодити.
        // Ово такође неће онеспособити ниједан показивач, јер Кс00Кс осигурава да ништа друго не показује ни на једну од ових `ћелија`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Замењује садржану вредност са Кс00Кс и враћа стару садржану вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЕЗБЕДНОСТ: Ово може проузроковати трке података ако се позивају из посебне нити,
        // али Кс00Кс је Кс01Кс, па се ово неће догодити.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Отпакује вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Враћа копију садржане вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЕЗБЕДНОСТ: Ово може проузроковати трке података ако се позивају из посебне нити,
        // али Кс00Кс је Кс01Кс, па се ово неће догодити.
        unsafe { *self.value.get() }
    }

    /// Ажурира садржану вредност помоћу функције и враћа нову вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Враћа сирови показивач на основне податке у овој ћелији.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Враћа променљиву референцу на основне податке.
    ///
    /// Овај позив позајмљује Кс00Кс променљиво (у време компајлирања), што гарантује да поседујемо једину референцу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Приказује Кс01Кс из Кс00Кс
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЕЗБЕДНОСТ: Кс00Кс осигурава јединствени приступ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Узима вредност ћелије, остављајући Кс00Кс на свом месту.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Приказује Кс01Кс из Кс00Кс
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЕЗБЕДНОСТ: Кс01Кс има исти распоред меморије као и Кс00Кс.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Променљива меморијска локација са динамички провереним правилима позајмљивања
///
/// Погледајте Кс00Кс за више.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Грешка коју је вратио Кс00Кс.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Грешка коју је вратио Кс00Кс.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Позитивне вредности представљају број активних Кс00Кс.Негативне вредности представљају број активних Кс01Кс.
// Вишеструки `РефМут` могу истовремено бити активни само ако се односе на различите компоненте које се не преклапају (нпр. Различити опсези пресека).
//
// `Ref` и Кс00Кс су две величине две речи, па вероватно никада неће постојати довољно `Реф`-ова или`РефМут-а` да пређу половину опсега Кс01Кс.
// Дакле, Кс00Кс се вероватно никада неће прелити или прелити.
// Међутим, ово није гаранција, јер патолошки програм може више пута креирати, а затим Кс00Кс `Реф`с или`РефМут`с.
// Према томе, сав код мора изричито проверити да ли постоји прелив и прелив како би се избегла несигурност или се барем понашао исправно у случају да се догоди преливање или доливање (нпр. Погледајте Кс00Кс).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Ствара нови Кс01Кс који садржи Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Троши Кс00Кс, враћајући умотану вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Будући да ова функција узима Кс00Кс (Кс01Кс) по вредности, преводилац статички проверава да тренутно није позајмљен.
        //
        self.value.into_inner()
    }

    /// Замењује умотану вредност новом, враћајући стару вредност, без деиницијализације било које.
    ///
    ///
    /// Ова функција одговара Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно позајмљена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Замењује умотану вредност новом израчунатом из Кс00Кс, враћајући стару вредност, без деиницијализације било које.
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно позајмљена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Замењује умотану вредност Кс01Кс са умотаном вредношћу Кс00Кс, без деиницијализације било које.
    ///
    ///
    /// Ова функција одговара Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Непроменљиво позајмљује умотану вредност.
    ///
    /// Позајмица траје док враћени Кс00Кс не изађе из опсега.
    /// Истовремено се може узети више непроменљивих позајмица.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно променљиво позајмљена.
    /// За варијанту која не изазива панику, користите Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Пример З0паниц0З:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Неизменљиво позајмљује умотану вредност, враћајући грешку ако је вредност тренутно променљиво позајмљена.
    ///
    ///
    /// Позајмица траје док враћени Кс00Кс не изађе из опсега.
    /// Истовремено се може узети више непроменљивих позајмица.
    ///
    /// Ово је непанична варијанта Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЕЗБЕДНОСТ: Кс00Кс осигурава само непроменљиви приступ
            // на вредност док је позајмљена.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Променљиво позајмљује умотану вредност.
    ///
    /// Позајмљивање траје до враћеног Кс00Кс или свих `РефМут-ова изведених из опсега изласка.
    ///
    /// Вредност се не може позајмити док је ова позајмица активна.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно позајмљена.
    /// За варијанту која не изазива панику, користите Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Пример З0паниц0З:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Променљиво позајмљује умотану вредност, враћајући грешку ако је вредност тренутно позајмљена.
    ///
    ///
    /// Позајмљивање траје до враћеног Кс00Кс или свих `РефМут-ова изведених из опсега изласка.
    /// Вредност се не може позајмити док је ова позајмица активна.
    ///
    /// Ово је непанична варијанта Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЕЗБЕДНОСТ: Кс00Кс гарантује јединствени приступ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Враћа сирови показивач на основне податке у овој ћелији.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Враћа променљиву референцу на основне податке.
    ///
    /// Овај позив позајмљује Кс00Кс променљиво (у време компајлирања), тако да нема потребе за динамичким проверама.
    ///
    /// Међутим, будите опрезни: овај метод очекује да ће Кс01Кс бити променљив, што обично није случај када се користи Кс00Кс.
    ///
    /// Уместо тога, погледајте Кс00Кс метод ако Кс01Кс није променљив.
    ///
    /// Такође, имајте на уму да је овај метод само за посебне околности и да обично није оно што желите.
    /// У случају сумње, користите Кс00Кс.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Поништите ефекат процурелих заштитника на стање позајмице Кс00Кс.
    ///
    /// Овај позив је сличан моделу Кс00Кс, али је специјализованији.
    /// Кс00Кс се позајмљује променљиво како би се осигурало да не постоје позајмице, а затим ресетује дељене позајмице за праћење стања.
    /// Ово је релевантно ако су процуриле неке позајмице Кс00Кс или Кс01Кс.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Неизменљиво позајмљује умотану вредност, враћајући грешку ако је вредност тренутно променљиво позајмљена.
    ///
    /// # Safety
    ///
    /// За разлику од Кс00Кс, овај метод је небезбедан јер не враћа Кс01Кс, што оставља заставицу позајмљивања нетакнутом.
    /// Заменљиво позајмљивање Кс00Кс док је референца враћена овом методом жива је недефинисано понашање.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЕЗБЕДНОСТ: Проверавамо да нико сада активно не пише, али јесте
            // одговорност позиваоца да осигура да нико не пише док враћена референца више не буде у употреби.
            // Такође, Кс01Кс се односи на вредност коју поседује Кс02Кс и због тога се гарантује да ће важити током века трајања Кс00Кс.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Узима умотану вредност, остављајући Кс00Кс на свом месту.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно позајмљена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност тренутно променљиво позајмљена.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Креира Кс00Кс, са вредностом Кс01Кс за Т.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// З0Паницс0З ако је вредност у било ком од Кс00Кс тренутно позајмљена.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Повећавање позајмице може довести до нечитања вредности (<=0) у следећим случајевима:
            // 1. Било је <0, тј. Постоје позајмице за писање, тако да не можемо дозволити позајмљено читање због З0Руст0З-ових правила алиасинга референци
            // 2.
            // То је био Кс00Кс (максимална количина позајмљивања за читање) и прелио се у Кс01Кс (максимални износ позајмљивања за писање), тако да не можемо дозволити додатно позајмљивање за читање, јер исизе не може представљати толико прочитаних позајмица (ово се може догодити само ако ви Кс02Кс више од мале константне количине `Реф-а`, што није добра пракса)
            //
            //
            //
            //
            None
        } else {
            // Повећавање позајмице може резултирати вредностом читања (> 0) у следећим случајевима:
            // 1. Било је=0, тј. Није позајмљено, а ми узимамо прво прочитано задуживање
            // 2. Било је> 0 и <Кс00Кс, тј
            // било је прочитаних позајмица, а исизе је довољно велик да представља још једну прочитану позајмицу
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Будући да овај Реф постоји, знамо да је застава позајмљивања позајмљивање за читање.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Спречите преливање бројача позајмица у писмено задуживање.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Умотава позајмљену референцу на вредност у поље Кс00Кс.
/// Тип омота за непроменљиво позајмљену вредност од Кс00Кс.
///
/// Погледајте Кс00Кс за више.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Копира Кс00Кс.
    ///
    /// Кс00Кс је већ непроменљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Имплементација Кс01Кс или метода ометаће широку употребу Кс02Кс за клонирање садржаја Кс00Кс.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Израђује нови Кс00Кс за компоненту позајмљених података.
    ///
    /// Кс00Кс је већ непроменљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Израђује нови Кс00Кс за опционалну компоненту позајмљених података.
    /// Оригинални штитник враћа се као Кс01Кс ако затварач врати Кс00Кс.
    ///
    /// Кс00Кс је већ непроменљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Раздваја Кс00Кс у више `Реф`-ова за различите компоненте позајмљених података.
    ///
    /// Кс00Кс је већ непроменљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Претворите у референцу на основне податке.
    ///
    /// Основни Кс00Кс се никада више не може променљиво позајмити и увек ће изгледати већ непроменљиво позајмљен.
    ///
    /// Није добра идеја пропуштати више од сталног броја референци.
    /// Кс00Кс се може поново непроменљиво позајмити ако се укупно догодио само мањи број цурења.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Заборављајући овај Реф, осигуравамо да се бројач позајмљивања у РефЦелл-у не може вратити на УНУСЕД током животног века Кс00Кс.
        // Ресетовање стања праћења референци захтевало би јединствену референцу на позајмљену РефЦелл.
        // Из оригиналне ћелије се не могу креирати даље променљиве референце.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Израђује нови Кс00Кс за компоненту позајмљених података, нпр. Варијанту набрајања.
    ///
    /// Кс00Кс је већ променљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): поправити позајмицу-чек
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Израђује нови Кс00Кс за опционалну компоненту позајмљених података.
    /// Оригинални штитник враћа се као Кс01Кс ако затварач врати Кс00Кс.
    ///
    /// Кс00Кс је већ променљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): поправити позајмицу-чек
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЕЗБЕДНОСТ: функција држи ексклузивну референцу током трајања
        // свог позива кроз Кс00Кс, а показивач је дереференциран само унутар позива функције, никада не дозвољавајући ексклузивној референци да побјегне.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЕЗБЕДНОСТ: исто као горе.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Дијели Кс00Кс на више `РефМут-ова` за различите компоненте посуђених података.
    ///
    /// Основни Кс00Кс остаће заменљиво позајмљен све док оба враћена `РефМута` не излазе из опсега.
    ///
    /// Кс00Кс је већ променљиво позајмљен, тако да ово не може да пропадне.
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Претворите у променљиву референцу на основне податке.
    ///
    /// Основни Кс00Кс не може се поново позајмити и увек ће изгледати већ променљиво посуђен, чинећи враћену референцу једином за унутрашњост.
    ///
    ///
    /// Ово је придружена функција која треба да се користи као Кс00Кс.
    /// Метода би ометала истоимене методе на садржају Кс01Кс који се користи кроз Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Заборављајући овај БорровРефМут, осигуравамо да се бројач позајмица у РефЦелл-у не може вратити на УНУСЕД током животног века Кс00Кс.
        // Ресетовање стања праћења референци захтевало би јединствену референцу на позајмљену РефЦелл.
        // Не могу се креирати даље референце из оригиналне ћелије током тог животног века, чинећи тренутну позајмицу једином референцом за преостали животни век.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: За разлику од Кс00Кс, нев се позива да креира иницијал
        // променљива референца, тако да тренутно не сме бити постојећих референци.
        // Дакле, док клон увећава променљиви бројач, овде изричито дозвољавамо само прелазак са УНУСЕД на УНУСЕД, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонира Кс00Кс.
    //
    // Ово важи само ако се сваки Кс00Кс користи за праћење променљиве референце на различит опсег оригиналног објекта који се не преклапа.
    //
    // Ово није у Цлоне импл-у, тако да га код не имплицитно позива.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Спречите да се бројач позајмљивања не излије.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Тип омота за променљиво позајмљену вредност из Кс00Кс.
///
/// Погледајте Кс00Кс за више.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Основни примитив за унутрашњу променљивост у З0Руст0З.
///
/// Ако имате референтни Кс00Кс, онда у З0Руст0З компајлер врши оптимизације на основу знања да Кс02Кс упућује на непроменљиве податке.Мутирање тих података, на пример преко псеудонима или претварањем Кс03Кс у Кс01Кс, сматра се недефинисаним понашањем.
/// `UnsafeCell<T>` онемогућавање гаранције непроменљивости за Кс01Кс: заједничка референца Кс02Кс може указивати на податке који се мутирају.Ово се зове Кс00Кс.
///
/// Све друге врсте које омогућавају унутрашњу променљивост, попут Кс01Кс и Кс00Кс, интерно користе Кс02Кс за умотавање својих података.
///
/// Имајте на уму да Кс01Кс утиче само на гаранцију непроменљивости за заједничке референце.То не утиче на гаранцију јединствености за променљиве референце.Не постоји *правни* законит начин за добијање псеудонима Кс02Кс, чак ни са Кс00Кс.
///
/// Сам АПИ Кс01Кс технички је врло једноставан: Кс00Кс вам даје сирови показивач Кс02Кс на његов садржај.До Кс03Кс као дизајнера апстракције је тачна употреба тог сировог показивача.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Прецизна правила алиасинга З0Руст0З донекле су променљива, али главне тачке нису спорне:
///
/// - Ако креирате сигурну референцу са животним веком Кс01Кс (било референцу Кс02Кс или Кс03Кс) којој је могуће приступити сигурним кодом (на пример, зато што сте је вратили), остатак не смете да приступате ни на који начин који је у супротности са том референцом за остатак од Кс00Кс.
/// На пример, то значи да ако узмете Кс02Кс са Кс03Кс и пребаците га на Кс00Кс, тада подаци у Кс04Кс морају остати непроменљиви (наравно сви модули Кс05Кс подаци пронађени у Кс01Кс) све док не истекне животни век те референце.
/// Слично томе, ако креирате Кс00Кс референцу која је пуштена у сигурни код, тада не смете приступати подацима унутар Кс01Кс док та референца не истекне.
///
/// - У сваком тренутку морате избегавати трке података.Ако више нити има приступ истом Кс00Кс, тада свако уписивање мора имати одговарајући однос пре свих осталих приступа (или користити атомику).
///
/// Да би се помогло у правилном дизајну, следећи сценарији су изричито проглашени легалним за једнонитни код:
///
/// 1. Референца Кс01Кс може се пребацити на сигуран код и тамо може коегзистирати са другим референцама Кс02Кс, али не и са Кс00Кс
///
/// 2. Референца Кс00Кс може бити објављена на безбедан код под условом да ни други Кс01Кс ни Кс02Кс не постоје заједно с њом.Кс03Кс мора увек бити јединствен.
///
/// Имајте на уму да, иако је мутирање садржаја Кс00Кс (чак и док други Кс01Кс референцира алиас ћелију) у реду (под условом да горе наведене инваријанте примените на неки други начин), и даље је недефинисано понашање имати више Кс02Кс псеудонима.
/// Односно, Кс02Кс је омот дизајниран да има посебну интеракцију са Кс00Кс, путем референце Кс03Кс);нема никакве магије када се ради са Кс01Кс, кроз Кс05Кс): ни ћелија ни умотана вредност не могу бити замењени током трајања тог позајмљивања Кс04Кс.
///
/// Ово приказује Кс01Кс додатак, који је Кс02Кс З0геттер0З који даје Кс00Кс.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ево примера који приказује како звучно мутирати садржај Кс00Кс упркос томе што је више референци стајало ћелију:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Набавите вишеструке/истовремене/дељене референце на исти Кс00Кс.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЕЗБЕДНОСТ: у овом опсегу нема других референци на садржај `к`-а,
///     // тако да је наш ефективно јединствен.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- позајмити-+
///     *p1_exclusive += 27; // |
/// } // <---------- не може ићи даље од ове тачке -------------------+
///
/// unsafe {
///     // БЕЗБЕДНОСТ: у оквиру овог опсега нико не очекује да има ексклузиван приступ садржају `к`-а,
///     // тако да истовремено можемо имати више заједничких приступа.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Следећи пример приказује чињеницу да ексклузивни приступ Кс01Кс подразумева ексклузивни приступ његовом Кс00Кс:
///
/// ```rust
/// #![forbid(unsafe_code)] // са ексклузивним приступима,
///                         // `UnsafeCell` је провидни но-оп омотач, тако да овде нема потребе за Кс00Кс.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Набавите јединствену референцу на Кс00Кс проверену током компајлирања.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Уз ексклузивну референцу, можемо бесплатно мутирати садржај.
/// *p_unique.get_mut() = 0;
/// // Или, еквивалентно:
/// x = UnsafeCell::new(0);
///
/// // Када поседујемо вредност, можемо бесплатно да издвојимо садржај.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Конструише нову инстанцу Кс00Кс која ће умотати наведену вредност.
    ///
    ///
    /// Сав приступ унутрашњој вредности путем метода је Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Отпакује вредност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Добија променљиви показивач на умотану вредност.
    ///
    /// Ово се може пребацити на показивач било које врсте.
    /// Уверите се да је приступ јединствен (без активних референци, променљиво или не) приликом пребацивања на Кс01Кс и уверите се да се приликом пребацивања на Кс00Кс не догађају мутације или променљиви псеудоними
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Можемо само пребацити показивач са Кс01Кс на Кс02Кс због Кс00Кс.
        // Ово користи специјални статус либстд-а, не постоји гаранција за кориснички код да ће ово функционисати у З0футуре0З верзијама компајлера!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Враћа променљиву референцу на основне податке.
    ///
    /// Овај позив позајмљује Кс00Кс променљиво (током компајлирања), што гарантује да поседујемо једину референцу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Добија променљиви показивач на умотану вредност.
    /// Разлика у односу на Кс00Кс је у томе што ова функција прихвата необрађени показивач, што је корисно за избегавање стварања привремених референци.
    ///
    /// Резултат се може пребацити на показивач било које врсте.
    /// Уверите се да је приступ јединствен (без активних референци, променљиво или не) приликом пребацивања на Кс01Кс и уверите се да се не дешавају мутације или променљиви псеудоними приликом пребацивања на Кс00Кс.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Постепена иницијализација Кс01Кс захтева Кс00Кс, јер би позивање Кс02Кс захтевало стварање референце на неиницијализоване податке:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Можемо само пребацити показивач са Кс01Кс на Кс02Кс због Кс00Кс.
        // Ово користи специјални статус либстд-а, не постоји гаранција за кориснички код да ће ово функционисати у З0футуре0З верзијама компајлера!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Креира Кс00Кс, са вредностом Кс01Кс за Т.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}