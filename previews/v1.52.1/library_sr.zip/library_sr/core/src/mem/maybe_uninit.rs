use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тип омотача за конструкцију неиницијализованих примерака Кс00Кс.
///
/// # Иницијализација инваријантна
///
/// Компајлер, генерално, претпоставља да је променљива правилно иницијализована у складу са захтевима типа променљиве.На пример, променљива референтног типа мора бити поравната и мора бити НУЛЛ.
/// Ово је инваријант који се мора увек подржавати, чак и у несигурном коду.
/// Као последица, нулта иницијализација променљиве референтног типа узрокује тренутни Кс00Кс, без обзира да ли се та референца икада користи за приступ меморији:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // недефинисано понашање!⚠
/// // Еквивалентни код са Кс00Кс:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // недефинисано понашање!⚠
/// ```
///
/// То компајлер користи за разне оптимизације, као што су уклањање провера времена извршавања и оптимизација изгледа Кс00Кс.
///
/// Слично томе, потпуно неиницијализована меморија може имати било какав садржај, док Кс01Кс увек мора бити Кс02Кс или Кс00Кс.Стога је стварање неиницијализованог Кс03Кс недефинисано понашање:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // недефинисано понашање!⚠
/// // Еквивалентни код са Кс00Кс:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // недефинисано понашање!⚠
/// ```
///
/// Штавише, неиницијализована меморија је посебна по томе што нема фиксну вредност (Кс00Кс што значи Кс01Кс).Читање истог неиницијализованог бајта више пута може дати различите резултате.
/// То чини недефинисано понашање неиницијализованим подацима у променљивој, чак иако та променљива има целобројни тип, који иначе може да садржи било који *фиксни* битни образац:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // недефинисано понашање!⚠
/// // Еквивалентни код са Кс00Кс:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // недефинисано понашање!⚠
/// ```
/// (Приметите да правила око неиницијализованих целих бројева још нису финализована, али док нису, пожељно их је избегавати.)
///
/// Поврх тога, имајте на уму да већина типова има додатне инваријанте, осим што се сматрају иницијализованим на нивоу типа.
/// На пример, Кс00Кс иницијализован са `1` сматра се иницијализованим (под тренутном имплементацијом; ово не представља стабилну гаранцију), јер једини компајлер који о њему зна јесте да показивач података мора бити не-нулл.
/// Стварање таквог Кс00Кс не узрокује *тренутно* недефинисано понашање, али ће изазвати недефинисано понашање код већине сигурних операција (укључујући његово испуштање).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служи за омогућавање несигурном коду да се бави неиницијализованим подацима.
/// То је сигнал компајлеру који указује да подаци овде *не* могу бити иницијализовани:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Направите експлицитно неиницијализовану референцу.
/// // Компајлер зна да подаци унутар Кс00Кс могу бити неваљани, па стога ово није УБ:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Поставите је на важећу вредност.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Издвојите иницијализоване податке-то је дозвољено *само након* правилне иницијализације Кс00Кс!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Компајлер тада зна да на овом коду не прави нетачне претпоставке или оптимизације.
///
/// Можете да замислите Кс00Кс као да је помало сличан Кс01Кс, али без икаквог праћења времена рада и без било каквих безбедносних провера.
///
/// ## out-pointers
///
/// Можете да користите Кс01Кс за примену Кс00Кс: уместо да вратите податке из функције, додајте јој показивач на неку меморију Кс02Кс да бисте ставили резултат.
/// Ово може бити корисно када је позиваоцу важно да контролише како се додељује меморија у којој се чува резултат, а желите да избегнете непотребне потезе.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не испушта стари садржај, што је важно.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Сада знамо да је Кс00Кс иницијализован!Ово такође осигурава да З0вецтор0З правилно падне.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Иницијализација низа елемент по елемент
///
/// `MaybeUninit<T>` може се користити за иницијализацију великог низа елемент-по-елемент:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Направите неиницијализовани низ Кс00Кс.
///     // Кс00Кс је сигуран јер је тип за који тврдимо да је овде иницијализован гомила `МаибеУнинит`-а, који не захтевају иницијализацију.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Испуштање Кс00Кс не значи ништа.
///     // Стога употреба сировог додељивања показивача уместо Кс00Кс не доводи до одбацивања старе неиницијализоване вредности.
/////
///     // Такође, ако током ове петље постоји З0паниц0З, имамо цурење меморије, али нема проблема са сигурношћу меморије.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Све је иницијализовано.
///     // Трансмутирај низ у иницијализовани тип.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Такође можете радити са делимично иницијализованим низовима, који се могу наћи у структури података ниског нивоа.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Направите неиницијализовани низ Кс00Кс.
/// // Кс00Кс је сигуран јер је тип за који тврдимо да је овде иницијализован гомила `МаибеУнинит`-а, који не захтевају иницијализацију.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Пребројите број елемената које смо доделили.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // За сваку ставку у низу испустите ако смо је доделили.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Иницијализација структуре поље по поље
///
/// Можете користити Кс00Кс и Кс01Кс макро за иницијализацију структура по пољу:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Иницијализација Кс00Кс поља
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Иницијализација Кс00Кс поља Ако овде постоји З0паниц0З, тада Кс01Кс у пољу Кс02Кс цури.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Сва поља су иницијализована, па позивамо Кс00Кс да добијемо иницијализовани Фоо.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` гарантује се да имају исту величину, поравнање и АБИ као Кс00Кс:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Међутим, имајте на уму да тип *који садржи* Кс00Кс није нужно истог изгледа;З0Руст0З генерално не гарантује да поља Кс01Кс имају исти редослед као Кс02Кс, чак и ако Кс03Кс и Кс04Кс имају исту величину и поравнање.
///
/// Даље, јер било која вредност бита важи за Кс00Кс, компајлер не може применити Кс01Кс оптимизације, што би потенцијално могло резултирати већом величином:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ако је Кс01Кс безбедан за ФФИ, онда је и Кс00Кс.
///
/// Иако је Кс00Кс Кс01Кс (што указује да гарантује исту величину, поравнање и АБИ као Кс02Кс), то *не* мења ниједно од претходних упозорења.
/// `Option<T>` и Кс01Кс и даље могу имати различите величине, а типови који садрже поље типа Кс02Кс могу се распоредити (и величине) другачије него да је то поље Кс00Кс.
/// `MaybeUninit` је тип синдиката, а Кс01Кс на синдикатима је нестабилан (види Кс00Кс.
/// Временом се могу развити тачне гаранције Кс01Кс за синдикате, а Кс02Кс може или не мора остати Кс00Кс.
/// Међутим, Кс01Кс ће *увек* гарантовати да има исту величину, поравнање и АБИ као Кс00Кс;само начин на који Кс02Кс примењује ту гаранцију може да еволуира.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Предметни језик како бисмо могли у њега умотати друге врсте.Ово је корисно за генераторе.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не позивајући Кс00Кс, не можемо знати да ли смо довољно иницијализовани за то.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ствара нови Кс00Кс иницијализован са датом вредношћу.
    /// Сигурно је позвати Кс00Кс за повратну вредност ове функције.
    ///
    /// Имајте на уму да испуштање Кс00Кс никада неће позвати `Т`-ов код за испуштање.
    /// Ваша је одговорност осигурати да Кс00Кс падне ако је иницијализиран.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Ствара нови Кс00Кс у неиницијализованом стању.
    ///
    /// Имајте на уму да испуштање Кс00Кс никада неће позвати `Т`-ов код за испуштање.
    /// Ваша је одговорност осигурати да Кс00Кс падне ако је иницијализиран.
    ///
    /// Погледајте Кс00Кс за неке примере.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Направите нови низ Кс00Кс предмета у неиницијализованом стању.
    ///
    /// Note: у верзији З0футуре0З З0Руст0З овај метод може постати непотребан када синтакса литералног низа дозвољава Кс00Кс.
    ///
    /// Пример у наставку би могао да користи Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Приказује (могуће мањи) део података који је стварно прочитан
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕЗБЕДНОСТ: Неиницијализован Кс00Кс је важећи.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Ствара нови Кс00Кс у неиницијализованом стању, са меморијом која је напуњена бајтовима Кс01Кс.Зависи од Кс02Кс да ли то већ омогућава правилну иницијализацију.
    ///
    /// На пример, Кс00Кс је иницијализован, али Кс01Кс није зато што референце не смеју бити нуле.
    ///
    /// Имајте на уму да испуштање Кс00Кс никада неће позвати `Т`-ов код за испуштање.
    /// Ваша је одговорност осигурати да Кс00Кс падне ако је иницијализиран.
    ///
    /// # Example
    ///
    /// Исправно коришћење ове функције: иницијализација структуре нулом, где сва поља структуре могу да садрже бит-образац 0 као важећу вредност.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Нетачна* употреба ове функције: позивање Кс00Кс када Кс01Кс није важећи бит-образац за тип:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Унутар пара креирамо Кс00Кс који нема важећи дискриминант.
    /// // Ово је недефинисано понашање.⚠
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕЗБЕДНОСТ: Кс00Кс показује на додељену меморију.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Поставља вредност Кс00Кс.
    /// Ово преписује било коју претходну вредност, а да је не испустите, па пазите да је не користите два пута, осим ако не желите прескочити покретање деструктора.
    ///
    /// Ради ваше удобности, ово такође враћа променљиву референцу на (сада безбедно иницијализован) садржај Кс00Кс.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕЗБЕДНОСТ: Управо смо иницијализовали ову вредност.
        unsafe { self.assume_init_mut() }
    }

    /// Добија показивач на садржану вредност.
    /// Читање из овог показивача или његово претварање у референцу је недефинисано понашање уколико Кс00Кс није иницијализован.
    /// Записивање у меморију на које указује овај показивач Кс00Кс је недефинисано понашање (осим унутар Кс01Кс).
    ///
    /// # Examples
    ///
    /// Правилна употреба ове методе:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Направите референцу за Кс00Кс.Ово је у реду јер смо га иницијализовали.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Нетачна* употреба ове методе:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Направили смо референцу на неиницијализовани З0вецтор0З!Ово је недефинисано понашање.⚠
    /// ```
    ///
    /// (Имајте на уму да правила око упућивања на неиницијализоване податке још нису довршена, али док нису, пожељно их је избегавати.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` и Кс00Кс су оба Кс01Кс, тако да можемо пребацити показивач.
        self as *const _ as *const T
    }

    /// Добија променљиви показивач на садржану вредност.
    /// Читање из овог показивача или његово претварање у референцу је недефинисано понашање уколико Кс00Кс није иницијализован.
    ///
    /// # Examples
    ///
    /// Правилна употреба ове методе:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Направите референцу за Кс00Кс.
    /// // Ово је у реду јер смо га иницијализовали.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Нетачна* употреба ове методе:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Направили смо референцу на неиницијализовани З0вецтор0З!Ово је недефинисано понашање.⚠
    /// ```
    ///
    /// (Имајте на уму да правила око упућивања на неиницијализоване податке још нису довршена, али док нису, пожељно их је избегавати.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` и Кс00Кс су оба Кс01Кс, тако да можемо пребацити показивач.
        self as *mut _ as *mut T
    }

    /// Издваја вредност из контејнера Кс00Кс.Ово је одличан начин да се осигура да подаци падну, јер резултујући Кс01Кс подлеже уобичајеном руковању падом.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да је Кс00Кс заиста у иницијализованом стању.Ово позивање када садржај још увек није у потпуности иницијализован изазива тренутно недефинисано понашање.
    /// Кс00Кс садржи више информација о овом инваријанту иницијализације.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Поврх тога, имајте на уму да већина типова има додатне инваријанте, осим што се сматрају иницијализованим на нивоу типа.
    /// На пример, Кс00Кс иницијализован са `1` сматра се иницијализованим (под тренутном имплементацијом; ово не представља стабилну гаранцију), јер једини компајлер који о њему зна јесте да показивач података мора бити не-нулл.
    ///
    /// Стварање таквог Кс00Кс не узрокује *тренутно* недефинисано понашање, али ће изазвати недефинисано понашање код већине сигурних операција (укључујући његово испуштање).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Правилна употреба ове методе:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Нетачна* употреба ове методе:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` још није био иницијализован, па је овај последњи ред изазвао недефинисано понашање.⚠
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс иницијализован.
        // То такође значи да Кс00Кс мора бити варијанта Кс01Кс.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Очитава вредност из Кс00Кс контејнера.Добијени Кс01Кс подлеже уобичајеном руковању падом.
    ///
    /// Кад год је то могуће, пожељно је користити Кс01Кс, који спречава дуплирање садржаја Кс00Кс.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да је Кс00Кс заиста у иницијализованом стању.Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање.
    /// Кс00Кс садржи више информација о овом инваријанту иницијализације.
    ///
    /// Штавише, ово оставља копију истих података у Кс00Кс.
    /// Када користите више копија података (позивањем Кс00Кс више пута или прво позивањем Кс01Кс, а затим Кс02Кс), ваша је одговорност да обезбедите да се ти подаци заиста могу дуплирати.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Правилна употреба ове методе:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` је Кс00Кс, па можемо читати више пута.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Дуплирање вредности Кс00Кс је у реду, тако да можемо читати више пута.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Нетачна* употреба ове методе:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Сада смо креирали две копије истог З0вецтор0З, што је довело до двоструког бесплатног ⚠ када обе падну!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс иницијализован.
        // Читање са Кс00Кс је сигурно јер Кс01Кс треба иницијализовати.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Спушта садржану вредност на место.
    ///
    /// Ако сте власник Кс00Кс, уместо њега можете да користите Кс01Кс.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да је Кс00Кс заиста у иницијализованом стању.Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање.
    ///
    /// Поврх тога, сви додатни инваријанти типа Кс00Кс морају бити задовољени, јер се имплементација Кс01Кс Кс02Кс (или његових чланова) може ослањати на ово.
    /// На пример, Кс00Кс иницијализован са `1` сматра се иницијализованим (под тренутном имплементацијом; ово не представља стабилну гаранцију), јер једини компајлер који о њему зна јесте да показивач података мора бити не-нулл.
    ///
    /// Међутим, испуштање таквог Кс00Кс проузроковаће недефинисано понашање.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс иницијализован и
        // задовољава све инваријанте Кс00Кс.
        // Испуштање вредности са места је сигурно ако је то случај.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Добија дељену референцу на садржану вредност.
    ///
    /// Ово може бити корисно када желимо да приступимо Кс01Кс који је иницијализован, али нема власништво над Кс02Кс (спречавајући употребу Кс00Кс.
    ///
    /// # Safety
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање: на позиваоцу је да гарантује да је Кс00Кс заиста у иницијализованом стању.
    ///
    ///
    /// # Examples
    ///
    /// ### Правилна употреба ове методе:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Иницијализујте Кс00Кс:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Сада када је познато да је наш Кс00Кс иницијализован, у реду је створити заједничку референцу на њега:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕЗБЕДНОСТ: Кс00Кс је иницијализован.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Нетачна* употреба ове методе:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Направили смо референцу на неиницијализовани З0вецтор0З!Ово је недефинисано понашање.⚠
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Иницијализујте Кс01Кс помоћу Кс00Кс:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Референца на неиницијализовани Кс00Кс: УБ!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс иницијализован.
        // То такође значи да Кс00Кс мора бити варијанта Кс01Кс.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Добија променљиву референцу Кс00Кс на садржану вредност.
    ///
    /// Ово може бити корисно када желимо да приступимо Кс01Кс који је иницијализован, али нема власништво над Кс02Кс (спречавајући употребу Кс00Кс.
    ///
    /// # Safety
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање: на позиваоцу је да гарантује да је Кс00Кс заиста у иницијализованом стању.
    /// На пример, Кс01Кс се не може користити за иницијализацију Кс00Кс.
    ///
    /// # Examples
    ///
    /// ### Правилна употреба ове методе:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Иницијализује *свих* бајтова улазног бафера.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Иницијализујте Кс00Кс:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Сада знамо да је Кс00Кс иницијализован, па бисмо могли да га Кс01Кс.
    /// // Међутим, коришћење Кс00Кс може покренути Кс01Кс од 2048 бајтова.
    /// // Да бисмо тврдили да је наш међуспремник иницијализован без копирања, надограђујемо Кс01Кс на Кс00Кс:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕЗБЕДНОСТ: Кс00Кс је иницијализован.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Сада можемо да користимо Кс00Кс као нормални пресек:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Нетачна* употреба ове методе:
    ///
    /// Не можете да користите Кс00Кс за иницијализацију вредности:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Направили смо референцу Кс01Кс за неиницијализовани Кс00Кс!
    ///     // Ово је недефинисано понашање.⚠
    /// }
    /// ```
    ///
    /// На пример, не можете Кс00Кс у неиницијализовани бафер:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) референца на неиницијализовано сећање!
    ///                             // Ово је недефинисано понашање.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Нити можете да користите директан приступ пољу за постепену иницијализацију од поља до поља:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) референца на неиницијализовано сећање!
    ///                  // Ово је недефинисано понашање.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) референца на неиницијализовано сећање!
    ///                  // Ово је недефинисано понашање.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Тренутно се ослањамо на то да је горе наведено нетачно, тј. Имамо референце на неиницијализоване податке (нпр. У Кс00Кс).
    // Коначну одлуку о правилима требали бисмо донети пре стабилизације.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕЗБЕДНОСТ: позивалац мора да гарантује да је Кс00Кс иницијализован.
        // То такође значи да Кс00Кс мора бити варијанта Кс01Кс.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Издваја вредности из низа контејнера Кс00Кс.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да су сви елементи низа у иницијализованом стању.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЕЗБЕДНОСТ: Сада на сигурном јер смо иницирали све елементе
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Позивач гарантује да су сви елементи низа иницијализовани
        // * `MaybeUninit<T>` и Т. гарантовано имају исти распоред
        // * Можда се Унининт не испушта, тако да нема двоструких ослобађања и стога је конверзија сигурна
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Под претпоставком да су сви елементи иницијализовани, узмите им пресек.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да су Кс00Кс елементи заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање.
    ///
    /// Погледајте Кс00Кс за више детаља и примера.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕЗБЕДНОСТ: преливање пресека на Кс00Кс је сигурно, јер позивалац то гарантује
        // `slice` је иницијализован, а за`МаибеУнинит` се гарантује да има исти изглед као Кс00Кс.
        // Добијени показивач је важећи јер се односи на меморију у власништву Кс00Кс која је референца и због тога се гарантује да ће важити за читање.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Под претпоставком да су сви елементи иницијализовани, узмите им променљиви пресек.
    ///
    /// # Safety
    ///
    /// На позиваоцу је да гарантује да су Кс00Кс елементи заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива недефинисано понашање.
    ///
    /// Погледајте Кс00Кс за више детаља и примера.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕЗБЕДНОСТ: слично безбедносним напоменама за Кс00Кс, али ми имамо а
        // променљива референца која такође има гаранцију да важи за уписе.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Добија показивач на први елемент низа.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Добија променљиви показивач на први елемент низа.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Копира елементе из Кс02Кс у Кс01Кс, враћајући променљиву референцу на сада иницирани садржај Кс00Кс.
    ///
    /// Ако Кс02Кс не примењује Кс01Кс, користите Кс00Кс
    ///
    /// Ово је слично Кс00Кс.
    ///
    /// # Panics
    ///
    /// Ова функција ће радити З0паниц0З ако су два реза различите дужине.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗБЕДНОСТ: управо смо копирали све елементе лена у резервни капацитет
    /// // први Кс00Кс елементи вец-а су сада важећи.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕЗБЕДНОСТ: &[Т] и&[МождаУнинит<T>] имају исти изглед
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕЗБЕДНОСТ: Важећи елементи су управо копирани у Кс00Кс, тако да је он почетним словима
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Клонира елементе из Кс02Кс у Кс01Кс, враћајући променљиву референцу на сада иницирани садржај Кс00Кс.
    /// Сви већ иницијални елементи неће бити испуштени.
    ///
    /// Ако Кс02Кс имплементира Кс01Кс, користите Кс00Кс
    ///
    /// Ово је слично Кс00Кс, али не испушта постојеће елементе.
    ///
    /// # Panics
    ///
    /// Ова функција ће З0паниц0З ако два одсечка имају различите дужине или ако је примена Кс00Кс З0паницс0З.
    ///
    /// Ако постоји З0паниц0З, већ клонирани елементи ће бити испуштени.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗБЕДНОСТ: управо смо клонирали све елементе сочива у резервни капацитет
    /// // први Кс00Кс елементи вец-а су сада важећи.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // за разлику од цопи_фром_слице, ово не позива цлоне_фром_слице на пресеку, то је зато што Кс00Кс не примењује Цлоне.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕЗБЕДНОСТ: овај сирови пресек садржаће само иницијализоване објекте
                // зато је дозвољено да га испустите.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Морамо их изричито исећи на исту дужину
        // за брисање провере граница, а оптимизатор ће генерисати мемцпи за једноставне случајеве (на пример Т=Кс00Кс).
        //
        let len = this.len();
        let src = &src[..len];

        // потребан је чувар Кс00Кс З0паниц0З се може догодити током клонирања
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕЗБЕДНОСТ: Важећи елементи су управо уписани у Кс00Кс, тако да је он почетним словима
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}