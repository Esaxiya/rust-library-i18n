//! Целобројно обликовање и форматирање бројева са покретном тачком

use crate::fmt;
use crate::mem::MaybeUninit;
use crate::num::flt2dec;
use crate::ops::{Div, Rem, Sub};
use crate::ptr;
use crate::slice;
use crate::str;

#[doc(hidden)]
trait DisplayInt:
    PartialEq + PartialOrd + Div<Output = Self> + Rem<Output = Self> + Sub<Output = Self> + Copy
{
    fn zero() -> Self;
    fn from_u8(u: u8) -> Self;
    fn to_u8(&self) -> u8;
    fn to_u16(&self) -> u16;
    fn to_u32(&self) -> u32;
    fn to_u64(&self) -> u64;
    fn to_u128(&self) -> u128;
}

macro_rules! impl_int {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}
macro_rules! impl_uint {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}

impl_int! { i8 i16 i32 i64 i128 isize }
impl_uint! { u8 u16 u32 u64 u128 usize }

/// Тип који представља одређени радикс
#[doc(hidden)]
trait GenericRadix: Sized {
    /// Број цифара.
    const BASE: u8;

    /// Низ префикса специфичан за радик.
    const PREFIX: &'static str;

    /// Претвара цео број у одговарајућу цифру радик.
    fn digit(x: u8) -> u8;

    /// Форматирајте цели број помоћу радикса помоћу формативача.
    fn fmt_int<T: DisplayInt>(&self, mut x: T, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Радик може бити само 2, па нам је потребан бафер од најмање 128 знакова за основни број 2.
        //
        let zero = T::zero();
        let is_nonnegative = x >= zero;
        let mut buf = [MaybeUninit::<u8>::uninit(); 128];
        let mut curr = buf.len();
        let base = T::from_u8(Self::BASE);
        if is_nonnegative {
            // Акумулирајте сваку цифру броја од најмање значајне до најзначајније цифре.
            //
            for byte in buf.iter_mut().rev() {
                let n = x % base; // Добијте тренутну вредност места.
                x = x / base; // Деакумулирајте број.
                byte.write(Self::digit(n.to_u8())); // Спремите цифру у бафер.
                curr -= 1;
                if x == zero {
                    // Нема више цифара за сакупљање.
                    break;
                };
            }
        } else {
            // Урадите исто као горе, али узимајући у обзир допуну двојке.
            for byte in buf.iter_mut().rev() {
                let n = zero - (x % base); // Добијте тренутну вредност места.
                x = x / base; // Деакумулирајте број.
                byte.write(Self::digit(n.to_u8())); // Спремите цифру у бафер.
                curr -= 1;
                if x == zero {
                    // Нема више цифара за сакупљање.
                    break;
                };
            }
        }
        let buf = &buf[curr..];
        // БЕЗБЕДНОСТ: Једине знакове у Кс00Кс креира Кс01Кс за које се претпоставља да јесу
        // важећи Кс00Кс
        let buf = unsafe {
            str::from_utf8_unchecked(slice::from_raw_parts(
                MaybeUninit::slice_as_ptr(buf),
                buf.len(),
            ))
        };
        f.pad_integral(is_nonnegative, Self::PREFIX, buf)
    }
}

/// Бинарни (основа 2) радикс
#[derive(Clone, PartialEq)]
struct Binary;

/// Осмерокутни (основа 8) радикс
#[derive(Clone, PartialEq)]
struct Octal;

/// Хексадецимални (основа 16) радикс, форматиран малим словима
#[derive(Clone, PartialEq)]
struct LowerHex;

/// Хексадецимални (основа 16) радикс, форматиран великим словима
#[derive(Clone, PartialEq)]
struct UpperHex;

macro_rules! radix {
    ($T:ident, $base:expr, $prefix:expr, $($x:pat => $conv:expr),+) => {
        impl GenericRadix for $T {
            const BASE: u8 = $base;
            const PREFIX: &'static str = $prefix;
            fn digit(x: u8) -> u8 {
                match x {
                    $($x => $conv,)+
                    x => panic!("number not in the range 0..={}: {}", Self::BASE - 1, x),
                }
            }
        }
    }
}

radix! { Binary,    2, "0b", x @  0 ..=  1 => b'0' + x }
radix! { Octal,     8, "0o", x @  0 ..=  7 => b'0' + x }
radix! { LowerHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'a' + (x - 10) }
radix! { UpperHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'A' + (x - 10) }

macro_rules! int_base {
    (fmt::$Trait:ident for $T:ident as $U:ident -> $Radix:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::$Trait for $T {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                $Radix.fmt_int(*self as $U, f)
            }
        }
    };
}

macro_rules! integer {
    ($Int:ident, $Uint:ident) => {
        int_base! { fmt::Binary   for $Int as $Uint  -> Binary }
        int_base! { fmt::Octal    for $Int as $Uint  -> Octal }
        int_base! { fmt::LowerHex for $Int as $Uint  -> LowerHex }
        int_base! { fmt::UpperHex for $Int as $Uint  -> UpperHex }

        int_base! { fmt::Binary   for $Uint as $Uint -> Binary }
        int_base! { fmt::Octal    for $Uint as $Uint -> Octal }
        int_base! { fmt::LowerHex for $Uint as $Uint -> LowerHex }
        int_base! { fmt::UpperHex for $Uint as $Uint -> UpperHex }
    };
}
integer! { isize, usize }
integer! { i8, u8 }
integer! { i16, u16 }
integer! { i32, u32 }
integer! { i64, u64 }
integer! { i128, u128 }
macro_rules! debug {
    ($($T:ident)*) => {$(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Debug for $T {
            #[inline]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if f.debug_lower_hex() {
                    fmt::LowerHex::fmt(self, f)
                } else if f.debug_upper_hex() {
                    fmt::UpperHex::fmt(self, f)
                } else {
                    fmt::Display::fmt(self, f)
                }
            }
        }
    )*};
}
debug! {
  i8 i16 i32 i64 i128 isize
  u8 u16 u32 u64 u128 usize
}

// Двоцифрена табела са децималним подацима
static DEC_DIGITS_LUT: &[u8; 200] = b"0001020304050607080910111213141516171819\
      2021222324252627282930313233343536373839\
      4041424344454647484950515253545556575859\
      6061626364656667686970717273747576777879\
      8081828384858687888990919293949596979899";

macro_rules! impl_Display {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(mut n: $u, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            // 2 ^ 128 је око 3 * 10 ^ 38, тако да 39 даје додатни бајт простора
            let mut buf = [MaybeUninit::<u8>::uninit(); 39];
            let mut curr = buf.len() as isize;
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // БЕЗБЕДНОСТ: Будући да су Кс01Кс и Кс02Кс увек мањи или једнаки Кс00Кс, ми
            // може копирати са Кс01Кс и Кс00Кс.
            // Да бисте показали да је у реду копирање у Кс00Кс, имајте на уму да је на почетку Кс02Кс од Кс01Кс, а у сваком кораку се ово задржава исто као што се дели Кс03Кс.
            //
            // Будући да је Кс00Кс увек ненегативан, то значи да је Кс01Кс тако да је Кс02Кс безбедан за приступ.
            //
            //
            unsafe {
                // треба најмање 16 битова да би 4 знака одједном радила.
                assert!(crate::mem::size_of::<$u>() >= 2);

                // жељно декодирајте по 4 знака
                while n >= 10000 {
                    let rem = (n % 10000) as isize;
                    n /= 10000;

                    let d1 = (rem / 100) << 1;
                    let d2 = (rem % 100) << 1;
                    curr -= 4;

                    // Овде је дозвољено копирање на Кс01Кс, јер иначе Кс00Кс.
                    // Али тада је Кс01Кс првобитно био барем Кс02Кс, што је Кс00Кс.
                    //
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                    ptr::copy_nonoverlapping(lut_ptr.offset(d2), buf_ptr.offset(curr + 2), 2);
                }

                // ако дођемо овде, бројеви су <=9999, дакле највише 4 знака
                let mut n = n as isize; // могуће смањити 64-битну математику

                // декодирати још 2 знака, ако је> 2 знака
                if n >= 100 {
                    let d1 = (n % 100) << 1;
                    n /= 100;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }

                // декодирање последњих 1 или 2 знака
                if n < 10 {
                    curr -= 1;
                    *buf_ptr.offset(curr) = (n as u8) + b'0';
                } else {
                    let d1 = n << 1;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
            }

            // БЕЗБЕДНОСТ: Кс00Кс> 0 (јер смо Кс01Кс направили довољно великим) и сви знакови су важећи
            // UTF-8 пошто је Кс00Кс
            let buf_slice = unsafe {
                str::from_utf8_unchecked(
                    slice::from_raw_parts(buf_ptr.offset(curr), buf.len() - curr as usize))
            };
            f.pad_integral(is_nonnegative, "", buf_slice)
        }

        $(#[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Display for $t {
            #[allow(unused_comparisons)]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                let is_nonnegative = *self >= 0;
                let n = if is_nonnegative {
                    self.$conv_fn()
                } else {
                    // претворите негативни број у позитивни збрајањем 1 у његов додатак 2
                    (!self.$conv_fn()).wrapping_add(1)
                };
                $name(n, is_nonnegative, f)
            }
        })*
    };
}

macro_rules! impl_Exp {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(
            mut n: $u,
            is_nonnegative: bool,
            upper: bool,
            f: &mut fmt::Formatter<'_>
        ) -> fmt::Result {
            let (mut n, mut exponent, trailing_zeros, added_precision) = {
                let mut exponent = 0;
                // броји и уклања последње децималне нуле
                while n % 10 == 0 && n >= 10 {
                    n /= 10;
                    exponent += 1;
                }
                let trailing_zeros = exponent;

                let (added_precision, subtracted_precision) = match f.precision() {
                    Some(fmt_prec) => {
                        // број децималних цифара минус 1
                        let mut tmp = n;
                        let mut prec = 0;
                        while tmp >= 10 {
                            tmp /= 10;
                            prec += 1;
                        }
                        (fmt_prec.saturating_sub(prec), prec.saturating_sub(fmt_prec))
                    }
                    None => (0,0)
                };
                for _ in 1..subtracted_precision {
                    n/=10;
                    exponent += 1;
                }
                if subtracted_precision != 0 {
                    let rem = n % 10;
                    n /= 10;
                    exponent += 1;
                    // заокружи последњу цифру
                    if rem >= 5 {
                        n += 1;
                    }
                }
                (n, exponent, trailing_zeros, added_precision)
            };

            // 39 цифара (најгори случај у128) +.
            // =40 Будући да се Кс01Кс увек смањује за број копираних цифара, то значи да Кс00Кс.
            //
            let mut buf = [MaybeUninit::<u8>::uninit(); 40];
            let mut curr = buf.len() as isize; // индекс за буф
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // декодирати 2 знака одједном
            while n >= 100 {
                let d1 = ((n % 100) as isize) << 1;
                curr -= 2;
                // БЕЗБЕДНОСТ: Кс00Кс, па можемо копирати са Кс01Кс од
                // `DEC_DIGITS_LUT` има дужину од 200.
                unsafe {
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
                n /= 100;
                exponent += 2;
            }
            // н је <=99, дакле највише 2 знака
            let mut n = n as isize; // могуће смањити 64-битну математику
            // декодира претпоследњи знак
            if n >= 10 {
                curr -= 1;
                // БЕЗБЕДНОСТ: Сигурно од Кс00Кс (види коментар)
                unsafe {
                    *buf_ptr.offset(curr) = (n as u8 % 10_u8) + b'0';
                }
                n /= 10;
                exponent += 1;
            }
            // додај децималну тачку ако је> 1 мантисса цифра ће бити одштампана
            if exponent != trailing_zeros || added_precision != 0 {
                curr -= 1;
                // БЕЗБЕДНОСТ: Сигурно од Кс00Кс
                unsafe {
                    *buf_ptr.offset(curr) = b'.';
                }
            }

            // БЕЗБЕДНОСТ: Сигурно од Кс00Кс
            let buf_slice = unsafe {
                // декодирање последњег знака
                curr -= 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';

                let len = buf.len() - curr as usize;
                slice::from_raw_parts(buf_ptr.offset(curr), len)
            };

            // чува Кс00Кс (или Кс01Кс) и до двоцифрени експонент
            let mut exp_buf = [MaybeUninit::<u8>::uninit(); 3];
            let exp_ptr = MaybeUninit::slice_as_mut_ptr(&mut exp_buf);
            // БЕЗБЕДНОСТ: У оба случаја, Кс01Кс је написан у границама, а Кс00Кс
            // је садржан у Кс01Кс од Кс00Кс.
            let exp_slice = unsafe {
                *exp_ptr.offset(0) = if upper {b'E'} else {b'e'};
                let len = if exponent < 10 {
                    *exp_ptr.offset(1) = (exponent as u8) + b'0';
                    2
                } else {
                    let off = exponent << 1;
                    ptr::copy_nonoverlapping(lut_ptr.offset(off), exp_ptr.offset(1), 2);
                    3
                };
                slice::from_raw_parts(exp_ptr, len)
            };

            let parts = &[
                flt2dec::Part::Copy(buf_slice),
                flt2dec::Part::Zero(added_precision),
                flt2dec::Part::Copy(exp_slice)
            ];
            let sign = if !is_nonnegative {
                "-"
            } else if f.sign_plus() {
                "+"
            } else {
                ""
            };
            let formatted = flt2dec::Formatted{sign, parts};
            f.pad_formatted_parts(&formatted)
        }

        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::LowerExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // претворите негативни број у позитивни збрајањем 1 у његов додатак 2
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, false, f)
                }
            })*
        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::UpperExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // претворите негативни број у позитивни збрајањем 1 у његов додатак 2
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, true, f)
                }
            })*
    };
}

// Овде укључите Кс00Кс, јер не одражава величину матичног показивача и често му је стало да добије мању величину кода.
//
#[cfg(any(target_pointer_width = "64", target_arch = "wasm32"))]
mod imp {
    use super::*;
    impl_Display!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named fmt_u64
    );
    impl_Exp!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named exp_u64
    );
}

#[cfg(not(any(target_pointer_width = "64", target_arch = "wasm32")))]
mod imp {
    use super::*;
    impl_Display!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named fmt_u32);
    impl_Display!(i64, u64 as u64 via to_u64 named fmt_u64);
    impl_Exp!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named exp_u32);
    impl_Exp!(i64, u64 as u64 via to_u64 named exp_u64);
}
impl_Exp!(i128, u128 as u128 via to_u128 named exp_u128);

/// Помоћна функција за уписивање Кс01Кс у Кс02Кс од последњег до првог, са Кс00Кс.
fn parse_u64_into<const N: usize>(mut n: u64, buf: &mut [MaybeUninit<u8>; N], curr: &mut isize) {
    let buf_ptr = MaybeUninit::slice_as_mut_ptr(buf);
    let lut_ptr = DEC_DIGITS_LUT.as_ptr();
    assert!(*curr > 19);

    // SAFETY:
    // У међуспремник уписује највише 19 знакова.Гарантовано је да било који птр у ЛУТ износи највише
    // 198, тако да никада неће ООБ.
    // Горе је потврђено да је остало најмање 19 знакова.
    unsafe {
        if n >= 1e16 as u64 {
            let to_parse = n % 1e16 as u64;
            n /= 1e16 as u64;

            // Неки од њих су нопс, али на овај начин изгледа елегантније.
            let d1 = ((to_parse / 1e14 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e12 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e10 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e8 as u64) % 100) << 1;
            let d5 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d6 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d7 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d8 = ((to_parse / 1e0 as u64) % 100) << 1;

            *curr -= 16;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d5 as isize), buf_ptr.offset(*curr + 8), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d6 as isize), buf_ptr.offset(*curr + 10), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d7 as isize), buf_ptr.offset(*curr + 12), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d8 as isize), buf_ptr.offset(*curr + 14), 2);
        }
        if n >= 1e8 as u64 {
            let to_parse = n % 1e8 as u64;
            n /= 1e8 as u64;

            // Неки од њих су нопс, али на овај начин изгледа елегантније.
            let d1 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e0 as u64) % 100) << 1;
            *curr -= 8;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
        }
        // `n` <1е8 <(1 << 32)
        let mut n = n as u32;
        if n >= 1e4 as u32 {
            let to_parse = n % 1e4 as u32;
            n /= 1e4 as u32;

            let d1 = (to_parse / 100) << 1;
            let d2 = (to_parse % 100) << 1;
            *curr -= 4;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
        }

        // `n` <1е4 <(1 << 16)
        let mut n = n as u16;
        if n >= 100 {
            let d1 = (n % 100) << 1;
            n /= 100;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }

        // декодирање последњих 1 или 2 знака
        if n < 10 {
            *curr -= 1;
            *buf_ptr.offset(*curr) = (n as u8) + b'0';
        } else {
            let d1 = n << 1;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for u128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt_u128(*self, true, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for i128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let is_nonnegative = *self >= 0;
        let n = if is_nonnegative {
            self.to_u128()
        } else {
            // претворите негативни број у позитивни збрајањем 1 у његов додатак 2
            (!self.to_u128()).wrapping_add(1)
        };
        fmt_u128(n, is_nonnegative, f)
    }
}

/// Специјализована оптимизација за у128.
/// Уместо да узима две ставке одједном, она се дели на највише 2 у64, а затим се дели на 10е16, 10е8, 10е4, 10е2, а затим 10е1.
/// Такође мора да обрађује 1 последњу ставку, као 10 ^ 40> 2 ^ 128> 10 ^ 39, док
/// 10 ^ 20> 2 ^ 64> 10 ^ 19.
fn fmt_u128(n: u128, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    // 2 ^ 128 је око 3 * 10 ^ 38, тако да 39 даје додатни бајт простора
    let mut buf = [MaybeUninit::<u8>::uninit(); 39];
    let mut curr = buf.len() as isize;

    let (n, rem) = udiv_1e19(n);
    parse_u64_into(rem, &mut buf, &mut curr);

    if n != 0 {
        // 0 јастучић до тачке
        let target = (buf.len() - 19) as isize;
        // БЕЗБЕДНОСТ: Гарантовано да смо написали највише 19 бајтова, а простора мора бити
        // преостала пошто има дужину 39
        unsafe {
            ptr::write_bytes(
                MaybeUninit::slice_as_mut_ptr(&mut buf).offset(target),
                b'0',
                (curr - target) as usize,
            );
        }
        curr = target;

        let (n, rem) = udiv_1e19(n);
        parse_u64_into(rem, &mut buf, &mut curr);
        // Да ли би ово следеће З0бранцх0З требало да буде означено са мало вероватним?
        if n != 0 {
            let target = (buf.len() - 38) as isize;
            // Сирови Кс00Кс показивач важи само док се Кс01Кс не користи следећи пут, али буф Кс02Кс се не користи у овом опсегу, тако да смо добри.
            //
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            // БЕЗБЕДНОСТ: У овом тренутку написали смо највише 38 бајтова, надопунили до те тачке,
            // Преостаје само 1 цифра.
            unsafe {
                ptr::write_bytes(buf_ptr.offset(target), b'0', (curr - target) as usize);
                curr = target - 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';
            }
        }
    }

    // БЕЗБЕДНОСТ: Кс00Кс> 0 (јер смо Кс01Кс направили довољно великим) и сви знакови су важећи
    // UTF-8 пошто је Кс00Кс
    let buf_slice = unsafe {
        str::from_utf8_unchecked(slice::from_raw_parts(
            MaybeUninit::slice_as_mut_ptr(&mut buf).offset(curr),
            buf.len() - curr as usize,
        ))
    };
    f.pad_integral(is_nonnegative, "", buf_slice)
}

/// Подела Кс00Кс на н> 1е19 и рем <=1е19
///
/// Алгоритам целобројне поделе заснован је на следећем раду:
///
///   Т. Гранлунд и П.
///   Монтгомери, " Дељење непроменљивим целобројним бројевима користећи множење` у Проц.
///   конференције о дизајнирању и примени програмског језика Кс00Кс, 1994, стр.
///   61–72
fn udiv_1e19(n: u128) -> (u128, u64) {
    const DIV: u64 = 1e19 as u64;
    const FACTOR: u128 = 156927543384667019095894735580191660403;

    let quot = if n < 1 << 83 {
        ((n >> 19) as u64 / (DIV >> 19)) as u128
    } else {
        u128_mulhi(n, FACTOR) >> 62
    };

    let rem = (n - quot * DIV as u128) as u64;
    (quot, rem)
}

/// Множите непотписане 128-битне цијеле бројеве, вратите горњих 128 битова резултата
#[inline]
fn u128_mulhi(x: u128, y: u128) -> u128 {
    let x_lo = x as u64;
    let x_hi = (x >> 64) as u64;
    let y_lo = y as u64;
    let y_hi = (y >> 64) as u64;

    // руковати могућношћу преливања
    let carry = (x_lo as u128 * y_lo as u128) >> 64;
    let m = x_lo as u128 * y_hi as u128 + carry;
    let high1 = m >> 64;

    let m_lo = m as u64;
    let high2 = (x_hi as u128 * y_lo as u128 + m_lo as u128) >> 64;

    x_hi as u128 * y_hi as u128 + high1 + high2
}