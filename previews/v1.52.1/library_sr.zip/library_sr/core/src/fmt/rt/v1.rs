//! Ово је интерни модул који користи ифмт!време извођења.Ове структуре се емитују у статичке низове у прекомпајлиране низове формата пре времена.
//!
//! Ове дефиниције су сличне њиховим еквивалентима Кс00Кс, али се разликују по томе што се могу статички доделити и мало су оптимизоване за време извођења
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Могућа поравнања која се могу затражити као део директиве о форматирању.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Ознака да садржај треба поравнати лево.
    Left,
    /// Ознака да садржај треба да буде поравнат удесно.
    Right,
    /// Ознака да садржај треба да буде поравнат према центру.
    Center,
    /// Није затражено поравнање.
    Unknown,
}

/// Користе га спецификатори Кс00Кс и Кс01Кс.
#[derive(Copy, Clone)]
pub enum Count {
    /// Наведено с дословним бројем, чува вредност
    Is(usize),
    /// Наведено коришћењем синтакса Кс01Кс и Кс02Кс, индекс чува у Кс00Кс
    Param(usize),
    /// Није прецизирано
    Implied,
}