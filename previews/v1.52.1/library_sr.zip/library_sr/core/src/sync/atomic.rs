//! Атомски типови
//!
//! Атомски типови пружају примитивну комуникацију са заједничком меморијом између нити и градивни су блокови осталих истовремених типова.
//!
//! Овај модул дефинише атомске верзије изабраног броја примитивних типова, укључујући Кс00Кс, Кс01Кс, Кс02Кс, Кс03Кс, Кс04Кс итд.
//! Атомски типови представљају операције које, када се правилно користе, синхронизују ажурирања између нити.
//!
//! Свака метода узима Кс02Кс који представља снагу меморијске баријере за ту операцију.Ове поруџбине су исте као код Кс01Кс.За више информација погледајте Кс00Кс.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Атомске променљиве је сигурно делити између нити (оне примењују Кс01Кс), али саме не пружају механизам за дељење и прате Кс00Кс од З0Руст0З.
//!
//! Најчешћи начин дељења атомске променљиве је стављање у Кс00Кс (дељени показивач који броји атомске референце).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Атомски типови се могу чувати у статичким променљивим, иницијализованим помоћу константних иницијализатора попут Кс00Кс.Атомска статика се често користи за лењу глобалну иницијализацију.
//!
//! # Portability
//!
//! Сви атомски типови у овом модулу загарантовани су Кс00Кс ако су доступни.То значи да они интерно не добијају глобални мутек.Није загарантовано да ће атомске врсте и операције бити без чекања.
//! То значи да се операције попут Кс00Кс могу применити помоћу петље упоређивања и замене.
//!
//! Атомске операције се могу применити на слоју инструкција са атомиком веће величине.На пример, неке платформе користе 4-бајтна атомска упутства за примену Кс00Кс.
//! Имајте на уму да ова емулација не би требало да утиче на исправност кода, то је само нешто чега треба бити свестан.
//!
//! Атомски типови у овом модулу можда неће бити доступни на свим платформама.Међутим, овде су сви атомски типови широко доступни и на њих се углавном може ослонити.Неки значајни изузеци су:
//!
//! * PowerPC и Кс00Кс платформе са 32-битним показивачима немају типове Кс01Кс или Кс02Кс.
//! * ARM платформе попут Кс02Кс које нису за Кс03Кс пружају само операције Кс04Кс и Кс05Кс и не подржавају операције упоређивања и замене Кс06Кс, као што су Кс00Кс, Кс01Кс итд.
//! Поред тога, на Кс00Кс, ове ЦАС операције се примењују путем Кс01Кс, што може доћи са казном учинка.
//! * ARM циљеви са Кс02Кс пружају само Кс03Кс и Кс04Кс операције и не подржавају операције упоређивања и замене Кс05Кс, као што су Кс00Кс, Кс01Кс итд.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Имајте на уму да се могу додати платформе З0футуре0З које такође немају подршку за неке атомске операције.Максимално преносиви код ће желети да буде пажљив око тога који се атомски типови користе.
//! `AtomicUsize` и Кс00Кс су генерално најпреносивији, али чак и тада нису свуда доступни.
//! За референцу, библиотека Кс00Кс захтева атомику величине показивача, иако Кс01Кс то не захтева.
//!
//! Тренутно ћете морати да користите Кс00Кс првенствено за условно компајлирање у коду са атомиком.Постоји и нестабилан Кс01Кс који се може стабилизовати у З0футуре0З.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Једноставан спинлоцк:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Сачекајте да друга нит отпусти браву
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Водите глобални број живих нити:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Логички тип који се може безбедно делити између нити.
///
/// Овај тип има исти приказ у меморији као Кс00Кс.
///
/// **Напомена**: Овај тип је доступан само на платформама које подржавају атомска оптерећења и складишта Кс00Кс.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Ствара Кс01Кс иницијализован за Кс00Кс.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Сенд је имплицитно имплементиран за АтомицБоол.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Необрађени тип показивача који се може безбедно делити између нити.
///
/// Овај тип има исти приказ у меморији као Кс00Кс.
///
/// **Напомена**: Овај тип је доступан само на платформама које подржавају атомска оптерећења и складишта показивача.
/// Његова величина зависи од величине циљног показивача.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Ствара нулу Кс00Кс.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Редослед атомске меморије
///
/// Поредак меморије одређује начин на који атомске операције синхронизују меморију.
/// У његовом најслабијем Кс00Кс синхронизује се само меморија коју је операција директно додирнула.
/// С друге стране, пар Кс00Кс операција са учитавањем меморије синхронизује другу меморију, уз истовремено очување укупног редоследа таквих операција у свим нитима.
///
///
/// Поруке меморије З0Руст0З су Кс00Кс.
///
/// За више информација погледајте Кс00Кс.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Нема ограничења за наручивање, већ само атомске операције.
    ///
    /// Одговара Кс00Кс у З0Ц ++ 0З20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// У комбинацији са складиштем, све претходне операције постају наложене пре било каквог учитавања ове вредности са Кс00Кс (или јачим) наручивањем.
    ///
    /// Конкретно, сва претходна писања постају видљива свим нитима које извршавају Кс00Кс (или јаче) оптерећење ове вредности.
    ///
    /// Приметите да употреба овог наручивања за операцију која комбинује оптерећења и складишта доводи до операције оптерећења Кс00Кс!
    ///
    /// Ово наручивање је применљиво само за операције које могу извршити продавницу.
    ///
    /// Одговара Кс00Кс у З0Ц ++ 0З20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// У комбинацији са оптерећењем, ако је учитана вредност написана операцијом складиштења са Кс00Кс (или јачим) наручивањем, тада све наредне операције постају поредане након тог складишта.
    /// Конкретно, сва наредна учитавања видеће податке записане пре складиштења.
    ///
    /// Приметите да употреба овог наручивања за операцију која комбинује оптерећења и складишта доводи до рада продавнице Кс00Кс!
    ///
    /// Ово наручивање је применљиво само за операције које могу извршити оптерећење.
    ///
    /// Одговара Кс00Кс у З0Ц ++ 0З20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Има ефекте и Кс00Кс и Кс01Кс заједно:
    /// За оптерећења користи Кс00Кс наручивање.За продавнице користи наруџбину Кс01Кс.
    ///
    /// Приметите да је у случају Кс00Кс могуће да операција на крају не изврши ниједно складиште и да стога има само Кс01Кс наручивање.
    ///
    /// Међутим, Кс00Кс никада неће извршити приступ Кс01Кс.
    ///
    /// Ово наручивање је применљиво само за операције које комбинују и терет и залихе.
    ///
    /// Одговара Кс00Кс у З0Ц ++ 0З20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Попут [`Ацкуире`]/[`Релеасе`]/[`АцкРел`](за операције учитавања, складиштења и учитавања са складиштем), уз додатну гаранцију да све нити виде све секвенцијално доследне операције у истом редоследу .
    ///
    ///
    /// Одговара Кс00Кс у З0Ц ++ 0З20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Кс01Кс иницијализован за Кс00Кс.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Ствара нови Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Враћа променљиву референцу на основни Кс00Кс.
    ///
    /// Ово је сигурно јер променљива референца гарантује да ниједна друга нит истовремено не приступа атомским подацима.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // БЕЗБЕДНОСТ: променљива референца гарантује јединствено власништво.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Приступите атомском приступу Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // БЕЗБЕДНОСТ: променљива референца гарантује јединствено власништво и
        // поравнање и Кс00Кс и Кс01Кс је 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Троши атомску и враћа садржану вредност.
    ///
    /// Ово је сигурно јер прослеђивање Кс00Кс по вредности гарантује да ниједна друга нит истовремено не приступа атомским подацима.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Учитава вредност из З0боол0З.
    ///
    /// `load` узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: било које расе података спречавају атомске карактеристике и сирови подаци
        // показивач који је прослеђен ваљан је јер смо га добили из референце.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Похрањује вредност у З0боол0З.
    ///
    /// `store` узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // БЕЗБЕДНОСТ: било које расе података спречавају атомске карактеристике и сирови подаци
        // показивач који је прослеђен ваљан је јер смо га добили из референце.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Похрањује вредност у З0боол0З, враћајући претходну вредност.
    ///
    /// `swap` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Похрањује вредност у Кс00Кс ако је тренутна вредност иста као вредност Кс01Кс.
    ///
    /// Повратна вредност је увек претходна вредност.Ако је једнако Кс00Кс, тада је вредност ажурирана.
    ///
    /// `compare_and_swap` такође узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Приметите да чак и када користите Кс00Кс, операција можда неће успети и стога само извршава Кс01Кс учитавање, али неће имати Кс02Кс семантику.
    /// Коришћење Кс01Кс чини складиште делом ове операције Кс02Кс ако се то догоди, а коришћење Кс03Кс чини део учитавања Кс00Кс.
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Прелазак на Кс01Кс и Кс00Кс
    ///
    /// `compare_and_swap` је еквивалентан Кс00Кс са следећим мапирањем за наручивање меморије:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Опуштено |Опуштено |Опуштено стицање |Стицање |Прибави издање |Издање |Опуштено АцкРел |АцкРел |Набавите СекЦст |СекЦст |СекЦст
    ///
    /// `compare_exchange_weak` дозвољено је да лажно откаже чак и када поређење успе, што омогућава компајлеру да генерише бољи склопни код када се упоређивање и размена користе у петљи.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Похрањује вредност у Кс00Кс ако је тренутна вредност иста као вредност Кс01Кс.
    ///
    /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
    /// У успеху ће ова вредност бити загарантована једнака Кс00Кс.
    ///
    /// `compare_exchange` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
    /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
    ///
    /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Похрањује вредност у Кс00Кс ако је тренутна вредност иста као вредност Кс01Кс.
    ///
    /// За разлику од Кс00Кс, овој функцији је дозвољено да лажно закаже чак и када поређење успе, што може резултирати ефикаснијим кодом на неким платформама.
    ///
    /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
    ///
    /// `compare_exchange_weak` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
    /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
    /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Логички Кс00Кс са логичком вредношћу.
    ///
    /// Изводи логичку операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
    ///
    /// Враћа претходну вредност.
    ///
    /// `fetch_and` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Логички Кс00Кс са логичком вредношћу.
    ///
    /// Изводи логичку операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
    ///
    /// Враћа претходну вредност.
    ///
    /// `fetch_nand` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Овде не можемо да користимо атомиц_нанд јер може да резултира З0боол0З са неважећом вредношћу.
        // То се дешава зато што се атомска операција врши са 8-битним целим бројем изнутра, који би поставио горњих 7 битова.
        //
        // Дакле, уместо тога користимо фетцх_кор или свап.
        if val {
            // ! (к&труе)==Кс00Кс Морамо да обрнемо З0боол0З.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (к&фалсе)==труе Морамо поставити З0боол0З на труе.
            //
            self.swap(true, order)
        }
    }

    /// Логички Кс00Кс са логичком вредношћу.
    ///
    /// Изводи логичку операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
    ///
    /// Враћа претходну вредност.
    ///
    /// `fetch_or` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Логички Кс00Кс са логичком вредношћу.
    ///
    /// Изводи логичку операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
    ///
    /// Враћа претходну вредност.
    ///
    /// `fetch_xor` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Враћа променљиви показивач на основни Кс00Кс.
    ///
    /// Неатомско читање и писање резултујућег целог броја може бити раса података.
    /// Ова метода је углавном корисна за ФФИ, где потпис функције може користити Кс01Кс уместо Кс00Кс.
    ///
    /// Повратак Кс00Кс показивача из заједничке референце на овај атом је сигуран јер атомски типови раде са унутрашњом променљивошћу.
    /// Све модификације атома мењају вредност кроз заједничку референцу и могу то безбедно учинити све док користе атомске операције.
    /// Свака употреба враћеног сировог показивача захтева Кс00Кс блок и још увек мора да се придржава истог ограничења: операције на њему морају бити атомске.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Дохвата вредност и на њу примењује функцију која враћа опционалну нову вредност.Приказује Кс02Кс од Кс03Кс ако је функција вратила Кс01Кс, иначе Кс00Кс.
    ///
    /// Note: Ово може функцију позвати више пута ако је вредност у међувремену промењена из других нити, све док функција враћа Кс00Кс, али ће функција бити примењена само једном на сачувану вредност.
    ///
    ///
    /// `fetch_update` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// Прва описује тражено наручивање када операција коначно успе, док друга описује тражено наручивање терета.
    /// Они одговарају редоследу успеха и неуспеха Кс00Кс.
    ///
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини коначно успешно учитавање Кс00Кс.
    /// Наручивање оптерећења Кс02Кс може бити само Кс00Кс, Кс01Кс или Кс03Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Овај метод је доступан само на платформама које подржавају атомске операције на Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Ствара нови Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Враћа променљиву референцу на основни показивач.
    ///
    /// Ово је сигурно јер променљива референца гарантује да ниједна друга нит истовремено не приступа атомским подацима.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Добити атомски приступ показивачу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - променљива референца гарантује јединствено власништво.
        //  - поравнање Кс00Кс и Кс01Кс је исто на свим платформама које подржава З0руст0З, као што је претходно потврђено.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Троши атомску и враћа садржану вредност.
    ///
    /// Ово је сигурно јер прослеђивање Кс00Кс по вредности гарантује да ниједна друга нит истовремено не приступа атомским подацима.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Учитава вредност из показивача.
    ///
    /// `load` узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Чува вредност у показивачу.
    ///
    /// `store` узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Похрањује вредност у показивач, враћајући претходну вредност.
    ///
    /// `swap` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
    /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
    ///
    ///
    /// **Note:** Ова метода је доступна само на платформама које подржавају атомске операције на показиваче.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Чува вредност у показивачу ако је тренутна вредност иста као вредност Кс00Кс.
    ///
    /// Повратна вредност је увек претходна вредност.Ако је једнако Кс00Кс, тада је вредност ажурирана.
    ///
    /// `compare_and_swap` такође узима Кс00Кс аргумент који описује редослед меморије ове операције.
    /// Приметите да чак и када користите Кс00Кс, операција можда неће успети и стога само извршава Кс01Кс учитавање, али неће имати Кс02Кс семантику.
    /// Коришћење Кс01Кс чини складиште делом ове операције Кс02Кс ако се то догоди, а коришћење Кс03Кс чини део учитавања Кс00Кс.
    ///
    /// **Note:** Ова метода је доступна само на платформама које подржавају атомске операције на показиваче.
    ///
    /// # Прелазак на Кс01Кс и Кс00Кс
    ///
    /// `compare_and_swap` је еквивалентан Кс00Кс са следећим мапирањем за наручивање меморије:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Опуштено |Опуштено |Опуштено стицање |Стицање |Прибави издање |Издање |Опуштено АцкРел |АцкРел |Набавите СекЦст |СекЦст |СекЦст
    ///
    /// `compare_exchange_weak` дозвољено је да лажно откаже чак и када поређење успе, што омогућава компајлеру да генерише бољи склопни код када се упоређивање и размена користе у петљи.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Чува вредност у показивачу ако је тренутна вредност иста као вредност Кс00Кс.
    ///
    /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
    /// У успеху ће ова вредност бити загарантована једнака Кс00Кс.
    ///
    /// `compare_exchange` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
    /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
    ///
    /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Ова метода је доступна само на платформама које подржавају атомске операције на показиваче.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Чува вредност у показивачу ако је тренутна вредност иста као вредност Кс00Кс.
    ///
    /// За разлику од Кс00Кс, овој функцији је дозвољено да лажно закаже чак и када поређење успе, што може резултирати ефикаснијим кодом на неким платформама.
    ///
    /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
    ///
    /// `compare_exchange_weak` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
    /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
    /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Ова метода је доступна само на платформама које подржавају атомске операције на показиваче.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗБЕДНОСТ: Ова суштинска особина није сигурна јер делује на сировом показивачу
        // али поуздано знамо да је показивач важећи (управо смо га добили од Кс00Кс који имамо референцом) и сама атомска операција нам омогућава да безбедно мутирамо садржај Кс01Кс.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Дохвата вредност и на њу примењује функцију која враћа опционалну нову вредност.Приказује Кс02Кс од Кс03Кс ако је функција вратила Кс01Кс, иначе Кс00Кс.
    ///
    /// Note: Ово може функцију позвати више пута ако је вредност у међувремену промењена из других нити, све док функција враћа Кс00Кс, али ће функција бити примењена само једном на сачувану вредност.
    ///
    ///
    /// `fetch_update` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
    /// Прва описује тражено наручивање када операција коначно успе, док друга описује тражено наручивање терета.
    /// Они одговарају редоследу успеха и неуспеха Кс00Кс.
    ///
    /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини коначно успешно учитавање Кс00Кс.
    /// Наручивање оптерећења Кс02Кс може бити само Кс00Кс, Кс01Кс или Кс03Кс и мора бити еквивалентно или слабије од успешног наручивања.
    ///
    /// **Note:** Ова метода је доступна само на платформама које подржавају атомске операције на показиваче.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Овај макро на крају се не користи на неким архитектурама.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Целобројни тип који се може безбедно делити између нити.
        ///
        /// Овај тип има исти приказ у меморији као основни целобројни тип, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// За више информација о разликама између атомских и неатомских типова, као и информације о преносивости овог типа, погледајте Кс00Кс.
        ///
        ///
        /// **Note:** Овај тип је доступан само на платформама које подржавају атомска оптерећења и складишта [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Атомски цели број иницијализован за Кс00Кс.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Сенд је имплицитно имплементиран.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Ствара нови атомски цео број.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Враћа променљиву референцу на основни цели број.
            ///
            /// Ово је сигурно јер променљива референца гарантује да ниједна друга нит истовремено не приступа атомским подацима.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// нека мут неки_инт=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// ассерт_ек! (соме_инт, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - променљива референца гарантује јединствено власништво.
                //  - поравнање Кс00Кс и Кс01Кс је исто, као што је обећао Кс02Кс и верификовано горе.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Троши атомску и враћа садржану вредност.
            ///
            /// Ово је сигурно јер прослеђивање Кс00Кс по вредности гарантује да ниједна друга нит истовремено не приступа атомским подацима.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Учитава вредност из атомског целог броја.
            ///
            /// `load` узима Кс00Кс аргумент који описује редослед меморије ове операције.
            /// Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
            ///
            /// # Panics
            ///
            /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Похрањује вредност у атомски цели број.
            ///
            /// `store` узима Кс00Кс аргумент који описује редослед меморије ове операције.
            ///  Могуће вредности су Кс01Кс, Кс02Кс и Кс00Кс.
            ///
            /// # Panics
            ///
            /// З0Паницс0З ако је Кс01Кс Кс02Кс или Кс00Кс.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Похрањује вриједност у атомски цијели број, враћајући претходну вриједност.
            ///
            /// `swap` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Похрањује вредност у атомски цели број ако је тренутна вредност иста као вредност Кс00Кс.
            ///
            /// Повратна вредност је увек претходна вредност.Ако је једнако Кс00Кс, тада је вредност ажурирана.
            ///
            /// `compare_and_swap` такође узима Кс00Кс аргумент који описује редослед меморије ове операције.
            /// Приметите да чак и када користите Кс00Кс, операција можда неће успети и стога само извршава Кс01Кс учитавање, али неће имати Кс02Кс семантику.
            ///
            /// Коришћење Кс01Кс чини складиште делом ове операције Кс02Кс ако се то догоди, а коришћење Кс03Кс чини део учитавања Кс00Кс.
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Прелазак на Кс01Кс и Кс00Кс
            ///
            /// `compare_and_swap` је еквивалентан Кс00Кс са следећим мапирањем за наручивање меморије:
            ///
            /// Оригинал |Успех |Неуспех
            /// -------- | ------- | -------
            /// Опуштено |Опуштено |Опуштено стицање |Стицање |Прибави издање |Издање |Опуштено АцкРел |АцкРел |Набавите СекЦст |СекЦст |СекЦст
            ///
            /// `compare_exchange_weak` дозвољено је да лажно откаже чак и када поређење успе, што омогућава компајлеру да генерише бољи склопни код када се упоређивање и размена користе у петљи.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Похрањује вредност у атомски цели број ако је тренутна вредност иста као вредност Кс00Кс.
            ///
            /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
            /// У успеху ће ова вредност бити загарантована једнака Кс00Кс.
            ///
            /// `compare_exchange` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
            /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
            /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
            /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
            ///
            /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Похрањује вредност у атомски цели број ако је тренутна вредност иста као вредност Кс00Кс.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// овој функцији је дозвољено да лажно закаже чак и када поређење успе, што може резултирати ефикаснијим кодом на неким платформама.
            /// Повратна вредност је резултат који показује да ли је нова вредност написана и садржи ли претходну вредност.
            ///
            /// `compare_exchange_weak` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
            /// `success` описује потребно наручивање за операцију читања-модификовања-писања која се одвија ако поређење са Кс00Кс успе.
            /// `failure` описује потребно наручивање за операцију утовара које се дешава када поређење не успе.
            /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини успешно учитавање Кс00Кс.
            ///
            /// Наручивање квара може бити само Кс00Кс, Кс01Кс или Кс02Кс и мора бити еквивалентно или слабије од успешног наручивања.
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// нека мут стари=Кс00Кс;
            /// петља {нека нова=стара * 2;
            ///     подударање Кс01Кс Кс02Кс}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Додаје тренутној вредности, враћајући претходну вредност.
            ///
            /// Ова операција се обавија при преливању.
            ///
            /// `fetch_add` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Одузима тренутну вредност, враћајући претходну вредност.
            ///
            /// Ова операција се обавија при преливању.
            ///
            /// `fetch_sub` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// У битовима Кс00Кс са тренутном вредношћу.
            ///
            /// Изводи битовну операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_and` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// У битовима Кс00Кс са тренутном вредношћу.
            ///
            /// Изводи битовну Кс01Кс операцију на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_nand` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (Кс00Кс и Кс01Кс));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// У битовима Кс00Кс са тренутном вредношћу.
            ///
            /// Изводи битовну операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_or` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// У битовима Кс00Кс са тренутном вредношћу.
            ///
            /// Изводи битовну операцију Кс01Кс на тренутној вредности и аргументу Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_xor` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Дохвата вредност и на њу примењује функцију која враћа опционалну нову вредност.Приказује Кс02Кс од Кс03Кс ако је функција вратила Кс01Кс, иначе Кс00Кс.
            ///
            /// Note: Ово може функцију позвати више пута ако је вредност у међувремену промењена из других нити, све док функција враћа Кс00Кс, али ће функција бити примењена само једном на сачувану вредност.
            ///
            ///
            /// `fetch_update` узима два Кс00Кс аргумента за опис редоследа меморије ове операције.
            /// Прва описује тражено наручивање када операција коначно успе, док друга описује тражено наручивање терета.Они одговарају наредбама за успех и неуспех
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Коришћење Кс02Кс као успешног наручивања чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини коначно успешно учитавање Кс00Кс.
            /// Наручивање оптерећења Кс02Кс може бити само Кс00Кс, Кс01Кс или Кс03Кс и мора бити еквивалентно или слабије од успешног наручивања.
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// ассерт_ек! (к.фетцх_упдате (Поредак: : СекЦст, Кс01Кс, | к | Кс00Кс, Ok(7));
            /// ассерт_ек! (к.фетцх_упдате (Поредак: : СекЦст, Кс01Кс, | к | Кс00Кс, Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Максимално са тренутном вредношћу.
            ///
            /// Проналази максимум тренутне вредности и аргумента Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_max` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека бар=42;
            /// нека мак_фоо=фоо.фетцх_мак (трака, Ordering::SeqCst).max(bar);
            /// тврдити! (мак_фоо==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Минимално са тренутном вредношћу.
            ///
            /// Проналази минимум тренутне вредности и аргумент Кс00Кс и поставља нову вредност на резултат.
            ///
            /// Враћа претходну вредност.
            ///
            /// `fetch_min` узима Кс00Кс аргумент који описује редослед меморије ове операције.Могући су сви начини наручивања.
            /// Имајте на уму да коришћење Кс02Кс чини складиште делом ове операције Кс01Кс, а коришћење Кс03Кс чини део утовара Кс00Кс.
            ///
            ///
            /// **Напомена**: Овај метод је доступан само на платформама које подржавају атомске операције на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека трака=12;
            /// нека мин_фоо=фоо.фетцх_мин (трака, Ordering::SeqCst).min(bar);
            /// ассерт_ек! (мин_фоо, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗБЕДНОСТ: расе података спречавају атомске карактеристике.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Враћа променљиви показивач на основни цели број.
            ///
            /// Неатомско читање и писање резултујућег целог броја може бити раса података.
            /// Ова метода је углавном корисна за ФФИ, где се може користити потпис функције
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Повратак Кс00Кс показивача из заједничке референце на овај атом је сигуран јер атомски типови раде са унутрашњом променљивошћу.
            /// Све модификације атома мењају вредност кроз заједничку референцу и могу то безбедно учинити све док користе атомске операције.
            /// Свака употреба враћеног сировог показивача захтева Кс00Кс блок и још увек мора да се придржава истог ограничења: операције на њему морају бити атомске.
            ///
            ///
            /// # Examples
            ///
            /// `` `игнорисати Кс00Кс
            ///
            /// # фн Кс00Кс {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ектерн Кс00Кс {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // БЕЗБЕДНОСТ: Сигурно све док је Кс00Кс атомски.
            /// несигурно {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Враћа претходну вредност (попут __синц_фетцх_анд_адд).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Враћа претходну вредност (попут __синц_фетцх_анд_суб).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// враћа максималну вредност (потписано поређење)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// враћа минималну вредност (потписано поређење)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// враћа максималну вредност (непотписано поређење)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// враћа минималну вредност (непотписано поређење)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗБЕДНОСТ: позивалац мора поштовати уговор о безбедности за Кс00Кс
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Атомска ограда.
///
/// У зависности од наведеног редоследа, ограда спречава компајлер и ЦПУ да преуређују одређене типове меморијских операција око себе.
/// То ствара синхронизацију-са односима између њега и атомским операцијама или оградама у другим нитима.
///
/// Ограда Кс00Кс која има (најмање) Кс01Кс семантику за наручивање, синхронизује се са оградом Кс02Кс са (најмање) Кс03Кс семантиком, ако и само ако постоје операције Кс и И, обе које оперишу на неком атомском објекту Кс04Кс, тако да је А секвенцирано пре Кс, И се синхронизују пре него што Б и И примете промену у М.
/// Ово обезбеђује зависност између А и Б.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Атомске операције са Кс00Кс или Кс01Кс семантиком такође могу да се синхронизују са оградом.
///
/// Ограда која има Кс00Кс наручивање, поред тога што има и Кс01Кс и Кс02Кс семантику, учествује у глобалном програмском редоследу осталих операција и/или ограда Кс03Кс.
///
/// Прихвата поруџбине Кс00Кс, Кс01Кс, Кс02Кс и Кс03Кс.
///
/// # Panics
///
/// З0Паницс0З ако је Кс01Кс Кс00Кс.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Примитив узајамног искључивања заснован на спинлоцк-у.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Сачекајте док стара вредност не буде Кс00Кс.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ова ограда се синхронизује са продавницом у Кс00Кс.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // БЕЗБЕДНОСТ: коришћење атомске ограде је сигурно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ограда меморије компајлера.
///
/// `compiler_fence` не емитује ниједан машински код, али ограничава врсте преуређивања меморије које је дозвољено компајлеру.Конкретно, у зависности од дате семантике Кс01Кс, компајлеру може бити забрањено премештање читања или писања пре или после позива на другу страну позива на Кс00Кс.Имајте на уму да **не** спречава *хардвер* да врши такво преуређивање.
///
/// То није проблем у контексту извршења са једним нити, али када друге нити могу истовремено модификовати меморију, потребни су јачи примитиви за синхронизацију као што је Кс00Кс.
///
/// Преуређивање које спречавају различите семантике редоследа су:
///
///  - са Кс00Кс није дозвољено преуређивање читања и писања преко ове тачке.
///  - са Кс00Кс, претходна читања и писања не могу се премештати у односу на наредна писања.
///  - са Кс00Кс, накнадно читање и писање не могу се померати испред претходних читања.
///  - са Кс00Кс се примењују оба горе наведена правила.
///
/// `compiler_fence` је обично корисно само за спречавање нити да се утркује *са собом*.Односно, ако дата нит извршава један део кода, а затим се прекида и започиње извршавање кода негде другде (док је још увек у истој нити, а концептуално још увек у истом језгру).У традиционалним програмима то се може догодити само када је регистрован обрађивач сигнала.
/// У коду нижег нивоа, такве ситуације могу настати и приликом руковања прекидима, приликом примене зелених нити са предубеђењем итд.
/// Радознали читаоци се подстичу да прочитају расправу о Кс00Кс језгра Кс01Кс.
///
/// # Panics
///
/// З0Паницс0З ако је Кс01Кс Кс00Кс.
///
/// # Examples
///
/// Без Кс00Кс, Кс01Кс у следећем коду *не* гарантује успех, упркос свему што се дешава у једној нити.
/// Да бисте видели зашто, имајте на уму да је преводилац слободан да замени продавнице на Кс03Кс и Кс04Кс, јер су обе Кс01Кс.Ако се догоди, и обрађивач сигнала се позове одмах након ажурирања Кс05Кс, тада ће обрађивач сигнала видети Кс02Кс, али Кс00Кс.
/// Коришћење Кс00Кс поправља ову ситуацију.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // спречити да се ранија писања померају даље од ове тачке
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // БЕЗБЕДНОСТ: коришћење атомске ограде је сигурно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Сигнализује процесор да се налази у спин-лооп-у заузетог чекања (" спин лоцк`).
///
/// Ова функција је застарела у корист Кс00Кс.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}