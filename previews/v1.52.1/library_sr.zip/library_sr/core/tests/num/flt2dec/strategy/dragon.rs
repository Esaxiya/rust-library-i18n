use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Мири је преспора
fn exact_sanity_test() {
    // Овај тест завршава са оним што могу само да претпоставим да је неки угаони случај функције библиотеке Кс00Кс, дефинисан у било ком Ц извођењу које користимо.
    // У ВС 2013 ова функција је очигледно имала грешку јер овај тест не успева када је повезана, али са ВС 2015 грешка изгледа исправљено јер тест ради сасвим у реду.
    //
    // Чини се да је грешка разлика у повратној вредности Кс01Кс, где у ВС 2013 враћа двоструко са битним узорком Кс02Кс, а у ВС 2015 враћа Кс00Кс.
    //
    //
    // За сада само занемарите овај тест у потпуности на МСВЦ-у јер је ионако тестиран негде другде и нисмо супер заинтересовани за тестирање имплементације Кс00Кс сваке платформе.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}