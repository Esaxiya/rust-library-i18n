// Поравнато са два бајта
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // Будући да је Кс01Кс поравнат са два бајта, додавањем 1 бајта томе се добија непоравнати * цонст Кс00Кс
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// фн Кс01Кс {користите Кс00Кс;
//
//    цонст фн Кс00Кс-> Кс01Кс {нека мут рес=0;
//        несигурно {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        рес} цонст АЛИГНЕД: Кс01Кс=Кс00Кс;
//    ассерт_ек! (АЛИГНЕД, 42);
//
//    цонст фн Кс01Кс-> Кс02Кс {лет мут тво_алигнед=Кс00Кс;
//        несигурно {нека уналигнед_птр=Кс01Кс као *мут Кс02Кс као* мут Кс00Кс;
//            птр: : врите_уналигнед (уналигнед_птр, Кс01Кс;} тво_алигнед} цонст УНАЛИГНЕД: Кс02Кс=Кс00Кс;
//
//    ассерт_ек! (НЕЛАГРЕДЕНО, Кс00Кс, Кс01Кс;}
//
//
//
//
//
//
//
//
//
//

// #[test]
// фн Кс00Кс {цонст фн Кс01Кс-> Кс02Кс {нека мут рес=0;
//        несигурна Кс03Кс рес} цонст ПОСТАВЉЕНА: Кс02Кс=Кс00Кс;
//
//    ассерт_ек! (АЛИГНЕД, 42);
//
//    цонст фн Кс01Кс-> Кс02Кс {лет мут тво_алигнед=Кс00Кс;
//        несигурно {нека уналигнед_птр=Кс01Кс као *мут Кс02Кс као* мут Кс00Кс;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        тво_алигнед} цонст НЕЛИГНИРАНО: Кс01Кс=Кс00Кс;
//    ассерт_ек! (НЕЛАГРЕДЕНО, Кс00Кс, Кс01Кс;}
//
//
//
//
//
//
//
//
//
//
//