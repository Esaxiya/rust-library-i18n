// rsbegin.o и Кс01Кс су такозвани Кс00Кс.
// Садрже код потребан за исправну иницијализацију времена извршавања компајлера.
//
// Када се извршива или дилиб слика повеже, сав кориснички код и библиотеке су Кс00Кс између ове две објектне датотеке, тако да код или подаци из Кс01Кс постају први у одговарајућим одељцима слике, док код и подаци из Кс02Кс постају последњи.
// Овај ефекат се може користити за постављање симбола на почетак или на крај одељка, као и за уметање свих потребних заглавља или подножја.
//
// Имајте на уму да се стварна улазна тачка модула налази у покретачком објекту Ц извођења (обично се назива Кс00Кс), који затим позива повратне позиве иницијализације других рунтиме компонената (регистрованих путем још једног посебног одељка слике).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Означава почетак оквира стека да одмотава информативни одељак
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Огребљени простор за унутрашње књиговодство одвијача.
    // Ово је дефинисано као Кс00Кс у $ З0ГЦЦ0З/либгцц/враинд-дв2-фде.х.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Опустите инфо Кс00Кс рутине.
    // Погледајте документе либпаниц_унвинд.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // региструјте информације о одмотавању приликом покретања модула
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // поништи регистрацију при искључивању
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Минутна регистрација Кс00Кс специфична за МинГВ
    pub mod mingw_init {
        // МинГВ-ови стартни објекти (Кс02Кс/Кс03Кс) позваће глобалне конструкторе у одељцима Кс00Кс и Кс01Кс приликом покретања и изласка.
        // У случају ДЛЛ-ова, то се ради када се ДЛЛ учита и истовари.
        //
        // Повезивач ће сортирати одељке, што осигурава да се наши повратни позиви налазе на крају листе.
        // Будући да се конструктори изводе у обрнутом редоследу, ово осигурава да су наши повратни позиви први и последњи извршени.
        //
        //

        #[link_section = ".ctors.65535"] // .цторс. *: Повратни позиви за иницијализацију Ц
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .дторс. *: Повратни позиви за завршетак Ц.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}