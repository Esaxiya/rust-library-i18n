#![stable(feature = "rust1", since = "1.0.0")]

//! Показивачи за бројање референци сигурни у нитима.
//!
//! За више детаља погледајте документацију Кс00Кс.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Меко ограничење количине референци које се могу упутити на Кс00Кс.
///
/// Прелазак овог ограничења прекинуће ваш програм (иако не нужно) на референцама Кс00Кс Кс01Кс.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ТхреадСанитизер не подржава меморијске ограде.
// Да бисте избегли лажно позитивне извештаје у Арц/Веак имплементацији, користите атомска оптерећења за синхронизацију.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Показивач за бројање референци сигуран у нит.Кс00Кс је скраћеница од " Атомицалли Референце Цоунт`.
///
/// Тип Кс02Кс обезбеђује дељено власништво над вредношћу типа Кс00Кс, алоцираном у гомили.Позивање Кс03Кс на Кс04Кс ствара нову инстанцу Кс05Кс, која указује на исто додељивање на хрпи као извор Кс01Кс, истовремено повећавајући број референци.
/// Када се уништи последњи Кс00Кс показивач на дату алокацију, вредност ускладиштена у тој алокацији (која се често назива Кс01Кс) такође се испушта.
///
/// Заједничке референце у З0Руст0З подразумевано онемогућавају мутацију, а Кс04Кс није изузетак: генерално не можете добити променљиву референцу на нешто унутар Кс00Кс.Ако требате мутирати кроз Кс01Кс, користите Кс02Кс, Кс03Кс или један од Кс05Кс типова.
///
/// ## Сигурност навоја
///
/// За разлику од Кс00Кс, Кс01Кс користи атомске операције за бројање референци.То значи да је заштићен од нити.Недостатак је што су атомске операције скупље од уобичајених приступа меморији.Ако не делите додељивања која се броје референцама између нити, размислите о коришћењу Кс02Кс за ниже трошкове.
/// [`Rc<T>`] је сигурно подразумевано, јер ће преводилац ухватити сваки покушај слања Кс00Кс између нити.
/// Међутим, библиотека може одабрати Кс00Кс како би потрошачима библиотеке пружила већу флексибилност.
///
/// `Arc<T>` ће применити Кс01Кс и Кс02Кс све док Кс03Кс имплементира Кс04Кс и Кс00Кс.
/// Зашто не можете да ставите тип Кс01Кс који није безбедан за навоје у Кс02Кс да би био сигуран у вези са нитима?Ово је у почетку можда помало контра-интуитивно: ипак, није ли поента безбедности Кс03Кс нити?Кључ је следећи: Кс00Кс чини вишеструко власништво над истим подацима вишеструким власништвом, али својим подацима не додаје сигурност нити.
///
/// Размислите о `Арц <` [`РефЦелл<T>`]`>`.
/// [`RefCell<T>`] није Кс00Кс, а ако је Кс02Кс увек био Кс01Кс, `Арц <` [`РефЦелл<T>`]`>`такође би било.
/// Али тада бисмо имали проблем:
/// [`RefCell<T>`] није заштићен нити;прати број позајмљивања користећи неатомске операције.
///
/// На крају, то значи да ћете можда морати да упарите Кс01Кс са неком врстом типа Кс02Кс, обично Кс00Кс.
///
/// ## Прекидни циклуси са Кс00Кс
///
/// Метода Кс01Кс се може користити за креирање непоседујућег показивача Кс02Кс.Показивач Кс03Кс може се [`надоградити '][надоградити] д на Кс00Кс, али то ће вратити Кс04Кс ако је вредност сачувана у алокацији већ испуштена.
/// Другим речима, Кс00Кс показивачи не одржавају вредност унутар алокације живом;међутим, они * одржавају алокацију (резервну меморију вредности) на животу.
///
/// Циклус између показивача Кс00Кс никада неће бити уклоњен.
/// Из тог разлога, Кс00Кс се користи за разбијање циклуса.На пример, дрво може да има јаке Кс01Кс показиваче од родитељских чворова до деце, а Кс02Кс показиваче од деце назад до родитеља.
///
/// # Клонирање референци
///
/// Стварање нове референце из постојећег показивача који се броји референцом врши се помоћу Кс01Кс З0 Портраит0З имплементираног за Кс02Кс и Кс00Кс.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Две синтаксе доле су еквивалентне.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // а, б и фоо су сви лукови који упућују на исто меморијско место
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` аутоматски преусмерава на Кс02Кс (путем Кс03Кс З0 Портраит0З), тако да можете да позовете методе `Т` на вредности типа Кс01Кс.Да би се избегла сукобљавања имена са методама `Т`, методе самог Кс04Кс су придружене функције, позване помоћу Кс00Кс:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Арц<T>Имплементације З0траитс0З попут Кс00Кс такође се могу позвати користећи потпуно квалификовану синтаксу.
/// Неки људи више воле да користе потпуно квалификовану синтаксу, док други више воле синтаксу метода-позива.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Синтакса позива-метода
/// let arc2 = arc.clone();
/// // Потпуно квалификована синтакса
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] не аутоматски преусмерава на Кс00Кс, јер је унутрашња вредност можда већ испуштена.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Дељење неких непроменљивих података између нити:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Имајте на уму да овде **не** покрећемо ове тестове.
// Креатори Кс00Кс постају изузетно незадовољни ако нит наџиви главну нит, а затим изађе у исто време (нешто застој), па то једноставно избегавамо не извршавањем ових тестова.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Дељење променљивог Кс00Кс:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Погледајте Кс00Кс за више примера бројања референци уопште.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` је верзија Кс00Кс која садржи непоседујућу референцу на управљану алокацију.
/// Додељивању се приступа позивом Кс00Кс на показивачу Кс01Кс, који враћа [`Оптион`]`<`[`Арц`] `<T>>`.
///
/// Будући да се референца Кс00Кс не рачуна у власништво, неће спречити испуштање вредности сачуване у алокацији, а сам Кс01Кс не даје гаранције да је вредност и даље присутна.
///
/// Стога може вратити Кс00Кс када [`надоградња`] д.
/// Међутим, имајте на уму да референца Кс00Кс *спречава* уклањање саме алокације (складишта подлога).
///
/// Показивач Кс00Кс користан је за задржавање привремене референце на алокацију којом управља Кс01Кс без спречавања испуштања његове унутрашње вредности.
/// Такође се користи за спречавање кружних референци између показивача Кс00Кс, јер међусобне референце поседовања никада не би дозволиле да било који Кс01Кс падне.
/// На пример, дрво може имати јаке Кс00Кс показиваче од родитељских чворова до деце, а Кс01Кс показиваче од деце назад до родитеља.
///
/// Типичан начин добијања показивача Кс01Кс је позивање Кс00Кс.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ово је Кс00Кс за омогућавање оптимизације величине овог типа у енумима, али није нужно важећи показивач.
    //
    // `Weak::new` поставља ово на Кс00Кс тако да не треба да додељује простор на гомили.
    // То није вредност коју ће стварни показивач икада имати јер РцБок има поравнање најмање 2.
    // То је могуће само када Кс00Кс;неодређени Кс01Кс никада се не мота.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ово је доказ од Кс00Кс до З0футуре0З против могућег преуређивања поља, што би ометало иначе сигуран Кс01Кс трансмутабилних унутрашњих типова.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // вредност Кс01Кс делује као сентинел за привремено Кс02Кс способност надоградње слабих показивача или спуштања јачих;ово се користи за избегавање трка у Кс03Кс и Кс00Кс.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Конструише нови Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Почните рачунати слаби показивач као 1, што је слаби показивач који држе сви јаки показивачи Кс00Кс, погледајте Кс01Кс за више информација
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Конструише нови Кс00Кс користећи слабу референцу на себе.
    /// Покушај надоградње слабе референце пре него што се ова функција врати резултираће Кс00Кс вредношћу.
    /// Међутим, слаба референца може се слободно клонирати и сачувати за касније коришћење.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Конструисати унутрашњост у Кс00Кс стању са једном слабом референцом.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно је да се не одричемо власништва над слабим показивачем, иначе би меморија могла бити ослобођена док се Кс00Кс не врати.
        // Ако бисмо заиста желели да пренесемо власништво, могли бисмо да створимо додатни слаби показивач за себе, али то би резултирало додатним ажурирањима броја слабих референци које иначе не би биле потребне.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Сада можемо правилно иницијализовати унутрашњу вредност и претворити нашу слабу референцу у јаку референцу.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Горње уписивање у поље података мора бити видљиво свим нитима које примећују снажно бројање које није нула.
            // Због тога нам је потребно најмање Кс01Кс наручивање да бисмо се синхронизовали са Кс02Кс у Кс00Кс.
            //
            // "Acquire" наручивање није потребно.
            // Када разматрамо могуће понашање Кс01Кс, морамо само да погледамо шта би могао да уради са референцом на Кс00Кс који се не може надоградити:
            //
            // - Може да *клонира* Кс00Кс, повећавајући број слабих референци.
            // - Може испустити те клонове, смањујући број слабих референци (али никада на нулу).
            //
            // Ови нежељени ефекти не делују на нас на било који начин, а никакви други нежељени ефекти нису могући само помоћу безбедног кода.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Јаке референце би заједно требало да поседују дељену слабу референцу, зато немојте покретати деструктор за нашу стару слабу референцу.
        //
        mem::forget(weak);
        strong
    }

    /// Израђује нови Кс00Кс са неиницијализованим садржајем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, са меморијом која је напуњена бајтовима Кс01Кс.
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструише нови Кс00Кс.
    /// Ако Кс01Кс не примени Кс00Кс, тада ће Кс02Кс бити закачен у меморију и не може се преместити.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Конструише нови Кс00Кс, враћа грешку ако додељивање не успе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Почните рачунати слаби показивач као 1, што је слаби показивач који држе сви јаки показивачи Кс00Кс, погледајте Кс01Кс за више информација
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, враћа грешку ако додељивање не успе.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, с меморијом која је напуњена бајтовима Кс01Кс, враћајући грешку ако додељивање не успе.
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Враћа унутрашњу вредност ако Кс00Кс има тачно једну снажну референцу.
    ///
    /// У супротном, враћа се Кс00Кс са истим Кс01Кс који је прослеђен.
    ///
    ///
    /// Ово ће успети чак и ако постоје изванредне слабе референце.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Направите слаб показивач да бисте очистили имплицитну јако-слабу референцу
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Конструише нови атомски пребројани пресек са неиницијализованим садржајем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Конструише нови атомски пребројани пресек са неиницијализованим садржајем, са меморијом која је напуњена бајтовима Кс00Кс.
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Претвара у Кс00Кс.
    ///
    /// # Safety
    ///
    /// Као и код Кс00Кс, на позиваоцу је да гарантује да је унутрашња вредност заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива тренутно недефинисано понашање.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Претвара у Кс00Кс.
    ///
    /// # Safety
    ///
    /// Као и код Кс00Кс, на позиваоцу је да гарантује да је унутрашња вредност заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива тренутно недефинисано понашање.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Конзумира Кс00Кс враћајући умотани показивач.
    ///
    /// Да би се избегло цурење меморије, показивач се мора конвертовати назад у Кс01Кс помоћу Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Пружа необрађени показивач на податке.
    ///
    /// На бројање то не утиче ни на који начин и Кс00Кс се не троши.
    /// Показивач важи све док у Кс00Кс има јаких бројева.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЕЗБЕДНОСТ: Ово не може проћи кроз Кс00Кс или Кс01Кс јер
        // ово је потребно да би се задржало порекло Кс00Кс такво да нпр
        // `get_mut` може писати кроз показивач након што се Рц обнови кроз Кс00Кс.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Конструише Кс00Кс из необрађеног показивача.
    ///
    /// Необрађени показивач мора бити претходно враћен позивом на Кс01Кс где Кс02Кс мора имати исту величину и поравнање као Кс00Кс.
    /// Ово је тривијално тачно ако је Кс01Кс Кс00Кс.
    /// Имајте на уму да ако Кс00Кс није Кс01Кс, али има исту величину и поравнање, ово је у основи попут претварања референци различитих врста.
    /// Погледајте Кс00Кс за више информација о томе која ограничења важе у овом случају.
    ///
    /// Корисник Кс00Кс мора осигурати да одређена вредност Кс01Кс падне само једном.
    ///
    /// Ова функција није сигурна јер неправилна употреба може довести до несигурности меморије, чак и ако се враћеном Кс00Кс никада не приступи.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Вратите се на Кс00Кс да бисте спречили цурење.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Даљи позиви на Кс00Кс не би били сигурни у меморији.
    /// }
    ///
    /// // Меморија је ослобођена када је Кс00Кс изашао из опсега горе, тако да Кс01Кс сада виси!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Обрните офсет да бисте пронашли оригинални АрцИннер.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ствара нови Кс00Кс показивач на ову алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ово опуштено је у реду јер проверавамо вредност у ЦАС испод.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // проверите да ли је слаби бројач тренутно Кс00Кс;ако је тако, заврти се.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: овај код тренутно занемарује могућност преливања
            // у Кс00Кс;генерално и Рц и Арц треба прилагодити да би се носило са преливањем.
            //

            // За разлику од Кс00Кс, ово нам треба да буде Ацкуире читање за синхронизацију са записом који долази из Кс01Кс, тако да се догађаји пре тог писања дешавају пре овог читања.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Уверите се да не стварамо висећи Слаби
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Добија број Кс00Кс показивача на ову алокацију.
    ///
    /// # Safety
    ///
    /// Ова метода је сама по себи сигурна, али правилна употреба захтева додатну пажњу.
    /// Друга нит може у било ком тренутку променити бројач слабих, укључујући потенцијално између позивања ове методе и деловања на резултат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ова тврдња је детерминистичка јер нисмо делили Кс00Кс или Кс01Кс између нити.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ако је тренутно слабо закључано, вредност броја је била 0 непосредно пре узимања закључавања.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Добија број снажних Кс00Кс показивача на ову алокацију.
    ///
    /// # Safety
    ///
    /// Ова метода је сама по себи сигурна, али правилна употреба захтева додатну пажњу.
    /// Друга нит може у било ком тренутку да промени јаки број, укључујући потенцијално између позивања ове методе и деловања на резултат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ова тврдња је детерминистичка јер нисмо делили Кс00Кс између нити.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Повећава јаки број референци на Кс00Кс повезан са датим показивачем за један.
    ///
    /// # Safety
    ///
    /// Показивач мора бити добијен преко Кс00Кс, а придружена инстанца Кс01Кс мора бити важећа (тј
    /// јаки број мора бити најмање 1) током трајања ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ова тврдња је детерминистичка јер нисмо делили Кс00Кс између нити.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Задржите Арц, али не додирујте поновно бројање умотавањем у МануаллиДроп
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Сада повећајте поновно бројање, али не испуштајте ни ново
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Бројач снажних референци на Кс00Кс повезан са датим показивачем смањује за један.
    ///
    /// # Safety
    ///
    /// Показивач мора бити добијен преко Кс00Кс, а придружена инстанца Кс01Кс мора бити важећа (тј
    /// јаки број мора бити најмање 1) при позивању на ову методу.
    /// Овај метод се може користити за ослобађање коначног Кс00Кс и пратеће меморије, али **не би требало** да се позива након објављивања коначног Кс01Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Те тврдње су детерминистичке јер нисмо делили Кс00Кс између нити.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ова несигурност је у реду јер док је овај лук жив гарантирамо да је унутрашњи показивач важећи.
        // Даље, знамо да је сама структура Кс00Кс Кс01Кс, јер су и унутрашњи подаци Кс02Кс, тако да можемо позајмити непроменљиви показивач на овај садржај.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Неуграђени део Кс00Кс.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Тренутно уништите податке, иако можда нећемо ослободити саму расподелу оквира (можда још увек леже слаби показивачи).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Одбаците слабе критике које колективно држе све снажне референце
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Приказује Кс00Кс ако два `Арц`-а указују на исту алокацију (у вени сличној Кс01Кс).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Додељује Кс00Кс са довољним простором за потенцијално неодређену унутрашњу вредност тамо где вредност има предвиђени распоред.
    ///
    /// Функција Кс01Кс се позива помоћу показивача података и мора вратити (потенцијално масно) показивач за Кс00Кс.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Израчунајте изглед користећи задати распоред вредности.
        // Раније је изглед израчунат на изразу Кс00Кс, али ово је створило погрешно поравнату референцу (види Кс01Кс).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Додељује Кс00Кс са довољним простором за потенцијално неодређену унутрашњу вредност где вредност има предвиђени изглед, враћа грешку ако додељивање не успе.
    ///
    ///
    /// Функција Кс01Кс се позива помоћу показивача података и мора вратити (потенцијално масно) показивач за Кс00Кс.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Израчунајте изглед користећи задати распоред вредности.
        // Раније је изглед израчунат на изразу Кс00Кс, али ово је створило погрешно поравнату референцу (види Кс01Кс).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Иницијализујте АрцИннер
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Додељује Кс00Кс са довољно простора за неодређену унутрашњу вредност.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Доделите за Кс00Кс користећи задату вредност.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копирај вредност у бајтовима
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Ослободите алокацију без испуштања њеног садржаја
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Додељује Кс00Кс задате дужине.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Копирајте елементе из реза у ново додељени лук <\[Т\]>
    ///
    /// Небезбедно јер позивалац мора или да преузме власништво или да веже Кс00Кс.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Конструише Кс00Кс из итератора за који се зна да је одређене величине.
    ///
    /// Понашање није дефинисано ако је величина погрешна.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // З0Паниц0З штитник при клонирању Т елемената.
        // У случају З0паниц0З, елементи који су записани у нови АрцИннер ће бити испуштени, а затим ће се меморија ослободити.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Показивач на први елемент
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Прекид узбуне.Заборавите чувара да не ослободи нови АрцИннер.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специјализација З0 Портраит0З коришћена за Кс00Кс.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Прави клон показивача Кс00Кс.
    ///
    /// Ово ствара још један показивач на исту алокацију, повећавајући јак број референци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Коришћење опуштеног редоследа овде је у реду, јер познавање оригиналне референце спречава друге нити да погрешно избришу објекат.
        //
        // Као што је објашњено у Кс00Кс, повећање бројача референци увек се може извршити помоћу мемори_ордер_релакед: Нове референце на објекат могу се формирати само из постојеће референце, а преношење постојеће референце из једне нити у другу већ мора да обезбеди потребну синхронизацију.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Међутим, морамо се чувати од масовних поновних бројања у случају да је неко `мем: : заборавио` Лукове.
        // Ако то не учинимо, бројање се може прелити и корисници ће после користити бесплатно.
        // Расно се заситимо до Кс00Кс под претпоставком да не постоји Кс01Кс милијарди нити које повећавају број референци одједном.
        //
        // Ова З0бранцх0З никада неће бити узета у било који реалан програм.
        //
        // Прекидамо јер је такав програм невероватно изрођен и не бринемо да га подржавамо.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Прави променљиву референцу на дати Кс00Кс.
    ///
    /// Ако постоје други Кс00Кс или Кс01Кс показивачи на исту алокацију, тада ће Кс02Кс створити нову алокацију и позвати Кс03Кс на унутрашњу вредност како би се осигурало јединствено власништво.
    /// Ово се такође назива клонирањем на писање.
    ///
    /// Имајте на уму да се ово разликује од понашања Кс00Кс који раздваја све преостале показиваче Кс01Кс.
    ///
    /// Такође погледајте Кс00Кс, који неће успети него клонирати.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Нећу клонирати ништа
    /// let mut other_data = Arc::clone(&data); // Неће клонирати унутрашње податке
    /// *Arc::make_mut(&mut data) += 1;         // Клонира унутрашње податке
    /// *Arc::make_mut(&mut data) += 1;         // Нећу клонирати ништа
    /// *Arc::make_mut(&mut other_data) *= 2;   // Нећу клонирати ништа
    ///
    /// // Сада Кс00Кс и Кс01Кс указују на различите алокације.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Имајте на уму да имамо и јаку и слабу референцу.
        // Дакле, пуштање само наше снажне референце само по себи неће проузроковати ослобађање меморије.
        //
        // Користите Ацкуире да бисте осигурали да уочимо било каква уписивања у Кс01Кс која се дешавају пре уписивања издања (тј. Декрементирање) у Кс00Кс.
        // Будући да имамо слаб број, нема шансе да се сам АрцИннер може ослободити.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Постоји још један снажан показивач, па морамо клонирати.
            // Унапред доделите меморију како бисте омогућили директно писање клониране вредности.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Опуштено је довољно у наведеном, јер је ово у основи оптимизација: увек се утркујемо са одбаченим слабим показивачима.
            // У најгорем случају, на крају смо непотребно доделили нови лук.
            //

            // Уклонили смо последњу јаку препоруку, али преостали су још слаби.
            // Садржај ћемо преместити у нови лук, а остале слабе референце поништити.
            //

            // Имајте на уму да читање Кс00Кс не може дати Кс01Кс (тј. Закључано), јер слаб број може закључати само нит са јаком референцом.
            //
            //

            // Материјализујте наш сопствени имплицитни слаби показивач, тако да може очистити АрцИннер по потреби.
            //
            let _weak = Weak { ptr: this.ptr };

            // Можете само украсти податке, преостао је само Веакс
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Били смо једина референца било које врсте;уназадите јаки број реф.
            //
            this.inner().strong.store(1, Release);
        }

        // Као и код Кс00Кс, несигурност је у реду јер је наша референца за почетак била јединствена или је постала клонирањем садржаја.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Враћа променљиву референцу у дати Кс00Кс, ако нема других показивача Кс01Кс или Кс02Кс на исту алокацију.
    ///
    ///
    /// У супротном враћа Кс00Кс, јер није сигурно мутирати заједничку вредност.
    ///
    /// Такође погледајте Кс00Кс, који ће Кс01Кс добити унутрашњу вредност када постоје други показивачи.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ова несигурност је у реду јер смо загарантовани да је враћени показивач *једини* показивач који ће икада бити враћен Т.
            // Наш број референци је загарантован у овом тренутку 1, а ми смо захтевали да лук буде Кс00Кс, па враћамо једину могућу референцу на унутрашње податке.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Враћа променљиву референцу у дати Кс00Кс, без икакве провере.
    ///
    /// Такође погледајте Кс00Кс, који је сигуран и врши одговарајуће провере.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ниједан други показивач Кс00Кс или Кс01Кс на исту алокацију не сме бити дереференциран током трајања враћене позајмице.
    ///
    /// То је тривијалан случај ако такви показивачи не постоје, на пример одмах након Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Пазимо да *не* креирамо референцу која покрива поља Кс00Кс, јер би то било замјенско име уз истовремени приступ бројању референци (нпр.
        // до Кс00Кс).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Утврдите да ли је ово јединствена референца (укључујући слабе референце) на основне податке.
    ///
    ///
    /// Имајте на уму да ово захтева закључавање слабог броја реф.
    fn is_unique(&mut self) -> bool {
        // закључајте број слабих показивача ако се чини да смо једини носилац слабог показивача.
        //
        // Ознака за преузимање овде осигурава везу пре дешавања са било којим уписом у Кс01Кс (посебно у Кс03Кс) пре смањења броја Кс02Кс (путем Кс00Кс, који користи издање).
        // Ако надограђени слаби реф никада није испуштен, ЦАС овде неће успети, па не бринемо за синхронизацију.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ово мора бити Кс00Кс да би се синхронизовао са декретом бројача Кс01Кс у Кс02Кс-једини приступ који се дешава када се одбаци било која референца осим последње.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Пуштање издања овде се синхронизује са читањем у Кс00Кс, ефикасно спречавајући да се претходно читање Кс01Кс догоди након писања.
            //
            //
            self.inner().weak.store(1, Release); // отпустите браву
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Испушта Кс00Кс.
    ///
    /// Ово ће смањити јак број референци.
    /// Ако јаки број референци достигне нулу, тада су једине остале референце (ако их има) Кс00Кс, па Кс01Кс добијамо унутрашњу вредност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Не штампа ништа
    /// drop(foo2);   // Штампа Кс00Кс
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Будући да је Кс00Кс већ атомски, не треба да синхронизујемо са другим нитима уколико не желимо да избришемо објекат.
        // Иста логика се односи на доњи Кс00Кс на број Кс01Кс.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ова ограда је потребна да би се спречило преуређивање употребе података и брисање података.
        // Будући да је означен Кс00Кс, смањење броја референци се синхронизује са овом оградом Кс01Кс.
        // То значи да се употреба података дешава пре смањења броја референци, што се дешава пре ове ограде, што се дешава пре брисања података.
        //
        // Као што је објашњено у Кс00Кс,
        //
        // > Важно је наметнути сваки могући приступ објекту у једном
        // > нит (кроз постојећу референцу) да се *догоди пре* брисања
        // > објекат у другој нити.То постиже Кс00Кс
        // > операција након испуштања референце (било који приступ објекту
        // > преко ове референце се очигледно морало догодити раније), и ан
        // > "acquire" операција пре брисања објекта.
        //
        // Конкретно, иако је садржај лука обично непроменљив, могуће је имати унутрашње записе у нешто попут Мутека<T>.
        // Пошто Мутек није стечен када се брише, не можемо се ослонити на његову синхронизациону логику како би уписи у нит А учинили видљивим деструктору покренутом у нити Б.
        //
        //
        // Такође имајте на уму да би овде ограда Ацкуире вероватно могла бити замењена теретом Ацкуире, што би могло побољшати перформансе у спорним ситуацијама.Погледајте Кс00Кс.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Покушај да се Кс00Кс спусти на бетон.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Конструише нови Кс00Кс, без издвајања меморије.
    /// Позивање Кс01Кс на повратну вредност увек даје Кс00Кс.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Тип помоћника који омогућава приступ бројању референци без давања било каквих тврдњи о пољу података.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Враћа сирови показивач на објекат Кс01Кс на који је указан овај Кс00Кс.
    ///
    /// Показивач је важећи само ако постоје неке јаке референце.
    /// Показивач може да се виси, не поравна или чак Кс00Кс у супротном.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Обоје указују на исти предмет
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Снажни га овде одржава на животу, тако да и даље можемо приступити објекту.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Али не више.
    /// // Можемо Кс00Кс, али приступ показивачу би довео до недефинисаног понашања.
    /// // ассерт_ек! ("здраво", несигурно {Кс00Кс;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ако показивач виси, вратимо стражара директно.
            // Ово не може бити важећа адреса корисног терета, јер је носивост поравната најмање као АрцИннер Кс00Кс.
            ptr as *const T
        } else {
            // БЕЗБЕДНОСТ: ако ис_данглинг врати фалсе, тада се показивач не може преусмјерити.
            // Корисни терет у овом тренутку може пасти, а ми морамо да одржавамо провенијенцију, па користите манипулацију сировим показивачем.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Конзумира Кс00Кс и претвара га у необрађени показивач.
    ///
    /// Ово претвара слаби показивач у необрађени показивач, истовремено задржавајући власништво над једном слабом референцом (ова операција не мења слаби број).
    /// Може се вратити у Кс01Кс са Кс00Кс.
    ///
    /// Примењују се иста ограничења приступа циљу показивача као и код Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Претвара сирови показивач који је претходно креирао Кс01Кс назад у Кс00Кс.
    ///
    /// Ово се може користити за сигурно добијање јаке референце (позивањем Кс01Кс касније) или за ослобађање броја слабих ако испустите Кс00Кс.
    ///
    /// Преузима власништво над једном слабом референцом (са изузетком показивача креираних од Кс00Кс, јер ови не поседују ништа; метода и даље ради на њима).
    ///
    /// # Safety
    ///
    /// Показивач мора да потиче из Кс00Кс и још увек мора да поседује потенцијално слабу референцу.
    ///
    /// Дозвољено је да јаки број буде 0 у тренутку када ово зовете.
    /// Ипак, ово преузима власништво над једном слабом референцом која је тренутно представљена као необрађени показивач (ова операција не мења слаби број) и зато мора бити упарена са претходним позивом на Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Умањи последњу слабу тачку.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Погледајте Кс00Кс за контекст о томе како је изведен улазни показивач.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ово је висећи Слаб.
            ptr as *mut ArcInner<T>
        } else {
            // У супротном, загарантовано нам је да показивач потиче од нервозна Слаба.
            // БЕЗБЕДНОСТ: дата_оффсет је сигурно позвати, јер птр упућује на стварни (потенцијално испуштени) Т.
            let offset = unsafe { data_offset(ptr) };
            // Дакле, обрћемо офсет да бисмо добили цео РцБок.
            // БЕЗБЕДНОСТ: показивач потиче од слабости, тако да је овај помак сигуран.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗБЕДНОСТ: сада смо обновили оригинални слаби показивач, тако да можемо створити слаб.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Покушаји надоградње показивача Кс01Кс на Кс00Кс, одлагање испуштања унутрашње вредности ако је успешно.
    ///
    ///
    /// Враћа Кс00Кс ако је унутрашња вредност у међувремену испуштена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Уништите све снажне показиваче.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Користимо ЦАС петљу за повећавање јаког броја уместо фетцх_адд, јер ова функција никада не би требало да броји референце од нуле до један.
        //
        //
        let inner = self.inner()?;

        // Опуштено оптерећење, јер свако записивање 0 које можемо да посматрамо оставља поље у трајно нултом стању (тако да је очитавање Кс00Кс од 0 у реду), а било која друга вредност се потврђује путем ЦАС-а доле.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Погледајте коментаре у Кс00Кс зашто то радимо (за Кс01Кс).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Опуштено је у реду за случај неуспеха, јер немамо никаква очекивања о новој држави.
            // Набавка је неопходна за синхронизацију случаја успеха са Кс00Кс, када се унутрашња вредност може покренути након што су Кс01Кс референце већ креиране.
            // У том случају очекујемо да ћемо уочити потпуно иницијализовану вредност.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // нула је означена горе
                Err(old) => n = old,
            }
        }
    }

    /// Добија број снажних Кс00Кс показивача који упућују на ову алокацију.
    ///
    /// Ако је Кс01Кс креиран помоћу Кс00Кс, вратиће се 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Добија приближни број Кс00Кс показивача који упућују на ову алокацију.
    ///
    /// Ако је Кс01Кс креиран помоћу Кс00Кс или ако нема преосталих јаких показивача, вратиће се 0.
    ///
    /// # Accuracy
    ///
    /// Због детаља имплементације, враћена вредност може бити искључена за 1 у било ком смеру када друге нити манипулишу било којим `Арц`с или`Веак`с-ом који упућују на исту алокацију.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Будући да смо приметили да је постојао барем један снажни показивач након читања слабог бројача, знамо да је имплицитна слаба референца (присутна кад год су живе неке јаке референце) још увек постојала када смо посматрали слабо бројање и зато је можемо безбедно одузети.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Враћа Кс01Кс када се показивач клати и нема додељеног Кс00Кс (тј. Када је овај Кс02Кс креирао Кс03Кс).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Пазимо да *не* направимо референцу која покрива поље Кс00Кс, јер поље може истовремено бити мутирано (на пример, ако се одустане од последњег Кс01Кс, поље података ће се уклонити на месту).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Приказује Кс01Кс ако два `Слаба` воде на исто додељивање (слично Кс02Кс) или ако оба не упућују на било које додељивање (јер су креирана са Кс00Кс.
    ///
    ///
    /// # Notes
    ///
    /// Будући да ово упоређује показиваче, то значи да ће се Кс00Кс изједначити, иако не указују на било какву алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Упоређујући Кс00Кс.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Прави клон показивача Кс00Кс који указује на исту алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Погледајте коментаре у Кс00Кс о томе зашто је ово опуштено.
        // Ово може да користи фетцх_адд (занемарујући закључавање), јер је слаб број закључан само тамо где *нема других* слабих показивача.
        //
        // (Дакле, у том случају не можемо покретати овај код).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Погледајте коментаре у Кс00Кс зашто то радимо (за Кс01Кс).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструише нови Кс00Кс, без издвајања меморије.
    /// Позивање Кс01Кс на повратну вредност увек даје Кс00Кс.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Испушта показивач Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Не штампа ништа
    /// drop(foo);        // Штампа Кс00Кс
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ако сазнамо да смо били последњи слаби показивач, време је да у потпуности ослободимо податке.Погледајте дискусију у Кс00Кс о редоследу меморије
        //
        // Овде није потребно проверавати закључано стање, јер се слаб број може закључати само ако је постојао тачно један слаби реф, што значи да би пад могао тек накнадно да се УКЉУЧИ на тај преостали слаби реф, што се може догодити тек након отпуштања закључавања.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ми овде радимо ову специјализацију, а не као општију оптимизацију на Кс00Кс, јер би у супротном додала трошак свим провјерама једнакости на реф.
/// Претпостављамо да се `Арц` користе за чување великих вредности, које се споро клонирају, али су и тешке за проверу једнакости, због чега се овај трошак лакше исплати.
///
/// Такође је вероватније да имате два Кс00Кс клона, који указују на исту вредност, него два `&Т`.
///
/// То можемо учинити само када Кс00Кс као Кс01Кс може бити намерно нефлексиван.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Једнакост за два `Арц`-а.
    ///
    /// Два `Арц` су једнака ако су њихове унутрашње вредности једнаке, чак и ако су ускладиштене у различитом распореду.
    ///
    /// Ако Кс00Кс такође примењује Кс01Кс (што подразумева рефлексивност једнакости), два `Арц`-а која указују на исту алокацију су увек једнака.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Неједнакост за два `Арц`-а.
    ///
    /// Два `Арц` су неједнака ако су њихове унутрашње вредности неједнаке.
    ///
    /// Ако Кс00Кс такође имплементира Кс01Кс (што подразумева рефлексивност једнакости), два `Арц`-а која указују на исту вредност никада нису неједнака.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Делимично поређење за два `Арц`.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Мање од поређења за два `Арц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Поређење " мање или једнако`за два " лука`.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Веће упоређивање за два `Арц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Поређење " веће или једнако`за два " лука`.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Поређење за два `Арц`.
    ///
    /// Њих двоје се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Ствара нови Кс01Кс, са вредношћу Кс02Кс за Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Додијелите референтно пребројану кришку и попуните је клонирањем ставки `в`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Доделите референтно бројени Кс00Кс и копирајте Кс01Кс у њега.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Доделите референтно бројени Кс00Кс и копирајте Кс01Кс у њега.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Преместите уоквирени објекат у нову додељивање рачунато бројем референци.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Доделите референтно пребројану кришку и преместите ставке `в` у њу.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Дозволите Вецу да ослободи меморију, али не и да уништи његов садржај
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Узима сваки елемент у Кс01Кс и сакупља га у Кс00Кс.
    ///
    /// # Техничке карактеристике
    ///
    /// ## Општи случај
    ///
    /// У општем случају, прикупљање у Кс01Кс врши се прво сакупљањем у Кс00Кс.Односно, када пишете следеће:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ово се понаша као да смо написали:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Овде се дешава први скуп расподела.
    ///     .into(); // Овде се дешава друго издвајање за Кс00Кс.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ово ће доделити онолико пута колико је потребно за конструкцију Кс01Кс, а затим ће доделити једном за претварање Кс02Кс у Кс00Кс.
    ///
    ///
    /// ## Итератори познате дужине
    ///
    /// Када ваш Кс01Кс примени Кс02Кс и буде тачне величине, извршиће се једно додељивање за Кс00Кс.На пример:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Овде се дешава само једно додељивање.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Специјализација З0 Портраит0З која се користи за прикупљање у Кс00Кс.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ово је случај за Кс00Кс итератор.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗБЕДНОСТ: Морамо осигурати да итератор има тачну дужину као и ми.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Вратите се нормалној примени.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Добијте офсет унутар Кс00Кс за носивост иза показивача.
///
/// # Safety
///
/// Показивач мора указивати на (и имати ваљане метаподатке за) претходно важећу инстанцу Т, али Т може бити испуштено.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Поравнајте неодређену вредност на крај АрцИннер-а.
    // Будући да је РцБок Кс00Кс, то ће увек бити последње поље у меморији.
    // БЕЗБЕДНОСТ: будући да су једини могући неодређени типови кришки, З0 Портраит0З објекти,
    // и екстерни типови, захтеви за безбедност улаза су тренутно довољни да задовоље захтеве алигн_оф_вал_рав;ово је детаљ примене језика на који се ван З0стд0З не може поуздати.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}