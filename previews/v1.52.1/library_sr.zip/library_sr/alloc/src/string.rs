//! УТФ-8 кодирани низ који се шири.
//!
//! Овај модул садржи тип Кс00Кс, Кс01Кс З0 Портраит0З за претварање у низове и неколико типова грешака које могу настати радом са [`Стринг`] с.
//!
//!
//! # Examples
//!
//! Постоји више начина за креирање новог Кс00Кс од литералног низа:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Можете створити нови Кс00Кс од постојећег спајањем са
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ако имате З0вецтор0З важећих Кс00Кс бајтова, од њега можете направити Кс01Кс.Можете и обрнуто.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Знамо да су ови бајтови валидни, па ћемо користити Кс00Кс.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// УТФ-8 кодирани низ који се шири.
///
/// Тип Кс01Кс је најчешћи тип низа који има власништво над садржајем низа.Има блиску везу са позајмљеним колегом, примитивним Кс00Кс.
///
/// # Examples
///
/// Можете створити Кс01Кс од Кс02Кс са Кс00Кс:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Можете додати Кс00Кс на Кс01Кс методом Кс02Кс, а Кс03Кс методом Кс04Кс:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ако имате З0вецтор0З од Кс00Кс бајтова, можете од њега створити Кс01Кс методом Кс02Кс:
///
/// ```
/// // неки бајтови, у З0вецтор0З
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Знамо да су ови бајтови валидни, па ћемо користити Кс00Кс.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Стрингови су увек важећи Кс01Кс.Ово има неколико импликација, од којих је прва да, ако вам треба низ који није УТФ-8, размислите о Кс02Кс.Слично је, али без ограничења Кс03Кс.Друга импликација је да не можете индексирати у Кс00Кс:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Индексирање је намењено сталном раду, али Кс00Кс кодирање нам то не дозвољава.Даље, није јасно какву ствар индекс треба да врати: бајт, кодну тачку или кластер графема.
/// Методе Кс00Кс и Кс01Кс враћају итераторе преко прва два, респективно.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Стринг`с Имплементатион [`Дереф`] `<Target=str>`, и тако наследите све методе [`стр`].Поред тога, то значи да Кс01Кс можете проследити функцији која узима Кс02Кс користећи амперсанд Кс00Кс:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ово ће створити Кс00Кс од Кс01Кс и предати га. Ова конверзија је веома скупа, па ће функције, опћенито, прихватити [`&стр`] као аргументе, осим ако им Кс02Кс није потребан из неког одређеног разлога.
///
/// У одређеним случајевима З0Руст0З нема довољно података за извршење ове конверзије, познате као присила Кс01Кс.У следећем примеру, кришка низа Кс02Кс имплементира З0 Портраит0З Кс00Кс, а функција Кс03Кс узима све што имплементира З0 Портраит0З.
/// У овом случају З0Руст0З би требало да изврши две имплицитне конверзије, што З0Руст0З нема средстава.
/// Из тог разлога, следећи пример се неће компајлирати.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Постоје две опције које би уместо тога функционисале.Прва би била промена линије Кс01Кс у Кс00Кс, користећи методу Кс02Кс за изричито издвајање низа низа који садржи низ.
/// Други начин мења Кс01Кс у Кс00Кс.
/// У овом случају преусмеравамо Кс02Кс на Кс01Кс, а затим Кс03Кс враћамо на Кс00Кс.
/// Други начин је идиоматичнији, међутим обојица раде на конверзији експлицитно, а не на ослањању на имплицитну конверзију.
///
/// # Representation
///
/// Кс00Кс се састоји од три компоненте: показивача на неке бајтове, дужине и капацитета.Показивач показује на интерни бафер који Кс01Кс користи за чување својих података.Дужина је број бајтова који се тренутно чувају у баферу, а капацитет је величина бафера у бајтовима.
///
/// Као таква, дужина ће увек бити мања или једнака капацитету.
///
/// Овај бафер се увек чува на гомили.
///
/// Ово можете погледати методама Кс00Кс, Кс01Кс и Кс02Кс:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // ФИКСМЕ Ажурирајте ово када је вец_инто_рав_партс стабилизован.
/// // Спречите аутоматско испуштање података низа
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // прича има деветнаест бајтова
/// assert_eq!(19, len);
///
/// // Можемо поново изградити Стринг од птр, лен и капацитета.
/// // Све ово није сигурно јер смо одговорни за то да компоненте буду ваљане:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ако Кс00Кс има довољан капацитет, додавање елемената у њега неће се прерасподелити.На пример, размотрите овај програм:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ово ће дати следеће:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// У почетку уопште немамо додељену меморију, али док се придружујемо низу, он на одговарајући начин повећава његов капацитет.Ако уместо тога користимо методу Кс00Кс за прво додељивање тачног капацитета:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// На крају имамо другачији излаз:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Овде нема потребе за додељивањем више меморије унутар петље.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Могућа вредност грешке при конвертовању Кс00Кс из бајта Кс01Кс З0вецтор0З.
///
/// Овај тип је тип грешке за метод Кс01Кс на Кс00Кс.
/// Дизајниран је на такав начин да пажљиво избегне прерасподелу: Кс00Кс метода ће вратити бајт З0вецтор0З који је коришћен у покушају конверзије.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Тип Кс01Кс који пружа Кс02Кс представља грешку која се може догодити приликом претварања дела [`у8`] с у Кс00Кс.
/// У том смислу, аналог је Кс00Кс, а можете га добити од Кс01Кс путем Кс02Кс методе.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // неки неважећи бајтови, у З0вецтор0З
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Могућа вредност грешке при конвертовању Кс00Кс из бајтног пресека Кс01Кс.
///
/// Овај тип је тип грешке за метод Кс01Кс на Кс00Кс.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Ствара нови празан Кс00Кс.
    ///
    /// С обзиром да је Кс00Кс празан, ово неће доделити почетни бафер.Иако то значи да је ова почетна операција веома јефтина, касније може додати прекомерно додељивање када додате податке.
    ///
    /// Ако имате идеју о томе колико података ће садржати Кс00Кс, размотрите метод Кс01Кс да бисте спречили прекомерно прерасподелу.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Ствара нови празан Кс00Кс одређеног капацитета.
    ///
    /// `Низови имају унутрашњи бафер за чување њихових података.
    /// Капацитет је дужина тог бафера и може се испитати методом Кс00Кс.
    /// Ова метода ствара празан Кс00Кс, али онај са почетним међуспремником који може да садржи Кс01Кс бајтове.
    /// Ово је корисно када можда додајете гомилу података у Кс00Кс, смањујући број прерасподељивања које треба да уради.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ако је задати капацитет Кс00Кс, неће доћи до додељивања, а овај метод је идентичан методу Кс01Кс.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Стринг не садржи знакове, иако има капацитет за више
    /// assert_eq!(s.len(), 0);
    ///
    /// // Све се то ради без прерасподјеле ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... али ово може учинити преусмеравање низа
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): код Кс00Кс својствена метода Кс01Кс, која је потребна за дефиницију ове методе, није доступна.
    // Будући да нам овај метод није потребан за тестирање, само ћу га натерати. Напомена: погледајте Кс00Кс модул у Кс01Кс за више информација
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Претвара З0вецтор0З бајтова у Кс00Кс.
    ///
    /// Низ Кс01Кс је направљен од бајтова Кс00Кс, а З0вецтор0З бајтова Кс02Кс је од бајтова, па се ова функција претвара између њих.
    /// Нису сви одсечци бајтова важећи `стрингови ', међутим: Кс01Кс захтева да је важећи Кс00Кс.
    /// `from_utf8()` проверава да ли су бајтови валидни Кс00Кс, а затим врши конверзију.
    ///
    /// Ако сте сигурни да је бајтни пресек важећи Кс00Кс, а не желите да имате опште трошкове провере ваљаности, постоји несигурна верзија ове функције, Кс01Кс, која се понаша на исти начин, али прескакање пропушта.
    ///
    ///
    /// Ова метода ће се побринути да З0вецтор0З не копира, ради ефикасности.
    ///
    /// Ако вам је потребан Кс02Кс уместо Кс01Кс, размислите о Кс00Кс.
    ///
    /// Инверзна метода је Кс00Кс.
    ///
    /// # Errors
    ///
    /// Враћа Кс01Кс ако пресек није Кс02Кс са описом зашто дати бајтови нису Кс00Кс.Укључен је и З0вецтор0З у који сте се уселили.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки бајтови, у З0вецтор0З
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Знамо да су ови бајтови валидни, па ћемо користити Кс00Кс.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Нетачни бајтови:
    ///
    /// ```
    /// // неки неважећи бајтови, у З0вецтор0З
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Погледајте документе за Кс00Кс за више детаља о томе шта можете учинити са овом грешком.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Претвара део бајтова у низ, укључујући неважеће знакове.
    ///
    /// Низови су направљени од бајтова Кс01Кс, а део бајтова Кс02Кс од бајтова, па се ова функција претвара између њих.Нису сви бајтни резови важећи низови: низови морају бити важећи Кс00Кс.
    /// Током ове конверзије, Кс01Кс ће заменити све неваљане секвенце Кс02Кс са Кс00Кс, што изгледа овако:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ако сте сигурни да је бајтни пресек важећи Кс00Кс и не желите да претрпите претворбу, постоји несигурна верзија ове функције, Кс01Кс, која има исто понашање, али прескаче провере.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ова функција враћа Кс01Кс.Ако је наш бајтни пресек неважећи Кс02Кс, тада треба да убацимо заменљиве знакове, који ће променити величину низа, па ће зато бити потребан Кс00Кс.
    /// Али ако је то већ важећи Кс00Кс, не треба нам ново додељивање.
    /// Овај тип повратка омогућава нам да обрадимо оба случаја.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки бајтови, у З0вецтор0З
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Нетачни бајтови:
    ///
    /// ```
    /// // неки неваљани бајтови
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Декодирајте УТФ-16 кодирани З0вецтор0З Кс01Кс у Кс00Кс, враћајући Кс02Кс ако Кс03Кс садржи неваљане податке.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ово се не ради путем цоллецт: : <Result<_, _>> () из разлога перформанси.
        // FIXME: функција се може поново поједноставити када је Кс00Кс затворен.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Декодирајте УТФ-16 кодирани део Кс02Кс у Кс01Кс, замењујући неваљане податке са Кс00Кс.
    ///
    /// За разлику од Кс02Кс који враћа Кс00Кс, Кс01Кс враћа Кс03Кс јер претворба Кс04Кс у Кс05Кс захтева додјелу меморије.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Разлаже Кс00Кс на његове сирове компоненте.
    ///
    /// Враћа сирови показивач на основне податке, дужину низа (у бајтовима) и додељени капацитет података (у бајтовима).
    /// То су исти аргументи истим редоследом као и аргументи Кс00Кс.
    ///
    /// Након позива ове функције, позивалац је одговоран за меморију којом је раније управљао Кс00Кс.
    /// Једини начин да се то уради је претворити сирови показивач, дужину и капацитет назад у Кс00Кс са функцијом Кс01Кс, омогућавајући деструктору да изведе чишћење.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ствара нови Кс00Кс од дужине, капацитета и показивача.
    ///
    /// # Safety
    ///
    /// Ово је крајње небезбедно због броја инваријаната који нису проверени:
    ///
    /// * Меморију на Кс00Кс мора претходно доделити исти алокатор који користи стандардна библиотека, са потребним поравнањем тачно 1.
    /// * `length` мора бити мањи или једнак Кс00Кс.
    /// * `capacity` треба да буде тачна вредност.
    /// * Први Кс01Кс бајтови на Кс02Кс морају бити валидни Кс00Кс.
    ///
    /// Њихово кршење може проузроковати проблеме попут оштећења интерних структура података додељивача.
    ///
    /// Власништво над Кс00Кс се ефективно преноси на Кс01Кс који тада може извршити ослобађање, прерасподјелу или промјену садржаја меморије на који указује показивач по жељи.
    /// Уверите се да ништа друго не користи показивач након позива ове функције.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // ФИКСМЕ Ажурирајте ово када је вец_инто_рав_партс стабилизован.
    ///     // Спречите аутоматско испуштање података низа
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Претвара З0вецтор0З бајтова у Кс01Кс без провере да ли низ садржи важећи Кс00Кс.
    ///
    /// Погледајте сигурну верзију Кс00Кс за више детаља.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ова функција није сигурна јер не проверава да ли су бајтови који су јој прослеђени ваљани Кс00Кс.
    /// Ако се ово ограничење прекрши, то може довести до проблема са сигурношћу меморије код корисника З0футуре0З корисника Кс01Кс, јер остатак стандардне библиотеке претпоставља да су `Стринг`ови важећи Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки бајтови, у З0вецтор0З
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Претвара Кс00Кс у бајт З0вецтор0З.
    ///
    /// Ово троши Кс00Кс, тако да не морамо да копирамо његов садржај.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Издваја кришку низа која садржи цео Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Конвертује Кс00Кс у променљиви одсечак низа.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Додаје дати одрезак низа на крај овог Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Враћа капацитет овог "низа", у бајтовима.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Осигурава да капацитет овог `стринга 'буде најмање Кс00Кс бајта већи од његове дужине.
    ///
    /// Капацитет се може повећати за више од Кс00Кс бајтова ако се одлучи, како би се спречиле честе прерасподеле.
    ///
    ///
    /// Ако не желите ово понашање Кс00Кс, погледајте методу Кс01Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ово можда заправо неће повећати капацитет:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // с сада има дужину 2 и капацитет 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // С обзиром да већ имамо додатних 8 капацитета, позивањем овог ...
    /// s.reserve(8);
    ///
    /// // ... заправо се не повећава.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Осигурава да капацитет овог `стринга 'буде Кс00Кс бајта већи од његове дужине.
    ///
    /// Размислите о употреби методе Кс00Кс, осим ако апсолутно не знате боље од алокатора.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ово можда заправо неће повећати капацитет:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // с сада има дужину 2 и капацитет 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // С обзиром да већ имамо додатних 8 капацитета, позивањем овог ...
    /// s.reserve_exact(8);
    ///
    /// // ... заправо се не повећава.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Покушава да резервише капацитет за најмање Кс01Кс више елемената који се убацују у дати Кс00Кс.
    /// Збирка може резервисати више простора како би се избегле честе прерасподеле.
    /// Након позивања Кс01Кс, капацитет ће бити већи или једнак Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// # Errors
    ///
    /// Ако се капацитет преплави или ако расподелитељ пријави квар, враћа се грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Унапред резервишите меморију, излазите ако не можемо
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Сада знамо да ово не може ООМ усред нашег сложеног посла
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Покушава да резервише минимални капацитет за тачно Кс01Кс додатних елемената који се убацују у дати Кс00Кс.
    ///
    /// Након позивања Кс01Кс, капацитет ће бити већи или једнак Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// Имајте на уму да додељивач може колекцији дати више простора него што захтева.
    /// Стога се на капацитет не може рачунати да буде тачно минималан.
    /// Дајте предност Кс00Кс ако се очекују уметања З0футуре0З.
    ///
    /// # Errors
    ///
    /// Ако се капацитет преплави или ако расподелитељ пријави квар, враћа се грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Унапред резервишите меморију, излазите ако не можемо
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Сада знамо да ово не може ООМ усред нашег сложеног посла
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Смањује капацитет овог Кс00Кс да би одговарао његовој дужини.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Смањује капацитет овог Кс00Кс са доњом границом.
    ///
    /// Капацитет ће остати најмање толико велик колико и дужина и испоручена вредност.
    ///
    ///
    /// Ако је тренутни капацитет мањи од доње границе, ово се не примењује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Додаје дати Кс01Кс на крај овог Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Приказује бајтни део садржаја овог `низа`.
    ///
    /// Инверзна метода је Кс00Кс.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Скраћује овај Кс00Кс на назначену дужину.
    ///
    /// Ако је Кс00Кс већа од тренутне дужине низа, то нема ефекта.
    ///
    ///
    /// Имајте на уму да овај метод нема утицаја на додељени капацитет низа
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако Кс00Кс не лежи на граници Кс01Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Уклања задњи знак из бафера низа и враћа га.
    ///
    /// Враћа Кс00Кс ако је овај Кс01Кс празан.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Уклања Кс00Кс са овог Кс01Кс у бајт положају и враћа га.
    ///
    /// Ово је операција *О*(*н*), јер захтева копирање сваког елемента у баферу.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс већа или једнака дужини `низа` или ако не лежи на граници Кс01Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Уклоните све подударности узорка Кс01Кс у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Подударања ће се детектовати и уклонити итеративно, па ће се у случајевима када се обрасци преклапају уклонити само први образац:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // БЕЗБЕДНОСТ: почетак и крај биће на Кс00Кс бајт границама по
        // докумената претраживача
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Задржава само знакове наведене у предикату.
    ///
    /// Другим речима, уклоните све знакове Кс01Кс тако да Кс02Кс врати Кс00Кс.
    /// Ова метода делује на месту, посећујући сваки лик тачно једном у оригиналном редоследу и задржава редослед задржаних знакова.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Тачан редослед може бити користан за праћење спољног стања, попут индекса.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Усмерите идк на следећи знак
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Убацује знак у овај Кс00Кс на положају бајта.
    ///
    /// Ово је операција *О*(*н*) јер захтева копирање сваког елемента у баферу.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс већи од дужине `низа` или ако не лежи на граници Кс01Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Убацује пресек низа у овај Кс00Кс на положају бајта.
    ///
    /// Ово је операција *О*(*н*) јер захтева копирање сваког елемента у баферу.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс већи од дужине `низа` или ако не лежи на граници Кс01Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Враћа променљиву референцу на садржај овог Кс00Кс.
    ///
    /// # Safety
    ///
    /// Ова функција није сигурна јер не проверава да ли су бајтови који су јој прослеђени ваљани Кс00Кс.
    /// Ако се ово ограничење прекрши, то може довести до проблема са сигурношћу меморије код корисника З0футуре0З корисника Кс01Кс, јер остатак стандардне библиотеке претпоставља да су `Стринг`ови важећи Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Враћа дужину овог Кс00Кс, у бајтовима, а не [`цхар`] или графеме.
    /// Другим речима, човек можда није оно што сматра дужином жице.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Приказује Кс00Кс ако је овај Кс01Кс дужине нула, а Кс02Кс у супротном.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Дијели низ на два при датом бајт индексу.
    ///
    /// Враћа ново додељени Кс00Кс.
    /// `self` садржи бајтове Кс01Кс, а враћени Кс02Кс садржи бајтове Кс00Кс.
    /// `at` мора бити на граници Кс00Кс кодне тачке.
    ///
    /// Имајте на уму да се капацитет Кс00Кс не мења.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако се Кс00Кс не налази на граници Кс01Кс кодне тачке или ако је изван последње кодне тачке низа.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Смањује овај Кс00Кс, уклањајући сав садржај.
    ///
    /// Иако ово значи да ће Кс00Кс имати дужину нула, то не додирује његов капацитет.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Ствара одводни итератор који уклања наведени опсег у Кс01Кс и даје уклоњени Кс00Кс.
    ///
    ///
    /// Note: Опсег елемената се уклања чак и ако се итератор не потроши до краја.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако почетна или крајња тачка не леже на Кс00Кс граници или ако су ван граница.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Уклоните опсег све док β из низа
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Читав опсег брише струне
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Сигурност меморије
        //
        // Стринг верзија З0Драин0З нема проблема са меморијом у верзији З0вецтор0З.
        // Подаци су обични бајтови.
        // Будући да се уклањање домета дешава у Дроп-у, ако итератор З0Драин0З процури, уклањање се неће догодити.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Извадите две истовремене позајмице.
        // Стрингу Кс00Кс неће се приступити док се итерација не заврши, у Дроп-у.
        let self_ptr = self as *mut _;
        // БЕЗБЕДНОСТ: Кс00Кс и Кс01Кс врше одговарајуће провере граница.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Уклања наведени опсег из низа и замењује га датим низом.
    /// Дати низ не мора бити исте дужине као опсег.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако почетна или крајња тачка не леже на Кс00Кс граници или ако су ван граница.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Замените опсег све док β из низа
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Сигурност меморије
        //
        // Реплаце_ранге нема проблема са сигурношћу меморије З0вецтор0З спојнице.
        // верзије З0вецтор0З.Подаци су обични бајтови.

        // УПОЗОРЕЊЕ: Уметање ове променљиве било би неразумно Кс00Кс
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // УПОЗОРЕЊЕ: Уметање ове променљиве било би неразумно Кс00Кс
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Поновна употреба Кс00Кс била би неразумна Кс01Кс Претпостављамо да границе о којима извештава Кс02Кс остају исте, али супарничка примена би се могла мењати између позива
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Претвара овај Кс00Кс у [`Бок`]`<`[`стр`] `>`.
    ///
    /// Ово ће смањити сваки вишак капацитета.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Приказује део бајтова [`у8`] који је покушан да се претвори у Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки неважећи бајтови, у З0вецтор0З
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Враћа бајтове који су покушали да претворе у Кс00Кс.
    ///
    /// Ова метода је пажљиво конструисана како би се избегла алокација.
    /// Искористиће грешку померајући бајтове, тако да не треба правити копију бајтова.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки неважећи бајтови, у З0вецтор0З
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Преузмите Кс00Кс да бисте добили више детаља о неуспеху конверзије.
    ///
    /// Тип Кс01Кс који пружа Кс02Кс представља грешку која се може догодити приликом претварања дела [`у8`] с у Кс00Кс.
    /// У том смислу, то је аналог Кс00Кс.
    /// Погледајте документацију за више детаља о њеном коришћењу.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // неки неважећи бајтови, у З0вецтор0З
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // први бајт је овде неважећи
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Будући да вршимо итерацију преко `Стринг-а`, можемо избећи барем једну алокацију тако што ћемо из итератора добити први низ и додати му све наредне низове.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Будући да вршимо итерацију у вези са ЦоВс, можемо да избегнемо најмање једну расподелу Кс00Кс тако што ћемо добити прву ставку и додати јој све наредне ставке.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Погодни импл који делегира импл за Кс00Кс.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Ствара празан Кс00Кс.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Примењује оператер Кс00Кс за спајање два низа.
///
/// Ово троши Кс00Кс на левој страни и поново користи његов бафер (по потреби га повећава).
/// То је учињено како би се избегло додељивање новог Кс00Кс и копирање целокупног садржаја на свакој операцији, што би довело до времена извођења *О*(*н*^ 2) приликом изградње низа од *н* бајта поновљеним повезивањем.
///
///
/// Струна на десној страни је само позајмљена;његов садржај се копира у враћени Кс00Кс.
///
/// # Examples
///
/// Спајање два `стринга` узима први по вредности, а други позајмљује:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` је премештено и овде више не може да се користи.
/// ```
///
/// Ако желите да наставите да користите први Кс00Кс, можете га клонирати и уместо њега додати:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` још увек важи овде.
/// ```
///
/// Конкатенирање Кс01Кс кришки може се обавити претварањем првог у Кс00Кс:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Примењује оператер Кс01Кс за додавање на Кс00Кс.
///
/// Ово се понаша исто као Кс00Кс метода.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Типични псеудоним за Кс00Кс.
///
/// Овај псеудоним постоји за повратну компатибилност и можда ће се застарети.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// З0 Портраит0З за претварање вредности у Кс00Кс.
///
/// Овај З0 Портраит0З се аутоматски примењује за било који тип који примењује Кс00Кс З0 Портраит0З.
/// Као такав, Кс00Кс не би требало имплементирати директно:
/// [`Display`] требало би да се примени уместо тога, а имплементацију Кс00Кс добијате бесплатно.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Претвара дату вредност у Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// У овој имплементацији, Кс00Кс метода З0паницс0З ако имплементација Кс01Кс врати грешку.
/// Ово указује на нетачну имплементацију Кс00Кс, јер Кс01Кс никада не враћа саму грешку.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Уобичајена смерница је да се не уграђују генеричке функције.
    // Међутим, уклањање Кс00Кс из ове методе узрокује занемарљиве регресије.
    // Погледајте Кс00Кс, последњи покушај уклањања.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// Резултат се распоређује на гомилу.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: тест увлачи либстд, што овде изазива грешке
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Претвара дати уоквирени Кс01Кс рез у Кс00Кс.
    /// Значајно је да је Кс00Кс пресек у власништву.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Претвара дати Кс00Кс у упаковани Кс01Кс рез који је у власништву.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Конвертује одсечак низа у позајмљену варијанту.
    /// Не врши се додељивање хрпе и низ се не копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Претвара низ у власничку варијанту.
    /// Не врши се додељивање хрпе и низ се не копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Претвара референцу на стринг у позајмљену варијанту.
    /// Не врши се додељивање хрпе и низ се не копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Претвара дати Кс01Кс у З0вецтор0З Кс02Кс који садржи вредности типа Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Одводни итератор за Кс00Кс.
///
/// Ова структура је креирана методом Кс01Кс на Кс00Кс.
/// Погледајте документацију за више информација.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Користиће се као&'а мут глас у деструктору
    string: *mut String,
    /// Почетак дела за уклањање
    start: usize,
    /// Крај дела за уклањање
    end: usize,
    /// Тренутни преостали опсег за уклањање
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Користите Кс00Кс.
            // "Reaffirm" границе проверавају како би се избегло поновно уметање З0паниц0З кода.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Приказује преостали (под) низ овог итератора као пресек.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: некоментирајте АсРеф доле при стабилизацији.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Оставите коментар код стабилизације Кс00Кс.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// импл <'а> АсРеф<str>за З0Драин0З <'а> {фн Кс00Кс-> Кс01Кс {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// импл <'а> АсРеф <[у8]> за З0Драин0З <' а> {фн Кс00Кс->&[у8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}