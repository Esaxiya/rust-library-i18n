//! Поглед динамичке величине у непрекидни низ, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Пресеци су поглед на блок меморије представљен као показивач и дужина.
//!
//! ```
//! // сече Вец
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // присиљавање низа на пресек
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Кришке је могуће променити или делити.
//! Тип дељеног пресека је Кс00Кс, док је променљиви тип пресека Кс01Кс, где Кс02Кс представља тип елемента.
//! На пример, можете мутирати блок меморије на који показује променљиви пресек:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ево неких ствари које овај модул садржи:
//!
//! ## Structs
//!
//! Постоји неколико структура корисних за кришке, као што је Кс00Кс, која представља итерацију преко пресека.
//!
//! ## З0Траит0З Имплементације
//!
//! Постоји неколико примена уобичајених З0траитс0З за кришке.Неки примери укључују:
//!
//! * [`Clone`]
//! * [`Eq`], Кс00Кс, за кришке чији је тип елемента Кс02Кс или Кс01Кс.
//! * [`Hash`] - за кришке чији је тип елемента Кс00Кс.
//!
//! ## Iteration
//!
//! Резине имплементирају Кс00Кс.Итератор даје референце на елементе реза.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Променљиви пресек даје променљиве референце на елементе:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Овај итератор даје променљиве референце на елементе пресека, па док је тип елемента пресека Кс01Кс, тип елемента итератора је Кс00Кс.
//!
//!
//! * [`.iter`] и Кс00Кс су експлицитне методе за враћање задатих итератора.
//! * Даљи методи који враћају итераторе су Кс00Кс, Кс01Кс, Кс02Кс, Кс03Кс и други.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Многе употребе овог модула користе се само у тест конфигурацији.
// Чистије је само искључити упозорење унусед_импортс него их поправити.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Основне методе продужења пресека
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) потребан за примену Кс00Кс макронаредбе током тестирања НБ, погледајте Кс01Кс модул у овој датотеци за више детаља.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) потребан за примену Кс00Кс током тестирања НБ, погледајте Кс01Кс модул у овој датотеци за више детаља.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Будући да Кс00Кс Кс01Кс није доступан, ове три функције су заправо методе које се налазе у Кс02Кс, али не и у Кс03Кс, те функције морамо да доставимо за Кс04Кс тест
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Овоме не бисмо требали додавати уграђени атрибут јер се ово углавном користи у Кс00Кс макроу и узрокује регресију перф.
    // Погледајте Кс00Кс за дискусију и резултате.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ставке су означене иницијализованим у петљи испод
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) је неопходно да ЛЛВМ уклони провере ограничења и има бољи кодеген од зип-а.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // вец је додељен и иницијализован горе бар на ову дужину.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // додељени горе са капацитетом Кс00Кс и иницијализујте се на Кс01Кс у Кс02Кс доле.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Сортира кришку.
    ///
    /// Ова сорта је стабилна (тј. Не преуређује једнаке елементе) и *О*(*н*\* Кс00Кс најгори случај.
    ///
    /// Када је применљиво, пожељно је нестабилно сортирање, јер је то углавном брже од стабилног сортирања и не додељује помоћну меморију.
    /// Погледајте Кс00Кс.
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам је адаптивна, итеративна врста спајања инспирисана Кс00Кс.
    /// Дизајниран је тако да буде врло брз у случајевима када је пресек скоро сортиран или се састоји од две или више сортираних секвенци повезане једна за другом.
    ///
    ///
    /// Такође, додељује привремено складиште упола мање од Кс00Кс, али за кратке одсеке уместо тога се користи сортирање уноса које не додељује.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Сортира рез уз функцију упоређивања.
    ///
    /// Ова сорта је стабилна (тј. Не преуређује једнаке елементе) и *О*(*н*\* Кс00Кс најгори случај.
    ///
    /// Функција упоређивања мора дефинисати укупан редослед елемената у пресеку.Ако редослед није укупан, редослед елемената је неодређен.
    /// Поруџбина је укупна поруџбина ако јесте (за све Кс00Кс, Кс01Кс и Кс02Кс):
    ///
    /// * укупно и антисиметрично: тачно један од Кс00Кс, Кс01Кс или Кс02Кс је тачан, и
    /// * транзитивни, Кс02Кс и Кс03Кс подразумева Кс01Кс.Исто мора да важи и за Кс04Кс и за Кс00Кс.
    ///
    /// На пример, иако Кс02Кс не примењује Кс03Кс јер је Кс01Кс, можемо користити Кс04Кс као функцију сортирања када знамо да пресек не садржи Кс00Кс.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Када је применљиво, пожељно је нестабилно сортирање, јер је то углавном брже од стабилног сортирања и не додељује помоћну меморију.
    /// Погледајте Кс00Кс.
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам је адаптивна, итеративна врста спајања инспирисана Кс00Кс.
    /// Дизајниран је тако да буде врло брз у случајевима када је пресек скоро сортиран или се састоји од две или више сортираних секвенци повезане једна за другом.
    ///
    /// Такође, додељује привремено складиште упола мање од Кс00Кс, али за кратке одсеке уместо тога се користи сортирање уноса које не додељује.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обрнуто сортирање
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Сортира сортирање помоћу функције извлачења кључа.
    ///
    /// Ова сорта је стабилна (тј. Не мења редослед једнаких елемената) и *О*(*м*\* * н *\* Кс00Кс најгори случај, где је кључна функција *О*(*м*).
    ///
    /// За скупе функције тастера (нпр
    /// функције које нису једноставни приступи својствима или основне операције), Кс00Кс ће вероватно бити знатно бржи, јер не прерачунава кључеве елемената.
    ///
    ///
    /// Када је применљиво, пожељно је нестабилно сортирање, јер је то углавном брже од стабилног сортирања и не додељује помоћну меморију.
    /// Погледајте Кс00Кс.
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам је адаптивна, итеративна врста спајања инспирисана Кс00Кс.
    /// Дизајниран је тако да буде врло брз у случајевима када је пресек скоро сортиран или се састоји од две или више сортираних секвенци повезане једна за другом.
    ///
    /// Такође, додељује привремено складиште упола мање од Кс00Кс, али за кратке одсеке уместо тога се користи сортирање уноса које не додељује.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Сортира сортирање помоћу функције извлачења кључа.
    ///
    /// Током сортирања, функција кључа се позива само једном по елементу.
    ///
    /// Ова сорта је стабилна (тј. Не преуређује једнаке елементе) и *О*(*м*\* * н *+* н *\* Кс00Кс најгори случај, где је кључна функција *О*(*м*) .
    ///
    /// За једноставне функције кључа (нпр. Функције које су својства или основни поступци), Кс00Кс ће вероватно бити бржи.
    ///
    /// # Тренутна примена
    ///
    /// Тренутни алгоритам заснован је на Кс00Кс од Орсона Петерса, који комбинује брзи просечни случај рандомизираног брзог сортирања са брзим најгорим случајем прекомерне сорте, док истовремено постиже линеарно време на резовима са одређеним обрасцима.
    /// Користи рандомизацију да би избегао изрођене случајеве, али са фиксним З0сеед0З да увек пружи детерминистичко понашање.
    ///
    /// У најгорем случају, алгоритам додељује привремено складиште у Кс00Кс дужине пресека.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Макро помагач за индексирање нашег З0вецтор0З према најмањем могућем типу, како би се смањила алокација.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Елементи Кс00Кс су јединствени, јер се индексирају, тако да ће било која врста бити стабилна у односу на оригинални пресек.
                // Овде користимо Кс00Кс, јер захтева мање издвајања меморије.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Копира Кс01Кс у нови Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Овде се Кс00Кс и Кс01Кс могу самостално модификовати.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Копира Кс00Кс у нови Кс01Кс са расподељивачем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Овде се Кс00Кс и Кс01Кс могу самостално модификовати.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Напомена, погледајте Кс00Кс модул у овој датотеци за више детаља.
        hack::to_vec(self, alloc)
    }

    /// Претвара Кс00Кс у З0вецтор0З без клонова или алокације.
    ///
    /// Добијени З0вецтор0З може се претворити назад у кутију путем `Вец<T>је Кс00Кс метода.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` не може се више користити јер је претворен у Кс00Кс.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Напомена, погледајте Кс00Кс модул у овој датотеци за више детаља.
        hack::into_vec(self)
    }

    /// Ствара З0вецтор0З понављањем пресека Кс00Кс пута.
    ///
    /// # Panics
    ///
    /// Ова функција ће З0паниц0З ако би се капацитет прелио.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// З0паниц0З при преливању:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ако је Кс01Кс већи од нуле, може се поделити као Кс00Кс.
        // `2^expn` је број представљен крајњим левим Кс02Кс битом Кс01Кс, а Кс03Кс је преостали део Кс00Кс.
        //
        //

        // Коришћење Кс01Кс за приступ Кс00Кс.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` понављање се врши удвостручавањем Кс00Кс `екпн` пута.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ако је Кс01Кс, преостали су битови до крајњег левог Кс00Кс.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` има капацитет од Кс00Кс.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=н, 2 ^ екпн`) понављање се врши копирањем првих Кс00Кс понављања из самог Кс01Кс.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ово се не преклапа од Кс00Кс.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` једнако Кс01Кс (`=Кс00Кс.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Сравни комад Кс01Кс у једну вредност Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Сравни комад Кс01Кс у једну вредност Кс00Кс, постављајући задати сепаратор између сваке.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Сравни комад Кс01Кс у једну вредност Кс00Кс, постављајући задати сепаратор између сваке.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Враћа З0вецтор0З који садржи копију овог пресека где се сваки бајт пресликава на свој АСЦИИ еквивалент великим словима.
    ///
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// За употребу великих слова на месту користите Кс00Кс.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Приказује З0вецтор0З који садржи копију овог пресека где се сваки бајт пресликава на свој АСЦИИ еквивалент малим словима.
    ///
    ///
    /// АСЦИИ слова Кс01Кс до Кс02Кс мапирају се у Кс03Кс до Кс00Кс, али слова која нису АСЦИИ остају непромењена.
    ///
    /// Да бисте умањили вредност на месту, користите Кс00Кс.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Додатак З0траитс0З за кришке одређених врста података
////////////////////////////////////////////////////////////////////////////////

/// Помоћник З0 Портраит0З за [`[Т]: : цонцат`](слице::цонцат).
///
/// Note: параметар типа Кс00Кс се не користи у овом З0 Портраит0З, али омогућава да импулси буду општији.
/// Без тога добијамо ову грешку:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// То је зато што би могли постојати типови Кс00Кс са вишеструким импликацијама Кс01Кс, тако да би се примењивало више типова Кс02Кс:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Добијени тип након спајања
    type Output;

    /// Имплементација [`[Т]: : цонцат`](слице::цонцат)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Помоћник З0 Портраит0З за [`[Т]: : јоин`](слице::јоин)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Добијени тип након спајања
    type Output;

    /// Имплементација [`[Т]: : јоин`](слице::јоин)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Стандардне имплементације З0 Портраит0З за кришке
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // баци било шта у циљ што неће бити преписано
        target.truncate(self.len());

        // target.len <=Кс00Кс због горњег пресека, тако да су овде резови увек у границама.
        //
        let (init, tail) = self.split_at(target.len());

        // поново користите садржане вредности 'Кс00Кс.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Убацује Кс00Кс у унапред сортирану секвенцу Кс01Кс тако да цео Кс02Кс постане сортиран.
///
/// Ово је интегрална потпрограм сортирања уметања.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Постоје три начина за примену уметања овде:
            //
            // 1. Замените суседне елементе док први не стигне на крајње одредиште.
            //    Међутим, на овај начин копирамо податке око више него што је потребно.
            //    Ако су елементи велике структуре (скупе за копирање), овај метод ће бити спор.
            //
            // 2. Понављајте док се не пронађе право место за први елемент.
            // Затим преместите елементе који следе да бисте направили места за то и коначно га поставите у преосталу рупу.
            // Ово је добра метода.
            //
            // 3. Копирајте први елемент у привремену променљиву.Понављајте док се не нађе право место за то.
            // Како идемо даље, копирајте сваки пређени елемент у утор који му претходи.
            // На крају, копирајте податке из привремене променљиве у преосталу рупу.
            // Ова метода је врло добра.
            // Референтне вредности показале су нешто боље перформансе него код друге методе.
            //
            // Све методе су биле референтне, а трећа је показала најбоље резултате.Па смо изабрали ону.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Средње стање процеса уметања увек прати Кс00Кс, који служи у две сврхе:
            // 1. Штити интегритет Кс01Кс од З0паницс0З у Кс00Кс.
            // 2. На крају попуњава преосталу рупу у Кс00Кс.
            //
            // З0Паниц0З сигурност:
            //
            // Ако се Кс02Кс З0паницс0З у било ком тренутку током процеса, Кс01Кс испусти и попуни рупу у Кс03Кс са Кс00Кс, осигуравајући тако да Кс04Кс и даље тачно држи сваки објекат који је у почетку држао.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` падне и тако копира Кс01Кс у преосталу рупу у Кс00Кс.
        }
    }

    // Када се испадне, копије из Кс01Кс у Кс00Кс.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Спаја не-опадајуће покрете Кс01Кс и Кс02Кс користећи Кс03Кс као привремено складиште и чува резултат у Кс00Кс.
///
/// # Safety
///
/// Две кришке не смеју бити празне, а Кс00Кс мора бити у границама.
/// Међуспремник Кс00Кс мора бити довољно дугачак да садржи копију краћег реза.
/// Такође, Кс00Кс не сме бити тип нулте величине.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Процес спајања прво копира краће покретање у Кс00Кс.
    // Затим се прати новокопирано покретање и дуже покретање унапред (или уназад), упоређујући њихове следеће непотрошене елементе и копирајући мањи (или већи) у Кс00Кс.
    //
    // Чим се краће коришћење потпуно потроши, процес је завршен.Ако се прво потроши дужи низ, онда морамо копирати оно што је остало од краћег трчања у преосталу рупу у Кс00Кс.
    //
    // Средње стање процеса увек прати Кс00Кс, који служи у две сврхе:
    // 1. Штити интегритет Кс01Кс од З0паницс0З у Кс00Кс.
    // 2. Попуњава преосталу рупу у Кс00Кс ако се прво потроши дужи рад.
    //
    // З0Паниц0З сигурност:
    //
    // Ако се Кс02Кс З0паницс0З у било ком тренутку током процеса, Кс01Кс испусти и попуни рупу у Кс03Кс непотрошеним дометом у Кс00Кс, осигуравајући тако да Кс04Кс и даље тачно држи сваки објекат који је у почетку држао.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Леви залет је краћи.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // У почетку, ови показивачи указују на почетке њихових низова.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Конзумирајте мању страну.
            // Ако је једнако, преферирајте леву вожњу да бисте одржали стабилност.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Права вожња је краћа.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // У почетку, ови показивачи показују крај њихових поља.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Конзумирајте већу страну.
            // Ако је једнако, преферирајте прави трк да бисте одржали стабилност.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Коначно, Кс00Кс пада.
    // Ако краћа серија није у потпуности потрошена, све што остане од ње сада ће се копирати у рупу у Кс00Кс.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Када падне, копира опсег Кс01Кс у Кс00Кс.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` није тип нулте величине, па је у реду поделити са његовом величином.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ова врста спајања позајмљује неке (али не све) идеје из ТимСорта, који је детаљно описан у Кс00Кс.
///
///
/// Алгоритам идентификује строго силазне и не-силазне подсеквенце, које се називају природни покрети.Постоји низ чека на чекању који тек треба да се споје.
/// Свако ново пронађено покретање се гура у стек, а затим се спајају пари суседних извођења док се ове две инваријанте не задовоље:
///
/// 1. за сваки Кс01Кс у Кс00Кс: `runs[i - 1].len > runs[i].len`
/// 2. за сваки Кс01Кс у Кс00Кс: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инваријанте осигуравају да је укупно време рада *О*(*н*\* Кс00Кс најгори случај.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Резови до ове дужине сортирају се помоћу сортирања уметањем.
    const MAX_INSERTION: usize = 20;
    // Веома кратка трчања се продужавају помоћу сортирања уметања да би обухватила барем оволико елемената.
    const MIN_RUN: usize = 10;

    // Сортирање нема смислено понашање код типова нулте величине.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Кратки низови се сортирају на месту помоћу сортирања уметањем да би се избегле алокације.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Доделите бафер за употребу као огреботина.Задржавамо дужину 0 како бисмо у њој могли да сачувамо плитке копије садржаја Кс00Кс, а да не ризикујемо да се мотори покрећу на копијама ако је Кс01Кс З0паницс0З.
    //
    // При спајању два сортирана извођења, овај ме успремник садржи копију краћег извођења, које ће увијек имати дужину од највише Кс00Кс.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Да бисмо идентификовали природне стазе у Кс00Кс, прелазимо је уназад.
    // То би могло изгледати чудно, али узмите у обзир чињеницу да се спајања чешће одвијају у супротном смеру Кс00Кс.
    // Према референтним вредностима, спајање напред је нешто брже од спајања уназад.
    // Да закључимо, идентификовање трчања заокретањем уназад побољшава перформансе.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Пронађите следећу природну вожњу и обрните је ако се строго спушта.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Уметните још неке елементе у низ ако је прекратак.
        // Сортирање уметањем је брже од сортирања спајањем на кратким секвенцама, па ово значајно побољшава перформансе.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Гурните ово трчање на стек.
        runs.push(Run { start, len: end - start });
        end = start;

        // Спојите неколико парова суседних трчања да бисте задовољили инваријанте.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Коначно, тачно једна трка мора остати у гомили.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Испитује стог извођења и идентификује следећи пар извођења за спајање.
    // Тачније, ако се врати Кс00Кс, то значи да се следећи морају спојити Кс01Кс и Кс02Кс.
    // Ако алгоритам уместо тога настави да гради нову пробу, враћа се Кс00Кс.
    //
    // ТимСорт је познат по својим имплементацијама грешака, као што је овде описано:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Суштина приче је: морамо применити инваријанте у прва четири трчања на стеку.
    // Њихова примјена на само прва три није довољна да би се осигурало да ће се инваријанте и даље држати за *све* трке у стеку.
    //
    // Ова функција исправно проверава инваријанте за прва четири извођења.
    // Поред тога, ако покретање на врху започне индексом 0, увек ће бити потребна операција спајања док се стек у потпуности не сруши, како би се завршило сортирање.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}