// Подесите дужину века када вредност Кс00Кс излази из опсега.
//
// Идеја је: Поље дужине у СетЛенОнДроп је локална променљива коју ће оптимизатор видети, али не замјењује ниједно складиште преко Вецовог показивача података.
// Ово је заобилазно решење за проблем замене Кс00Кс
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}