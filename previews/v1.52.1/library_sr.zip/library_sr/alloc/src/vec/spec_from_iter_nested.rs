use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Друга специјализација З0 Портраит0З за Кс00Кс неопходна за ручно одређивање приоритета који се преклапају погледајте Кс01Кс за детаље.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Одмотајте прву итерацију, јер ће З0вецтор0З бити проширен на овој итерацији у сваком случају када итерабле није празан, али петља у Кс00Кс неће видети да је З0вецтор0З пун у неколико наредних итерација петље.
        //
        // Тако добијамо боље предвиђање З0бранцх0З.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // мора делегирати на Кс00Кс јер сам Кс01Кс делегира на спец_фром за празне Вецс
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // мора делегирати на Кс00Кс јер сам Кс01Кс делегира на спец_фром за празне Вецс
        //
        vector.spec_extend(iterator);
        vector
    }
}