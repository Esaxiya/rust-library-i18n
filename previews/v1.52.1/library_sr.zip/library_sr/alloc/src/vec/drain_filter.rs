use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Итератор који користи затварање да би утврдио да ли елемент треба уклонити.
///
/// Ову структуру креира Кс00Кс.
/// Погледајте документацију за више информација.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Индекс ставке која ће се прегледати до следећег позива на Кс00Кс.
    pub(super) idx: usize,
    /// Број предмета који су до сада исушени Кс00Кс.
    pub(super) del: usize,
    /// Оригинална дужина Кс00Кс пре испуштања.
    pub(super) old_len: usize,
    /// Предикат теста филтера.
    pub(super) pred: F,
    /// Ознака која означава З0паниц0З се појавила у предикату теста филтра.
    /// Ово се користи као наговештај у испуштању како би се спречила потрошња остатка Кс00Кс.
    /// Све непрерађене ставке ће бити враћене у Кс00Кс, али предикат филтра неће испустити или тестирати даље ставке.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Враћа референцу на основни алокатор.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ажурирајте индекс * након што се позове предикат.
                // Ако се индекс претходно ажурира и предикат З0паницс0З, елемент у овом индексу би процурио.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ово је прилично забрљано стање и заправо не постоји очигледно исправна ствар.
                        // Не желимо да наставимо да покушавамо да извршимо Кс00Кс, зато само пребацимо све необрађене елементе уназад и кажемо вецу да они и даље постоје.
                        //
                        // Преокрет уназад је потребан да би се спречило двоструко испуштање последњег успешно испражњеног предмета пре З0паниц0З у предикату.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Покушајте да потрошите преостале елементе ако се предикат филтра још увек није успаничио.
        // Пребацићемо све преостале елементе уназад без обзира да ли смо се већ успаничили или је овде потрошња З0паницс0З.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}