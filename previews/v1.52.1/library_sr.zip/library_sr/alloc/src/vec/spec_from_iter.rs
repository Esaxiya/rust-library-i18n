use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Специјализација З0 Портраит0З коришћена за Кс00Кс
///
/// ## Графикон делегирања:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Уобичајени случај је прослеђивање З0вецтор0З у функцију која се одмах поново сакупља у З0вецтор0З.
        // Можемо ово кратко спојити ако ИнтоИтер уопште није напредан.
        // Када је напредан, такође можемо поново користити меморију и премештати податке напред.
        // Али то чинимо само када резултујући Вец не би имао више неискоришћеног капацитета него што би га створио генеричком имплементацијом ФромИтератор.
        //
        // То ограничење није стриктно неопходно јер Вец-ово понашање при додељивању није намерно одређено.
        // Али то је конзервативан избор.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // мора делегирати на Кс00Кс јер сам Кс01Кс делегира на спец_фром за празне Вецс
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ово користи Кс00Кс, јер спец_ектенд мора предузети више корака како би закључио коначни капацитет + дужину и тако обавио више посла.
// `to_vec()` директно додељује тачан износ и тачно га попуњава.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): код Кс00Кс својствена метода Кс01Кс, која је потребна за дефиницију ове методе, није доступна.
    // Уместо тога, користите функцију Кс00Кс која је доступна само са Кс01Кс НБ, погледајте Кс02Кс модул у Кс03Кс за више информација
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}