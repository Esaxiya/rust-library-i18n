use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Ознака специјализације за прикупљање итераторског цевовода у Вец уз поновну употребу алокације извора, тј
/// извођење цевовода на месту.
///
/// Надређени СоурцеИтер З0 Портраит0З неопходан је специјализованој функцији за приступ додељивању које треба поново користити.
/// Али није довољно да би специјализација била валидна.
/// Погледајте додатне границе на импл.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// З0стд0З-интерни Кс00Кс З0траитс0З имплементирају само ланци адаптера <Adapter<Adapter<IntoIter>>> (све у власништву Кс01Кс).
// Додатне границе на имплементацијама адаптера (изван Кс00Кс) зависе само од других З0траитс0З који су већ означени као специјализација З0траитс0З (Цопи, ТрустедРандомАццесс, ФуседИтератор).
//
// I.e. маркер не зависи од животног века врста које испоручују корисници.Модуло рупа за копирање, о којој већ зависи неколико других специјализација.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Додатни захтеви који се не могу изразити путем З0 Портраит0З З0боундс0З.Уместо тога, ослањамо се на цонст евал:
        // а) без ЗСТ-ова, јер не би било додељивања за поновну употребу, а аритметика показивача би се З0паниц0З б) подударала по величини како захтева уговор о Аллоц-у; ц) поравнања се поклапају како захтева уговор о Аллоц-у
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // повратак на више генеричке примене
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // користи три-фолд од
        // - векторизује се боље за неке адапторе итератора
        // - за разлику од већине интерних метода итерације, потребан је само Кс00Кс
        // - омогућава нам да провучемо показивач за писање кроз његову унутрашњост и вратимо га на крају
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // итерација је успела, не спуштајте главу
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // проверите да ли је подржан СоурцеИтер уговор: уколико нису, можда нећемо стићи ни до ове тачке
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // проверите уговор ИнПлацеИтерабле.То је могуће само ако је итератор уопште унапредио показивач извора.
        // Ако користи непроверени приступ путем ТрустедРандомАццесс, тада ће изворни показивач остати у почетном положају и не можемо га користити као референцу
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // испустите све преостале вредности у реп извора, али спречите пад саме алокације када ИнтоИтер изађе из опсега ако пад З0паницс0З тада пропуштамо и све елементе прикупљене у дст_буф
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // уговор ИнПлацеИтерабле не може се овде тачно верификовати, јер три_фолд има ексклузивну референцу на изворни показивач, све што можемо да урадимо је да проверимо да ли је и даље у домету
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}