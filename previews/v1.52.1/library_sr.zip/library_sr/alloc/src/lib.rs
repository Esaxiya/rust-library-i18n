//! # Библиотека алокација и збирки језгара З0Руст0З
//!
//! Ова библиотека нуди паметне показиваче и колекције за управљање вредностима додељеним гомили.
//!
//! Ову библиотеку, попут либцоре-а, обично није потребно директно користити, јер се њен садржај поново извози у Кс00Кс.
//! З0Цратес0З који користе атрибут Кс01Кс, међутим обично неће зависити од Кс00Кс, па би уместо тога користили овај З0црате0З.
//!
//! ## Уоквирене вредности
//!
//! Тип Кс01Кс је тип паметног показивача.Власник Кс00Кс може бити само један, а власник може одлучити да мутира садржај који живи на гомили.
//!
//! Овај тип се може ефикасно слати међу нити јер је величина Кс00Кс вредности једнака величини показивача.
//! Структуре података налик дрвету често се граде помоћу оквира, јер сваки чвор често има само једног власника, родитеља.
//!
//! ## Референтни бројачи показивача
//!
//! Тип Кс00Кс је тип показивача који није сигуран за бројање референци и намењен је дељењу меморије унутар нити.
//! Показивач Кс02Кс обавија тип Кс00Кс и дозвољава приступ само Кс01Кс, заједничкој референци.
//!
//! Овај тип је користан када је наслеђена променљивост (као што је коришћење Кс02Кс) превише ограничавајући за апликацију и често је упарена са типовима Кс00Кс или Кс01Кс како би се омогућила мутација.
//!
//!
//! ## Атомско референцирани бројачи показивача
//!
//! Тип Кс01Кс је еквивалент сигурног конца типу Кс02Кс.Пружа исту функцију Кс00Кс, осим што захтева да се садржани тип Кс03Кс може делити.
//! Поред тога, Кс00Кс је сам по себи доступан, док Кс01Кс није.
//!
//! Овај тип омогућава заједнички приступ садржаним подацима и често је упарен са примитивима за синхронизацију, као што су мутекси, да би се омогућила мутација дељених ресурса.
//!
//! ## Collections
//!
//! Имплементације најчешћих структура података опште намене дефинисане су у овој библиотеци.Они се поново извозе кроз Кс00Кс.
//!
//! ## Хеап интерфејси
//!
//! Модул Кс00Кс дефинише интерфејс ниског нивоа према подразумеваном глобалном алокатору.Није компатибилан са АПИ-јем за додељивање либц.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Технички, ово је грешка у рустдоц-у: рустдоц види да је документација о Кс02Кс блоковима намењена Кс00Кс-у, који такође има документацију која користи ову функцију у Кс01Кс-у, и побесни што улаз функција није омогућен.
// У идеалном случају, не би проверавао приступ функцијама за документе из других З0цратес0З, али с обзиром да се ово може појавити само за језичке ставке, чини се да није вредно поправљања.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Дозволи тестирање ове библиотеке

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Модул са унутрашњим макроима које користе други модули (потребно је укључити их пре осталих модула).
#[macro_use]
mod macros;

// Гомиле предвиђене за стратегије додељивања на ниском нивоу

pub mod alloc;

// Примитивни типови који користе гомиле горе

// Потребно је условно дефинисати мод из Кс00Кс како би се избегло дуплицирање ланг-ставки приликом уградње у тест цфг;али такође треба да дозволи да код има Кс01Кс декларације.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}