//! Показивачи за бројање референци са једним навојем.Кс00Кс је скраћеница од " Референца`
//! Counted'.
//!
//! Тип Кс01Кс пружа заједничко власништво над вредношћу типа Кс00Кс, додељеном у гомили.
//! Позивање Кс00Кс на Кс01Кс ствара нови показивач на исту алокацију у гомили.
//! Када се уништи последњи Кс00Кс показивач на дату алокацију, вредност ускладиштена у тој алокацији (која се често назива Кс01Кс) такође се испушта.
//!
//! Заједничке референце у З0Руст0З подразумевано онемогућавају мутацију, а Кс01Кс није изузетак: генерално не можете добити променљиву референцу на нешто унутар Кс00Кс.
//! Ако вам је потребна променљивост, ставите Кс02Кс или Кс03Кс унутар Кс01Кс;види Кс00Кс.
//!
//! [`Rc`] користи неатомско бројање референци.
//! То значи да су режијски трошкови врло ниски, али Кс01Кс не може да се пошаље између нити, па сходно томе Кс02Кс не примењује Кс00Кс.
//! Као резултат, компајлер З0Руст0З ће у време компајлирања *проверити* да не шаљете [`Рц`] с између нити.
//! Ако вам је потребно бројање атомских референци са више нити, користите Кс00Кс.
//!
//! Метода Кс00Кс се може користити за креирање непоседујућег показивача Кс01Кс.
//! Показивач Кс01Кс може се [`надоградити`][надоградити] д на Кс00Кс, али то ће вратити Кс02Кс ако је вредност сачувана у алокацији већ испуштена.
//! Другим речима, Кс00Кс показивачи не одржавају вредност унутар алокације живом;међутим, они *држе* алокацију (складиште за унутрашњу вредност) на животу.
//!
//! Циклус између показивача Кс00Кс никада неће бити уклоњен.
//! Из тог разлога, Кс00Кс се користи за разбијање циклуса.
//! На пример, дрво може имати јаке Кс00Кс показиваче од родитељских чворова до деце, а Кс01Кс показиваче од деце назад до родитеља.
//!
//! `Rc<T>` аутоматски преусмерава на Кс01Кс (путем Кс02Кс З0 Портраит0З), тако да можете да позовете методе `Т` на вредности типа Кс00Кс.
//! Да би се избегла сукобљавања имена са методама `Т`, методе самог Кс01Кс су придружене функције, позване помоћу Кс00Кс:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Рц<T>Имплементације З0траитс0З попут Кс00Кс такође се могу позвати користећи потпуно квалификовану синтаксу.
//! Неки људи више воле да користе потпуно квалификовану синтаксу, док други више воле синтаксу метода-позива.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Синтакса позива-метода
//! let rc2 = rc.clone();
//! // Потпуно квалификована синтакса
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] не аутоматски преусмерава на Кс00Кс, јер је унутрашња вредност можда већ испуштена.
//!
//! # Клонирање референци
//!
//! Стварање нове референце на исту алокацију као и постојећи показивач бројаних референци врши се помоћу Кс01Кс З0 Портраит0З имплементираног за Кс02Кс и Кс00Кс.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Две синтаксе доле су еквивалентне.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // а и б указују на исто место у меморији као фоо.
//! ```
//!
//! Синтакса Кс00Кс је најизразитија јер експлицитније преноси значење кода.
//! У горњем примеру, ова синтакса олакшава уочавање да овај код ствара нову референцу уместо да копира целокупан садржај фоо-а.
//!
//! # Examples
//!
//! Размотрите сценарио у коме је сет `гаџета` у власништву датог Кс00Кс.
//! Желимо да наша `направа` укаже на њихов Кс01Кс.То не можемо учинити са јединственим власништвом, јер више гаџета може припадати истом Кс00Кс.
//! [`Rc`] омогућава нам да делимо Кс00Кс између више `Гадгета` и да Кс01Кс остане додељен све док било који Кс02Кс показује на њега.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... друга поља
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... друга поља
//! }
//!
//! fn main() {
//!     // Направите Кс00Кс бројену референцом.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Направите `гаџет` који припада Кс00Кс.
//!     // Клонирање Кс00Кс даје нам нови показивач на исто додељивање Кс01Кс, повећавајући број референци у процесу.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Одложите нашу локалну променљиву Кс00Кс.
//!     drop(gadget_owner);
//!
//!     // Упркос одустајању од Кс00Кс, још увек можемо да одштампамо име Кс01Кс `Гадгета`.
//!     // То је зато што смо испустили само један Кс00Кс, а не Кс01Кс на који указује.
//!     // Све док постоје други Кс00Кс који указују на исту Кс01Кс алокацију, он ће остати активан.
//!     // Пројекција поља Кс01Кс функционише јер се Кс02Кс аутоматски преусмерава на Кс00Кс.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // На крају функције, Кс01Кс и Кс02Кс су уништени, а са њима и последње пребројане референце на наш Кс00Кс.
//!     // Гадгет Ман такође постаје уништен.
//!     //
//! }
//! ```
//!
//! Ако се наши захтеви промене, а такође морамо да будемо у могућности да пређемо са Кс01Кс на Кс00Кс, наићи ћемо на проблеме.
//! Показивач Кс00Кс од Кс01Кс до Кс02Кс уводи циклус.
//! То значи да њихов број референци никада не може досећи 0, а алокација никада неће бити уништена:
//! цурење меморије.Да бисмо ово заобишли, можемо користити показиваче Кс00Кс.
//!
//! З0Руст0З заправо донекле отежава стварање ове петље.Да би се завршиле са две вредности које упућују једна на другу, једна од њих мора бити променљива.
//! Ово је тешко јер Кс00Кс намеће сигурност меморије давањем само заједничких референци на вредност коју умотава, а оне не дозвољавају директну мутацију.
//! Морамо да умотамо део вредности који желимо да мутирамо у Кс00Кс, који пружа *унутрашњу променљивост*: метод за постизање променљивости кроз заједничку референцу.
//! [`RefCell`] спроводи правила позајмљивања З0Руст0З током извршавања.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... друга поља
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... друга поља
//! }
//!
//! fn main() {
//!     // Направите Кс00Кс бројену референцом.
//!     // Имајте на уму да смо ставили `Овнер` З0вецтор0З`Гадгета` у Кс00Кс како бисмо могли да га мутирамо кроз заједничку референцу.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Створите `Гадгет`-ове који припадају Кс00Кс, као и раније.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Додајте `Гадгет` уређаје њиховом Кс00Кс.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` овде се завршава динамичко позајмљивање.
//!     }
//!
//!     // Понављајте наше `справице`, исписујући њихове детаље.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` је Кс00Кс.
//!         // С обзиром да показивачи Кс02Кс не могу гарантовати да додељивање још увек постоји, морамо позвати Кс01Кс, који враћа Кс00Кс.
//!         //
//!         //
//!         // У овом случају знамо да додељивање још увек постоји, тако да једноставно Кс01Кс Кс00Кс.
//!         // У компликованијем програму, можда ће вам требати грациозно руковање грешкама за резултат Кс00Кс.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // На крају функције, Кс00Кс, Кс01Кс и Кс02Кс се уништавају.
//!     // Сада нема јаких Кс00Кс показивача на уређаје, па су уништени.
//!     // Ово поништава број референци на Гадгет Ман-у, тако да и он постаје уништен.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ово је доказ од Кс00Кс до З0футуре0З против могућег преуређивања поља, што би ометало иначе сигуран Кс01Кс трансмутабилних унутрашњих типова.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Показивач за бројање референци са једним навојем.Кс00Кс је скраћеница од " Референца`
/// Counted'.
///
/// Погледајте Кс00Кс за више детаља.
///
/// Све својствене методе Кс02Кс су све повезане функције, што значи да их морате звати као нпр. Кс01Кс уместо Кс00Кс.
/// Ово избегава сукобе са методама унутрашњег типа Кс00Кс.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ова несигурност је у реду јер док је овај Рц жив гарантирамо да је унутрашњи показивач важећи.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Конструише нови Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Постоји имплицитни слаби показивач у власништву свих јаких показивача, који осигурава да слаби деструктор никада не ослобађа алокацију док је јаки деструктор покренут, чак и ако је слаби показивач ускладиштен унутар јаког показивача.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Конструише нови Кс00Кс користећи слабу референцу на себе.
    /// Покушај надоградње слабе референце пре него што се ова функција врати резултираће Кс00Кс вредношћу.
    ///
    /// Међутим, слаба референца може се слободно клонирати и сачувати за касније коришћење.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... још поља
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Конструисати унутрашњост у Кс00Кс стању са једном слабом референцом.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно је да се не одричемо власништва над слабим показивачем, иначе би меморија могла бити ослобођена док се Кс00Кс не врати.
        // Ако бисмо заиста желели да пренесемо власништво, могли бисмо да створимо додатни слаби показивач за себе, али то би резултирало додатним ажурирањима броја слабих референци које иначе не би биле потребне.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Јаке референце би заједно требало да поседују дељену слабу референцу, зато немојте покретати деструктор за нашу стару слабу референцу.
        //
        mem::forget(weak);
        strong
    }

    /// Израђује нови Кс00Кс са неиницијализованим садржајем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, са меморијом која је напуњена бајтовима Кс01Кс.
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструише нови Кс00Кс, враћа грешку ако додељивање не успе
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Постоји имплицитни слаби показивач у власништву свих јаких показивача, који осигурава да слаби деструктор никада не ослобађа алокацију док је јаки деструктор покренут, чак и ако је слаби показивач ускладиштен унутар јаког показивача.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, враћа грешку ако додељивање не успе
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструише нови Кс00Кс са неиницијализованим садржајем, с меморијом која је напуњена бајтовима Кс01Кс, враћа грешку ако додељивање не успе
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Конструише нови Кс00Кс.
    /// Ако Кс01Кс не примени Кс00Кс, тада ће Кс02Кс бити закачен у меморију и не може се преместити.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Враћа унутрашњу вредност ако Кс00Кс има тачно једну снажну референцу.
    ///
    /// У супротном, враћа се Кс00Кс са истим Кс01Кс који је прослеђен.
    ///
    ///
    /// Ово ће успети чак и ако постоје изванредне слабе референце.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // копирајте садржани објекат

                // Укажите Веакс-у да их не може напредовати смањењем јаког броја, а затим уклоните имплицитни Кс00Кс показивач, истовремено рукујући логиком испуштања, само израдом лажног Слабца.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Конструише нови пресек пребројан референцама са неиницијализованим садржајем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Конструише нови пресек пребројан референцама са неиницијализованим садржајем, са меморијом која је напуњена бајтовима Кс00Кс.
    ///
    ///
    /// Погледајте Кс00Кс за примере тачне и нетачне употребе ове методе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Претвара у Кс00Кс.
    ///
    /// # Safety
    ///
    /// Као и код Кс00Кс, на позиваоцу је да гарантује да је унутрашња вредност заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива тренутно недефинисано понашање.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Претвара у Кс00Кс.
    ///
    /// # Safety
    ///
    /// Као и код Кс00Кс, на позиваоцу је да гарантује да је унутрашња вредност заиста у иницијализованом стању.
    ///
    /// Ово позивање када садржај још увек није у потпуности иницијализован изазива тренутно недефинисано понашање.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Одложена иницијализација:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Конзумира Кс00Кс враћајући умотани показивач.
    ///
    /// Да би се избегло цурење меморије, показивач се мора конвертовати назад у Кс01Кс помоћу Кс00Кс.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Пружа необрађени показивач на податке.
    ///
    /// На бројање то не утиче ни на који начин и Кс00Кс се не троши.
    /// Показивач важи све док у Кс00Кс има јаких бројева.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЕЗБЕДНОСТ: Ово не може проћи кроз Кс00Кс или Кс01Кс јер
        // ово је потребно да би се задржало порекло Кс00Кс такво да нпр
        // `get_mut` може писати кроз показивач након што се Рц обнови кроз Кс00Кс.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Конструише Кс00Кс из необрађеног показивача.
    ///
    /// Необрађени показивач мора бити претходно враћен позивом на Кс01Кс где Кс02Кс мора имати исту величину и поравнање као Кс00Кс.
    /// Ово је тривијално тачно ако је Кс01Кс Кс00Кс.
    /// Имајте на уму да ако Кс00Кс није Кс01Кс, али има исту величину и поравнање, ово је у основи попут претварања референци различитих врста.
    /// Погледајте Кс00Кс за више информација о томе која ограничења важе у овом случају.
    ///
    /// Корисник Кс00Кс мора осигурати да одређена вредност Кс01Кс падне само једном.
    ///
    /// Ова функција није сигурна јер неправилна употреба може довести до несигурности меморије, чак и ако се враћеном Кс00Кс никада не приступи.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Вратите се на Кс00Кс да бисте спречили цурење.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Даљи позиви на Кс00Кс не би били сигурни у меморији.
    /// }
    ///
    /// // Меморија је ослобођена када је Кс00Кс изашао из опсега горе, тако да Кс01Кс сада виси!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Обрните офсет да бисте пронашли оригинални РцБок.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ствара нови Кс00Кс показивач на ову алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Уверите се да не стварамо висећи Слаби
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Добија број Кс00Кс показивача на ову алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Добија број снажних Кс00Кс показивача на ову алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Враћа Кс00Кс ако нема других показивача Кс01Кс или Кс02Кс на ову алокацију.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Враћа променљиву референцу у дати Кс00Кс, ако нема других показивача Кс01Кс или Кс02Кс на исту алокацију.
    ///
    ///
    /// У супротном враћа Кс00Кс, јер није сигурно мутирати заједничку вредност.
    ///
    /// Такође погледајте Кс00Кс, који ће Кс01Кс добити унутрашњу вредност када постоје други показивачи.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Враћа променљиву референцу у дати Кс00Кс, без икакве провере.
    ///
    /// Такође погледајте Кс00Кс, који је сигуран и врши одговарајуће провере.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ниједан други показивач Кс00Кс или Кс01Кс на исту алокацију не сме бити дереференциран током трајања враћене позајмице.
    ///
    /// То је тривијалан случај ако такви показивачи не постоје, на пример одмах након Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Пазимо да *не* креирамо референцу која покрива поља Кс00Кс, јер би то било у сукобу са приступима бројању референци (нпр.
        // до Кс00Кс).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Враћа Кс00Кс ако два `Рц`-а упућују на исту алокацију (у вену сличну Кс01Кс).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Прави променљиву референцу на дати Кс00Кс.
    ///
    /// Ако постоје други Кс00Кс показивачи на исту алокацију, тада ће Кс01Кс Кс02Кс унети унутрашњу вредност у нову алокацију како би се осигурало јединствено власништво.
    /// Ово се такође назива клонирањем на писање.
    ///
    /// Ако не постоје други Кс00Кс показивачи на ову алокацију, тада ће Кс01Кс показивачи на ову алокацију бити раздвојени.
    ///
    /// Такође погледајте Кс00Кс, који неће успети него клонирати.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Нећу клонирати ништа
    /// let mut other_data = Rc::clone(&data);    // Неће клонирати унутрашње податке
    /// *Rc::make_mut(&mut data) += 1;        // Клонира унутрашње податке
    /// *Rc::make_mut(&mut data) += 1;        // Нећу клонирати ништа
    /// *Rc::make_mut(&mut other_data) *= 2;  // Нећу клонирати ништа
    ///
    /// // Сада Кс00Кс и Кс01Кс указују на различите алокације.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] показивачи ће бити раздвојени:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Морам да клонирам податке, постоје и други Рцс.
            // Унапред доделите меморију како бисте омогућили директно писање клониране вредности.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Можете само украсти податке, преостао је само Веакс
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Уклоните имплицитни јаки и слаби реф (овде не треба правити лажни Слаби-знамо да нас други Слаби могу очистити)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ова несигурност је у реду јер смо загарантовани да је враћени показивач *једини* показивач који ће икада бити враћен Т.
        // У овом тренутку зајамчено је да је наш референтни број 1, а тражили смо да сам Кс01Кс буде Кс00Кс, па враћамо једину могућу референцу на доделу.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Покушај да се Кс00Кс спусти на бетон.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Додељује Кс00Кс са довољним простором за потенцијално неодређену унутрашњу вредност тамо где вредност има предвиђени распоред.
    ///
    /// Функција Кс01Кс се позива помоћу показивача података и мора вратити (потенцијално масно) показивач за Кс00Кс.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Израчунајте изглед користећи задати распоред вредности.
        // Раније је изглед израчунат на изразу Кс00Кс, али ово је створило погрешно поравнату референцу (види Кс01Кс).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Додељује Кс00Кс са довољним простором за потенцијално неодређену унутрашњу вредност где вредност има предвиђени изглед, враћа грешку ако додељивање не успе.
    ///
    ///
    /// Функција Кс01Кс се позива помоћу показивача података и мора вратити (потенцијално масно) показивач за Кс00Кс.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Израчунајте изглед користећи задати распоред вредности.
        // Раније је изглед израчунат на изразу Кс00Кс, али ово је створило погрешно поравнату референцу (види Кс01Кс).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Доделите за изглед.
        let ptr = allocate(layout)?;

        // Иницијализујте РцБок
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Додељује Кс00Кс са довољно простора за неодређену унутрашњу вредност
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Доделите за Кс00Кс користећи задату вредност.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копирај вредност у бајтовима
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Ослободите алокацију без испуштања њеног садржаја
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Додељује Кс00Кс задате дужине.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Копирајте елементе из пресека у ново додељени Рц <\[Т\]>
    ///
    /// Небезбедно јер позивалац мора или да преузме власништво или да веже Кс00Кс
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Конструише Кс00Кс из итератора за који се зна да је одређене величине.
    ///
    /// Понашање није дефинисано ако је величина погрешна.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // З0Паниц0З штитник при клонирању Т елемената.
        // У случају З0паниц0З, елементи који су записани у нови РцБок ће бити испуштени, а затим ће се меморија ослободити.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Показивач на први елемент
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Прекид узбуне.Заборавите чувара да не ослободи нови РцБок.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специјализација З0 Портраит0З коришћена за Кс00Кс.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Испушта Кс00Кс.
    ///
    /// Ово ће смањити јак број референци.
    /// Ако јаки број референци достигне нулу, тада су једине остале референце (ако их има) Кс00Кс, па Кс01Кс добијамо унутрашњу вредност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Не штампа ништа
    /// drop(foo2);   // Штампа Кс00Кс
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // уништити садржани предмет
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // уклоните имплицитни Кс00Кс показивач сада када смо уништили садржај.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Прави клон показивача Кс00Кс.
    ///
    /// Ово ствара још један показивач на исту алокацију, повећавајући јак број референци.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Ствара нови Кс01Кс, са вредношћу Кс02Кс за Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Хацк за омогућавање специјализације за Кс00Кс иако Кс01Кс има метод.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ми овде радимо ову специјализацију, а не као општију оптимизацију на Кс00Кс, јер би у супротном додала трошак свим провјерама једнакости на реф.
/// Претпостављамо да се `Рц` користе за складиштење великих вредности, које се споро клонирају, али су и тешке за проверу једнакости, због чега се овај трошак лакше исплати.
///
/// Такође је вероватније да имате два Кс00Кс клона, који указују на исту вредност, него два `&Т`.
///
/// То можемо учинити само када Кс00Кс као Кс01Кс може бити намерно нефлексиван.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Једнакост за два `Рц`-а.
    ///
    /// Два `Рц`-а су једнака ако су њихове унутрашње вредности једнаке, чак и ако су ускладиштене у различитом распореду.
    ///
    /// Ако Кс00Кс такође имплементира Кс01Кс (што подразумева рефлексивност једнакости), два `Рц` која указују на исту алокацију су увек једнака.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Неједнакост за два `Рц`-а.
    ///
    /// Два `Рц` су неједнака ако су њихове унутрашње вредности неједнаке.
    ///
    /// Ако Кс00Кс такође имплементира Кс01Кс (што подразумева рефлексивност једнакости), два `Рц` која указују на исту алокацију никада нису неједнака.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Делимично поређење за два `Рц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Мање од поређења за два `Рц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Поређење " Мање или једнако`за два " Рц`.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Веће упоређивање за два `Рц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Поређење " веће или једнако`за два " Рц`-а.
    ///
    /// Њих две се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Поређење за два `Рц`-а.
    ///
    /// Њих двоје се упоређују позивањем Кс00Кс на основу њихових унутрашњих вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Додијелите референтно пребројану кришку и попуните је клонирањем ставки `в`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Доделите референтно пребројани одсечак низа и у њега копирајте Кс00Кс.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Доделите референтно пребројани одсечак низа и у њега копирајте Кс00Кс.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Преместите уоквирени објекат у нову, додељену, бројену референцу.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Доделите референтно пребројану кришку и преместите ставке `в` у њу.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Дозволите Вецу да ослободи меморију, али не и да уништи његов садржај
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Узима сваки елемент у Кс01Кс и сакупља га у Кс00Кс.
    ///
    /// # Техничке карактеристике
    ///
    /// ## Општи случај
    ///
    /// У општем случају, прикупљање у Кс01Кс врши се прво сакупљањем у Кс00Кс.Односно, када пишете следеће:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ово се понаша као да смо написали:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Овде се дешава први скуп расподела.
    ///     .into(); // Овде се дешава друго издвајање за Кс00Кс.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ово ће доделити онолико пута колико је потребно за конструкцију Кс01Кс, а затим ће доделити једном за претварање Кс02Кс у Кс00Кс.
    ///
    ///
    /// ## Итератори познате дужине
    ///
    /// Када ваш Кс01Кс примени Кс02Кс и буде тачне величине, извршиће се једно додељивање за Кс00Кс.На пример:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Овде се дешава само једно додељивање.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Специјализација З0 Портраит0З која се користи за прикупљање у Кс00Кс.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ово је случај за Кс00Кс итератор.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗБЕДНОСТ: Морамо осигурати да итератор има тачну дужину као и ми.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Вратите се нормалној примени.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` је верзија Кс00Кс која садржи непоседујућу референцу на управљану алокацију.Додељивању се приступа позивом Кс01Кс на показивачу Кс02Кс, који враћа [`Оптион`]`<`[`Рц`] `<T>>`.
///
/// Будући да се референца Кс00Кс не рачуна у власништво, неће спречити испуштање вредности сачуване у алокацији, а сам Кс01Кс не даје гаранције да је вредност и даље присутна.
/// Стога може вратити Кс00Кс када [`надоградња`] д.
/// Међутим, имајте на уму да референца Кс00Кс *спречава* уклањање саме алокације (складишта подлога).
///
/// Показивач Кс00Кс користан је за задржавање привремене референце на алокацију којом управља Кс01Кс без спречавања испуштања његове унутрашње вредности.
/// Такође се користи за спречавање кружних референци између показивача Кс00Кс, јер међусобне референце поседовања никада не би дозволиле да било који Кс01Кс падне.
/// На пример, дрво може имати јаке Кс00Кс показиваче од родитељских чворова до деце, а Кс01Кс показиваче од деце назад до родитеља.
///
/// Типичан начин добијања показивача Кс01Кс је позивање Кс00Кс.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ово је Кс00Кс за омогућавање оптимизације величине овог типа у енумима, али није нужно важећи показивач.
    //
    // `Weak::new` поставља ово на Кс00Кс тако да не треба да додељује простор на гомили.
    // То није вредност коју ће стварни показивач икада имати јер РцБок има поравнање најмање 2.
    // То је могуће само када Кс00Кс;неодређени Кс01Кс никада се не мота.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Конструише нови Кс00Кс, без издвајања меморије.
    /// Позивање Кс01Кс на повратну вредност увек даје Кс00Кс.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Тип помоћника који омогућава приступ бројању референци без давања било каквих тврдњи о пољу података.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Враћа сирови показивач на објекат Кс01Кс на који је указан овај Кс00Кс.
    ///
    /// Показивач је важећи само ако постоје неке јаке референце.
    /// Показивач може да се виси, не поравна или чак Кс00Кс у супротном.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Обоје указују на исти предмет
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Снажни га овде одржава на животу, тако да и даље можемо приступити објекту.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Али не више.
    /// // Можемо Кс00Кс, али приступ показивачу би довео до недефинисаног понашања.
    /// // ассерт_ек! ("здраво", несигурно {Кс00Кс;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ако показивач виси, вратимо стражара директно.
            // Ово не може бити важећа адреса корисног терета, јер је носивост поравната најмање као РцБок Кс00Кс.
            ptr as *const T
        } else {
            // БЕЗБЕДНОСТ: ако ис_данглинг врати фалсе, тада се показивач не може преусмјерити.
            // Корисни терет у овом тренутку може пасти, а ми морамо да одржавамо провенијенцију, па користите манипулацију сировим показивачем.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Конзумира Кс00Кс и претвара га у необрађени показивач.
    ///
    /// Ово претвара слаби показивач у необрађени показивач, истовремено задржавајући власништво над једном слабом референцом (ова операција не мења слаби број).
    /// Може се вратити у Кс01Кс са Кс00Кс.
    ///
    /// Примењују се иста ограничења приступа циљу показивача као и код Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Претвара сирови показивач који је претходно креирао Кс01Кс назад у Кс00Кс.
    ///
    /// Ово се може користити за сигурно добијање јаке референце (позивањем Кс01Кс касније) или за ослобађање броја слабих ако испустите Кс00Кс.
    ///
    /// Преузима власништво над једном слабом референцом (са изузетком показивача креираних од Кс00Кс, јер ови не поседују ништа; метода и даље ради на њима).
    ///
    /// # Safety
    ///
    /// Показивач мора да потиче из Кс00Кс и још увек мора да поседује потенцијално слабу референцу.
    ///
    /// Дозвољено је да јаки број буде 0 у тренутку када ово зовете.
    /// Ипак, ово преузима власништво над једном слабом референцом која је тренутно представљена као необрађени показивач (ова операција не мења слаби број) и зато мора бити упарена са претходним позивом на Кс00Кс.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Умањи последњу слабу тачку.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Погледајте Кс00Кс за контекст о томе како је изведен улазни показивач.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ово је висећи Слаб.
            ptr as *mut RcBox<T>
        } else {
            // У супротном, загарантовано нам је да показивач потиче од нервозна Слаба.
            // БЕЗБЕДНОСТ: дата_оффсет је сигурно позвати, јер птр упућује на стварни (потенцијално испуштени) Т.
            let offset = unsafe { data_offset(ptr) };
            // Дакле, обрћемо офсет да бисмо добили цео РцБок.
            // БЕЗБЕДНОСТ: показивач потиче од слабости, тако да је овај помак сигуран.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗБЕДНОСТ: сада смо обновили оригинални слаби показивач, тако да можемо створити слаб.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Покушаји надоградње показивача Кс01Кс на Кс00Кс, одлагање испуштања унутрашње вредности ако је успешно.
    ///
    ///
    /// Враћа Кс00Кс ако је унутрашња вредност у међувремену испуштена.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Уништите све снажне показиваче.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Добија број снажних Кс00Кс показивача који упућују на ову алокацију.
    ///
    /// Ако је Кс01Кс креиран помоћу Кс00Кс, вратиће се 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Добија број Кс00Кс показивача који упућују на ову алокацију.
    ///
    /// Ако не остану јаки показивачи, ово ће вратити нулу.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // одузми имплицитни слаби птр
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Враћа Кс01Кс када се показивач клати и нема додељеног Кс00Кс (тј. Када је овај Кс02Кс креирао Кс03Кс).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Пазимо да *не* направимо референцу која покрива поље Кс00Кс, јер поље може истовремено бити мутирано (на пример, ако се одустане од последњег Кс01Кс, поље података ће се уклонити на месту).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Приказује Кс01Кс ако два `Слаба` воде на исто додељивање (слично Кс02Кс) или ако оба не упућују на било које додељивање (јер су креирана са Кс00Кс.
    ///
    ///
    /// # Notes
    ///
    /// Будући да ово упоређује показиваче, то значи да ће се Кс00Кс изједначити, иако не указују на било какву алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Упоређујући Кс00Кс.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Испушта показивач Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Не штампа ништа
    /// drop(foo);        // Штампа Кс00Кс
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // број слабих започиње са 1, и ићи ће на нулу само ако су сви јаки показивачи нестали.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Прави клон показивача Кс00Кс који указује на исту алокацију.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструише нови Кс00Кс, додељујући меморију за Кс01Кс без иницијализације.
    /// Позивање Кс01Кс на повратну вредност увек даје Кс00Кс.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Овде смо проверили_додали да бисмо безбедно решили Кс00Кс.Нарочито
// ако имате Кс00Кс Рцс (или Слаби), бројање реф-а може се прелити и тада можете ослободити алокацију док постоје изванредни Рцс (или Слаби).
//
// Прекидамо јер је ово толико изрођен сценарио да нас није брига шта ће се догодити-ниједан прави програм то никада не би требало да доживи.
//
// Ово би требало да има занемариве трошкове, јер заправо не требате толико клонирати у З0Руст0З захваљујући власништву и семантици померања.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Желимо да прекинемо при преливању, уместо да испустимо вредност.
        // Бројање референци никада неће бити нула када се ово позове;
        // ипак, овде убацујемо прекид да бисмо наговестили ЛЛВМ о иначе пропуштеној оптимизацији.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Желимо да прекинемо при преливању, уместо да испустимо вредност.
        // Бројање референци никада неће бити нула када се ово позове;
        // ипак, овде убацујемо прекид да бисмо наговестили ЛЛВМ о иначе пропуштеној оптимизацији.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Добијте офсет унутар Кс00Кс за носивост иза показивача.
///
/// # Safety
///
/// Показивач мора указивати на (и имати ваљане метаподатке за) претходно важећу инстанцу Т, али Т може бити испуштено.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Поравнајте неодређену вредност на крај РцБок-а.
    // Будући да је РцБок Кс00Кс, то ће увек бити последње поље у меморији.
    // БЕЗБЕДНОСТ: будући да су једини могући неодређени типови кришки, З0 Портраит0З објекти,
    // и екстерни типови, захтеви за безбедност улаза су тренутно довољни да задовоље захтеве алигн_оф_вал_рав;ово је детаљ примене језика на који се ван З0стд0З не може поуздати.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}