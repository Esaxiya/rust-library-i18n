#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Садржај нове меморије је неиницијализован.
    Uninitialized,
    /// Нова меморија загарантована је на нули.
    Zeroed,
}

/// Услужни програм ниског нивоа за ергономскије распоређивање, прерасподјелу и уклањање међуспремника меморије на гомили, без потребе за бригом о свим угаоним случајевима.
///
/// Овај тип је одличан за изградњу властитих структура података попут Вец и ВецДекуе.
/// Нарочито:
///
/// * Производи Кс00Кс на типовима нулте величине.
/// * Производи Кс00Кс на алокацијама нулте дужине.
/// * Избегава ослобађање Кс00Кс.
/// * Хвата све преливе у прорачунима капацитета (промовише их у Кс00Кс З0паницс0З).
/// * Штити од 32-битних система који додељују више од Кс00Кс бајтова.
/// * Штити од прекомерне дужине.
/// * Позива Кс00Кс на погрешна издвајања.
/// * Садржи Кс00Кс и тако кориснику даје све сродне погодности.
/// * Користи вишак враћен из алокатора да користи највећи расположиви капацитет.
///
/// Овај тип ни у ком случају не прегледава меморију којом управља.Када га испустите,*ослободиће му меморију, али* неће * покушати да испусти садржај.
/// На кориснику Кс01Кс је да обрађује стварне ствари *похрањене* у Кс00Кс.
///
/// Имајте на уму да је вишак типова нулте величине увек бесконачан, па Кс01Кс увек враћа Кс00Кс.
/// То значи да морате бити опрезни када заобилазите овај тип са Кс00Кс, јер Кс01Кс неће дати дужину.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): То постоји зато што Кс00Кс `цонст фн`с не морају бити у складу са Кс01Кс, тако да се не могу позивати ни у`мин_цонст_фн`с.
    ///
    /// Ако промените Кс01Кс или зависности, припазите да не уведете ништа што би заиста кршило Кс00Кс.
    ///
    /// NOTE: Могли бисмо да избегнемо ово хаковање и проверимо усаглашеност са неким Кс01Кс атрибутом који захтева усаглашеност са Кс02Кс, али не мора нужно дозволити његово позивање у Кс03Кс/кориснички код који не омогућава Кс04Кс када је присутан Кс05Кс.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ствара највећи могући Кс00Кс (на системској гомили) без додељивања.
    /// Ако Кс01Кс има позитивну величину, онда ово чини Кс02Кс капацитета Кс00Кс.
    /// Ако је Кс01Кс нулте величине, онда прави Кс02Кс капацитета Кс00Кс.
    /// Корисно за примену одложене алокације.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Ствара Кс01Кс (на системској хрпи) са тачно потребним капацитетом и поравнањем за Кс00Кс.
    /// То је еквивалентно позивању Кс00Кс када је Кс01Кс Кс02Кс или Кс03Кс нулте величине.
    /// Имајте на уму да ако је Кс00Кс нулте величине, то значи да *нећете* добити Кс01Кс захтеваног капацитета.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако тражени капацитет премашује Кс00Кс бајтова.
    ///
    /// # Aborts
    ///
    /// Прекиди на ООМ.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Као и Кс00Кс, али гарантује да је бафер поништен.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Реконституише Кс00Кс из показивача и капацитета.
    ///
    /// # Safety
    ///
    /// Кс01Кс мора бити додељен (на системској хрпи) и са датим Кс00Кс.
    /// Кс00Кс не може премашити Кс01Кс за велике типове.(само забринутост за 32-битне системе).
    /// ЗСТ З0вецторс0З може имати капацитет до Кс00Кс.
    /// Ако Кс01Кс и Кс02Кс потичу од Кс00Кс, онда је ово загарантовано.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Мали Вецс су глупи.Прескочи на:
    // - 8 ако је величина елемента 1, јер ће било који алокатори гомиле вероватно заокружити захтев мањи од 8 бајтова на најмање 8 бајтова.
    //
    // - 4 ако су елементи умерене величине (<=1 КиБ).
    // - 1 иначе, како би се избегло губљење превише простора за врло кратке Вецс.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Попут Кс01Кс, али параметризован при избору алокатора за враћени Кс00Кс.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` значи Кс00Кс.типови нулте величине се занемарују.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Попут Кс01Кс, али параметризован при избору алокатора за враћени Кс00Кс.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Попут Кс01Кс, али параметризован при избору алокатора за враћени Кс00Кс.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Претвара Кс01Кс у Кс00Кс.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Претвара читав међуспремник у Кс01Кс са наведеним Кс00Кс.
    ///
    /// Имајте на уму да ће ово исправно реконструисати све промене Кс00Кс које су можда извршене.(За детаље погледајте опис типа.)
    ///
    /// # Safety
    ///
    /// * `len` мора бити већи или једнак најновије траженом капацитету и
    /// * `len` мора бити мањи или једнак Кс00Кс.
    ///
    /// Имајте на уму да би се тражени капацитет и Кс00Кс могли разликовати, јер би расподељивач могао да додијели и врати већи меморијски блок од захтеваног.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Проверити исправност једне половине сигурносних захтева (другу половину не можемо).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Овде избегавамо Кс00Кс, јер смањује количину генерисаног ЛЛВМ ИР-а.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Реконституише Кс00Кс из показивача, капацитета и алокатора.
    ///
    /// # Safety
    ///
    /// Кс01Кс мора бити додељен (преко датог додељивача Кс02Кс) и са датим Кс00Кс.
    /// Кс00Кс не може премашити Кс01Кс за велике типове.
    /// (само забринутост за 32-битне системе).
    /// ЗСТ З0вецторс0З може имати капацитет до Кс00Кс.
    /// Ако Кс01Кс и Кс02Кс потичу из Кс03Кс створеног преко Кс00Кс, онда је то загарантовано.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Добија сирови показивач на почетак алокације.
    /// Имајте на уму да је ово Кс00Кс ако је Кс01Кс или Кс02Кс нулте величине.
    /// У првом случају, морате бити опрезни.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Добија капацитет алокације.
    ///
    /// Ово ће увек бити Кс00Кс ако је Кс01Кс нулте величине.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Враћа заједничку референцу на алокатор који подржава овај Кс00Кс.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Додијељен нам је дио меморије, тако да можемо заобићи провјере времена извођења да бисмо добили наш тренутни изглед.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Осигурава да бафер садржи најмање довољно простора за држање Кс00Кс елемената.
    /// Ако већ нема довољно капацитета, прерасподелит ће довољно простора плус удобан опуштени простор да би се амортизовало *О*(1) понашање.
    ///
    /// Ограничиће ово понашање ако би се непотребно проузроковало З0паниц0З.
    ///
    /// Ако Кс01Кс премаши Кс00Кс, ово можда неће успети да додијели тражени простор.
    /// Ово у ствари није несигурно, али несигурни код * који напишете и који се ослања на понашање ове функције може се покварити.
    ///
    /// Ово је идеално за спровођење групног притиска као што је Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет премашује Кс00Кс бајтова.
    ///
    /// # Aborts
    ///
    /// Прекиди на ООМ.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // резерва би се прекинула или успаничила да је лећа премашила Кс00Кс, тако да је то сада сигурно учинити неозначеним.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Исто као и Кс00Кс, али враћа грешке уместо панике или прекида.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Осигурава да бафер садржи најмање довољно простора за држање Кс00Кс елемената.
    /// Ако већ није, прерасподелит ће најмању могућу количину потребне меморије.
    /// Генерално, ово ће бити тачно потребна количина меморије, али у принципу је расподељивач слободан да врати више него што смо тражили.
    ///
    ///
    /// Ако Кс01Кс премаши Кс00Кс, ово можда неће успети да додијели тражени простор.
    /// Ово у ствари није несигурно, али несигурни код * који напишете и који се ослања на понашање ове функције може се покварити.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет премашује Кс00Кс бајтова.
    ///
    /// # Aborts
    ///
    /// Прекиди на ООМ.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Исто као и Кс00Кс, али враћа грешке уместо панике или прекида.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Смањује издвајање до наведеног износа.
    /// Ако је дати износ 0, заправо се у потпуности ослобађа.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је дати износ *већи* од тренутног капацитета.
    ///
    /// # Aborts
    ///
    /// Прекиди на ООМ.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Враћа се ако бафер треба да расте како би испунио потребан додатни капацитет.
    /// Углавном се користи за омогућавање уврштавања резервних позива без уградње Кс00Кс.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ова метода се обично примени много пута.Дакле, желимо да то буде што мање, како бисмо побољшали време компајлирања.
    // Али такође желимо да што већи део његовог садржаја буде статички израчунљив, како би генерисани код радио брже.
    // Стога је овај метод пажљиво написан тако да је сав код који зависи од Кс01Кс унутар њега, док је што је могуће више кода који не зависи од Кс02Кс у функцијама које нису генеричке у односу на Кс00Кс.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // То осигуравају позивни контексти.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Пошто враћамо капацитет од Кс00Кс када је Кс01Кс
            // 0, долазак овде нужно значи да је Кс00Кс препун.
            return Err(CapacityOverflow);
        }

        // Нажалост, ништа не можемо учинити са овим чековима.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ово гарантује експоненцијални раст.
        // Удвостручавање се не може прелити јер је Кс01Кс и тип Кс02Кс Кс00Кс.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` није генерички у односу на Кс00Кс.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ограничења ове методе су приближно иста као и код Кс00Кс, али ова метода се обично ређа мање често, тако да је мање критична.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Пошто враћамо капацитет од Кс00Кс када је величина типа
            // 0, долазак овде нужно значи да је Кс00Кс препун.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` није генерички у односу на Кс00Кс.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ова функција је изван Кс00Кс да би се смањило време компајлирања.Погледајте коментар изнад Кс01Кс за детаље.
// (Параметар Кс00Кс није значајан, јер је број различитих типова Кс01Кс виђених у пракси много мањи од броја типова Кс02Кс.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Овде потражите грешку да бисте смањили величину Кс00Кс.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Додељивач проверава једнакост поравнања
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ослобађа меморију у власништву Кс00Кс *без* покушаја испуштања њеног садржаја.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Централна функција за руковање резервним грешкама.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Морамо да гарантујемо следеће:
// * Никада не додељујемо објекте величине бајта Кс00Кс.
// * Не преливамо Кс00Кс и заправо додељујемо премало.
//
// На 64-битној само треба да проверимо да ли има прекорачења, јер покушај додељивања Кс00Кс бајтова сигурно неће успети.
// На 32-битне и 16-битне треба да додамо додатну заштиту за ово у случају да радимо на платформи која може да користи свих 4 ГБ у корисничком простору, нпр. ПАЕ или Кс00Кс.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Једна централна функција одговорна за прекомерни капацитет извештавања.
// Ово ће осигурати да генерирање кода повезано са овим З0паницс0З буде минимално, јер постоји само једна локација која је З0паницс0З, а не гомила у целом модулу.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}