use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Писање теста интеграције између независних алокатора и Кс00Кс помало је зезнуто, јер Кс01Кс АПИ не излаже погрешним методама алокације, па не можемо да проверимо шта се дешава када се алокатор исцрпи (осим откривања З0паниц0З).
    //
    //
    // Уместо тога, ово само проверава да Кс00Кс методе пролазе барем кроз Аллоцатор АПИ када резервише складиште.
    //
    //
    //
    //
    //

    // Глупи алокатор који троши фиксну количину горива пре него што покушаји доделе почну да пропадају.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (узрокује реаллоц, тако да се користи 50 + 150=200 јединица горива)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Прво, Кс01Кс издваја попут Кс00Кс.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 је више него дупло од 7, тако да би Кс01Кс требао радити као Кс00Кс.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 је мање од половине 12, тако да Кс00Кс мора да расте експоненцијално.
        // У време писања овог теста фактор раста је 2, тако да је нови капацитет 24, међутим, фактор раста Кс00Кс је такође у реду.
        //
        // Отуда Кс00Кс у тврдњи.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}