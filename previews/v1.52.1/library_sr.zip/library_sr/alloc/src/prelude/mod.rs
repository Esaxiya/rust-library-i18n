//! Алок З0Прелуде0З
//!
//! Сврха овог модула је да ублажи увоз најчешће коришћених предмета Кс00Кс З0црате0З додавањем глоб увоза на врх модула:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;