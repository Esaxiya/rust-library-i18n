//! Двоструки ред имплементиран са пуфером прстена који се може одмицати.
//!
//! Овај ред садржи *О*(1) амортизоване уметке и уклоне са оба краја контејнера.
//! Такође има *О*(1) индексирање попут З0вецтор0З.
//! Садржани елементи не морају се копирати, а ред ће бити доступан ако је садржани тип могуће.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Највећа могућа снага два

/// Двоструки ред имплементиран са пуфером прстена који се може одмицати.
///
/// Кс00Кс употреба овог типа као реда је употреба Кс01Кс за додавање у ред, а Кс02Кс за уклањање из реда.
///
/// [`extend`] и Кс00Кс се на тај начин гурају позади, а понављање Кс01Кс иде напред назад.
///
/// Будући да је Кс00Кс прстенасти бафер, његови елементи нису нужно непрекидни у меморији.
/// Ако елементима желите да приступите као један пресек, на пример за ефикасно сортирање, можете да користите Кс00Кс.
/// Ротира Кс00Кс тако да се његови елементи не умотавају и враћа променљиви рез у сада већ суседну секвенцу елемената.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // реп и глава су показивачи у тампон.
    // Реп увек показује на први елемент који се могао прочитати, Хеад увек показује где подаци треба да буду записани.
    //
    // Ако је таил==хеад, бафер је празан.Дужина пуфера је дефинисана као растојање између њих.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Покреће деструктор за све ставке у пресеку када падне (нормално или током одмотавања).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // користите пад за Кс00Кс
            ptr::drop_in_place(front);
        }
        // РавВец се бави ослобађањем
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Ствара празан Кс00Кс.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Незнатно погодније
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Незнатно погодније
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // За нулте величине, увек смо максималног капацитета
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Претворите птр у рез
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Претворите птр у мутну кришку
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Премешта елемент из међуспремника
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Записује елемент у бафер, премештајући га.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Враћа Кс00Кс ако је бафер пуног капацитета.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Враћа индекс у основном међуспремнику за дати индекс логичког елемента.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Приказује индекс у основном међуспремнику за задати логички елемент индек + адденд.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Враћа индекс у основни међуспремник за дати индекс логичког елемента, субтрахенд.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Копира непрекидни блок меморије дугачке од З0срц0З до дст
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Копира непрекидни блок меморије дугачке од З0срц0З до дст
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Копира потенцијални блок меморије дугачки од З0срц0З до одредишта.
    /// (abs(dst - src) + лен) не сме бити већи од Кс00Кс (Између З0срц0З и одредишта мора постојати највише једно непрекидно преклапајуће подручје).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // З0срц0З се не умотава, дст се не умотава
                //
                //        С...
                // 1 Кс00Кс
                // 2 Кс00Кс Д.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // дст пре З0срц0З, З0срц0З се не умотава, дст се умота
                //
                //
                //    С...
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс .. Д.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // З0срц0З пре прашине, З0срц0З се не умотава, дст умотава
                //
                //
                //              С...
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс .. Д.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // дст пре З0срц0З, З0срц0З умотава, дст се не умотава
                //
                //
                //    .. С.
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс Д...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // З0срц0З пре прашине, З0срц0З обавија, дст се не премотава
                //
                //
                //    .. С.
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс Д...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // дст пре З0срц0З, З0срц0З фолије, дст фолије
                //
                //
                //    ... С.
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс
                // 4 Кс00Кс .. Д..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // З0срц0З пре прашине, З0срц0З облоге, омотачи од прашине
                //
                //
                //    .. С..
                // 1 Кс00Кс
                // 2 Кс00Кс
                // 3 Кс00Кс
                // 4 Кс00Кс... Д.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Фробс око главе и репа около како би се носило са чињеницом да смо се прерасподијелили.
    /// Небезбедно јер верује у олд_цапацити.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Померите најкраћи суседни део одбојника прстена ТХ
        //
        //   [o o o o o o o . ]
        //    ТХА Кс00Кс ХТ
        //   [o o . o o o o o ]
        //          ТХБ [...ооооооо......
        //          ] ХТ
        //   [o o o o o . o o ]
        //              ХТЦ Кс00Кс
        //
        //
        //
        //

        if self.tail <= self.head {
            // А Ноп
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Ствара празан Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Ствара празан Кс00Кс са простором за најмање Кс01Кс елемената.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1, јер међуспремник прстена увијек оставља један простор празан
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Пружа референцу на елемент у датом индексу.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Пружа променљиву референцу на елемент у датом индексу.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Замењује елементе у индексима Кс01Кс и Кс00Кс.
    ///
    /// `i` и Кс00Кс може бити једнак.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је било који индекс ван граница.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Приказује број елемената које Кс00Кс може да садржи без прерасподјеле.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Резервише минимални капацитет за тачно Кс01Кс додатних елемената који се убацују у дати Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// Имајте на уму да додељивач може колекцији дати више простора него што захтева.
    /// Стога се не може поуздати да је капацитет тачно минималан.
    /// Дајте предност Кс00Кс ако се очекују уметања З0футуре0З.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Резервише капацитет за најмање Кс01Кс више елемената који се убацују у дати Кс00Кс.
    /// Збирка може резервисати више простора како би се избегле честе прерасподеле.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Покушава да резервише минимални капацитет за тачно Кс01Кс додатних елемената који се убацују у дати Кс00Кс.
    ///
    /// Након позивања Кс01Кс, капацитет ће бити већи или једнак Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// Имајте на уму да додељивач може колекцији дати више простора него што захтева.
    /// Стога се на капацитет не може рачунати да буде тачно минималан.
    /// Дајте предност Кс00Кс ако се очекују уметања З0футуре0З.
    ///
    /// # Errors
    ///
    /// Ако капацитет пређе Кс00Кс или ако расподељивач пријави квар, враћа се грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Унапред резервишите меморију, излазите ако не можемо
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Сада знамо да ово не може Кс00Кс усред нашег сложеног посла
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // веома компликовано
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Покушава да резервише капацитет за најмање Кс01Кс више елемената који се убацују у дати Кс00Кс.
    /// Збирка може резервисати више простора како би се избегле честе прерасподеле.
    /// Након позивања Кс01Кс, капацитет ће бити већи или једнак Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// # Errors
    ///
    /// Ако капацитет пређе Кс00Кс или ако расподељивач пријави квар, враћа се грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Унапред резервишите меморију, излазите ако не можемо
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Сада знамо да ово не може ООМ усред нашег сложеног посла
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // веома компликовано
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Смањује капацитет Кс00Кс што је више могуће.
    ///
    /// Смањиће се што је могуће ближе дужини, али расподељивач ће можда ипак обавестити Кс00Кс да има места за још неколико елемената.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Смањује капацитет Кс00Кс са доњом границом.
    ///
    /// Капацитет ће остати најмање толико велик колико и дужина и испоручена вредност.
    ///
    ///
    /// Ако је тренутни капацитет мањи од доње границе, ово се не примењује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Не морамо да бринемо због преливања, јер ни Кс01Кс ни Кс02Кс никада не могу бити Кс00Кс.
        // +1 јер ме успремник звона увијек оставља један простор празан.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Постоје три случаја од интереса:
            //   Сви елементи су изван жељених граница Елементи су суседни, а глава је ван жељених граница Елементи су нестални, а реп је изван жељених граница
            //
            //
            // У свим осталим временима, положаји елемената не утичу.
            //
            // Означава да треба премештати елементе на врху.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Премештање елемената изван жељених граница (позиције након циљне_капице)
            if self.tail >= target_cap && head_outside {
                // ТХ
                //   [. . . . . . . . o o o o o o o . ]
                //    ТХ
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ТХ
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // ХТ
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Скраћује Кс00Кс, задржавајући прве Кс01Кс елементе, а испуштајући остале.
    ///
    ///
    /// Ако је Кс00Кс већа од тренутне дужине `ВецДекуе`-а, то нема ефекта.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Покреће деструктор за све ставке у пресеку када падне (нормално или током одмотавања).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Сигурно јер:
        //
        // * Било који пресек прослеђен Кс00Кс је важећи;други случај има Кс01Кс и враћање на Кс02Кс осигурава Кс03Кс у првом случају
        //
        // * Глава ВецДекуе-а се помера пре позивања Кс00Кс, тако да се ниједна вредност не испушта два пута ако Кс01Кс З0паницс0З
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Обавезно испустите другу половину чак и када је деструктор у првој З0паницс0З.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Враћа предњи и задњи итератор.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Враћа итератор испред-назад који враћа променљиве референце.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // БЕЗБЕДНОСТ: Интерни Кс00Кс сигурносни инваријант је успостављен јер
        // `ring` који креирамо је дереференцирани комад за цео живот '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Враћа пар кришки које садрже редослед садржаја Кс00Кс.
    ///
    /// Ако је Кс00Кс претходно био позван, сви елементи Кс01Кс биће у првом пресеку, а други ће бити празан.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Враћа пар кришки које садрже редослед садржаја Кс00Кс.
    ///
    /// Ако је Кс00Кс претходно био позван, сви елементи Кс01Кс биће у првом пресеку, а други ће бити празан.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Даје број елемената у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Приказује Кс00Кс ако је Кс01Кс празан.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Ствара итератор који покрива наведени опсег у Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је почетна тачка већа од крајње тачке или ако је крајња тачка већа од дужине З0вектора0З.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Читав асортиман покрива све садржаје
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Заједничка референца коју имамо у Кс00Кс одржава се у '_ оф Итер.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Ствара итератор који покрива наведени променљиви опсег у Кс00Кс.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је почетна тачка већа од крајње тачке или ако је крајња тачка већа од дужине З0вектора0З.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Читав асортиман покрива све садржаје
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // БЕЗБЕДНОСТ: Интерни Кс00Кс сигурносни инваријант је успостављен јер
        // `ring` који креирамо је дереференцирани комад за цео живот '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Ствара одводни итератор који уклања наведени опсег у Кс00Кс и даје уклоњене ставке.
    ///
    /// Напомена 1: Опсег елемената уклања се чак и ако се итератор не потроши до краја.
    ///
    /// Напомена 2: Није прецизирано колико се елемената уклања из декуе-а, ако вредност Кс00Кс није испуштена, али позајмица коју задржава истиче (нпр. Због Кс01Кс).
    ///
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је почетна тачка већа од крајње тачке или ако је крајња тачка већа од дужине З0вектора0З.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Комплетна палета брише сав садржај
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Сигурност меморије
        //
        // Када се З0Драин0З први пут креира, изворни декуе се скраћује како би се осигурало да уопште нису доступни неиницијализовани или премештени елементи ако деструктор З0Драин0З никада не покрене.
        //
        //
        // З0Драин0З ће Кс00Кс избацити вредности за уклањање.
        // По завршетку, преостали подаци ће се копирати назад да покрију рупу, а вредности Кс00Кс ће бити исправно враћене.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Елементи Декуе-а подијељени су у три сегмента:
        // * self.tail  -> drain_tail
        // * З0драин_таил0З-> З0драин_хеад0З
        // * З0драин_хеад0З-> Кс00Кс
        //
        // Т=Кс00Кс;Х=Кс01Кс;т=З0драин_таил0З;х=З0драин_хеад0З
        //
        // З0драин_таил0З чувамо као Кс00Кс, а З0драин_хеад0З и Кс01Кс као афтер_таил и афтер_хеад на З0Драин0З.
        // Ово такође скраћује ефективни низ тако да ако процури З0Драин0З, заборавили смо на потенцијално померене вредности након почетка З0драин0З.
        //
        //
        //        Т тх Х
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" о вредностима након почетка З0драин0З до завршетка З0драин0З и покретања З0Драин0З деструктора.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Кључно је што овде стварамо само заједничке референце из Кс00Кс и читамо из њих.
                // Не пишемо на Кс00Кс нити се враћамо на променљиву референцу.
                // Стога сирови показивач који смо креирали горе, за Кс00Кс, остаје важећи.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Брише Кс00Кс уклањајући све вредности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Приказује Кс00Кс ако Кс01Кс садржи елемент једнак датој вредности.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Пружа референцу на предњи елемент или Кс00Кс ако је Кс01Кс празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Пружа променљиву референцу на предњи елемент или Кс00Кс ако је Кс01Кс празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Пружа референцу на задњи елемент или Кс00Кс ако је Кс01Кс празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Пружа променљиву референцу на задњи елемент или Кс00Кс ако је Кс01Кс празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Уклања први елемент и враћа га, или Кс00Кс ако је Кс01Кс празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Уклања последњи елемент из Кс00Кс и враћа га, или Кс01Кс ако је празан.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Додаје елемент у Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Додаје елемент на полеђину Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Да ли треба да узмемо у обзир Кс00Кс
        // да је Кс00Кс суседан?
        self.tail <= self.head
    }

    /// Уклања елемент са било ког места у Кс00Кс и враћа га, замењујући га првим елементом.
    ///
    ///
    /// Ово не чува редослед, али је *О*(1).
    ///
    /// Приказује Кс00Кс ако је Кс01Кс ван граница.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Уклања елемент са било ког места у Кс00Кс и враћа га, замењујући га последњим елементом.
    ///
    ///
    /// Ово не чува редослед, али је *О*(1).
    ///
    /// Приказује Кс00Кс ако је Кс01Кс ван граница.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Убацује елемент на Кс01Кс унутар Кс00Кс, померајући све елементе са индексима већим или једнаким Кс02Кс ка задњој страни.
    ///
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс већа од дужине `ВецДекуе`-а
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Преместите најмањи број елемената у међуспремник прстена и убаците дати објекат
        //
        // Премјестиће се највише Кс00Кс, 1 елемент. O(min(n, n-i))
        //
        // Три су главна случаја:
        //  Елементи су суседни
        //      - посебан случај када је реп 0 Елементи су нестални и уметак је у одељку репа Елементи су нестални и уметак је у одељку главе
        //
        //
        // За сваки од њих постоје још два случаја:
        //  Уметак је ближе репу Уметак је ближе глави
        //
        // Кључ: Х, Кс00Кс
        //      Т, Кс00Кс о, важећи елемент И, елемент за уметање А, елемент који треба да буде након тачке уметања М, означава да је елемент премештен
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       ТИХ
                //      [Оооооо.......
                //      .
                //      .]
                //
                //                       ХТ
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // суседни, уметните ближе репу:
                    //
                    //             ТИХ
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ТХ
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // суседни, уметните ближе репу и реп је 0:
                    //
                    //
                    //       ТИХ
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       ХТ
                    //      [o I A o o o o o . . . . . . . o]
                    //       ММ

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Већ смо померили реп, тако да копирамо само Кс00Кс елементе.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // суседни, уметните ближе глави:
                    //
                    //             ТИХ
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ТХ
                    //      [. . . o o o o I A o o . . . . .]
                    //                       МММ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // неспојиво, уметните ближе репу, одељак репа:
                    //
                    //                   ХТИ
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   ХТ
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // неспојив, уметните ближе глави, репни део:
                    //
                    //           ХТИ
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             ХТ
                    //      [o o o . . . . . . o o o o o I A]
                    //       ММММ

                    // копирајте елементе до нове главе
                    self.copy(1, 0, self.head);

                    // копирајте последњи елемент на празно место на дну бафера
                    self.copy(0, self.cap() - 1, 1);

                    // преместите елементе из идк-а у крај напред не укључујући ^ елемент
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // неспојив, уметак је ближе репу, одељку главе и налази се на индексу нула у унутрашњем баферу:
                    //
                    //
                    //       ИХТ
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           ХТ
                    //      [A o o o o o o o o o . . o o o I]
                    //                               МММ

                    // копирајте елементе до новог репа
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // копирајте последњи елемент на празно место на дну бафера
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // неспојиво, уметните ближе репу, део главе:
                    //
                    //             ИХТ
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           ХТ
                    //      [o o I A o o o o o o . . o o o o]
                    //       ММММММ

                    // копирајте елементе до новог репа
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // копирајте последњи елемент на празно место на дну бафера
                    self.copy(self.cap() - 1, 0, 1);

                    // преместите елементе из Кс00Кс на крај напред не укључујући ^ елемент
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // неспојиво, уметните ближе глави, одељак главе:
                    //
                    //               ИХТ
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     ХТ
                    //      [o o o o I A o o . . . . . o o o]
                    //                 МММ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // реп је можда промењен па морамо да прерачунамо
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Уклања и враћа елемент у Кс01Кс са Кс00Кс.
    /// Који год крај да је ближи тачки уклањања, помериће се како би се направило места, а сви погођени елементи биће премештени на нове положаје.
    ///
    /// Приказује Кс00Кс ако је Кс01Кс ван граница.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Три су главна случаја:
        //  Елементи су суседни Елементи су међусобно несклони и уклањање је у задњем делу Елементи су несавесно и уклањање је у главном делу
        //
        //      - посебан случај када су елементи технички суседни, али Кс00Кс=0
        //
        // За сваки од њих постоје још два случаја:
        //  Уметак је ближе репу Уметак је ближе глави
        //
        // Кључ: Х, Кс00Кс
        //      Т, Кс00Кс о, важећи елемент к, елемент означен за уклањање Р, означава елемент који се уклања М, означава да је елемент премештен
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // суседни, уклоните ближе репу:
                    //
                    //             ТРХ
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ТХ
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // суседни, уклоните ближе глави:
                    //
                    //             ТРХ
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ТХ
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // неспојиво, уклонити ближе репу, одељак репа:
                    //
                    //                   ХТР
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   ХТ
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // неспојиво, уклоните ближе глави, одељак главе:
                    //
                    //               РХТ
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   ХТ
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // неспојиво, уклонити ближе глави, репном делу:
                    //
                    //             ХТР
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           ХТ
                    //      [o o . . . . . . . o o o o o o o]
                    //       ММММ
                    //
                    // или квази нескладни, уклоните поред главе, репног дела:
                    //
                    //       ХТР
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ТХ
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // увући елементе у репни део
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Спречава подливање.
                    if self.head != 0 {
                        // копирајте први елемент на празно место
                        self.copy(self.cap() - 1, 0, 1);

                        // померање елемената у одељку главе уназад
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // неспојиво, уклонити ближе репу, део главе:
                    //
                    //           РХТ
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           ХТ
                    //      [o o o o o o o o o o . . . . o o]
                    //       МММММ

                    // увући елементе до идк
                    self.copy(1, 0, idx);

                    // копирајте последњи елемент на празно место
                    self.copy(0, self.cap() - 1, 1);

                    // померајте елементе од репа до краја напред, искључујући последњи
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Деље Кс00Кс на два на датом индексу.
    ///
    /// Враћа ново додељени Кс00Кс.
    /// `self` садржи елементе Кс01Кс, а враћени Кс02Кс садржи елементе Кс00Кс.
    ///
    /// Имајте на уму да се капацитет Кс00Кс не мења.
    ///
    /// Елемент са индексом 0 је предњи део реда.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако је Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` лежи у првом полувремену.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // само узмите цело друго полувреме.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` лежи у другој половини, треба узети у обзир елементе које смо прескочили у првој половини.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Чишћење тамо где су крајеви одбојника
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Премешта све елементе Кс01Кс у Кс00Кс, остављајући Кс02Кс празним.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови број елемената у себи пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // наивни импл
        self.extend(other.drain(..));
    }

    /// Задржава само елементе које наводи предикат.
    ///
    /// Другим речима, уклоните све елементе Кс00Кс тако да Кс01Кс врати фалсе.
    /// Ова метода делује на месту, посећујући сваки елемент тачно једном у оригиналном редоследу и задржава редослед задржаних елемената.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Тачан редослед може бити користан за праћење спољног стања, попут индекса.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Ово може З0паниц0З или прекинути
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Удвостручите величину бафера.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Модификује Кс01Кс на месту тако да је Кс02Кс једнак Кс00Кс, било уклањањем вишка елемената са задње стране или додавањем елемената генерисаних позивањем Кс03Кс на задњу страну.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Преуређује унутрашњу меморију овог декуе-а тако да је један суседни комад, који се затим враћа.
    ///
    /// Ова метода не додељује и не мења редослед убачених елемената.Како враћа променљиву кришку, ово се може користити за сортирање декуе-а.
    ///
    /// Једном када се интерна меморија приближи, методе Кс00Кс и Кс01Кс враћају целокупан садржај Кс02Кс у једном пресеку.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Сортирање садржаја декуе-а.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // сортирање деке
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // сортирање у обрнутом редоследу
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Добијање непроменљивог приступа суседном парчету.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // сада можемо бити сигурни да Кс01Кс садржи све елементе декуе-а, а да и даље има непроменљив приступ Кс00Кс.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // има довољно слободног простора за копирање репа у једном потезу, то значи да прво померамо главу уназад, а затим реп копирамо у исправан положај.
            //
            //
            // од: ДЕФГХ .... АБЦ
            // до: АБЦДЕФГХ ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Тренутно не разматрамо .... АБЦДЕФГХ
            // да буде суседна, јер би Кс00Кс у овом случају био Кс01Кс.
            // Иако ово вероватно желимо да променимо, то није тривијално, јер на неким местима очекује да Кс01Кс значи да можемо једноставно да нарежемо на Кс00Кс.
            //
            //

            // има довољно слободног простора за копирање главе у једном потезу, то значи да прво померамо реп напред, а затим копирамо главу у исправан положај.
            //
            //
            // од: ФГХ .... АБЦДЕ
            // до: ... АБЦДЕФГХ.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // фрее је мањи и од главе и од репа, то значи да морамо полако Кс00Кс да правимо реп и главу.
            //
            //
            // од: ЕФГХИ ... АБЦД или Кс00Кс
            // до: АБЦДЕФГХИ ... или АБЦДЕФГХИЈК.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Општи проблем изгледа овако ГХИЈКЛМ ... АБЦДЕФ, пре било каквих замена АБЦДЕФМ ... ГХИЈКЛ, након 1 проласка замена АБЦДЕФГХИЈМ ... КЛ, мењајте док леви З0едге0З не дође у привремену продавницу
                //                  - затим поново покрените алгоритам са новом Кс00Кс продавницом Понекад се постигне привремена меморија када је прави З0едге0З на крају бафера, то значи да смо постигли прави редослед са мање замена!
                //
                // E.g
                // ЕФ..АБЦД АБЦДЕФ .., након само четири замене смо завршили
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Ротира двоструки ред Кс00Кс места лево.
    ///
    /// Equivalently,
    /// - Ротира ставку Кс00Кс на прву позицију.
    /// - Отвори прве Кс00Кс предмете и потисне их до краја.
    /// - Ротира Кс00Кс места десно.
    ///
    /// # Panics
    ///
    /// Ако је Кс01Кс већи од Кс00Кс.
    /// Имајте на уму да Кс00Кс ради Кс01Кс З0паниц0З и да се не окреће.
    ///
    /// # Complexity
    ///
    /// Заузима Кс01Кс време и нема додатног простора.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Ротира двоструки ред Кс00Кс места удесно.
    ///
    /// Equivalently,
    /// - Ротира прву ставку у положај Кс00Кс.
    /// - Избаци последње Кс00Кс предмете и гурне их напред.
    /// - Ротира Кс00Кс места лево.
    ///
    /// # Panics
    ///
    /// Ако је Кс01Кс већи од Кс00Кс.
    /// Имајте на уму да Кс00Кс ради Кс01Кс З0паниц0З и да се не окреће.
    ///
    /// # Complexity
    ///
    /// Заузима Кс01Кс време и нема додатног простора.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // БЕЗБЕДНОСТ: следеће две методе захтевају износ ротације
    // бити мања од половине дужине деке.
    //
    // `wrap_copy` захтева Кс00Кс, али Кс01Кс никада није већи од половине капацитета, без обзира на к, па је звучно позвати овде јер зовемо са нечим мањим од половине дужине, која никада није изнад половине капацитета.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Бинарни претражује овај сортирани Кс00Кс за датим елементом.
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.
    /// Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента.
    /// Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Ако желите да уметнете ставку у сортирани Кс00Кс, а да притом задржите редослед сортирања:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Бинарни претражује овај сортирани Кс00Кс са функцијом упоређивања.
    ///
    /// Функција упоређивања треба да имплементира налог који је у складу са редоследом сортирања основног Кс00Кс, враћајући код налога који указује да ли је његов аргумент Кс01Кс, Кс02Кс или Кс03Кс од жељеног циља.
    ///
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента.Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Бинарни претражује овај сортирани Кс00Кс са функцијом извлачења кључа.
    ///
    /// Претпоставља да је Кс00Кс сортиран по кључу, на пример са Кс01Кс користећи исту функцију извлачења кључа.
    ///
    ///
    /// Ако је вредност пронађена, тада се враћа Кс00Кс, који садржи индекс одговарајућег елемента.
    /// Ако постоји више подударања, тада би се могла вратити било која од подударности.
    /// Ако вредност није пронађена, тада се враћа Кс00Кс, који садржи индекс где би могао да се убаци одговарајући елемент, а да се одржи сортирани редослед.
    ///
    /// # Examples
    ///
    /// Потражује низ од четири елемента у парчету парова сортираних по њиховим другим елементима.
    /// Пронађена је прва, са јединствено одређеним положајем;други и трећи нису пронађени;четврти би могао да се подудара са било којом позицијом у Кс00Кс.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Модификује Кс00Кс на месту тако да је Кс01Кс једнак нев_лен, било уклањањем вишка елемената са задње стране или додавањем клонова Кс02Кс на задњу страну.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Враћа индекс у основном међуспремнику за дати индекс логичког елемента.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // величина је увек снага 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Израчунајте број елемената који су преостали за читање у међуспремнику
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // величина је увек снага 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Увек дељив у три одељка, на пример: селф: Кс03Кс отхер: Кс01Кс фронт=3, мид=1, Кс02Кс==Кс04Кс&&Кс05Кс==Кс06Кс&&Кс07Кс==Кс00Кс
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Није могуће користити Кс00Кс на кришкама враћеним методом ас_слицес, јер њихова дужина може варирати у иначе идентичним декуеовима.
        //
        //
        // Хасхер гарантује еквивалентност само за потпуно исти скуп позива својих метода.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Конзумира Кс00Кс у предњи и задњи итератор који даје елементе по вредности.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ова функција би требала бити морални еквивалент:
        //
        //      за артикал у Кс00Кс {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Претворите Кс01Кс у Кс00Кс.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ово избегава прерасподелу где год је то могуће, али услови за то су строги и подложни су променама, па се на то не треба ослањати осим ако Кс00Кс потиче из Кс01Кс и није прерасподељен.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Не постоји стварна расподела за ЗСТ-ове да брину о капацитету, али Кс01Кс не може да поднесе толико дужине као Кс00Кс.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Морамо да променимо величину ако капацитет није двоје, премален или нема барем један слободан простор.
            // То радимо док је још увек у Кс00Кс, тако да ће предмети пасти на З0паниц0З.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Претворите Кс01Кс у Кс00Кс.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ово никада не треба прерасподељивати, али мора извршити *О*(*н*) кретање података ако случајно кружни бафер није на почетку додељивања.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Овај је *О*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Овом је потребно преуређивање података.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}