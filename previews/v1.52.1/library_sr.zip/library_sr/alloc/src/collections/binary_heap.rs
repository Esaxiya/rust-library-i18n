//! Приоритетни ред имплементиран са бинарном хрпом.
//!
//! Уметање и искакање највећег елемента имају временску сложеност Кс00Кс.
//! Провера највећег елемента је *О*(1).Претварање З0вецтор0З у бинарну гомилу може се извршити на месту и има сложеност *О*(*н*).
//! Бинарна гомила се такође може претворити у сортирани З0вецтор0З на месту, омогућавајући му употребу за *О*(*н*\* Кс00Кс на месту.
//!
//! # Examples
//!
//! Ово је већи пример који примењује Кс01Кс за решавање Кс02Кс на Кс00Кс.
//!
//! Показује како се Кс00Кс користи са прилагођеним типовима.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Редослед приоритета зависи од Кс00Кс.
//! // Експлицитно имплементирајте З0 Портраит0З тако да ред постаје мин-гомила уместо мак-гомила.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Приметите да преокрећемо редослед трошкова.
//!         // У случају изједначења упоређујемо позиције, овај корак је неопходан како би имплементације Кс00Кс и Кс01Кс биле доследне.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` треба такође применити.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Сваки чвор је представљен као Кс00Кс, ради краће примене.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Дијкстрин најкраћи алгоритам путање.
//!
//! // Почните од Кс00Кс и користите Кс01Кс да бисте пратили тренутно најкраћу удаљеност до сваког чвора.Ова имплементација није ефикасна у меморији, јер може оставити дуплиране чворове у реду.
//! //
//! // Такође користи Кс00Кс као контролну вредност, ради једноставније примене.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // дист [ноде]=тренутно најкраћа удаљеност од Кс01Кс до Кс00Кс
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Налазимо се на Кс00Кс, са нултим трошковима
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Прво испитајте границу са чворовима са нижом ценом
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Алтернативно, могли смо да наставимо да проналазимо све најкраће стазе
//!         if position == goal { return Some(cost); }
//!
//!         // Важно јер смо можда већ пронашли бољи начин
//!         if cost > dist[position] { continue; }
//!
//!         // За сваки чвор до којег можемо доћи, погледајте да ли можемо пронаћи начин са нижим трошковима који пролази кроз овај чвор
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ако је тако, додајте је на границу и наставите
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Опуштање, сада смо пронашли бољи начин
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Циљ није достижан
//!     None
//! }
//!
//! fn main() {
//!     // Ово је усмерени граф који ћемо користити.
//!     // Бројеви чворова одговарају различитим стањима, а пондери З0едге0З симболизују трошкове преласка са једног чвора на други.
//!     //
//!     // Имајте на уму да су ивице једносмерне.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          в 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||. |
//!     //                   +---------------+
//!     //
//!     // Графикон је представљен као листа суседности где сваки индекс, који одговара вредности чвора, има листу одлазних ивица.
//!     // Изабран због своје ефикасности.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Чвор 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Чвор 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Чвор 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Чвор 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Чвор 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Приоритетни ред имплементиран са бинарном хрпом.
///
/// Ово ће бити максимална гомила.
///
/// Логична је грешка да се ставка модификује на такав начин да се редослед ставке у односу на било коју другу ставку, како је одређено Кс00Кс З0 Портраит0З, мења док је у гомили.
///
/// То је обично могуће само путем Кс00Кс, Кс01Кс, глобалног стања, Кс02Кс или небезбедног кода.
/// Понашање које је резултат такве логичке грешке није наведено, али неће резултирати недефинисаним понашањем.
/// То може укључивати З0паницс0З, нетачне резултате, прекиде, цурење меморије и не-прекид.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Закључивање типа омогућава нам да изоставимо експлицитни потпис типа (који би у овом примеру био Кс00Кс).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Помоћу завирења можемо погледати следећу ставку у гомили.
/// // У овом случају још нема предмета, па добивамо Ниједан.
/// assert_eq!(heap.peek(), None);
///
/// // Додајмо неке резултате ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Сада завиривање показује најважнију ставку у гомили.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Можемо проверити дужину гомиле.
/// assert_eq!(heap.len(), 3);
///
/// // Можемо прелазити преко ставки у гомили, иако се враћају случајним редоследом.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ако уместо тога ставимо ове резултате, они би се требали вратити по реду.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Можемо очистити гомилу свих преосталих предмета.
/// heap.clear();
///
/// // Гомила би сада требала бити празна.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Или Кс00Кс или прилагођена имплементација Кс01Кс могу се користити за прављење Кс02Кс од минималне гомиле.
/// То чини да Кс00Кс враћа најмању вредност уместо највеће.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Вредности умотавања у Кс00Кс
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ако сада ставимо ове резултате, требали би се вратити обрнутим редоследом.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Сложеност времена
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Вредност за Кс00Кс је очекивани трошак;документација о методи даје детаљнију анализу.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Структура која омотава променљиву референцу на највећи предмет на Кс00Кс.
///
///
/// Овај Кс01Кс је креиран методом Кс02Кс на Кс00Кс.
/// Погледајте документацију за више информација.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // БЕЗБЕДНОСТ: ПеекМут је инстанциран само за непразне гомиле.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // СИГУРНО: ПеекМут је инстанциран само за непразне гомиле
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // СИГУРНО: ПеекМут је инстанциран само за непразне гомиле
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Уклања вирену вредност из гомиле и враћа је.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Ствара празан Кс00Кс.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Ствара празан Кс00Кс као максималну гомилу.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Ствара празан Кс00Кс одређеног капацитета.
    /// Ово унапред додељује довољно меморије за Кс00Кс елементе, тако да Кс01Кс не мора бити прерасподељен док не садржи бар толико вредности.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Враћа променљиву референцу на највећу ставку у бинарној хрпи или Кс00Кс ако је празна.
    ///
    /// Note: Ако процури вредност Кс00Кс, гомила може бити у нескладном стању.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Сложеност времена
    ///
    /// Ако је ставка модификована, тада је најгора временска сложеност Кс00Кс, иначе је *О*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Уклања највећу ставку из бинарне хрпе и враћа је, или Кс00Кс ако је празна.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Сложеност времена
    ///
    /// Најгора цена Кс01Кс на хрпи која садржи *н* елементе је Кс00Кс.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // БЕЗБЕДНОСТ: Кс00Кс значи да је Кс01Кс> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Гура ставку на бинарну хрпу.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Сложеност времена
    ///
    /// Очекивани трошак Кс00Кс, просечан по сваком могућем редоследу потискивања елемената и током довољно великог броја потискивања, је *О*(1).
    ///
    /// Ово је најсмисленија метрика трошкова када се гурају елементи који *нису* већ у било ком сортираном обрасцу.
    ///
    /// Временска сложеност се погоршава ако се елементи потискују у претежно растућем редоследу.
    /// У најгорем случају, елементи се потискују растућим сортираним редоследом, а амортизована цена по потискивању је Кс00Кс према гомили која садржи *н* елемената.
    ///
    /// Најгори случај *појединачног* позива на Кс00Кс је *О*(*н*).Најгори случај се дешава када се капацитет исцрпи и треба му променити величину.
    /// Трошак промене величине амортизован је у претходним цифрама.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // БЕЗБЕДНОСТ: Будући да смо гурнули нову ставку, то значи да
        //  олд_лен=Кс01Кс, 1 <Кс00Кс
        unsafe { self.sift_up(0, old_len) };
    }

    /// Троши Кс00Кс и враћа З0вецтор0З у сортираном редоследу Кс01Кс.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // БЕЗБЕДНОСТ: Кс00Кс прелази са Кс01Кс на 1 (оба су укључена),
            //  тако да је увек важећи индекс за приступ.
            //  Сигурно је приступити индексу 0 (тј. Кс00Кс), јер
            //  1 <=крај <Кс00Кс, што значи Кс01Кс>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // БЕЗБЕДНОСТ: Кс00Кс прелази са Кс01Кс на 1 (оба су укључена), тако да:
            //  0 <1 <=крај <=Кс01Кс, 1 <Кс02Кс Што значи 0 <крај и крај <Кс00Кс.
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Имплементације сифт_уп и сифт_довн користе небезбедне блокове да би се елемент преместио из З0вецтор0З (остављајући рупу), померио дуж осталих и уклонио уклоњени елемент назад у З0вецтор0З на коначном месту рупе.
    //
    // За представљање се користи тип Кс00Кс и побрините се да се рупа на крају обима попуни, чак и на З0паниц0З.
    // Коришћење рупе смањује константни фактор у поређењу са коришћењем замена, што укључује двоструко више потеза.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Позиватељ мора да гарантује да је Кс00Кс.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Извадите вредност на Кс00Кс и направите рупу.
        // БЕЗБЕДНОСТ: Позиватељ гарантује да је поз <Кс00Кс
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // БЕЗБЕДНОСТ: Кс00Кс> старт>=0, што значи Кс01Кс> 0
            //  и тако Кс00Кс, 1 не може да се залије.
            //  Ово гарантује да је родитељ <Кс01Кс, па је то важећи индекс, а такође и!=Кс00Кс.
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // БЕЗБЕДНОСТ: Исто као горе
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Узмите елемент на Кс00Кс и померите га низ хрпу, док су његова деца већа.
    ///
    ///
    /// # Safety
    ///
    /// Позиватељ мора да гарантује да је Кс00Кс.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // БЕЗБЕДНОСТ: Позиватељ гарантује да је поз <крај <=Кс00Кс.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Непроменљива петља: дете==2 * Кс00Кс + 1.
        while child <= end.saturating_sub(2) {
            // упоредите са већим од двоје деце БЕЗБЕДНОСТ: дете <крај, 1 <Кс01Кс и дете + 1 <крај <=Кс00Кс, тако да су важећи индекси.
            //
            //  дете==2 *Кс01Кс + 1!=Кс02Кс и дете + 1==2* Кс03Кс + 2!=Кс00Кс.
            // FIXME: 2 *Кс00Кс + 1 или 2* Кс01Кс + 2 могу се прелити ако је Т ЗСТ
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ако смо већ у реду, станите.
            // БЕЗБЕДНОСТ: дете је сада или старо дете или старо дете + 1
            //  Већ смо доказали да су оба <Кс01Кс и!=Кс00Кс
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // БЕЗБЕДНОСТ: исто као горе.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // БЕЗБЕДНОСТ: &&кратки спој, што значи да у
        //  други услов је већ тачно да је дете==крај, 1 <Кс00Кс.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // БЕЗБЕДНОСТ: дете је већ доказано ваљан индекс и
            //  дете==2 * Кс01Кс + 1!=Кс00Кс.
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Позиватељ мора да гарантује да је Кс00Кс.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // БЕЗБЕДНОСТ: поз <лен гарантује позивалац и
        //  очигледно лен=Кс01Кс <=Кс00Кс.
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Узмите елемент у Кс00Кс и померите га скроз низ хрпу, а затим га просејте до свог положаја.
    ///
    ///
    /// Note: То је брже када се зна да је елемент велик/ако би требао бити ближе дну.
    ///
    /// # Safety
    ///
    /// Позиватељ мора да гарантује да је Кс00Кс.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // БЕЗБЕДНОСТ: Позиватељ гарантује да је поз <Кс00Кс.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Непроменљива петља: дете==2 * Кс00Кс + 1.
        while child <= end.saturating_sub(2) {
            // БЕЗБЕДНОСТ: дете <крај, 1 <Кс00Кс и
            //  дете + 1 <крај <=Кс00Кс, тако да су важећи индекси.
            //  дете==2 *Кс01Кс + 1!=Кс02Кс и дете + 1==2* Кс03Кс + 2!=Кс00Кс.
            //
            // FIXME: 2 *Кс00Кс + 1 или 2* Кс01Кс + 2 могу се прелити ако је Т ЗСТ
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // БЕЗБЕДНОСТ: Исто као горе
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // БЕЗБЕДНОСТ: дете==крај, 1 <Кс00Кс, тако да је то важећи индекс
            //  и дете==2 * Кс01Кс + 1!=Кс00Кс.
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // БЕЗБЕДНОСТ: поз је положај у рупи и већ је доказан
        //  да буде важећи индекс.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // БЕЗБЕДНОСТ: н почиње од Кс00Кс/2 и спушта се на 0.
            //  Једини случај када! (Н <Кс00Кс је ако је Кс01Кс==0, али то искључује услов петље.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Премешта све елементе Кс01Кс у Кс00Кс, остављајући Кс02Кс празним.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` узима Кс01Кс операције и око 2 *(Кс07Кс + Кс08Кс) поређења у најгорем случају, док Кс02Кс узима Кс03Кс операције и око 1* Кс04Кс * Кс05Кс поређења у најгорем случају, под претпоставком Кс06Кс>=Кс00Кс.
        // За веће гомиле тачка укрштања више не следи ово образложење и одређена је емпиријски.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Враћа итератор који преузима елементе у редоследу гомиле.
    /// Преузети елементи уклањају се са оригиналне гомиле.
    /// Преостали елементи ће се уклонити у падајућем редоследу.
    ///
    /// Note:
    /// * `.drain_sorted()` је *О*(*н*\* Кс01Кс; много спорији од Кс00Кс.
    ///   Ово потоње бисте требали користити у већини случајева.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // уклања све елементе у редоследу гомиле
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Задржава само елементе које наводи предикат.
    ///
    /// Другим речима, уклоните све елементе Кс01Кс тако да Кс02Кс врати Кс00Кс.
    /// Елементи се посећују у несортованом (и неспецификованом) редоследу.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // задржите само парне бројеве
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Враћа итератор који посећује све вредности у основном З0вецтор0З, произвољним редоследом.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Одштампајте 1, 2, 3, 4 произвољним редоследом
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Враћа итератор који преузима елементе у редоследу гомиле.
    /// Ова метода троши оригиналну гомилу.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Враћа највећу ставку у бинарној хрпи или Кс00Кс ако је празна.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Сложеност времена
    ///
    /// Трошак је *О*(1) у најгорем случају.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Приказује број елемената који бинарна гомила може да садржи без прерасподјеле.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Резервише минимални капацитет за тачно Кс01Кс додатних елемената који се убацују у дати Кс00Кс.
    /// Не чини ништа ако је капацитет већ довољан.
    ///
    /// Имајте на уму да додељивач може колекцији дати више простора него што захтева.
    /// Стога се не може поуздати да је капацитет тачно минималан.
    /// Дајте предност Кс00Кс ако се очекују уметања З0футуре0З.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Резервише капацитет за најмање Кс01Кс додатних елемената који се убацују у Кс00Кс.
    /// Збирка може резервисати више простора како би се избегле честе прерасподеле.
    ///
    /// # Panics
    ///
    /// З0Паницс0З ако нови капацитет пређе Кс00Кс.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Одбацује што већи додатни капацитет.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Баца капацитет са доњом границом.
    ///
    /// Капацитет ће остати најмање толико велик колико и дужина и испоручена вредност.
    ///
    ///
    /// Ако је тренутни капацитет мањи од доње границе, ово се не примењује.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Троши Кс00Кс и враћа основни З0вецтор0З произвољним редоследом.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Штампаће се по неком редоследу
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Даје дужину бинарне хрпе.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Проверава да ли је бинарна гомила празна.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Брише бинарну хрпу, враћајући итератор преко уклоњених елемената.
    ///
    /// Елементи се уклањају произвољним редоследом.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Одбацује све ставке из бинарне хрпе.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Рупа представља рупу у пресеку, тј. Индекс без важеће вредности (јер је премештена из или дуплирана).
///
/// У паду, Кс00Кс ће вратити рез тако што ће положај рупе попунити вредношћу која је првобитно уклоњена.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Направите нови Кс01Кс са индексом Кс00Кс.
    ///
    /// Небезбедно, јер пози морају бити унутар пресека података.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // СИГУРНО: поз треба да буде унутар пресека
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Враћа референцу на уклоњени елемент.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Враћа референцу на елемент на Кс00Кс.
    ///
    /// Небезбедно јер индекс мора бити унутар пресека података и не мора бити једнак поз.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Преместите рупу на ново место
    ///
    /// Небезбедно јер индекс мора бити унутар пресека података и не мора бити једнак поз.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // поново попуните рупу
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Итератор над елементима Кс00Кс.
///
/// Овај Кс01Кс је креирао Кс00Кс.
/// Погледајте документацију за више информација.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Уклоните у корист Кс00Кс
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Поседовање итератора над елементима Кс00Кс.
///
/// Овај Кс00Кс је креирао Кс01Кс (обезбедио Кс02Кс З0 Портраит0З).
/// Погледајте документацију за више информација.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Одводни итератор преко елемената Кс00Кс.
///
/// Овај Кс01Кс је креирао Кс00Кс.
/// Погледајте документацију за више информација.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Одводни итератор преко елемената Кс00Кс.
///
/// Овај Кс01Кс је креирао Кс00Кс.
/// Погледајте документацију за више информација.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Уклања елементе гомиле по редоследу гомиле.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// Ова конверзија се дешава на месту и има *О*(*н*) временску сложеност.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Претвара Кс01Кс у Кс00Кс.
    ///
    /// Ова конверзија не захтева кретање или алокацију података и има сталну временску сложеност.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ствара конзумирајући итератор, односно онај који премешта сваку вредност из бинарне гомиле у произвољном редоследу.
    /// Бинарна гомила се не може користити након позива.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Одштампајте 1, 2, 3, 4 произвољним редоследом
    /// for x in heap.into_iter() {
    ///     // к има тип Кс01Кс, а не Кс00Кс
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}