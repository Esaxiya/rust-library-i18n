use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Додаје све парове кључ/вредност из обједињавања два узлазна итератора, увећавајући Кс00Кс променљиву током пута.Ово последње олакшава позиваоцу да избегне цурење када се руковатељ падом успаничи.
    ///
    /// Ако оба итератора производе исти кључ, овај метод испушта пар из левог итератора и додаје пар из десног итератора.
    ///
    /// Ако желите да дрво заврши у строго растућем редоследу, као код Кс00Кс, оба итератора треба да произведу кључеве у строго растућем редоследу, сваки већи од свих кључева у дрвету, укључујући све кључеве који се већ налазе у дрвету при уносу.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Припремамо се за спајање Кс00Кс и Кс01Кс у сортирани низ у линеарном времену.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // У међувремену, из сортираног низа градимо дрво у линеарном времену.
        self.bulk_push(iter, length)
    }

    /// Потискује све парове кључ/вредност на крај стабла, увећавајући Кс00Кс променљиву током пута.
    /// Ово последње олакшава позиваоцу да избегне цурење када се итератор успаничи.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Прелиставајте све парове кључ/вредност, гурајући их у чворове на правом нивоу.
        for (key, value) in iter {
            // Покушајте да потиснете пар кључ/вредност у тренутни чвор листа.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Нема више места, идите горе и гурајте тамо.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Пронашли смо чвор са преосталим простором, гурните овде.
                                open_node = parent;
                                break;
                            } else {
                                // Иди горе.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // На врху смо, створимо нови коренски чвор и гурнемо тамо.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Притисни пар кључ/вредност и ново десно подстабло.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Поново се спустите на крајњи десни лист.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Повећавајте дужину сваке итерације како бисте били сигурни да карта испушта додате елементе чак и ако напредовање итератора успаничи.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Итератор за спајање две сортиране секвенце у једну
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ако су два кључа једнака, враћа пар кључ/вредност из десног извора.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}