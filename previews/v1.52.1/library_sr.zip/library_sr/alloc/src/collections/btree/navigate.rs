use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Привремено вади још један, непроменљиви еквивалент истог опсега.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Проналази различите ивице листа које ограничавају наведени опсег на дрвету.
    /// Враћа или пар различитих ручица у исто стабло или пар празних опција.
    ///
    /// # Safety
    ///
    /// Ако Кс01Кс није Кс00Кс, немојте користити дупликате ручица да бисте два пута посетили исти КВ.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Еквивалентно Кс00Кс, Кс01Кс, али ефикасније.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Проналази пар ивица листа који ограничавају одређени опсег на дрвету.
    ///
    /// Резултат је значајан само ако је дрво поредано по кључу, као што је дрво у Кс00Кс.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // БЕЗБЕДНОСТ: наш тип позајмљивања је непроменљив.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Проналази пар ивица листа који ограничавају цело дрво.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Дијели јединствену референцу на пар ивица листа ограничавајући наведени распон.
    /// Резултат су нејединствене референце које омогућавају мутацију Кс00Кс, које се морају пажљиво користити.
    ///
    /// Резултат је значајан само ако је дрво поредано по кључу, као што је дрво у Кс00Кс.
    ///
    ///
    /// # Safety
    /// Не користите дуплиране ручке да бисте два пута посетили исти КВ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Дијели јединствену референцу на пар ивица листа ограничавајући читав опсег стабла.
    /// Резултати су јединствене референце које омогућавају мутацију (само вредности), па се морају користити пажљиво.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Овде дуплирамо роот НодеРеф-никада нећемо посетити исти КВ два пута и никада нећемо завршити са референцама вредности које се преклапају.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Дијели јединствену референцу на пар ивица листа ограничавајући читав опсег стабла.
    /// Резултати су јединствене референце које омогућавају масовно деструктивну мутацију, па се морају користити са највећом пажњом.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Овде дуплирамо роот НодеРеф-никада му нећемо приступити на начин који се преклапа са референцама добијеним из роот-а.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// С обзиром на дршку листа З0едге0З, враћа Кс00Кс са дршком у суседни КВ на десној страни, који се налази у истом чвору листа или у чвору претка.
    ///
    /// Ако је лист З0едге0З последњи на дрвету, враћа Кс00Кс са коренским чвором.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// С обзиром на дршку листа З0едге0З, враћа Кс00Кс са дршком у суседни КВ на левој страни, који се налази у истом чвору листа или у чвору претка.
    ///
    /// Ако је лист З0едге0З први на дрвету, враћа Кс00Кс са коријенским чвором.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// С обзиром на интерну З0едге0З ручицу, враћа Кс00Кс са ручицом у суседни КВ на десној страни, који је или у истом унутрашњем чвору или у чвору претка.
    ///
    /// Ако је интерни З0едге0З последњи у стаблу, враћа Кс00Кс са коренским чвором.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// С обзиром да се листа З0едге0З листа у умируће дрво, враћа следећи лист З0едге0З на десној страни и пар кључ/вредност између који се налази или у истом чвору листа, у чвору претка или не постоји.
    ///
    ///
    /// Ова метода такође ослобађа сваки Кс00Кс чији је крај.
    /// То имплицира да ако више не постоји пар кључ/вредност, цео остатак стабла ће бити ослобођен и нема више шта да се врати.
    ///
    /// # Safety
    /// Дати З0едге0З не сме претходно бити враћен од стране колеге Кс00Кс.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// С обзиром да се лист З0едге0З листа у умируће дрво, враћа следећи лист З0едге0З на левој страни и пар кључ/вредност између који је или у истом чвору листа, у чвору претка или не постоји.
    ///
    ///
    /// Ова метода такође ослобађа сваки Кс00Кс чији је крај.
    /// То имплицира да ако више не постоји пар кључ/вредност, цео остатак стабла ће бити ослобођен и нема више шта да се врати.
    ///
    /// # Safety
    /// Дати З0едге0З не сме претходно бити враћен од стране колеге Кс00Кс.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Даље алоцира гомилу чворова од листа до корена.
    /// Ово је једини начин да се уклони остатак дрвета након што су Кс00Кс и Кс01Кс грицкали обе стране стабла и погодили исти З0едге0З.
    /// Будући да је намењен позиву само када су враћени сви кључеви и вредности, не врши се чишћење ниједног кључа или вредности.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Премешта ручицу листа З0едге0З на следећи лист З0едге0З и враћа референце на кључ и вредност између.
    ///
    ///
    /// # Safety
    /// Мора да постоји још један КВ у пређеном правцу.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Премешта ручицу листа З0едге0З на претходни лист З0едге0З и враћа референце на кључ и вредност између.
    ///
    ///
    /// # Safety
    /// Мора да постоји још један КВ у пређеном правцу.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Премешта ручицу листа З0едге0З на следећи лист З0едге0З и враћа референце на кључ и вредност између.
    ///
    ///
    /// # Safety
    /// Мора да постоји још један КВ у пређеном правцу.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ово последње је брже, према мерилима.
        kv.into_kv_valmut()
    }

    /// Премешта ручицу листа З0едге0З на претходни лист и враћа референце на кључ и вредност између.
    ///
    ///
    /// # Safety
    /// Мора да постоји још један КВ у пређеном правцу.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ово последње је брже, према мерилима.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Премешта ручицу листа З0едге0З на следећи лист З0едге0З и враћа кључ и вредност између њих, ослобађајући било који чвор који је остао док одговарајући З0едге0З оставља у свом матичном чвору који се мота.
    ///
    /// # Safety
    /// - Мора да постоји још један КВ у пређеном правцу.
    /// - Та колега Кс00Кс претходно није вратио КВ ни на једној копији дршки које се користе за прелазак стаблом.
    ///
    /// Једини сигуран начин да се настави са ажурираном ручицом је упоређивање, испуштање, поновно позивање ове методе у складу са њеним безбедносним условима или позивање колеге Кс00Кс у складу са њеним безбедносним условима.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Премешта ручицу листа З0едге0З на претходни лист З0едге0З и враћа кључ и вредност између њих, ослобађајући било који чвор који је остао, остављајући одговарајући З0едге0З у свом матичном чвору да виси.
    ///
    /// # Safety
    /// - Мора да постоји још један КВ у пређеном правцу.
    /// - Колега Кс00Кс претходно није вратио тај лист З0едге0З ни на једној копији дршки која се користи за прелазак стаблом.
    ///
    /// Једини сигуран начин да се настави са ажурираном ручицом је упоређивање, испуштање, поновно позивање ове методе у складу са њеним безбедносним условима или позивање колеге Кс00Кс у складу са њеним безбедносним условима.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Враћа крајњи леви лист З0едге0З у или испод чвора, другим речима, З0едге0З који вам је потребан при навигацији напред (или последњи при кретању уназад).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Приказује крајњи десни лист З0едге0З у или испод чвора, другим речима, З0едге0З који вам је потребан последњи за навигацију напред (или први за навигацију уназад).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Посећује чворове листова и интерне КВ-ове по редоследу узлазних кључева, а такође посећује и интерне чворове у целини у дубини првог реда, што значи да унутрашњи чворови претходе њиховим појединачним КВ-овима и њиховим подређеним чворовима.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Израчунава број елемената у (под) стаблу.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Враћа лист З0едге0З најближи КВ за напредну навигацију.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Враћа лист З0едге0З најближи КВ за уназадну навигацију.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}