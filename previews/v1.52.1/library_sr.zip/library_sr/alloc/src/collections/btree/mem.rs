use core::intrinsics;
use core::mem;
use core::ptr;

/// Ово замењује вредност иза Кс00Кс јединствене референце позивањем релевантне функције.
///
///
/// Ако се З0паниц0З догоди у затварању Кс00Кс, цео поступак ће бити прекинут.
#[allow(dead_code)] // чувати као илустрацију и за употребу за З0футуре0З
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ово замењује вредност иза јединствене референце Кс00Кс позивањем релевантне функције и враћа резултат добијен успут.
///
///
/// Ако се З0паниц0З догоди у затварању Кс00Кс, цео поступак ће бити прекинут.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}