use backtrace::Backtrace;

// Овај тест ради само на платформама које имају функционалну Кс00Кс функцију за оквире који пријављују почетну адресу симбола.
// Као резултат, омогућен је само на неколико платформи.
//
const ENABLED: bool = cfg!(all(
    // Windows није стварно тестиран, а ОСКС не подржава заправо проналажење затвореног оквира, па онемогућите ово
    //
    target_os = "linux",
    // На АРМ-у проналажење функције затварања једноставно враћа сам ип.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}