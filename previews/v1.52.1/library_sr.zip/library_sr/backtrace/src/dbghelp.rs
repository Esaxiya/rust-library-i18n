//! Модул за помоћ у управљању дбгхелп везама на Кс00Кс
//!
//! Повратни трагови на Кс00Кс (барем за МСВЦ) углавном се напајају путем Кс01Кс и различитих функција које садржи.
//! Ове функције се тренутно учитавају *динамички*, уместо да се статички повезују са Кс00Кс.
//! То тренутно ради стандардна библиотека (и тамо је у теорији то потребно), али је покушај да се помогне у смањењу статичких ДЛЛ зависности библиотеке, јер су повратни трагови обично прилично необавезни.
//!
//! То се каже, Кс01Кс готово увек успешно учитава на Кс00Кс.
//!
//! Имајте на уму да, с обзиром да динамички учитавамо сву ову подршку, заправо не можемо да користимо необрађене дефиниције у Кс00Кс, већ морамо сами да дефинишемо типове показивача функција и то користимо.
//! Заправо не желимо да се бавимо дуплирањем винапија, тако да имамо функцију З0Царго0З Кс00Кс која тврди да се све везе подударају са онима у винапију, а ова функција је омогућена на ЦИ.
//!
//! Коначно, овде ћете приметити да се длл за Кс00Кс никада не растерећује, а то је тренутно намерно.
//! Размишља се да га можемо глобално кеширати и користити између позива АПИ-ју, избегавајући скупи Кс00Кс.
//! Ако је ово проблем са детекторима цурења или нечим сличним, можемо прећи мост кад стигнемо тамо.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Радите око Кс00Кс и Кс01Кс који нису присутни у самом винапи-у.
// Иначе се ово користи само када двоструко проверавамо типове против винапија.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Још није дефинисано у винапију
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ово је дефинисано у винапи-ју, али је нетачно (ФИКСМЕ винапи-рс#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Још није дефинисано у винапију
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Овај макро користи се за дефинисање Кс00Кс структуре која интерно садржи све показиваче на функције које бисмо могли учитати.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Учитани ДЛЛ за Кс00Кс
            dll: HMODULE,

            // Сваки показивач функције за сваку функцију коју бисмо могли користити
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // У почетку нисмо учитали ДЛЛ
            dll: 0 as *mut _,
            // Иницијално су све функције постављене на нулу како би се рекло да их треба динамички учитавати.
            //
            $($name: 0,)*
        };

        // Погодност типедеф за сваки тип функције.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Покушаји отварања Кс00Кс.
            /// Враћа успех ако успе или грешка ако Кс00Кс не успе.
            ///
            /// З0Паницс0З ако је библиотека већ учитана.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Функција за сваку методу коју бисмо желели да користимо.
            // Када се позове, или ће прочитати предмеморирани показивач функције или ће га учитати и вратити учитану вриједност.
            // Оптерећења се тврде да успевају.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Погодни прокси за употребу брава за чишћење за упућивање на функције дбгхелп.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Иницијализујте сву подршку неопходну за приступ Кс00Кс АПИ функцијама са овог З0црате0З.
///
///
/// Имајте на уму да је ова функција **сигурна**, интерно има сопствену синхронизацију.
/// Такође имајте на уму да је сигурно позвати ову функцију више пута рекурзивно.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Прва ствар коју треба да урадимо је да синхронизујемо ову функцију.То се може позвати истовремено из других нити или рекурзивно у оквиру једне нити.
        // Имајте на уму да је то ипак замршеније јер оно што овде користимо, Кс00Кс,*такође* мора бити синхронизовано са свим осталим позиваоцима у Кс01Кс у овом процесу.
        //
        // Типично нема толико позива на Кс00Кс у оквиру истог процеса и вероватно можемо сигурно претпоставити да му приступамо само ми.
        // Међутим, постоји још један примарни корисник о којем морамо бринути, што је иронично и сами, али у стандардној библиотеци.
        // З0Руст0З стандардна библиотека зависи од овог З0црате0З за подршку повратног праћења, а ова З0црате0З постоји и на Кс00Кс.
        // То значи да ако се у стандардној библиотеци штампа З0паниц0З бацктраце, може се тркати са овим З0црате0З који долази из Кс00Кс, што узрокује сегфаултс.
        //
        // Да бисмо помогли у решавању овог проблема са синхронизацијом, овде користимо трик специфичан за Виндовс (уосталом, то је Виндовс ограничење у вези са синхронизацијом).
        // Стварамо *локално за сесије* именован мутек да заштитимо овај позив.
        // Намера овде је да стандардна библиотека и овај З0црате0З не морају да деле АПИ-је на нивоу З0Руст0З да би се овде синхронизовали, већ уместо тога могу да раде иза сцене како би били сигурни да се међусобно синхронизују.
        //
        // На тај начин када се ова функција позива преко стандардне библиотеке или путем Кс00Кс, можемо бити сигурни да се исти мутек добија.
        //
        // Дакле, све то значи да прво што овде радимо је да атомски створимо Кс01Кс који је именовани мутек на Кс00Кс.
        // Неколико синхронизујемо са другим нитима које посебно деле ову функцију и осигуравамо да се креира само једна ручица по инстанци ове функције.
        // Имајте на уму да се ручица никада не затвара када се ускладишти у глобалу.
        //
        // Након што заиста закључамо браву, једноставно је набављамо и наша ручица Кс00Кс коју уручимо биће одговорна за њено испуштање на крају.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ок, фуј!Сад кад смо сви безбедно синхронизовани, почнимо заправо све да обрађујемо.
        // Прво морамо осигурати да је Кс00Кс стварно учитан у овом процесу.
        // То радимо динамички да бисмо избегли статичку зависност.
        // Ово је кроз историју било заобиђено чудним проблемима повезивања и има за циљ да бинарне датотеке учини мало преносивијим, јер је ово углавном само услужни програм за отклањање грешака.
        //
        //
        // Након што отворимо Кс00Кс, у њему морамо позвати неке функције иницијализације, а то је детаљније детаљније у наставку.
        // Међутим, ово радимо само једном, па имамо глобално логичко стање које показује да ли смо већ завршили или не.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Обавезно поставите заставицу Кс01Кс, јер према МСВЦ-овим сопственим документима о овоме: Кс00Кс, па хајде да то учинимо!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Заправо иницијализујте симболе МСВЦ-ом.Имајте на уму да ово може пропасти, али ми то занемарујемо.
        // За ово не постоји тона стања технике, али чини се да ЛЛВМ интерно игнорише повратну вредност овде, а једна од дезинфекционих библиотека у ЛЛВМ-у исписује застрашујуће упозорење ако то не успе, али у основи га дугорочно игнорише.
        //
        //
        // Један случај који се пуно појављује за З0Руст0З је да стандардна библиотека и овај З0црате0З на Кс01Кс желе да се такмиче за Кс00Кс.
        // Стандардна библиотека је у прошлости већину времена желела да покрене затим чишћење, али сада када користи овај З0црате0З то значи да ће неко прво доћи до иницијализације, а други ће ту иницијализацију покупити.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}