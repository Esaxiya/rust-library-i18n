#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматор за повратне трагове.
///
/// Овај тип се може користити за испис бацктраце-а без обзира на то одакле потиче бацктраце.
/// Ако имате тип Кс00Кс, његова примена Кс01Кс већ користи овај формат штампања.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Стилови штампе које можемо штампати
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Штампа терсер бацктраце који идеално садржи само релевантне информације
    Short,
    /// Штампа бацктраце који садржи све могуће информације
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Направите нови Кс01Кс који ће уписивати излаз на испоручени Кс00Кс.
    ///
    /// Аргумент Кс00Кс ће контролисати стил у којем се исписује бацктраце, а аргумент Кс01Кс ће се користити за испис примерака датотека Кс02Кс.
    /// Овај тип сам не врши штампање имена датотека, али за то је потребан овај повратни позив.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Штампа преамбулу за бацктраце који ће се штампати.
    ///
    /// Ово је потребно на неким платформама да би се повратни трагови касније у потпуности симболизирали, а иначе би ово требало да буде само прва метода коју позовете након креирања Кс00Кс.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Додаје оквир на излаз за враћање уназад.
    ///
    /// Ово урезивање враћа РАИИ инстанцу Кс00Кс која се може користити за стварно штампање оквира, а након уништавања повећаће бројач оквира.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Завршава излаз повратне спреге.
    ///
    /// Ово тренутно није дозвољено, али је додато због компатибилности З0футуре0З са форматима повратних трагова.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Тренутно се не ради-укључујући овај З0хоок0З како би се омогућиле додавања З0футуре0З.
        Ok(())
    }
}

/// Форматор за само један кадар повратног трага.
///
/// Овај тип креира функција Кс00Кс.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Штампа Кс00Кс помоћу овог обликовача оквира.
    ///
    /// Ово ће рекурзивно одштампати све инстанце Кс01Кс унутар Кс00Кс.
    ///
    /// # Потребне карактеристике
    ///
    /// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Штампа Кс01Кс у оквиру Кс00Кс.
    ///
    /// # Потребне карактеристике
    ///
    /// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ово није сјајно што на крају ништа не штампамо
            // са именима датотека која нису утф8.
            // Срећом скоро све је Кс00Кс, тако да ово не би требало бити превише лоше.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Штампа сироко трасиране Кс01Кс и Кс00Кс, обично из сирових повратних позива овог З0црате0З.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Додаје необрађени оквир на излаз повратне спреге.
    ///
    /// Ова метода, за разлику од претходне, узима необрађене аргументе у случају да су извор са различитих локација.
    /// Имајте на уму да се ово може позивати више пута за један кадар.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Додаје необрађени оквир на излаз повратне спреге, укључујући информације о колонама.
    ///
    /// Ова метода, као и претходна, узима необрађене аргументе у случају да су извор са различитих локација.
    /// Имајте на уму да се ово може позивати више пута за један кадар.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фуксија није у стању да симболизује унутар процеса, тако да има посебан формат који се касније може користити за симболизацију.
        // Одштампајте то уместо да овде штампате адресе у нашем формату.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Нема потребе за штампањем Кс00Кс оквира, то у основи само значи да је системско враћање уназад било мало жељно да се врати веома далеко.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Да бисмо смањили величину ТЦБ-а у Сгк енклави, не желимо да применимо функционалност резолуције симбола.
        // Уместо тога, овде можемо исписати офсет адресе, који би касније могао бити мапиран како би исправио функцију.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Одштампајте индекс оквира као и опционални показивач инструкција оквира.
        // Ако смо изнад првог симбола овог оквира, ми само исписујемо одговарајући размак.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Следеће, напишите име симбола, користећи алтернативно форматирање за више информација ако смо пуни бацктраце.
        // Овде такође рукујемо симболима који немају име,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // И на крају, одштампајте Кс00Кс број ако су доступни.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line се штампају на линијама под именом симбола, па испишите одговарајући размак да бисте се некако поравнали.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Делегирајте у наш интерни повратни позив да бисте одштампали име датотеке, а затим одштампали број линије.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Додајте број колоне, ако је доступан.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Стало нам је само до првог симбола оквира
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}