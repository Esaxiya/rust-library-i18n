// тренутно се користи само на Кс00Кс, па зато допустите мртви код негде другде
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Једноставан алокатор арене за бајт бафере.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Додељује међуспремник одређене величине и враћа му променљиву референцу.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕЗБЕДНОСТ: ово је једина функција која икада прави промењиву
        // референца на Кс00Кс.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕЗБЕДНОСТ: никада не уклањамо елементе са Кс00Кс, па референца
        // подаци унутар било ког бафера ће живети све док Кс00Кс живи.
        &mut buffers[i]
    }
}