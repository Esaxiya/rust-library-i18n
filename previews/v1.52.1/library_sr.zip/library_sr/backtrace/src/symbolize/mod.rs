use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Решите адресу симбола, преносећи симбол на одређено затварање.
///
/// Ова функција ће тражити дату адресу у областима као што су табела локалних симбола, динамичка табела симбола или информације о отклањању грешака ДВАРФ (у зависности од активиране имплементације) како би пронашла симболе који ће дати.
///
///
/// Затварање се не може затражити ако се решавање не може извршити, а такође се може позвати и више пута у случају уграђених функција.
///
/// Дати симболи представљају извршење на наведеном Кс00Кс, враћајући Кс01Кс парове за ту адресу (ако је доступно).
///
/// Имајте на уму да ако имате Кс00Кс, онда се препоручује употреба функције Кс01Кс уместо ове.
///
/// # Потребне карактеристике
///
/// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
///
/// # Panics
///
/// Ова функција тежи никада З0паниц0З, али ако је Кс00Кс обезбедио З0паницс0З, неке платформе ће присилити двоструки З0паниц0З да прекине процес.
/// Неке платформе користе Ц библиотеку која интерно користи повратне позиве који се не могу одмотати, па паника из Кс00Кс може покренути прекид процеса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // погледајте само горњи оквир
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Решите претходно ухваћени оквир у симбол, преносећи симбол у одређено затварање.
///
/// Овај функтин обавља исту функцију као и Кс00Кс, осим што узима Кс01Кс као аргумент уместо адресе.
/// То може да омогући неким имплементацијама повратног праћења да пруже тачније информације о симболима или информације о уграђеним оквирима, на пример.
///
/// Препоручује се да ово користите ако можете.
///
/// # Потребне карактеристике
///
/// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
///
/// # Panics
///
/// Ова функција тежи никада З0паниц0З, али ако је Кс00Кс обезбедио З0паницс0З, неке платформе ће присилити двоструки З0паниц0З да прекине процес.
/// Неке платформе користе Ц библиотеку која интерно користи повратне позиве који се не могу одмотати, па паника из Кс00Кс може покренути прекид процеса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // погледајте само горњи оквир
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ИП вредности из оквира стека су обично Кс00Кс инструкција *након* позива која је стварни траг стека.
// Ако ово симболизујете, Кс00Кс број је један испред и можда у празнину ако је при крају функције.
//
// Чини се да је то у основи увек случај на свим платформама, па увек одузмемо један од разрешеног ип-а да бисмо га решили у претходном упутству за позив, уместо у то да се упутство врати.
//
//
// Идеално би било да ово не радимо.
// Идеално би било да овде захтевамо од позивалаца АПИ-ја Кс00Кс да ручно раде Кс01Кс и рачунају да желе информације о локацији за *претходну* инструкцију, а не за тренутну.
// Идеално би било да изложимо и на Кс00Кс ако смо заиста адреса следеће инструкције или тренутне.
//
// За сада је ово прилично забринутост, па је само интерно увек одузети.
// Потрошачи би требало да наставе да раде и постижу прилично добре резултате, па бисмо требали бити довољно добри.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Исто као и Кс00Кс, само несигурно јер је несинхронизовано.
///
/// Ова функција нема гаранције за синхронизацију, али је доступна када Кс00Кс функција овог З0црате0З није компајлирана.
/// Погледајте функцију Кс00Кс за више документације и примера.
///
/// # Panics
///
/// Погледајте информације о Кс00Кс за упозорења о паничности Кс01Кс.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Исто као и Кс00Кс, само несигурно јер је несинхронизовано.
///
/// Ова функција нема гаранције за синхронизацију, али је доступна када Кс00Кс функција овог З0црате0З није компајлирана.
/// Погледајте функцију Кс00Кс за више документације и примера.
///
/// # Panics
///
/// Погледајте информације о Кс00Кс за упозорења о паничности Кс01Кс.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// З0 Портраит0З представља резолуцију симбола у датотеци.
///
/// Овај З0 Портраит0З се даје као З0 Портраит0З објекат затварању датој функцији Кс00Кс и практично се шаље јер је непознато која имплементација стоји иза њега.
///
///
/// Симбол може да даје контекстуалне информације о функцији, на пример име, име датотеке, број линије, тачну адресу итд.
/// Нису све информације увек доступне у симболу, па сви методи враћају Кс00Кс.
///
///
pub struct Symbol {
    // TODO: ову животну границу треба на крају одржати до Кс00Кс,
    // али то је тренутно преломна промена.
    // За сада је ово сигурно јер се Кс00Кс увек дели само референцом и не може се клонирати.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Враћа име ове функције.
    ///
    /// Враћена структура може се користити за испитивање различитих својстава о имену симбола:
    ///
    ///
    /// * Имплементација Кс00Кс ће исписати демонтирани симбол.
    /// * Може се приступити необрађеној Кс00Кс вредности симбола (ако је важећа Кс01Кс).
    /// * Може се приступити необрађеним бајтовима имена симбола.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Враћа почетну адресу ове функције.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Враћа сирово име датотеке као пресек.
    /// Ово је углавном корисно за Кс00Кс окружења.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Враћа број колоне за место где се овај симбол тренутно извршава.
    ///
    /// Само гимли тренутно пружа вредност овде, чак и тада само ако Кс01Кс врати Кс00Кс, па је према томе подложан сличним упозорењима.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Враћа број реда за место где се овај симбол тренутно извршава.
    ///
    /// Ова повратна вредност је обично Кс01Кс ако Кс02Кс врати Кс00Кс и према томе подлеже сличним упозорењима.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Враћа име датотеке где је дефинисана ова функција.
    ///
    /// Ово је тренутно доступно само када се користи либбацктраце или гимли (нпр
    /// unix платформе остало) и када се бинарни фајл компајлира са дебугинфо.
    /// Ако није испуњен ниједан од ових услова, ово ће вероватно вратити Кс00Кс.
    ///
    /// # Потребне карактеристике
    ///
    /// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Можда рашчлањени симбол Ц ++, ако рашчлањивање изопаченог симбола као З0Руст0З није успело.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Обавезно задржите ову величину нулте величине, тако да функција Кс00Кс нема трошкова када је онемогућена.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Омотач око имена симбола који пружа ергономске приступнике рашчлањеном имену, сировим бајтовима, сировом низу итд.
///
// Дозволи мртви код када функција Кс00Кс није омогућена.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Ствара ново име симбола од сирових основних бајтова.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Враћа сирово име Кс01Кс симбола као Кс02Кс ако је симбол важећи Кс00Кс.
    ///
    /// Користите имплементацију Кс00Кс ако желите демонтирану верзију.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Враћа сирово име симбола као листу бајтова
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ово би се могло исписати ако демонтирани симбол заправо није важећи, зато грациозно рукујте овде грешком не ширећи је према споља.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Покушај повратка те кеширане меморије која се користи за симболизацију адреса.
///
/// Овим методом ће се покушати ослободити све глобалне структуре података које су иначе кеширане глобално или у нити, а које обично представљају рашчлањене информације о ДВАРФ или слично.
///
///
/// # Caveats
///
/// Иако је ова функција увек доступна, она заправо не ради ништа на већини примена.
/// Библиотеке попут дбгхелп или либбацктраце не пружају могућности за уклањање стања и управљање додељеном меморијом.
/// За сада је Кс00Кс карактеристика овог З0црате0З једина карактеристика у којој ова функција има било какав ефекат.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}