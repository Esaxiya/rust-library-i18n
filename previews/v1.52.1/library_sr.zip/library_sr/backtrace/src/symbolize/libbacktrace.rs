//! Стратегија симболизовања помоћу кода за рашчлањивање ДВАРФ-а у либбацктрацеу.
//!
//! Библиотека либбацктраце Ц, која се обично дистрибуира са З0гцц0З, подржава не само генерисање повратног трага (који заправо не користимо), већ и симболизовање повратног трага и руковање информацијама о отклањању грешака патуљака о стварима попут уграђених оквира и слично.
//!
//!
//! Ово је релативно компликовано због пуно разних забринутости овде, али основна идеја је:
//!
//! * Прво зовемо Кс00Кс.Ово добија информације о симболима из динамичке табеле симбола ако можемо.
//! * Следеће зовемо Кс00Кс.Ово ће рашчланити дебугинфо табеле ако су доступне и омогућити нам да опоравимо информације о уграђеним оквирима, именима датотека, бројевима линија итд.
//!
//! Много је трикова око увођења патуљастих столова у либбацктраце, али надамо се да то није крај света и да је довољно јасно када прочитате у наставку.
//!
//! Ово је задата стратегија симболизације за платформе које нису МСВЦ и не-ОСКС.У либстд-у је ово подразумевана стратегија за ОСКС.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ако је могуће, преферирајте име Кс00Кс које долази из дебугинфо-а и обично може бити тачније за на пример уграђене оквире.
                // Ако тога нема, вратите се на име табеле симбола наведено у Кс00Кс.
                //
                // Имајте на уму да се понекад Кс01Кс може осећати нешто мање тачно, на пример да је наведен као Кс02Кс уместо Кс00Кс.
                //
                // Није заиста јасно зашто, али у целини име Кс00Кс делује тачније.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // не радити ништа за сада
}

/// Тип показивача Кс01Кс прешао је у Кс00Кс
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Једном када се овај повратни позив позове из Кс01Кс када започнемо решавање, идемо даље да позовемо Кс00Кс.
    // Функција Кс00Кс ће прегледати информације о отклањању грешака и покушати да изврши неке ствари попут опоравка информација о Кс01Кс, као и уграђених оквира.
    // Ипак, имајте на уму да Кс01Кс може да пропадне или не може много ако нема информација о отклањању грешака, па ако се то догоди, сигурно ћемо позвати повратни позив са најмање једним симболом из Кс00Кс.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Тип показивача Кс01Кс прешао је у Кс00Кс
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// АПИ либбацктраце подржава стварање државе, али не подржава уништавање државе.
// Ја лично схватам да ово значи да је држава намењена стварању, а затим животу заувек.
//
// Волео бих да региструјем Кс00Кс обрађивач који чисти ово стање, али либбацктраце не пружа начин за то.
//
// Уз ова ограничења, ова функција има статички предмеморирано стање које се израчунава први пут када се то затражи.
//
// Запамтите да се повратно праћење свега догађа серијски (једна глобална брава).
//
// Имајте на уму да је овде недостатак синхронизације због захтева да се Кс00Кс синхронизује споља.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не вежбајте безбедне нити могућности либбацктрацеа јер га увек зовемо синхронизовано.
        //
        0,
        error_cb,
        ptr::null_mut(), // без додатних података
    );

    return STATE;

    // Имајте на уму да да би либбацктраце уопште радио, потребно је пронаћи информације о отклањању грешака ДВАРФ-а за тренутну извршну датотеку.Обично то чини путем бројних механизама, укључујући, али не ограничавајући се на:
    //
    // * /proc/self/exe на подржаним платформама
    // * Назив датотеке се експлицитно предаје приликом креирања стања
    //
    // Библиотека либбацктраце је велика гомила Ц кода.То природно значи да има рањивости у вези са меморијом, посебно када се рукује неисправним дебугинфо-ом.
    // Либстд је у прошлости наилазио на пуно тога.
    //
    // Ако се користи Кс00Кс, онда их обично можемо занемарити јер претпостављамо да је либбацктраце Кс01Кс, а иначе не ради чудне ствари са информацијама о отклањању грешака патуљака Кс02Кс.
    //
    //
    // Ако додамо име датотеке, међутим, то је могуће на неким платформама (попут БСД-ова) где злонамерни глумац може проузроковати постављање произвољне датотеке на ту локацију.
    // То значи да ако кажемо либбацктраце о имену датотеке, можда користи произвољну датотеку, што може узроковати сегфаултс.
    // Ако либбацктрацеу ништа не кажемо, онда то неће учинити ништа на платформама које не подржавају путање попут Кс00Кс!
    //
    // С обзиром на све што се трудимо што је више могуће да *не* пренесемо име датотеке, али то морамо на платформама које уопште не подржавају Кс00Кс.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Имајте на уму да бисмо у идеалном случају користили Кс00Кс, али овде не можемо да захтевамо Кс01Кс.
            //
            // Користите Кс00Кс за учитавање тренутне извршне путање у статично подручје (које ако је премало једноставно одустаните).
            //
            //
            // Имајте на уму да овде озбиљно верујемо да либбацктраце неће умрети на оштећеним извршним датотекама, али сигурно јесте ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows има начин отварања датотека где након отварања не може да се избрише.
            // То је генерално оно што овде желимо јер желимо да осигурамо да се наша извршна датотека не мења испод нас након што је предамо на либбацктраце, надам се да ублажавамо могућност преношења произвољних података у либбацктраце (што може бити погрешно обрађено).
            //
            //
            // С обзиром на то да овде мало играмо како бисмо покушали да постигнемо неку врсту закључавања сопствене слике:
            //
            // * Упознајте се са тренутним процесом, учитајте његово име датотеке.
            // * Отворите датотеку у то име датотеке са одговарајућим заставицама.
            // * Поново учитајте име датотеке тренутног процеса, водећи рачуна да је исто
            //
            // Ако је то све прошло, ми смо у теорији заиста отворили датотеку нашег процеса и гарантујемо да се то неће променити.ФВИВ гомила овога је историјски копирана из либстд-а, тако да је ово моје најбоље тумачење онога што се догађало.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ово живи у статичкој меморији да бисмо га могли вратити ..
                static mut BUF: [i8; N] = [0; N];
                // ... и ово живи на гомили јер је привремено
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // овде намерно процури Кс00Кс, јер би његово отварање требало да сачува закључавање овог имена датотеке.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Желимо да вратимо пресек који је нул-завршен, па ако је све попуњено и једнако је укупној дужини, изједначите то са неуспехом.
                //
                //
                // У супротном, приликом враћања успеха побрините се да је нул бајт укључен у пресек.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // грешке повратног трага су тренутно пометене под тепих
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Позовите Кс00Кс АПИ који (након читања кода) треба да позове Кс01Кс тачно једном (или не успе са вероватно грешком).
    // Тада више радимо у оквиру Кс00Кс.
    //
    // Имајте на уму да ово радимо јер ће Кс00Кс консултовати табелу симбола, проналазећи имена симбола чак и ако у бинарном систему нема информација о отклањању грешака.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}