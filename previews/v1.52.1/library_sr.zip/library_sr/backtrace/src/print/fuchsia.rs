use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // дл_итерате_пхдр узима повратни позив који ће добити дл_пхдр_инфо показивач за сваки ОДС који је повезан у процес.
    // дл_итерате_пхдр такође осигурава да је динамички повезивач закључан од почетка до краја итерације.
    // Ако повратни позив врати вредност која није нула, итерација се прекида.
    // 'data' биће прослеђен као трећи аргумент повратном позиву за сваки позив.
    // 'size' даје величину дл_пхдр_инфо.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Морамо рашчланити ИД градње и неке основне податке заглавља програма, што значи да нам треба и мало ствари из ЕЛФ спецификација.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Сада морамо реплицирати, бит за бит, структуру типа дл_пхдр_инфо коју користи тренутни динамички линкер фуцхсиа.
// Цхромиум такође има ову АБИ границу, као и пад пад.
// Евентуално бисмо желели да ове случајеве преместимо на елф претрагу, али то бисмо морали да обезбедимо у СДК-у, а то још увек није учињено.
//
// Стога смо (и они) заглавили да морамо да користимо ову методу која доводи до чврстог спајања са фуцхсиа либц.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Не можемо никако да сазнамо да ли је е_пхофф и е_пхнум валидни.
    // либц би то требало да нам осигура, али зато је сигурно овде формирати део.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Елф_Пхдр представља 64-битно ЕЛФ заглавље програма у крајности циљне архитектуре.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Пхдр представља важеће заглавље ЕЛФ програма и његов садржај.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Не можемо да проверимо да ли су п_аддр или п_мемсз валидни.
    // Фуцхсиа-ин либц прво рашчлањује напомене, међутим зато што су овде ова заглавља морају бити важећа.
    //
    // НотеИтер не захтева да основни подаци буду ваљани, али захтева да границе буду важеће.
    // Верујемо да је либц осигурао да је то случај са нама овде.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Тип белешке за ИД-ове градње.
const NT_GNU_BUILD_ID: u32 = 3;

// Елф_Нхдр представља заглавље ЕЛФ белешке у крајњем циљу.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Белешка представља ЕЛФ белешку (заглавље + садржај).
// Име је остављено као Кс00Кс кришка, јер није увек нулто прекинуто, а З0руст0З чини довољно једноставним да се провери да ли се бајтови у сваком случају подударају.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// НотеИтер вам омогућава да сигурно прелазите преко сегмента белешке.
// Прекида се чим дође до грешке или ако више нема белешки.
// Ако пређете преко неважећих података, функционисаће као да нису пронађене белешке.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Инваријант је функције да задати показивач и величина означавају важећи опсег бајтова који се сви могу прочитати.
    // Садржај ових бајтова може бити било који, али опсег мора бити важећи да би ово било сигурно.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// алигн_то поравнава Кс00Кс са поравнањем бајтова под претпоставком да је Кс01Кс снаге 2.
// Ово следи стандардни образац у Ц/Ц ++ ЕЛФ коду за рашчлањивање где се користи (к + до, 1)&Кс00Кс.
// З0Руст0З вам не дозвољава да негирате усизе па га користим
// Конверзија 2-комплемента да бисте то поново створили.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// таке_битес_алигн4 троши број бајтова из пресека (ако је присутан) и додатно осигурава да је коначни пресек правилно поравнан.
// Ако је број захтеваних бајтова превелик или пресек не може накнадно да се поравна због недовољног броја преосталих бајтова, враћа се Ниједан и пресек се не мења.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ова функција нема стварне инваријанте које позивалац мора подржати, осим да можда Кс00Кс треба поравнати ради перформанси (и на неким тачностима архитектуре).
// Вредности у пољима Елф_Нхдр могу бити бесмислице, али ова функција не осигурава тако нешто.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ово је сигурно док има довољно простора, а ми смо то управо потврдили у горенаведеној изјави, тако да ово не би требало бити несигурно.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Имајте на уму да сице_оф: :<Elf_Nhdr>() је увек поравнато са 4 бајта.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Провери да ли смо стигли до краја.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Трансмутирамо нхдр, али пажљиво разматрамо резултујућу структуру.
        // Не верујемо намесз или десцсз и не доносимо небезбедне одлуке на основу типа.
        //
        // Дакле, чак и ако избацимо комплетно смеће, и даље бисмо требали бити на сигурном.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Означава да је сегмент извршни.
const PERM_X: u32 = 0b00000001;
/// Означава да је у сегменту могуће писати.
const PERM_W: u32 = 0b00000010;
/// Означава да је сегмент читљив.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Представља ЕЛФ сегмент током извођења.
struct Segment {
    /// Даје виртуелну адресу извођења садржаја овог сегмента.
    addr: usize,
    /// Даје величину меморије садржаја овог сегмента.
    size: usize,
    /// Даје модулу виртуелну адресу овог сегмента са ЕЛФ датотеком.
    mod_rel_addr: usize,
    /// Даје дозволе пронађене у ЕЛФ датотеци.
    /// Међутим, ове дозволе нису нужно дозволе присутне током извођења.
    flags: Perm,
}

/// Омогућава итерацију сегмената од ОДС-а.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Представља ЕЛФ ДСО (динамички дељени објекат).
/// Овај тип се позива на податке ускладиштене у стварном ОДС-у, уместо да прави своју копију.
struct Dso<'a> {
    /// Динамички повезивач увек нам даје име, чак и ако је име празно.
    /// У случају главне извршне датотеке ово име ће бити празно.
    /// У случају дељеног објекта то ће бити сонаме (погледајте ДТ_СОНАМЕ).
    name: &'a str,
    /// На Фуцхсиа-и практично сви бинарни програми имају ИД-ове за изградњу, али ово није строг захтев.
    /// Не постоји начин да се ДСО информације повежу са правом ЕЛФ датотеком након тога ако нема буилд_ид, па захтевамо да га сваки ДСО овде има.
    ///
    /// ОДС без буилд_ид се игноришу.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Враћа итератор над сегментима у овом ОДС-у.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Те грешке кодирају проблеме који настају приликом рашчлањивања информација о сваком ОДС-у.
///
enum Error {
    /// НамеЕррор значи да је дошло до грешке приликом претварања низа стила Ц у З0руст0З низ.
    ///
    NameError(core::str::Utf8Error),
    /// БуилдИДЕррор значи да нисмо пронашли ИД градње.
    /// То може бити због тога што ОДС није имао ИД верзије или зато што је сегмент који садржи ИД верзије погрешно обликован.
    ///
    BuildIDError,
}

/// Позива Кс00Кс или Кс01Кс за сваки ОДС повезан у процес динамичким везником.
///
///
/// # Arguments
///
/// * `visitor` - ДсоПринтер који ће имати једну од метода која се зове фореацх ДСО.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // дл_итерате_пхдр осигурава да Кс00Кс показује на исправну локацију.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ова функција исписује ознаку Фуцхсиа симболизатора за све информације садржане у ОДС-у.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}