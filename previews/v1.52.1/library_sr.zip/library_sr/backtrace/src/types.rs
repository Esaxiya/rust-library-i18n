//! Типови зависни од платформе.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Приказивање низа од платформе.
/// Када радите са омогућеним Кс00Кс, препоручују се погодни методи за омогућавање конверзија у типове Кс01Кс.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Парче, обично доступно на Кс00Кс платформама.
    Bytes(&'a [u8]),
    /// Широке жице обично од Кс00Кс.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Губитак претвара у Кс01Кс, доделиће ако Кс02Кс није важећи Кс03Кс или ако је Кс04Кс Кс00Кс.
    ///
    /// # Потребне карактеристике
    ///
    /// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Пружа Кс01Кс приказ Кс00Кс.
    ///
    /// # Потребне карактеристике
    ///
    /// За ову функцију је потребна функција Кс00Кс Кс01Кс З0црате0З, а функција Кс02Кс је подразумевано омогућена.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}