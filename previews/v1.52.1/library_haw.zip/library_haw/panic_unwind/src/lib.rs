//! Ka hoʻokō ʻana o panics ma o ka wehe ʻana i ka puʻu
//!
//! ʻO kēia crate kahi hoʻokō o panics ma Rust me ka hoʻohana ʻana i ka "most native" stacking mechanical o ka paepae e hōʻiliʻili ʻia nei.
//! Hoʻokaʻawale ʻia kēia i ʻekolu mau bākeke i kēia manawa:
//!
//! 1. Hoʻohana nā pahuhopu MSVC iā SEH i ka faila `seh.rs`.
//! 2. Emscripten hoʻohana C++ , koe ma ka `emcc.rs` waihona.
//! 3. Hoʻohana nā pahuhopu ʻē aʻe iā libunwind/libgcc i ka faila `gcc.rs`.
//!
//! More nā moʻolelo e pili ana i kēlā me kēia manaʻo hiki ke loaʻa i loko o ka lakou mau Module.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` hoʻohana ʻole ʻia me Miri, no laila nā ʻōlelo aʻoaʻo hāmau.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Pili nā mea hoʻomaka o Rust runtime i kēia mau hōʻailona, no laila e hoʻolaha lākou.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Pahuhopu i kākoʻo ʻole i ka wehe ʻana.
        // - arch=wasm32
        // - os=ʻaʻole ("bare metal" mau pahuhopu)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // E hoʻohana i ka holo ʻana o Miri.
        // Mākou nō Pono e kekahi kiʻi i ka maʻamau runtime luna, e like me rustc Ua manao kekahi lang ikamu mai laila aku a hiki i ke ho'ākāka 'ia.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // E hoʻohana i ka holo maoli.
        use real_imp as imp;
    }
}

extern "C" {
    /// kapa Handler ma libstd ka wā o ka panic mea ua hoʻokuʻu waho o `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Kāhea ʻia ʻo Handler ma libstd ke loaʻa kahi haole ʻē.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Komo aku ai i wahi no ka hoala ana i koe, eʻelele a hiki i ka anuu-i ho'ākāka 'manaʻo.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}