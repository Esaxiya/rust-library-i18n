//! Windows SEH
//!
//! Ma Windows (ma MSVC wale nō i kēia manawa), ʻo ka hana lawelawe ʻana i ka hoʻokoe ʻole maʻamau ʻo Structured Exception Handling (SEH).
//! He ʻokoʻa ʻokoʻa kēia ma mua o ka lawelawe ʻana o ka hoʻokoe Dwarf (e laʻa, ka mea a nā unix pae ʻē aʻe e hoʻohana ai) e pili ana i nā mea hoʻopili kūloko, no laila e pono iā LLVM e loaʻa i kahi kākoʻo maikaʻi hou no SEH.
//!
//! I kahi pōkole, he aha ka hana ma aneʻi:
//!
//! 1. Ka papa `panic` kahea i ka hae Windows kuleana pili i `_CxxThrowException` e hoolei i ka C++ -e like koe nae, triggering ka unwinding kaʻina.
//! 2.
//! Hoʻohana nā pads landing a pau i hoʻokumu ʻia e ka mea hoʻopili i ka hana pilikino `__CxxFrameHandler3`, kahi hana i ka CRT, a me ka helu ʻole i ka Windows e hoʻohana i kēia hana pilikino e hoʻokō i nā code hoʻomaʻemaʻe āpau ma ka stack.
//!
//! 3. Loaʻa i nā kāhea hoʻopili a pau i `invoke` i kahi papa pae i hoʻonohonoho ʻia ma ke ʻano he `cleanuppad` LLVM kuhikuhi, e hōʻike ana i ka hoʻomaka o ka hoʻomaʻemaʻe maʻamau.
//! ʻO ke kanaka (i ka ʻanuʻu 2, wehewehe ʻia i ka CRT) kuleana no ka holo ʻana i nā kaʻina hoʻomaʻemaʻe.
//! 4. Ma ka hopena ua hoʻokō ʻia ka "catch" code ma ka `try` intrinsic (i hoʻokumu ʻia e ka mea hoʻopili) a hōʻike i ka hoʻi ʻana o ka mana i Rust.
//! Hana ʻia kēia ma o `catchswitch` a me kahi aʻo `catchpad` i nā huaʻōlelo LLVM IR, ke hoʻi nei i ka kaomi maʻamau i ka papahana me kahi aʻo `catchret`.
//!
//! Kekahi hana i ho'ākāka 'oko mai o ka gcc-ka nānā' ana, koe i ka hoʻohanaʻana i:
//!
//! * ʻAʻohe o Rust hana pilikino pilikino, ma kahi o * `__CxxFrameHandler3` mau.Hoʻohui ʻia, ʻaʻole hana ʻia kahi kānana keu, no laila ke hopu nei mākou i nā ʻokoʻa C++ e kū like me kahi ʻano a mākou e hoʻolei nei.
//! Note e hoolei i koe i loko o Rust mea undefined hana Hehe, no laila, i kēia e e uku.
//! * Loaʻa iā mākou kahi ʻikepili e hoʻoili ma o ka palena wili ʻole, kahi `Box<dyn Any + Send>` kikoʻī.Like me ka Dwarf 'ia kēia mau mea kuhikuhi mau i waiho waho me ka payload i loko o ke koe wale.
//! Ma MSVC, eia nō naʻe, ʻaʻole pono ka hoʻokaʻawale puʻupuʻu keu no ka mālama ʻia ʻana o ka piʻo kāhea i ka wā e hoʻokō ʻia ai nā hana kānana.
//! Keia mea i ka mea, ua hele pololei na mea kuhikuhi i `_CxxThrowException` i i laila, loaʻa hou i loko o ka papa Kānana e e palapala i ka noae ponoi o ka `try` kūʻiʻoo.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Pono kēia e lilo i Option no ka mea hopu mākou i ka ʻokoʻa ma ke kūmole a hoʻokō ʻia kāna mea hoʻopau e ka C++ runtime.
    // A hiki mākou i lawe i ka Box mai o ke koe, ua pono, e haʻalele i ke koe i loko o ka henua pololei moku'āina no kona destructor e holo me ka papalua-hooki i ka Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ʻO ka mua, he hui holoʻokoʻa o nā wehewehe ʻano.Aia kekahi mau ʻano ʻokoʻa kikoʻī ma aneʻi, a he nui i kope kope kope wale ʻia mai LLVM.ʻO ke kumu o kēia mau mea āpau e hoʻokō i ka hana `panic` ma lalo nei ma o ke kāhea ʻana iā `_CxxThrowException`.
//
// Lawe kēia hana i nā paio ʻelua.I ka mua o ka laʻau kuhikuhi i nā ikepili mākou huli hele ana i loko, a ma keia hihia o mākou trait mea.Maʻalahi maʻalahi e loaʻa!ʻO ka mea aʻe, ʻoi aku ka paʻakikī.
// He kuhikuhi kēia i kahi hanana `_ThrowInfo`, a makemake wale ʻia e wehewehe i ka ʻokoʻa i hoʻolei ʻia.
//
// I kēia manawa he huluhulu iki ka wehewehe ʻana o kēia ʻano [1], a ʻo ka ʻano ʻē (a ʻokoʻa ka ʻatikala pūnaewele) ma 32-bit nā kuhi kiko kuhi akā ma 64-bit ua kuhikuhi ʻia nā kuhi lima ma ke ʻano he 32-bit offset mai ka `__ImageBase` hōʻailona.
//
// Hoʻohana ʻia ka `ptr_t` a me ka `ptr!` macro i nā modula ma lalo e hōʻike i kēia.
//
// ʻO ka maze o nā wehewehe ʻano e pili pono ana i ka LLVM e hoʻopuka ai no kēia ʻano hana.ʻO kahi laʻana, inā ʻoe e hōʻuluʻulu i kēia code C++ ma MSVC a hoʻokuʻu i ka LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic,
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      hakahaka foo() { rust_panic a = {0, 1};
//          hoʻolei a;}
//
// O ia ka leoʻano nui mea mākou āu e makemake ana i ka holoʻokoʻaai.ʻO ka hapa nui o nā waiwai mau ma lalo wale nō i kope wale ʻia mai LLVM,
//
// Ma kekahi hihia, i kēia mau hale a i mea a pau kūkulu i loko o ka like ano, a me ka mea, ke pono iki verbose no mākou.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// E hoʻomaopopo ʻaʻole mākou i nānā i nā kānāwai mangling inoa ma aneʻi: ʻaʻole makemake mākou e hiki i C++ ke kiʻi iā Rust panics ma o ka haʻi maʻalahi ʻana i `struct rust_panic`.
//
//
// Ke hoʻololi nei, e hōʻoia i ke kaulike o ke ʻano inoa i ka mea i hoʻohana ʻia ma `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ʻO ke alakaʻi `\x01` byte ma aneʻi he hōʻailona hoʻokalakupua iā LLVM e *ʻole* hoʻopili i kekahi mangling ʻē aʻe e like me ka pīpī ʻana me kahi ʻano `_`.
    //
    //
    // ʻO kēia hōʻailona ka vtable i hoʻohana ʻia e C++ 's `std::type_info`.
    // Mea o keʻano `std::type_info`, 'ano descriptors, i ka laʻau kuhikuhi a hiki i keia papaʻaina.
    // Kuhi ʻia nā ʻano weheweheʻano e nā hanana C++ EH i wehewehe ʻia ma luna a kūkulu mākou ma lalo.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Hoʻohana wale ʻia kēia ʻano wehewehe ma ke kīloi ʻana i kahi ʻokoʻa.
// Ka hoopahele ae la i ke kuleana o ua lawelawe ma ka hoao ana o kūʻiʻoo, i paha ke kona iho TypeDescriptor.
//
// Maikaʻi kēia mai ka hoʻohana ʻana o ka manawa MSVC i ka hoʻohālikelike ʻana i ke kaula ma ka inoa ʻano e kūlike i TypeDescriptors ma mua o ka like o ka pointer.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Hoʻohana ʻia ka mea hoʻopau inā hoʻoholo ka code C++ e hopu i ka mea ʻokoʻa a hoʻokuʻu iā ia me ka ʻole e hoʻolaha.
// E hoʻonoho ka ʻāpana o ka intrinsic hoʻāʻo i ka huaʻōlelo mua o ka mea ʻokoʻa i 0 i haʻalele ʻia e ka mea hōʻino.
//
// Note i x86 Windows hoʻohana i ka "thiscall" Hea Kuikahi no C++ lālā oihana kahi o ka paʻamau "C" kahea Kuikahi.
//
// Ke exception_copy kuleana pili i ka he iki kūikawāʻaneʻi: ka mea, maluna o lakou ma ka MSVC runtime ma lalo o ka try/catch aeie a me ka panic ia mākou paha iʻaneʻi, e hoʻohana 'e like me ka hopena o ke koe kope.
//
// Hoʻohana ʻia kēia e ka C++ runtime e kākoʻo i ke kiʻi ʻana i nā hoʻokoe me std::exception_ptr, ka mea hiki ʻole iā mākou ke kākoʻo no ka pahu<dyn Any>ʻaʻohe clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // Hoʻokō holoʻokoʻa ʻo_CxxThrowException ma kēia kiʻina paʻa, no laila ʻaʻole pono e hoʻololi i ka `data` i ka puʻu.
    // Hoʻoholo wale mākou i kahi kuhikuhi kuhi i kēia hana.
    //
    // Pono ka ManwalDrop ma aneʻi no ka mea ʻaʻole mākou makemake e hāʻule ʻo Exception i ka wā e hemo ʻole ai.
    // Ma kahi o ka mea e hoʻokau ʻia e exception_cleanup i kāhea ʻia e ka C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Kēia ... i mea kahaha ko oukou naau, a me justifiably pela.Ma ka 32-bit MSVC wale nō nā kuhi ma waena o kēia ʻano.
    // Ma 64-iki MSVC, nae, o ka mea kuhikuhi ma waena o nā hale e makemake ana ia mea i olelo ia e like me ka 32-iki offsets mai `__ImageBase`.
    //
    // No laila, ma ka 32-bit MSVC hiki iā mākou ke haʻi i kēia mau kuhikuhi āpau i nā "static`s ma luna.
    // Ma ka 64-bit MSVC, pono mākou e hōʻike i ka unuhi ʻana o nā kuhikuhi ma nā statics, ka mea a Rust i ʻae ʻole ai i kēia manawa, no laila ʻaʻole hiki iā mākou ke hana maoli.
    //
    // ʻO ka mea maikaʻi aʻe aʻe, a laila e hoʻopihapiha i kēia mau hale i ka manawa holo (ʻo ka panicking ka "slow path" nō).
    // No laila, 'aneʻi mākou reinterpret a pau o kēia mau laʻau kuhikuhi nā mahinaʻai me 32-iki integers, a laila hoahu i ka pili waiwai i loko o ka mea (atomically, like concurrent panics i e hanaia).
    //
    // Technically ka runtime e paha ke hana i kekahi nonatomic heluhelu iho o kēia mau mahinaʻai, akā, ma ka kumumanaʻo o ka mea, aole loa e heluhelu i ka *hewa* waiwai ai ka mea e ole e 'ino ...
    //
    // Ma kekahi hihia, ua holo nōhie pono e hana i kekahi mea e like keia a mākou hiki ka hoike hou ana ma statics (a, aole loa mākou e e hiki ia).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // ʻO kahi uku NULL ma aneʻi i loaʻa iā mākou mai ka hopu (...) o __rust_try.
    // Hana ʻia kēia ke hopu ʻia kahi haole kū ʻole Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Koi ʻia kēia mea e ka mea hōʻuluʻulu e ola (e laʻa, he mea lang ia), akā ʻaʻole ia i kāhea ʻia e ka mea hoʻopili no ka mea ʻo __C_specific_handler a i ʻole_except_handler3 ka hana pilikino e hoʻohana mau ʻia.
//
// Nolaila keia mea like he aborting Papa.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}