//! Unwinding for *emscripten* pahu hopu.
//!
//! 'Oiai, Rust ka mau unwinding manaʻo no Unix ʻawa a kāhea aku a ke i loko o ka libunwind APIs' ana, ma Emscripten mākou kahi i kapa aku ai i loko o ka C++ unwinding APIs.
//! He kūpono wale nō kēia mai ka holo mau ʻana o Emscripten i mau API mau a ʻaʻole hoʻokō i ka libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Kūlike kēia i ka hoʻolālā o std::type_info ma C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // ʻO ke alakaʻi `\x01` byte ma aneʻi he hōʻailona hoʻokalakupua iā LLVM e *ʻole* hoʻopili i kekahi mangling ʻē aʻe e like me ka pīpī ʻana me kahi ʻano `_`.
    //
    //
    // ʻO kēia hōʻailona ka vtable i hoʻohana ʻia e C++ 's `std::type_info`.
    // Mea o keʻano `std::type_info`, 'ano descriptors, i ka laʻau kuhikuhi a hiki i keia papaʻaina.
    // Kuhi ʻia nā ʻano weheweheʻano e nā hanana C++ EH i wehewehe ʻia ma luna a kūkulu mākou ma lalo.
    //
    // Note i ka mea maoli nui ka nui ma mua o 3 usize, akā, ua pono wale mākou vtable i ka wahi i ke kolu o ka hehee ai.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info no ka papa kalehu_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // E hoʻohana maʻamau iā .as_ptr().add(2) akā ʻaʻole holo pono kēia i kahi pōʻaiapili.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Kēia intentionally 'aʻole e hoʻohana i ka maʻamau inoa haehaeia noaia no ka mea, aole makou e ole makemake C++ e e hiki i ka paka a hoopahele ae la i Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Pono kēia no ka mea hiki i ka C++ code ke hopu i kā mākou execption me std::exception_ptr a hoʻihoʻi iā ia i nā manawa he nui, malia paha i kahi pae ʻē aʻe.
    //
    //
    caught: AtomicBool,

    // Pono kēia e lilo i Option no ka mea ke ola nei ka mea ma hope o C++ semantics: ke kiʻi ʻo catch_unwind i ka pahu mai kahi ʻē aʻe pono ia e waiho i ka mea kūʻokoʻa i kahi kūlana kūpono no ka mea e kāhea ʻia ana kāna mea hōʻino e __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try hāʻawi maoli iā mākou i kahi kuhikuhi i kēia ʻano.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // No ka cleanup() ua i 'ae' ia panic, mākou wale'ō'ū hakahaka.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}