//! Ka hoʻokō ʻana o panics i kākoʻo ʻia e libgcc/libunwind (i kekahi ʻano).
//!
//! No ke kāʻei kua ma ka lawelawe ʻana i ka hoʻokoe a hoʻoneʻe i ka wehe ʻana e ʻike iā "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) a me nā palapala e pili ana iā ia.
//! Heluhelu maikaʻi ʻia hoʻi kēia:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## He hōʻuluʻulu manaʻo pōkole
//!
//! Hana ʻokoʻa i ka lawelawe ʻana i kahi ʻelua mau ʻāpana: kahi ʻimi huli a me kahi pae hoʻomaʻemaʻe.
//!
//! Ma nā ʻaoʻao ʻelua e hele ka unwinder i nā mōlina stack mai luna a i lalo e hoʻohana ana i ka ʻike mai ka puʻupuʻu puʻupuʻu e hoʻokaʻawale i nā ʻāpana o nā kaʻina hana o kēia manawa ("module" ma aneʻi e pili ana i kahi module OS, ʻo ia hoʻi, kahi waihona a i ʻole kahi waihona waihona hōʻeuʻeu).
//!
//!
//! No kēlā me kēia puʻupuʻu puʻupuʻu, kāhea ia i ka "personality routine" e pili pū ana, nona kahi e waiho ai i ka ʻaoʻao ʻike unwind.
//!
//! I ka pae hulina, ʻo ka hana o kahi hana pilikino e nānā i nā mea ʻē aʻe e kiola ʻia ana, a e hoʻoholo inā e hopu ʻia ia i kēlā papa paʻa.Ke ʻike ʻia ka pae lima, hoʻomaka ka wā hoʻomaʻemaʻe.
//!
//! I ka wā hoʻomaʻemaʻe, kāhea hou ka mea pale i kēlā me kēia ʻano hana pilikino.
//! Hoʻoholo kēia manawa hoʻoholo i ka (inā loaʻa) kahi code hoʻomaʻemaʻe e pono ai e holo no ke kiʻina paʻa o kēia manawa.Inā pēlā, hoʻoili ʻia ka kāohi i kahi branch kūikawā i ke kino hana, ka "landing pad", e kāhea ana i nā mea hōʻino, hoʻokuʻu i ka hoʻomanaʻo, a pēlā aku.
//! I ka hopena o ka pae pae, hoʻoneʻe ʻia ka mālama i ka hoʻomaka hou ʻole a me ka hoʻomaha ʻole.
//!
//! I ka manawa e hemo ʻole ai ka stack i lalo i ka pae paʻa lima, e hoʻomaha ana i nā kū a me ka hana hope loa e hoʻololi i ka kaohi i ka poloka hopu.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Hoʻomaopopo papa ʻokoʻa o Rust.
// Hoʻohana ʻia kēia e nā hana pilikino e hoʻoholo inā i kiola ʻia ka ʻokoʻa e kā lākou holo ponoʻī.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-mea kūʻai aku, ʻōlelo
    0x4d4f5a_00_52555354
}

// E hoʻokāinoa ids i kaʻikaʻiʻia mai LLVM ka TargetLowering::getExceptionPointerRegister() a me TargetLowering::getExceptionSelectorRegister() no kēlā me kēia kuhikuhipuʻuone, laila, kaha palapala i DWARF? Aaeno nui Via? Aaeno? Wehewehena papa (nō kāu<arch>AaenoInfo.td, e ʻimi no "DwarfRegNum").
//
// E nānā pū http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Hoʻokumu ʻia ka helu aʻe ma muli o kā GCC C a me C++ ʻano maʻamau.No ke kuhikuhi, e nānā:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM ʻO ka papa hana pilikino EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS hoʻohana i ka hana maʻamau ma kahi o ka hoʻohana ʻana iā SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // E kāhea nā Backtraces ma ARM i ka papa hana pilikino me ka mokuʻāina==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // I kēlā mau hihia makemake mākou e hoʻomau i ka wehe ʻana i ka stack, i ʻole e pau kā mākou backtraces ma __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Kuhi ka DWARF unwinder i ka_Unwind_Context paʻa i nā mea e like me ka hana a me nā kuhi LSDA, akā hoʻokomo ʻo ARM EHABI iā lākou i kahi mea ʻokoʻa.
            // E malama i na inoa o ka oihana e like _Unwind_GetLanguageSpecificData(), i lawe wale i ka pōʻaiapili laʻau kuhikuhi, GCC kanaka kūmau ma Makuahine i ka laʻau kuhikuhi e exception_object ma ka pōʻaiapili, hoʻohana 'wahi hoahu iho la no ka lima o ka "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... ʻO kahi ala i alakaʻi ʻia e hāʻawi i ka wehewehe piha o ka ARM's_Unwind_Context i kā mākou libunwind bindings a kiʻi i ka ʻikepili i koi ʻia mai laila pololei, e kāpae ana i nā hana hoʻohālikelike DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI pono ke kanaka oaeouee? E update i ka SP cia i loko o ka'ākeʻakeʻa mai ahu hoʻokoe o ke koe mea.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Ma lima EHABI ka ke kanaka me oaeouee mea kuleana no maoli unwinding i hookahi noae kapiliia ma mua hoi mai (lima EHABI pauku.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // ho'ākāka 'ia ma libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Default kanaka e oaeouee, a ua hoʻohana 'ia' ana ma luna o ka hapanui pale, a kahiko o ka'āina ma Windows x86_64 Via SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Ma x86_64 MinGW pale kaua, i ka unwindingʻano papa hana o SEH nō naʻe ka unwind handlerʻikepili (aka LSDA) hoʻohana GCC-hana maʻalahi hoʻopā'ālua.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ʻO ka papa hana pilikino no ka hapa nui o kā mākou pahuhopu.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Ke hoʻi aae? Puan 1ʻai hala ka hea ke aʻo, a hiki ia i loko o ka hope IP huahelu ma LSDA huahelu papa.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Mōlina i unwind ikepili kemu kakau ana
//
// Loaʻa i nā kiʻi o kēlā me kēia kiʻi i kahi ʻāpana e hōʻoki i ka ʻikepili ʻike (maʻamau ".eh_frame").Ke loaded/unloaded kahi module i ke kaʻina hana, pono e hoʻomaopopo ʻia ka mea pale e pili ana i kahi o kēia ʻāpana i ka hoʻomanaʻo.Hoʻololi nā ʻano hana e loaʻa ai i kēlā me kēia ʻokoʻa e ka pae.
// Ma kekahi (e laʻa, Linux), hiki i ka mea hoʻokaʻawale ke ʻike i nā ʻāpana o nā ʻikepili i loko o kāna iho (e ka helu nui ʻana i nā modula i hoʻoili ʻia i kēia manawa ma o ka dl_iterate_phdr() API and finding their ".eh_frame" sections); ʻO nā mea ʻē aʻe, e like me Windows, koi i nā modula e hoʻopaʻa inoa i kā lākou ʻāpana ʻikepili ma o ka unwinder API
//
//
// Hōʻike kēia module i nā hōʻailona ʻelua i kuhikuhi ʻia a kāhea ʻia mai rsbegin.rs e hoʻopaʻa inoa i kā mākou ʻike me ka GCC runtime.
// Hoʻolilo ʻia ka hoʻokō ʻana o ka stack stacking (no kēia manawa) i libgcc_eh, eia nō naʻe Rust crates e hoʻohana i kēia mau kiko komo kikoʻī Rust e hōʻalo i nā hakakā kūpono me kekahi GCC manawa holo.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}