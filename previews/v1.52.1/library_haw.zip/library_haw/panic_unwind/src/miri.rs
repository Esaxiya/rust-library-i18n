//! Unwinding panics no Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ke ʻano o ka ukana a ka ʻenekini Miri e hoʻolaha ai ma o ka hemo ʻole ʻana iā mākou.
// Pono e helu-nui.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Hāʻawi ʻo Miri i kahi hana waho e hoʻomaka i ka haʻalele ʻana.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ʻO ka ukana a mākou e hāʻawi ai iā `miri_start_panic` e kūlike ia me ka paio a mākou e loaʻa ai i `cleanup` ma lalo.
    // No laila pahu wale mākou i hoʻokahi manawa, e kiʻi i kahi mea kuhikuhi-nui.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // E hoʻihoʻi i ka `Box` kumu.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}