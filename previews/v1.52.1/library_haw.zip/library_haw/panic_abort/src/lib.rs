//! Manaʻo o Rust panics Via kaʻina'ō'ū
//!
//! I ka hoʻohālike au i ka manaʻo Via unwinding, keia crate o *nui* simpler!ʻO ka ʻōlelo ʻia, ʻaʻole ia he mea maʻalahi loa, akā eia ke hele nei.
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ka ukana a shim i ka pili kūpono ma ka paepae i nīnau ʻia.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // kāhea iā std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ma Windows, e hoʻohana i ka hana __fastfail kikoʻī kikoʻī.Ma Windows 8 a ma hope, e hoʻopau koke kēia i ke kaʻina hana me ka holo ʻole ʻana o nā mea lawelawe ʻokoʻa i ka hana.
            // I nā mana ma mua o Windows, e mālama ʻia kēia kaʻina o nā ʻōlelo aʻoaʻo ma ke ʻano he ʻaihue komo, e hoʻopau ana i ke kaʻina hana akā me ka ʻole e kāpae i nā mea lawelawe ʻokoʻa.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ʻo kēia ka hoʻohana like e like me ka libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// ʻO kēia ... kahi ʻano ʻano ʻē.ʻO ka tl; dr;koi ʻia kēia e hoʻopili pono, ʻo ka wehewehe lōʻihi ma lalo.
//
// I kēia manawa nā binaries o libcore/libstd a mākou moku e hōʻuluʻulu ʻia me `-C panic=unwind`.Hana ʻia kēia e hōʻoia i ka hoʻopili pono ʻana o nā binaries me nā hanana i hiki.
// Eia naʻe, koi ka mea hoʻopili i kahi "personality function" no nā hana āpau i hōʻuluʻulu ʻia me `-C panic=unwind`.Kēia kanaka kuleana pili i ua hardcoded i ka hōʻailona `rust_eh_personality`, a ua ho'ākāka 'ia ma ka `eh_personality` lang'ikamu.
//
// So...
// no ke aha e wehewehe ʻole ai i kēlā mea wale nō ma aneʻi?Nīnau maikaʻi!ʻO ke ala i hoʻopili ʻia ai ʻo panic runtime ma loko maoli nō ia o "sort of" ma ka hale kūʻai crate o ka mea hoʻopili, akā pili wale nō inā ʻaʻole pili maoli kekahi.
//
// ʻO ka hopena o kēia ka manaʻo e hiki i kēia crate a me ka panic_unwind crate ke hōʻike ʻia i ka hale kūʻai crate o ka mea hoʻopili, a inā e wehewehe nā mea ʻelua i ka `eh_personality` lang mea a laila loaʻa kahi hemahema.
//
// E lawelawe i kēia ka compiler wale pono ka `eh_personality` ua hoakaka ina ka panic runtime i ua hoʻopili i loko o ka unwinding runtime, a i ole ia he hana i koi 'ia e ke ho'ākāka' (rightfully pela).
// I kēia hihia, akā naʻe, wehewehe wale kēia waihona i kēia hōʻailona no laila aia ma ka liʻiliʻi kekahi ʻano ma kahi.
//
// ʻAno nui kēia hōʻailona ua pono hoakaka no ka hoʻoili mai i libcore/libstd binaries, akā, ka mea, e aole e kapaʻia me mākou e ole kuhikihi ana i loko o kekahi unwinding runtime ma nā mea a pau.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // ko kakou mau kanaka hana e pono ai, e hoʻi `ExceptionContinueSearch` me mākou huli hele ma luna o nā mōlina a pau mākou Ma x86_64-PC-puka makani-gnu mākou hana.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // E like me ia ma luna, pili kēia i ka mea `eh_catch_typeinfo` lang i hoʻohana wale ʻia ma Emscripten i kēia manawa.
    //
    // No ka mea panics hana ʻole i nā hoʻokoe a me nā hoʻokoe haole i kēia manawa UB me -C panic=abort (ʻoiai e loli paha kēia), ʻaʻole e hoʻohana iki nā kāhea catch_unwind i kēia typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Kāhea ʻia kēia mau mea ʻelua e kā mākou mea hoʻomaka i i686-pc-windows-gnu, akā ʻaʻole pono lākou e hana i kekahi mea no laila ʻaʻole pono nā kino.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}