//! Kahi waihona waihona kākoʻo no nā mea kākau macro i ka wehewehe ʻana i nā makō hou.
//!
//! Hāʻawi ʻia kēia hale waihona puke e ka hoʻokaʻawale maʻamau, hāʻawi i nā ʻano i hoʻopau ʻia i loko o nā interface o ka wehewehena e like me ka macros `#[proc_macro]`, nā ʻano macro me ka `#[proc_macro_attribute]` a me nā ʻano loaʻa kūlohelohe`#[proc_macro_derive]`.
//!
//!
//! E ʻike iā [the book] no ka mea hou aku.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// E hoʻoholo inā i loaʻa iā proc_macro i ka polokalamu e holo nei.
///
/// Hoʻohana wale ʻia ka proc_macro crate no ka hoʻohana ʻana i loko o ka hoʻokō ʻana o nā kōmi ʻōkuhi.ʻO nā hana āpau i kēia crate panic inā i noi ʻia mai waho o kahi macro kaʻina hana, e like me ka script script a i ʻole unit test a i ʻole Rust binary maʻamau.
///
/// Me ka noonoo no ka Rust hale waihona puke i i ke hoʻololi e kākoʻo nā nunui a me ka 'ole-nunui hana hoopii, `proc_macro::is_available()` hoʻolako he pili-'ā'ā ala, e huai ae ina ka aeuiiai ieaia? Koi' ia e hoʻohana i ka API o ka proc_macro Ua lawe hou i loaʻa.
/// Hoʻi ʻoiaʻiʻo inā kāhea ʻia mai loko mai o kahi kōkuhi ʻoihana, wahaheʻe inā kāhea ʻia mai nā binary ʻē aʻe.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ʻO ke ʻano nui i hāʻawi ʻia e kēia crate, e hōʻike ana i kahi kahawai kahakaha o tokens, a i ʻole kikoʻī, i ke kaʻina o nā lāʻau token.
/// Keʻano i Library no ka iterating ma ua mau laau token a, conversely, kaʻohiʻana i ka helu o token lāʻau i loko o kekahi kahawai.
///
///
/// ʻO kēia ka hoʻokomo a me ka puka o `#[proc_macro]`, `#[proc_macro_attribute]` a me `#[proc_macro_derive]` wehewehe.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Ua hoʻi ka hewa mai `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Hoʻihoʻi i kahi `TokenStream` hakahaka ʻole i loaʻa nā token lāʻau.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Nānā inā hakahaka kēia `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Hoao mai ana e uhai i ke kaula i tokens a wae poe tokens i loko o ka token kahawai.
/// E hāʻule no nā kumu he nui, no ka laʻana, inā loaʻa i ke kaula nā kaulike kaulike ʻole a i ʻole huapalapala i loaʻa ʻole i ka ʻōlelo.
///
/// All tokens ma ka wae kahawai kiʻi `Span::call_site()` nā kapuwaʻiʻehā.
///
/// NOTE: kekahi hewa hiki i panics kahi o ka hoi ana `LexError`.E waiho i ka pono e hoʻololi i kēia mau hewa i loko o 'LexError`s hope.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Wahi ka token kahawai o like me ka kaula i ua manao ia e losslessly convertible hoʻi i loko o ka ia token kahawai (modulo nā kapuwaʻiʻehā), koe wale no ka hiki `TokenTree: : Group`s me `Delimiter::None` delimiters a me ka io laulā literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Nā paʻi token i kahi ʻano kūpono no ka debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Hana i kahi kahawai token i loaʻa kahi lāʻau token hoʻokahi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Hōʻiliʻili i kahi nui o nā lāʻau token i hoʻokahi kahawai.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" hana ma token kahawai, 'ohi i token laau mai mau token nā muliwai hoʻi i loko o ka hoʻokahi kahawai.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) E hoʻohana i ka hoʻomākaukau leʻa manaʻo if/when hiki.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Nā kikoʻī hoʻokō lehulehu no ka `TokenStream` ʻano, e like me iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// He iterator ma luna o kā TokenStream` TokenTreeʻs.
    /// Ke iteration o "shallow", IAOEIAaO, ka iterator aʻole i recurse i loko o delimited nā pūʻulu, a me ka hoike a pau pūʻulu me token laau.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ʻae iā tokens āpau a hoʻonui i loko o kahi `TokenStream` e wehewehe nei i ka hoʻokomo.
/// No ka laʻana, `quote!(a + b)` e paka i ka olelo, i, ka wā kūpono, iino? Ieea ka `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting ua hana me `$`, a me ka hana ma ka lawe i ka hookahi aʻe ident like me ka unquoted makahiki.
/// No ka ʻōlelo ʻana iā `$` ponoʻī, e hoʻohana iā `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Kahi ʻāpana o ke code kumu, me ka ʻike hoʻonui hoʻonui macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Hana i kahi `Diagnostic` hou me ka `message` i hāʻawi ʻia i ka lōʻihi `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Kahi lōʻihi e hoʻonā ma ka pūnaewele wehewehe macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ka lōʻihi o ke noi ʻana o ka macro o ke kaʻina hana o kēia manawa.
    /// E hoʻoponopono ʻia nā mea ʻike me kēia āpau me he mea lā ua kākau pololei ʻia ia ma kahi o ka leo heahea (hygiene pūnaewele pūnaewele) a hiki i nā code ʻē aʻe ma ka pūnaewele kāhea macro ke kuhikuhi iā lākou pū kekahi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Kahi lōʻihi e hōʻike ana i ka maʻemaʻe `macro_rules`, a i kekahi manawa hoʻonā i ka pūnaewele wehewehe macro (nā loli kūloko, nā lepili, `$crate`) a i kekahi manawa ma ka pūnaewele kāhea macro (nā mea āpau āpau).
    ///
    /// Lawe ʻia ka wahi i hoʻolōʻihi ʻia mai ka pūnaewele pūnaewele.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ʻO ka faile kumu kumu i kuhikuhi ai kēia kiko.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// ʻO `Span` no ka tokens i ka hoʻonui mua o ka macro mai kahi `self` i hana ʻia mai, inā paha.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// ʻO ka laulā no ka code kumu kumu i hoʻokumu ʻia ai `self` mai.
    /// Inā keia `Span` ia i ua loaʻa mai nā nunui? Ee laila, ka hoʻi waiwai io o ka ia me `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Loaʻa ka hoʻomaka line/column i loko o ke kumu waihona no kēia nā kapuwaʻiʻehā.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Loaʻa i ka line/column hopena i ka faila kumu no kēia āpau.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Hana i kahi āpau hou e hoʻopuni ana iā `self` a me `other`.
    ///
    /// Hoʻi iā `None` inā `self` a me `other` mai nā faile like ʻole.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Hoʻokumu i kahi āpau hou me ka ʻike line/column like ma `self` akā hoʻoholo i nā hōʻailona me he mea lā ma `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Hana i kahi laulā hou me ka hana hoʻonā hoʻonā inoa like me `self` akā me ka ʻike line/column o `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Hoʻohālikelike i nā spans e ʻike inā kūlike lākou.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Hoʻihoʻi i ka huaʻōlelo kumu ma hope o kahi kiko.
    /// Mālama kēia i ke code kumu kumu, me nā wahi a me nā ʻōlelo.
    /// Hoʻihoʻi wale ia i kahi hopena inā kūlike ka lōʻihi i ke code kumu maoli.
    ///
    /// Note: Ke observable hopena o ka nunui e wale hilinai aku ma luna o ka tokens, aʻaʻole ma luna o kēia kumu kikokikona.
    ///
    /// ʻO ka hopena o kēia hana kahi hana maikaʻi loa e hoʻohana ʻia no nā diagnostics wale nō.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Pai i kahi kiko i kahi ʻano kūpono no ka debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// A laina-kolamu paʻa ia ho i ka hoʻomaka 'ana a me ka hopena o ka `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// ʻO ka laina 1 i kuhikuhi ʻia i ka faila waihona ma kahi e hoʻomaka ai a hoʻopau paha ka lōʻihi iā (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ʻO ka kolamu helu helu 0 (i nā huapalapala UTF-8) i ka faile kumu e hoʻomaka ai a hoʻopau paha ka lōʻihi iā (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ʻO ka faila kumu o kahi `Span` i hāʻawi ʻia.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Loaʻa i ke ala i kēia faila kumu.
    ///
    /// ### Note
    /// Inā ka pā'ālua kīkoʻo kona pili i keia `SourceFile` i ua loaʻa ma ka mawaho nunui, keia nunui, ua hiki ole ia he maoli ala ma ka filesystem.
    /// E hoʻohana iā [`is_real`] e nānā.
    ///
    /// Pū 'ana i kumumanaʻo e hiki ina `is_real` hoi mai `true`, ina `--remap-path-prefix` Ua hooholoia ma ke kauoha laina, i ke ala e like me ia e ole nae e i pololei ia.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Hoʻi `true` ina keia kumu waihona mea he maoli kahi waihona, aʻaʻole ua loaʻa ma kekahi mawaho nunui ka? Anoe? Aiey.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // He He hack a intercrate nā kapuwaʻiʻehā e hoʻokō, a ua hiki i maoli kumu AEIU no nā kapuwaʻiʻehā ua loaʻa i loko o mawaho macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Kahi token hoʻokahi a i ʻole ke kaʻina palena palena o nā lāʻau token (e laʻa, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ʻO kahi kahawai token i hoʻopuni ʻia e nā palena palena palena.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// An hōʻike no.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Kahi kikoʻī hoʻokahi kikoʻī (`+`, `,`, `$`, a me nā mea ʻē aʻe).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Kaha huapalapala (`'a'`), string (`"hello"`), helu (`2.3`), a pēlā aku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Hoike i ke kīkoʻo o keia laau, delegating i ka `span` ano o ka mea i kakauiaʻi maluna token ai ka delimited kahawai.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Hoʻonohonoho i ke kiko no *kēia token* wale nō.
    ///
    /// E hoʻomaopopo inā he `Group` kēia token a laila ʻaʻole hoʻonohonoho kēia ʻano i ka lōʻihi o kēlā me kēia tokens i loko, e ʻelele wale kēia i ka hana `set_span` o kēlā me kēia ʻano.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Paʻi token lāʻau ma kahi ʻano kūpono no ka debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kēlā me kēia no kēia mau mea i ka inoa i loko o ka struct 'ano i loko o ka loko debug, no laila, mai bother me he keu ahu iho la ka indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Wahi ka token laau me he kaula i ua manao ia e losslessly convertible hoʻi i loko o ka ia token laau (modulo nā kapuwaʻiʻehā), koe wale no ka hiki `TokenTree: : Group`s me `Delimiter::None` delimiters a me ka io laulā literals.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Kahi kahawai token palena palena.
///
/// A `Group` i loko o kekahi mau he `TokenStream` i ua hoʻopuniʻia `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Wehewehe i ka hopena o ke kaʻina o nā lāʻau token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// An implicit delimiter, i hiki, no ka laʻana, hōʻike a puni tokens e hele mai ana, mai ka "macro variable" `$var`.
    /// He mea nui e mālama i nā mea ʻoihana a nā mea makemake e like me `$var * 3` kahi `$var` `1 + 2`.
    /// Implicit delimiters hiki ole ola roundtrip o ka token kahawai ma ke kui.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Hana i kahi `Group` hou me ka hāʻawi palena palena a me ke kahawai token.
    ///
    /// Kēia constructor, e hoonoho i ke kīkoʻo no keia pae i `Span::call_site()`.
    /// No ka hoʻololi ʻana i ke kiko hiki iā ʻoe ke hoʻohana i ka hana `set_span` ma lalo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Huli i ka delimiter o keia `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Hoike i ka `TokenStream` o tokens mea i delimited ma keia `Group`.
    ///
    /// Hoʻomaopopo ʻaʻole ka kahawai token i hoʻihoʻi ʻia i hoʻokomo i ka palena palena i hoʻihoʻi ʻia ma luna.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Huli i ke kīkoʻo no nā delimiters o keia token kahawai, spanning ka `Group` holoʻokoʻa.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Hōʻike i ka lōʻihi e kuhikuhi ana i ka palena palena mua o kēia hui.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Hōʻike i ka lōʻihi e kuhikuhi ana i ka palena palena palena pau o kēia hui.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Hoʻonohonoho i ka laulā no nā palena palena o kēia Pūʻulu, akā ʻaʻole na tokens o loko.
    ///
    /// Kēia hana e **i** i ke kīkoʻo o nā mea a pau i ka na tokens spanned ma keia pae, akā, e aho ia, e wale nō i ke kīkoʻo o ka delimiter tokens ma ka pae o ka `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wahi o ka pūʻulu me he kaula i e e losslessly convertible hoʻi i loko o ka ia pūʻulu (modulo nā kapuwaʻiʻehā), koe wale no ka hiki `TokenTree: : Group`s me `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// ʻO `Punct` kahi kiko kiko hoʻokahi e like me `+`, `-` a i ʻole `#`.
///
/// Nunui-pūʻulu 'ana, e like `+=` e na poe like elua manawa o `Punct` me kekahi mau ano o `Spacing` hoi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ina he `Punct` ua hahai koke ma kekahi `Punct` a hahai aku la ia ma kekahi token a whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// e laʻa, `+` ʻo `Alone` i `+ =`, `+ident` a i `+()` paha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// e like, `+` o `Joint` ma `+=` a `'#`.
    /// Eia kekahi, hookahi kea `'` hiki ke hui me ka hōʻike no ke i ka wa e ola ana ano `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Hana i kahi `Punct` hou mai ke ʻano a me ka spacing i hāʻawi ʻia.
    /// Ka `ch` loulou pono ia i ka henua pololei punctuation ano Ke aeia'ku nei ia ma ka 'ōlelo, ai ole ke kuleana pili i makemake panic.
    ///
    /// Ka hoi `Punct` e i ka paʻamau kīkoʻo o `Span::call_site()` i hiki ke kele pūnaewele hou ia me ka `set_span` iaoiaeii ma lalo nei.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Huli i ka waiwai o keia punctuationʻano like `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Hoike i ka spacing o keia punctuation ano, e hoike ana inā he hana koke hahai ma kekahi `Punct` ma ka token kahawai, no laila, ka mea hiki palena papaha e hui i ka nunui-pūʻulu Aʻole (`Joint`), a he hana ukali ia e kekahi token 'ē aʻe paha whitespace (`Alone`) ai ka Aʻole i maopopo pau.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Hoʻihoʻi i ka laulā no kēia huapalapala puana.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// E hoʻonohonoho i ka laulā no kēia huapalapala kaha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wahi i ka punctuation ano like he kaula i e e losslessly convertible hoʻi i loko o ka ia ano.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// An hōʻike no (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// I ka mea hou `Ident` me ka haawi `string` like hoʻi me ka mea i hoakaka ia `span`.
    /// Ka `string` loulou pono ia i ka henua pololei hōʻike no Ke aeia'ku nei ia ma ka 'ōlelo (me hua'ōlelo, IAOEIAaO `self` a `fn`).Inā ʻole, ʻo panic ka hana.
    ///
    /// E noke i `span`, a ianoiyuaa a ma rustc, hoʻonohonoho i ke kou niho 'ikepili no kēia hōʻike no.
    ///
    /// E like me kēia manawa `Span::call_site()` koho ʻiʻo a i ka hoʻomaʻemaʻe "call-site" ʻo ia hoʻi nā manaʻo e hana ʻia me kēia āpau e hoʻonā ʻia me he mea lā ua kākau pololei ʻia ia ma kahi o ka kāhea macro, a hiki i nā code ʻē aʻe ma ka pūnaewele kāhea macro ke kuhikuhi. ʻo lākou pū kekahi.
    ///
    ///
    /// Hope nā kapuwaʻiʻehā e like `Span::def_site()` e ae i ka hōʻalo-i i "definition-site" kou niho la me ka manao e hōʻike no ke hana me keia kīkoʻo, e e hoʻonā 'ia ma o ka wahi o ka nunui ho'ākāka' ana a me ka 'ē aʻe kivila ma ka nunui kāhea paena,ʻaʻole e e hiki, e hoʻohuli i iā ia.
    ///
    /// Aie i ka mea he nui o kou niho keia constructor, e like me ka tokens, koi 'he `Span` e e hoakaka ia ma ke kūkuluʻia.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// E like me `Ident::new`, akā hana i kahi mea hōʻike (`r#ident`) maka.
    /// Ka `string` i kekahi manaʻo hoʻopiʻi e ka henua pololei hōʻike no Ke aeia'ku nei ia ma ka 'ōlelo (me hua'ōlelo, IAOEIAaO `fn`).
    /// Keywords i nā usable ma ka ala Hoʻohana (e like
    /// `self`, `Super`) ka mea, 'aʻole i kākoʻo, a e i ka panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Huli i ke kīkoʻo o keia `Ident`, hoʻopuniʻana i ka holoʻokoʻa kaula hoi e [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Hoʻonohonoho i ke kīkoʻo o keia `Ident`, o hiki mai hoʻololi kona kou niho pōʻaiapili.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wahi i ka hōʻike no me he kaula i e e losslessly convertible hoʻi i loko o ka hookahi hōʻike no.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A literal kui (`"hello"`),ʻai kui (`b"hello"`), ano (`'a'`),ʻai ano (`b'a'`), i helu 'ole e lana wahi helu me me ka kau hope' ole ('1`, `1u8`, `2.3`, `2.3f32`).
///
/// Lālā paʻa literals e like `true` a me `false` i hui ole ia iʻaneʻi, e nā `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// I ka mea hou hopeʻo helu literal me ka hoakaka waiwai.
        ///
        /// E hana kēia hana i integer e like me `1u32` kahi i kuhikuhi ʻia ka helu helu o ka ʻāpana mua o ka token a hoʻopili ʻia ka integral i ka hopena.
        /// Literals hana mai io nui e ole ola a-huakaʻi ma `TokenStream` paha kaula, a hiki e wāwahiʻia i loko o nā tokens (`-` a me ka maikaʻi literal).
        ///
        ///
        /// ʻO nā palapala i haku ʻia ma o kēia hana i loaʻa ka `Span::call_site()` āpau e ka paʻamau, a hiki ke hoʻonohonoho ʻia me ke ʻano `set_span` ma lalo.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Hana i kahi helu helu unsuffixed hou me ka helu i kuhikuhi ʻia.
        ///
        /// Kēia papa, e ho okumu i ka helu e like `1` kahi o ka mua loa o ka token ka helu waiwai i hoakaka ia.
        /// No kau hope ua i hoakaka ia ma keia token, la me ka manao e invocations e like `Literal::i8_unsuffixed(1)` e like me `Literal::u32_unsuffixed(1)`.
        /// ʻAʻole hiki i nā hua palapala i haku ʻia mai nā helu maikaʻi ʻole ke ola i nā rountrips ma o `TokenStream` a i ʻole nā kaula a haki ʻia i ʻelua tokens (`-` a me nā huaʻōlelo maikaʻi).
        ///
        ///
        /// ʻO nā palapala i haku ʻia ma o kēia hana i loaʻa ka `Span::call_site()` āpau e ka paʻamau, a hiki ke hoʻonohonoho ʻia me ke ʻano `set_span` ma lalo.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Hana i kahi kiko kiko ʻole unsuffixed lana.
    ///
    /// Ua like kēia mea kūkulu me nā mea e like me `Literal::i8_unsuffixed` kahi i hoʻokuʻu ʻia ai ka waiwai o ka float i loko o ka token akā ʻaʻohe hopena i hoʻohana ʻia, no laila e manaʻo ʻia he `f64` ma hope i ka mea hoʻopili.
    ///
    /// ʻAʻole hiki i nā hua palapala i haku ʻia mai nā helu maikaʻi ʻole ke ola i nā rountrips ma o `TokenStream` a i ʻole nā kaula a haki ʻia i ʻelua tokens (`-` a me nā huaʻōlelo maikaʻi).
    ///
    /// # Panics
    ///
    /// Kēia papa Pono i ka hoakaka lana mea finite, no ka hoohalike ina mea mea infinity paha Nan keia kuleana pili, e panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Hoʻokumu i kahi kiko lana lana hou kiko.
    ///
    /// E hana kēia mea kūkulu i literal e like me `1.0f32` kahi o ka waiwai i kuhikuhi ʻia i ka ʻāpana mua o ka token a ʻo `f32` ka hope o ka token.
    /// E hoʻokau mau ʻia kēia token i `f32` i ka mea hoʻopili.
    /// ʻAʻole hiki i nā hua palapala i haku ʻia mai nā helu maikaʻi ʻole ke ola i nā rountrips ma o `TokenStream` a i ʻole nā kaula a haki ʻia i ʻelua tokens (`-` a me nā huaʻōlelo maikaʻi).
    ///
    ///
    /// # Panics
    ///
    /// Kēia papa Pono i ka hoakaka lana mea finite, no ka hoohalike ina mea mea infinity paha Nan keia kuleana pili, e panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Hana i kahi kiko kiko ʻole unsuffixed lana.
    ///
    /// Ua like kēia mea kūkulu me nā mea e like me `Literal::i8_unsuffixed` kahi i hoʻokuʻu ʻia ai ka waiwai o ka float i loko o ka token akā ʻaʻohe hopena i hoʻohana ʻia, no laila e manaʻo ʻia he `f64` ma hope i ka mea hoʻopili.
    ///
    /// ʻAʻole hiki i nā hua palapala i haku ʻia mai nā helu maikaʻi ʻole ke ola i nā rountrips ma o `TokenStream` a i ʻole nā kaula a haki ʻia i ʻelua tokens (`-` a me nā huaʻōlelo maikaʻi).
    ///
    /// # Panics
    ///
    /// Kēia papa Pono i ka hoakaka lana mea finite, no ka hoohalike ina mea mea infinity paha Nan keia kuleana pili, e panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Hoʻokumu i kahi kiko lana lana hou kiko.
    ///
    /// E hana kēia mea kūkulu i literal e like me `1.0f64` kahi o ka waiwai i kuhikuhi ʻia i ka ʻāpana mua o ka token a ʻo `f64` ka hope o ka token.
    /// E hoʻokau mau ʻia kēia token i `f64` i ka mea hoʻopili.
    /// ʻAʻole hiki i nā hua palapala i haku ʻia mai nā helu maikaʻi ʻole ke ola i nā rountrips ma o `TokenStream` a i ʻole nā kaula a haki ʻia i ʻelua tokens (`-` a me nā huaʻōlelo maikaʻi).
    ///
    ///
    /// # Panics
    ///
    /// Kēia papa Pono i ka hoakaka lana mea finite, no ka hoohalike ina mea mea infinity paha Nan keia kuleana pili, e panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String maoli.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Kaha literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ʻAi kaula literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Hoʻihoʻi i ka lōʻihi e hoʻopuni ana i kēia literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Hoʻonohonoho i ka lōʻihi e pili ana i kēia huaʻōlelo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Hoʻihoʻi i kahi `Span` kahi ʻāpana o `self.span()` i loaʻa wale nā byte kumu i ka pae `range`.
    /// Huli `None` ina ka makemake-e hoʻomaikaʻi i kīkoʻo kona mea ma waho o nā palena o `self`.
    ///
    // FIXME(SergioBenitez): e kaha i kaʻai huahelu kaʻina kānāwai a me ka welau ma ka UTF-8 palena o ke kumu.
    // i ole ia, ka mea, O ia paha i ka panic e ana kakou i ka wa a ke kumu kikokikona ua pai ia.
    // FIXME(SergioBenitez): ʻaʻohe ala e ʻike ai ka mea hoʻohana i ka palapala maoli a `self.span()`, no laila hiki ke hea makapō wale ʻia kēia ala.
    // No ka laʻana, `to_string()` no ke ano 'c' hoʻi "'\u{63}'";ʻaʻohe ala e ʻike ai ka mea hoʻohana inā 'c' ke kumu kumu a i ʻole '\u{63}' paha.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) mea like iā `Option::cloned`, akā no `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ke alahaka wale hoakaka `to_string`, hoʻokō i `fmt::Display` ma muli o ka mea, (i ka nana e hoole ana i ka mau pilina ma waena o ka elua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Wahi i ka literal me he kaula i e e losslessly convertible hoʻi i loko o ka ia literal (koe wale no ka e hiki polopelema no ka lana wahi literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pūʻolo ke kōkua o ke DEBEMAIL E DEBFULLNAME.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// E kiʻi i kahi hoʻololi o ke kaiapuni a hoʻohui iā ia e kūkulu i ka ʻike pili.
    /// Build'ōnaehana hana i ka compiler, e ike i ka ee iaaanu aey i lolouila i compilation, a e e hiki ke rerun i ka hana i ka wa a ka waiwai o ia ee iaaanu aey hoʻololi.
    ///
    /// Ma waho o ka dependency ka hoʻokoloʻana i kēia papa e e like no `env::var` mai o ka hae hale waihona puke, koe wale no i ka manaʻo hoʻopiʻi kū'ē pono ia UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}