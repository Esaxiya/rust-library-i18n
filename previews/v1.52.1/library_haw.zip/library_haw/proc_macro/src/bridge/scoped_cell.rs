//! `Cell` ʻokoʻa no (scoped) ola mau.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// ʻAno palapala lambda, me kahi ola.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// ʻAno lambda e lawe ana i ke ola, ie, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) hana a puni wānana hoʻokau 'me ka newtype FIXME(#52812) kuapo me `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Hoʻonohonoho i ka waiwai ma `self` a `replacement` ʻoiai e holo `f`, i loaʻa ka waiwai kahiko, hiki ke hoʻololi ʻia.
    /// Ke kahiko kumukuai e e hoihoi hou ia ma hope o `f` Haʻalele i ka, a hiki ma ka panic, me ka hoʻololi 'ana i ia mea ma `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Wrapper e hōʻoia 'ia ai i ka halepaahao mauʻia piha (me ka palapala ana, kohoʻia hoʻololiʻia `f`), a hiki ina ua'ā'ā `f`.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// Nā pūʻulu ka waiwai i loko o `self` i `value` oiai e holo mai ana `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}