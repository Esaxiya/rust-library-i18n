//! Ka hoʻokō ʻana o ka `#[assert_instr]` macro
//!
//! Ua hoʻohana 'ia kēia nunui ka wā hoao i ka `stdarch` crate, a ua hoʻohana' ia paha hoao manawa i ka hoʻike i ka oihana e io pihaʻi me na kuhikuhi i ke huli me ka manao ia e loaʻa.
//!
//! Maʻalahi maʻalahi ke kaʻina hana ma aneʻi, hoʻopili wale ia i kahi hana `#[test]` i ke kahawai token kumu e hōʻike nei i ka hana ponoʻī i loko o nā ʻōkuhi pili.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // E hoʻopio i assert_instr no ka x86 pale i houluuluia me avx hoʻohana ', i ke kumu no LLVM hiki paha keʻokoʻa intrinsics i ka mea a mākou e hoao ana no.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // Inā aʻo e ho'āʻo ai i ka polokalamu JavaScriptʻaloʻana K'lauea keia Sima ma nā mea a pau, e hoʻi i ka palapala mau ukana me mākou kaila.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // Mau inoa i ia e kū hoʻokahi lawa no mākou e loaʻa ia ma ka disassembly ma hope ma:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // E hoʻohana i kahi ABI ma Windows e hala i nā koina SIMD i nā papa inoa, e like me ka mea e hana ai ma Unix (manaʻo wau?) Ma ke ʻano paʻamau.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // Ke compiler i hoʻomākaukau leʻa ano ma ka paʻamau holo kekahi alahele kapa "mergefunc" kahi mea e merge oihana e nānā'ālike.
            // 'Ana e haʻalele mai kekahi intrinsics paka'ālike kivila a me ka mea huli pelupelu ia pu, me ka manao i kekahi pono Lele i kekahi.
            // Kēiaʻai i ka nana ana o ka disassembly o keia papa, a kākou i ka nui peahi o ia.
            //
            // E hoʻopūhili i keia alahele, a pale aku oihana mai i merged mākou paha kekahi karaima mai i ka hopefully loa pilipaa i hua'ōlelo o ka codegen akā, mea ole kū hoʻokahi, e pale aku kuhi mai, ua pelupelu ia.
            //
            //
            // Hōʻalo ʻia kēia ma Wasm32 i kēia manawa no ka mea ʻaʻole kuhi ʻia kēia mau hana e haki ai kā mākou mau hoʻāʻo no ka mea ke nānā nei kēlā me kēia intrinsic i nā hana.
            // Huli i nā hana ʻaʻole like like e hui pū ʻia me wasm32.
            // Nānā ʻia kēia pepeke ma rust-lang/rust#74320.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}