use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Hoʻohana ʻia e haʻi i kā mākou `#[assert_instr]` annotations i loaʻa nā simd intrinsics āpau e hoʻāʻo i kā lākou codegen, ʻoiai kekahi mau puka ma hope o kahi `-Ctarget-feature=+unimplemented-simd128` keu i loaʻa ʻole ka like ma `#[target_feature]` i kēia manawa.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}