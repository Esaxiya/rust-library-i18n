#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// E nānā iā [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// E kiʻi i ka laina cache i loaʻa ka helu `p` me ka hāʻawi ʻana i ka `rw` a me `locality` i hāʻawi ʻia.
///
/// Pono ka `rw` i kekahi o:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): ke hoʻomākaukau nei ka prefetch no kahi heluhelu.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): ke hoʻomākaukau nei ka prefetch no kahi kākau.
///
/// Pono ka `locality` i kekahi o:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Prefetch ke kahe a i ʻole ka manawa ʻole, no ka ʻike i hoʻohana wale ʻia i hoʻokahi manawa wale nō.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Kiʻi i ka pae 3 ahu hoʻokoe.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): E kiʻi i ka cache 2 pae.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Kiʻi i ka pae 1 ahu hoʻokoe.
///
/// Ke prefetch paʻa kuhikuhi peʻahiʻana i ka iaiyoe'ōnaehana e iaiyoe accesses mai i ke koho 'ia aae? E paha, e ana i loko o ka kokoke future.
/// Hiki i ka ʻōnaehana hoʻomanaʻo ke pane ma o ka hana ʻana i nā hana i manaʻo ʻia e wikiwiki i ke komo ʻana o ka hoʻomanaʻo i ka wā e hana ai, e like me ka preloading o ka helu wahi i hōʻike ʻia i hoʻokahi a i ʻole nā cache.
///
/// Ma muli o ke kuhi wale kēia mau hōʻailona, kūpono ia no kahi CPU kikoʻī e mālama i kekahi a i ʻole nā kuhikuhi prefetch ma ke ʻano he NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // E hoʻohana i ka `llvm.prefetch` instrinsic me `cache type` =1 (ʻikepili ahu hoʻokoe).
    // `rw` a me `strategy` ma muli o nā palena hana.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}