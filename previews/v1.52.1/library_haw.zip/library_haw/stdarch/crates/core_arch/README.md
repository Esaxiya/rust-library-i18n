`core::arch` - ʻO kā Rust hale waihona puke kumu-kikoʻī intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Hoʻokomo ka module `core::arch` i nā intrinsics hilinaʻi hilinaʻi (e laʻa me SIMD).

# Usage 

`core::arch` loaʻa ma ke ʻano he ʻāpana o `libcore` a hoʻouka hou ʻia e `libstd`.E makemake e hoʻohana iā ia ma o `core::arch` a i ʻole `std::arch` ma mua o kēia crate.
He hu wale hiʻona i pinepine i loaʻa i loko o nightly Rust Via ka `feature(stdsimd)`.

E ho ohana i `core::arch` Via keia crate pono nightly Rust, a me ka mea e hiki (a me ka malama) uhai pinepine.Nā hihia wale nō i loko o ka mea au e noonoo i ka hoʻohana 'ia Via keia crate i:

* ina e pono e hou-i hoʻouluulu `core::arch` oe ia oe iho, e like, me ka maikai pale-hiʻona hoʻohana 'i mea ole pūnaewele no `libcore`/`libstd`.
Note: inā pono ʻoe e hōʻuluʻulu hou iā ia no kahi pahuhopu ʻole maʻamau, e ʻoluʻolu e hoʻohana i `xargo` a hōʻuluʻulu hou iā `libcore`/`libstd` e like me ka pono ma kahi o ka hoʻohana ʻana i kēia crate.
  
* hoʻohana 'ana i kekahi mau hiʻona i paha,ʻaʻole e loaʻa ma ke kua o ka poe Rust hiʻona.Hoʻomaʻo mākou e mālama i kēia mau mea i kahi liʻiliʻi.
Inā 'oe Pono e hana i kekahi o kēia mau hiʻona, e hoʻokaʻakaʻa aʻeʻoe i kahe ai ia mākou ke kiola aku ia i loko o nightly Rust a oe ke hana ia, mai ia wahi.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ua kuhikuhi haawi ma lalo o nā hua'ōlelo o nā ka laikini mit a me ka Apache laikini (Version 2.0), a me kaʻai uhiʻia e likeʻole BSD-e like palapalaʻae male.

E nānā i laikini-APACHE, a me ka laikini-mit no lāliʻi.

# Contribution

Inā ʻaʻole ʻoe e haʻi akāka, ʻaʻole hāʻawi ʻia i kēlā me kēia hāʻawi no ka hoʻokomo ʻana i `core_arch` e ʻoe, e like me ia i ho'ākāka ʻia ma ka laikini Apache-2.0, ʻelua laikini e like me ma luna, me ka ʻole o nā ʻōlelo a me nā kumu.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












