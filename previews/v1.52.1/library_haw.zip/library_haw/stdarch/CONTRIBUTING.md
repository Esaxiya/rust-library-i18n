# Hāʻawi i ka stdarch

ʻOi aku ka `stdarch` crate e ʻae i nā hāʻawi!Mua oe e paha makemake e kikoo mai i ka waihona a me ka mālama pono ana i ho'āʻo ai i kekahi, no oe:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Where `<your-target-arch>` o ka pale umauma hoʻokahi Triple i hoʻohana 'ia e `rustup`, IAOEIAaO `x86_x64-unknown-linux-gnu` (me kekahi māhele ma mua o `nightly-` a like).
E hoʻomanaʻo hoʻi he pono kēia waihona i ke kahawai pō o Rust!
Pono nā hōʻike i luna e koi i ka rust i ka pō e lilo i paʻamau ma kāu ʻōnaehana, e hoʻonohonoho i ka hoʻohana `rustup default nightly` (a me `rustup default stable` e hoʻi hou).

Inā kekahi o na luna a me ke kapuai mai e hana, [please let us know][new]!

Ma hope aʻe hiki iā ʻoe ke [find an issue][issues] e kōkua ma, ua koho mākou i kekahi mau mea me nā [`help wanted`][help] a me [`impl-period`][impl] tag e hiki ke hoʻohana pono i kekahi kōkua. 
Oe i ke loa hoihoi i loko o [#40][vendor], i hoʻokō i nā mea a pau mea kūʻai aku intrinsics ma x86.Loaʻa nā kuhi maikaʻi i kēlā pukana e pili ana i kahi e hoʻomaka ai!

Inā he mau nīnau kāu no ka [join us on gitter][gitter] a nīnau a puni.E ʻoluʻolu e ping iā@BurntSushi a i ʻole@alexcrichton me nā nīnau.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Pehea e kākau examples no stdarch intrinsics

Aia kekahi mau hiʻohiʻona e pono ai e hoʻohana pono i ka intrinsic i hāʻawi ʻia a e holo wale ʻia ke hiʻohiʻona e `cargo test --doc` ke kākoʻo ʻia ka hiʻohiʻona e ka CPU.

E like me ka hopena, i ka paʻamau `fn main` i ua ua loaʻa ma `rustdoc` e ole e holopono ana (i loko o ka hapanui hihia).
E noʻonoʻo e hoʻohana i ka mea aʻe ma ke ʻano he alakaʻi e hōʻoia i kāu mau hiʻohiʻona e like me ka mea i manaʻo ʻia.

```rust
/// # // Mākou e pono cfg_target_feature e hōʻoia i ka hana mea wale
/// # // holo ma `cargo test --doc` ka wā o ka CPU kākoʻo i ka hiʻona
/// # #![feature(cfg_target_feature)]
/// # // Pono mākou i target_feature no ka intrinsic e holo
/// # #![feature(target_feature)]
/// #
/// # // hoʻohana ʻo rustdoc iā `extern crate stdarch` i ka paʻamau, akā pono mākou i ka
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // ʻO ka hana nui maoli
/// # fn main() {
/// #     // Holo wale i kēia inā kākoʻo ʻia ʻo `<target feature>`
/// #     inā CFG_feature_enabled! ("<target feature>"){
/// #         // Hana i kahi hana `worker` e holo wale inā ke hiʻohiʻona hiʻohiʻona
/// #         // Kākoʻo ʻia a hōʻoia ʻia e hiki ai i ka `target_feature` i kāu limahana
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         palekana fn worker() {
/// // Kākau i kāu hiʻohiʻona ma aneʻi.Ka makamake nui i ho'ākāka 'intrinsics e hanaʻaneʻi!Hele hihiu!
///
/// #         }
///
/// #         unsafe { worker(); }
/// #     }
/// # }
```

Inā kekahi o ka mea ma luna o Ka Mooolelo O aʻole e nana ninau, ka [Documentation as tests] pauku o ka [Rust Book] hōʻike ana i ka `rustdoc` Ka Mooolelo Oʻano pono.
E like me nā manawa maʻamau, e ʻoluʻolu iā [join us on gitter][gitter] a nīnau iā mākou inā ʻoe i pā i kekahi snags, a mahalo iā ʻoe no ke kōkua ʻana e hoʻomaikaʻi i ka palapala o `stdarch`!

# Koho ikea ai Na Ke Kumu

Paipai nui ʻia iā ʻoe e hoʻohana iā `ci/run.sh` e holo i nā hoʻokolohua.
Eia naʻe ʻaʻole maikaʻi kēia iā ʻoe, eg inā ʻoe ma Windows.

I mea hihia oe ke emi aku i hope i ka holo `cargo +nightly test` a me `cargo +nightly test --release -p core_arch` no ka hoao i ke kuhi hanauna.
Note e noi aku i kēia mau ka nightly toolchain e e hoʻouka kekahi, a no ka `rustc` e ike e pili ana i kou pale kaua a me ka Triple kona CPU.
I ka pau 'oe pono e hoonoho i ka `TARGET` OOAaAeU like oe makemake no `ci/run.sh`.
ʻO kekahi hoʻi, e pono e hoonoho `RUSTCFLAGS` (e pono ai ka `C`) e ka hōʻike pale hiʻona, e like `RUSTCFLAGS="-C -target-features=+avx2"`.
Hiki iā ʻoe ke hoʻonohonoho iā `-C -target-cpu=native` inā "just" ʻoe e hoʻomohala nei i kāu CPU o kēia manawa.

E ao i ka wā e hoʻohana i kēia mau 'ano like kauoha, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], e like
aʻo hanauna e ho'āʻo ai i pau, no ka mea disassembler kapa ia okoa, e like
hiki iā ia ke hoʻoulu iā `vaesenc` ma kahi o `aesenc` mau kuhikuhi ma muli o kā lākou ʻano like.
Eia kekahi mau ʻōkuhi e hana i nā hōʻike liʻiliʻi ma mua o ka hana maʻamau, no laila mai kahaha i ka wā e huki ai-noi i kekahi mau hewa e hōʻike ʻia no nā hōʻike i uhi ʻole ʻia ma aneʻi.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






