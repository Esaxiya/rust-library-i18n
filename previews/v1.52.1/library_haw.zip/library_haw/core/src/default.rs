//! ʻO `Default` trait no nā ʻano i loaʻa paha nā waiwai palena ʻole.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait no ka hāʻawi ʻana i kahi ʻano i kahi waiwai palena ʻole kūpono.
///
/// I kekahi manawa, e makemake e emi aku i hope a hiki i kekahi ano o ka paʻamau waiwai, a me ka mai ole pakahi aku la ia manao i ia mea.
/// Kēia hele mai i pinepine me ka 'struct`s e hoakaka i ke kaʻina o nā koho:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Pehea la e hiki ai ke hoakaka i kekahi paʻamau nā loina?Hiki nō ke hoʻohana `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Ano, e kiʻi a pau o ka paʻamau loina.Rust mea lapaʻau `Default` no kela primitives ano.
///
/// Inā 'oe makemake e aʻe i kekahi koho, akā, hoopaa no ka mea'ē aʻe o ia ka paʻamau.
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Keia trait hiki ke hoʻohana 'ia me `#[derive]` ina a pau o ke' ano o nā mahinaʻai hoʻokō `Default`.
/// Ke `derive`d, e hoʻohana ia i ka waiwai paʻamau no kēlā me kēia ʻano o ke kahua.
///
/// ## Pehea e hiki ai iaʻu ke hoʻokō iā `Default`?
///
/// E hoʻolako i ka manaʻo no ka `default()` iaoia e huli i ka waiwai o kou 'ano mea e ia i ka paʻamau.
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Hoʻihoʻi i ka "default value" no kahi ʻano.
    ///
    /// Default Hawaiʻi i pinepine kekahi ano o ka loiloi mua waiwai, paha, ka 'waiwai, a me kekahi mea e ae i hiki e hoohalike me ka paʻamau.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana 'ana i kūkulu-ma ka paʻamau Hawaiʻi:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Ke hana nei i kāu iho:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// E hoʻi i ka paʻamau waiwai o kekahi 'ano, e like me ka `Default` trait.
///
/// Hoʻopiʻi ʻia ke ʻano e hoʻi mai ka pōʻaiapili;keia mea like i `Default::default()` akā pōkole i ka type.
///
/// O kahi laʻana:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Loaa nunui hoʻomakaʻia ka impl o ka trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }