//! Nā mea hoʻopili hoʻopili.
//!
//! Aia nā wehewehe like i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! ʻO nā hoʻokō pili kūlike i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: e kūkākūkā me nā kime ʻōlelo i nā loli i ke kūpaʻa o nā intrinsics.
//! Hoʻopili kēia i nā loli i ke kūpaʻa o ke kumukānāwai.
//!
//! I mea e hana i ka waiwai kūʻiʻoo usable i i hoʻouluulu-manawa, i kekahi pono ai, e kope i ka manaʻo, mai <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> a hiki i `compiler/rustc_mir/src/interpret/intrinsics.rs`, a hoʻokomo i ka `#[rustc_const_unstable(feature = "foo", issue = "01234")]` i ka waiwai kūʻiʻoo.
//!
//!
//! Inā manaʻo ʻia e hoʻohana ʻia kahi intrinsic mai kahi `const fn` me kahi ʻano `rustc_const_stable`, pono ke ʻano o ka intrinsic `rustc_const_stable` kekahi.
//! Oia ka loli E ole e hana me ka T-lang kuka, no ka mea, pūlehu akula i ka i ka hiʻona i loko o ka 'ōlelo i ole e replicated hiki ma ka mea hoʻohana kivila me compiler kākoʻo.
//!
//! # Volatiles
//!
//! Ke yiaeaiiacaaeneiie intrinsics i hana i manao e hana ma I/O hoomanao ana, i ka mea, ua hoʻohiki ai i ole e reordered ma ka compiler ma'ē aʻe e yiaeaiiacaaeneiie intrinsics.E ʻike i ka palapala LLVM ma [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ke'ātoma intrinsics hoolako, he pono ole'ātoma ana ma ka mīkini mau olelo, me ka mau e hiki iaiyoe hoonoho papa.Ka mea, e hoolohe mai oe i ka ia semantics me C++ 11.E nānā i ke LLVM nā moʻolelo ma [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Hoʻomaha wikiwiki i ka hoʻonohonoho hoʻomanaʻo ʻana:
//!
//! * Loaʻa, kahi pale no ka loaʻa ʻana o ka laka.Mahope heluhelu a kakau iho ai lawe wahi ma hope o ka'ākeʻakeʻa mai.
//! * E hoʻokuʻu, kahi pale no ka hoʻokuʻu ʻana i kahi laka.Heluhelu a kākau mua ʻia ma mua o ka pale.
//! * Sequentially pahuhopu nei, sequentially e ku hana i ua hoʻohiki e hiki mai i ka mea.ʻO kēia ke ʻano maʻamau no ka hana ʻana me nā ʻano atomic a like ia me Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Hoʻohana ʻia kēia mau mea lawe mai no ka hoʻomaʻalahi ʻana i nā loulou intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Maluhia: nānā `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, mau intrinsics lawe maka mea kuhikuhi no ka mea, mutate aliased hoomanao, i mea ole i pololei ia no kekahi `&` a `&mut`.
    //

    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange` ano ma ka hele [`Ordering::SeqCst`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange` ano ma ka hele [`Ordering::Acquire`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange` ma o ka hala ʻana i [`Ordering::Release`] ma ke ʻano he `success` a me [`Ordering::Relaxed`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange` ma o ka hala ʻana i [`Ordering::AcqRel`] ma ke ʻano he `success` a me [`Ordering::Acquire`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange` ano ma ka hele [`Ordering::Relaxed`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange` ano ma ka hele [`Ordering::SeqCst`] like me ka `success` a me [`Ordering::Relaxed`] like me ka `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange` ma o ka hala ʻana i [`Ordering::SeqCst`] ma ke ʻano he `success` a me [`Ordering::Acquire`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange` ano ma ka hele [`Ordering::Acquire`] like me ka `success` a me [`Ordering::Relaxed`] like me ka `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange` ma o ka hala ʻana i [`Ordering::AcqRel`] ma ke ʻano he `success` a me [`Ordering::Relaxed`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange_weak` ano ma ka hele [`Ordering::SeqCst`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange_weak` ano ma ka hele [`Ordering::Acquire`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange_weak` ma o ka hala ʻana i [`Ordering::Release`] ma ke ʻano he `success` a me [`Ordering::Relaxed`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange_weak` ma o ka hala ʻana i [`Ordering::AcqRel`] ma ke ʻano he `success` a me [`Ordering::Acquire`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange_weak` ano ma ka hele [`Ordering::Relaxed`] me nā ka `success` a me `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    ///
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange_weak` ano ma ka hele [`Ordering::SeqCst`] like me ka `success` a me [`Ordering::Relaxed`] like me ka `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange_weak` ma o ka hala ʻana i [`Ordering::SeqCst`] ma ke ʻano he `success` a me [`Ordering::Acquire`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `compare_exchange_weak` ano ma ka hele [`Ordering::Acquire`] like me ka `success` a me [`Ordering::Relaxed`] like me ka `failure` kiko'î ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Hale kūʻai i ka waiwai ina ka he waiwai o ka ia me ka `old` waiwai.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `compare_exchange_weak` ma o ka hala ʻana i [`Ordering::AcqRel`] ma ke ʻano he `success` a me [`Ordering::Relaxed`] ma ke ʻano he mau palena `failure`.
    /// O kahi laʻana, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Hoʻouka i ka waiwai o ka kuhikuhi i kēia manawa.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `load` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Hoʻouka i ka waiwai o ka kuhikuhi i kēia manawa.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `load` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Hoʻouka i ka waiwai o ka kuhikuhi i kēia manawa.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `load` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i kuhikuhi ʻia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `store` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i kuhikuhi ʻia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `store` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i kuhikuhi ʻia.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `store` ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i hōʻike ʻia, e hoʻihoʻi ana i ka waiwai kahiko.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `swap` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i hōʻike ʻia, e hoʻihoʻi ana i ka waiwai kahiko.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `swap` ma o ka hala ʻana iā [`Ordering::Acquire`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i hōʻike ʻia, e hoʻihoʻi ana i ka waiwai kahiko.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `swap` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i hōʻike ʻia, e hoʻihoʻi ana i ka waiwai kahiko.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `swap` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E mālama i ka waiwai ma ka wahi hoʻomanaʻo i hōʻike ʻia, e hoʻihoʻi ana i ka waiwai kahiko.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `swap` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_add` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_add` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_add` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_add` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_add` ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// E unuhi mai ka waiwai i kēia manawa, e hoʻihoʻi i ka waiwai i hala.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_sub` ma o ka hala ʻana iā [`Ordering::SeqCst`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// E unuhi mai ka waiwai i kēia manawa, e hoʻihoʻi i ka waiwai i hala.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_sub` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// E unuhi mai ka waiwai i kēia manawa, e hoʻihoʻi i ka waiwai i hala.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_sub` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E unuhi mai ka waiwai i kēia manawa, e hoʻihoʻi i ka waiwai i hala.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_sub` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E unuhi mai ka waiwai i kēia manawa, e hoʻihoʻi i ka waiwai i hala.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_sub` ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_and` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_and` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_and` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_and` ma o ka hala ʻana iā [`Ordering::AcqRel`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_and` ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand me ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka ʻano [`AtomicBool`] ma o ka hana `fetch_nand` e ka hala [`Ordering::SeqCst`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`AtomicBool`] 'ano Via ka `fetch_nand` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`AtomicBool`] 'ano Via ka `fetch_nand` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`AtomicBool`] 'ano Via ka `fetch_nand` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
    ///
    /// Ua loaʻa ma ka [`AtomicBool`] 'ano Via ka `fetch_nand` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_or` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_or` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_or` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_or` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise a me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_or` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_xor` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_xor` ano ma ka hele [`Ordering::Acquire`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_xor` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma nā ʻano [`atomic`] ma o ka hana `fetch_xor` ma o ka hala ʻana iā [`Ordering::AcqRel`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me kaʻikena cia, hoi mai ka mua cia.
    ///
    /// Ua loaʻa ma ka [`atomic`] ʻano Via ka `fetch_xor` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ʻO ke kiʻekiʻe me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike i kau inoa ʻia.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_max` ano ma ka hele [`Ordering::SeqCst`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻO ke kiʻekiʻe me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike i kau inoa ʻia.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_max` ano ma ka hele [`Ordering::Acquire`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻO ke kiʻekiʻe me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike i kau inoa ʻia.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_max` ano ma ka hele [`Ordering::Release`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻO ke kiʻekiʻe me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike i kau inoa ʻia.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] i pūlima ʻia i nā integer ma o ka hana `fetch_max` e ka [`Ordering::AcqRel`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I kā mākou i kaʻikena cia.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_max` ano ma ka hele [`Ordering::Relaxed`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ka palena iki me kaʻikena cia hoʻohana i ka pūlima hoʻohālike.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_min` ano ma ka hele [`Ordering::SeqCst`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka palena iki me kaʻikena cia hoʻohana i ka pūlima hoʻohālike.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_min` ano ma ka hele [`Ordering::Acquire`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka palena iki me kaʻikena cia hoʻohana i ka pūlima hoʻohālike.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_min` ano ma ka hele [`Ordering::Release`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka palena iki me kaʻikena cia hoʻohana i ka pūlima hoʻohālike.
    ///
    /// Ua loaʻa nā stabilized hoʻokolohua o keia waiwai ma luna o ka [`atomic`] kakau inoa helu ano Via ka `fetch_min` ano ma ka hele [`Ordering::AcqRel`] like me ka `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka palena iki me kaʻikena cia hoʻohana i ka pūlima hoʻohālike.
    ///
    /// Loaʻa ka mana i hoʻokūpaʻa ʻia o kēia intrinsic ma ka [`atomic`] i pūlima ʻia i nā integer ma o ka `fetch_min` hana ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ka liʻiliʻi me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Ua loaʻa ma ka [`atomic`] unsigned heluʻAno Via ka `fetch_min` ano ma ka hele [`Ordering::SeqCst`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka liʻiliʻi me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] unsigned integer ʻano ma o ka `fetch_min` ʻano hana ma o ka hala ʻana iā [`Ordering::Acquire`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka liʻiliʻi me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] unsigned integer ʻano ma o ka `fetch_min` ʻano hana ma o ka hala ʻana iā [`Ordering::Release`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka liʻiliʻi me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Ua loaʻa ma ka [`atomic`] unsigned heluʻAno Via ka `fetch_min` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka liʻiliʻi me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Ua loaʻa ma ka [`atomic`] unsigned heluʻAno Via ka `fetch_min` ano ma ka hele [`Ordering::Relaxed`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ʻOi loa me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] unsigned integer ʻano ma o ka `fetch_max` ʻano hana ma o ka hala ʻana iā [`Ordering::SeqCst`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻOi loa me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] unsigned integer ʻano ma o ka `fetch_max` ʻano hana ma o ka hala ʻana iā [`Ordering::Acquire`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻOi loa me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Ua loaʻa ma ka [`atomic`] unsigned heluʻAno Via ka `fetch_max` ano ma ka hele [`Ordering::Release`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻOi loa me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Ua loaʻa ma ka [`atomic`] unsigned heluʻAno Via ka `fetch_max` ano ma ka hele [`Ordering::AcqRel`] like me ka `order` Ka stabilized hoʻokolohua o keia waiwai.
    /// O kahi laʻana, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ʻOi loa me ka waiwai o kēia manawa me ka hoʻohana ʻana i ka hoʻohālikelike inoa ʻole.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma ka [`atomic`] unsigned integer ʻano ma o ka `fetch_max` ʻano hana ma o ka hala ʻana iā [`Ordering::Relaxed`] ma ke ʻano he `order`.
    /// O kahi laʻana, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ʻO ka `prefetch` intrinsic kahi hint i ka generator code e hoʻokomo i kahi ʻōlelo aʻoaʻo prefetch inā kākoʻo ʻia;i ole ia, ia mea he ole-Kaiaulu.
    /// Prefetches i ole ia ma luna o ka hana o ka polokalamu akā, hiki ke hoʻololi kona lawelawe 'ano.
    ///
    /// Pono ka hoʻopaʻapaʻa `locality` i integer mau a he kikoʻī kūloko kūlohelohe mai ka (0), ʻaʻohe wahi, a hiki i (3), kūloko loa i kahi cache.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// ʻO ka `prefetch` intrinsic kahi hint i ka generator code e hoʻokomo i kahi ʻōlelo aʻoaʻo prefetch inā kākoʻo ʻia;i ole ia, ia mea he ole-Kaiaulu.
    /// Prefetches i ole ia ma luna o ka hana o ka polokalamu akā, hiki ke hoʻololi kona lawelawe 'ano.
    ///
    /// Pono ka hoʻopaʻapaʻa `locality` i integer mau a he kikoʻī kūloko kūlohelohe mai ka (0), ʻaʻohe wahi, a hiki i (3), kūloko loa i kahi cache.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// ʻO ka `prefetch` intrinsic kahi hint i ka generator code e hoʻokomo i kahi ʻōlelo aʻoaʻo prefetch inā kākoʻo ʻia;i ole ia, ia mea he ole-Kaiaulu.
    /// Prefetches i ole ia ma luna o ka hana o ka polokalamu akā, hiki ke hoʻololi kona lawelawe 'ano.
    ///
    /// Pono ka hoʻopaʻapaʻa `locality` i integer mau a he kikoʻī kūloko kūlohelohe mai ka (0), ʻaʻohe wahi, a hiki i (3), kūloko loa i kahi cache.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// ʻO ka `prefetch` intrinsic kahi hint i ka generator code e hoʻokomo i kahi ʻōlelo aʻoaʻo prefetch inā kākoʻo ʻia;i ole ia, ia mea he ole-Kaiaulu.
    /// Prefetches i ole ia ma luna o ka hana o ka polokalamu akā, hiki ke hoʻololi kona lawelawe 'ano.
    ///
    /// Pono ka hoʻopaʻapaʻa `locality` i integer mau a he kikoʻī kūloko kūlohelohe mai ka (0), ʻaʻohe wahi, a hiki i (3), kūloko loa i kahi cache.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// He pā atomic.
    ///
    /// o ka stabilized hoʻokolohua o keia waiwai i loaʻa i loko o [`atomic::fence`] ma ka hele [`Ordering::SeqCst`] like me ka `order`.
    ///
    ///
    pub fn atomic_fence();
    /// He pā atomic.
    ///
    /// o ka stabilized hoʻokolohua o keia waiwai i loaʻa i loko o [`atomic::fence`] ma ka hele [`Ordering::Acquire`] like me ka `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// He pā atomic.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma [`atomic::fence`] ma o ka hala ʻana i [`Ordering::Release`] ma ke ʻano he `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// He pā atomic.
    ///
    /// o ka stabilized hoʻokolohua o keia waiwai i loaʻa i loko o [`atomic::fence`] ma ka hele [`Ordering::AcqRel`] like me ka `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A compiler-wale iaiyoe ke'ākeʻakeʻa mai.
    ///
    /// ʻAʻole e hoʻonohonoho hou ʻia nā kiʻi hoʻomanaʻo i kēia pale e ka mea nāna e hoʻopili, akā ʻaʻole e hāʻawi ʻia nā ʻōlelo aʻo nona.
    /// Kūpono kēia no nā hana ma ka pae like i hiki ke mālama ʻia, e like me ka wā e launa pū ana me nā mea lawe lima.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma [`atomic::compiler_fence`] ma o ka hala ʻana i [`Ordering::SeqCst`] ma ke ʻano he `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A compiler-wale iaiyoe ke'ākeʻakeʻa mai.
    ///
    /// ʻAʻole e hoʻonohonoho hou ʻia nā kiʻi hoʻomanaʻo i kēia pale e ka mea nāna e hoʻopili, akā ʻaʻole e hāʻawi ʻia nā ʻōlelo aʻo nona.
    /// Kūpono kēia no nā hana ma ka pae like i hiki ke mālama ʻia, e like me ka wā e launa pū ana me nā mea lawe lima.
    ///
    /// o ka stabilized hoʻokolohua o keia waiwai i loaʻa i loko o [`atomic::compiler_fence`] ma ka hele [`Ordering::Acquire`] like me ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A compiler-wale iaiyoe ke'ākeʻakeʻa mai.
    ///
    /// ʻAʻole e hoʻonohonoho hou ʻia nā kiʻi hoʻomanaʻo i kēia pale e ka mea nāna e hoʻopili, akā ʻaʻole e hāʻawi ʻia nā ʻōlelo aʻo nona.
    /// Kūpono kēia no nā hana ma ka pae like i hiki ke mālama ʻia, e like me ka wā e launa pū ana me nā mea lawe lima.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma [`atomic::compiler_fence`] ma o ka hala ʻana i [`Ordering::Release`] ma ke ʻano he `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A compiler-wale iaiyoe ke'ākeʻakeʻa mai.
    ///
    /// ʻAʻole e hoʻonohonoho hou ʻia nā kiʻi hoʻomanaʻo i kēia pale e ka mea nāna e hoʻopili, akā ʻaʻole e hāʻawi ʻia nā ʻōlelo aʻo nona.
    /// Kūpono kēia no nā hana ma ka pae like i hiki ke mālama ʻia, e like me ka wā e launa pū ana me nā mea lawe lima.
    ///
    /// Loaʻa ka mana paʻa o kēia intrinsic ma [`atomic::compiler_fence`] ma o ka hala ʻana i [`Ordering::AcqRel`] ma ke ʻano he `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsic e kiʻi i kona manaʻo mai nā ʻano i hoʻopili ʻia i ka hana.
    ///
    /// No ka laʻana, dataflow hoʻohana i kēia e inject kūpaʻa assertions ai ia `rustc_peek(potentially_uninitialized)` makemake maoli palua-ponopono ana dataflowʻiʻo compute i ia mea, ua uninitialized ma ia wahi i loko o ke ana pele.
    ///
    ///
    /// ʻAʻole pono e hoʻohana i kēia intrinsic ma waho o ka mea hoʻopili.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts ka hoʻokō ʻana o ke kaʻina.
    ///
    /// ʻO kahi mana hoʻohana-aloha a paʻa o kēia hana ʻo [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Hoʻomaopopo 'o ia i ka optimizer i keia wahi i loko o ka eiae mea ole reachable, ka ho'ā hou optimizations.
    ///
    /// NB, keia mea loa okoa mai ka `unreachable!()` nunui: Haʻalele ka nunui, a panics ka wā e ua hoʻokō, ia mea *undefined hana* i hiki kuhi hoailono aku la i keia kuleana pili i.
    ///
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Hoʻomaopopo 'o ia i ka optimizer i ke ano o ka manawa oiaio.
    /// Inā ke ano mea wahahee, no ka hana ua undefined.
    ///
    /// No pā'ālua ua ua loaʻa no keia waiwai kūʻiʻoo, akā, no ka optimizer, e ho'āʻo e mālama aku ia (a me kona ano) ma waena o ala, a i ālai ia 'aʻe i kaʻoi loa o ka hoʻopuni karaima, a emi lawelawe.
    /// It EʻAʻole e hoʻohana 'ina ka invariant hiki ke loaa ma ka optimizer ma kona iho, a ina ia aole ia e hiki ai i kekahiʻiʻo optimizations.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Nā kuhi i ka mea hoʻopili e ʻoiaʻiʻo paha ke ʻano branch.
    /// Huli i ka waiwai maalo ae ia ia.
    ///
    /// ʻO nā hoʻohana ʻē aʻe ma mua o ka `if` mau ʻōlelo ʻaʻole paha e hopena.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Kuhi mai nā kuhi i ka mea hōʻuluʻulu manaʻo he wahaheʻe paha ʻo branch.
    /// Huli i ka waiwai maalo ae ia ia.
    ///
    /// ʻO nā hoʻohana ʻē aʻe ma mua o ka `if` mau ʻōlelo ʻaʻole paha e hopena.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Hana i kahi hei breakpoint, no ka nānā ʻana e kahi mea hoʻopau.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn breakpoint();

    /// Ka nui o kahi ʻano ma nā byte.
    ///
    /// ʻOi aku ke kikoʻī, ʻo kēia ka offset ma nā byte ma waena o nā mea i kū like o ke ʻano like, e like me ka pale kaulike.
    ///
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ka palena iki kaulike o kahi ʻano.
    ///
    /// ʻO [`core::mem::align_of`](crate::mem::align_of) ka mana paʻa o kēia intrinsic.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ka pahuhopu i hoʻopololei o keʻano.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ka nui o ka waiwai i kuhikuhi ʻia i nā bytes.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ke koi hoʻopololei o ka i maopopo nä haumäna waiwai.
    ///
    /// ʻO [`core::mem::align_of_val`](crate::mem::align_of_val) ka mana paʻa o kēia intrinsic.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Loaʻa he kūpaʻa kaula māhele i loaʻa i ka inoa o keʻano.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Loaʻa kekahi hōʻike no i ka puni ke ao kū hoʻokahi a hiki i ke koho 'iaʻano.
    /// Kēia papa, e hoʻi i ka ia cia no kekahiʻano nānā 'ole o whichever crate ka mea, ua' auʻa 'ia ma.
    ///
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A kiai no ka unsafe oihana i ole loa e hoʻokō hiki ina `T` mea i paʻapū i:
    /// Kēia e statically kekahi panic, a hana i kekahi mea.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A kiai no ka unsafe oihana i ole loa e hoʻokō hiki ina `T` 'aʻole e ae Aʻohe-initialization: kēia e statically kekahi panic, a hana i kekahi mea.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn assert_zero_valid<T>();

    /// A kiai no ka unsafe oihana i ole loa e hoʻokō hiki ina `T` i helu kuhi iki lauana: kēia e statically kekahi panic, a hana i kekahi mea.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn assert_uninit_valid<T>();

    /// Loaʻa ka pili i kekahi kūpaʻa `Location` e hoike ana i kahi mea i kapaʻia.
    ///
    /// E hoomanao i ka hoʻohana 'ana [`core::panic::Location::caller`](crate::panic::Location::caller) hakahaka.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Höʻike i ka waiwai mai o ka laulā me ka holo kulu glue.
    ///
    /// Kēia i koe wale nō ke no [`mem::forget_unsized`];Hoʻohana `forget` maʻamau `ManuallyDrop` ma kahi.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets nā'āpana o ka waiwai o kekahi 'ano me kekahiʻano.
    ///
    /// Pono ka nui o nā ʻano ʻelua.
    /// ʻAʻole paha ke kumu, a i ʻole ka hopena, he [invalid value](../../nomicon/what-unsafe-does.html) paha.
    ///
    /// `transmute` mea semantically like i ka bitwise hele o ke 'ano kekahi i kekahi.Kope i nā ʻāpana mai ke kumu waiwai i ka waiwai huakaʻi, a laila poina i ke kumu.
    /// Kūlike ia me C's `memcpy` ma lalo o ka pale, e like me `transmute_copy`.
    ///
    /// No ka mea, `transmute` mea he ma-waiwai ana, hoʻopololei o ka *transmuted loina lakou iho* mea,ʻaʻole he mea e hopohopo nei.
    /// E like me nā hana ʻē aʻe, hōʻoia ka mea hoʻopili i nā `T` a me `U` i ke kaulike kūpono.
    /// Eia nō naʻe, i ka hoʻoili ʻana i nā waiwai i *kuhi ma nā wahi ʻē aʻe*(e like me nā kuhi kiko, nā kuhikuhi, nā pahu…), pono ka mea i kāhea i ka hoʻopili pono ʻana i nā waiwai i kuhikuhi ʻia.
    ///
    /// `transmute` ʻaʻole **weliweli** palekana.Nui a hewahewa nā ala e hiki ai iā [undefined behavior][ub] me kēia hana.`transmute` e ia i ka kāpae hope e akoakoa ai.
    ///
    /// He palapala hou kā ka [nomicon](../../nomicon/transmutes.html).
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Aia mau mea he mau mea `transmute` mea maoli pono no.
    ///
    /// Haliu ae la ia i ka laʻau kuhikuhi i loko o ke kuleana pili i laʻau kuhikuhi.ʻAʻole kēia * hiki ke lawe ʻia i nā mīkini kahi ʻokoʻa ka nui o nā kuhikuhi kuhikuhi a me nā kuhikuhi kikoʻī.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Hoʻonui i kahi ola, a i ʻole ke hoʻopōkole ʻana i ke ola mau ʻole.Kēia Ua nui nō, loa unsafe Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Hana ole o ka manao: he nui na hana o `transmute` hiki ke loaʻa ma kekahi 'ano.
    /// Aia ma lalo e like me ka palapala noi o `transmute` i hiki ke auou caiaiai me ka lua pele? Aiey iauaeoia.
    ///
    /// Ke hoʻohuli nei i bytes(`&[u8]`) maka i `u32`, `f64`, a pēlā aku.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // e hoʻohana ma kahi o `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // a ke hoʻohana `u32::from_le_bytes` a `u32::from_be_bytes`, e hoakaka i ka endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ke hoʻohuli nei i kahi kuhikuhi i `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // E hoʻohana i kahi `as` cast ma kahi
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Haliu ae la ia i ka `*mut T` i loko o ka `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // E hoʻohana i ka reborrow kahi
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ke hoʻohuli nei i kahi `&mut T` i `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ano, e kau pu `as` a reborrowing, e hoailona oukou i ka hoopaaia lakou o `as` `as` mea ole transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Haliu ae ka `&str` i loko o ka `&[u8]`:
    ///
    /// ```
    /// // keia mea i kaʻaoʻao maikaʻi e hana i kēia.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oe hiki ke hoʻohana `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // A i 'ole, e hoʻohana i kaʻai ia-a-, ina oe i hooponopono ma luna o ke kaula literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Haliu ae la ia i ka `Vec<&T>` i loko o ka `Vec<Option<&T>>`.
    ///
    /// E transmute i ka pā 'ano o kahi o ka ipu, e pono e maopopo lea ai ia i kue i kekahi o ko ka ipu ka invariants.
    /// No `Vec`, ke kumu o kēia e like ka nui *a me ke kaulike* o nā ʻano o loko.
    /// Other pahu paha hilinai aku maluna o ka nui o ka 'ano, hoʻopololei, a hiki i ka `TypeId`, ma i hihia transmuting makemake,ʻaʻole e hiki i nā mea a pau me ka' aʻe i ka ipu invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone ka vector like, e hoʻohana hou mākou ia hope
    /// let v_clone = v_orig.clone();
    ///
    /// // Ke hoʻohana nei i ka transmute: hilinaʻi kēia i ka hoʻonohonoho ʻikepili i hōʻike ʻole ʻia o `Vec`, kahi manaʻo maikaʻi ʻole a hiki ke kumu i ka Undefined behaviour.
    /////
    /// // Naʻe, ka mea, mea ole-kope.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ʻO kēia ka ala i ʻōlelo ʻia, palekana.
    /// // Ka mea, 'aʻole kope i ka vector holoʻokoʻa, naʻe, i loko o ka hou ke kaua.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 'O kēia ka mea pono ole-kope, unsafeʻaoʻao o "transmuting" he `Vec`, me ka hilinai ma o kaʻikepiliʻia.
    /// // Ma kahi o ka literally kahea `transmute`, ua hana ka laʻau kuhikuhi hoolei, akā, ma ka olelo o ka hoʻololi 'ana i ka palapala oloko type (`&i32`) i hou kekahi (`Option<&i32>`) ka, keia i nā mea a pau i ka hookahi caveats.
    /////
    /// // Ma waho o ka 'ike i hoakaka ia ma luna, i nīnau aku i ka [`from_raw_parts`] palapala kuhikuhi.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Hoʻohou i kēia ke kūpaʻa ka vector_into_raw_parts.
    ///     // Hōʻoia i ka palapala vector ua i haule.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Ka hoʻokō `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Aia i mau aoao, e hana i kēia, a he mea mau pilikia a me ka hope o (transmute) alanui.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // mua: transmute ua e kikokiko i palekana;a pau ka mea loaʻa, e kaha mea ia T a
    ///         // Ua like ka nui o U.
    ///         // ʻO ka lua, ma aneʻi, loaʻa iā ʻoe ʻelua mau kuhikuhi e hiki ke hoʻololi ʻia e kuhikuhi ana i ka hoʻomanaʻo like.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Kēiaʻia pakele o ke 'ano palekana pilikia;`&mut *` e* wale *haawi mai oe i `&mut T` mai ka `&mut T` paha `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // nae, oe nō i mau mutable kūmole kuhikuhi ana a hiki i ka ia iaiyoe.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 'O kēia pehea ka maʻamau hale waihona hana no hoi ia.
    /// // ʻO kēia ke ala ʻoi loa, inā pono ʻoe e hana i kahi mea e like me kēia
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Kēia manawa he ekolu mutable kūmole kuhikuhi ana ma ka ia iaiyoe.`slice`, ka rvalue ret.0, a me ka rvalue ret.1.
    ///         // `slice` ua ike ole e hoʻohana 'ia ma hope o `let ptr = ...`, a no laila i kekahi ke hana ia me "dead", a no laila,' oe wale nō i nā maoli mutable slices.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ia ia i hana i ka waiwai kūʻiʻoo const i ka pilina paʻa, ke i kekahi aoao kivila ma const fn
    // E kaha makau i mea ole kona hoʻohana i loko o `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Hoʻihoʻi iā `true` inā hāʻawi ʻia ke ʻano maoli e like me `T` e pono ke kulu kulu;hoike `false` ina ka maoli type hoakaka no `T` mea lapaʻau `Copy`.
    ///
    ///
    /// Inā ka maoli type aole pono kulu glue, aole hoi e kakau mai `Copy`, laila, ka hoʻi waiwai io o keia kuleana pili i ka unspecified.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ho omaulia i ke ka offset mai ka laʻau kuhikuhi.
    ///
    /// Hoʻohana ʻia kēia ma ke ʻano he intrinsic e hōʻalo ai i ka hoʻololi ʻana i a mai kahi integer, ʻoiai e hoʻolei ka hoʻohuli i ka ʻike aliasing.
    ///
    /// # Safety
    ///
    /// Ua ka hoʻomaka a me ka kūpono laʻau kuhikuhi pono e kekahi i ka pale, a me kekahiʻai hala i ka hopena o ka anao? Aou mea.
    /// Inā kekahi laʻau kuhikuhi mea mai o nā palena 'ole makemakika hoʻohālana ia lŘlŘ laila kekahi hou ana o ka hoi mai la waiwai, e' ai pono i loko o undefined kolohe.
    ///
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Hoʻomaulia i ka offset mai kahi kuhikuhi, hiki ke ʻāwili.
    ///
    /// Keia ua hoʻokō e like me ka waiwai kūʻiʻoo e hōʻalo ai i ka hoʻololi 'ana i, a mai ka helu, mahope mai o ka huli ana inhibits kekahi optimizations.
    ///
    /// # Safety
    ///
    /// Like ka `offset` kūʻiʻoo, keia kūʻiʻoo 'aʻole i ka hoʻohāiki' i ka kūpono laʻau kuhikuhi i ka wahi i loko o ai kekahiʻai hala i ka hopena o ka anao? Aou e hoopii mai ai, a me ia wahī mai me ka mau o ka hoʻokō makemakika.
    /// Ke kūpono waiwai mea i pololei ia ia e hoʻohana 'ia nae ke kōkua o iaiyoe,ʻaʻole pono.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kūlike ia i ka intrinsic `llvm.memcpy.p0i8.0i8.*` kūpono, me ka nui o `count`*`size_of::<T>()` a me kahi kaulike o
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ka mea e yiaeaiiacaaeneiie aiao ua hoonoho ia `true`, no laila ia eʻaʻole e hoʻomākaukau leʻa mai ina aole nui, ua like ke 'Aʻohe.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Kūlike ia i ka intrinsic `llvm.memmove.p0i8.0i8.*` kūpono, me ka nui o `count* size_of::<T>()` a me kahi kaulike o
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ka mea e yiaeaiiacaaeneiie aiao ua hoonoho ia `true`, no laila ia eʻaʻole e hoʻomākaukau leʻa mai ina aole nui, ua like ke 'Aʻohe.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Kūlike ia i ka intrinsic `llvm.memset.p0i8.*` kūpono, me ka nui o `count* size_of::<T>()` a me kahi kaulike o `min_align_of::<T>()`.
    ///
    ///
    /// Ka mea e yiaeaiiacaaeneiie aiao ua hoonoho ia `true`, no laila ia eʻaʻole e hoʻomākaukau leʻa mai ina aole nui, ua like ke 'Aʻohe.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Hana i kahi ukana maʻalahi mai ka kuhikuhi `src`.
    ///
    /// ʻO [`core::ptr::read_volatile`](crate::ptr::read_volatile) ka mana paʻa o kēia intrinsic.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Hanaʻia he yiaeaiiacaaeneiie hale kūʻai i ka `dst` laʻau kuhikuhi.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Hanaʻia he yiaeaiiacaaeneiie haawe ana mai o ka `src` laʻau kuhikuhi ka laʻau kuhikuhi ia i koi 'ia e ua kūponoʻia.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Hanaʻia he yiaeaiiacaaeneiie hale kūʻai i ka `dst` laʻau kuhikuhi.
    /// Ke laʻau kuhikuhi 'aʻole i koi' ia e ua kūponoʻia.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Huli i ka huinahalike kumu o ka `f32`
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Huli i ka huinahalike kumu o ka `f64`
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ke hoala mai i ka `f32` i ka helu mana.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ke hoala mai i ka `f64` i ka helu mana.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Hoʻihoʻi i ke sine o `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Huli i ka sine o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Hoʻihoʻi i ke cosine o kahi `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Hoʻihoʻi i ke cosine o kahi `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ke hoala mai i ka `f32` i ka `f32` mana.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ke hoala mai i ka `f64` i ka `f64` mana.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Huli i ka exponential o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Huli i ka exponential o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Hoike 2 hoala mai ai i ka mana o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Hoike 2 hoala mai ai i ka mana o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Hoʻihoʻi i ka logarithm maoli o kahi `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Huli i ka Olelo Kikeke Ma maoli o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Huli i ke kumu 10 Olelo Kikeke Ma o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Hoʻihoʻi i ka base 10 logarithm o kahi `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Huli i ke kumu 2 Olelo Kikeke Ma o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Huli i ke kumu 2 Olelo Kikeke Ma o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Hoʻi `a * b + c` no `f32` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Hoʻi `a * b + c` no `f64` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Huli i ka loa cia o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Hoʻihoʻi i ka waiwai piha o kahi `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Huli i ka palena iki o ka mau `f32` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Huli i ka palena iki o ka mau `f64` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Huli i ka i kā mākou o elua `f32` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Huli i ka i kā mākou o elua `f64` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kope i ka hoailona, mai `y` a hiki i `x` no `f32` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kope i ka hoailona, mai `y` a hiki i `x` no `f64` loina.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Hoʻihoʻi i ka helu nui loa ma lalo o a i ʻole like i `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Hoike i ka nui loa helu emi 'ole ma mua o i keia a hiki i ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Huli i ka huna uuku heluʻoi aku ma mua o paha i keia i ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Huli i ka huna uuku heluʻoi aku ma mua o paha i keia i ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Huli i ka helu wahi o ka `f32`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Huli i ka helu wahi o ka `f64`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// E hoʻihoʻi i ka helu helu kokoke i kahi `f32`.
    /// Hiki iā ia ke hāpai i kahi ʻokoʻa lana kiko kiko ʻole inā ʻaʻole hoʻopaʻapaʻa ka helu.
    pub fn rintf32(x: f32) -> f32;
    /// Hoʻi ka mea kokoke helu i ka `f64`.
    /// Hiki iā ia ke hāpai i kahi ʻokoʻa lana kiko kiko ʻole inā ʻaʻole hoʻopaʻapaʻa ka helu.
    pub fn rintf64(x: f64) -> f64;

    /// E hoʻihoʻi i ka helu helu kokoke i kahi `f32`.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Hoʻi ka mea kokoke helu i ka `f64`.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn nearbyintf64(x: f64) -> f64;

    /// E hoʻihoʻi i ka helu helu kokoke i kahi `f32`.Puni hapalua-ala hihia aku mai Aʻohe.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Hoʻi ka mea kokoke helu i ka `f64`.Puni hapalua-ala hihia aku mai Aʻohe.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo mea
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Lana hou e leie aku optimizations ka nānā 'ana ma luna o algebraic lula.
    /// E lawe nā manaʻo i finite.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Lana subtraction e leie aku optimizations ka nānā 'ana ma luna o algebraic lula.
    /// E lawe nā manaʻo i finite.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float multiplication e ʻae ai i nā optimization ma muli o nā rula algebraic.
    /// E lawe nā manaʻo i finite.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Lana mahele e leie aku optimizations ka nānā 'ana ma luna o algebraic lula.
    /// E lawe nā manaʻo i finite.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ʻO ke koena lana e ʻae ai i nā optimization ma muli o nā rula algebraic.
    /// E lawe nā manaʻo i finite.
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Hoʻohuli me LLVM's fptoui/fptosi, i hoʻihoʻi i undef no nā waiwai i waho o ka pae
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Hoʻonohonoho like [`f32::to_int_unchecked`] a me [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Hoike ka helu o nā'āpana i loko o ka helu type `T`
    ///
    /// i loaʻa ma ka helu primitives Via ka `count_ones` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Hoʻihoʻi i ka helu o nā alakaʻi unset alakaʻi (zeroes) i kahi integer type `T`.
    ///
    /// Loaʻa nā mana stabilized o kēia intrinsic ma ka integer primitives ma o ka `leading_zeros` hana.
    /// O kahi laʻana,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// E hoʻihoʻi kahi `x` me ka waiwai `0` i ka laulā o `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Like `ctlz`, akā, keu-unsafe me ka mea i hoi mai `undef` wā hāʻawi i `x` me ka waiwai `0`.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Hoʻihoʻi i ka helu o nā huki kiʻi ʻole (zeroes) i huina helu helu `T`.
    ///
    /// i loaʻa ma ka helu primitives Via ka `trailing_zeros` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// An `x` me ka waiwai `0`, e hoʻi i ka iki laula o `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// E like me `cttz`, akā keu-palekana ʻole ma muli o ka hoʻihoʻi ʻana iā `undef` ke hāʻawi ʻia i `x` me ka waiwai `0`.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Hoʻohuli i nā bytes i ka helu huina `T`.
    ///
    /// i loaʻa ma ka helu primitives Via ka `swap_bytes` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Huli i nā ʻāpana i ka helu huina `T`.
    ///
    /// i loaʻa ma ka helu primitives Via ka `reverse_bits` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Hanaʻia kulana kupono helu hou.
    ///
    /// Loaʻa nā mana stabilized o kēia intrinsic ma ka integer primitives ma o ka `overflowing_add` hana.
    /// O kahi laʻana,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Hanaʻia kulana kupono helu subtraction
    ///
    /// i loaʻa ma ka helu primitives Via ka `overflowing_sub` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Hanaʻia kulana kupono helu multiplication
    ///
    /// i loaʻa ma ka helu primitives Via ka `overflowing_mul` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Hanaʻia he mau mahele, kūpono ma undefined hana kahi `x % y != 0` a `y == 0` paha `x == T::MIN && y == -1`
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Hanaʻia he unchecked mahele, kūpono ma undefined hana kahi `y == 0` a `x == T::MIN && y == -1`
    ///
    ///
    /// Loaʻa nā wahī palekana no kēia intrinsic ma ka integer primitives ma o ka `checked_div` hana.
    /// O kahi laʻana,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Huli i ke koena o ka unchecked mahele, kūpono ma undefined hana ia `y == 0` a `x == T::MIN && y == -1`
    ///
    ///
    /// Maluhia wrappers no keia waiwai i loaʻa ma ka helu primitives Via ka `checked_rem` hana.
    /// O kahi laʻana,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Hana i kahi hoʻololi hema hema ʻole ʻia, e hopena ana i ka hana undefined ke `y < 0` a i ʻole `y >= N`, kahi N ka laulā o T i nā ʻāpana.
    ///
    ///
    /// Maluhia wrappers no keia waiwai i loaʻa ma ka helu primitives Via ka `checked_shl` hana.
    /// O kahi laʻana,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Hanaʻia he unchecked pono naeaeaa, kūpono ma undefined hana ia `y < 0` a `y >= N`, kahi N o ka laula o T i loko o nā kānaka.
    ///
    ///
    /// Loaʻa nā wahī palekana no kēia intrinsic ma ka integer primitives ma o ka `checked_shr` hana.
    /// O kahi laʻana,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Huli i ka hopena o ka unchecked hou, kūpono ma undefined hana ia `x + y > T::MAX` a `x + y < T::MIN`.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Huli i ka hopena o ka unchecked subtraction, kūpono ma undefined hana ia `x - y > T::MAX` a `x - y < T::MIN`.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Huli i ka hopena o ka unchecked multiplication, kūpono ma undefined hana ia `x *y > T::MAX` a `x* y < T::MIN`.
    ///
    ///
    /// Kēia kūʻiʻoo Aʻole i ka hale lio counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Hanaʻia ka ao ka haʻalele.
    ///
    /// Loaʻa nā mana stabilized o kēia intrinsic ma ka integer primitives ma o ka `rotate_left` hana.
    /// O kahi laʻana,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Hana pololei i ka huli.
    ///
    /// Loaʻa nā mana stabilized o kēia intrinsic ma ka integer primitives ma o ka `rotate_right` hana.
    /// O kahi laʻana,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Hoike (he + b) mod 2 <sup>N,</sup> kahi N o ka laula o T i loko o nā kānaka.
    ///
    /// i loaʻa ma ka helu primitives Via ka `wrapping_add` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Hoike (he, b) mod 2 <sup>N,</sup> kahi N o ka laula o T i loko o nā kānaka.
    ///
    /// i loaʻa ma ka helu primitives Via ka `wrapping_sub` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Hoike (he * b) mod 2 <sup>N,</sup> kahi N o ka laula o T i loko o nā kānaka.
    ///
    /// i loaʻa ma ka helu primitives Via ka `wrapping_mul` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, kūhohonu loa ma laulā i pale a.
    ///
    /// i loaʻa ma ka helu primitives Via ka `saturating_add` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, kūhohonu loa ma laulā i pale a.
    ///
    /// i loaʻa ma ka helu primitives Via ka `saturating_sub` iaoiaeii ka stabilized wale nō o kēia kūʻiʻoo.
    /// O kahi laʻana,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Hoʻihoʻi i ka waiwai o ka hoʻokae no ka mea ʻokoʻa ma 'v';
    /// ina `T` ʻAʻohe discriminant, hoi mai `0`.
    ///
    /// Na stabilized mana o keia waiwai kūʻiʻoo o [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Hoike i ka helu ana o Lolina o keʻano `T` hoolei aku i ka `usize`;
    /// ina `T` ʻAʻohe Lolina, hoi mai `0`.I paʻapū i Lolina e ke helu aku.
    ///
    /// ʻO ka mana e hoʻokūpaʻa ʻia o kēia intrinsic [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ka "try catch"? Ieoaeunoai a ke pule aku nei i ka papa laʻau kuhikuhi `try_fn` me kaʻikepili laʻau kuhikuhi `data`.
    ///
    /// Ke kolu o ka loulou o ka papa i kapaia ina he panic ia lŘlŘ.
    /// Lawe kēia hana i ka mea kuhikuhi ʻikepili a me kahi kuhikuhi i kahi mea ʻokoʻa kikoʻī i hopu ʻia.
    ///
    /// No ka 'ike hou aku i ka compiler ka kumu e like me std ka hoopahele ae la i manaʻo.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Hoʻouna i kahi hale kūʻai `!nontemporal` e like me LLVM (ʻike i kā lākou palapala).
    /// Paha, e aole loa i hale lio.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// E nānā i nā moʻolelo o `<*const T>::offset_from` no lāliʻi.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// E nānā i nā moʻolelo o `<*const T>::guaranteed_eq` no lāliʻi.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// E nānā i nā moʻolelo o `<*const T>::guaranteed_ne` no lāliʻi.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Līkaia i i hoʻouluulu manawa.E ole e kapaia ma runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ua wehewehe ʻia kekahi mau hana ma aneʻi no ka mea loaʻa ʻole lākou i loaʻa i kēia module ma ka hale paʻa.
// E nānā iā <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` i moe i loko o kēia waeʻano, akā, ka mea hiki ole ke wahi no a hiki i ka loaʻa, e kaha i `T` a me `U` i ka ia nui.)
//

/// E kaha makau i paha `ptr` ua pono ua kūponoʻia me ka manao ana i `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kope `count *size_of::<T>()` nāʻai, mai `src` a hiki i `dst`.Ke kumu a me ka mākaʻikaʻi pono* i * ano.
///
/// No ka wahi o ka iaiyoe i ke ano, e hoʻohana [`copy`] kahi.
///
/// `copy_nonoverlapping` ua like ia me C's [`memcpy`], akā ua hoʻololi ʻia ke kauoha hoʻopaʻapaʻa.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `src` pono e [valid] no ka heluhelu o `count * size_of::<T>()` nāʻai.
///
/// * `dst` pono e [valid] no nā kākau o `count * size_of::<T>()` bytes.
///
/// * He mau `src` a `dst` pono e pono ua kūponoʻia.
///
/// * E hoʻomaka ana ka ʻāpana o ka hoʻomanaʻo ma `src` me ka nui o ka `helu *
///   size_of: :<T>() `Nāʻai pono *i* ano a me ka māhele o ka iaiyoe e hoomaka ana me ka ia nui ma `dst`.
///
/// E like me [`read`], hana ʻo `copy_nonoverlapping` i kope liʻiliʻi o `T`, me ka nānā ʻole inā `T` ʻo [`Copy`].
/// Inā `T` mea ole [`Copy`], hoʻohana '*nā* na aiee i loko o ka māhele' āina e hoomaka ana ma `*src`, a me ka aina e hoomaka ana ma `* dst` ke [violate memory safety][read-ownership].
///
///
/// Note e hiki ina na ka pono mānewanewa kanikau nui ('helu * size_of: :<T>() `) O `0`, na mea kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// E hoʻokō lima iā [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// E neʻe aku i na oihana mua o `src` i `dst`, waiho `src` nele.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Hōʻoia 'ia ai `dst` loaʻa lawa nona iho, e hoopaa a pau o `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Palekana mau ke kāhea e offset no ka mea ʻaʻole e hoʻokaʻawale ʻo `Vec` ma mua o nā `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` me ka hooki kona Contents.
///         // Hana mākou i kēia i ka mea mua, e hōʻalo i nā pilikia inā hihia kekahi mea ma lalo o panics.
///         src.set_len(0);
///
///         // Nā wahiʻelua hiki ole ano no ka mutable kūmole hana ole Alia, a me nāʻokoʻa vectors hiki ole ponoi i ka hookahi iaiyoe.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Hai aku `dst` i mea e paʻa kahi o `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Hana kēia mau loaʻa, e kaha i holo manawa wale
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ole'ā'ā e malama codegen hopena uuku.
        abort();
    }*/

    // Ka maluhia: o ka maluhia aelike no `copy_nonoverlapping` pono e
    // kokuaia oia ma ka Caller.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kope `count * size_of::<T>()` nāʻai, mai `src` a hiki i `dst`.Pili paha ke kumu a me kahi e hele ai.
///
/// Inā i ke kumu a me ka mākaʻikaʻi e *aole* ano, [`copy_nonoverlapping`] hiki ke hoʻohana hakahaka.
///
/// `copy` mea semantically like ia C ka [`memmove`], akā, me ka manaʻo hoʻopiʻi kū'ē kauoha swapped.
/// Ka hoʻopiliʻana i wahi like ina i mānewanewa na nāʻai, mai `src` a hiki i ka pokole e kū'ē, a laila, mānewanewa, mai ke kaua a hiki i `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `src` pono e [valid] no ka heluhelu o `count * size_of::<T>()` nāʻai.
///
/// * `dst` pono e [valid] no nā kākau o `count * size_of::<T>()` bytes.
///
/// * He mau `src` a `dst` pono e pono ua kūponoʻia.
///
/// E like me [`read`], hana ʻo `copy` i kope liʻiliʻi o `T`, me ka nānā ʻole inā `T` ʻo [`Copy`].
/// Inā `T` mea ole [`Copy`], hoʻohana 'ana i nā nā aiee i loko o ka māhele' āina e hoomaka ana ma `*src`, a me ka aina e hoomaka ana ma `* dst` ke [violate memory safety][read-ownership].
///
///
/// Note e hiki ina na ka pono mānewanewa kanikau nui ('helu * size_of: :<T>() `) O `0`, na mea kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Hana maikaʻi i kahi Rust vector mai kahi pale pale palekana:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` pono e pono ua kūponoʻia no kona 'ano a me ka' ole-Aʻohe.
/// /// * `ptr` pono e kūpono no ka heluhelu ʻana i nā mea pili pili o `elts` o ka ʻano `T`.
/// /// * pono ole e hoʻohana 'ma hope o kahea ana i kēia kuleana pili i ole `T: Copy` ia mau kumu.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: ʻO kā mākou precondition e hōʻoia i ke kūlike a kūpono o ke kumu.
///     // a me `Vec::with_capacity` e hōʻoiaʻiʻo ana mākou i usable i manawa e kākau ia.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // Maluhia: mākou i hana ia i keia mea nona iho mua,
///     // a me ka mea mua `copy` i initialized mau kumu.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Hana kēia mau loaʻa, e kaha i holo manawa wale
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ole'ā'ā e malama codegen hopena uuku.
        abort();
    }*/

    // Maluhia: pono e kokuaia oia e ka Caller ka maluhia aelike no `copy`.
    unsafe { copy(src, dst, count) }
}

/// Hoʻonohonoho iā `count * size_of::<T>()` bytes o ka hoʻomanaʻo e hoʻomaka ma `dst` a i `val`.
///
/// `write_bytes` mea i 'ano like me C ka [`memset`], akā, nā pūʻulu `count * size_of::<T>()` nāʻai i `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `dst` pono e [valid] no nā kākau o `count * size_of::<T>()` bytes.
///
/// * `dst` pono e hoʻopili pono.
///
/// Eia kekahi, o ka Caller pono hōʻoia i kākau `count * size_of::<T>()` nāʻai a hiki i ka haawiia mai māhele o ka iaiyoe hualoaʻa ma ka henua pololei waiwai o `T`.
/// Hoʻohana 'ana i kekahi māhele o ka iaiyoe i kikokiko ai me ka `T` i paka me kekahi helu kuhi waiwai o `T` mea undefined kolohe.
///
/// Note e hiki ina na ka pono mānewanewa kanikau nui ('helu * size_of: :<T>() `) O `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// E pili ana i ka helu kuhi cia:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Kulu i ka waiwai i mālama ʻia ma o ka hoʻokahuli ʻana i ka `Box<T>` me kahi kuhikuhi pono ʻole.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ma keia wahi, hoʻohana 'ole e kahe mai ana `v` hualoaʻa ma undefined kolohe.
/// // drop(v); // ERROR
///
/// // O leaking `v` "uses" ia, a nolaila mea undefined kolohe.
/// // mem::forget(v); // ERROR
///
/// // I ka mea, `v` mea kūponoʻole ma muli o ka walaʻauʻana typeʻia invariants, no laila,*kekahi* hana no ia mea undefined kolohe.
/////
/// // e v2 =V;//hewa
///
/// unsafe {
///     // E mākou kahi i loko o ka henua pololei cia
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // I kēia manawa ua maikaʻi ka pahu
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: ʻo ka ʻaelike palekana no `write_bytes` pono e kākoʻo ʻia e ka mea e kāhea ana.
    unsafe { write_bytes(dst, val, count) }
}