//! Nā hana manuahi e hana iā `&[T]` a me `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Hana i kahi ʻāpana mai kahi kuhikuhi a me ka lōʻihi.
///
/// Ke `len` i kekahi manaʻo hoʻopiʻi o ka helu ana o **oihana mua**, i ka helu o nāʻai.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `data` pono e [valid] no ka heluhelu ʻana no `len * mem::size_of::<T>()` mau bytes, a pono e hoʻopili pono ʻia.ʻO kēia ke ʻano:
///
///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.E ʻike iā [below](#incorrect-usage) no kahi laʻana e lalau ʻole ana i kēia i ka moʻokāki.
///     * `data` pono e non-null a hoʻopili pono ʻia no nā ʻāpana ʻole-lōʻihi.
///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
///
/// * `data` pono e kuhikuhi iā `len` i ka helu kūpono i hoʻokumu mua ʻia o ke ʻano `T`.
///
/// * ʻO ka hoʻomanaʻo i kuhikuhi ʻia e ka ʻāpana i hoʻihoʻi ʻia ʻaʻole pono e hoʻololi ʻia no ka lōʻihi o ke ola `'a`, koe wale nō i loko o `UnsafeCell`.
///
/// * ʻAʻole pono ka nui o ka nui `len * mem::size_of::<T>()` o ka ʻāpana ma mua o `isize::MAX`.
///   E ʻike i nā palapala palekana o [`pointer::offset`].
///
/// # Caveat
///
/// Hoʻomanaʻo ʻia ke ola no ka ʻāpana i hoʻihoʻi ʻia mai ka hoʻohana ʻia ʻana.
/// I mea e pale aku ai i ka hoʻohana hewa kolohe ʻole ʻia
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // e hōʻike i kahi ʻāpana no kahi mea hoʻokahi
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Hoʻohana kūpono ʻole
///
/// ʻO ka hana `join_slices` aʻe he **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Hōʻike ka ʻōlelo ma luna i ka pili o `fst` a me `snd`, akā aia nō paha i loko o _different allocated objects_, kahi e hana nei i kēia ʻāpana he ʻano kūpono ʻole.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` a me `b` nā mea ʻokoʻa i hoʻokaʻawale ʻia ...
///     let a = 42;
///     let b = 27;
///     // ... kahi e waiho contiguently i ka hoʻomanaʻo: |he |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Hana i nā hana like me [`from_raw_parts`], koe wale nō i hoʻihoʻi ʻia kahi ʻāpana i hiki ke hoʻololi.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `data` pono e [valid] no nā heluhelu ʻelua a kākau no `len * mem::size_of::<T>()` i nā bytes he nui, a pono e hoʻopili pono ʻia.ʻO kēia ke ʻano:
///
///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.
///     * `data` pono e non-null a hoʻopili pono ʻia no nā ʻāpana ʻole-lōʻihi.
///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
///
///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
///
/// * `data` pono e kuhikuhi iā `len` i ka helu kūpono i hoʻokumu mua ʻia o ke ʻano `T`.
///
/// * ʻO ka hoʻomanaʻo i kuhikuhi ʻia e ka ʻāpana i hoʻihoʻi ʻia ʻaʻole pono e kiʻi ʻia ma o nā kuhikuhi ʻē aʻe (ʻaʻole i lawe ʻia mai ka waiwai hoʻihoʻi) no ka lōʻihi o ke ola `'a`.
///   Pāpā ʻia nā mea heluhelu a kākau.
///
/// * ʻAʻole pono ka nui o ka nui `len * mem::size_of::<T>()` o ka ʻāpana ma mua o `isize::MAX`.
///   E ʻike i nā palapala palekana o [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Hoʻololi i kahi kuhikuhi iā T i kahi ʻāpana o ka lōʻihi 1 (me ke kope ʻole).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Hoʻololi i kahi kuhikuhi iā T i kahi ʻāpana o ka lōʻihi 1 (me ke kope ʻole).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}