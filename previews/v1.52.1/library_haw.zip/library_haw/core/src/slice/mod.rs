// ignore-tidy-filelength

//! Hoʻoponopono i ka ʻāpana a me ka hoʻoponopono ʻana.
//!
//! No ka ʻike hou aku e ʻike iā [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// ʻO ka hoʻokō Zchrust0Z memchr pono, lawe ʻia mai rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// He lehulehu wale kēia hana no ka mea ʻaʻohe ala ʻē aʻe e hoʻokau ai i ka heapsort hoʻokolohua.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Hoʻihoʻi i ka helu o nā mea i ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: kani ke kani no ka mea lawe mākou i ka lōʻihi i kahi mea hoʻohana (ʻo ia nō)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: palekana kēia no ka mea aia iā `&[T]` a me `FatPtr<T>` ke ʻano like.
            // Hiki iā `std` ke hana i kēia hōʻoia.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: E kuapo me `crate::ptr::metadata(self)` ke kūpaʻa kēlā.
            // E like me kēia kākau ʻana he kumu kēia no ka hewa "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Ke palekana nei ke kiʻi ʻana i ka waiwai mai ka hui `PtrRepr` mai ka * const T
            // a me nā PtrComponents<T>i nā hoʻonohonoho hoʻomanaʻo like.
            // Hiki iā std ke hana i kēia hōʻoia.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Hoʻi iā `true` inā lōʻihi ka lōʻihi o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hoʻihoʻi i ka mea mua o ka ʻāpana, a i ʻole `None` inā nele.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Hoʻihoʻi i kahi kuhikuhi kuhi i ka mea mua o ka ʻāpana, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Hoʻihoʻi i ka mea mua a me ke koena o nā mea o ka ʻāpana, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Hoʻihoʻi i ka mea mua a me ke koena o nā mea o ka ʻāpana, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Hoʻihoʻi i ka hope a me nā koena a pau o nā ʻāpana o ka ʻāpana, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hoʻihoʻi i ka hope a me nā koena a pau o nā ʻāpana o ka ʻāpana, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Hoʻihoʻi i ka mea hope loa o ka ʻāpana, a i ʻole `None` inā nele.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Hoʻihoʻi i kahi kuhikuhi kuhi i ka mea hope loa i ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// E hoʻihoʻi i kahi kuhikuhi i kahi kumumea a i ʻole nā kau inoa e pili ana i ka ʻano o ka papa kuhikuhi.
    ///
    /// - Inā hāʻawi ʻia i kahi kūlana, hoʻihoʻi i kahi kuhikuhi i ka mea i kēlā kūlana a i ʻole `None` inā ma waho o nā palena.
    ///
    /// - Inā hāʻawi ʻia i kahi pae, e hoʻihoʻi i ka subslice e kūlike ana i kēlā pae, a i ʻole `None` inā ma waho o nā palena.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i kahi mea a i ʻole ka lawelawe inoa e pili ana i ka ʻano o ka papa kuhikuhi (ʻike [`get`]) a i ʻole `None` inā aia ka papa kuhikuhi ma waho o nā palena.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// E hoʻihoʻi i kahi kuhikuhi i kahi mea a i ʻole ka lawelawe, me ka hana ʻole ʻana i nā palena.
    ///
    /// No kahi koho palekana e ʻike iā [`get`].
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana me ka papa kuhikuhi ma waho o nā palena palena ʻo *[hana ʻole i hoʻoholo ʻia]* ʻoiai inā ʻaʻole hoʻohana ʻia ke kūmole hopena.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka hapa nui o nā koi palekana no `get_unchecked`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &*index.get_unchecked(self) }
    }

    /// E hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i kahi mea a i ʻole ka lawena, me ka hana ʻole ʻana i nā palena.
    ///
    /// No kahi koho palekana e ʻike iā [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana me ka papa kuhikuhi ma waho o nā palena palena ʻo *[hana ʻole i hoʻoholo ʻia]* ʻoiai inā ʻaʻole hoʻohana ʻia ke kūmole hopena.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: pono e mālama ka mea kelepona i nā koi palekana no `get_unchecked_mut`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Hoʻi i ka maka laʻau kuhikuhi ana i ka māhele o ka aooa.
    ///
    /// Pono ka mea e kāhea ana e hōʻoia i ka ola o ka ʻāpana i ka pointer i hoʻi kēia hana, a i ʻole a e hoʻopau paha i ke kuhikuhi ʻana i nā ʻōpala.
    ///
    /// Pono e hōʻoia ka mea e kelepona ana ʻaʻole e kākau ʻia ka hoʻomanaʻo o ka poʻomanaʻo (non-transitively) (koe wale nō i loko o `UnsafeCell`) me ka hoʻohana ʻana i kēia kuhikuhi a i ʻole nā kuhikuhi i loaʻa iā ia.
    /// Inā pono ʻoe e hoʻololi i nā ʻike o ka ʻāpana, e hoʻohana iā [`as_mut_ptr`].
    ///
    /// Ke hoʻololi nei i ka ipu i kuhikuhi ʻia e kēia ʻāpana i kumu e hoʻoili ʻia ai kāna buffer, a he mea ʻole ia e kuhikuhi ʻia kekahi mau kuhikuhi iā ia.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Hoʻihoʻi i kahi kuhikuhi kuhi palekana ʻole i ka buffer o ka ʻāpana.
    ///
    /// Pono ka mea e kāhea ana e hōʻoia i ka ola o ka ʻāpana i ka pointer i hoʻi kēia hana, a i ʻole a e hoʻopau paha i ke kuhikuhi ʻana i nā ʻōpala.
    ///
    /// Ke hoʻololi nei i ka ipu i kuhikuhi ʻia e kēia ʻāpana i kumu e hoʻoili ʻia ai kāna buffer, a he mea ʻole ia e kuhikuhi ʻia kekahi mau kuhikuhi iā ia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Hoʻihoʻi i nā kuhuhi maka ʻelua e ʻanā i ka ʻāpana.
    ///
    /// ʻO ka palena i hoʻihoʻi ʻia he hāmama hāmama, ʻo ia hoʻi ke kiko kuhikuhi hope *hoʻokahi i hala* ka mea hope loa o ka ʻāpana.
    /// Kēia ala, ua hōʻike ʻia kahi ʻāpana hakahaka e nā kuhikahi like ʻelua, a ʻo ka ʻokoʻa ma waena o nā kuhikuhi ʻelua i ka nui o ka ʻāpana.
    ///
    /// E ʻike iā [`as_ptr`] no nā ʻōlelo aʻoaʻo no ka hoʻohana ʻana i kēia mau kuhikuhi.Pono ka pointer hopena e akahele, no ka mea, ʻaʻole ia e kuhikuhi i kahi pono kūpono i ka ʻāpana.
    ///
    /// Pono kēia hana no ka launa pū ʻana me nā mea ʻē ʻē e hoʻohana i nā kuhikuhi ʻelua e kuhikuhi i kahi pae o nā mea i ka hoʻomanaʻo, e like me ka maʻamau ma C++ .
    ///
    ///
    /// Hiki iā ia ke lilo i mea pono e nānā inā kuhikuhi kahi kuhikuhi i kahi mea i kekahi kumu o kēia ʻāpana.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: Palekana ka `add` ma aneʻi, no ka mea:
        //
        //   - ʻO nā kuhi ʻelua nā ʻāpana o ka mea like, e like me ke kuhikuhi pololei ʻana i ka mea.
        //
        //   - ʻAʻole i ʻoi aku ka nui o ka ʻāpana ma mua o isize::MAX bytes, e like me ka mea i kākau ʻia ma aneʻi:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - ʻAʻohe mea hoʻopili e pili ana, no ka mea ʻaʻole wahī ʻia nā ʻāpana ma mua o ka pau ʻana o ka wahi kamaʻilio.
        //
        // E ʻike i nā palapala o pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Hoʻoiho i nā kuhi mutable ʻelua palekana ʻole e kau ana i ka ʻāpana.
    ///
    /// ʻO ka palena i hoʻihoʻi ʻia he hāmama hāmama, ʻo ia hoʻi ke kiko kuhikuhi hope *hoʻokahi i hala* ka mea hope loa o ka ʻāpana.
    /// Kēia ala, ua hōʻike ʻia kahi ʻāpana hakahaka e nā kuhikahi like ʻelua, a ʻo ka ʻokoʻa ma waena o nā kuhikuhi ʻelua i ka nui o ka ʻāpana.
    ///
    /// E ʻike iā [`as_mut_ptr`] no nā ʻōlelo aʻoaʻo no ka hoʻohana ʻana i kēia mau kuhikuhi.
    /// Ka hopena laʻau kuhikuhi pono keu mālama nui, e like me ka mea aole i kuhikuhi i ka henua pololei hehee ai i loko o ka māhele.
    ///
    /// Pono kēia hana no ka launa pū ʻana me nā mea ʻē ʻē e hoʻohana i nā kuhikuhi ʻelua e kuhikuhi i kahi pae o nā mea i ka hoʻomanaʻo, e like me ka maʻamau ma C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETY: E ʻike iā as_ptr_range() ma luna no ke aha e palekana ai ʻo `add`.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Kuapo i nā mea ʻelua i ka ʻāpana.
    ///
    /// # Arguments
    ///
    /// * a, Ka papa kuhikuhi o nā mea mua
    /// * b, Ka papa kuhikuhi o ka ʻaoʻao ʻelua
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `a` a `b` paha i waho o nā palena.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ʻAʻole hiki ke lawe i ʻelua mau hōʻaiʻē hoʻololi ʻia mai hoʻokahi vector, no laila e hoʻohana i nā kuhikuhi maka.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: Ua hana ʻia ʻo `pa` a me `pb` mai nā kūmole hiki ke hoʻololi a palekana
        // i nā mea i ka ʻāpana a no laila e hōʻoiaʻiʻo ʻia e kūpono a hoʻopili ʻia.
        // E hoʻomaopopo i ke kiʻi ʻana i nā mea ma hope o `a` a me `b` ke nānā ʻia a panic ke hele i waho o nā palena.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Hoʻohuli i ke kaʻina o nā mea i ka ʻāpana, ma kahi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // No nā ʻano liʻiliʻi loa, heluhelu ka poʻe āpau i ke ala maʻamau e hana maikaʻi ʻole.
        // Hiki iā mākou ke hana ʻoi aku ka maikaʻi, hāʻawi ʻia i ka load/store unaligned kūpono, ma ka hoʻouka ʻana i kahi chunk nui aʻe a hoʻohuli i kahi papa inoa.
        //

        // Maikaʻi ʻo LLVM e hana ai i kēia na mākou, no ka mea, ua ʻike ʻoi aku ka maikaʻi ma mua o kā mākou hana inā maikaʻi paha nā heluhelu unaligned (ʻoiai ka hoʻololi ma waena o nā mana ARM like ʻole) a me ka nui o ka chunk nui loa.
        // Minamina, e pili ana iā LLVM 4.0 (2017-05) wehe wale ia i ka loop, no laila pono mākou e hana i kēia iho.
        // (Kuhiakau: hoʻopilikia i ka hope no ka mea hiki ke hoʻopili i nā ʻaoʻao ʻokoʻa-e lilo, ke ʻano ʻē ka lōʻihi-no laila ʻaʻohe ala o ka emitting mua ʻana a me postludes e hoʻohana pono i ka SIMD i waena.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // E hoʻohana i ka llvm.bswap intrinsic e hoʻohuli i nā u8s i kahi usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Nui a hewahewa nā mea e nānā ai ma aneʻi:
                //
                // - E hoʻomaopopo he X a 8 paha ka `chunk` ma muli o ka helu CFg ma luna.No laila `chunk - 1` maikaʻi.
                // - Maikaʻi ka papa inoa ʻana me ka helu `i` e like me nā hoʻohiki o ka loop loop
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Maikaʻi ka papa inoa ʻana me ka index `ln - i - chunk = ln - (i + chunk)`:
                //   - `i + chunk > 0` ʻoiaʻiʻo ʻole ia.
                //   - Hōʻoia ka loop loop:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, no laila ʻaʻole e kahe ana ka hoʻoliʻiliʻi.
                // - Maikaʻi ke kāhea ʻana o `read_unaligned` a me `write_unaligned`:
                //   - `pa` kuhikuhi i ka helu `i` ma kahi `i < ln / 2 - (chunk - 1)` (ʻike ma luna) a me `pb` kiko i ka papa kuhikuhi `ln - i - chunk`, no laila aia ma ka liʻiliʻi `chunk` mau bytes mai ka hopena o `self`.
                //
                //   - Kūpono ʻia kekahi hoʻomanaʻo i hoʻomaka mua ʻia `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // E hoʻohana i ka rotate-by-16 e hoʻohuli i nā u16 i kahi u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Hiki ke heluhelu ʻia i kahi u32 unaligned mai `i` inā `i + 1 < ln`
                // (a maopopo `i < ln`), no ka mea, he 2 bytes kēlā me kēia meheu a ke heluhelu nei mākou iā 4.
                //
                // `i + chunk - 1 < ln / 2` # ʻoiai ke kūlana
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // ʻOiai ʻoi aku ka liʻiliʻi ma mua o ka lōʻihi i māhele ʻia e 2, a laila ma nā palena.
                //
                // ʻO ia hoʻi ka mea e mahalo mau ʻia ke ʻano `0 < i + chunk <= ln`, e hōʻoia ana i ka hiki ke hoʻohana palekana ʻia ka pointer `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: ʻoi aku ka haʻahaʻa o `i` i ka hapalua o ka lōʻihi o ka ʻāpana
            // ke komo nei i ka `i` a me ka `ln - i - 1` palekana (hoʻomaka ʻo `i` ma 0 a ʻaʻole hele i mua o `ln / 2 - 1`).
            // No laila ua kuhi nā kuhi `pa` a me `pb` a ua kaulike ʻia, a hiki ke heluhelu ʻia a kākau ʻia i.
            //
            //
            unsafe {
                // Kuapo palekana ʻole e hōʻalo i nā palena palena i ke kuapo palekana.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Hoʻihoʻi i kahi iterator ma luna o kahi ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Hoʻihoʻi i kahi iterator e hiki ai ke hoʻololi i kēlā me kēia waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā windows āpau āpau o ka lōʻihi `size`.
    /// Pākuʻi ʻia ka windows.
    /// Inā ʻoi aku ka pōkole o ka ʻāpana ma mua o `size`, hoʻi ʻole ka iterator i nā kumukūʻai.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Inā ʻoi aku ka pōkole o ka ʻāpana ma mua o `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `chunk_size` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana a ʻaʻole hoʻopili.Inā ʻaʻole ʻo `chunk_size` e puʻunaue i ka lōʻihi o ka ʻāpana, a laila ʻaʻole lōʻihi ka lōʻihi `chunk_size`.
    ///
    /// E ʻike iā [`chunks_exact`] no kahi ʻano like ʻole o kēia iterator e hoʻihoʻi i nā ʻāpana o nā manawa `chunk_size` mau, a me [`rchunks`] no ka iterator like akā hoʻomaka i ka hopena o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `chunk_size` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana hiki ke hoʻololi ʻia, a mai hoʻopili ʻole.Inā ʻaʻole ʻo `chunk_size` e puʻunaue i ka lōʻihi o ka ʻāpana, a laila ʻaʻole lōʻihi ka lōʻihi `chunk_size`.
    ///
    /// E ʻike iā [`chunks_exact_mut`] no kahi ʻano like ʻole o kēia iterator e hoʻihoʻi i nā ʻāpana o nā manawa `chunk_size` mau, a me [`rchunks_mut`] no ka iterator like akā hoʻomaka i ka hopena o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `chunk_size` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana a ʻaʻole hoʻopili.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `chunk_size` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `chunk_size-1` a hiki ke kiʻi ʻia mai ka hana `remainder` o ka iterator.
    ///
    ///
    /// Ma muli o kēlā me kēia chunk loaʻa pololei nā `chunk_size` mau mea, hiki i ka mea hōʻuluʻulu ke hoʻokau pinepine i ke code hopena ma mua o ka hihia o [`chunks`].
    ///
    /// E nānā i [`chunks`] no ka Lolina o keia iterator mea no hoi, e huli hou i ke koena me ka liʻiliʻi chunk, a me [`rchunks_exact`] no ka mea ia iterator akā, e hoʻomaka ana i ka pau ana o ka māhele.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `chunk_size` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana hiki ke hoʻololi ʻia, a mai hoʻopili ʻole.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `chunk_size` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `chunk_size-1` a hiki ke kiʻi ʻia mai ka hana `into_remainder` o ka iterator.
    ///
    ///
    /// Ma muli o kēlā me kēia chunk loaʻa pololei nā `chunk_size` mau mea, hiki i ka mea hōʻuluʻulu ke hoʻokau pinepine i ke code hopena ma mua o ka hihia o [`chunks_mut`].
    ///
    /// E ʻike iā [`chunks_mut`] no ka mea ʻokoʻa o kēia iterator e hoʻihoʻi pū i ke koena ma ke ʻano he chunk liʻiliʻi, a me [`rchunks_exact_mut`] no ka iterator like akā hoʻomaka i ka hopena o ka ʻāpana.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Māhele i ka ʻāpana i kahi ʻāpana o nā 'N'-element arrays, ke manaʻo nei ʻaʻohe koena.
    ///
    ///
    /// # Safety
    ///
    /// Kāhea ʻia kēia wale nō ke
    /// - Māhele pololei ka ʻāpana i nā ʻāpana N-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: ʻaʻohe koena o nā chunks 1-element
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: ʻO ka lōʻihi o ka lōʻihi (6) kahi mau o 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Kuhi ʻole kēia mau mea:
    /// // e hoʻokuʻu i nā ʻāpana: &[[_;5]]= slice.as_chunks_unchecked()//ʻAʻole lōʻihi ka lōʻihi o ka lōʻihi o 5 e hoʻokuʻu i nā ʻāpana:&[[_;0]]=ʻAʻole ʻae ʻia nā ʻāpana slice.as_chunks_unchecked()//Zero-length
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: ʻO kā mākou precondition ka mea e pono ai e kāhea i kēia
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Hoʻolei mākou i kahi ʻāpana o `new_len * N` mau mea i loko
        // i kahi ʻāpana o `new_len` mau ʻāpana `N` nui.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Mahae ka māhele i loko o ka māhele o ka 'N`-hehee ai huihui ikehu lā, e hoʻomaka ana i ka hoʻomaka o ka māhele, a me he koena māhele me ka lōʻihi pololei emi ma mua o `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Ua makaʻu mua mākou no ka ʻole, a hōʻoia ʻia e ke kūkulu ʻana
        // ʻo ka lōʻihi o ka sublice he mau manawa he nui o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Hoʻokaʻawale i kahi ʻāpana i kahi ʻāpana o nā 'N'-element arrays, e hoʻomaka ana ma ka hopena o ka ʻāpana, a me kahi ʻāpana i koe me ka lōʻihi i emi ma lalo o `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Ua makaʻu mua mākou no ka ʻole, a hōʻoia ʻia e ke kūkulu ʻana
        // ʻo ka lōʻihi o ka sublice he mau manawa he nui o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `N` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana nā kuhi kuhikuhi a ʻaʻole hoʻopili.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `N` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `N-1` a hiki ke kiʻi ʻia mai ka hana `remainder` o ka iterator.
    ///
    ///
    /// ʻO kēia ʻano hana ka like generic o [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Māhele i ka ʻāpana i kahi ʻāpana o nā 'N'-element arrays, ke manaʻo nei ʻaʻohe koena.
    ///
    ///
    /// # Safety
    ///
    /// Kāhea ʻia kēia wale nō ke
    /// - Māhele pololei ka ʻāpana i nā ʻāpana N-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: ʻaʻohe koena o nā chunks 1-element
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: ʻO ka lōʻihi o ka lōʻihi (6) kahi mau o 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Kuhi ʻole kēia mau mea:
    /// // e hoʻokuʻu i nā ʻāpana: &[[_;5]]= slice.as_chunks_unchecked_mut()//ʻAʻole lōʻihi ka lōʻihi o ka lōʻihi o 5 e hoʻokuʻu i nā ʻāpana:&[[_;0]]=ʻAʻole ʻae ʻia nā ʻāpana slice.as_chunks_unchecked_mut()//Zero-length
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: ʻO kā mākou precondition ka mea e pono ai e kāhea i kēia
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Hoʻolei mākou i kahi ʻāpana o `new_len * N` mau mea i loko
        // i kahi ʻāpana o `new_len` mau ʻāpana `N` nui.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Mahae ka māhele i loko o ka māhele o ka 'N`-hehee ai huihui ikehu lā, e hoʻomaka ana i ka hoʻomaka o ka māhele, a me he koena māhele me ka lōʻihi pololei emi ma mua o `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Ua makaʻu mua mākou no ka ʻole, a hōʻoia ʻia e ke kūkulu ʻana
        // ʻo ka lōʻihi o ka sublice he mau manawa he nui o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Hoʻokaʻawale i kahi ʻāpana i kahi ʻāpana o nā 'N'-element arrays, e hoʻomaka ana ma ka hopena o ka ʻāpana, a me kahi ʻāpana i koe me ka lōʻihi i emi ma lalo o `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Ua makaʻu mua mākou no ka ʻole, a hōʻoia ʻia e ke kūkulu ʻana
        // ʻo ka lōʻihi o ka sublice he mau manawa he nui o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea `N` o ka ʻāpana i kēlā me kēia manawa, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    /// ʻO nā ʻāpana nā papa kuhikuhi kuhi hiki ʻole ke hoʻololi ʻia a mai hoʻopili ʻole.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `N` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `N-1` a hiki ke kiʻi ʻia mai ka hana `into_remainder` o ka iterator.
    ///
    ///
    /// ʻO kēia ʻano hana ka like generic o [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0. ʻO kēia kaha e hoʻololi paha i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o ka overlaping windows o nā `N` o kahi ʻāpana, e hoʻomaka ana i ka hoʻomaka o ka ʻāpana.
    ///
    ///
    /// ʻO kēia ka like generic o [`windows`].
    ///
    /// Inā ʻoi aku ka nui o `N` ma mua o ka nui o ka ʻāpana, e hoʻi ʻole ia i windows.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `N` ka 0.
    /// E loli paha kēia huli i kahi hewa manawa hōʻuluʻulu ma mua o ka paʻa ʻana o kēia ʻano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Hoʻi he iterator ma luna o `chunk_size` oihana mua o ka māhele i ka manawa, e hoʻomaka ana i ka pau ana o ka māhele.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana a ʻaʻole hoʻopili.Inā ʻaʻole ʻo `chunk_size` e puʻunaue i ka lōʻihi o ka ʻāpana, a laila ʻaʻole lōʻihi ka lōʻihi `chunk_size`.
    ///
    /// E ʻike iā [`rchunks_exact`] no kahi ʻano like ʻole o kēia iterator e hoʻihoʻi i nā ʻāpana o nā manawa `chunk_size` mau, a me [`chunks`] no ka mea like akā hoʻomaka i ka hoʻomaka o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Hoʻi he iterator ma luna o `chunk_size` oihana mua o ka māhele i ka manawa, e hoʻomaka ana i ka pau ana o ka māhele.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana hiki ke hoʻololi ʻia, a mai hoʻopili ʻole.Inā ʻaʻole ʻo `chunk_size` e puʻunaue i ka lōʻihi o ka ʻāpana, a laila ʻaʻole lōʻihi ka lōʻihi `chunk_size`.
    ///
    /// E ʻike iā [`rchunks_exact_mut`] no kahi ʻano like ʻole o kēia iterator e hoʻihoʻi i nā ʻāpana o nā manawa `chunk_size` mau, a me [`chunks_mut`] no ka mea like akā hoʻomaka i ka hoʻomaka o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Hoʻi he iterator ma luna o `chunk_size` oihana mua o ka māhele i ka manawa, e hoʻomaka ana i ka pau ana o ka māhele.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana a ʻaʻole hoʻopili.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `chunk_size` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `chunk_size-1` a hiki ke kiʻi ʻia mai ka hana `remainder` o ka iterator.
    ///
    /// Ma muli o kēlā me kēia chunk loaʻa pololei nā `chunk_size` mau mea, hiki i ka mea hōʻuluʻulu ke hoʻokau pinepine i ke code hopena ma mua o ka hihia o [`chunks`].
    ///
    /// E ʻike iā [`rchunks`] no kahi ʻano like o kēia iterator e hoʻihoʻi pū i ke koena ma ke ʻano he chunk liʻiliʻi, a me [`chunks_exact`] no ka iterator like akā hoʻomaka i ka hoʻomaka o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Hoʻi he iterator ma luna o `chunk_size` oihana mua o ka māhele i ka manawa, e hoʻomaka ana i ka pau ana o ka māhele.
    ///
    /// ʻO nā ʻāpana he mau ʻāpana hiki ke hoʻololi ʻia, a mai hoʻopili ʻole.
    /// Inā ʻaʻole hoʻokaʻawale ʻo `chunk_size` i ka lōʻihi o ka ʻāpana, a laila e haʻalele ʻia ka mea hope loa a hiki i ka `chunk_size-1` a hiki ke kiʻi ʻia mai ka hana `into_remainder` o ka iterator.
    ///
    /// Ma muli o kēlā me kēia chunk loaʻa pololei nā `chunk_size` mau mea, hiki i ka mea hōʻuluʻulu ke hoʻokau pinepine i ke code hopena ma mua o ka hihia o [`chunks_mut`].
    ///
    /// E ʻike iā [`rchunks_mut`] no kahi ʻano like o kēia iterator e hoʻihoʻi pū i ke koena ma ke ʻano he chunk liʻiliʻi, a me [`chunks_exact_mut`] no ka iterator like akā hoʻomaka i ka hoʻomaka o ka ʻāpana.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `chunk_size` ka 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o ka ʻāpana e hana ana i nā holo non-overlaping o nā mea e hoʻohana ana i ka predicate e hoʻokaʻawale iā lākou.
    ///
    /// Kāhea ʻia ka predicate ma luna o nā mea ʻelua ma hope o lākou iho, ʻo ia ka mea i kāhea ʻia ka predicate ma `slice[0]` a me `slice[1]` a laila ma `slice[1]` a me `slice[2]` a pēlā aku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hiki ke hoʻohana i kēia hana e huki i nā kau inoa i hoʻokaʻina ʻia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o ka ʻāpana e hana ana i nā holo i hiki ʻole ke hoʻopili ʻia o nā mea e hoʻohana ana i ka predicate e hoʻokaʻawale iā lākou.
    ///
    /// Kāhea ʻia ka predicate ma luna o nā mea ʻelua ma hope o lākou iho, ʻo ia ka mea i kāhea ʻia ka predicate ma `slice[0]` a me `slice[1]` a laila ma `slice[1]` a me `slice[2]` a pēlā aku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hiki ke hoʻohana i kēia hana e huki i nā kau inoa i hoʻokaʻina ʻia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Māhele i hoʻokahi ʻāpana i ʻelua ma ka papa kuhikuhi.
    ///
    /// Ka mea mua, e komo a pau indices, mai `[0, mid)` (Ma waho aʻeo ka i ka 'inideka `mid` iho) a me ka lua, e komo a pau indices, mai `[mid, len)` (Ma waho aʻeo ka i ka' inideka `len` iho).
    ///
    ///
    /// # Panics
    ///
    /// Panics inā `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` a me `[mid; len]` ma loko o `self`, kahi
        // hoʻokō i nā koina o `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Māhele i hoʻokahi ʻāpana i hiki ke hoʻololi ʻia i ʻelua ma ka papa kuhikuhi.
    ///
    /// Ka mea mua, e komo a pau indices, mai `[0, mid)` (Ma waho aʻeo ka i ka 'inideka `mid` iho) a me ka lua, e komo a pau indices, mai `[mid, len)` (Ma waho aʻeo ka i ka' inideka `len` iho).
    ///
    ///
    /// # Panics
    ///
    /// Panics inā `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` a me `[mid; len]` ma loko o `self`, kahi
        // hoʻokō i nā koina o `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Māhele i hoʻokahi ʻāpana i ʻelua ma ka papa kuhikuhi, me ka hana ʻole ʻana i nā palena.
    ///
    /// Ka mea mua, e komo a pau indices, mai `[0, mid)` (Ma waho aʻeo ka i ka 'inideka `mid` iho) a me ka lua, e komo a pau indices, mai `[mid, len)` (Ma waho aʻeo ka i ka' inideka `len` iho).
    ///
    ///
    /// No kahi koho palekana e ʻike iā [`split_at`].
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana me ka papa kuhikuhi ma waho o nā palena palena ʻo *[hana ʻole i hoʻoholo ʻia]* ʻoiai inā ʻaʻole hoʻohana ʻia ke kūmole hopena.Pono ka mea e kāhea e hōʻoia iā `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: Pono ka mea kelepona e nānā i kēlā `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Māhele i hoʻokahi ʻāpana i hiki ke hoʻololi ʻia i ʻelua ma ka papa kuhikuhi, me ka hana ʻole ʻana i nā palena.
    ///
    /// Ka mea mua, e komo a pau indices, mai `[0, mid)` (Ma waho aʻeo ka i ka 'inideka `mid` iho) a me ka lua, e komo a pau indices, mai `[mid, len)` (Ma waho aʻeo ka i ka' inideka `len` iho).
    ///
    ///
    /// No kahi koho palekana e ʻike iā [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana me ka papa kuhikuhi ma waho o nā palena palena ʻo *[hana ʻole i hoʻoholo ʻia]* ʻoiai inā ʻaʻole hoʻohana ʻia ke kūmole hopena.Pono ka mea e kāhea e hōʻoia iā `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: Pono ka mea kelepona e nānā i kēlā `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` a me `[mid; len]` ʻaʻole hoʻopili, no laila ke hoʻi nei i kahi kūmole hiki ke hoʻololi.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred`.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Inā kūlike ka mea mua, ʻo kahi ʻāpana hakahaka ka mea mua i hoʻihoʻi ʻia e ka iterator.
    /// Pēlā nō, inā kūlike ka mea hope loa o ka ʻāpana, ʻo kahi ʻāpana hakahaka ka mea hope loa i hoʻihoʻi ʻia e ka iterator.
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Inā pili pono ʻelua mau mea i kūlike, e loaʻa kahi ʻāpana hakahaka ma waena o lākou.
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā leka i hoʻololi ʻia i hoʻokaʻawale ʻia e nā mea e like me `pred`.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred`.
    /// Aia ka mea i kūlike i ka hopena o ka subslice i hala ma ke ʻano he terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Inā kūlike ka mea hope o ka ʻāpana, e manaʻo ʻia kēlā mea i ka terminator o ka ʻāpana o mua.
    ///
    /// Ua māhele nō ia i ka hope aia hoi ma ka iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā leka i hoʻololi ʻia i hoʻokaʻawale ʻia e nā mea e like me `pred`.
    /// Aia ka mea i hoʻohālikelike ʻia i loko o ka subslice mua ma ke ʻano he terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred`, e hoʻomaka ana ma ka hopena o kahi ʻāpana a hana i hope.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// E like me `split()`, inā kūlike ka mea mua a hope paha, ʻo kahi ʻāpana hakahaka ka mea mua (a i ʻole hope) i hoʻihoʻi ʻia e ka iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā loli hoʻololi i hoʻokaʻawale ʻia e nā mea e like me `pred`, e hoʻomaka ana ma ka hopena o kahi ʻāpana a hana i hope.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred`, kaupalena ʻia i ka hoʻi ʻana i nā mea `n` nui loa.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// Ua hoʻihoʻi ʻia ka mea hope loa, inā loaʻa, e loaʻa ke koena o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// E paʻi i ka māhele i hoʻokaʻawale ʻia e nā helu i hiki ke hoʻokaʻawale ʻia e 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred`, kaupalena ʻia i ka hoʻi ʻana i nā mea `n` nui loa.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// Ua hoʻihoʻi ʻia ka mea hope loa, inā loaʻa, e loaʻa ke koena o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred` i kaupalena ʻia i ka hoʻi ʻana ma ka hapanui o nā huahana `n`.
    /// Hoʻomaka kēia ma ka hopena o ka ʻāpana a hana i hope.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// Ua hoʻihoʻi ʻia ka mea hope loa, inā loaʻa, e loaʻa ke koena o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// E paʻi i ka ʻāpana i ka manawa hoʻokahi, e hoʻomaka ana mai ka hopena, i nā helu i hiki ke hoʻokaʻawale ʻia e 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Hoʻihoʻi i kahi iterator ma luna o nā mea lawelawe i hoʻokaʻawale ʻia e nā mea e like me `pred` i kaupalena ʻia i ka hoʻi ʻana ma ka hapanui o nā huahana `n`.
    /// Hoʻomaka kēia ma ka hopena o ka ʻāpana a hana i hope.
    /// ʻAʻole i loko o nā mea kau ʻia ke kumu hoʻohālikelike.
    ///
    /// Ua hoʻihoʻi ʻia ka mea hope loa, inā loaʻa, e loaʻa ke koena o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Hoʻi iā `true` inā loaʻa kahi ʻāpana i kahi ʻāpana me ka waiwai i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Inā ʻaʻohe ou `&T`, akā he `&U` wale nō e like me kēlā `T: Borrow<U>` (e laʻa
    /// ʻĀpana: ʻaiʻē<str>`), hiki iā ʻoe ke hoʻohana iā `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ʻāpana o `String`
    /// assert!(v.iter().any(|e| e == "hello")); // e ʻimi me `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Hoʻi iā `true` inā `needle` i kahi mua o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Hoʻi mau iā `true` inā he ʻāpana hakahaka ʻo `needle`:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Hoʻi iā `true` inā ʻo `needle` kahi kikoʻī o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Hoʻi mau iā `true` inā he ʻāpana hakahaka ʻo `needle`:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Hoʻi i kahi leka me ka unuhi mua.
    ///
    /// Inā hoʻomaka ka ʻāpana me `prefix`, hoʻihoʻi i ka papa inoa ma hope o ka pīpī pīpī, wahī ʻia i `Some`.
    /// Inā hakahaka ʻo `prefix`, hoʻihoʻi wale i ka ʻāpana kumu.
    ///
    /// Inā ʻaʻole hoʻomaka kahi ʻāpana me `prefix`, hoʻihoʻi iā `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Pono kēia hana e kākau hou inā a ʻoi aku ka maʻalahi o SlicePattern.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Hoʻi i kahi kau inoa me ka hope i lawe ʻia.
    ///
    /// Inā pau ka ʻāpana me `suffix`, hoʻihoʻi i ka papa inoa ma mua o ka hope, i wahī ʻia i `Some`.
    /// Inā hakahaka ʻo `suffix`, hoʻihoʻi wale i ka ʻāpana kumu.
    ///
    /// Inā ʻaʻole e pau ka ʻāpana me `suffix`, hoʻihoʻi iā `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Pono kēia hana e kākau hou inā a ʻoi aku ka maʻalahi o SlicePattern.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ʻImi ʻo Binary i kēia ʻāpana i hoʻokaʻina ʻia no kahi ʻenehana i hāʻawi ʻia.
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.
    /// Inā he mea mau ihoiho, a laila, hiki ke hoʻi kekahi i kekahi o na ihoiho.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    ///
    /// E nānā pū [`binary_search_by`], [`binary_search_by_key`], a me [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā.
    /// Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Inā makemake ʻoe e hoʻokomo i kahi mea i vector i hoʻokaʻina ʻia, ʻoiai e mālama nei i ka ʻoka ʻoka:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Huli ʻo Binary i kēia ʻāpana i hoʻonohonoho ʻia me kahi hana hoʻohālikelike.
    ///
    /// Pono e hoʻokō i ka hana hoʻohālikelike i kahi kauoha e kūlike me ka ʻoka hoʻonohonoho o ka ʻāpana o lalo, e hoʻihoʻi ana i kahi code hoʻonohonoho e hōʻike ana inā `Less`, `Equal` a i ʻole `Greater` ka manaʻo i makemake ʻia.
    ///
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.Inā he nui nā match, a laila hiki ke hoʻihoʻi ʻia kekahi o nā pāʻani.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    /// E nānā pū [`binary_search`], [`binary_search_by_key`], a me [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā.Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SAFETY: mālama palekana ʻia ke kāhea e nā poʻe invariants aʻe:
            // - `mid >= 0`
            // - `mid < size`: Hoʻopili ʻia ʻo `mid` e `[left; right)` paʻa.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // ʻO ke kumu a mākou e hoʻohana ai i ka kahe if/else kahe ma mua o ke kūlike no ka mea hoʻoponopono hou nā hoʻokūkū hoʻohālikelike i nā hana, kahi mea maʻalahi.
            //
            // ʻO x86 asm kēia no u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Huli ʻo Binary i kēia ʻāpana i hoʻonohonoho ʻia me kahi hana ʻoki kī.
    ///
    /// Kuhi ʻia e hoʻokaʻawale ʻia kahi ʻāpana e ke kī, e laʻa me [`sort_by_key`] me ka hoʻohana ʻana i ka hana ʻoki kī hoʻokahi.
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.
    /// Inā he mea mau ihoiho, a laila, hiki ke hoʻi kekahi i kekahi o na ihoiho.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    ///
    /// E nānā pū [`binary_search`], [`binary_search_by`], a me [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā i kahi ʻāpana o nā hui i hoʻokaʻawale ʻia e ko lākou mau ʻaoʻao ʻelua.
    /// Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // ʻAe ʻia ʻo Lint rustdoc::broken_intra_doc_links ʻoiai ʻo `slice::sort_by_key` ma crate `alloc`, a no ka mea ʻaʻole i kēia manawa ke kūkulu `core`.
    //
    // nā loulou i lalo o crate: #74481.No ka mea ua palapala wale ʻia nā primitives i ka libstd (#73423), ʻaʻole loa kēia e alakaʻi i nā loulou haʻihaʻi i ka hana.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Hoʻokaʻawale i ka ʻāpana, akā ʻaʻole hiki ke mālama i ke kaʻina o nā mea like.
    ///
    /// Paʻa ʻole kēia ʻano (ie, hiki ke hoʻonohonoho hou i nā mea like), ma kahi (ie, ʻaʻole hoʻokaʻawale), a me *O*(*n*\*log(* n*)) ʻoi loa ka hihia.
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma [pattern-defeating quicksort][pdqsort] e Orson Peters, kahi e hoʻohui ai i ka hihia awelika wikiwiki o ka quicksort me ka hihia ʻoi loa o ka heapsort, ʻoiai e loaʻa ana ka manawa laina i nā ʻoki me kekahi mau hiʻohiʻona.
    /// Hoʻohana ia i kekahi randomization e hōʻalo i nā hihia degenerate, akā me kahi seed paʻa e hāʻawi mau i ka hana deterministic.
    ///
    /// ʻOi aku ka wikiwiki o ia ma mua o ka hoʻonohonoho paʻa ʻana, koe wale nō i kekahi mau hihia kūikawā, e laʻa me ka ʻāpana o nā ʻāpana hoʻokaʻawale concatenated i hoʻonohonoho ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Hoʻokaʻawale i ka ʻāpana me kahi hana hoʻohālikelike, akā ʻaʻole e mālama i ke kaʻina o nā mea like.
    ///
    /// Paʻa ʻole kēia ʻano (ie, hiki ke hoʻonohonoho hou i nā mea like), ma kahi (ie, ʻaʻole hoʻokaʻawale), a me *O*(*n*\*log(* n*)) ʻoi loa ka hihia.
    ///
    /// Pono e wehewehe i ka hana hoʻohālikelike i kahi hoʻonohonoho holoʻokoʻa no nā mea i ka ʻāpana.Inā ʻaʻole piha ka hoʻonohonoho ʻana, ʻaʻole hōʻike ʻia ke ʻano o nā mea.ʻO kahi ʻoka kahi ʻoka holoʻokoʻa inā (no nā `a`, `b` a me `c`) a pau:
    ///
    /// * huina a me antisymmetric: pololei kekahi o `a < b`, `a == b` a i ʻole `a > b` ʻoiaʻiʻo, a
    /// * transitive, `a < b` a me `b < c` e hōʻike nei iā `a < c`.Pono e paʻa ka mea like no `==` a me `>`.
    ///
    /// ʻO kahi laʻana, ʻoiai ʻaʻole [`f64`] e hoʻokō iā [`Ord`] ma muli o `NaN != NaN`, hiki iā mākou ke hoʻohana i `partial_cmp` e like me kā mākou ʻano hana ke ʻike mākou i ka ʻāpana i kahi `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma [pattern-defeating quicksort][pdqsort] e Orson Peters, kahi e hoʻohui ai i ka hihia awelika wikiwiki o ka quicksort me ka hihia ʻoi loa o ka heapsort, ʻoiai e loaʻa ana ka manawa laina i nā ʻoki me kekahi mau hiʻohiʻona.
    /// Hoʻohana ia i kekahi randomization e hōʻalo i nā hihia degenerate, akā me kahi seed paʻa e hāʻawi mau i ka hana deterministic.
    ///
    /// ʻOi aku ka wikiwiki o ia ma mua o ka hoʻonohonoho paʻa ʻana, koe wale nō i kekahi mau hihia kūikawā, e laʻa me ka ʻāpana o nā ʻāpana hoʻokaʻawale concatenated i hoʻonohonoho ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // hoʻoliʻiliʻi hoʻoliʻiliʻi
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Hoʻokaʻawale i ka ʻāpana me kahi hana hemo kī, akā ʻaʻole mālama ʻia ke ʻano o nā mea like.
    ///
    /// Paʻa ʻole kēia ʻano (ie, hiki ke hoʻonohonoho hou i nā mea like), ma kahi (ie, ʻaʻole hoʻokaʻawale), a me *O*(m\* * n *\* log(*n*)) hihia maikaʻi loa, kahi o ka hana nui ʻo *O*(*m*).
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma [pattern-defeating quicksort][pdqsort] e Orson Peters, kahi e hoʻohui ai i ka hihia awelika wikiwiki o ka quicksort me ka hihia ʻoi loa o ka heapsort, ʻoiai e loaʻa ana ka manawa laina i nā ʻoki me kekahi mau hiʻohiʻona.
    /// Hoʻohana ia i kekahi randomization e hōʻalo i nā hihia degenerate, akā me kahi seed paʻa e hāʻawi mau i ka hana deterministic.
    ///
    /// Ma muli o kāna kāhea kāhea nui, e lohi paha ʻo [`sort_unstable_by_key`](#method.sort_unstable_by_key) ma mua o [`sort_by_cached_key`](#method.sort_by_cached_key) i nā hihia kahi e pipiʻi ai ka hana kī.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Hoʻonohonoho hou i ka ʻāpana e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Hoʻonohonoho hou i ka ʻāpana me kahi hana hoʻohālikelike e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Hoʻonohonoho hou i ka ʻāpana me kahi hana hemo kī e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Hoʻonohonoho hou i ka ʻāpana e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    ///
    /// He waiwai hou aʻe kēia hoʻonohonoho hou ʻana e ʻoi aku ka liʻiliʻi ma mua o ka waiwai o kekahi waiwai ma ke kūlana `i < index` ma kahi kūlana `j > index`.
    /// Hoʻopili ia, kūpaʻa kēia hoʻonohonoho hou ʻana (ie
    /// e pau paha kekahi mau helu like i ke kūlana `index`), ma kahi (ie
    /// ʻaʻole hoʻokaʻawale), a me *O*(*n*) hihia ʻino loa.
    /// ʻIke ʻia a ʻike ʻia kēia hana ma "kth element" i nā waihona puke ʻē aʻe.
    /// Hoʻihoʻi ia i kahi kolamu o nā helu aʻe: ʻo nā mea āpau i emi ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia, ka waiwai ma ka papa kuhikuhi i hāʻawi ʻia, a me nā mea āpau i ʻoi aku ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia.
    ///
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma ka ʻāpana wikiwiki o ka like algorithm wikiwiki i hoʻohana ʻia no [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ke `index >= len()`, ʻo ia hoʻi panics mau ma nā ʻāpana hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // E ʻike i ka median
    /// v.select_nth_unstable(2);
    ///
    /// // Hoʻopaʻa wale ʻia mākou i kahi ʻāpana kekahi o kēia mau mea, e pili ana i ke ʻano a mākou e hoʻokaʻawale ai e pili ana i ka papa kuhikuhi i kuhikuhi ʻia.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Hoʻonohonoho hou i ka ʻāpana me kahi hana hoʻohālikelike e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    ///
    /// Loaʻa i kēia hoʻonohonoho hou ʻana ka waiwai hou aʻe e hoʻemi ʻia a ʻoi ʻole paha ke kumukūʻai ma ke kūlana `i < index` ma mua a i ʻole e like me kekahi waiwai i kahi kūlana `j > index` e hoʻohana ana i ka hana hoʻohālikelike.
    /// Hoʻohui ʻia, paʻa ʻole kēia hoʻonohonoho hou ʻana (ʻo ia paha e pau nā helu o nā mea like i ke kūlana `index`), ma kahi (ʻaʻole hāʻawi ʻia kēia), a me *O*(*n*) hihia maikaʻi loa.
    /// Hoʻomaopopo ʻia kēia hana ʻo "kth element" i nā waihona puke ʻē aʻe.
    /// Hoʻihoʻi ia i kahi kolamu o nā helu aʻe: ʻo nā mea āpau i emi ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia, ka waiwai ma ka papa kuhikuhi i hāʻawi ʻia, a me nā mea āpau i ʻoi aku ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia, e hoʻohana ana i ka hana hoʻohālikelike i hāʻawi ʻia.
    ///
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma ka ʻāpana wikiwiki o ka like algorithm wikiwiki i hoʻohana ʻia no [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ke `index >= len()`, ʻo ia hoʻi panics mau ma nā ʻāpana hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // E ʻike i ka mediane me he mea lā ua hoʻokaʻawale ʻia kahi ʻāpana i ke kaʻina e iho ai.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Hoʻopaʻa wale ʻia mākou i kahi ʻāpana kekahi o kēia mau mea, e pili ana i ke ʻano a mākou e hoʻokaʻawale ai e pili ana i ka papa kuhikuhi i kuhikuhi ʻia.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Hoʻonohonoho hou i ka ʻāpana me kahi hana hemo kī e like me ka mea ma `index` ma kāna kūlana hoʻonohonoho hope.
    ///
    /// He waiwai hou aʻe kēia hoʻonohonoho hou ʻana e ʻoi aku ka liʻiliʻi ma mua o ka waiwai o kēlā me kēia waiwai ma ke kūlana `i < index` ma ke kūlana `j > index` me ka hoʻohana ʻana i ka hana unuhi kī.
    /// Hoʻohui ʻia, paʻa ʻole kēia hoʻonohonoho hou ʻana (ʻo ia paha e pau nā helu o nā mea like i ke kūlana `index`), ma kahi (ʻaʻole hāʻawi ʻia kēia), a me *O*(*n*) hihia maikaʻi loa.
    /// Hoʻomaopopo ʻia kēia hana ʻo "kth element" i nā waihona puke ʻē aʻe.
    /// Hoʻihoʻi ia i kahi kolamu o nā helu aʻe: ʻo nā mea āpau i emi ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia, ka waiwai ma ka papa kuhikuhi i hāʻawi ʻia, a me nā mea āpau i ʻoi aku ma mua o ka mea ma ka papa kuhikuhi i hāʻawi ʻia, e hoʻohana ana i ka hana unuhi kī i hāʻawi ʻia.
    ///
    ///
    /// # Ke hoʻokō ʻia nei
    ///
    /// Hoʻokumu ʻia ka algorithm i kēia manawa ma ka ʻāpana wikiwiki o ka like algorithm wikiwiki i hoʻohana ʻia no [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ke `index >= len()`, ʻo ia hoʻi panics mau ma nā ʻāpana hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // E hoʻi i ka Media me ina ka hoʻouka i hoʻokaʻina 'e like me ka loa nui.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Hoʻopaʻa wale ʻia mākou i kahi ʻāpana kekahi o kēia mau mea, e pili ana i ke ʻano a mākou e hoʻokaʻawale ai e pili ana i ka papa kuhikuhi i kuhikuhi ʻia.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// E hoʻoneʻe i nā ʻaoʻao āpau i ka hopena o ka ʻāpana e like me ka [`PartialEq`] trait hoʻokō.
    ///
    ///
    /// Hoʻihoʻi i nā ʻāpana ʻelua.ʻAʻohe o nā mea i hana ʻia i ka mea mua.
    /// Loaʻa ka lua i nā kope āpau i ʻole hoʻonohonoho kikoʻī.
    ///
    /// Inā hoʻokaʻawale ʻia kahi ʻāpana, ʻaʻohe kope o ka ʻāpana i hoʻi mua ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Hoʻoneʻe i nā mea āpau akā ʻo ka mua o nā mea pili i ka hopena o ka ʻāpana e hōʻoluʻolu i kahi pili like i hāʻawi ʻia.
    ///
    /// Hoʻihoʻi i nā ʻāpana ʻelua.ʻAʻohe o nā mea i hana ʻia i ka mea mua.
    /// Loaʻa ka lua i nā kope āpau i ʻole hoʻonohonoho kikoʻī.
    ///
    /// Hoʻouna ʻia ka hana `same_bucket` i nā kūmole i ʻelua mau ʻaoʻao mai ka ʻāpana a pono e hoʻoholo inā hoʻohālikelike nā mea like.
    /// Hoʻoholo ʻia nā mea i ka ʻaoʻao ʻē aʻe mai kā lākou papa i ka ʻāpana, no laila inā hoʻi ʻo `same_bucket(a, b)` i `true`, hoʻoneʻe ʻia ʻo `a` ma ka hopena o ka ʻāpana.
    ///
    ///
    /// Inā hoʻokaʻawale ʻia kahi ʻāpana, ʻaʻohe kope o ka ʻāpana i hoʻi mua ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // ʻOiai loaʻa iā mākou kahi kuhikuhi mutable i `self`, ʻaʻole hiki iā mākou ke hana i nā hoʻololi *arbitrary*.Hiki i nā kāhea `same_bucket` ke panic, no laila pono mākou e hōʻoia i kahi ʻāpana i kahi kūlana kūpono i nā manawa āpau.
        //
        // ʻO ke ala a mākou e lawelawe ai i kēia ma ka hoʻohana ʻana i nā swaps;mākou iterate ma nā mea a pau o nā kumu mua, swapping me mākou e hele aku ai ia i ka hopena o nā kumu mua mākou makemake e mālama i loko o ka mua, a me ka poe mākou makemake i ka ai ia e hoole i ma ka hope.
        // Hiki iā mākou ke hoʻokaʻawale i kahi ʻāpana.
        // ʻO `O(n)` kēia hana.
        //
        // Laʻana: Hoʻomaka mākou i kēia mokuʻāina, kahi e hōʻike ai ʻo `r` "aʻe
        // heluhelu "a `w` kū i ka" hope_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ke kapakai a self[r] ku pakiko [w,-1], keia mea,ʻaʻole heʻia kekahi mau mea, no laila, ua kuapo self[r] a me self[w] (ʻaʻohe kanawai me R==w), a laila, xi nā R a me ka w, ua waiho oia no me:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ke hoʻohālikelike nei iā self[r] e kūʻē iā ʻoe iho [w-1], he kope kēia waiwai, no laila hoʻonui mākou i ka `r` akā waiho i nā mea āpau āpau ʻole.
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ke hoʻohālikelike nei iā self[r] e kūʻē iā ʻoe iho [w-1], ʻaʻole kēia he mea i kope ʻia, no laila e hoʻololi iā self[r] a me self[w] a e holo mua r a w.
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ʻAʻole kope, hana hou:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Pālua, advance r. End o kahi ʻāpana.Wāwahi ʻia ma w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: hōʻoia ka `while` i ka `next_read` a me `next_write`
        // ma lalo o `len`, no laila aia i loko o `self`.
        // `prev_ptr_write` kuhikuhi i hoʻokahi mea ma mua o `ptr_write`, akā hoʻomaka ʻo `next_write` ma 1, no laila ʻaʻole emi ka `prev_ptr_write` ma lalo o 0 a aia i loko o ka ʻāpana.
        // Mālama kēia i nā koi no ka dereferencing `ptr_read`, `prev_ptr_write` a me `ptr_write`, a no ka hoʻohana ʻana i `ptr.add(next_read)`, `ptr.add(next_write - 1)` a me `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ua hoʻonui ʻia i ka manawa hoʻokahi ma ka loop i ka nui loa o ka manaʻo ʻaʻohe kumu o ka lele ʻana ke pono ia e kuapo.
        //
        // `ptr_read` a me `prev_ptr_write` loa kuhikuhi i ka ia hehee ai.Koi ʻia kēia no ka `&mut *ptr_read`, `&mut* prev_ptr_write` e palekana.
        // Maʻalahi ka wehewehe ʻana he mau nō ka `next_read >= next_write`, no laila ʻo `next_read > next_write - 1` kekahi.
        //
        //
        //
        //
        //
        unsafe {
            // Hōʻalo i nā loiloi palena palena ma o ka hoʻohana ʻana i nā kuhi maka.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// E hoʻoneʻe i nā mea āpau akā ʻo ka mua o nā mea pili i ka hopena o ka ʻāpana e hoʻoholo i ke kī like.
    ///
    ///
    /// Hoʻihoʻi i nā ʻāpana ʻelua.ʻAʻohe o nā mea i hana ʻia i ka mea mua.
    /// Loaʻa ka lua i nā kope āpau i ʻole hoʻonohonoho kikoʻī.
    ///
    /// Inā hoʻokaʻawale ʻia kahi ʻāpana, ʻaʻohe kope o ka ʻāpana i hoʻi mua ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Hoʻohuli i ka ʻāpana i kahi e neʻe ai nā mea `mid` mua o ka ʻāpana i ka hopena ʻoiai e neʻe ana nā mea `self.len() - mid` hope loa i mua.
    /// Ma hope o ke kāhea ʻana iā `rotate_left`, ʻo ka mea ma mua ma ka helu `mid` e lilo i mea mua i ka ʻāpana.
    ///
    /// # Panics
    ///
    /// E panic kēia hana inā ʻoi aku ka nui o `mid` ma mua o ka lōʻihi o ka ʻāpana.E hoʻomaopopo he `mid == self.len()` ka _not_ panic a he hoʻohuli no-op.
    ///
    /// # Complexity
    ///
    /// Lawe i ka laina (i ka manawa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Ke hoʻohuli nei i kahi kauā:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: ʻO ka laulā `[p.add(mid) - mid, p.add(mid) + k)` he mea liʻiliʻi
        // kūpono no ka heluhelu ʻana a me ke kākau ʻana, e like me ke koi a `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Hoʻohuli i ka ʻāpana i kahi e neʻe ai nā mea `self.len() - k` mua o ka ʻāpana i ka hopena ʻoiai e neʻe ana nā mea `k` hope loa i mua.
    /// Ma hope o ke kāhea ʻana iā `rotate_right`, ʻo ka mea ma mua ma ka helu `self.len() - k` e lilo i mea mua i ka ʻāpana.
    ///
    /// # Panics
    ///
    /// E panic kēia hana inā ʻoi aku ka nui o `k` ma mua o ka lōʻihi o ka ʻāpana.E hoʻomaopopo he `k == self.len()` ka _not_ panic a he hoʻohuli no-op.
    ///
    /// # Complexity
    ///
    /// Lawe i ka laina (i ka manawa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Hoʻohuli i kahi kauā:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: ʻO ka laulā `[p.add(mid) - mid, p.add(mid) + k)` he mea liʻiliʻi
        // kūpono no ka heluhelu ʻana a me ke kākau ʻana, e like me ke koi a `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Hoʻopiha ʻo `self` i nā mea e ka cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Hoʻopiha iā `self` me nā mea i hoʻihoʻi ʻia e ke kāhea pinepine ʻana i kahi pani.
    ///
    /// Hoʻohana kēia hana i ka pani ʻana e hana i nā waiwai hou.Inā makemake ʻoe iā [`Clone`] i kahi waiwai i hāʻawi ʻia, e hoʻohana iā [`fill`].
    /// Inā makemake ʻoe e hoʻohana i ka [`Default`] trait e hana i nā waiwai, hiki iā ʻoe ke hala i [`Default::default`] ma ke ʻano he hoʻopaʻapaʻa.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// E kope i nā mea mai `src` a i `self`.
    ///
    /// Pono ka lōʻihi o `src` e like me `self`.
    ///
    /// Inā hoʻokomo ʻo `T` iā `Copy`, hiki ke hana hou aku i ka hoʻohana ʻana iā [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Kēia papa, e panic ina na slices elua i okoa ka loa.
    ///
    /// # Examples
    ///
    /// ʻO ka cloning ʻelua mau mea mai kahi ʻāpana i kahi ʻē aʻe:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ma muli o ka lōʻihi like o nā ʻāpana, ʻoki mākou i ka ʻāpana kumu mai ʻehā mau mea a i ʻelua.
    /// // E panic inā ʻaʻole mākou e hana i kēia.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Hoʻoikaika ʻo Rust i ka hiki ke lilo i hoʻokahi kūmole hiki ke hoʻololi ʻia me ka ʻole o nā kuhikuhi hiki ʻole ke hoʻololi ʻia i kahi ʻikepili i kahi kikoʻī kikoʻī.
    /// Ma muli o kēia, ʻo ka hoʻāʻo ʻana e hoʻohana i `clone_from_slice` ma kahi ʻāpana hoʻokahi e hopena i kahi kīnā ʻole.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// E hana a puni kēia, hiki iā mākou ke hoʻohana i [`split_at_mut`] e hana i ʻelua mau ʻāpana ʻāpana ʻokoʻa mai kahi ʻāpana:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// E kope i nā mea āpau mai `src` a i `self`, me ka hoʻohana ʻana i kahi memcpy.
    ///
    /// Pono ka lōʻihi o `src` e like me `self`.
    ///
    /// Inā ʻaʻole hoʻokomo ʻo `T` iā `Copy`, e hoʻohana iā [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Kēia papa, e panic ina na slices elua i okoa ka loa.
    ///
    /// # Examples
    ///
    /// Ke kope ʻana i ʻelua mau mea mai kahi ʻāpana i kahi ʻē aʻe:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ma muli o ka lōʻihi like o nā ʻāpana, ʻoki mākou i ka ʻāpana kumu mai ʻehā mau mea a i ʻelua.
    /// // E panic inā ʻaʻole mākou e hana i kēia.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Hoʻoikaika ʻo Rust i ka hiki ke lilo i hoʻokahi kūmole hiki ke hoʻololi ʻia me ka ʻole o nā kuhikuhi hiki ʻole ke hoʻololi ʻia i kahi ʻikepili i kahi kikoʻī kikoʻī.
    /// Ma muli o kēia, ʻo ka hoʻāʻo ʻana e hoʻohana i `copy_from_slice` ma kahi ʻāpana hoʻokahi e hopena i kahi kīnā ʻole.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// E hana a puni kēia, hiki iā mākou ke hoʻohana i [`split_at_mut`] e hana i ʻelua mau ʻāpana ʻāpana ʻokoʻa mai kahi ʻāpana:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Hoʻokomo ʻia ke ala kuhi panic i kahi hana anuanu e hoʻoliʻiliʻi ʻole i ka pūnaewele kāhea.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // Maluhia: `self` mea i pololei ia no `self.len()` nā kumumea ma ka ho'ākāka 'ana, a me ka `src` ua
        // hōʻoia ʻia e like ka lōʻihi.
        // ʻAʻole hiki i nā ʻāpana ke hoʻopili aku no ka mea he kū hoʻokahi nā ʻōlelo mutable.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kope i nā mea mai kekahi ʻāpana o ka ʻāpana i kahi ʻāpana o ia iho, e hoʻohana ana i kahi memmove.
    ///
    /// `src` ʻo ia ka pae i loko o `self` e kope ai.
    /// `dest` ʻo ia ka papa kuhikuhi hoʻomaka o ka laulā ma waena o `self` e kope i, kahi e like ai ka lōʻihi me `src`.
    /// Pili paha nā pae ʻelua.
    /// Pono nā wēlau o nā pae ʻelua ma lalo o a i ʻole like me `self.len()`.
    ///
    /// # Panics
    ///
    /// E panic kēia hana inā ʻoi aku ka nui o kahi pae i ka hopena o kahi ʻāpana, a i ʻole inā ʻo ka hopena o `src` ma mua o ka hoʻomaka.
    ///
    ///
    /// # Examples
    ///
    /// Ke kope ʻana i nā bytes ʻehā ma loko o kahi ʻāpana:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: ua nānā ʻia nā kūlana no `ptr::copy` ma luna,
        // e like me kēlā no `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Kuapo i nā mea āpau i `self` me kēlā mau mea i `other`.
    ///
    /// Pono ka lōʻihi o `other` e like me `self`.
    ///
    /// # Panics
    ///
    /// Kēia papa, e panic ina na slices elua i okoa ka loa.
    ///
    /// # Example
    ///
    /// Ke hoʻololi nei i ʻelua mau mea ma nā ʻāpana:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Hoʻoikaika ʻo Rust i ka hiki ke lilo i hoʻokahi kuhikuhi mutable i kahi ʻikepili kikoʻī i kahi kikoʻī kikoʻī.
    ///
    /// Ma muli o kēia, ʻo ka hoʻāʻo ʻana e hoʻohana i `swap_with_slice` ma kahi ʻāpana hoʻokahi e hopena i kahi kīnā ʻole.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// E hana a puni kēia, hiki iā mākou ke hoʻohana i [`split_at_mut`] e hana i ʻelua mau ʻāpana sub-mutable ʻokoʻa mai kahi ʻāpana.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // Maluhia: `self` mea i pololei ia no `self.len()` nā kumumea ma ka ho'ākāka 'ana, a me ka `src` ua
        // hōʻoia ʻia e like ka lōʻihi.
        // ʻAʻole hiki i nā ʻāpana ke hoʻopili aku no ka mea he kū hoʻokahi nā ʻōlelo mutable.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Hana e helu i nā lōʻihi o ka ʻāpana waena a me ka trailing no `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // He aha kā mākou e hana ai e pili ana i `rest` ke koho nei i nā mea he nui o nā ʻU e hiki ai iā mākou ke waiho i kahi helu haʻahaʻa loa o nā.
        //
        // A ehia mākou e pono ai no kēlā me kēia "multiple".
        //
        // E noʻonoʻo e laʻa me T=u8 U=u16.A laila hiki iā mākou ke hoʻokomo iā 1 U i 2 Ts.Simple.
        // I kēia manawa, e noʻonoʻo e laʻa me kahi hihia kahi size_of: :<T>=16, ka nui_of::<U>=24.</u>
        // Hiki iā mākou ke hoʻokau iā 2 Us ma kahi o kēlā me kēia 3 Ts i ka ʻāpana `rest`.
        // ʻOi aku ka paʻakikī.
        //
        // Kumumanaʻo e helu ai i kēia:
        //
        // Kākou= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Hoʻonui a maʻalahi hoʻi:
        //
        // Kākou=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Laki ʻoiai ke loiloi mau ʻia kēia mau mea āpau ... hana ʻole ma aneʻi ʻole.
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Iterative stein's algorithm Pono mākou e hana i kēia `const fn` (a hoʻi hou i ka algorithm recursive inā mākou e hana) no ka mea ke hilinaʻi nei i ka llvm e kūʻē i kēia mau mea āpau ... maikaʻi, hōʻoluʻolu ʻole wau.
            //
            //

            // SAFETY: Nānā ʻia ʻo `a` a me `b` i mau waiwai ʻole-ʻole.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // Wehe i nā kumu āpau o 2 mai b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: Nānā ʻia ʻo `b` i non-zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Me ka ʻike me kēia ʻike, hiki iā mākou ke loaʻa i ka nui o nā ʻU e hiki iā mākou ke kūpono!
        let us_len = self.len() / ts * us;
        // A ehia mau mea ʻe i ka ʻāpana trailing!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Hoʻololi i ka ʻāpana i kahi ʻāpana o kahi ʻano ʻē aʻe, e mālama pono i ka hoʻopili ʻana o nā ʻano.
    ///
    /// Hoʻokaʻawale kēia hana i ka ʻāpana i ʻekolu mau ʻoki ʻoki: kuhuna kuhikuhipuʻuone, hoʻopili pono ʻia i ka ʻāpana waena o kahi ʻano hou, a me ka ʻāpana hope.
    /// Hiki i ke kiʻina hana ke hana i ka ʻāpana waena i ka lōʻihi ʻoi loa no kahi ʻano i hāʻawi ʻia a me kahi ʻāpana hoʻokomo, akā ʻo ka hana a kāu algorithm wale nō e pili i kēlā, ʻaʻole kona pololei.
    ///
    /// ʻAe ʻia no ka hoʻihoʻi ʻia ʻana o ka ʻikepili hoʻokomo e like me ka pīpī a i ʻole ka ʻāpana o ka hope.
    ///
    /// ʻAʻohe kumu o kēia ʻano hana ke loaʻa ka huina komo `T` a i ʻole ka huina `U` i ka nui a e hoʻi hou i ka ʻāpana kumu me ka ʻole o ka hoʻokaʻawale ʻana i kekahi mea.
    ///
    /// # Safety
    ///
    /// ʻO kēia ʻano hana he `transmute` e pili ana i nā mea i ka ʻāpana waena i hoʻihoʻi ʻia, no laila pili nā ana maʻamau āpau e pili ana iā `transmute::<T, U>` ma aneʻi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // E hoʻomaopopo i ka hapa nui o kēia hana e loiloi mau ʻia,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // lawelawe pono i nā ZST, ʻo ia hoʻi-mai lawelawe iki iā lākou.
            return (self, &[], &[]);
        }

        // ʻO ka mea mua, e ʻike i ke kiko e hoʻokaʻawale ai mākou ma waena o ka ʻāpana mua a me ka ʻelua.
        // Māmā me ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: E ʻike i ke ʻano `align_to_mut` no ka ʻōlelo hoʻopakele kikoʻī.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: i kēia manawa `rest` pili pono, no laila ua maikaʻi ʻo `from_raw_parts` ma lalo,
            // ʻoiai ka mea e hōʻoia ai hiki iā mākou ke transmute `T` i `U` me ka palekana.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Hoʻololi i ka ʻāpana i kahi ʻāpana o kahi ʻano ʻē aʻe, e mālama pono i ka hoʻopili ʻana o nā ʻano.
    ///
    /// Hoʻokaʻawale kēia hana i ka ʻāpana i ʻekolu mau ʻoki ʻoki: kuhuna kuhikuhipuʻuone, hoʻopili pono ʻia i ka ʻāpana waena o kahi ʻano hou, a me ka ʻāpana hope.
    /// Hiki i ke kiʻina hana ke hana i ka ʻāpana waena i ka lōʻihi ʻoi loa no kahi ʻano i hāʻawi ʻia a me kahi ʻāpana hoʻokomo, akā ʻo ka hana a kāu algorithm wale nō e pili i kēlā, ʻaʻole kona pololei.
    ///
    /// ʻAe ʻia no ka hoʻihoʻi ʻia ʻana o ka ʻikepili hoʻokomo e like me ka pīpī a i ʻole ka ʻāpana o ka hope.
    ///
    /// ʻAʻohe kumu o kēia ʻano hana ke loaʻa ka huina komo `T` a i ʻole ka huina `U` i ka nui a e hoʻi hou i ka ʻāpana kumu me ka ʻole o ka hoʻokaʻawale ʻana i kekahi mea.
    ///
    /// # Safety
    ///
    /// ʻO kēia ʻano hana he `transmute` e pili ana i nā mea i ka ʻāpana waena i hoʻihoʻi ʻia, no laila pili nā ana maʻamau āpau e pili ana iā `transmute::<T, U>` ma aneʻi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // E hoʻomaopopo i ka hapa nui o kēia hana e loiloi mau ʻia,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // lawelawe pono i nā ZST, ʻo ia hoʻi-mai lawelawe iki iā lākou.
            return (self, &mut [], &mut []);
        }

        // ʻO ka mea mua, e ʻike i ke kiko e hoʻokaʻawale ai mākou ma waena o ka ʻāpana mua a me ka ʻelua.
        // Māmā me ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Eia mākou ke hōʻoia nei e hoʻohana i nā kuhikuhi kuhikuhi no U no ka
        // koena o ka hana.Hana ʻia kēia ma ka waiho ʻana i kahi kuhikuhi i&[T] me kahi kaulike i hoʻokumu ʻia no U.
        // `crate::ptr::align_offset` ua kāhea ʻia me ka pololei kuhikuhi a pololei pointer `ptr` (hele mai ia mai kahi kuhikuhi i `self`) a me ka nui he mana ia o ʻelua (ʻoiai mai ka hoʻopili ʻana no U), e hōʻoluʻolu ana i kāna mau pale palekana.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // ʻAʻole hiki iā mākou ke hoʻohana hou iā `rest` ma hope o kēia, hōʻole ʻole ia i kona inoa `mut_ptr`!SAFETY: e nānā i nā manaʻo no `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Nānā inā hoʻonohonoho ʻia nā mea o kēia ʻāpana.
    ///
    /// ʻO ia, no kēlā me kēia meahana `a` a me kāna ʻaoʻao aʻe `b`, pono e paʻa ʻo `a <= b`.Inā hua pololei ka hua i hoʻokahi a i ʻole hoʻokahi mea, hoʻihoʻi ʻia ʻo `true`.
    ///
    /// E hoʻomaopopo inā ʻo `Self::Item` `PartialOrd` wale nō, akā ʻaʻole `Ord`, hōʻike ka wehewehe i luna e hoʻi kēia hana i `false` inā ʻaʻole hoʻohālikelike ʻia nā mea ʻelua ʻelua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Nānā inā hoʻonohonoho ʻia nā mea o kēia ʻāpana i ka hoʻohana ʻana i ka hana hoʻohālikelike i hāʻawi ʻia.
    ///
    /// Ma kahi o ka hoʻohana ʻana iā `PartialOrd::partial_cmp`, hoʻohana kēia hana i ka hana `compare` i hāʻawi ʻia e hoʻoholo ai i ka hoʻonohonoho ʻana o nā mea ʻelua.
    /// Kaawale mai ia, ua like ia me [`is_sorted`];ike kona nā moʻolelo no ka 'ike hou aku.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Nānā inā hoʻonohonoho ʻia nā mea o kēia ʻāpana i ka hoʻohana ʻana i ka hana ʻoki kī.
    ///
    /// Ma kahi o ka hoʻohālikelike pololei ʻana i nā ʻāpana o ka ʻāpana, hoʻohālikelike kēia hana i nā kī o nā mea, e like me ka hoʻoholo ʻana e `f`.
    /// Kaawale mai ia, ua like ia me [`is_sorted`];ike kona nā moʻolelo no ka 'ike hou aku.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// E hoʻihoʻi i ka papa kuhikuhi o ka pākākā e like me ka predicate i hāʻawi ʻia (ʻo ka helu o ka mea mua o ka ʻāpana ʻelua).
    ///
    /// Kuhi ʻia ka ʻāpana e hoʻokaʻawale ʻia e like me ka predicate i hāʻawi ʻia.
    /// ʻO kēia ke kumu o nā mea āpau e hoʻi ai ka predicate i ka hoʻomaka o ka ʻāpana a me nā mea āpau e hoʻi ai ka predicate i ka hopena.
    ///
    /// ʻO kahi laʻana, [7, 15, 3, 5, 4, 12, 6] he paku ma lalo o ka predicate x% 2!=0 (nā helu ʻē a pau i ka hoʻomaka, a pau i ka hopena).
    ///
    /// Inā ʻaʻole i hoʻokaʻawale ʻia kēia ʻāpana, ʻike ʻole ʻole ʻia ka hopena i hoʻihoʻi ʻia a hana ʻole ʻia kēia ʻano hana i kahi ʻano o ka huli binary.
    ///
    /// E nānā pū [`binary_search`], [`binary_search_by`], a me [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Ke `left < right`, `left <= mid < right`.
            // No laila hoʻonui mau ʻo `left` a hoʻemi mau ʻo `right`, a koho ʻia kekahi o lākou.I nā kūlana ʻelua ua māʻona ʻo `left <= right`.No ia mea, ina `left < right` ma no i koe, `left <= right` Ua hoomaona mai la oia ma ka ia mua.
            //
            // No laila ke lōʻihi o `left != right`, māʻona ʻo `0 <= left < right <= len` a inā ʻoluʻolu pū kēia hihia `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: E Pono e kūlike loa māhele ia i ka ia loa
        // i mea e maʻalahi ai no ka optimizer e elide palena palena ke kaha ʻana.
        // Akā no ka mea hiki ʻole ke hilinaʻi ʻia iā mākou he loiloi kūikawā no T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Hoʻokumu i kahi ʻāpana hakahaka.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Hoʻokumu i kahi ʻāpana hakahaka mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Kumu hoohalike ma slices, a ianoiyuaa a, wale hoʻohanaʻia `strip_prefix` a me `strip_suffix`.
/// Ma kahi kiko future, lana ko mākou manaʻo e hoʻonui i ka `core::str::Pattern` (ka mea ma ka manawa kākau e kaupalena ʻia i `str`) i nā ʻoki, a laila e pani a hoʻopau ʻia paha kēia trait.
///
pub trait SlicePattern {
    /// ʻO ke ʻano o ka ʻāpana i hoʻohālikelike ʻia.
    type Item;

    /// I kēia manawa, pono i nā mea kūʻai mai `SlicePattern` kahi ʻāpana.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}