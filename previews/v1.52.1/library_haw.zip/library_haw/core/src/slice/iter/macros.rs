//! Hoʻohana ʻia nā Macros e nā iterator o kahi ʻāpana.

// Hoʻokomo ʻia ʻo is_empty a len i kahi ʻano hana nui
macro_rules! is_empty {
    // Ke ala a mākou e encode ai i ka lōʻihi o kahi Zer iterator, hana kēia no ZST a me non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// No ka hoʻopau ʻana i kekahi mau kaha palena (e nānā iā `position`), helu mākou i ka lōʻihi i kahi ala i manaʻo ʻole ʻia.
// (Hōʻike ʻia e `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // hoʻohana ʻia mākou i kekahi manawa ma loko o kahi poloka palekana

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Hoʻohana kēia _cannot_ i ka `unchecked_sub` no ka mea ke hilinaʻi nei mākou i ka wahī ʻana e hōʻike i ka lōʻihi o ka lōʻihi ZST slice iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // ʻIke mākou i ka `start <= end`, no laila hiki ke hana i ka ʻoi aku ma mua o `offset_from`, kahi e pono ai ke hana pūlima ʻia.
            // Ma ke kau ʻana i nā hae kūpono ma aneʻi hiki iā mākou ke haʻi iā LLVM i kēia, ka mea e kōkua iā ia e hemo i nā kaha palena.
            // SAFETY: Na ka invariant ʻano, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ma ka haʻi ʻana aku iā LLVM ua hoʻokaʻawale ʻia nā kuhi ma kahi kikoʻī o ka nui o ka ʻano, hiki iā ia ke hoʻonui iā `len() == 0` a i ka `start == end` ma kahi o `(end - start) < size`.
            //
            // SAFETY: Na ke ʻano invariant, kaulike ʻia nā pointers no laila ka
            //         mamao ma waena o lākou pono e nui o ka pointee nui
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// ʻO ka wehewehe like ʻana o nā iterator `Iter` a me `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Hoʻihoʻi i ka mea mua a neʻe i ka hoʻomaka o ka iterator i mua e 1.
        // Hoʻonui maikaʻi i ka hana i hoʻohālikelike ʻia i kahi hana i hoʻopili ʻia.
        // Ke iterator pono,ʻaʻole e nele mai.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Hoʻihoʻi i ka mea hope loa a neʻe i ka hopena o ka iterator i hope e 1.
        // Hoʻonui maikaʻi i ka hana i hoʻohālikelike ʻia i kahi hana i hoʻopili ʻia.
        // Ke iterator pono,ʻaʻole e nele mai.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // E hoʻoliʻiliʻi i ka iterator ke Z ʻo T, ma ka neʻe ʻana i ka hopena o ka iterator i hope e `n`.
        // `n` pono ʻole ma mua o `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hana ka mea kōkua no ka hana ʻana i kahi ʻāpana mai ka iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: ua hoʻokumu ʻia ka iterator mai kahi ʻāpana me ka kuhikuhi
                // `self.ptr` a me ka lōʻihi `len!(self)`.
                // Hōʻoia kēia i nā pono āpau no `from_raw_parts` e hoʻokō ʻia.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hana ka mea kōkua no ka neʻe ʻana i ka hoʻomaka o ka iterator i mua e nā mea `offset`, e hoʻihoʻi nei i ka hoʻomaka mua.
            //
            // Palekana ʻole no ka mea ʻaʻole pono ka offset ma mua o `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: hōʻoia ka mea kelepona ʻaʻole ʻoi aku ka nui o `offset` i ka `self.len()`,
                    // no laila aia kēia pointer hou i loko o `self` a pēlā e hōʻoia ʻole ʻia ai.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hana ka mea kōkua no ka neʻe ʻana i ka hopena o ka iterator i hope e nā mea `offset`, e hoʻihoʻi nei i ka hopena hou.
            //
            // Palekana ʻole no ka mea ʻaʻole pono ka offset ma mua o `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: hōʻoia ka mea kelepona ʻaʻole ʻoi aku ka nui o `offset` i ka `self.len()`,
                    // ka mea e hōʻoia ʻia ʻaʻole e hoʻonui i `isize`.
                    // Nō hoʻi, ka mea kūpono laʻau kuhikuhi mea i loko o palena o `slice`, a hoʻokōʻana i nā koi no `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // hiki ke hoʻokō ʻia me nā ʻāpana, akā pale kēia i nā kaha

                // SAFETY: palekana nā kāhea `assume` mai ka kuhikuhi ʻana o kahi ʻāpana
                // pono e 'ole-Yard, a me slices ma' ole-ZSTs pono no hoi i ka pili-Yard hopena laʻau kuhikuhi.
                // Palekana ke kāhea iā `next_unchecked!` mai ka nānā ʻana inā nele ka iterator ma mua.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hakahaka kēia mea hoʻoiho.
                    if mem::size_of::<T>() == 0 {
                        // Pono mākou e hana i kēia ala ʻo `ptr` ʻaʻole loa he 0, akā hiki iā `end` (ma muli o ke kāwili).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // Maluhia: hope hiki ole e 0 inā T mea ole ZST no ka ptr mea ole 0 pau, a>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: Aia mākou i nā palena.Hana ʻo `post_inc_start` i ka mea kūpono no ZSTs kekahi.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            // Eia kekahi, pale ka `assume` i kahi kaha palena.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAFETY: hoʻohiki ʻia mākou ma nā palena e ka invariant loop:
                        // ka wā `i >= n`, `self.next()` huli `None` a me ka loop, mai hemo mai.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Hoʻohuli mākou i ka hoʻokō paʻamau, e hoʻohana nei i `try_fold`, no ka mea e hana ana kēia hana maʻalahi i ka liʻiliʻi ʻo LLVM IR a ʻoi aku ka wikiwiki o ka hōʻuluʻulu ʻana.
            // Eia kekahi, pale ka `assume` i kahi kaha palena.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` ma lalo o `n` mai ka hoʻomaka ʻana ma `n`
                        // a ke emi wale nei nō.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: pono i ka mea kelepona e hōʻoia i ka `i` i nā palena o
                // ʻo ka ʻāpana i lalo, no laila ʻaʻole hiki iā `i` ke hoʻonui i kahi `isize`, a hōʻoia ʻia nā ʻōlelo i hoʻihoʻi ʻia e kuhikuhi i kahi ʻāpana o ka ʻāpana a pēlā e hōʻoiaʻiʻo ʻia ai.
                //
                // Hoʻomaopopo pū ka mea e kāhea aku ai i ka poʻe e kāhea ana ʻaʻole mākou i kāhea hou ʻia me ka papa kuhikuhi like, a ʻaʻohe ʻano hana ʻē aʻe e hiki ai i kēia ʻāpana ke kāhea ʻia, no laila he kūpono ia no ka huli ʻana o ka ʻōlelo i hoʻihoʻi ʻia i hiki ke hoʻololi ʻia i ka hihia o
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // hiki ke hoʻokō ʻia me nā ʻāpana, akā pale kēia i nā kaha

                // SAFETY: palekana nā kāhea `assume` ma muli o ka ʻole ʻole o ka kuhikuhi o kahi ʻāpana.
                // a ʻo nā ʻāpana ma luna o nā ZST ʻole pono pū kekahi me ka ʻole kuhikuhi ʻole.
                // Ke kahea aku i `next_back_unchecked!` Ua pakele mai mākou e kaha ina ka iterator mea nele mua.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hakahaka kēia mea hoʻoiho.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: Aia mākou i nā palena.Hana ʻo `pre_dec_end` i ka mea kūpono no ZSTs kekahi.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}