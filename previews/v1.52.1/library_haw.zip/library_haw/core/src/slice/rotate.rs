// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Hoʻohuli i ka laulā `[mid-left, mid+right)` e like me ka mea ma `mid` i lilo i mea mua.Hoʻohālikelike, kaʻapuni i nā kikowaena `left` ma ka hema a i ʻole `right` mau mea i ka ʻākau.
///
/// # Safety
///
/// Pono ka pae i kuhikuhi ʻia no ka heluhelu ʻana a me ke kākau ʻana.
///
/// # Algorithm
///
/// Hoʻohana ʻia ka Algorithm 1 no nā waiwai liʻiliʻi o `left + right` a i ʻole no `T` nui.
/// Hoʻoneʻe ʻia nā mea i ko lākou kūlana hope i kēlā me kēia manawa e hoʻomaka ana ma `mid - left` a holomua e `right` ʻanuʻu modulo `left + right`, no ka mea hoʻokahi wale nō manawa e pono ai.
/// Ma ka hopena, hoʻi mākou i `mid - left`.
/// Eia nō naʻe, inā ʻaʻole ʻo `gcd(left + right, right)` ka 1, ua haʻalele ʻia nā ʻanuʻu o luna i luna o nā mea.
/// O kahi laʻana:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ʻO ka mea pōmaikaʻi, ʻo ka helu o nā skipping ma luna o nā mea ma waena o nā mea hope loa i kaulike mau ʻia, no laila hiki iā mākou ke offset i ko mākou kūlana hoʻomaka a hana i nā pōʻai hou (ʻo ka nui o nā pōʻaiapuni ka `gcd(left + right, right)` value).
///
/// ʻO ka hopena ka hopena o nā mea āpau i hoʻokahi a hoʻokahi wale nō manawa.
///
/// Hoʻohana ʻia ka Algorithm 2 inā nui ka `left + right` akā ua liʻiliʻi ʻo `min(left, right)` i mea e kau ai i kahi pale pale.
/// Kope kope ʻia nā mea `min(left, right)` ma luna o ka pale, noi ʻia ʻo `memmove` i nā mea ʻē aʻe, a hoʻoneʻe ʻia nā mea ma ka pale i loko o ka lua ma kēlā ʻaoʻao ʻaoʻao o kahi i hoʻomaka ai.
///
/// Nā Algorithms i hiki ke vectorized outperform ma luna o ka manawa `left + right` lilo nui lawa.
/// Hiki ke hoʻopili ʻia ke Algorithm 1 e ka chunking a me ka hana ʻana i nā pōʻai he nui i hoʻokahi manawa, akā he nui loa nā pōʻai ma ka awelika a hiki i ka nui ʻana o `left + right`, a ma laila mau ka hihia ʻoi loa o ka pōʻai hoʻokahi.
/// Ma kahi o, hoʻohana ʻo algorithm 3 i ka hoʻololi pinepine ʻana o nā `min(left, right)` a hiki i ka waiho ʻana o kahi pilikia kuapo liʻiliʻi.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ke `left < right` ke hoʻololi ʻana mai ka hema ma kahi.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. hiki i nā algorithms ma lalo ke holo pono inā ʻaʻole nānā ʻia kēia mau hihia
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Hōʻike ka Algorithm 1 Microbenchmarks ʻoi aku ka maikaʻi o ka hana maʻamau no ka loli maʻamau a hiki i kahi o `left + right == 32`, akā ʻo ka hana maikaʻi loa e haki ma kahi o 16.
            // Ua koho ʻia ʻo 24 ma ke kahua waena.
            // Inā ʻoi aku ka nui o `T` ma mua o 4 `usize`s, ʻoi aku ka maikaʻi o kēia algorithm ma mua o nā algorithms ʻē aʻe.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ka hoʻomaka ʻana o ka pōʻai mua
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` hiki ke loaʻa ma mua o ka lima ma ka helu ʻana iā `gcd(left + right, right)`, akā ʻoi aku ka wikiwiki o ka hana ʻana i hoʻokahi loop e helu ai i ka gcd ma ke ʻano he hopena, a laila e hana ana i ke koena o ka chunk
            //
            //
            let mut gcd = right;
            // Nā Māka Hoʻohālike hōʻike i ia mea wikiwiki i ka kuapo temporaries a pau i ke ala ma kahi o ka heluhelu i kekahi? aiaiiuie, hoʻokahi houʻana, ka hoʻopiliʻana hope, a laila, kākau i? aiaiiuie i ka loa hopena.
            // Ma muli paha o ke kuapo ʻana a i ʻole ka hoʻololi ʻana i nā manawa kūlohelohe e hoʻohana wale i hoʻokahi helu hoʻomanaʻo i ka loop ma kahi o ka pono e hoʻokele i ʻelua.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // ma kahi o ka hoʻonui `i` a laila e nānā inā aia ma waho o nā palena, nānā mākou inā `i` e hele i waho o nā palena i ka hoʻonui aʻe.
                // Pale kēia i nā wahī ʻana a i ʻole `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // hopena o ka puni mua
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // pono e loaʻa kēia ʻano ma aneʻi inā `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // hoʻopau i ka chunk me nā puni hou aʻe
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ʻAʻole ia he ʻano kaulike ʻole, no laila maikaʻi ke hoʻokaʻawale ʻia e kāna nui.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 ʻO ka `[T; 0]` ma aneʻi e hōʻoia i ke kaulike kūpono ʻana kēia no T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Aia kekahi ala ʻē aʻe o ke kuapo e pili ana i ka loaʻa ʻana kahi o ka swap hope loa o kēia algorithm, a ke hoʻololi nei i ka hoʻohana ʻana i kēlā ʻāpana hope loa ma kahi o ke kuapo ʻana i nā ʻāpana pili e like me ka hana ʻana o kēia algorithm, akā ʻoi aku ka wikiwiki o kēia ala.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}