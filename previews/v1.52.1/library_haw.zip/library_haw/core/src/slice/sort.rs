//! Hoʻokaʻina ʻāpana
//!
//! Aia i loko o kēia māhele kahi algorithm hoʻokaʻina e pili ana i ka Ors Peters 'kumu-e lanakila ana i ka quicksort, paʻi ʻia ma: <https://github.com/orlp/pdqsort>
//!
//!
//! He hu wale i hoʻokaʻina 'He hana maʻalahi me ka libcore, no ka mea, aole ia i līkaia hoomanao, e like mākou hale lio ka hoʻomaopopoʻana manaʻo.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ke waiho ʻia, kope mai `src` a i `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SAFETY: ʻO kēia kahi papa kōkua.
        //          E nānā i kāna hoʻohana ʻana no ka pololei.
        //          ʻO ia hoʻi, pono e ʻike pono kekahi ʻaʻole e hoʻopili ʻo `src` a me `dst` e like me ka mea i koi ʻia e `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Hoʻololi i ka mea mua i ka ʻākau a hiki i kona hālāwai ʻana me kahi mea nui a like paha.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: ʻO nā hana palekana ʻole ma lalo nei e pili ana i ka helu ʻana me ka ʻole o ka kaha i hoʻopaʻa ʻia (`get_unchecked` a me `get_unchecked_mut`)
    // a me ke kope ʻana i ka hoʻomanaʻo (`ptr::copy_nonoverlapping`).
    //
    // a.Papa kuhikuhi helu:
    //  1. Ua nānā mākou i ka nui o ke ʻano i>=2.
    //  2. ʻO nā papa helu helu āpau a mākou e hana ai ma waena o {0 <= index < len} mau loa.
    //
    // b.Kope hoʻomanaʻo
    //  1. Ke kiʻi nei mākou i nā kuhikuhi i nā kūmole i hōʻoiaʻiʻo ʻia e pololei.
    //  2. ʻAʻole hiki iā lākou ke hoʻopili aku no ka mea loaʻa iā mākou nā kiko i nā ʻikepili ʻokoʻa o ka ʻāpana.
    //     ʻO `i` a me `i-1`.
    //  3. Inā kū pololei ka ʻāpana, hoʻopili pono nā mea.
    //     ʻO ke kuleana o ka mea kāhea e hōʻoia i ka hoʻopili pono ʻana o kahi ʻāpana.
    //
    // E ʻike i nā manaʻo ma lalo no ka kikoʻī hou aʻe.
    unsafe {
        // Inā kū i waho o ka ʻaoʻao nā mea mua ʻelua ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // E heluhelu i ka mea mua i loko o kahi laulā i hoʻokaʻawale ʻia.
            // Inā kahi hana hoʻohālikelike aʻe panics, e hāʻule ʻo `hole` a kākau aunoa i ka mea i loko o ka ʻāpana.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // E neʻe i kahi ʻekahi kahi wahi ma ka hema, a pēlā e hoʻololi ai i ka lua i ka ʻākau.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` loaʻa hoʻokuʻu a pela kope `tmp` i loko o ka puka i loko o `v` koe.
        }
    }
}

/// Hoʻololi i ka mea hope loa i ka hema a hiki i kona hālāwai ʻana me kahi mea liʻiliʻi a kaulike paha.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: ʻO nā hana palekana ʻole ma lalo nei e pili ana i ka helu ʻana me ka ʻole o ka kaha i hoʻopaʻa ʻia (`get_unchecked` a me `get_unchecked_mut`)
    // a me ke kope ʻana i ka hoʻomanaʻo (`ptr::copy_nonoverlapping`).
    //
    // a.Papa kuhikuhi helu:
    //  1. Ua nānā mākou i ka nui o ke ʻano i>=2.
    //  2. ʻO nā papa helu helu āpau a mākou e hana ai ma waena o `0 <= index < len-1` mau loa.
    //
    // b.Kope hoʻomanaʻo
    //  1. Ke kiʻi nei mākou i nā kuhikuhi i nā kūmole i hōʻoiaʻiʻo ʻia e pololei.
    //  2. ʻAʻole hiki iā lākou ke hoʻopili aku no ka mea loaʻa iā mākou nā kiko i nā ʻikepili ʻokoʻa o ka ʻāpana.
    //     ʻO `i` a me `i+1`.
    //  3. Inā kū pololei ka ʻāpana, hoʻopili pono nā mea.
    //     ʻO ke kuleana o ka mea kāhea e hōʻoia i ka hoʻopili pono ʻana o kahi ʻāpana.
    //
    // E ʻike i nā manaʻo ma lalo no ka kikoʻī hou aʻe.
    unsafe {
        // Inā ʻoi aku ka maikaʻi o nā mea ʻelua i hala ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // E heluhelu i ka mea hope loa i loko o kahi laulā i hoʻokaʻawale ʻia.
            // Inā kahi hana hoʻohālikelike aʻe panics, e hāʻule ʻo `hole` a kākau aunoa i ka mea i loko o ka ʻāpana.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // E neʻe i kahi ʻekahi kahi wahi i ka ʻākau, a pēlā e hoʻololi ai i ka lua i ka hema.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` loaʻa hoʻokuʻu a pela kope `tmp` i loko o ka puka i loko o `v` koe.
        }
    }
}

/// Hoʻokaʻawale hapa i kahi ʻāpana e ka hoʻololi ʻana i kekahi mau mea ma waho o ka ʻaoʻao a puni.
///
/// Hoʻi iā `true` inā hoʻokaʻawale ʻia kahi ʻāpana i ka hopena.ʻO kēia hana ʻo *O*(*n*) hihia ʻino loa.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ka nui o nā paʻa ma waho o ka ʻaoʻao e pili ana e hoʻoneʻe ʻia.
    const MAX_STEPS: usize = 5;
    // Inā ʻoi aku ka pōkole o ka ʻāpana ma mua o kēia, mai hoʻoneʻe i kekahi mau mea.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Ua hana akāka mākou i ka nānā ʻana me ka `i < len`.
        // ʻO kā mākou papa helu helu hope aʻe aia wale nō ma ka pae `0 <= index < len`
        unsafe {
            // E ʻike i nā paʻa aʻe o nā mea ʻē aʻe ma waho o ka ʻaoʻao e pili ana.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Pau mākou?
        if i == len {
            return true;
        }

        // Mai hoʻololi i nā mea ma nā arrays pōkole, he uku hoʻokō kēlā.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Kuapo i nā mea i ʻike ʻia.Hoʻonoho pololei kēia iā lākou.
        v.swap(i - 1, i);

        // E hoʻohuli i ka mea liʻiliʻi i ka hema.
        shift_tail(&mut v[..i], is_less);
        // E hoʻohuli i ka mea nui i ka ʻākau.
        shift_head(&mut v[i..], is_less);
    }

    // ʻAʻole mālama ʻia e hoʻokaʻawale i kahi ʻāpana i ka helu palena o nā ʻanuʻu.
    false
}

/// Hoʻokaʻawale i kahi ʻāpana e hoʻohana ana i ka ʻano hoʻokomo, ʻo ia hoʻi ʻo *O*(*n*^ 2) hihia ʻino loa.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Hoʻokaʻawale `v` me ka hoʻohana ʻana i ka heapsort, ka mea e hōʻoia ai iā *O*(*n*\*log(* n*)) hihia maikaʻi loa.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Hoʻomaopopo kēia puʻu binary i ka `parent >= child` invariant.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Nā keiki a `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Koho i ke keiki ʻoi aku ka nui.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // E kū inā paʻa ka invariant ma `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Kuapo i `node` me ke keiki ʻoi aku ka nui, neʻe i lalo i lalo, a hoʻomau i ka kānana.
            v.swap(node, greater);
            node = greater;
        }
    };

    // E kūkulu i ka ahu i ka manawa linear.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pākuʻi i nā mea kiʻekiʻe mai ka ahu.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Nā ʻāpana `v` i nā mea i ʻoi aku ka liʻiliʻi ma mua o `pivot`, a ukali ʻia e nā mea i ʻoi aku ma mua a i ʻole like me `pivot`.
///
///
/// Hoʻihoʻi i ka helu o nā mea liʻiliʻi ma mua o `pivot`.
///
/// Hana ʻia ka hoʻokaʻawale ʻana i kēlā me kēia wahi i mea e hōʻemi ai i ke kumukūʻai o nā hana lālā.
/// Hōʻike ʻia kēia manaʻo i ka pepa [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ka helu o nā mea i kahi poloka maʻamau.
    const BLOCK: usize = 128;

    // Hōʻike ka algorithm ʻāpana i kēia mau kaʻina a hiki i ka pau ʻana.
    //
    // 1. E haki i kahi palaka mai ka ʻaoʻao hema e ʻike ai i nā mea i ʻoi aku ma mua a i ʻole like i ka pivot.
    // 2. E huki i kahi palaka mai ka ʻaoʻao ʻākau e ʻike ai i nā mea i ʻoi aku ka liʻiliʻi ma mua o ka pivot.
    // 3. E hoʻololi i nā mea i ʻike ʻia ma waena o ka ʻaoʻao hema a ʻākau.
    //
    // Mālama mākou i nā loli aʻe no kahi poloka o nā mea:
    //
    // 1. `block` - Ka helu o nā mea i ka palaka.
    // 2. `start` - E hoʻomaka i ka kuhikuhi ma ka lālani `offsets`.
    // 3. `end` - E hoʻopau i ka pointer i ka lālani `offsets`.
    // 4. ʻO nā offset, nā ʻikepili o nā mea ma waho o ka papa i loko o ka palaka.

    // ʻO ka palaka o kēia manawa ma ka ʻaoʻao hema (mai `l` a i `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ʻO ka palaka o kēia manawa ma ka ʻaoʻao ʻākau (mai `r.sub(block_r)` to `r`).
    // SAFETY: ʻO nā palapala no .add() hōʻike kikoʻī ʻo `vec.as_ptr().add(vec.len())` palekana mau`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ke loaʻa iā mākou nā VLA, e hoʻāʻo e hana i hoʻokahi lālani o ka lōʻihi `min(v.len(), 2 * BLOCK) ʻeā
    // ma mua o ʻelua mau hoʻonohonoho hoʻonohonoho paʻa o ka lōʻihi `BLOCK`.ʻOi aku ka cache-efficence o VLAs.

    // Hoʻihoʻi i ka helu o nā mea ma waena o nā kuhi `l` (inclusive) a me `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Hana mākou me ka pale ʻana i ka pale-by-block ke kokoke loa ʻo `l` a me `r`.
        // A laila hana mākou i kahi hana patch-up i mea e hoʻokaʻawale ai i nā mea i koe ma waena.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Ka helu o nā mea i koe (ʻaʻole hoʻohālikelike ʻia i ka pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Hoʻololi i nā nui poloka i ʻole e hoʻopili ka hema a me ka poloka kūpono, akā e hoʻopili pono e uhi i ka āpau i koe.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Huli i nā mea `block_l` mai ka ʻaoʻao hema.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAFETY: ʻO nā hana palekana ʻole ma lalo e pili ana i ka hoʻohana ʻana o `offset`.
                //         Wahi a nā kūlana i koi ʻia e ka hana, hōʻoluʻolu mākou iā lākou no ka mea:
                //         1. `offsets_l` hāʻawi ʻia, a no laila ua manaʻo ʻia he mea hoʻokaʻawale ʻia.
                //         2. Hoʻi ka hana `is_less` i `bool`.
                //            ʻO ka hoʻolei ʻana i `bool` ʻaʻole loa e hoʻonui iā `isize`.
                //         3. Ua hōʻoia mākou ʻo `block_l` ka `<= BLOCK`.
                //            Hoʻohui, `end_l` i hoʻonohonoho mua ʻia i ka pointer hoʻomaka o `offsets_` i haʻi ʻia ma ka stack.
                //            No laila, ʻike mākou i loko o ka hihia ʻoi loa (ʻo nā noi āpau o `is_less` e hoʻi i ka wahaheʻe) aia wale nō mākou i ka 1 byte e hoʻopau i ka hopena.
                //        ʻO kahi hana palekana ʻē aʻe ma aneʻi ka hoʻopau ʻana iā `elem`.
                //        Eia nō naʻe, ʻo `elem` ka hoʻomaka ma ka kuhikuhi ʻana i ka ʻāpana i kūpono mau.
                unsafe {
                    // Hoʻohālike lālā ʻole.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Huli i nā mea `block_r` mai ka ʻaoʻao ʻākau.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAFETY: ʻO nā hana palekana ʻole ma lalo e pili ana i ka hoʻohana ʻana o `offset`.
                //         Wahi a nā kūlana i koi ʻia e ka hana, hōʻoluʻolu mākou iā lākou no ka mea:
                //         1. `offsets_r` hāʻawi ʻia, a no laila ua manaʻo ʻia he mea hoʻokaʻawale ʻia.
                //         2. Hoʻi ka hana `is_less` i `bool`.
                //            ʻO ka hoʻolei ʻana i `bool` ʻaʻole loa e hoʻonui iā `isize`.
                //         3. Ua hōʻoia mākou ʻo `block_r` ka `<= BLOCK`.
                //            Hoʻohui, `end_r` i hoʻonohonoho mua ʻia i ka pointer hoʻomaka o `offsets_` i haʻi ʻia ma ka stack.
                //            No laila, ʻike mākou i loko o ka hihia maikaʻi loa (hoʻihoʻi maoli nā noi āpau o `is_less`) ma ka hapanui o 1 byte e hoʻopau i ka hopena.
                //        ʻO kahi hana palekana ʻē aʻe ma aneʻi ka hoʻopau ʻana iā `elem`.
                //        Eia nō naʻe, `elem` ma mua `1 *sizeof(T)` i hala i ka hopena a hōʻemi mākou iā ia e `1* sizeof(T)` ma mua o ke kiʻi ʻana iā ia.
                //        Eia kekahi, `block_r` Ua hoʻike ia e emi ma mua o `BLOCK` a me `elem` e no laila, i loa e kuhikuhi ana i ka hoʻomaka o ka māhele.
                unsafe {
                    // Hoʻohālike lālā ʻole.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Ka helu o nā mea ma waho o ke kauoha e kuapo ma waena o ka ʻaoʻao hema a ʻākau.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ma kahi o ke kuapo ʻana i hoʻokahi paʻa i ka manawa, ʻoi aku ka maikaʻi o ka hoʻokō ʻana i kahi permutation cyclic.
            // ʻAʻole like kēia i ke kuapo, akā hoʻopuka i kahi hopena like me ka hoʻohana ʻana i nā ʻoihana hoʻomanaʻo liʻiliʻi.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ua hoʻoneʻe ʻia nā mea āpau ma waho o ka ʻoka i ka palaka hema.E neʻe i ka palaka aʻe.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Ua hoʻoneʻe ʻia nā mea āpau ma waho o ka ʻoka ma ka poloka kūpono.E neʻe i ka palaka ma mua.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ʻO nā mea i koe i kēia manawa aia ma ka hapanui o hoʻokahi poloka (ʻo ka hema a ʻo ka ʻākau paha) me nā mea kū i waho e pono e hoʻoneʻe ʻia.
    // Hiki ke hoʻoneʻe maʻalahi i nā mea i koe i ka hopena ma loko o kā lākou palaka.
    //

    if start_l < end_l {
        // Mau ka palaka hema.
        // E neʻe i kāna mau koina ma waho o ka ʻaoʻao ʻākau a ʻākau.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Koe ka poloka kūpono.
        // E hoʻoneʻe i kāna mau mea i koe o ka ʻaoʻao hema i ka hema hema.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ʻAʻohe mea ʻē aʻe e hana ai, ua pau mākou.
        width(v.as_mut_ptr(), l)
    }
}

/// Nā ʻāpana `v` i nā mea i ʻoi aku ka liʻiliʻi ma mua o `v[pivot]`, a ukali ʻia e nā mea i ʻoi aku ma mua a i ʻole like me `v[pivot]`.
///
///
/// Hoʻihoʻi i kahi tuple o:
///
/// 1. Ka helu o nā mea liʻiliʻi ma mua o `v[pivot]`.
/// 2. ʻOiaʻiʻo inā ua hoʻokaʻawale ʻia ʻo `v`.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // E kau i ka pivot i ka hoʻomaka o ka ʻāpana.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // E heluhelu i ka pivot i loko o kahi laulā i hoʻokaʻawale ʻia no ka pono.
        // Inā kahi hana hoʻohālikelike aʻe o panics, e kākau aunoa ʻia ka pivot i loko o kahi ʻāpana.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // E ʻike i ka hui mua o nā mea ma waho o ka ʻoka.
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: ʻO ka palekana ʻole ma lalo e pili ana i ka helu ʻana i kahi hoʻonohonoho.
        // No ka mea mua: Hana mua mākou i nā palena e nānā nei me `l < r`.
        // No ka lua: Loaʻa iā `l == 0` a me `r == v.len()` ka mea mua iā mākou a ua hōʻoia mākou i kēlā `l < r` i kēlā me kēia hana papa inoa.
        //                     Mai aneʻi ʻike mākou he `r == l` ma ka liʻiliʻi `r == l` i hōʻike ʻia he kūpono mai ka mea mua.
        unsafe {
            // E ʻike i ka mea mua i ʻoi aku ma mua o ka like paha o ka pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // E ʻike i ka mea hope loa i ʻoi aku ka liʻiliʻi o ka pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` hele i waho o ka laulā a kākau i ka pivot (ʻo ia ka hoʻololi i hoʻokaʻawale ʻia) i loko o ka ʻāpana kahi i noho mua ai.
        // He mea koʻikoʻi kēia hana i ka hōʻoia ʻana i ka palekana!
        //
    };

    // E kau i ka pivot ma waena o nā pālua.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Nā ʻāpana `v` i nā mea like i ka `v[pivot]` ukali ʻia e nā mea i ʻoi aku ma mua o `v[pivot]`.
///
/// Hoʻihoʻi i ka helu o nā mea like i ka pivot.
/// Manaʻo ʻia ʻaʻohe o `v` mau mea i ʻoi aku ka liʻiliʻi ma mua o ka pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // E kau i ka pivot i ka hoʻomaka o ka ʻāpana.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // E heluhelu i ka pivot i loko o kahi laulā i hoʻokaʻawale ʻia no ka pono.
    // Inā kahi hana hoʻohālikelike aʻe o panics, e kākau aunoa ʻia ka pivot i loko o kahi ʻāpana.
    // SAFETY: Kūpono ka kuhikuhi ma aneʻi no ka mea i loaʻa mai kahi kuhikuhi i kahi ʻāpana.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // E hoʻokaʻawale i ka ʻāpana.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: ʻO ka palekana ʻole ma lalo e pili ana i ka helu ʻana i kahi hoʻonohonoho.
        // No ka mea mua: Hana mua mākou i nā palena e nānā nei me `l < r`.
        // No ka lua: Loaʻa iā `l == 0` a me `r == v.len()` ka mea mua iā mākou a ua hōʻoia mākou i kēlā `l < r` i kēlā me kēia hana papa inoa.
        //                     Mai aneʻi ʻike mākou he `r == l` ma ka liʻiliʻi `r == l` i hōʻike ʻia he kūpono mai ka mea mua.
        unsafe {
            // E ʻike i ka mea mua ma mua o ka pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // E ʻike i ka mea hope loa i like me ka pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Pau mākou?
            if l >= r {
                break;
            }

            // Kuapo i nā mea i loaʻa i waho o ka ʻoka i loaʻa.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Ua loaʻa iā mākou nā mea `l` e like me ka pivot.Hoʻohui 1 i ka helu no ka pivot ponoʻī.
    l + 1

    // `_pivot_guard` hele i waho o ka laulā a kākau i ka pivot (ʻo ia ka hoʻololi i hoʻokaʻawale ʻia) i loko o ka ʻāpana kahi i noho mua ai.
    // He mea koʻikoʻi kēia hana i ka hōʻoia ʻana i ka palekana!
}

/// E hoʻopuehu i kekahi mau mea a puni i ka hoʻāʻo e uhaʻi i nā kumu i hiki ke kumu i nā pā kaulike ʻole i quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ʻO ka generator helu Pseudorandom mai ka pepa "Xorshift RNGs" na George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Lawe i nā helu kaulike i kēia helu.
        // Kūpono ka helu i `usize` no ka mea ʻaʻole ʻoi aku ka nui o `len` ma mua o `isize::MAX`.
        let modulus = len.next_power_of_two();

        // E kokoke ana kekahi o nā moho pivot i kēia papa kuhikuhi.E koho iā lākou.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Hana i kahi helu maʻamau modulo `len`.
            // Eia nō naʻe, i mea e hōʻalo ai i nā hana kumukūʻai e lawe mua mākou iā ia i modulo i kahi mana o ʻelua, a laila e hoʻēmi e `len` a hiki i ke komo ʻana i ka pae `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ua hōʻoia ʻia ma lalo o `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Koho i kahi pivot ma `v` a hoʻihoʻi i ka papa kuhikuhi a me `true` inā ua hoʻonohonoho mua ʻia kahi ʻāpana.
///
/// Hoʻonohonoho hou ʻia nā mea i `v` i ke kaʻina.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ka lōʻihi liʻiliʻi e koho i ka hana waena-o-waena.
    // Hoʻohana nā ʻāpana pōkole i ke ʻano waena waena-ʻekolu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ʻO ka nui o nā swaps i hiki ke hana i kēia hana.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ʻEkolu mau helu kikoʻī kokoke mākou e koho ai i kahi pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Helu ʻia ka huina o nā swaps a mākou e hana nei i ka hoʻokaʻawale ʻana i nā ʻike.
    let mut swaps = 0;

    if len >= 8 {
        // Kuapo i nā papa kuhikuhi no laila `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Kuapo i nā papa kuhikuhi no laila `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // E ʻike i ka median o `v[a - 1], v[a], v[a + 1]` a mālama i ka papa kuhikuhi i `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // E ʻike i nā medians ma nā kaiāulu o `a`, `b`, a me `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // E ʻike i ka waena ma waena o `a`, `b`, a me `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Ua hoʻokō ʻia ka nui o nā kuapo.
        // Ke iho mai nei ka ʻāpana a i ʻole ka iho ʻana i ka hapa nui, no laila ke kōkua ʻo ka hoʻohuli ʻana i ka wikiwiki.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Hoʻemi hou ʻia ʻo `v`.
///
/// Inā he mua kekahi o ka ʻāpana i ka lālau kumu, ua hōʻike ʻia ʻo `pred`.
///
/// `limit` ʻo ia ka helu o nā ʻāpana kaulike ʻole i ʻae ʻia ma mua o ka hoʻololi ʻana i `heapsort`.
/// Inā ʻole, e hoʻololi koke kēia hana i ka heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Hoʻonohonoho ʻia nā ʻāpana o a i kēia lōʻihi me ka hoʻohana ʻana i ka ʻano hoʻokomo.
    const MAX_INSERTION: usize = 20;

    // ʻOiaʻiʻo inā kaulike kūpono ka pāhele hope loa.
    let mut was_balanced = true;
    // ʻOiaʻiʻo inā ʻaʻole shuffle nā ʻāpana hope (ua hoʻokaʻawale ʻia ka ʻāpana).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Hoʻonohonoho ʻia nā ʻāpana pōkole loa e hoʻohana ana i ka ʻano hoʻokomo.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Inā nui a hewahewa nā koho pivot i koho ʻia, hoʻi wale i ka heapsort i mea e hōʻoia ai i ka hihia ʻoi loa `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Inā kūlike ʻole ka pāhaina hope loa, e hoʻāʻo i nā hāpana i ka ʻāpana e ka loli ʻana i kekahi mau mea a puni.
        // Lana ka manaʻo e koho mākou i kahi pivot ʻoi aku ka maikaʻi i kēia manawa.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Koho i kahi pivot a hoʻāʻo e koho inā ua hoʻonohonoho ʻia ka ʻāpana.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Inā kaulike kaulike ka paina hope loa a ʻaʻole i hoʻololi i nā mea, a inā wānana ke koho pivot ua hoʻokaʻawale ʻia kahi ʻāpana ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // E hoʻāʻo e ʻike i nā mea ma waho o ka ʻoka a hoʻololi iā lākou e hoʻoponopono i nā kūlana.
            // Inā hoʻopau ʻia kahi ʻāpana i ka hoʻonohonoho piha ʻia ʻana, pau kā mākou.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Inā like ka pivot i koho ʻia me ka mea i mua, a laila ʻo ia ka mea liʻiliʻi loa i ka ʻāpana.
        // Hoʻokaʻawale i ka ʻāpana i nā mea like a me nā mea i ʻoi aku ma mua o ka pivot.
        // Pā pinepine ʻia kēia hihia ke loaʻa i nā ʻāpana kope he nui i ka ʻāpana.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // E hoʻomau i ka hoʻokaʻawale ʻana i nā mea i ʻoi aku ma mua o ka pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Hoʻokaʻawale i ka ʻāpana.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // E hoʻokaʻawale i ka ʻāpana i `left`, `pivot`, a me `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Hoʻihoʻi i ka ʻaoʻao pōkole wale nō i mea e hōʻemi ai i ka helu o nā kelepona recursive a hoʻopau i ka liʻiliʻi o ka hakahaka.
        // A laila e hoʻomau me ka ʻaoʻao lōʻihi (pili kēia i ka recursion o ka huelo).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Hoʻokaʻawale `v` me ka hoʻohana ʻana i ke kumu hoʻohālikelike wikiwiki, ʻo ia ka *O*(*n*\*log(* n*)) hihia maikaʻi loa.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ʻAʻohe ʻano kūpono o ka wehewehe ʻana ma nā ʻano nui ʻole.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Palena i ka helu o nā māhele kaulike ʻole i `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // No nā ʻāpana a hiki i kēia lōʻihi ʻoi aku ka wikiwiki o ka hoʻonohonoho maʻalahi ʻana iā lākou.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Koho i kahi pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Inā like ka pivot i koho ʻia me ka mea i mua, a laila ʻo ia ka mea liʻiliʻi loa i ka ʻāpana.
        // Hoʻokaʻawale i ka ʻāpana i nā mea like a me nā mea i ʻoi aku ma mua o ka pivot.
        // Pā pinepine ʻia kēia hihia ke loaʻa i nā ʻāpana kope he nui i ka ʻāpana.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Inā ua hala mākou i kā mākou papa kuhikuhi, a laila maikaʻi mākou.
                if mid > index {
                    return;
                }

                // Inā ʻole, e hoʻomau i ka hoʻokaʻawale ʻana i nā mea ʻoi aku ka nui ma mua o ka pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // E hoʻokaʻawale i ka ʻāpana i `left`, `pivot`, a me `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Inā helu==waena, a laila pau mākou, no ka mea, ua hōʻoia ʻo partition() ʻoi aku ka nui o nā mea ma hope o ka waena ma mua a i ʻole waena paha.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // ʻAʻohe ʻano kūpono o ka wehewehe ʻana ma nā ʻano nui ʻole.Mai hana i kekahi mea.
    } else if index == v.len() - 1 {
        // E ʻike i ka max element a kau iā ia i ke kūlana hope loa o ka lālani.
        // Ua manuahi mākou e hoʻohana i `unwrap()` ma aneʻi no ka mea ʻike mākou ʻaʻole pono ʻole ka v.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // E huli i nā min hehee ai, a waiho ia ma ke kulana mua o ke ku e.
        // Ua manuahi mākou e hoʻohana i `unwrap()` ma aneʻi no ka mea ʻike mākou ʻaʻole pono ʻole ka v.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}