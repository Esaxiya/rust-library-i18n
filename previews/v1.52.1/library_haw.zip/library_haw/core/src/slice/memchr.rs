// Lawe ʻia ka hoʻokō kumu mai rust-memchr.
// Copyright 2015 Andrew Nui!, Bluss a me Nikolao ka Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// E hoʻohana i ka truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Hoʻi iā `true` inā loaʻa iā `x` kekahi byte zero.
///
/// Mai *Nā Pono Helu*, J. Arndt:
///
/// "ʻO ka manaʻo e hoʻolawe i kekahi mai kēlā me kēia byte a laila e nānā i nā byte kahi i hoʻolaha ai ka hōʻaiʻē a hiki i ka mea nui
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Hoʻihoʻi i ka papa kuhikuhi mua e kūlike ana i ka byte `x` ma `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ke ala wikiwiki no nā ʻoki liʻiliʻi
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan NineManga.com no kekahi waiwai byte ma ka heluhelu ʻana i ʻelua mau huaʻōlelo `usize` i ka manawa hoʻokahi.
    //
    // Wāwahi `text` i ʻekolu mau ʻāpana
    // - kapili ʻole i ka ʻaoʻao mua, ma mua o ka hoʻopili ʻana o ka huaʻōlelo mua i ka leka
    // - kino, ʻimi e nā hua ʻōlelo 2 i ka manawa hoʻokahi
    // - ka ʻāpana hope i koe, <2 ka nui o ka ʻōlelo

    // e ʻimi a loaʻa i ka palena kaulike
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // e ʻimi i ke kino o ka ʻōlelo
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: hōʻoia ka predicate o ka manawa i kahi mamao o 2 * usize_bytes ma kahi liʻiliʻi
        // ma waena o ka offset a me ka hopena o ka ʻāpana.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // haki inā aia kekahi byte like
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // E ʻike i ka byte ma hope o ke kiko i kū ai ke loop loop.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Hoʻihoʻi i ka papa kuhikuhi hope loa e kūlike ana i ka byte `x` ma `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan NineManga.com no kekahi waiwai byte ma ka heluhelu ʻana i ʻelua mau huaʻōlelo `usize` i ka manawa hoʻokahi.
    //
    // Wāwahi `text` i ʻekolu mau ʻāpana:
    // - huelo kaulike ʻole, ma hope o ka ʻōlelo hope loa i hoʻopili ʻia i ka leka uila,
    // - kino, nānā ʻia e nā hua ʻōlelo 2 i ka manawa like,
    // - nā byte mua i koe, <2 ka nui o ka ʻōlelo.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Kāhea mākou i kēia no ka loaʻa ʻana o ka lōʻihi o ka pīpī a me ka hope.
        // Ma ka waena waena mākou e hana mau i nā ʻāpana ʻelua i ka manawa hoʻokahi.
        // SAFETY: palekana ka hoʻoili ʻana i `[u8]` i `[usize]` koe wale no nā ʻokoʻa nui e lawelawe ʻia e `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // E ʻimi i ke kino o ka huaʻōlelo, e hōʻoia ʻaʻole mākou e hele i ka min_aligned_offset.
    // Hoʻonohonoho pinepine ʻia ka offset, no laila ke lawa nei ka hoʻāʻo ʻana iā `>` a pale i ka hiki ke piʻi.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: hoʻomaka ke offset ma len, suffix.len(), ʻoiai ke ʻoi aku ka nui ma mua o
        // min_aligned_offset (prefix.len()) ke koena o ka mamao ma kahi o 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Haki inā loaʻa kahi byte like.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // E ʻike i ka byte ma mua o ka kiko i kū ai ke loop loop.
    text[..offset].iter().rposition(|elt| *elt == x)
}