//! Hana ma ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Nānā inā aia nā byte āpau i kēia ʻāpana i loko o ka pae ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Nānā i nā ʻāpana ʻelua he match case-insensitive ASCII.
    ///
    /// E like me `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, akā me ka hoʻokaʻawale ʻole a me ke kope ʻana i nā manawa.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Hoʻololi i kēia ʻāpana i kāna ASCII hihia kiʻekiʻe i kūlike i ka wahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'a' a i 'z' i 'A' a i 'Z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou aʻe me ka ʻole o ka hoʻololi ʻana i kahi e kū nei, e hoʻohana iā [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Hoʻololi i kēia ʻāpana i kāna ASCII hihia haʻahaʻa e like ana ma kahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'A' a i 'Z' i 'a' a i 'z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou i hoʻemi ʻia me ka hoʻololi ʻole i kahi e kū nei, e hoʻohana iā [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Hoʻi iā `true` inā loaʻa kekahi byte i ka huaʻōlelo `v` non nonpiii (>=128).
/// Snarfed mai `../str/mod.rs`, a hana like i kahi mea like no ka hōʻoia utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Hoʻokolohua hōʻoia ASCII e hoʻohana i nā hana usize-at-a-time ma kahi o nā byte-at-a-time Operations (ke hiki).
///
/// He maʻalahi ka algorithm a mākou e hoʻohana ai ma aneʻi.Inā pōkole loa ʻo `s`, nānā wale mākou i kēlā me kēia byte a hana ʻia me ia.I ʻole:
///
/// - E heluhelu i ka huaʻōlelo me ka ukana unaligned.
/// - E hoʻopili i ka kuhikuhi, heluhelu i nā huaʻōlelo a hiki i ka hopena me nā ukana i kaulike ʻia.
/// - E heluhelu i ka `usize` hope loa mai `s` me kahi ukana i kaulike ʻole ʻia.
///
/// Inā hana kekahi o kēia mau ukana i kahi mea a `contains_nonascii` (above) e hoʻi ai i ka ʻoiaʻiʻo, a laila ʻike mākou he wahaheʻe ka pane.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Inā ʻaʻole mākou e loaʻa i kekahi mea mai ka hoʻokō huaʻōlelo-ma-ka-manawa, hoʻi i ka loop scalar.
    //
    // Hana mākou i kēia no nā hoʻolālā kahi ʻaʻole lawa ka hoʻopili ʻana o `size_of::<usize>()` no `usize`, no ka mea he hihia edge ʻano ʻē.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Heluhelu mau mākou i ka huaʻōlelo i kau ʻole ʻia, ʻo ia hoʻi `align_offset`
    // 0, heluhelu hou mākou i ka helu like no ka heluhelu kaulike.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: Hōʻoiaʻiʻo mākou iā `len < USIZE_SIZE` ma luna.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ua nānā mākou i kēia ma luna, ʻano implicitly.
    // E hoʻomaopopo he `align_offset` a `USIZE_SIZE` paha ka `offset_to_aligned`, ua nānā ākea ʻia ʻelua ma luna.
    //
    debug_assert!(offset_to_aligned <= len);

    // Maluhia: word_ptr o ka (pono ua kūponoʻia) usize ptr mākou hoʻohana i ka heluhelu i ka
    // ʻāpana waena o ka ʻāpana.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` o kaʻai Index o `word_ptr`, hoʻohana no ka loop hope loaʻa, e kaha.
    let mut byte_pos = offset_to_aligned;

    // Paranoia ponopono ana hoʻopololei, ke oe e pili ana, e hanaʻoukou i pūpū o unaligned wahie, ma hope.
    // I mea keia e pono e hiki ole'ākeʻakeʻa he pilikia i loko o `align_offset` nae.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Heluhelu i nā huaʻōlelo a hiki i ka huaʻōlelo kūlike loa, me ka hoʻokaʻawale ʻole i ka huaʻōlelo kūlike hope loa e hana ʻia i ka huelo huli ma hope, i mea e hōʻoia mau ai ka huelo hoʻokahi `usize` ma ka hapanui a keu branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Nānā Sanity i ka heluhelu ʻana i ka palena
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // A ʻo kā mākou mau manaʻo e pili ana iā `byte_pos` paʻa.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: ʻike mākou ua hoʻopili pololei ʻia ʻo `word_ptr` (ma muli o
        // `align_offset`), a ʻike mākou ua lawa kā mākou bytes ma waena o `word_ptr` a me ka hopena
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: ʻike mākou i ka `byte_pos <= len - USIZE_SIZE`, ʻo ia hoʻi
        // ma hope o kēia `add`, `word_ptr` ma ka hapanui o hoʻokahi-hala-ka-hopena.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Nānā Sanity e hōʻoia he hoʻokahi wale nō `usize` i koe.
    // Pono e hōʻoia ʻia kēia e ko mākou ʻano loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: Ke hilinaʻi nei kēia ma `len >= USIZE_SIZE`, a mākou e nānā ai i ka hoʻomaka.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}