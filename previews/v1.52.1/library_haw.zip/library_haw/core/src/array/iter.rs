//! Wehewehe i ka `IntoIter` nona iterator no ka arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ʻO ka iterator [array] waiwai.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ʻO kēia ka lālani a mākou e ʻōlapa nei.
    ///
    /// ʻO nā mea me ka papa kuhikuhi `i` kahi `alive.start <= i < alive.end` ʻaʻole i hāʻawi ʻia i kēia manawa a he kūpono i nā kuhi komo.
    /// Nā kumumea me indices `i < alive.start` a `i >= alive.end` i ua haawi mua, a pono ole ke lolouila hou!Aia paha kēlā mau mea make i kahi kūlana uninitialized loa!
    ///
    ///
    /// No laila, na invariants i:
    /// - `data[alive]` mea e ola ana ('o ia hoʻi he pololei ia oihana mua)
    /// - `data[..alive.start]` a ua make ʻo `data[alive.end..]` (ie ua heluhelu ʻia nā ʻaoʻao a ʻaʻole pono e hoʻopā hou ʻia.)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Nā mea i `data` ʻaʻole i hāʻawi ʻia i kēia manawa.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// I ka mea hou iterator ma o ka haawi mai `array`.
    ///
    /// *Note*: keia iaoia paha e kaila ma ka future, ma hope [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // ʻO ke ʻano o `value` kahi `i32` ma aneʻi, ma kahi o `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: palekana maoli ka transmute ma aneʻi.Na Palapala o `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ua ua hoʻohiki ia i na ia nui, a hoʻopololei
        // > e like me `T`.
        //
        // Hōʻike nā Docs i kahi transmute mai kahi hoʻonohonoho o `MaybeUninit<T>` i kahi lāina o `T`.
        //
        //
        // Me kēlā, ua māʻona kēia hoʻomaka ʻana i ka poʻe invariants.

        // FIXME(LukasKalbertodt): hoʻohana maoli iā `mem::transmute` ma aneʻi, ke hana pū ia me nā generics Const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // A laila, ua hiki ke hoʻohana `mem::transmute_copy` e hana i kekahi bitwise kope me he okoaʻano, a laila, poina `array` no laila, i ka mea, ua i haule.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Hoʻi he luli ole māhele o nā kumu mua i i ole, ua lele aku nae.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // Maluhia: mākouʻike i nā mea a pau nā kumumea i loko o `alive` e pono initialized.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Hoʻihoʻi i kahi ʻāpana hikiwawe o nā mea āpau i hāʻawi ʻole ʻia.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // Maluhia: mākouʻike i nā mea a pau nā kumumea i loko o `alive` e pono initialized.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // E kiʻi i ka aʻe 'inideka, mai ke alo.
        //
        // ʻO ka hoʻonui ʻana iā `alive.start` e 1 mālama i ka invariant e pili ana iā `alive`.
        // Eia nō naʻe, ma muli o kēia loli, no kahi manawa pōkole, ʻaʻole `data[alive]` ka wahi ola, akā `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // E heluhelu i ka hehee ai, mai ka hoʻonohonoho.
            // SAFETY: `idx` kahi helu kuhikuhi i ka mahele "alive" o ka
            // lālani.ʻO ka heluhelu ʻana i kēia kumumanaʻo ua manaʻo ʻia ʻo `data[idx]` me he mea make lā i kēia manawa (ie ʻaʻole e hoʻopā).
            // Like `idx` i ka hoʻomaka 'ana o ka mea e ola ana-ciia, ka mea e ola ana ciia o `data[alive]` hou manawa, hoihoi hou ana a pau invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // E kiʻi i ka papa kuhikuhi hou mai ka hope.
        //
        // ʻO ka hōʻemi ʻana iā `alive.end` e 1 mālama i ka invariant e pili ana iā `alive`.
        // Eia naʻe, ma muli o ia kēia loli, no ka pōkole manawa, ka mea e ola ana ciia mea ole `data[alive]` hou, akā, `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // E heluhelu i ka hehee ai, mai ka hoʻonohonoho.
            // SAFETY: `idx` kahi helu kuhikuhi i ka mahele "alive" o ka
            // lālani.ʻO ka heluhelu ʻana i kēia kumumanaʻo ua manaʻo ʻia ʻo `data[idx]` me he mea make lā i kēia manawa (ie ʻaʻole e hoʻopā).
            // ʻOiai ʻo `idx` ka hopena o ka zona ola, ʻo ka wahi ola i kēia manawa ʻo `data[alive]` hou, e hoʻihoʻi ana i nā mea invariants āpau.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: Palekana kēia: hoʻihoʻi pololei ʻo `as_mut_slice` i ka sub-slice
        // o ka oihana mua i i ole, ua nee mai no nae, a ua koe ia e haule iho la iluna.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // , Aole loa ia underflow manawa i ka invariant `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Hōʻike ka mea hana i ka lōʻihi pololei.
// Ka helu o "alive" oihana mua (mea e nō e lele aku) o ka lōʻihi o ka laulā `alive`.
// Hoʻemi ʻia kēia pae i ka lōʻihi ma `next` a i ʻole `next_back`.
// Hoʻemi mau ʻia ia e 1 i kēlā mau ʻano hana, akā inā hoʻihoʻi ʻia ʻo `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Hoʻomaopopo, ʻaʻole pono mākou e kūlike i ka pae ola like, no laila hiki iā mākou ke clone i offset 0 me ka nānā ʻole i kahi o `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone a pau e ola ana hehee wale.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Kākau i kahi clone i loko o ka lālani hou, a laila hoʻohou i kāna pae ola.
            // Inā kālone ʻia panics, e hāʻule pololei mākou i nā mea ma mua.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Wale e kakau na kumu mua i i ole alaila kuu aku la ia i: mākou hiki ole keʻeʻe ma ka haawi ana i hehee hou.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}