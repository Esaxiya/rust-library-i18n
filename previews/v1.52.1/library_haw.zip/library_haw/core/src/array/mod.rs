//! Nā hana o nā mea e like me `Eq` no nā lōʻihi lōʻihi paʻa a i kekahi lōʻihi.
//! ʻO ka hopena, hiki iā mākou ke hoʻonui i nā lōʻihi āpau.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Hoʻololi i kahi kuhikuhi i `T` i kahi kuhikuhi i kahi lālani o ka lōʻihi 1 (me ke kope ʻole).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // Maluhia: hoʻololi `&T` i `&[T; 1]` mea kani.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Pio he mutable olua i `T` i loko o ka mutable pili i ka kaua o ka lōʻihi 1 (me ka hoʻopiliʻana).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // SAFETY: Ke hoʻololi nei i `&mut T` i `&mut [T; 1]` ke kani.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Pili i ka hoʻoponopono trait hoʻokō wale ma huihui ikehu lā o ka paa nui
///
/// Keia trait hiki ke hoʻohana 'ia?' Ē traits i paa-nui huihui ikehu lā ole ma o na la nui metadata bloat.
///
/// Ka trait ua hoailono aku la unsafe i mea no ka hoʻohāiki 'implementors i paa-nui huihui ikehu lā.
/// Hiki i kahi mea hoʻohana o kēia trait ke kuhi i ka hoʻonohonoho pono i ka hoʻonohonoho pono i ka hoʻomanaʻo ʻana i kahi hoʻonohonoho paʻa paʻa (no ka laʻana, no ka hoʻomaka mua ʻole ʻana.
///
///
/// E noke i ka traits [`AsRef`] a me [`AsMut`] i like epekema no ke ano i hiki ole e paa-nui huihui ikehu lā.
/// Pono nā mea hoʻokō e makemake i kēlā traits ma kahi.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Pio i ke kaua i ka luli ole māhele
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Hoʻohuli i ka lālani i kahi ʻāpana mutable
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Ua hoʻi ka ʻano hewa ke hoʻololi ʻole kahi hoʻololi mai kahi ʻāpana i kahi hoʻonohonoho.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // SAFETY: maikaʻi no ka mea ua nānā wale mākou i ka lōʻihi o ka lōʻihi
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // SAFETY: maikaʻi no ka mea ua nānā wale mākou i ka lōʻihi o ka lōʻihi
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: kāpae ʻia kekahi impls ʻoi aku ka nui o ka nui e hōʻemi i ka bloat code
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// E kakau mai e like me ka ikehu lā [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Ke Default impls hiki ole ke hana me ka const generics no ka mea, `[T; 0]` 'aʻole i koi Default ia e hoʻokō, a me ka' okoʻa impl ālai 'no kekahi huina ua ole kākoʻo nae.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// Hoʻihoʻi i kahi lālani o ka nui like me `self`, me ka hana `f` i noi ʻia i kēlā me kēia mea i ke kaʻina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // Maluhia: ua ike no kekahi i keia iterator e hookuu aku me kēia nui `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zips i luna' i ʻelua hoʻonohonoho i hoʻokahi lālani pālua.
    ///
    /// `zip()` hoʻihoʻi i kahi hoʻonohonoho hou kahi tuple kahi o nā mea mua kahi i hele mai ai ka mea mua mai ka lālani mua, a ʻo ka lua o nā mea mai ka lālani ʻelua.
    ///
    /// I nā huaʻōlelo ʻē aʻe, zip pū ʻia ia i ʻelua hoʻonohonoho, i hoʻokahi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // Maluhia: ua ike no kekahi i keia iterator e hookuu aku me kēia nui `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Hoʻihoʻi i kahi ʻāpana i piha i ka lālani holoʻokoʻa.Kūlike ʻia me `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Hoʻi kekahi mutable māhele i loaʻa i ka hoʻonohonoho holoʻokoʻa.
    /// Kūlike ʻia me `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Noi wale aku kēlā hehee ai, a hoi mai i ke kaua ana o nä haumäna a me ka ia nui me `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// ʻOi loa ka maikaʻi o kēia hana inā hoʻohui ʻia me nā ʻano hana ʻē aʻe, e like me [`map`](#method.map).
    /// Keia ala, e hiki ke pakele neʻe maila i ka palapala e kaua ina kona oihana mua i ole `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // E hiki nō keʻeʻe ma ka palapala ku: ka mea, i ole, ua nee aku no ia.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // Maluhia: ua ike no kekahi i keia iterator e hookuu aku me kēia nui `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Hoʻoiho i kēlā me kēia meahana e hiki ke hoʻololi a hoʻihoʻi i kahi hoʻonohonoho o nā kūmole hiki ke hoʻololi ʻia me ka nui like me `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // Maluhia: ua ike no kekahi i keia iterator e hookuu aku me kēia nui `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// Huki i nā mea `N` mai `iter` a hoʻihoʻi iā lākou ma ke ʻano he hoʻonohonoho.
/// Inā hāʻawi ka iterator i mau mea ma mua o `N` mau mea, hōʻike kēia hana i ka lawena i hōʻike ʻole ʻia.
///
///
/// E nānā i [`collect_into_array`] no ka 'ike hou aku.
///
/// # Safety
///
/// Aia ia i ka mea kelepona e hōʻoia i ka loaʻa ʻana o `iter` ma kahi o `N` mau mea.
/// ʻO ka hōʻino ʻana i kēia kūlana ke kumu o ka lawena kūpono ʻole.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: ʻO `TrustedLen` kahi o kahi hoʻokolohua.He wale kēia
    // hana kūloko, no laila e ʻoluʻolu e hemo inā pili kēia i ka manaʻo maikaʻi ʻole.
    // I kēlā hihia, e hoʻomanaʻo e hoʻoneʻe hoʻi i ka `debug_assert!` paʻa lalo ma lalo!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // SAFETY: uhi ʻia e ka ʻaelike hana.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// Pulls `N` ikamu mai `iter`, a hoike ia e like me ka kū'ē.Inā hāʻawi ka iterator i mau mea ma mua o `N` mau mea, hoʻihoʻi ʻia ʻo `None` a hāʻule nā mea i loaʻa i ka wā.
///
/// Ma muli o ka hala ʻana o ka iterator ma ke ʻano he hiki ke hoʻololi a kāhea kēia hana iā `next` i ka hapa nui o nā manawa `N`, hiki ke hoʻohana ʻia ka iterator ma hope e kiʻi i nā mea i koe.
///
///
/// Inā `iter.next()` panick, hāʻule nā mea āpau i hāʻawi ʻia e ka iterator.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // SAFETY: Noho mau ʻia kahi lālani nele a ʻaʻohe ona invariants kūpono.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // SAFETY: e loaʻa i kēia ʻoki maka nā mea i hoʻomaka mua ʻia.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // SAFETY: Hoʻomaka ʻo `guard.initialized` ma 0, hoʻonui ʻia e hoʻokahi ma ka
        // loop, a me ka loop ua'ō'ū koke mea hiki N (i o `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // E hōʻoia inā ua hoʻokumu ʻia ka pūʻulu holoʻokoʻa.
        if guard.initialized == N {
            mem::forget(guard);

            // SAFETY: ke kuhi i luna aʻe nei e ʻōlelo i nā kumumea āpau
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Keia ua wale i ina ua ho'āʻo 'o ka iterator mua `guard.initialized` ihoiho `N`.
    //
    // E hoʻomaopopo hoʻi ua hāʻule ʻo `guard` ma aneʻi, e hoʻokuʻu i nā mea i hoʻomaka mua ʻia.
    None
}