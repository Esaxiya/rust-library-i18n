//! Nā koho koho.
//!
//! Hoʻohālikelike ka [`Option`] i kahi waiwai koho: ʻo kēlā me kēia [`Option`] a [`Some`] paha a loaʻa kahi waiwai, a i ʻole [`None`], a ʻaʻole.
//! [`Option`] ʻike nui ʻia nā ʻano ma ka pāʻālua Rust, no ka mea, he nui nā hoʻohana.
//!
//! * Nā waiwai mua
//! * Nā helu hoʻihoʻi no nā hana i wehewehe ʻole ma luna o kā lākou pae komo āpau (nā ʻāpana hapa)
//! * E hoʻihoʻi i ka waiwai no ka hōʻike ʻana i nā hemahema maʻalahi, kahi i hoʻihoʻi ʻia ai ʻo [`None`] ma ke kuhi hewa
//! * Nā māla estr nā koho
//! * Nā kahua kūkulu i hiki ke hōʻaiʻē a i ʻole "taken"
//! * Nā manaʻo hoʻopaʻapaʻa koho
//! * Kuhikihi nullable
//! * Ke hoʻololi nei i nā mea mai nā hanana paʻakikī
//!
//! Hoʻohui like ʻia ʻo [Option`] me ke kumu hoʻohālikelike e nīnau i ke alo o kahi waiwai a hana i ka hana, e helu mau ana i ka hihia [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ʻO ka waiwai hoʻihoʻi o ka hana he koho
//! let result = divide(2.0, 3.0);
//!
//! // Kūlike ke kumu hoʻohālikelike e kiʻi i ka waiwai
//! match result {
//!     // Ua kūpono ka mahele
//!     Some(x) => println!("Result: {}", x),
//!     // Ua kūpono ʻole ka mahele
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Hōʻike pehea e hoʻohana ʻia ai `Option` i ka hana, me nā ʻano hana he nui
//
//! # Nā koho a me nā kuhikihi ("nullable" pointers)
//!
//! Rust ka laʻau kuhikuhiʻAno pono mau kuhikuhi i ka henua pololei e huli;ʻaʻohe "null" kūmole.Ma kahi o, Rust he mau kuhikuhi kuhikuhi * koho, e like me ka pahu pono koho, [`ʻAno`]`<`[Box<T>`]>>.
//!
//! Hoʻohana ka hiʻohiʻona aʻe i ka [`Option`] e hana i kahi pahu koho o [`i32`].
//! E hoʻomaopopo i ka mea e hoʻohana ai i ka waiwai [`i32`] i loko ma mua, pono ka hana `check_optional` e hoʻohana i ke ʻano hoʻohālikelike e hoʻoholo inā he waiwai ka pahu (ʻo ia hoʻi, ʻo [`Some(...)`][`Some`]) a ʻaʻole ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Hōʻoiaʻiʻo ʻo Rust e hoʻonui i nā ʻano `T` aʻe e like me ka nui o ka [`Option<T>`] me `T`.
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` kūkulu puni i kekahi o nā ʻano i kēia papa inoa.
//!
//! Hōʻoia ʻē ʻia ia, no nā hihia i luna, hiki i kekahi ke [`mem::transmute`] mai nā waiwai kūpono āpau o `T` a i `Option<T>` a mai `Some::<T>(_)` a i `T` (akā ʻo ka hoʻoili ʻana i `None::<T>` i `T` ka hana i hoʻoholo ʻole ʻia).
//!
//! # Examples
//!
//! Hoʻohālikelike ka hoʻohālikelike kumu ma [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // E lawe i kahi kuhikuhi i ke aho i hoʻopaʻa ʻia
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Wehe i ke aho i hoʻopaʻa ʻia, e luku ana i ke koho
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! E hoʻomaka i kahi hopena i [`None`] ma mua o kahi loop:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // He papa inoa o ka ʻikepili e ʻimi ai.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // E ʻimi ana mākou i ka inoa o ka holoholona nui, akā e hoʻomaka me ka loaʻa iā `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // I kēia manawa ua loaʻa iā mākou ka inoa o kekahi holoholona nui
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// ʻO ka `Option` ʻano.E ʻike iā [the module level documentation](self) no ka mea hou aku.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// ʻAʻohe waiwai
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// ʻO kekahi waiwai `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ʻAno hoʻokō
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Ke noi nei i nā waiwai i loaʻa
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻi iā `true` inā he [`Some`] ke koho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Hoʻi iā `true` inā he [`None`] ke koho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Huli `true` ina ke koho mea he [`Some`] waiwai i loaʻa i ka haawi waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter no ka hana ʻana me nā kūmole
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻololi mai `&Option<T>` a `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Hoʻohuli i kahi `ʻAno <<[String`]`>`i loko o kahi ʻO Option <`[`usize`]`>>, e mālama nei i ke kumu.
    /// Lawe ka hana [`map`] i ka `self` hoʻopaʻapaʻa e ka waiwai, e hoʻopau ana i ke kumu, no laila hoʻohana kēia hana i ka `as_ref` e lawe mua i kahi `Option` i kahi kuhikuhi i ka waiwai i loko o ke kumu.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // ʻO ka mea mua, hoʻolei iā `Option<String>` i `Option<&String>` me `as_ref`, a laila hoʻopau iā *kēlā* me `map`, e waiho ana iā `text` ma ka puʻu.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Hoʻololi mai `&mut Option<T>` a `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Hoʻololi mai [Pin]] <&koho<T>> `i ka 'Option <` [`Pin`]`<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // SAFETY: Hōʻoiaʻiʻo ʻia ʻo `x` e hoʻopili ʻia no ka mea mai `self` ia
        // ka mea i pinia.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Hoʻololi mai [Pin]] <&mut koho<T>> `i ka 'Option <` [`Pin`]`<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // SAFETY: `get_unchecked_mut` ʻaʻole hoʻohana ʻia e neʻe i ka `Option` i loko o `self`.
        // `x` hoʻohiki ʻia e pin ʻia no ka mea mai `self` i hoʻopaʻa ʻia.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ke kiʻi nei i nā waiwai
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻihoʻi i ka waiwai [`Some`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// # Panics
    ///
    /// Panics ina o ka waiwai o ka [`None`] me ka mea mau panic memo i hoʻolako 'ia e `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Some`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// Ma muli o kēia hana panic, hoʻonāwaliwali ʻia ka hoʻohana ʻana.
    /// Ma kahi o, makemake e hoʻohana i ke ʻano hoʻohālikelike a lawelawe i ka hihia [`None`] me ka maopopo, a i ʻole kāhea iā [`unwrap_or`], [`unwrap_or_else`], a i ʻole [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics inā like ka waiwai ponoʻī me [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Some`] i loaʻa a i ʻole kahi paʻamau i hāʻawi ʻia.
    ///
    /// Kuhi ʻia nā hoʻopaʻapaʻa i `unwrap_or`;inā ʻoe e hele i ka hopena o kahi kāhea hana, makemake ʻia e hoʻohana iā [`unwrap_or_else`], i loiloi lohi ʻia.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Some`] i hoʻopaʻa ʻia a helu ʻia paha mai kahi pani.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Some`] i loko, e hoʻopau ana i ka waiwai `self`, me ka nānā ʻole ʻana ʻaʻole [`None`] ka waiwai.
    ///
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana ma [`None`] ka *[hana i hoʻoholo ʻole ʻia]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Undefined ana!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // Maluhia: pono e kokuaia oia e ka Caller ka maluhia like.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ke hoʻololi nei i nā waiwai i loaʻa
    /////////////////////////////////////////////////////////////////////////

    /// Nā palapala aniani `Option<T>` a `Option<U>` ma ke noi ʻana i kahi hana i kahi waiwai i loaʻa.
    ///
    /// # Examples
    ///
    /// Hoʻohuli i kahi `ʻAno <<[String`]`>`i loko o kahi ʻO koho <`[`usize`]`>>, e ʻai ana i ke kumu:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` lawe iā ʻoe iho *ma ka waiwai*, e ʻai ana iā `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Pili i kahi hana i ka waiwai i loaʻa (inā paha), a i hoʻihoʻi i ka paʻamau i hāʻawi ʻia (inā ʻaʻole).
    ///
    /// Manaʻo hoʻopiʻi kū'ē i hooholoia i `map_or` i eagerly loiloi ';inā ʻoe e hele i ka hopena o kahi kāhea hana, makemake ʻia e hoʻohana iā [`map_or_else`], i loiloi lohi ʻia.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Pili i kahi hana i ka waiwai i loaʻa (inā kekahi), a i ʻole helu ʻana i kahi paʻamau (inā ʻaʻole).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Hoʻololi i ka `Option<T>` i [`Result<T, E>`], palapala kiʻi [`Some(v)`] i [`Ok(v)`] a me [`None`] i [`Err(err)`].
    ///
    /// Kuhi ʻia nā hoʻopaʻapaʻa i `ok_or`;ina oe e hele ana i ka hopena o ka papa hea, ka mea, ua? aeiiaiaoaony e hoʻohana [`ok_or_else`], i ua lazily loiloi '.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Hoʻololi i ka `Option<T>` i [`Result<T, E>`], palapala kiʻi [`Some(v)`] i [`Ok(v)`] a me [`None`] i [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Hoʻokomo i `value` i ke koho a laila hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi iā ia.
    ///
    /// Inā loaʻa ka waiwai i ka koho, ua hāʻule ka waiwai kahiko.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // SAFETY: ua hoʻopiha ke code ma luna i ke koho
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ʻO nā mea kūkulu Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻihoʻi i kahi iterator ma luna o ka waiwai i loaʻa paha.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Hoʻihoʻi i kahi iterator hiki ke hoʻololi ʻia ma luna o ka waiwai i loaʻa i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Hana ʻo Boolean i nā waiwai, hoihoi a palaualelo
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻi iā [`None`] inā [`None`] ke koho, a i ʻole hoʻi hoʻihoʻi iā `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Hoʻihoʻi iā [`None`] inā ʻo [`None`] ke koho, a i ʻole kāhea iā `f` me ka waiwai i wahī ʻia a hoʻihoʻi i ka hopena.
    ///
    ///
    /// Kāhea kekahi mau ʻōlelo i kēia papa hana i flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Hoʻi iā [`None`] inā ʻo [`None`] ke koho, a i ʻole kāhea iā `predicate` me ka waiwai i wahī ʻia a hoʻi.
    ///
    ///
    /// - [`Some(t)`] inā hoʻihoʻi ʻo `predicate` iā `true` (kahi ʻo `t` ka waiwai i ʻōwili ʻia), a
    /// - [`None`] inā hoʻihoʻi `predicate` iā `false`.
    ///
    /// Hana like kēia hana me [`Iterator::filter()`].
    /// Oe ke hoi i noonoo ai i ka `Option<T>` i ka iterator ma luna o kekahi 'ole' Aʻohe hehee wale.
    /// `filter()` e ʻae iā ʻoe e hoʻoholo i nā mea e mālama ai.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// E hoʻihoʻi i ke koho inā loaʻa kahi waiwai, hoʻihoʻi iā `optb`.
    ///
    /// Kuhi ʻia nā hoʻopaʻapaʻa i `or`;ina oe e hele ana i ka hopena o ka papa hea, ka mea, ua? aeiiaiaoaony e hoʻohana [`or_else`], i ua lazily loiloi '.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Hoʻihoʻi i ke koho inā loaʻa kahi waiwai, e kāhea iā `f` a hoʻihoʻi i ka hopena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Hoʻi iā [`Some`] inā pololei kekahi o `self`, `optb` ʻo [`Some`], a i ʻole hoʻi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Nā hana e like me ke komo e hoʻokomo inā ʻaʻohe a hoʻihoʻi i kahi kūmole
    /////////////////////////////////////////////////////////////////////////

    /// Inserts `value` i loko o ke koho ina mea o [`None`], alaila, hoi mai i ka mutable pili i ka kakauiaʻi maluna waiwai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Hoʻokomo i ka waiwai paʻamau i loko o ke koho inā [`None`] ia, a laila hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka waiwai i loaʻa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Hoʻokomo i kahi waiwai i helu ʻia mai `f` i loko o ke koho inā [`None`] ia, a laila hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka waiwai i loaʻa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // SAFETY: ua hoʻololi ʻia kahi ʻano `None` no `self` e `Some`
            // ʻokoʻa i ke code ma luna.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// E lawe i ka waiwai mai o ke koho, e waiho i ka [`None`] ma kona wahi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Hoʻololi i ka waiwai maoli i ke koho e ka waiwai i hāʻawi ʻia i ka parameter, e hoʻihoʻi ana i ka waiwai kahiko inā aia, e waiho ana i kahi [`Some`] ma kona wahi me ka hoʻokaʻawale ʻole ʻana i kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Zips `self` me kekahi `Option`.
    ///
    /// Inā `self` ʻo `Some(s)` a `other` ʻo `Some(o)`, hoʻihoʻi kēia ala iā `Some((s, o))`.
    /// Inā ʻole, hoʻihoʻi ʻia ʻo `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` a me kekahi `Option` me ka hana `f`.
    ///
    /// Inā `self` ʻo `Some(s)` a `other` ʻo `Some(o)`, hoʻihoʻi kēia ala iā `Some(f(s, o))`.
    /// Inā ʻole, hoʻihoʻi ʻia ʻo `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Maps he `Option<&T>` i ka `Option<T>` ma ka hoʻopiliʻana kahi o ke koho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Maps he `Option<&mut T>` i ka `Option<T>` ma ka hoʻopiliʻana kahi o ke koho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Palapala 'āina i `Option<&T>` i kahi `Option<T>` ma ke kāloke ʻana i nā ʻike o ke koho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Palapala 'āina i `Option<&mut T>` i kahi `Option<T>` ma ke kāloke ʻana i nā ʻike o ke koho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Pau `self` ʻoiai ke manaʻo nei iā [`None`] a hoʻi ʻole i kekahi mea.
    ///
    /// # Panics
    ///
    /// Panics inā he [`Some`] ka waiwai, me kahi leka panic me ka leka i hala, a me ka ʻike o ka [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ʻAʻole kēia e panic, ʻoiai nā kī āpau āpau.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Pau `self` ʻoiai ke manaʻo nei iā [`None`] a hoʻi ʻole i kekahi mea.
    ///
    /// # Panics
    ///
    /// Panics inā he [`Some`] ka waiwai, me kahi leka panic maʻamau i hāʻawi ʻia e ka waiwai ['Some`]' s.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ʻAʻole kēia e panic, ʻoiai nā kī āpau āpau.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Hoʻihoʻi i ka waiwai [`Some`] i hoʻopaʻa ʻia a i ʻole kahi paʻamau
    ///
    /// Pau ka hoʻopaʻapaʻa `self` a laila, inā [`Some`], hoʻihoʻi i ka waiwai i loaʻa, a i ʻole inā [`None`], hoʻihoʻi i ka [default value] no kēlā ʻano.
    ///
    ///
    /// # Examples
    ///
    /// Pio he kaula i ka helu, huli poorly-hana kaula i loko o 0 (ka paʻamau waiwai io no integers).
    /// [`parse`] pio i ke kaula i kekahi 'ē' ano i mea lapaʻau [`FromStr`], hoi mai [`None`] ma ka hewa.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Hoʻololi mai `Option<T>` (a i ʻole `&Option<T>`) a i `Option<&T::Target>`.
    ///
    /// Haʻalele i ka Option kumu ma kahi, e hana ana i kahi hou me kahi kuhikuhi i ka mea kumu, me ka hoʻokau ʻana i ka ʻike ma o [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Hoʻololi mai `Option<T>` (a i ʻole `&mut Option<T>`) a i `Option<&mut T::Target>`.
    ///
    /// Lau o ka palapala `Option` ma-wahi, e pili ana i ka hou kekahi i loaʻa i ka mutable pili ana i ka pā type ka `Deref::Target` type.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Hoʻololi i `Option` o [`Result`] i [`Result`] o `Option`.
    ///
    /// [`None`] e palapala 'āina iā [Ok'] `(` `ʻAʻohe`]`) ʻ.
    /// [`Kekahi`]`(`[ʻAk`]` (_)) ʻ and [`Some`]`(`` (``Err`] `(_))` ʻelele mapa iā [ʻAk`]`(`[` Kekahi`]`(_))`a me [`Err`]` (_) ʻ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// He hana kaʻawale kēia e hōʻemi i ka nui o ke code o .expect() ponoʻī.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// He He hookaawale papa, e emi i ke karaima nui o .expect_none() iho.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Nā hoʻokō Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Hoʻi iā [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Hoʻihoʻi i kahi iterator e hoʻopau ana ma luna o ka waiwai i loaʻa i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Kope iā `val` i kahi `Some` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Hoʻololi mai `&Option<T>` a `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Hoʻohuli i kahi `ʻAno <<[String`]`>`i loko o kahi ʻO Option <`[`usize`]`>>, e mālama nei i ke kumu.
    /// Lawe ka hana [`map`] i ka `self` hoʻopaʻapaʻa e ka waiwai, e hoʻopau ana i ke kumu, no laila hoʻohana kēia hana i ka `as_ref` e lawe mua i kahi `Option` i kahi kuhikuhi i ka waiwai i loko o ke kumu.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Hoʻololi mai `&mut Option<T>` a `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Nā ʻIterators Option
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// He iterator ma luna o kahi kuhikuhi i ka [`Some`] ʻano o kahi [`Option`].
///
/// Hāʻawi ka iterator i hoʻokahi waiwai inā he [`Some`] ka [`Option`], inā ʻaʻohe.
///
/// Hana ʻia kēia `struct` e ka hana [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// An iterator ma luna o ka mutable pili i ka [`Some`] Lolina o ka [`Option`].
///
/// Hāʻawi ka iterator i hoʻokahi waiwai inā he [`Some`] ka [`Option`], inā ʻaʻohe.
///
/// Hana ʻia kēia `struct` e ka hana [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// He iterator ma luna o ka waiwai ma [`Some`] ʻano o kahi [`Option`].
///
/// Hāʻawi ka iterator i hoʻokahi waiwai inā he [`Some`] ka [`Option`], inā ʻaʻohe.
///
/// Hana ʻia kēia `struct` e ka hana [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Lawe i kēlā me kēia meahana i ka [`Iterator`]: inā he [`None`][Option::None], ʻaʻohe mea i lawe hou ʻia, a hoʻihoʻi ʻia ka [`None`][Option::None].
    /// Inā ʻaʻole [`None`][Option::None] e kū mai, hoʻihoʻi ʻia kahi ipu me nā waiwai o kēlā me kēia [`Option`].
    ///
    /// # Examples
    ///
    /// Eia kahi laʻana e hoʻonui ai i kēlā me kēia helu i vector.
    /// Hoʻohana mākou i ka loli nānā ʻia o `add` e hoʻihoʻi iā `None` ke hopena ka helu ʻana i kahi kahawai.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// E like me kāu e ʻike ai, e hoʻihoʻi kēia i nā mea i manaʻo ʻia, nā mea kūpono.
    ///
    /// Eia kekahi laʻana e hoʻāʻo e unuhi i kekahi mai kekahi papa inoa o nā integers, i kēia manawa ke nānā nei i ka underflow:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// No ka mea he zero ka mea hope loa, e kahe ana ia.No laila, ʻo `None` ka waiwai i loaʻa.
    ///
    /// Eia kahi hoʻololi ma ka laʻana ma mua, e hōʻike ana ʻaʻole lawe ʻia nā mea hou mai `iter` ma hope o ka `None` mua.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Ma muli o ke kolu o ka mea i hoʻokumu i kahi kahe, ʻaʻole i lawe ʻia nā mea hou aʻe, no laila ʻo ka waiwai hope loa o `shared` he 6 (= `3 + 2 + 1`), ʻaʻole 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Hiki ke hoʻololi i kēia me Iterator::scan ke pani ʻia kēia hewa hana.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ʻO ke ʻano hemahema i hopena ʻia mai ka noi ʻana i ka mea hoʻāʻo (`?`) i kahi waiwai `None`.
/// Inā makemake ʻoe e ʻae iā `x?` (kahi `x` kahi `Option<T>`) e hoʻohuli ʻia i kāu ʻano hemahema, hiki iā ʻoe ke hoʻokō iā `impl From<NoneError>` no `YourErrorType`.
///
/// I kēlā hihia, `x?` ma waena o kahi hana e hoʻihoʻi iā `Result<_, YourErrorType>` e unuhi i kahi waiwai `None` i kahi hopena `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Hoʻololi mai `Option<Option<T>>` a `Option<T>`
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Flattening lawe aku oe i kekahi kiʻekiʻe o aiacayueony i kekahi manawa wale:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}