//! Functionality no ka hoonoho papa ana ia a me ka like.
//!
//! Aia kēia module i nā pono hana like ʻole no ke kauoha ʻana a me ka hoʻohālikelike ʻana i nā waiwai.I ka hōʻuluʻulu manaʻo:
//!
//! * [`Eq`] a me [`PartialEq`] ʻo traits e ʻae iā ʻoe e wehewehe i ka like a me ka hapa kaulike ma waena o nā waiwai.
//! Ke hoʻonui nei iā lākou i nā `==` a me nā mea hoʻohana `!=`.
//! * [`Ord`] a me [`PartialOrd`] i traits e ae oe e hoakaka huina a me ka helehelena a ua kauoha nō ma waena o nā loina, niioaaonoaaiii.
//!
//! Ke hoʻonui nei iā lākou i nā `<`, `<=`, `>`, a me nā mea hoʻohana `>=`.
//! * [`Ordering`] mea he enum hoi ma ka papa kuhikuhiE mana o [`Ord`] a me [`PartialOrd`], a wehewehe i ka hoonoho papa ana ia.
//! * [`Reverse`] he kumu e ʻae iā ʻoe e hoʻololi maʻalahi i kahi kauoha.
//! * [`max`] a me [`min`] nā hana i hana aku o [`Ord`], a ae oe, e huli i ka i kā mākou a me ka palena iki o ka mau loina.
//!
//! No nā kikoʻī hou aku, e ʻike i nā palapala ponoʻī o kēlā me kēia mea i ka papa inoa.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait no ka like Hoʻohālikelike maikaʻi i nā [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Keia trait apono 'no ka hapa e hoʻokolokolo pono, no ka mea, ano e mai,ʻaʻole i ka piha equivalence ana.
/// ʻO kahi laʻana, i nā helu lana lana `NaN != NaN`, no laila, hoʻokomo nā ʻano lana lana i `PartialEq` akā ʻaʻole [`trait@Eq`].
///
/// Formally, ka mea e hoʻokolokolo pono pono e (no ka mea a pau `a`, `b`, `c` o ke 'ano `A`, `B`, `C`):
///
/// - **Symmetric**: ina `A: PartialEq<B>` a me `B: PartialEq<A>`, laila **'he==b`hoʻohuʻu' b.==a`**;a
///
/// - **Transitive**: inā `A: PartialEq<B>` a me `B: PartialEq<C>` a me `A:
///   PartialEq<C>`, Laila **'he==b` a me `b == c` hoʻohuʻu' he==c`**.
///
/// Note i ka `B: PartialEq<A>` (symmetric) a me `A: PartialEq<C>` (transitive) impls ka mea,ʻaʻole lākou e ola ana, akā, i kēia mau koi pili manawa a pau e hana hoi ma-.
///
/// ## Derivable
///
/// Hiki ke hoʻohana ʻia kēia trait me `#[derive]`.Ke `derive`d i nā kaula, like nā hanana ʻelua inā kūlike nā māla āpau, a ʻaʻole kaulike inā ʻaʻole kaulike nā pā.Ka wā 'derive`d ma enums, kēlā Lolina Ua like ia iho, aʻaʻole i keia i ka mea'ē aʻe Lolina.
///
/// ## Pehea e hiki ai iaʻu ke hoʻokō iā `PartialEq`?
///
/// `PartialEq` pono wale nō e hoʻokō i ke ʻano [`eq`];[`ne`] ua ho'ākāka 'ia ma ka hua'ōlelo o ka mea ma ka paʻamau.Kekahi manuale manaʻo o [`ne`]*pono* mahalo i ka rula e [`eq`] mea he ikaika inverse o [`ne`];ʻo ia hoʻi, `!(a == b)` inā a inā `a != b` wale nō.
///
/// Nā palapala hoʻokō o `PartialEq`, [`PartialOrd`], a me [`Ord`]*pono* ʻaelike kekahi i kekahi.ʻO oluolu e accidentally e ia i kū'ē'ē ai ma ka Napuelua kekahi o ka traits a me ka hana lima hoʻokō 'ē aʻe.
///
/// ʻO kahi laʻana e hana nei no kahi kikowaena kahi i manaʻo ʻia ai nā puke ʻelua i puke like inā pili like kā lākou ISBN, ʻoiai inā ʻokoʻa nā ʻano.
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Pehea e hiki ai au e hoohalike ai eluaʻano?
///
/// Keʻano oe e like me ka ua hoi malalo o ko 'PartialEq` ka type aiao.
/// ʻO kahi laʻana, e hoʻopili iki i kā mākou code mua:
///
/// ```
/// // Hoʻokomo ka mea loaʻa<BookFormat>==<BookFormat>hoʻohālikelike
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Hoʻokomo<Book>==<BookFormat>hoʻohālikelike
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // hoʻokō i<BookFormat>==<Book>like me kā
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Ma ka hoʻololi ʻana iā `impl PartialEq for Book` i `impl PartialEq<BookFormat> for Book`, ʻae mākou e hoʻohālikelike ʻia nā `BookFormat` me nā`Book`s.
///
/// A hoʻohālike e like me ka kekahi luna, i ignores kekahi mahinaʻai o ka struct, hiki e weliweli.Ua hiki wawe ka alakai i ka unintended 'aʻe ana i nā koi no ka hapa equivalence ana.
/// No ka laʻana, ina ua mālama i ka luna manaʻo o `PartialEq<Book>` no `BookFormat`, a hou i ka manaʻo o `PartialEq<Book>` no `Book` (kekahi i kekahi `#[derive]` a Via ka manuale manaʻo i ka hana mua mai) laila, i ka hopena e kue ana transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Kēia hana e ho'āʻo ai no `self` a me `other` nā loina i e like ana, a ua hoʻohana 'ia e `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Hōʻaia kēia hana no `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Loaa nunui hoʻomakaʻia ka impl o ka trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait no ka like Hoʻohālikelike maikaʻi i nā [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Keia mea, i ka hou ana i `a == b` a me `a != b` i ikaika inverses, ka like pono e (no ka mea a pau `a`, `b` a me `c`):
///
/// - reflexive: `a == a`;
/// - symmetric: `a == b` hoʻohuʻu `b == a`;a me ka
/// - transitive: `a == b` a me `b == c` hoʻohuʻu `a == c`.
///
/// ʻAʻole hiki ke nānā ʻia kēia waiwai e ka mea hōʻuluʻulu, a no laila `Eq` e hōʻike nei iā [`PartialEq`], a ʻaʻohe ona ʻano keu.
///
/// ## Derivable
///
/// Keia trait hiki ke hoʻohana me `#[derive]`.
/// Ka wā 'derive`d, no ka mea, `Eq` ʻaʻohe keu ano, ka mea, ua wale e hoike ana i ka compiler i keia mea he equivalence hoahanau, aole ma mua o ka hapa equivalence ana.
///
/// E noke i ka `derive` kou akamai koi nā mahinaʻai i `Eq`, i ua ole mau makemake.
///
/// ## Pehea e hiki ai iaʻu ke hoʻokō iā `Eq`?
///
/// Inā ʻaʻole hiki iā ʻoe ke hoʻohana i ka hoʻolālā `derive`, kikoʻī e hoʻokō i kāu ʻano `Eq`, ʻaʻohe ona ʻano:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // keia hana ua hoʻohana 'ia n? ma#[Napuelua] e hoʻike ana na ke keʻena o keʻano mea lapaʻau#[Napuelua] iho, i ka he loko aeuiiai ieaia? hoʻi e hana i kēia assertion me ka hoʻohana' ana i kekahi papa hana ma keia trait mea aneane hiki ole i.
    //
    //
    // Kēia E loa e hoʻokōʻia e ka lima.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Hoʻokumu i ka macro e hoʻokumu i kahi impl o ka trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: keia struct ua hoʻohana 'ia n? ma#[loko] i
// hoʻike i ke keʻena o keʻano mea lapaʻau Eq kela.
//
// Kēia struct e loa hou i loko o mea hoʻohana kuhi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// An `Ordering` o ka hopena o ka hoʻohālike ma waena o nā loina.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Ke kauoha ʻana ma kahi o ka waiwai i hoʻohālikelike ʻia ma lalo o kekahi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// E kauoha ana i kahi i hoʻohālikelike ʻia ka waiwai e like me kekahi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// An hoonoho papa kahi i hoohalikeia waiwai, ua oi aku ma mua o kekahi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Hoʻi iā `true` inā ʻo ka ʻoka ke ʻano `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Huli `true` ina o ka hoonoho papa ana ia mea i ka `Equal` Lolina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Huli `true` ina o ka hoonoho papa ana ia mea i ka `Less` Lolina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Hoʻi iā `true` inā ʻo ka ʻoka ke ʻano `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Hoʻi iā `true` inā ʻo ka ʻoka ʻana he `Less` a i ʻole `Equal` ʻokoʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Hoʻi iā `true` inā ʻo ka ʻoka ʻana he `Greater` a i ʻole `Equal` ʻokoʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Nana e hoole i ka `Ordering`.
    ///
    /// * `Less` e lilo i `Greater`.
    /// * `Greater` e lilo i `Less`.
    /// * `Equal` e lilo i `Equal`.
    ///
    /// # Examples
    ///
    /// Nā hana maʻamau:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Hiki ke hoʻohana i kēia hana e hoʻohuli i kahi hoʻohālikelike:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // hoʻokaʻina i ka hoʻonohonoho mai ka nui a ka liʻiliʻi.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Kaula hilo elua hoonoho papa.
    ///
    /// Hoʻi iā `self` ke ʻole `Equal`.I ole ia, e huli hou `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Kaulahao i ke kauoha ʻana me ka hana i hāʻawi ʻia.
    ///
    /// Hoike `self` ka wā e Aloha ole `Equal`.
    /// I ole ia ke kahea aku nei `f`, a huli i ka hopena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Kahi mea kōkua no ka hoʻonohonoho hope ʻana.
///
/// ʻO kēia mea kōkua he mea kōkua e hoʻohana ʻia me nā hana e like me [`Vec::sort_by_key`] a hiki ke hoʻohana ʻia e hoʻohuli i kahi ʻāpana o ke kī.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait no nā ʻano hana i [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// ʻO kahi ʻoka kahi ʻoka holoʻokoʻa inā (no nā `a`, `b` a me `c`) a pau:
///
/// - huina a me ka asymmetric: e like kekahi o `a < b`, `a == b` a `a > b` mea oiaio;a
/// - transitive, `a < b` a me `b < c` e hōʻike nei iā `a < c`.Pono e paʻa ka mea like no `==` a me `>`.
///
/// ## Derivable
///
/// Keia trait hiki ke hoʻohana me `#[derive]`.
/// I ka `derive`d ma luna o structs, ka mea e paka i [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) hoonoho papa ma muli o ka luna-i-lalo kukala mea o ka struct ka lala.
///
/// I ka `derive`d ma enums, e kauoha Lolina ma kā lākou mau luna-i-lalo discriminant kauoha.
///
/// ## Hoʻohālikelike Lexicograpical
///
/// Lexicographical e like mea i hana me ke kēia mau waiwai:
///  - Mau kaʻina i hoʻohālike hehee ai ma ka hehee ai.
///  - Ka mua mismatching hehee ai hoakaka i ke kaʻina o lexicographically emi a oi aku ia mamua o ka 'ē aʻe.
///  - Inā he kuhimua kekahi o nā kaʻina ʻē aʻe, ʻo ka kaʻina pōkole ka lexicographically ma lalo o kekahi.
///  - Inā mau kaʻina, i like paha oihana mua a me ka mea o ka mea hookahi lōʻihi, a laila, i nā kaʻina i lexicographically like.
///  - ʻOi ke kaʻina kaʻawale lexicographically ma lalo o kekahi kaʻina kau ʻole.
///  - ʻO nā kaʻina hakahaka ʻelua he lexicographically like.
///
/// ## Pehea e hiki ai iaʻu ke hoʻokō iā `Ord`?
///
/// `Ord` pono i keʻano nō hoʻi e [`PartialOrd`] a me [`Eq`] (i pono [`PartialEq`]).
///
/// A laila pono ʻoe e wehewehe i kahi hoʻokō no [`cmp`].Oe i loaʻa ka mea pono e hoʻohana [`cmp`] ma kou 'ano o ka mahinaʻai.
///
/// Implementations o [`PartialEq`], [`PartialOrd`], a me `Ord`*pono*'aelike i kekahi i kekahi.
/// Ia mea, `a.cmp(b) == Ordering::Equal` ina a wale ina `a == b` a me `Some(a.cmp(b)) == a.partial_cmp(b)` no `a` a me nā mea a pau `b`.
/// ʻO oluolu e accidentally e ia i kū'ē'ē ai ma ka Napuelua kekahi o ka traits a me ka hana lima hoʻokō 'ē aʻe.
///
/// Eia kekahi laʻana kahi au makemake e Hoʻokaʻina kanaka ma ka kiʻekiʻe wale, ka nānāʻole `id` a me `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Kēia papa hana hoʻi i [`Ordering`] ma waena o `self` a me `other`.
    ///
    /// By aha-elele, `self.cmp(&other)`, hoi mai ka hoonoho papa ana ia'ālike o ka hōʻike `self <operator> other` ina oiaio ia mau mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Hoʻohālikelike a hoʻihoʻi i ka nui o nā waiwai ʻelua.
    ///
    /// E hoʻihoʻi i ka paio lua inā hoʻoholo ka hoʻohālikelike e like lākou.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Hoʻohālikeʻana a huli i ka palena iki o nā waiwai Hawaiʻi.
    ///
    /// E hoʻihoʻi i ka paio mua inā hoʻoholo ka hoʻohālikelike e like lākou.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Ka hoʻohāiki 'i kekahi mea i ka kekahi wā mawaena.
    ///
    /// Hoʻi iā `max` inā ʻo `self` ʻoi aku ma mua o `max`, a ʻo `min` inā ʻo `self` ma lalo o `min`.
    /// Inā ʻaʻole kēia hoʻihoʻi `self`.
    ///
    /// # Panics
    ///
    /// Panics ina `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Hoʻokumu i ka macro e hoʻokumu i kahi impl o ka trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait no nā waiwai i hiki ke hoʻohālikelike ʻia no kahi ʻoka hoʻonohonoho.
///
/// Pono e māʻona ka hoʻohālikelike, no nā `a`, `b` a me `c` āpau.
///
/// - asymmetry: inā `a < b` a laila `!(a > b)`, a me `a > b` e hōʻike nei iā `!(a < b)`;a
/// - transitivity: `a < b` a me `b < c` e hōʻike nei iā `a < c`.Pono e paʻa ka mea like no `==` a me `>`.
///
/// Note i kēia mau koi aha i ka trait iho pono e hoʻokō symmetrically a transitively: ina `T: PartialOrd<U>` a me `U: PartialOrd<V>` laila `U: PartialOrd<T>` a `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Keia trait hiki ke hoʻohana me `#[derive]`.I ka `derive`d ma luna o structs, ka mea e paka i lexicographic hoonoho papa ma muli o ka luna-i-lalo kukala mea o ka struct ka lala.
/// I ka `derive`d ma enums, e kauoha Lolina ma kā lākou mau luna-i-lalo discriminant kauoha.
///
/// ## Pehea hiki au hoʻokō `PartialOrd`?
///
/// `PartialOrd` wale pono manaʻo o ka [`partial_cmp`] ano, a me na'ē aʻe ua loaʻa mai ka paʻamau implementations.
///
/// Eia nō naʻe hiki ke hoʻokō i nā mea ʻē aʻe ʻokoʻa no nā ʻano ʻaʻohe nui o ke kauoha.
/// ʻO kahi laʻana, no nā helu helu lana, `NaN < 0 == false` a me `NaN >= 0 == false` (cf.
/// IEEE 754-2008 pauku 5.11).
///
/// `PartialOrd` koi i kou ʻano e [`PartialEq`].
///
/// Implementations o [`PartialEq`], `PartialOrd`, a me [`Ord`]*pono*'aelike i kekahi i kekahi.
/// ʻO oluolu e accidentally e ia i kū'ē'ē ai ma ka Napuelua kekahi o ka traits a me ka hana lima hoʻokō 'ē aʻe.
///
/// Inā [`Ord`] kāu ʻano, hiki iā ʻoe ke hoʻokō i [`partial_cmp`] ma ka hoʻohana ʻana iā [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Hiki paha iā ʻoe ke ʻike he mea pono e hoʻohana i [`partial_cmp`] ma kāu mau ʻano ʻano.
/// Eia kahi hiʻohiʻona o `Person` ʻano i loaʻa kahi mālame kihi `height` kahua ʻo ia wale nō ka māla e hoʻohana ai no ka hoʻokaʻawale ʻana:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Kēia papa hana hoʻi i ka hoonoho papa ana ia ma waena o `self` a me `other` aiee ina kekahi i koe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Ka wā e like mea hiki ole:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Kēia papa hana ho'āʻo ma emi ma mua o (no ka `self` a me `other`) a ua hoʻohana 'ia e ka `<` Aʻole.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Hoʻomaʻamaʻa kēia ala i lalo a i ʻole like paha (no `self` a me `other`) a hoʻohana ʻia e ka mea hoʻohana `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Kēia papa hana ho'āʻo ma oi ma mua o (no ka `self` a me `other`) a ua hoʻohana 'ia e ka `>` Aʻole.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Hōʻike kēia hana i nā mea i ʻoi aku ma mua o ka mea (no `self` a me `other`) a hoʻohana ʻia e ka mea hoʻohana `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Loaa nunui hoʻomakaʻia ka impl o ka trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Hoʻohālikeʻana a huli i ka palena iki o nā waiwai Hawaiʻi.
///
/// E hoʻihoʻi i ka paio mua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// Hoʻohana kūloko kahi inoa i [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Huli i ka palena iki o nā Hawaiʻi a me ka mahalo i ka hoʻohālike kuleana pili i ke koho 'ia.
///
/// E hoʻihoʻi i ka paio mua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Hoʻihoʻi i ka mea i hāʻawi i ka palena iki o ka waiwai mai ka hana i kuhikuhi ʻia.
///
/// E hoʻihoʻi i ka paio mua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Hoʻohālikelike a hoʻihoʻi i ka nui o nā waiwai ʻelua.
///
/// E hoʻihoʻi i ka paio lua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// I loko o hoʻohana he Alia i [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Huli i ka i kā mākou o nā loina a me ka mahalo i ka hoʻohālike kuleana pili i ke koho 'ia.
///
/// E hoʻihoʻi i ka paio lua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Hoʻihoʻi i ka mea e hāʻawi i ka waiwai nui mai ka hana i kuhikuhi ʻia.
///
/// E hoʻihoʻi i ka paio lua inā hoʻoholo ka hoʻohālikelike e like lākou.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Ka hoʻokō ʻana o PartialEq, Eq, PartialOrd a me Ord no nā ʻano primitive
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // He mea nui ke kauoha ma aneʻi e hoʻonui i ka hoʻākoakoa kūpono loa.
                    // E ʻike iā <https://github.com/rust-lang/rust/issues/63758> no ka ʻike hou aku.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Ke hoʻolei nei i ka i8 a hoʻololi i ka ʻokoʻa i kahi Kauoka e hoʻonui ana i kahi anaina maikaʻi loa.
            //
            // E nānā i <https://github.com/rust-lang/rust/issues/66780> no nāʻike'ē.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool e like me i8 hoʻihoʻi i 0 a i ʻole 1, no laila ʻaʻole hiki ke ʻokoʻa i kekahi mea ʻē aʻe
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &kuhikihi

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}