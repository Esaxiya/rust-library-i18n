//! Primitive traits a me ke ano no ko ka walaʻauʻana waiwai o ke ano.
//!
//! Hiki ke hoʻokaʻawale ʻia nā ʻano Rust i nā ʻano pono like ʻole e like me kā lākou mau intrinsic.
//! Hōʻike ʻia kēia mau papa inoa ma ke ʻano traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Ano i hiki ke hoololiia ma ka pae palena.
///
/// Keia trait ua akomi hoʻokō i ka wa a ka compiler hoʻoholo ia ka hana kūpono.
///
/// An kumu o ka non-`Send` 'ano o ka olua-helu laʻau kuhikuhi [`rc::Rc`][`Rc`].
/// Inā hoʻāʻo ʻelua mau wili e kāloli iā [Rc`] kuhi i ka helu like i helu ʻia, hiki iā lākou ke hoʻāʻo e hoʻohou i ka helu kuhikuhi i ka manawa like, ʻo ia ʻo [undefined behavior][ub] ma muli o ka hoʻohana ʻole o [`Rc`] i nā hana atomic.
///
/// Kona hoahānauʻo [`sync::Arc`][arc] i hoʻohana'ātoma hana (incurring kekahi lolo) a pela o `Send`.
///
/// E nānā i [the Nomicon](../../nomicon/send-and-sync.html) no ka oi lāliʻi.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Kind me ka ikaika nuiʻike i i hoʻouluulu manawa.
///
/// Allʻano kiko'î i ka implicit e paa ana o `Sized`.Hiki ke hoʻohana ʻia ka syntax kūikawā `?Sized` e wehe i kēia paʻa inā ʻaʻole kūpono.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//Kuʻia: pepa paia ua i hoʻokō no [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// O kekahi koe nae o ka implicit `Self` 'ano o ka trait.
/// ʻAʻohe o trait i implicit `Sized` i hoʻopaʻa ʻia no ka mea ʻaʻole kūpono kēia me [trait mea] kahi, ma ka wehewehe ʻana, pono e hana pū ka trait me nā mea hiki ke hoʻokō pono, a no laila hiki ke nui.
///
///
/// ʻOiai Rust e e oe nakinaki `Sized` i ka trait,ʻaʻoleʻoe e e hiki ke hana ia, e hana i ka trait mea hope:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // e y me: &dyn Bar= &Impl;//Kuʻia: ka trait `Bar` hiki ole ke hana i loko o kekahi mea
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // no Default, no ka laʻana, e koi ana e loiloi ʻia `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Nā ʻano i hiki ke lilo i "unsized" i kahi ʻano dynamically-size.
///
/// No ka laʻana, ka pepa paia kuʻano `[i8; 2]` e kakau mai `Unsize<[i8]>` a me `Unsize<dyn fmt::Debug>`.
///
/// All implementations o `Unsize` i hoʻolako 'akomi' ma ka compiler.
///
/// `Unsize` hoʻokō 'ia no:
///
/// - `[T; N]` ʻO `Unsize<[T]>`
/// - `T` ʻO `Unsize<dyn Trait>` ke `T: Trait`
/// - `Foo<..., T, ...>` o `Unsize<Foo<..., U, ...>>` inā:
///   - `T: Unsize<U>`
///   - ʻO Foo kahi mea kūkulu
///   - Wale nō ke kahua hope o `Foo` mai i keʻano o kekahi kanaka `T`
///   - `T` mea ole kekahi hapa o ke 'ano o kekahi'ē aʻe mahinaʻai
///   - `Bar<T>: Unsize<Bar<U>>`, ina ke kahua hope o `Foo` mai type `Bar<T>`
///
/// `Unsize` Ua hoʻohana 'ia a me [`ops::CoerceUnsized`] e ae "user-defined" ipu e like me [`Rc`] e pihaʻi me dynamically-pepa paia ano.
/// E nānā i ke [DST coercion RFC][RFC982] a me [the nomicon entry on coercion][nomicon-coerce] no hou lāliʻi.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Koi trait no ia a eia i hoʻohana 'ia i loko o kumu ihoiho.
///
/// ʻO kēlā me kēia ʻano i loaʻa iā `PartialEq` e hoʻokō pono i kēia trait,*me ka nānā ʻole* inā paha e hoʻokomo kāna ʻano-kikoʻī iā `Eq`.
///
/// Inā he `const` ikamu kekahi mau kekahi 'ano e, aole ia e hoʻokō i keia trait, laila, ua' ano kekahi (1.) 'aʻole i hoʻokō i `PartialEq` (a' o ia hoʻi ka ikaika,ʻaʻole e i ua hoʻohālike hana, a kuhi hanauna kuhi mea loaʻa), a me (2.) ka mea, e kakau mai *kona mau* mana o `PartialEq` (a mākou e manaʻo nei ʻaʻole i kūlike i ka hoʻohālikelike ʻano-kūlike).
///
///
/// Ma kekahi o na mau nā mea e hiki wale mai ma luna, ke pale ana i hoʻomähuahua 'o ia i ka ia a eia i loko o ke kumu ń.
///
/// E nānā i ke [structural match RFC][RFC1445], a me [issue 63438] i ohohia migrating mai kaila-ma muli manao i keia trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Koi trait no ia a eia i hoʻohana 'ia i loko o kumu ihoiho.
///
/// Kekahi 'ano i loaa `Eq` akomi e kakau mai keia trait,*nānā'* o paha kona 'ano mea kiko'î a hoʻokō i `Eq`.
///
/// He hack kēia e hana a puni kahi palena i kā mākou ʻōnaehana ʻano.
///
/// # Background
///
/// Mākou makemake e noi aku i ke ano o ka consts hoʻohana i kumu hoʻohālike ihoiho i ke kaila `#[derive(PartialEq, Eq)]`.
///
/// Ma ka hou maikaʻi honua, ua hiki kaha i koi ma ka pono o kéu hoʻomaopopo i ka haawiia maiʻano lako nā ka `StructuralPartialEq` trait *a me* ka `Eq` trait.
/// Eia naʻe, e hiki i ADTs i *hana*`derive(PartialEq, Eq)`, a e he hihia ia mākou makemake i ka compiler eʻae, a aole nae me ka ikaika o ka 'ano' aʻole e hoʻokō `Eq`.
///
/// Oia, he hihia e like keia:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ka pilikia i loko o ka luna kivila mea i `Wrap<fn(&())>` 'aʻole i hoʻokō i `PartialEq`, aole hoi `Eq`, no ka mea,' no ka < 'i> fn(&'a _)` does not implement those traits.)
///
/// Nolaila, ua hiki ole hilinai aku maluna o naʻaupō ponopono no `StructuralPartialEq` a me maula `Eq`.
///
/// E like me ka hack, e hana a puni i kēia, ua hoʻohana mau hookaawale traits injected ma kela a me keia o na mau loaa (`#[derive(PartialEq)]` a me `#[derive(Eq)]`) a me ponopono i ua makana me hapa o mall-ń makau 'ia Kaha nā o ia.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Ano o kona mau loina hiki keʻia i kekahi wale ma ka hoʻopiliʻana i nā kānaka.
///
/// Ma ka paʻamau, 'hoʻololi semantics.'Ma nā hua'ōlelo:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` Ua hoʻoneʻe i `y`, a no laila, hiki ole ke hoʻohana
///
/// // println! ("{: ?}", x);//hewa: ano o ka neʻe ikaikaʻana waiwai
/// ```
///
/// Eia nō naʻe, inā pili kahi ʻano i `Copy`, loaʻa iā ia kahi 'copy semantics':
///
/// ```
/// // Mākou ke loaa i ka `Copy` manaʻo.
/// // `Clone` mea i koi 'ia, e like me ka mea ke he supertrait o `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` mea he kope o `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// He mea nui e hoʻomaopopo i loko o kēia mau laʻana ʻelua, ʻo ka ʻokoʻa wale nō inā ʻae ʻia ʻoe e komo i `x` ma hope o ka hana.
/// Ma lalo o ka pāpale, hiki i kahi kope a me ka neʻe ke hopena i nā kope e kope ʻia i ka hoʻomanaʻo, ʻoiai e hoʻonui ʻia kēia i kekahi manawa.
///
/// ## Pehea hiki au hoʻokō `Copy`?
///
/// Aia nāʻaoʻaoʻelua ia? `Copy` ma kou type.ʻO ka mea maʻalahi ka hoʻohana ʻana iā `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Hiki iā ʻoe ke hoʻokomo iā `Copy` a me `Clone` i ka lima.
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Aia He He liʻiliʻiʻana ma waena o nā elua: o ka `derive` kou akamai, e kekahi i kekahi `Copy` e paa ana ma ka 'ano mea kiko'î, i ua ole mau makemake.
///
/// ## He aha ka mea likeʻole ma waena o `Copy` a me `Clone`?
///
/// Kope hiki implicitly, no ka laʻana i hapa o ka paha `y = x`.Ka hana o `Copy` mea ole overloadable;ia mea mau he mea iki-naauao kope.
///
/// Cloning mea he pelapela hana, `x.clone()`.Ka manaʻo o [`Clone`] hiki i kekahi 'ano-i ho'ākāka' hana pono, e nānā me nā loina maluhia.
/// No ka laʻana, i ka manaʻo o [`Clone`] no [`String`] pono e kope i ke kuhikuhi mai la lakou-i kaula aooa? I loko o ka puu.
/// ʻO kahi kope bitwise maʻalahi o nā waiwai [`String`] e kope wale i ka kuhikuhi, e alakaʻi ana i kahi manuahi manuahi i lalo o ka laina.
/// No keia kumu, [`String`] mea [`Clone`] akā,ʻaʻole `Copy`.
///
/// [`Clone`] He supertrait o `Copy`, no laila ʻo nā mea āpau a `Copy` pono nō e hoʻokō iā [`Clone`].
/// Inā heʻano o `Copy` laila kona [`Clone`] manaʻo wale pono e hoʻi `*self` (e nānā i ke kumu ma luna).
///
/// ## I ka hiki koʻu 'ano e `Copy`?
///
/// Aʻano ke hoʻokō i `Copy` ina a pau o kona eiiiiiaiou hoʻokō `Copy`.No ka laʻana, ua struct hiki ia `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct hiki ia `Copy`, a me [`i32`] o `Copy`, nolaila mea kūpono ia e `Copy` `Point`.
/// Ma ka hoʻohālikelike, e noʻonoʻo
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// ʻAʻole hiki i ka struct `PointList` ke hoʻokō iā `Copy`, no ka mea ʻaʻole [`Vec<T>`] ka `Copy`.Inā mākou e hoʻāʻo e loaʻa i kahi hoʻokō `Copy`, e loaʻa iā mākou kahi hewa:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Kaʻana kūmole (`&T`) i kekahi `Copy`, no laila, he 'ano hiki ia `Copy`, i ka wā e paʻa i kaʻana like i maopopo nä haumäna o ke ano `T` i mea *ole*`Copy`.
/// E hoomanao i ka mea kēia struct, a hiki hoʻokō `Copy`, no ka mea, ka mea paʻa wale nō i *i kaʻana like i maopopo kahi* i kā mākou 'ole-`Copy`' ano `PointList` mai luna:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## I ka *hiki ole* koʻu 'ano e `Copy`?
///
/// ʻAʻole hiki ke kope palekana ʻia kekahi ʻano.No ka laʻana, ka hoʻopiliʻana `&mut T` e ho okumu i ka aliased mutable i maopopo nä haumäna.
/// Ka hoʻopiliʻana [`String`] e nānā me ke kuleana no ka mālama 'ana i ka [' String`] 'ke aooa, e alakai ana i ka papalua noa.
///
/// Generalizing ka hope hihia, i kekahiʻano hoʻokō [`Drop`] hiki ole e `Copy`, no ka mea, he hana mālama 'ana i kekahi o nā kumu waiwai heʻokoʻa kona mau [`size_of::<T>`] nāʻai.
///
/// Inā 'oe e ho'āʻo i ka hoʻokō `Copy` ma ka struct a enum i loaʻa' ole-`Copy` aeaiiua, oe, e kiʻi i ka hewa [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## I ka *e* koʻu 'ano e `Copy`?
///
/// Ano laulā, e olelo ana, ina kou 'ano _can_ hoʻokō `Copy`, ia pono.
/// E noʻonoʻo naʻe, ʻo ka hoʻokomo ʻana i `Copy` kahi ʻāpana o ka API lehulehu o kāu ʻano.
/// Inā keʻano he mea lawehala 'ole-`Copy` i loko o ka future, ka mea hiki e ke akamai e omit i ka `Copy` manaʻo manawa, e pale aku i ka wawahi API loli.
///
/// ## Nā mea hoʻokō hou aʻe
///
/// Ma waho aʻeo ia ka [implementors listed below][impls], i kēia 'ano i hoʻokō i `Copy`:
///
/// * Launch'ikamuʻAno ('o ia hoʻi, ka mea okoa ke ano i ho'ākāka' ana no kēlā me kēia kuleana pili i)
/// * Launch laʻau kuhikuhiʻAno (e like, `fn() -> i32`)
/// * Nā ʻano huapalapala, no nā nui āpau, inā pili ka ʻano o ka huahana iā `Copy` (eg, `[i32; 123456]`)
/// * Tuple ano, ina kēlā me kēia ke keʻena i mea lapaʻau `Copy` (e like, `()`, `(i32, bool)`)
/// * PaninaʻAno, ina e hoʻopio i waiwai, mai ka i hoʻolilo 'ia ai ina mea a pau e like me pio nā loina hoʻokō `Copy` lakou iho.
///   E hoʻomaopopo i nā loli i hopu ʻia e ka hōʻike kūkaʻi e hoʻokō mau i ka `Copy` (ʻoiai inā ʻaʻole ka referent), ʻo nā loli i hopu ʻia e ka referable mutable ʻaʻole e hoʻokō iā `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ua apono ka hoʻopiliʻana i keʻano e hua ole hoʻokō `Copy` no ka unsatisfied wa e ola pale, (ka hoʻopiliʻana `A<'_>` ka wā `A<'static>: Copy` wale a me `A<'_>: Clone`).
// Mākou i kēia kaila 'aneʻi no ka manawa wale nō, no ka mea, ua loa he mau na specializations ma `Copy` e ola ia i loko o ka hale waihona puke maʻamau, a malaila keʻaʻohe ala i ka maluhia i keia hana pono manawa.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Loaa nunui hoʻomakaʻia ka impl o ka trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ʻO nā ʻano palekana e kaʻana like i nā pae ma waena o nā pae.
///
/// Keia trait ua akomi hoʻokō i ka wa a ka compiler hoʻoholo ia ka hana kūpono.
///
/// Ke kūlike loa ka wehewehena mea: heʻano `T` o [`Sync`] ina a wale ina `&T` o [`Send`].
/// I nā huaʻōlelo ʻē aʻe, inā ʻaʻohe hiki o [undefined behavior][ub] (me nā lāhui ʻikepili) ke hala i nā kuhikuhi `&T` ma waena o nā pae.
///
/// E like me ka mea e manaʻo ʻia ai, ʻo nā ʻano primitive e like me [`u8`] a me [`f64`] nā [`Sync`] āpau, a pēlā nō hoʻi nā ʻano hōʻuluʻulu maʻalahi i loaʻa iā lākou, e like me nā tuples, nā kaula a me nā enum.
/// More examples o ka walaʻauʻana [`Sync`] ano loaʻa "immutable" ke ano e like `&T`, a me ka poe me na mea ili mutability, e like me [`Box<T>`][box], [`Vec<T>`][vec] a me ka hapanui o nā ohiʻAno.
///
/// (Pono nā ʻōpana generic i [`Sync`] no kā lākou ipu e [Sync`].)
///
/// ʻO kahi hopena kupaianaha o ka wehewehe ʻo `&mut T` ʻo `Sync` (inā `T` ʻo `Sync`) ʻoiai e like paha me ka hāʻawi ʻana o ka hoʻololi i hoʻohui ʻole ʻia.
/// Ka liana a mea i ka mutable pili ma hope o ke kaʻana like i maopopo kahi (ia mea, `& &mut T`) i heluhelu-wale, me he mea la he `& &T`.
/// Laila,ʻaʻole nō he pilikia o kaʻikepili heihei.
///
/// Ano i mea ole `Sync` lākou nei ka poʻe i loaʻa "interior mutability" i loko o ka pili-pae-palekana palapala, e like me [`Cell`][cell] a me [`RefCell`][refcell].
/// Mau ano ae no mutation o ko lākou mau Contents, a hiki ma ka luli ole, i kaʻana like i maopopo nä haumäna.
/// Eia kekahi laʻana ʻo ka hana `set` ma [`Cell<T>`][cell] e lawe iā `&self`, no laila e koi wale ana i kahi kūmole [`&Cell<T>`][cell].
/// Ka papa hana hanaʻia i hoʻononiakahi, pela [`Cell`][cell] hiki ole ia `Sync`.
///
/// Kekahi laʻana o ka non-`Sync` 'ano o ka olua-helu laʻau kuhikuhi [`Rc`][rc].
/// Ua haawiia i kekahi olua [`&Rc<T>`][rc], e hiki clone i ka hou [`Rc<T>`][rc], modifying ka olua helu i loko o ka pili-'ātoma ala.
///
/// No ka hihia o kekahi hana e pono ka pae-palekana Kalaiaina mutability, Rust hoakaka [atomic data types], e like me pelapela laka Via [`sync::Mutex`][mutex] a me [`sync::RwLock`][rwlock].
/// Mau ano hōʻoia 'ia ai kekahi mutation hiki ole ponoʻikepili o kēia lāhui kanaka, ma keia hope aku i nāʻano mea `Sync`.
/// Pēlā nō, hāʻawi ʻo [`sync::Arc`][arc] i kahi analogue palekana o [`Rc`][rc].
///
/// Kekahi 'ano me ka Kalaiaina mutability pono no hoi ke hoʻohana' ia i ka [`cell::UnsafeCell`][unsafecell] wrapper puni ka value(s) i hiki ke mutated ma ka kaʻana i maopopo nä haumäna.
/// Nele i ka hana i kēia mea [undefined behavior][ub].
/// No ka laʻana, ['transmute`][transmute]-ing mai `&T` a hiki i `&mut T` mea kūponoʻole.
///
/// E nānā i [the Nomicon][nomicon-send-and-sync] no ka oi lāliʻi e pili ana `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): koke kākoʻo, e hoʻouka hou aku au memo ma `rustc_on_unimplemented` na aina ma ka Hoʻokolohua, a me ka mea, ua haawiia mai e nānā ina paha i ka panina o anywhere i loko o ke koi kaula, hohola aku ia e like me ia (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Hoʻohana ʻia nā ʻano Zero e kaha i nā mea a "act like" iā lākou kahi `T`.
///
/// Ohui i ka `PhantomData<T>` kahua i kou 'ano i kāna ka compiler i kouʻano hana me he mea la ka mea hale kūʻai i ka waiwai o ke' ano `T`, e like nae ka mea hana ole maoli.
/// Ua ike ua hoʻohana 'ia ka wā Me kekahi maluhia waiwai.
///
/// No ka nui ma-hohonu wehewehe ana pehea e hoʻohana `PhantomData<T>`, e ike [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Kaha
///
/// Inā paha ka mea, o ka poe i scary inoa, `PhantomData` a 'phantomʻAno' e pili pū ana, akā,ʻaʻole'ālike.A phantomʻano aiao mea wale keʻano aiao i ua ole i hoʻohana.
/// Ma Rust, keia pinepine ke kumu i ka compiler e hoohewa aku, a me ke kākoʻo pāʻoihana mea, e hui aku i ka "dummy" hoʻohana ma ka aoao o `PhantomData`.
///
/// # Examples
///
/// ## Ua hanaʻole ola kiko'î
///
/// Maliʻa paha ʻo ka hihia hoʻohana maʻamau no `PhantomData` kahi mea i loaʻa kahi pāʻina ola i hoʻohana ʻole ʻia, ma ke ʻano he ʻāpana o kekahi pāʻālua palekana.
/// No ka laʻana, eia ka he struct `Slice` mea i mau mea kuhikuhi o ke 'ano `*const T`, presumably kuhikuhi i loko o ka hoʻouka aloha:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// I ka manao o ia ka nń kuʻikepili mea i pololei ia wale no ka wa e ola ana `'a`, no laila, `Slice` e i ola ma hope iho `'a`.
/// Naʻe, ua ole i olelo ia i kēia mea i loko o ke Kanawai, no ka loaʻa nō i hana i ka wa e ola ana `'a`, a ma keia hope aku ka mea, ua ole loa ka ikepili ka mea pili i ka.
/// Mākou ke hooponopono i kēia ma ka hai ana i ka compiler e hana *i ina* ka `Slice` struct he i maopopo kahi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// He no hoi ma ka huli pono ke annotation `T: 'a`, e hoike ana i kekahi i maopopo nä haumäna ma `T` mea i pololei ia ma ka wā e ola `'a`.
///
/// Ke hoʻomaka nei i kahi `Slice` hāʻawi wale ʻoe i ka waiwai `PhantomData` no ke kahua `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ua hanaʻoleʻano kiko'î
///
/// Ua kekahi manawa ka hana ia oe i ua hanaʻole type kiko'î i hoike mea 'ano o nāʻikepili kekahi struct o "tied" ia, a hiki nae iʻikepili ua ole maoli i loaʻa i loko o ka struct wale.
/// Eia kahi laʻana kahi e ala ai kēia me [FFI].
/// Ka haole, mau 'E hoʻokomo i mea e paʻa ai o ke' ano `*mut ()`, e hoʻohuli i ke Rust aiee o nāʻano.
/// Mākou Track ka Rust 'ano hoʻohana i ka phantomʻano aiao ma ka struct `ExternalResource` i wahī mai i ke kumu.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ona a me ke kulu ponopono
///
/// Ohui i ka mahinaʻai o ke 'ano `PhantomData<T>` Hōʻike i kouʻano nonaʻikepili o ka type `T`.Hōʻike kēia i ka manawa i hāʻule ai kāu ʻano, hāʻule paha ia i hoʻokahi a ʻoi o nā hanana o ka ʻano `T`.
/// Ke kau nei kēia ma ka Rust compiler's [drop check] analysis.
///
/// Ināʻaʻole i kou struct i ka mea *iho* kaʻikepili o ka 'ano `T`, ia mea maikaʻi, e hoʻohana i ka oluaʻano, e like `PhantomData<&'a T>` (ideally) ole `PhantomData<*const T>` (ina i wa e ola ana pili), no laila, i ole e ka hōʻike ona.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-na trait hoʻohana i ka hōʻike i ke 'ano o ka enum discriminants.
///
/// Keia trait ua akomi hoʻokō i nāʻano a 'aʻole i hoʻokomo i kekahi hoʻohiki i [`mem::Discriminant`].
/// ʻO **ka lawai ʻole i hoʻoholo ʻole** e hoʻoili ma waena o `DiscriminantKind::Discriminant` a me `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ke ʻano o ka hoʻokae, pono e māʻona i ka trait bounds e koi ʻia e `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-na trait hoʻohana i ike ai i ko ke 'ano he mea `UnsafeCell` i loko o, akā,ʻaʻole ma ka indirection.
///
/// Kēia e loli ai, no ka laʻana, ina paha he `static` o iaʻano ua waihoia ma ka heluhelu-wale kūpaʻa iaiyoe a writable kūpaʻa iaiyoe.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Ano i hiki e maluhia neʻe ma hope o ka pinned.
///
/// ʻAʻohe manaʻo o Rust i nā ʻano neʻe ʻole, a manaʻo i nā neʻe (e laʻa, ma o ka hāʻawi ʻana a i ʻole [`mem::replace`]) e palekana mau ai.
///
/// Ka [`Pin`][Pin] ʻano ua hoʻohana 'ia kahi e pale aku Pńk'pika ma keʻano nenoaiu.Mea kuhikuhi `P<T>` wahīʻia i loko o ka [`Pin<P<T>>`][Pin] wrapper,ʻaʻole e neʻe hiki mai o.
/// E nānā i ke [`pin` module] nā moʻolelo no ka 'ike hou aku i pinning.
///
/// Ke hāpai nei i ka `Unpin` trait no `T` hāpai i nā kapu o ka pinning ʻana i ke ʻano, a laila ʻae i ka neʻe ʻana i `T` mai [`Pin<P<T>>`][Pin] me nā hana e like me [`mem::replace`].
///
///
/// `Unpin` mea ole no ia mau hopena i nā mea a pau no ka ole-pinnedʻikepili.
/// Ma kekahi, [`mem::replace`] paha höʻike `!Unpin` ʻikepili (ka mea, hana no kekahi `&mut T`,ʻaʻole pono ia `T: Unpin`).
/// Eia naʻe, e hiki ole hoʻohana [`mem::replace`] maʻikepili wahīʻia i loko o ka [`Pin<P<T>>`][Pin], no ka hiki ole e loaa i ka `&mut T` e pono ai no ka mea, a *ua* ka mea i hana i keia kahua hana.
///
/// No laila, ʻo kēia, no ka laʻana, hiki ke hana wale ʻia i nā ʻano e hoʻokomo nei iā `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // He Pono i ka mutable maopopo kahi e kahea `mem::replace`.
/// // Mākou ke loaa ia o ka olua e (implicitly) kahea `Pin::deref_mut`, akā, i ka mea hiki wale no ka `String` mea lapaʻau `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Keia trait ua akomi hoʻokō no ka aneane nāʻano.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// A peni mäkaʻano a 'aʻole i hoʻokō i `Unpin`.
///
/// Inā heʻano he he `PhantomPinned`,ʻaʻole ia e hoʻokō i `Unpin` ma ka paʻamau.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations o `Copy` no primitive ano.
///
/// Implementations i ole e ho'ākāka 'ia i loko o Rust hiki i hoʻokō ma `traits::SelectionContext::copy_clone_conditions()` ma `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Kaʻana kūmole hiki ke mānewanewa, akā, mutable kūmole *hiki ole*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}