//! Traits no ka hoʻololi ʻana ma waena o nā ʻano.
//!
//! Ke traits i loko o kēia māhele Module i ke ala e 'ana mai' ano kekahi i kekahiʻano.
//! Kēlā me kēia trait lawelawe 'ana i kaʻokoʻa manao:
//!
//! - Hoʻokō i ka [`AsRef`] trait no nike olua-i-maopopo kahi conversions
//! - E hoʻokō i ka [`AsMut`] trait no nā loli liʻiliʻi i hiki ke hoʻololi ʻia
//! - Hoʻokō i ka [`From`] trait no ka hoopau ana pono-i-waiwai conversions
//! - Hoʻokō i ka [`Into`] trait no ka hoopau ana pono-i-waiwai conversions iʻano ma waho o kaʻikena crate
//! - Ke [`TryFrom`] a [`TryInto`] traits hoi e like [`From`] a me [`Into`], akā, e hoʻokō ka wā o ka huli ana ke pau.
//!
//! Ke traits i loko o kēia māhele Module e pinepine hoʻohana like trait bounds no nōhie oihana e like ia i ka manaʻo hoʻopiʻi kū'ē ana i mau ano i kākoʻo.E nānā i ka moʻolelo o kēlā me kēia trait no examples.
//!
//! E like me ka hale waihona puke mea kākau, 'oe E mau ka makemake o ka hoʻokō' [`From<T>`][`From`] a [`TryFrom<T>`][`TryFrom`] aole i ka [`Into<U>`][`Into`] a [`TryInto<U>`][`TryInto`], me [`From`] a me [`TryFrom`] i nui kohoʻia, a kaumaha aku i like paha [`Into`] a [`TryInto`] implementations no ka noa, i ke aloha a hiki i kekahi papa manaʻo i loko o ka hale waihona puke maʻamau.
//! I ka ka mākaʻana i kekahi mana mamua i Rust 1.41, ka mea i e pono e hoʻokō [`Into`] a [`TryInto`] pololei ka wā hoʻololi 'ana i ke' ano mawaho o kaʻikena crate.
//!
//! # nōhie Implementations
//!
//! - [`AsRef`] a me [`AsMut`] ola auto-dereference ina ka pahaleʻano mea he olua
//! - [`From`] <U>'no T`hoʻohuʻu [` Into`]`</u><T><U>no U`</u>
//! - [`TryFrom`]`<U>no ka mea ʻo T` e ʻāpono nei ['HoaʻimoMa`]`</u><T><U>no U`</u>
//! - [`From`] a [`Into`] reflexive, ʻo ia hoʻi hiki i nā ʻano āpau ke `into` iā lākou iho a me `from` iā lākou iho
//!
//! E nānā i kēlā me kēia trait no oAaEeIeIAaIAeO examples.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Ka hana ʻike.
///
/// ʻElua mea nui e hoʻomaopopo e pili ana i kēia hana:
///
/// - ʻAʻole like ia me ka panina e like me `|x| x`, ʻoiai hiki i ka panina ke koi iā `x` i kahi ʻano ʻokoʻa.
///
/// - Ua kolo ana i ka hoʻokomo o `x` i hooholoia i ka kuleana pili i.
///
/// Oiai ka mea, i mea kupanaha e i kekahi kuleana pili i ua pono hoike hope o ka hoʻokomo o, loaʻa nō kekahi mau hana hoihoi hoʻohana.
///
///
/// # Examples
///
/// E ho ohana i `identity` e hana i kekahi mea i loko o ke kaʻina o nā, hoihoi ', hana:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // E hoʻohālike i ka hoʻohui ʻana i kahi hana hoihoi.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// E ho ohana i `identity` like me ka "do nothing" kumu hihia i loko o ka conditional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Hana hou hana hoihoi mea ...
///
/// let _results = do_stuff(42);
/// ```
///
/// E ho ohana i `identity` e malama i ka `Some` Lolina o ka iterator o `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Hoʻohana ʻia e hana i kahi hoʻohuli kūmole kūmole.
///
/// Ua like kēia trait me [`AsMut`] i hoʻohana ʻia no ka hoʻololi ʻana ma waena o nā kūmole hiki ke hoʻololi.
/// Inā 'oe Pono e hana i kekahi kumu huli ana ia mea maikaʻi, e hoʻokō [`From`] me ka' ano `&T` a kākau i kekahi kuleana pili i oihana.
///
/// `AsRef` i ka ia inoa me [`Borrow`], akā, [`Borrow`] mea okoa me ka mau, ao ke ano:
///
/// - ʻAʻole like me `AsRef`, [`Borrow`] i kahi blanket impl no kekahi `T`, a hiki ke hoʻohana ʻia e ʻae i kekahi kūmole a i ʻole kahi waiwai.
/// - [`Borrow`] Koi pū ʻia ʻo [`Hash`], [`Eq`] a me [`Ord`] no ka waiwai ʻaiʻē i like me ka waiwai i loaʻa.
/// No keia kumu, ina e makemake e noi wale he hookahi kahua o ka struct oe hiki ke hoʻokō i `AsRef`, akā,ʻaʻole [`Borrow`].
///
/// **Note: ʻAʻole pono e holo hewa kēia trait **.Inā ka huli ana ke nele, hana i ka mea laʻa iaoia a hoi mai ka [`Option<T>`] paha he [`Result<T, E>`].
///
/// # nōhie Implementations
///
/// - `AsRef` auto-dere rujukan inā he kūmole ke ʻano o loko a i ʻole he kuhikuhi hiki ke hoʻololi ʻia (e laʻa: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ma ka hoʻohana 'ana trait bounds mākou eʻae manaʻo hoʻopiʻi kū'ē o nāʻano like loa me ka mea hiki e huli ai i ka mea i hoakaka ia type `T`.
///
/// No kekahi laʻana: By ka nōhie papa e lawe i ka `AsRef<str>` e pili ana mākou i ka hoike ana mākou makemake i kaʻae a pau i maopopo nä haumäna e hiki ke huli i [`&str`] me ka loulou.
/// No nā [`String`] a me [`&str`] hoʻokō `AsRef<str>` mākou keʻae nā like hoʻokomo o loulou.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Hana i ka hoʻohuli.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Hoʻohana ʻia e hana i kahi hoʻololi kūmole i hiki ke hoʻololi ʻia.
///
/// Keia trait Ua like ia [`AsRef`] akā, hoʻohana 'ia no ka hoʻololi' ana i waena o mutable kūmole.
/// Inā 'oe Pono e hana i kekahi kumu huli ana ia mea maikaʻi, e hoʻokō [`From`] me ka' ano `&mut T` a kākau i kekahi kuleana pili i oihana.
///
/// **Note: ʻAʻole pono e holo hewa kēia trait **.Inā ka huli ana ke nele, hana i ka mea laʻa iaoia a hoi mai ka [`Option<T>`] paha he [`Result<T, E>`].
///
/// # nōhie Implementations
///
/// - `AsMut` ola auto-dereferences ina ka pahaleʻano mea he mutable maopopo kahi (e like: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ke hoʻohana nei iā `AsMut` ma ke ʻano trait bound no kahi hana generic hiki iā mākou ke ʻae i nā kūmole hiki ke hoʻololi a hiki ke hoʻohuli ʻia e kikokiko `&mut T`.
/// No ka mea, [`Box<T>`] mea lapaʻau `AsMut<T>` mākou hiki i kekahi kuleana pili i `add_one` i lawe i nā manaʻo hoʻopiʻi kū'ē i hiki ke huli i `&mut u64` kākauʻana.
/// No ka mea, [`Box<T>`] mea lapaʻau `AsMut<T>`, `add_one` Eʻoluʻoluʻoe i manaʻo hoʻopiʻi kū'ē o ke 'ano `&mut Box<u64>` like hoʻi:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Hana i ka hoʻohuli.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// A pono-i-waiwai huli ana e hoʻopau nō ia i ka hoʻokomo o cia.ʻO ka ʻaoʻao ʻē aʻe o [`From`].
///
/// Kekahi e pakele ka hoʻokō [`Into`], a hoʻokō [`From`] ma.
/// Hāʻawi ka hoʻokō ʻana iā [`From`] i hoʻokahi me ka hoʻokō ʻana o [`Into`] mahalo i ka hoʻokomo kapa ma ka waihona waihona maʻamau.
///
/// Makemake 'ia i ka hoʻohana' ana [`Into`] ma [`From`] ka wā hoakaka ana trait bounds ma ka nōhie papa e hōʻoia 'ia ano e wale hoʻokō [`Into`] hiki ke hoʻohana like maikai.
///
/// **Note: Kēia trait pono e pau **.Inā hiki ʻole ke hoʻololi, e hoʻohana iā [`TryInto`].
///
/// # nōhie Implementations
///
/// - [`Mai`]<T>no ka U` hoʻohuʻu `Into<U> for T`
/// - [`Into`] reflexive ia, ʻo ia hoʻi ka hoʻokō ʻia o `Into<T> for T`
///
/// # Hoʻokō [`Into`] no conversions i mawahoʻano ma kahiko wale nō o Rust
///
/// Prior i Rust 1.41, ina ua ka mākaʻikaʻiʻano i kekahi hapa o ka he crate lailaʻoe hiki ole hoʻokō [`From`] pololei.
/// ʻO kahi laʻana, lawe i kēia code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ʻAʻole e hōʻuluʻulu kēia i nā mana kahiko o ka ʻōlelo no ka mea ʻoi aku ka ʻoi loa o nā rula o nā keiki makua ʻole a Rust.
/// E kāpae i kēia, hiki iā ʻoe ke hoʻokomo pololei iā [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// He nui no ka maopopo i [`Into`] aʻole ole i kekahi [`From`] manaʻo (me [`From`] i me [`Into`]).
/// No laila, e hoʻāʻo mau ʻoe e hoʻokō i [`From`] a laila hoʻi i hope i [`Into`] inā ʻaʻole hiki ke hoʻokō ʻia ʻo [`From`].
///
/// # Examples
///
/// [`String`] mea hana [`i loko`]`<`[Vec`]` <`[` u8`]`>>`:
///
/// I mea e hōʻike ai makemake mākou i kahi hana generic e lawe i nā hoʻopaʻapaʻa āpau i hiki ke hoʻololi ʻia i kahi ʻano `T` i hōʻike ʻia, hiki iā mākou ke hoʻohana i kahi trait bound o [`ʻIno`] '<T>...
///
/// No kekahi laʻana: ke kuleana pili i `is_hello` lawe i nā manaʻo hoʻopiʻi kū'ē i hiki ke hoohuliia mai i loko o ka ['Vec`]' <'[' u8`] '>'.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Hana i ka hoʻohuli.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Hoʻohana ʻia e hana i nā hoʻololi hoʻololi waiwai i ka wā e hoʻohana ana i ka waiwai hoʻokomo.ʻO ia ka pānaʻi like o [`Into`].
///
/// Kekahi e mau ka makemake o ka hoʻokō `From` ma [`Into`] no ka mea, i hoʻokō i `From` akomi hoakaka kekahi me ka manaʻo o [`Into`] ke aloha a hiki i ka blanket manaʻo i loko o ka hale waihona puke maʻamau.
///
///
/// E hoʻokomo wale iā [`Into`] ke kuhi nei i kahi mana ma mua o Rust 1.41 a hoʻololi i kahi ʻano ma waho o ka crate o kēia manawa.
/// `From` ʻaʻole i hiki ke hana i kēia mau ʻano hoʻololi i nā mana mua ma muli o nā rula o nā keiki makua ʻole a Rust.
/// E ʻike iā [`Into`] no nā kikoʻī hou aʻe.
///
/// Makemake 'ia i ka hoʻohana' ana [`Into`] ma ka hoʻohana 'ana `From` ka wā hoakaka ana trait bounds ma ka nōhie kuleana pili i.
/// ʻO kēia ala, hiki ke hoʻohana ʻia i nā ʻano i hoʻokomo pono i ka [`Into`] ma ke ʻano he hoʻopaʻapaʻa pū kekahi.
///
/// Ke `From` Ua hoi loa maikaʻi kēia wā hana hewa pēpēʻana.i kekahi kuleana pili i ia mea hiki ke nele ka wā kūkulu, i ka hoʻi 'ano e nui ia o ka palapala `Result<T, E>`.
/// Hoʻomaopopo ka `From` trait i ka lawelawe hewa ʻana ma ka ʻae ʻana i kahi hana e hoʻihoʻi i kahi ʻano hewa i hoʻopili ʻia i nā ʻano hewa he nui.E ʻike i ka ʻāpana "Examples" a me [the book][book] no nā kikoʻī hou aʻe.
///
/// **Note: ʻAʻole pono e holo hewa kēia trait **.Inā hiki ʻole ke hoʻololi, e hoʻohana iā [`TryFrom`].
///
/// # nōhie Implementations
///
/// - `From<T> for U` hoʻohuʻu [`Into`] <U>'no T`</u>
/// - `From` reflexive ia, ʻo ia hoʻi ka hoʻokō ʻia o `From<T> for T`
///
/// # Examples
///
/// [`String`] hoʻokomo iā `From<&str>`:
///
/// An pelapela huli ana mai ka `&str` a hiki i ke kaula ua hana like penei:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ʻOiai ke hana hewa ʻana e hoʻohana pono ia i ka `From` no kāu ʻano hewa ponoʻī.
/// Ma ka hoʻololi 'ana i nń ku hewaʻAno i kā mākou mau hana mau hewa type e encapsulates ka nń ku hewaʻano, ua hiki hoʻi i ka hookahi hewa' ano me losing 'ikepili ma ka nń ku kumu.
/// Hoʻololi ka mea hoʻohana '?' i ke ʻano hewa i lalo i kā mākou ʻano hemahema maʻamau ma ke kāhea ʻana iā `Into<CliError>::into` i hāʻawi ʻia i ka wā e hoʻokō ana iā `From`.
/// Hoʻopili ka mea hoʻopili i ka hoʻokō o `Into` e hoʻohana ai.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Hana i ka hoʻohuli.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// An ho'āʻo huli ana e hoʻopau nō ia i `self`, a hiki ole paha i e pipiʻi.
///
/// Library kākau e IeAUPIIe, IAa IO ole 'ana hoʻokō i keia trait, akā, e ka makemake o ka hoʻokō' ia o ka [`TryFrom`] trait, a kaumaha nui kohoʻia, a hoʻolako i like paha `TryInto` manaʻo no ka noa, i ke aloha a hiki i kekahi papa manaʻo i loko o ka hale waihona puke maʻamau.
/// No ka 'ike hou ma luna o kēia,ʻike i ka palapala kuhikuhi no [`Into`].
///
/// # Ke hoʻokō nei iā `TryInto`
///
/// Loaʻa kēia i nā kapu like a me nā manaʻo e like me ka hoʻokō ʻana iā [`Into`], e ʻike ma laila no nā kikoʻī.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Ua hoʻi ka ʻano i ka hanana o ka hewa hoʻohuli.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Hana i ka hoʻohuli.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple a me ka maluhia type conversions i i nele i loko o ka lāʻau ala ma lalo o kekahi mau ka noho ana.ʻO ia ka pānaʻi like o [`TryInto`].
///
/// He mea maikaʻi kēia ke hana nei ʻoe i kahi ʻano hoʻololi e kūleʻa iki akā pono paha i kahi lawelawe kūikawā.
/// No ka laʻana, ka mea,ʻaʻohe ala, e hoohuli i ka [`i64`] i loko o ka [`i32`] ka hoʻohana 'ana i ka [`From`] trait, no ka mea, he [`i64`] e komo i ka waiwai i [`i32`] hiki ole ho i ia, a no laila, i ka huli ana e liloʻikepili.
///
/// E mālama ʻia paha kēia ma ke ʻoki ʻana i ka [`i64`] i kahi [`i32`] (hāʻawi maoli i ka [i64`] waiwai modulo [`i32::MAX`]) a i ʻole ka hoʻihoʻi ʻana iā [`i32::MAX`], a i ʻole kekahi ʻano hana ʻē aʻe.
/// Kuhi ʻia ka [`From`] trait no ka hoʻohuli piha ʻana, no laila e hoʻomaopopo ka `TryFrom` trait i ka mea papahana i ka wā e hiki ai i kahi ʻano hoʻohuli ke hele a maikaʻi a hāʻawi iā lākou e hoʻoholo pehea e mālama ai.
///
/// # nōhie Implementations
///
/// - `TryFrom<T> for U` hoʻohuʻu [`TryInto`] <U>'no T`</u>
/// - [`try_from`] mea reflexive, a 'o ia hoʻi i ka hoʻokō a `TryFrom<T> for T` hiki ole pau-ka pili `Error` ano no kahea `T::try_from()` ma luna o ka waiwai o keʻano `T` o [`Infallible`].
/// I ka wā o ka [`!`] 'ano ua stabilized [`Infallible`] a me [`!`] e e like paha.
///
/// `TryFrom<T>` hiki ke hoʻokō ʻia penei:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// E like me ia i ho'ākāka ', [`i32`] mea lapaʻau `TryFrom <' ['i64`]'> ':
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Hāʻule mālie i `big_number`, koi i ka ʻimi ʻana a me ka lawelawe ʻana i ka truncation ma hope o ka ʻoiaʻiʻo.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Hoʻi ka hewa, no ka `big_number` mea, ua nui no ka pono i loko o ka `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Hoʻi iā `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Ua hoʻi ka ʻano i ka hanana o ka hewa hoʻohuli.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Hana i ka hoʻohuli.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// nōhie IMPLS
////////////////////////////////////////////////////////////////////////////////

// E like me ka hāpai ʻana i&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Like e hoʻokiʻekiʻe aʻe ma luna o &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): e puku i ka mea ma luna o impls no&/&mut me ke kēia oi mau hoʻokahi:
// // E like me ka hāpai ʻana iā Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Nui> AsRef <U>no D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Hāpai ʻo AsMut ma luna o &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): e pani i ka impl ma luna no &mut me ka mea hou aʻe:
// // Hāpai ʻo AsMut ma luna o DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Pepa paia> AsMut <U>no ka D, fn as_mut(&mut self)-> &mut U,</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Mai hoʻohuʻu I
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Mai (a pela i loko) reflexive
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **kumupaʻa memo i:** kēia impl 'aʻole i koe nei, akā, ua mau "reserving space" e hui ia i loko o ka future.
/// E nānā i [rust-lang/rust#64715][#64715] no lāliʻi.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): e hana i kahi hoʻoponopono kumu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Hōʻike ʻo TryFrom iā TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallible conversions i semantically like i fallible conversions me ka i paʻapū i hewa type.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// pōhaku puna IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// THE NO-hewa hewaʻano
////////////////////////////////////////////////////////////////////////////////

/// ʻO ke ʻano hemahema no nā hewa i hiki ʻole ke hiki.
///
/// No keia enumʻaʻohe Lolina, he waiwai o kēia 'ano hiki loa nae nei.
/// Hiki ke hoʻohana pono ʻia kēia no nā API generic e hoʻohana ana iā [`Result`] a parameterize i ke ʻano hemahema, e hōʻike ai he [`Ok`] mau ka hopena.
///
/// No ka laʻana, ka mea [`TryFrom`] trait (huli ana i hoike i ka [`Result`]) i kekahi papa manaʻo no nā mea a pau ano kahi i nana e hoole [`Into`] manaʻo kūpono.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Hoʻohālikelike Future
///
/// Kēia enum i ka ia kūlana me [the `!`“never”type][never], i mea lolelua ka i loko o kēia mana o Rust.
/// Ke hoʻokūpaʻa ʻia ʻo `!`, hoʻolālā mākou e hana iā `Infallible` i kahi ʻano inoa iā ia:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …A laila hoʻonele hope iā `Infallible`.
///
/// Eia naʻe ka mea, i kekahi hihia ma `!` Ka Mooolelo O hiki ke hoʻohana mua `!` ua stabilized me ka piha-fledged type: i loko o ka oihana o ke kuleana pili i ka hoʻi type.
/// Ua hōʻike hewa, he mea hiki implementations no nāʻokoʻa papa laʻau kuhikuhiʻAno:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Me `Infallible` kahi enum, kūpono kēia code.
/// Naʻe ka wā `Infallible` i ka Alia no ka never type, na impl`s mau 'ia e hoʻomaka i ka' ano, a no laila, e ke kāne iā ia ma ka 'ōlelo o ka trait coherence lula.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}