//! ʻO ka libcore prelude
//!
//! Hoʻonohonoho ʻia kēia module no nā mea hoʻohana o libcore i pili ʻole i ka libstd.
//! Kuhi ʻia kēia module e ka paʻamau ke hoʻohana ʻia ʻo `#![no_std]` i ke ʻano like me ka prelude o ka waihona maʻamau.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// ʻO ka mana 2015 o ka prelude nui.
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ʻO ka mana 2018 o ka prelude nui.
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ʻO ka mana 2021 o ka prelude nui.
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Hoʻohui i nā mea hou aʻe.
}