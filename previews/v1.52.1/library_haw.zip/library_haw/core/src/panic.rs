//! Kākoʻo Panic i ka waihona waihona maʻamau.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Ke hāʻawi nei i kahi ʻike e pili ana i kahi panic.
///
/// `PanicInfo` ua hala ka hanana i kahi panic hook i hoʻonohonoho ʻia e ka hana [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Hoʻihoʻi i ka ukana pili me ka panic.
    ///
    /// ʻO kēia maʻamau, akā ʻaʻole mau, he `&'static str` a i ʻole [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Inā hoʻohana ʻia ka macro `panic!` mai ka `core` crate (ʻaʻole mai `std`) me kahi string formatting a me kekahi mau hoʻopaʻapaʻa hou aʻe, hoʻi i kēlā leka i mākaukau e hoʻohana ʻia me [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Hōʻike i ka ʻike e pili ana i kahi i hoʻomaka ai ka panic, inā loaʻa.
    ///
    /// E hoʻihoʻi mau kēia ala i ka [`Some`] i kēia manawa, akā hoʻololi paha kēia i nā mana future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Inā hoʻololi ʻia kēia i kekahi manawa hoʻi mai ʻaʻohe,
        // hana me kēlā hihia ma std::panicking::default_hook a me std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ʻaʻole hiki iā mākou ke hoʻohana downcast_ref: :<String>() ma aneʻi
        // ʻoiai ʻaʻole loaʻa ke aho ma ka libcore!
        // He String ka ukana ke kāhea ʻia ʻo `std::panic!` me nā hoʻopaʻapaʻa he nui, akā i kēlā manawa e loaʻa pū ka leka.
        //

        self.location.fmt(formatter)
    }
}

/// ʻO kahi mea i loaʻa ka ʻike e pili ana i kahi o panic.
///
/// Hana ʻia kēia hanana e [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Hoʻohālikelike maikaʻi no ka like a me ka hoonoho papa i hana ma ka waihona, laina, laila, kia ao makakoho.
/// Hoʻohālikelike ʻia nā faile ma ke ʻano he aho, ʻaʻole `Path`, hiki ke manaʻo ʻole ʻia.
/// E ʻike i nā palapala a [`Wahi: : faila`] no ke kūkā hou aʻe.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Hoʻihoʻi i kahi o ke kumu o ka mea e kāhea ana i kēia hana.
    /// Inā hōʻike ʻia ka mea kāhea o ia hana a laila hoʻihoʻi ʻia kāna wahi kāhea, a pēlā nō e piʻi aʻe i ka piʻina i ke kāhea mua i loko o kahi kino hana i ʻole ka nānā ʻia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Hoʻihoʻi i ka [`Location`] ma kahi i hea ʻia ai.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Hoʻihoʻi i kahi [`Location`] mai loko mai o ka wehewehe o kēia hana.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ke holo nei i ka hana untracked like i kahi wahi ʻokoʻa e hāʻawi iā mākou i ka hopena like
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ke holo nei i ka hana i mālama ʻia i kahi wahi ʻokoʻa e hoʻopuka i kahi waiwai ʻē aʻe
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Hoʻihoʻi i ka inoa o ka faile kumu i hoʻomaka ai ka panic.
    ///
    /// # `&str`, aole `&Path`
    ///
    /// ʻO ka inoa i hoʻihoʻi ʻia e pili ana i kahi ala kumu ma ka ʻōnaehana hōʻuluʻulu, akā ʻaʻole kūpono ia e hōʻike pololei i kēia me he `&Path`.
    /// E holo paha ka pāʻālua i hōʻuluʻulu ʻia ma kahi ʻōnaehana ʻokoʻa me ka hoʻokō `Path` ʻokoʻa ma mua o ka ʻōnaehana e hāʻawi nei i nā ʻike a ʻaʻohe ʻano "host path" ʻokoʻa o kēia waihona.
    ///
    /// Ka loa kahaha ko oukou naau hana ia lŘlŘ ia "the same" waihona mea reachable Via mau kuamoo, i loko o ka Module'ōnaehana (i hookuu hoʻohana i ka `#[path = "..."]` kaila a like), i hiki i ka mea akaka, e e'ālike kivila, e hoʻi like pu ole, aiee, mai keia kuleana pili i.
    ///
    ///
    /// # Cross-compilation
    ///
    /// ʻAʻole kūpono kēia waiwai no ka hele ʻana i `Path::new` a i ʻole nā mea kūkulu like i ka wā e ʻokoʻa ai ke kahua hoʻokipa.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// E hoʻihoʻi i ka helu laina a panic i hoʻomaka ai.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Hoʻihoʻi i ka kolamu kahi i hoʻomaka ai ka panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Kahi trait kūloko i hoʻohana ʻia e libstd e hāʻawi i ka ʻikepili mai ka libstd a i ka `panic_unwind` a me nā manawa holo panic ʻē aʻe.
/// ʻAʻole i manaʻo ʻia e hoʻokūpaʻa i kēlā me kēia manawa, mai hoʻohana.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Lawe i ke kuleana piha i nā ʻike ma loko.
    /// ʻO `Box<dyn Any + Send>` ka ʻano hoʻihoʻi, akā ʻaʻole hiki iā mākou ke hoʻohana i `Box` i ka libcore.
    ///
    /// Ma hope o ke kāhea ʻia ʻana o kēia hana, koe ka `self` wale nō ke kumu kūʻai paʻamau.
    /// Kahea ana i kēia hana i na manawa elua, a kahea `get` ma hope o ke kahea keia hana, o ka hewa.
    ///
    /// Ua aie ka hoʻopaʻapaʻa, no ka mea panic runtime (`__rust_start_panic`) wale loaʻa he aie `dyn BoxMeUp`.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// E hōʻaiʻe wale i nā ʻike.
    fn get(&mut self) -> &(dyn Any + Send);
}