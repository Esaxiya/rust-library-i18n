//! Shareable mutable pahu.
//!
//! Hoʻokumu ʻia ka palekana hoʻomanaʻo Rust ma kēia kānāwai: Hāʻawi ʻia i kahi mea `T`, hiki wale ke loaʻa kekahi o kēia mau mea:
//!
//! - Loaʻa iā (`&T`) mau kuhikuhi kūlohelohe ʻole i ka mea (ʻo **aliasing** kekahi).
//! - He hoʻokahi mutable maopopo kahi ('&mut T`) i ka mea (iʻikeʻia me **mutability**).
//!
//! Keia ua hookoia ma ka Rust compiler.Eia nō naʻe, aia kekahi mau hanana i lawa ʻole ka loli o kēia lula.I kekahi manawa koi ʻia e loaʻa i nā kuhikuhi he nui i kahi mea a hoʻololi ʻia naʻe.
//!
//! Aia nā ipu hiki ke hoʻololi i hiki ke ʻae i ka mutability i kahi ʻano kāohi, ʻoiai i ke alo o ka aliasing.ʻAe ʻelua [`Cell<T>`] a me [`RefCell<T>`] i ka hana ʻana i kēia i kahi ala hoʻokahi.
//! Eia naʻe,ʻaʻole hoʻi `Cell<T>` aole hoi `RefCell<T>` i ka pae malu (ka mea, e hoʻokō i ole [`Sync`]).
//! Inā pono ʻoe e hana i ka aliasing a me ka hoʻololi ma waena o nā pae he hiki ke hoʻohana i nā ʻano [`Mutex<T>`], [`RwLock<T>`] a i ʻole [`atomic`].
//!
//! Hiki ke hoʻololi ʻia nā waiwai o ka `Cell<T>` a me ka `RefCell<T>` ma o nā loiloi like (ie
//! ka `&T` ʻano maʻamau), ʻo ka hapanui o nā ʻano Rust hiki ke hoʻololi ʻia ma o nā kūmole kū hoʻokahi (`&mut T`).
//! Mākou e'ōlelo aku i `Cell<T>` a me `RefCell<T>` i 'Kalaiaina mutability', ma ka Akä naÿe me ka typical Rust ʻano e hōʻike nō ia o 'ili mutability'.
//!
//! CellʻAno e hele mai i loko o nā flavors: `Cell<T>` a me `RefCell<T>`.Hoʻokomo ʻo `Cell<T>` i ka hoʻololi o loko e ka neʻe ʻana i nā waiwai i loko a i waho o ka `Cell<T>`.
//! E hoʻohana ai i nā kūmole ma kahi o nā waiwai, pono i kekahi e hoʻohana i ka ʻano `RefCell<T>`, e loaʻa ana i kahi laka kākau ma mua o ka hoʻololi ʻana.`Cell<T>` i nā kiʻina hana e loaʻa nā a hoʻololi i kaʻikena Kalaiaina cia:
//!
//!  - No nā ʻano e hoʻokomo iā [`Copy`], loaʻa ka hana [`get`](Cell::get) i ka waiwai o loko i kēia manawa.
//!  - No nā ʻano e hoʻokomo iā [`Default`], hoʻololi ke ʻano [`take`](Cell::take) i ka waiwai o loko i kēia manawa me [`Default::default()`] a hoʻihoʻi i ka waiwai i hoʻololi ʻia.
//!  - No nā ʻano āpau, hoʻololi ka hana [`replace`](Cell::replace) i ka waiwai kūloko o kēia manawa a hoʻihoʻi i ka waiwai i hoʻololi ʻia a hoʻopau ka hana [`into_inner`](Cell::into_inner) i ka `Cell<T>` a hoʻihoʻi i ka waiwai o loko.
//!  Eia kekahi, o ka [`set`](Cell::set) iaoia replaces ke Keena Kalaiaina cia, e kahe mai ana i ka auou caiaiai waiwai.
//!
//! `RefCell<T>` hoʻohana Rust ka wa e ola ana, e hoʻokō 'hōʻeuʻeu i lawekahikiʻia', he kaʻina hana e hiki ai i kekahi ke koi? aiaiiuie, mikanele, mutable komo ana i ka pahale nui.
//! Noi wale aku no ka `RefCell<T>Nānā 'ʻia' i ka manawa holo ', ʻaʻole like me nā ʻano kūmole o Rust i nānā kūpaʻa ʻia, i ka manawa hōʻuluʻulu.
//! No ka mea, `RefCell<T>` noi wale aku i hōʻeuʻeu ia mea hiki, e hoao mai i ka aie i ka waiwai i ua mua mutably aie;ka wā keia hana ia Nā hualoaʻa ma ka pae panic.
//!
//! # Ka wā e koho ai i ka mutability o loko
//!
//! ʻO ka mutability hoʻoilina i ʻike pinepine ʻia, kahi e loaʻa ai i kahi ke komo ʻokoʻa e hoʻololi i kahi waiwai, ʻo ia kekahi o nā mea ʻōlelo nui e hiki ai iā Rust ke noʻonoʻo ikaika e pili ana i ka kuhikuhi ʻana i ka pointer, e pale kūpaʻa nei i nā ʻūpā.
//! Ma muli o ia mea, ʻoi aku ka makemake o ka mutability hoʻoilina, a ʻo ka mutability o loko kahi mea hope loa.
//! Mai aeeaʻAno ā nā mutation kahi i makemake ole ia e kāne iā nae, ma laila nō e lapa kāne ai ka wā Kalaiaina mutability paha e kūpono, a hoi *pono* e hoʻohana ', e like
//!
//! * Ke hoʻolauna nei i ka mutability 'inside' o kahi mea hiki ʻole ke hoʻololi
//! * Nā kikoʻī hoʻokō o nā ʻano loiloi-hiki ʻole ke hoʻololi.
//! * Hoʻohuli i nā hoʻokō o [`Clone`].
//!
//! ## Ke hoʻolauna nei i ka mutability 'inside' o kahi mea hiki ʻole ke hoʻololi
//!
//! Nui nā ʻano māka kuhikuhi ʻokoʻa, me [`Rc<T>`] a me [`Arc<T>`], hāʻawi i nā ipu i hiki ke kālona ʻia a kaʻana like ʻia ma waena o nā ʻaoʻao he nui.
//! Ma muli o ka hoʻonui ʻia ʻana o nā waiwai i loko o ka inoa, hiki iā lākou ke hōʻaiʻē me `&`, ʻaʻole `&mut`.
//! Me ka ʻole o nā hunaola hiki ʻole ke hoʻololi i ka ʻikepili i loko o kēia mau kuhi akamai.
//!
//! He mea maʻamau a laila kau i kahi `RefCell<T>` i loko o nā ʻano kuhikuhi ʻokoʻa e hoʻihoʻi hou i ka hiki ke hoʻololi.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // E hana i kekahi hou hihia, e kali i ka laulā o ka hōʻeuʻeu kēia
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // E hoʻomaopopo inā ʻaʻole mākou i hoʻokuʻu i ka hōʻaiʻē o ka cache ma mua o ka pae a laila ʻo ka hōʻaiʻē ma hope e hoʻokumu i kahi wana ikaika panic.
//!     //
//!     // ʻO kēia ka weliweli nui o ka hoʻohana ʻana iā `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! E hoʻomaopopo e hoʻohana ana kēia laʻana iā `Rc<T>` a ʻaʻole iā `Arc<T>`.`RefCell<T>ʻO nā no nā hanana i wili ʻia.E noʻonoʻo e hoʻohana i ka [`RwLock<T>`] a i ʻole [`Mutex<T>`] inā pono ʻoe i ka mutability ma kahi ʻano i wili ʻia.
//!
//! ## Nā kikoʻī hoʻokō o nā ʻano loiloi-hiki ʻole ke hoʻololi
//!
//! ʻO kekahi manawa makemake ʻia ʻaʻole e hōʻike i kahi API aia kahi hoʻololi e ulu nei ma "under the hood".
//! Kēia i ia no kekahi hoʻonohonoho i ka hana mea luli ole, akā, IAOEIAaO, Ahu poe koa i ka manaʻo e hana mutation;a no ka mea, e pono e hoohana mutation e hoʻokō i kekahi manaʻo trait iaoia i i mua i ho'ākāka 'e lawe `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Pipiʻi computation hele 'aneʻi
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Hoʻohuli i nā hoʻokō o `Clone`
//!
//! Keia mea wale ka kūikawā, akā, he pono ole, hihia o ka mua: peʻe mutability no ka hana e hoike hou aku ai e luli ole.
//! ʻO ka hana [`clone`](Clone::clone) i manaʻo ʻia ʻaʻole e loli i ke kumu waiwai, a ua ʻōlelo ʻia e lawe iā `&self`, ʻaʻole `&mut self`.
//! No laila, i kekahi mutation i ka hana i loko o ka `clone` hana pono hoʻohana aeeaʻAno.
//! No ka laʻana, [`Rc<T>`] malama kona maopopo kahi helu i loko o ka `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// A mutable iaiyoe wahi.
///
/// # Examples
///
/// I kēia laʻana, hiki iā ʻoe ke ʻike i ka `Cell<T>` hiki ke hoʻololi i loko o kahi mea hoʻololi ʻole.
/// Ma na olelo e ae, ia mau hiʻohiʻona nō "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Hewa: `my_struct` hiki ke hoʻololi ʻole
/// // my_struct.regular_field =New_value;
///
/// // Hana ana: naʻe `my_struct` mea luli ole, `special_field` mea he `Cell`,
/// // i hiki mau ke mutated
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Hana he `Cell<T>`, a me ka `Default` waiwai no T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Hana i kahi `Cell` hou i loaʻa ka waiwai i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Hoʻonohonoho i ka waiwai i loaʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Swaps na aiee o elua keena.
    /// Koena unuhi me `std::mem::swap` mea i keia papa, aole ia i koi `&mut` i maopopo nä haumäna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: Hiki ke makaʻala kēia inā e kāhea ʻia mai nā pae i hoʻokaʻawale ʻia, akā `Cell`
        // o `!Sync` no laila keia e aole e hiki mai.
        // ʻAʻole ia e hōʻoia i nā kuhikuhi ma hope o `Cell` e hōʻoia nei ʻaʻohe mea ʻē aʻe e kuhikuhi ana i kekahi o kēia mau 'Pūnaewele.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Replaces ka mea i kakauiaʻi maluna dala me `val`, a hoi mai i ka mea kahiko i kakauiaʻi maluna waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETY: Hiki i kēia ke kumu i nā lāhui ʻikepili inā kāhea ʻia mai kahi pae ʻokoʻa,
        // akā ʻo `Cell` ʻo `!Sync` no laila ʻaʻole kū kēia.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Wehe i ka waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Hoʻihoʻi i kahi kope o ka waiwai i loaʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETY: Hiki i kēia ke kumu i nā lāhui ʻikepili inā kāhea ʻia mai kahi pae ʻokoʻa,
        // akā ʻo `Cell` ʻo `!Sync` no laila ʻaʻole kū kēia.
        unsafe { *self.value.get() }
    }

    /// Hoʻopuka hou ka mea i kakauiaʻi maluna waiwai hoʻohana i ka papa, a hoike i ka hou cia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Hoike i ka maka laʻau kuhikuhi i ka nń kuʻikepili i loko o keia halepaahao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// E hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i ka ʻikepili ma lalo.
    ///
    /// Keia leo kahea e noi `Cell` mutably (i i hoʻouluulu-manawa) i hoʻohiki ia mākou e komo ai i ka wale i maopopo nä haumäna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Hoʻihoʻi i kahi `&Cell<T>` mai kahi `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` e hōʻoia i ke komo ʻokoʻa.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Lawe i ka waiwai o ka pūnaewele, waiho iā `Default::default()` ma kona wahi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Hoʻihoʻi i kahi `&[Cell<T>]` mai kahi `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: Loaʻa iā `Cell<T>` ka hoʻolālā hoʻomanaʻo like me `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Kahi kahi hoʻomanaʻo hoʻomanaʻo me nā lula hōʻaiʻē hōʻeuʻeu hōʻeuʻeu
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// An hewa hoʻi ma [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// An hewa hoʻi ma [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Hōʻike nā helu maikaʻi i ka helu o `Ref` e hana nei.Hōʻike nā helu maikaʻi ʻole i ka helu o `RefMut` e hana nei.
// hiki wale nō mau 'RefMut`s e hana i kekahi manawa, inā lākou lākou i kapa i ka okoa, nonoverlapping eiiiiiaiou o ka `RefCell` (e like, kekahi mau papa koa o ka māhele).
//
// `Ref` a me `RefMut` nō lāua mau hua'ōlelo ma ka nui, a no laila, ma laila nō paha aole e lawa 'Ref`s' ole 'RefMut`s ma ka wa e hoʻohālana ka hapalua o ka `usize` laulā.
// Penei, he `BorrowFlag` e paha aole hoʻohālana paha underflow.
// Eia nō naʻe, ʻaʻole ia he ʻōlelo hoʻohiki, no ka mea hiki i kahi papahana pathological ke hana pinepine a laila mem::forget Ref`s a i ʻole 'RefMut`s.
// No laila, pono e nānā pono i nā code āpau no ka overflow a me ka underflow i mea e pale ʻole ai i ka palekana, a i ʻole ma ke ʻano kūpono e hana pono ai i ka hanana i kahe mai a i ʻole kahe i lalo (eg, e nānā iā BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// I ka mea hou `RefCell` i loaʻa `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Pau ka `RefCell`, hoʻihoʻi i ka waiwai i wahī ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ma muli o ka hana o `self` (ka `RefCell`) ma o ka waiwai, hōʻoia ka mea hoʻopili ʻaʻole ia i hōʻaiʻē ʻia i kēia manawa.
        //
        self.value.into_inner()
    }

    /// Hoʻololi i ka waiwai i wahī ʻia me kahi mea hou, e hoʻihoʻi ana i ka waiwai kahiko, me ka hoʻopau ʻole ʻana i kekahi i kekahi.
    ///
    ///
    /// Kēia kuleana pili i hoʻopili like i [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics inā hōʻaiʻē ke kumukūʻai i kēia manawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Hoʻololi i ka waiwai i wahī ʻia me kahi mea hou i helu ʻia mai `f`, e hoʻihoʻi nei i ka waiwai kahiko, me ka hoʻopau ʻole ʻana i kekahi i kekahi.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā hōʻaiʻē ke kumukūʻai i kēia manawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps ka wahīʻia waiwai o `self` me na wahi waiwai o `other`, me deinitializing kekahi i kekahi.
    ///
    ///
    /// Kūlike kēia hana i [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably noi wale aku i ka wahi waiwai.
    ///
    /// Noho ka ʻaiʻē a hiki i ka hoʻi ʻana o `Ref` i ka laulā.
    /// Mau luli ole mai kaii hiki ke lawe mai i ka ia manawa.
    ///
    /// # Panics
    ///
    /// Panics ina o ka waiwai ua a ianoiyuaa a mutably aie.
    /// No ka pili-'ā'ā Lolina, e hoʻohana [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// An laʻana o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Hoʻoiho ʻole Immutable i ka waiwai i wahī ʻia, e hoʻihoʻi nei i kahi hemahema inā hōʻaiʻē ʻia kēia waiwai i kēia manawa.
    ///
    ///
    /// Noho ka ʻaiʻē a hiki i ka hoʻi ʻana o `Ref` i ka laulā.
    /// Mau luli ole mai kaii hiki ke lawe mai i ka ia manawa.
    ///
    /// ʻO kēia ka ʻano panicking ʻole o [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: Hōʻoia ʻo `BorrowRef` aia wale nō ke komo hiki ʻole ke hoʻololi ʻia
            // a hiki i ka nui ana aie.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably noi wale aku i ka wahi waiwai.
    ///
    /// Na kēia mau a hiki i ka hoi mai `RefMut` a me nā mea a pau 'RefMut`s loko mai o ka mea OAAIeOO laulā.
    ///
    /// Ke kumukuai hiki ole e aie oiai keia kēia mea kaila.
    ///
    /// # Panics
    ///
    /// Panics inā hōʻaiʻē ke kumukūʻai i kēia manawa.
    /// No kahi ʻano panic ʻole panicking, e hoʻohana iā [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// An laʻana o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably noi wale aku i ka wahiia waiwai, hoi mai ka hewa ina i ka waiwai ua a ianoiyuaa a aie.
    ///
    ///
    /// Na kēia mau a hiki i ka hoi mai `RefMut` a me nā mea a pau 'RefMut`s loko mai o ka mea OAAIeOO laulā.
    /// Ke kumukuai hiki ole e aie oiai keia kēia mea kaila.
    ///
    /// ʻO kēia ka ʻano panicking ʻole o [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // Maluhia: `BorrowRef` hoʻohiki hanana ke kula.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Hoike i ka maka laʻau kuhikuhi i ka nń kuʻikepili i loko o keia halepaahao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// E hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i ka ʻikepili ma lalo.
    ///
    /// Keia leo kahea e noi `RefCell` mutably (i i hoʻouluulu-manawa) no laila ka mea, aole e pono no ka hōʻeuʻeu loaʻa, e kaha.
    ///
    /// Eia naʻe e makaala lakou: i kēia papa hana manao `self` e e mutable, i mea nui i ka hihia o ka hoʻohana 'ana i ka `RefCell`.
    ///
    /// E i ka nana aku i ka [`borrow_mut`] iaoiaeii kahi ina `self` mea ole mutable.
    ///
    /// Nō hoʻi, e 'oluʻolu e makaala i keia iaoia mea wale no ka hana ana a me ka mea ana i mea e makemake.
    /// Inā kānalua, e hoʻohana ma kahi o [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Wehe aku i ka hopena o ka pūnāwai kiai ma ka kēia moku'āina o ka `RefCell`.
    ///
    /// Ua like kēia kāhea me [`get_mut`] akā ʻoi aku ka loea.
    /// Hāʻawi hōʻaiʻē ʻo `RefCell` e hōʻoia i ka loaʻa ʻole o nā hōʻaiʻe a laila hoʻonohonoho hou i ka huli ʻana o ka mokuʻāina i nā ʻaiʻē.
    /// Kēia mea pili ina kekahi `Ref` a `RefMut` noi wale aku i ua pūnāwai.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Hoʻoiho ʻole Immutable i ka waiwai i wahī ʻia, e hoʻihoʻi nei i kahi hemahema inā hōʻaiʻē ʻia kēia waiwai i kēia manawa.
    ///
    /// # Safety
    ///
    /// ʻAʻole like me `RefCell::borrow`, palekana kēia ʻano hana no ka mea ʻaʻole ia e hoʻihoʻi i kahi `Ref`, a pēlā e waiho nei i ka hae hōʻaiʻe i hoʻopā ʻole ʻia.
    /// Mutably i lawekahikiʻia ka `RefCell` ana ka olua hoi ma keia iaoia mea e ola ana ka undefined kolohe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // Maluhia: mākou e kaha i ka 'Aʻohe ua' Imi kākau kēia manawa, akā, ia mea
            // ke kuleana o ka mea e kāhea ana e hōʻoia i ka ʻole kākau ʻana a hiki i ka hoʻohana ʻole ʻana o ka palapala hoʻihoʻi.
            // Eia kekahi, `self.value.get()` pili i ka waiwai i loaʻa iā `self` a no laila ua hōʻoia ʻia e kūpono no ke ola o `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// I ka wahiia waiwai, a waiho `Default::default()` ma kona wahi.
    ///
    /// # Panics
    ///
    /// Panics inā hōʻaiʻē ke kumukūʻai i kēia manawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ina o ka waiwai ua a ianoiyuaa a mutably aie.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Hana i kahi `RefCell<T>`, me ka waiwai `Default` no T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ina o ka waiwai i loko o kekahi `RefCell` ua a ianoiyuaa a aie.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Hiki i ka hōʻaiʻē hoʻonui ʻana ke hopena i kahi waiwai heluhelu ʻole (<=0) i kēia mau hihia:
            // 1. Ka mea, ua <0, oa ma laila e kākau noi wale aku, no laila mākou hiki ole ae i ka heluhelu iho nonoi ke ku i Rust ka maopopo kahi aliasing rula
            // 2.
            // ʻO isize::MAX (ka nui o nā ʻaiʻē heluhelu) a hoʻonui ʻia i isize::MIN (ka nui o ke noi ʻana i nā ʻaiʻē) no laila ʻaʻole hiki iā mākou ke ʻae i kahi hōʻaiʻē heluhelu hou aʻe no ka mea ʻaʻole hiki i ka isize ke hōʻike i nā ʻaiʻē heluhelu he nui (hiki wale kēia inā oe mem::forget oi ma mua o ka uuku a eia i nui o ka 'Ref`s, i mea ole pono me ka hana pono)
            //
            //
            //
            //
            None
        } else {
            // Incrementing kēia hiki ka hopena i ka heluhelu waiwai (> 0) i loko o kēia mau hihia:
            // 1. ʻO ia=0, ie ʻaʻole ia i ʻaiʻē ʻia, a ke lawe nei mākou i ka ʻaiʻē heluhelu mua
            // 2. Ka mea, ua> 0 a <isize::MAX, oa
            // ka mea, ua heluhelu iho noi wale aku, a me ka isize mea nui kupono e ho i ka hoʻokahi heluhelu iho hou kēia
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // No keia Ref nei, aole makou i ike i ke kēia ka hae o ka heluhelu ana kēia.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Pale aku i ka nonoi ke loan mai ka ua kahe i loko o ka kēia palapala.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wahī mai i ka aie pili i kekahi mea i loko o ka `RefCell` pahu.
/// A wrapperʻano no ka waiwai immutably aie mai ka `RefCell<T>`.
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Nā kope o ka `Ref`.
    ///
    /// Ka `RefCell` Ua ua immutably aie, no laila, ua hiki ole pau.
    ///
    /// Keia mea he hui hana e pono e e hoʻohana like `Ref::clone(...)`.
    /// Hoʻopilikia kahi hoʻokō `Clone` a i ʻole kahi hana i ka hoʻohana ākea o `r.borrow().clone()` e clone i nā ʻike o kahi `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Hana i kahi `Ref` hou no kahi ʻāpana o ka ʻikepili i hōʻaiʻē ʻia.
    ///
    /// Ka `RefCell` Ua ua immutably aie, no laila, ua hiki ole pau.
    ///
    /// He hana pili kēia e pono e hoʻohana ʻia ma ke ʻano he `Ref::map(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Make i ka hou `Ref` no ka koho ke keʻena o ka aie aeaiiuo.
    /// Ka palapala kiai ua hoi aku la me ka `Err(..)` ina ka panina huli `None`.
    ///
    /// Ka `RefCell` Ua ua immutably aie, no laila, ua hiki ole pau.
    ///
    /// Keia mea he hui hana e pono e e hoʻohana like `Ref::filter_map(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Mahae he `Ref` i loko o mau 'Ref`s no kekahi mau eiiiiiaiou o ka aie aeaiiuo.
    ///
    /// Ka `RefCell` Ua ua immutably aie, no laila, ua hiki ole pau.
    ///
    /// He hana pili kēia e pono e hoʻohana ʻia ma ke ʻano he `Ref::map_split(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Ho ololi i loko o ka pili a hiki i ka hp'pnphp 'ikepili.
    ///
    /// ʻAʻole hiki ke hōʻaiʻē hou ʻia ka `RefCell` ma lalo a e hōʻike mau ʻia ua hōʻaiʻē ʻole ʻia.
    ///
    /// Ia mea,ʻaʻole he aho paha e liu hou ma mua o kekahi mau helu o nā kūmole.
    /// Hiki ke hōʻaiʻē ʻole hou ʻia ka `RefCell` inā loaʻa kahi liʻiliʻi liʻiliʻi o nā kahe i ka huina.
    ///
    /// He hana pili kēia e pono e hoʻohana ʻia ma ke ʻano he `Ref::leak(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // E poina ana i kēia Ref ua hōʻoia 'ia ai ka nonoi ke ee i loko o ka RefCell hiki ole ke hele hoʻi i ka ua hanaʻole i loko o ka wā e ola `'b`.
        // ʻO ka hoʻonohonoho hou ʻana i ka mokuʻāina hulina e koi ai i kahi kū hoʻokahi i ka RefCell i hōʻaiʻē ʻia.
        // No aku mutable kūmole hiki ke hana mai i ka palapala halepaahao.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Make i ka hou `RefMut` no i ke keʻena o ka aie aeaiiua, IAOEIAaO, he enum Lolina.
    ///
    /// Ua hōʻaiʻē mutable ʻia ka `RefCell`, no laila ʻaʻole hiki i kēia ke hāʻule.
    ///
    /// Keia mea he hui hana e pono e e hoʻohana like `RefMut::map(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): hoʻoponopono hoʻopono-hōʻaiʻē
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Make i ka hou `RefMut` no ka koho ke keʻena o ka aie aeaiiuo.
    /// Ka palapala kiai ua hoi aku la me ka `Err(..)` ina ka panina huli `None`.
    ///
    /// Ua hōʻaiʻē mutable ʻia ka `RefCell`, no laila ʻaʻole hiki i kēia ke hāʻule.
    ///
    /// Keia mea he hui hana e pono e e hoʻohana like `RefMut::filter_map(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): hoʻoponopono hoʻopono-hōʻaiʻē
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // Maluhia: kuleana pili i paʻa ma luna o ka mikanele kūmole no ka lōʻihi like
        // o kona kahea ma `orig`, a me ka laʻau kuhikuhi mea wale de-i maopopo nä haumäna maloko o ka papa hea loa i hiki i ka mikanele i maopopo kahi e pakele.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: like me ma luna.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Mahae he `RefMut` i loko o mau 'RefMut`s no kekahi mau eiiiiiaiou o ka aie aeaiiuo.
    ///
    /// Na ka hp'pnphp `RefCell` e mea, ke koe mutably aie a hele mai nā hoʻi `RefMut`s o ka laulā.
    ///
    /// Ua hōʻaiʻē mutable ʻia ka `RefCell`, no laila ʻaʻole hiki i kēia ke hāʻule.
    ///
    /// He hana pili kēia e pono e hoʻohana ʻia ma ke ʻano he `RefMut::map_split(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Hoʻohuli i kahi kuhikuhi e hiki ai ke hoʻololi i ka ʻikepili ma lalo.
    ///
    /// ʻAʻole hiki ke hōʻaiʻē hou ʻia ka `RefCell` ma lalo a e hōʻike ʻē ʻia i kēia manawa ua hōʻaiʻē ʻia, e hana ana i ka hoʻihoʻi i ka ʻaoʻao i loko wale nō.
    ///
    ///
    /// Keia mea he hui hana e pono e e hoʻohana like `RefMut::leak(...)`.
    /// A hana e ālai ia 'aʻe i kāu kiʻina hana o ka ia inoa ma luna o kahi o ka `RefCell` hoʻohana ma `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // E poina ana i kēia BorrowRefMut ua hōʻoia 'ia ai ka nonoi ke ee i loko o ka RefCell hiki ole ke hele hoʻi i ka ua hanaʻole i loko o ka wā e ola `'b`.
        // ʻO ka hoʻonohonoho hou ʻana i ka mokuʻāina hulina e koi ai i kahi kū hoʻokahi i ka RefCell i hōʻaiʻē ʻia.
        // ʻAʻole hiki ke hana i nā kūmole hou mai ka pūnaewele kumu i loko o kēlā ola ʻana, e hōʻaiʻē ana i kēia manawa i kahi kuhikuhi wale nō no ke koena o ke ola.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Haʻalele BorrowRefMut::clone, hou ua kapaia e hana i ka loiloi mua
        // mutable maopopo, a no laila, he pono a ianoiyuaa a e ole na kūmole.
        // No laila, ʻoiai e hoʻonui ana ka clone i ka helu hou i hiki ke hoʻololi ʻia, eia mākou ke ʻae wale nei e hele mai UNUSED a UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones he `BorrowRefMut`.
    //
    // Kēia mea i pololei ia wale nō inā kela a me keia `BorrowRefMut` ua hoʻohana 'ia e Hoʻokolo ka mutable pili i ka okoa, nonoverlapping huahelu o ka palapala mea.
    //
    // ʻAʻole kēia i ka Clone impl no laila ʻaʻole kāhea ke code i kēia implicitly.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Pale aku i ka nonoi ke loan mai underflowing.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// A wrapperʻano no ka waiwai mutably aie mai ka `RefCell<T>`.
///
/// E ʻike i ka [module-level documentation](self) no ka mea hou aʻe.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// ʻO ke kumu kumu no ka hoʻololi o loko i Rust.
///
/// Inā he `&T` kūmole kāu, a laila ma Rust maʻamau ka hana a ka mea hoʻopili i nā optimization e pili ana i ka ʻike e kuhikuhi ana ʻo `&T` i ka ʻikepili hiki ʻole ke hoʻololi., Mutating mea aeaiiua, no ka laʻana ma ka Alia paha ma transmuting ka `&T` i loko o ka `&mut T` ua noʻonoʻo undefined kolohe.
/// `UnsafeCell<T>` hōʻalo-mai o ka immutability kumu hoʻomalu no `&T`: i kaʻana maopopo kahi `&UnsafeCell<T>` e kuhikuhi i kaʻikepili i ua ka mutated.Kapa ʻia kēia "interior mutability".
///
/// Nā ʻano ʻē aʻe āpau e ʻae i ka hoʻololi kūloko, e like me `Cell<T>` a me `RefCell<T>`, hoʻohana kūloko iā `UnsafeCell` e wahī i kā lākou ʻikepili.
///
/// Hoʻomaopopo e hoʻopili wale ʻia ka hōʻoia immutability no nā kūmole i pili ʻia e `UnsafeCell`.ʻAʻole hoʻohuli ʻia ka ʻōlelo kū hoʻokahi no nā kūmole hiki ke hoʻololi ʻia.ʻAʻohe *ala* kū kānāwai e kiʻi ai i ka aliasing `&mut`, ʻaʻole me `UnsafeCell<T>`.
///
/// Ka `UnsafeCell` API iho ka technically loa puni hoʻi: [`.get()`] haawi mai oe i ka maka laʻau kuhikuhi `*mut T` i kona Contents.Aia iā _you_ ma ke ʻano he mea hoʻolālā kiʻi e hoʻohana pololei i kēlā kuhikuhi maka.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Aia i loko o ka flx ka lula pololei Rust aliasing rula, akā ʻaʻole kūʻē nā mea nui.
///
/// - Inā 'oe e ho okumu i ka palekana i maopopo kahi me ka wa e ola ana `'a` (kekahi he `&T` a `&mut T` maopopo) i mea ole ma ka palekana code (no kekahi laʻana, no ka mea, e hoʻi hou ka mea,), a lailaʻoe pono ole keʻeʻe ma nāʻikepili ma kekahi ala e hoole aku paha i pili no ke koena o `'a`.
/// ʻO kahi laʻana, ʻo ia hoʻi inā ʻoe e lawe i ka `*mut T` mai kahi `UnsafeCell<T>` a hoʻolei iā ia i `&T`, a laila mau ka ʻike ma `T` (modulo i kahi `UnsafeCell` ʻikepili i loaʻa ma loko o `T`, ʻoiaʻiʻo) a pau ke ola o kēlā kūmole.
/// Pēlā nō, inā hana ʻoe i kahi kūmole `&mut T` i hoʻokuʻu ʻia i kahi pāʻālua palekana, a laila ʻaʻole pono ʻoe e kiʻi i ka ʻikepili ma loko o ka `UnsafeCell` a pau ka manawa o kēlā kūmole.
///
/// - I nā manawa āpau, pono ʻoe e hōʻalo i nā lāhui ʻikepili.Inā loaʻa i nā pae he nui i ka `UnsafeCell` like, a laila pono i kekahi mau kākau i kahi hanana kūpono-ma mua o ka pili ʻana i nā kiʻi ʻē aʻe (a hoʻohana i nā atomika).
///
/// E kokua me ka kupono manao, i ka i kēia nā mea e hiki wale mai i kūlike loa hai loio no hookahi-wili kuhi:
///
/// 1. Hiki ke hoʻokuʻu ʻia kahi kūmole `&T` i ka pāʻālua palekana a ma laila hiki ke noho pū me nā kuhikuhi `&T` ʻē aʻe, akā ʻaʻole me `&mut T`
///
/// 2. E hoʻokuʻu ʻia kahi kūmole `&mut T` i ke code palekana i hāʻawi ʻia ʻaʻole i loaʻa pū kekahi `&mut T` a `&T` paha me ia.A `&mut T` pono mau ke ʻano ʻokoʻa.
///
/// Note e oiai i hookuuiaʻi na mutating kahi o ka `&UnsafeCell<T>` (e like ana nā `&UnsafeCell<T>` kūmole Alia ka halepaahao) mea OK (ina oe hooko i ka luna invariants kekahi'ē aʻe ala), ia mea nō undefined hana e i mau `&mut UnsafeCell<T>` Iu.
/// Ia mea, `UnsafeCell` mea he wrapper ke hoʻololi i ka i ka kūikawā AaOIeIOUIeXAOAaIN me _shared_ accesses (_i.e._, ma ka `&UnsafeCell<_>` kūmole);ka mea, aohe kilokilo ka mea i ka wā Hana me _exclusive_ accesses (_e.g._, ma ka `&mut UnsafeCell<_>`): aole hoi o ka halepaahao, aole hoi me ka wahi waiwai i ke aliased no ka lōʻihi like 'ole o ka mea `&mut` kēia.
///
/// Keia ua showcased ma ka [`.get_mut()`] accessor, i mea he _safe_ getter mea e haawi i ko ke `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Eia kahi laʻana e hōʻike ana pehea e hoʻololi pono ai i nā ʻike o kahi `UnsafeCell<_>` me ka nui o nā kūmole he nui e hoʻohuli nei i ka pūnaewele.
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Kiʻi i mau/i kaʻana like i maopopo nä haumäna i ka ia `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: ma waena o kēia laulā ʻaʻohe mea ʻē aʻe e pili ana i nā ʻikepili o `x`,
///     // no laila kū hoʻokahi kā mākou.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- hōʻaiʻē-+
///     *p1_exclusive += 27; // |
/// } // <---------- ʻaʻole hiki ke hele ma ʻō o kēia kiko -------------------+
///
/// unsafe {
///     // Maluhia: i loko o kēia laulā 'Aʻohe manao e i mikanele ke kōkua o ke' x` ka Contents,
///     // no laila, ua hiki i mau kaʻana accesses concurrently.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Hōʻike ka laʻana aʻe i ka ʻoiaʻiʻo ke komo wale ʻana i kahi `UnsafeCell<T>` e hōʻike nei i ke komo wale ʻana i kāna `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // me nā kiʻi kūikawā,
///                         // `UnsafeCell` mea he aniani moakaka ole-Kaiaulu wrapper, no laila,ʻaʻohe mea e pono ai no ka `unsafe` ʻaneʻi.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // E kiʻi i kahi hōʻuluʻulu manawa-nānā kū hoʻokahi i `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Me ka mikanele olua, ua hiki mutate i nā mea no ka noa.
/// *p_unique.get_mut() = 0;
/// // A i ʻole, kaulike:
/// x = UnsafeCell::new(0);
///
/// // Ke loaʻa iā mākou ka waiwai, hiki iā mākou ke unuhi i nā ʻike no ka manuahi.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Iino? Ieea he hou kekahi manawa o `UnsafeCell` a e uhi i ka hoakaka waiwai.
    ///
    ///
    /// All komo i ka pā cia ma kāu kiʻina hana o `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Wehe i ka waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Loaʻa i kahi kuhikuhi kuhi i ka waiwai i wahī ʻia.
    ///
    /// Kēia hiki e hoolei i ka laʻau kuhikuhi ana i kekahi ano keia ano.
    /// Hōʻoia 'ia ai ka hoʻohana kū hoʻokahi (ʻaʻohe hana kūmole, mutable pahaʻaʻole) ka wā e mahiki ana i `&mut T`, a hōʻoia' ia ai, he ole mutations a mutable Iu hele ana ma luna o ka wā e mahiki ana i `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Hiki iā mākou ke hoʻolei i ka pointer mai `UnsafeCell<T>` a `T` ma muli o #[repr(transparent)].
        // Hoʻohana kēia i ke kūlana kūikawā o libstd, ʻaʻohe mea hōʻoia no ka pāʻālua hoʻohana e hana kēia i nā mana future o ka mea hoʻopili!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// E hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i ka ʻikepili ma lalo.
    ///
    /// ʻOi kāhea kēia kāhea i ka `UnsafeCell` hiki ke hoʻololi ʻia (i ka manawa hōʻuluʻulu) e hōʻoia ai e loaʻa iā mākou kahi kūmole wale nō.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Loaʻa i kahi kuhikuhi kuhi i ka waiwai i wahī ʻia.
    /// Ke koena unuhi ia [`get`] mea i kēia kuleana pili i lawe maikai nei heʻiʻo maka nō laʻau kuhikuhi, i mea pono e pale i ka haku o? Aiaiiuie kūmole.
    ///
    /// Hiki ke hoʻolei i ka hopena i kahi kuhikuhi o kēlā me kēia ʻano.
    /// Hōʻoia 'ia ai ka hoʻohana kū hoʻokahi (ʻaʻohe hana kūmole, mutable pahaʻaʻole) ka wā e mahiki ana i `&mut T`, a hōʻoia' ia ai, he ole mutations a mutable Iu hele ana ma luna o ka wā e mahiki ana i `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Gradual initialization o ka `UnsafeCell` pono `raw_get`, e like me ke kahea `get` makemake e noi mai ana e pili ana i ka olua i uninitializedʻikepili:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Hiki iā mākou ke hoʻolei i ka pointer mai `UnsafeCell<T>` a `T` ma muli o #[repr(transparent)].
        // Hoʻohana kēia i ke kūlana kūikawā o libstd, ʻaʻohe mea hōʻoia no ka pāʻālua hoʻohana e hana kēia i nā mana future o ka mea hoʻopili!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Hana i kahi `UnsafeCell`, me ka waiwai `Default` no T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}