//! Nā ʻano ʻĀtoma
//!
//! Hāʻawi nā ʻano atomic i nā kamaʻilio hoʻomanaʻo hoʻomanaʻo kahiko ma waena o nā pae, a ʻo ia nā mea kūkulu o nā ʻano like like.
//!
//! Hōʻike kēia module i nā mana atomic o kahi wae i wae ʻia o nā ʻano primitive, e like me [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Hōʻike nā ʻano ʻĀtoma i nā hana, ke hoʻohana pono ʻia, hoʻopili i nā mea hou ma waena o nā pae.
//!
//! Lawe kēlā me kēia hana i [`Ordering`] e hōʻike ana i ka ikaika o ka pale hoʻomanaʻo no kēlā hana.Ua like kēia mau hoʻonohonoho ʻana me [C++20 atomic orderings][1].No ka ʻike hou aku e ʻike i ka [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Palekana nā ʻano Atomic e kaʻana ma waena o nā pae (hoʻokomo lākou i [`Sync`]) akā ʻaʻole lākou e hoʻolako i ka hana no ka kaʻana like ʻana a me ka ukali ʻana i ka [threading model](../../../std/thread/index.html#the-threading-model) o Rust.
//!
//! ʻO ke ala maʻamau e kaʻana like ai i ka loli atomic e hoʻokomo iā ia i loko o kahi [`Arc`][arc] (kahi kuhikuhi kuhikuhi i helu ʻia me nā atika.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! 'Ātoma ano hiki ke waiho i loko o kūpaʻa DEBFULLNAME, initialized hoʻohana 'ana i nā initializers ikaika e like [`AtomicBool::new`].Hoʻohana pinepine ʻia nā Atomic statics no ka hoʻomaka palau ʻana o ka honua.
//!
//! # Portability
//!
//! Hoʻomaopopo ʻia nā ʻano ʻātoma āpau i kēia module i [lock-free] inā loaʻa lākou.Kuhi kēia ʻaʻole lākou e loaʻa i loko kahi mutex honua.ʻAʻole hōʻoia ʻia nā ʻano ʻĀtoma a me nā hana e kali ʻole ai.
//! ʻO kēia ka mea e hoʻokō ʻia nā hana e like me `fetch_or` me kahi loop hoʻohālikelike a me swap.
//!
//! Hiki ke hoʻokō ʻia nā hana Atomic ma ka papa kuhikuhi me nā ʻenoma nui.Eia kekahi laʻana, hoʻohana kekahi mau paepae i nā ʻōkuhi atomic 4-byte e hoʻokō iā `AtomicI8`.
//! E hoʻomaopopo he pono ʻole kēia hopena ma ka pololei o ke code, he mea wale nō ia e ʻike ai.
//!
//! i ole e loaʻa ma luna o nā mea a pau paepae ai ke'ātoma ano i loko o kēia māhele Module.Loaʻa ākea nā ʻano ʻātoma ma aneʻi, akā naʻe, a hiki ke hilinaʻi nui ʻia i ka wā e kū nei.ʻO kekahi mau hoʻokoe koʻikoʻi:
//!
//! * PowerPC a me nā paepae MIPS me nā pointers 32-bit ʻaʻohe o `AtomicU64` a i ʻole `AtomicI64` mau ʻano.
//! * ARM hoʻolako nā paepae e like me `armv5te` ʻaʻole no Linux wale nō nā hana `load` a me `store`, a ʻaʻole kākoʻo i ka hoʻohālikelike a me ka Swap (CAS) mau hana, e like me `swap`, `fetch_add`, etc.
//! Hoʻohui ʻia ma Linux, hoʻokō ʻia kēia mau hana CAS ma o [operating system support], i hiki mai me ka hoʻopaʻi hana.
//! * ARM hoʻolako nā pahuhopu me `thumbv6m` i nā hana `load` a me `store` wale nō, a ʻaʻole i kākoʻo i ka hoʻohālikelike a me ka Swap (CAS) mau hana, e like me `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! E hoʻomaopopo he hiki ke hoʻohui ʻia i nā paepae future i loaʻa ʻole ke kākoʻo no kekahi mau hana ʻtoma.Makemake ka makaʻu lawelima maximally e akahele e pili ana i nā ʻano atomic e hoʻohana ʻia ai.
//! `AtomicUsize` a ʻo `AtomicIsize` ka mea maʻalahi loa, akā ʻaʻole naʻe i loaʻa ma nā wahi āpau.
//! No ke kuhikuhi, koi ka waihona `std` i nā atomika i kuhikuhi i ka helu, ʻoiai ʻo `core` ʻaʻole.
//!
//! I kēia manawa pono ʻoe e hoʻohana i ka `#[cfg(target_arch)]` mua e hōʻuluʻulu kūloko i ke code me nā atomika.Aia kekahi `#[cfg(target_has_atomic)]` paʻa ʻole e kūpaʻa paha i ka future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ʻO kahi wili maʻalahi:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // E kali no ka pae ʻē aʻe e hoʻokuʻu i ka laka
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! E mālama i kahi helu honua o nā pae ola:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ʻO kahi ʻano boolean i hiki ke kaʻana like ʻia ma waena o nā pae.
///
/// Loaʻa i kēia ʻano ke ʻano hoʻomanaʻo hoʻomanaʻo like me [`bool`].
///
/// **Note**: kēiaʻano mea loaʻa wale nō ma luna o paepae ai i kākoʻo'ātoma wahie, a me nā hale kūʻai o `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Hana i kahi `AtomicBool` i hoʻomaka mua ʻia i `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Hoʻonohonoho pono ʻia ʻo Send no AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ʻO kahi ʻano kuhikuhi maka maka hiki ke hoʻokaʻawale pono ʻia ma waena o nā pae.
///
/// Kēiaʻano i ka ia i loko o-iaiyoe e hoohalike me he `*mut T`.
///
/// **Kahakaha**: Aia wale kēia ʻano ma nā paepae e kākoʻo i nā ukana ʻtoma a me nā hale kūʻai o nā kuhikuhi.
/// Aia ka nui i ka nui o ka māka kuhikuhi.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Hana i kahi nul `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ʻĀina hoʻouka hoʻomanaʻo Atomic
///
/// Hoʻonohonoho nā hoʻonohonoho hoʻomanaʻo i ke ala o ka hana ʻana o nā atomic i ka hoʻomanaʻo.
/// I kāna [`Ordering::Relaxed`] nāwaliwali loa, hoʻopili wale ʻia ka memo e ka hana.
/// Ma ka lima ʻē aʻe, kahi pālua ukana o nā hana [`Ordering::SeqCst`] e lōkahi i nā hoʻomanaʻo ʻē aʻe me ka mālama pū ʻana i kahi hoʻonohonoho o ia ʻano hana ma nā pae āpau.
///
///
/// ʻO nā hoʻonohonoho hoʻomanaʻo hoʻomanaʻo Rust ʻo [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// No ka ʻike hou aku e ʻike i ka [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ʻAʻohe kaohi ʻana i nā kaohi, nā hana atomika wale nō.
    ///
    /// Kūlike i ka [`memory_order_relaxed`] ma C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Ke hui pū ʻia me kahi hale kūʻai, ua kauoha ʻia nā hana a pau ma mua o ka hoʻouka ʻana o kēia waiwai me ke kauoha [`Acquire`] (a ʻoi aku paha ka ikaika).
    ///
    /// Ma nā kikoʻī, ʻike ʻia nā kākau mua āpau i nā pae āpau e hana ana i kahi [`Acquire`] (a i ʻole ʻoi aku ka ikaika) o kēia waiwai.
    ///
    /// E hoʻomaopopo i ka hoʻohana ʻana i kēia ʻoka no kahi hana e hoʻohui i nā ukana a me nā hale kūʻai i alakaʻi i kahi hana hoʻouka [`Relaxed`]!
    ///
    /// Pili wale kēia kauoha no nā hana i hiki ke hana i kahi hale kūʻai.
    ///
    /// Kūlike i ka [`memory_order_release`] ma C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ke hoʻohui ʻia me kahi ukana, inā i kākau ʻia ka waiwai i hoʻouka ʻia e kahi hana hale kūʻai me [`Release`] (a ʻoi aku paha ka ikaika) e kauoha ana, a laila kauoha ʻia nā hana āpau ma hope o kēlā hale kūʻai.
    /// Eia kekahi, ʻo nā ukana a pau e ʻike i ka ʻikepili i kākau ʻia ma mua o ka hale kūʻai.
    ///
    /// E hoʻomaopopo i ka hoʻohana ʻana i kēia kauoha no kahi hana e hoʻohui i nā ukana a me nā hale kūʻai i alakaʻi i kahi hana hale kūʻai [`Relaxed`].
    ///
    /// Pili wale kēia hoʻonohonoho no nā hana i hiki ke hana i kahi ukana.
    ///
    /// Hoʻopili like ia [`memory_order_acquire`] ma C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Loaʻa nā hopena o ka [`Acquire`] a me ka [`Release`] pū.
    /// No nā ukana e hoʻohana ana i ka ʻoka ʻana [`Acquire`].No nā hale kūʻai hoʻohana ia i ka hoʻonohonoho [`Release`].
    ///
    /// Ka leka hoʻomaopopo i loko o ka hihia o `compare_and_swap`, he mea hiki i ka hana welau a i ole lawelawe i kekahi hale kūʻai, a ma keia hope aku ka mea, ua pono [`Acquire`] hoonoho papa.
    ///
    /// Eia nō naʻe, ʻaʻole e hana ʻo `AcqRel` i nā komo [`Relaxed`].
    ///
    /// Kēia hoonoho papa He pili wale no ka hana e hui pu iho nā wahie, a me nā papa kāwiliʻai.
    ///
    /// Kūlike i ka [`memory_order_acq_rel`] ma C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Like [`Acquire`]/[`Release`]/[`AcqRel`](no ka haawe, hale kūʻai, a me ka haawe ana-me-hale kūʻai ana, niioaaonoaaiii) me ka hou kumu hoʻomalu i nā pae ike a pau sequentially pahuhopu nei ana i loko o ka hookahi mea .
    ///
    ///
    /// Kūlike i ka [`memory_order_seq_cst`] ma C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// ʻO [`AtomicBool`] i hoʻomaka ʻia i `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// I ka mea hou `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka [`bool`] kumu.
    ///
    /// Palekana kēia ma muli o ka hoʻohuli ʻana o ka mutable e hōʻoia i ka loaʻa ʻole o nā pae ʻē aʻe i ke ʻikepili ʻtoma.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SAFETY: hōʻoia ka ʻōlelo kūmole i nā kuleana kū hoʻokahi.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// E kiʻi i ke kiʻi ʻtoma i kahi `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAFETY: ka hoʻohuli i ka mutable e hōʻoiaʻiʻo i ka ʻona kū hoʻokahi, a
        // ke kaulike o nā `bool` a me `Self` ka 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Pau i ka atomic a hoʻihoʻi i ka waiwai i loaʻa.
    ///
    /// Palekana kēia ma muli o ka hala ʻana o `self` e ka waiwai e hoʻohiki ai ʻaʻohe pae ʻē aʻe e komo pū ana i ka ʻikepili atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Hoʻouka i kahi waiwai mai ka bool.
    ///
    /// `load` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// ʻO [`SeqCst`], [`Acquire`] a me [`Relaxed`] paha nā waiwai i hiki.
    ///
    /// # Panics
    ///
    /// Panics inā `order` ʻo [`Release`] a [`AcqRel`] paha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SAFETY: pale ʻia kekahi mau lāhui ʻikepili e nā intricics atomic a me nā maka
        // pololei ka pointer i hala no ka mea ua loaʻa iā mākou mai kahi kūmole.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Kūʻai i kahi waiwai i loko o bool.
    ///
    /// `store` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// ʻO [`SeqCst`], [`Release`] a me [`Relaxed`] paha nā waiwai i hiki.
    ///
    /// # Panics
    ///
    /// Panics inā `order` ʻo [`Acquire`] a [`AcqRel`] paha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SAFETY: pale ʻia kekahi mau lāhui ʻikepili e nā intricics atomic a me nā maka
        // pololei ka pointer i hala no ka mea ua loaʻa iā mākou mai kahi kūmole.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Kūʻai i kahi waiwai i loko o bool, e hoʻihoʻi nei i ka waiwai i hala.
    ///
    /// `swap` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// E mālama i kahi waiwai i ka [`bool`] inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻO ka waiwai hoʻihoʻi ka waiwai mua.Inā like ia me `current`, a laila hōʻano hou ʻia ka waiwai.
    ///
    /// `compare_and_swap` lawe pū i kahi manaʻo [`Ordering`] e wehewehe ana i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// Hoʻomaopopo i ka wā e hoʻohana ana iā [`AcqRel`], e holo paha ka hana a no laila e hana wale i kahi `Acquire` ukana, akā ʻaʻohe `Release` semantics.
    /// Hoʻohana ka [`Acquire`] i ka hale kūʻai i kahi o kēia hana [`Relaxed`] inā kū, a me ka hoʻohana ʻana i [`Release`] e hana i ka ʻāpana [`Relaxed`].
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Ke neʻe nei i `compare_exchange` a me `compare_exchange_weak`
    ///
    /// `compare_and_swap` ua like ia me `compare_exchange` me kēia palapala ʻāina no nā ʻōkuhi hoʻomanaʻo.
    ///
    /// Kumu |Holomua |Hoka
    /// -------- | ------- | -------
    /// Hoʻomaha |nanea wale |Loaʻa Loaʻa |Loaʻa |Loaʻa Loaʻa Hoʻokuʻu |Hoʻokuʻu |Hoʻomaha AcqRel |AcqRel |Loaʻa iā SeqCst |SeqCst |ʻO SeqCst
    ///
    /// `compare_exchange_weak` Ua 'ae' ia pau spuriously a hiki i ka wa a ke hoʻohālike pani ihola ma hope, e leie aku ka compiler hiki paha ke maikaʻi anaina kanaka karaima ia ka hoohalike a me ka ua ia kuapo i loko o ka loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// E mālama i kahi waiwai i ka [`bool`] inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
    /// Ma ka kūleʻa e hōʻoia ʻia kēia waiwai e like me `current`.
    ///
    /// `compare_exchange` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
    /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
    ///
    /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// E mālama i kahi waiwai i ka [`bool`] inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻAʻole like me [`AtomicBool::compare_exchange`], ʻae ʻia kēia hana e holomua me ke kūleʻa ʻole o ka hoʻohālikelike ʻana, kahi e hopena ai i ke code ʻoi aku ka maikaʻi ma kekahi pae.
    ///
    /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
    ///
    /// `compare_exchange_weak` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
    /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
    /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ʻO Logical "and" me kahi waiwai boolean.
    ///
    /// Hana i kahi hana "and" logical ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
    ///
    /// Hoʻihoʻi i ka waiwai mua.
    ///
    /// `fetch_and` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// ʻO Logical "nand" me kahi waiwai boolean.
    ///
    /// Hana i kahi hana "nand" logical ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
    ///
    /// Hoʻihoʻi i ka waiwai mua.
    ///
    /// `fetch_nand` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ʻAʻole hiki iā mākou ke hoʻohana i ka atomic_nand ma aneʻi no ka mea hiki ke hopena i bool me kahi helu kūpono ʻole.
        // Hana ʻia kēia no ka hana ʻana o ka atomic me kahi integer 8-bit i loko, kahi e hoʻonohonoho ai i nā ʻāpana he 7.
        //
        // No laila hoʻohana wale mākou i fetch_xor a i ʻole kuapo ma kahi.
        if val {
            // ! (x&ʻoiaʻiʻo)== !x Pono mākou e hoʻohuli i ka bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&ʻole)==ʻoiae Pono mākou e hoʻonohonoho i ka bool i ka ʻoiaʻiʻo.
            //
            self.swap(true, order)
        }
    }

    /// ʻO Logical "or" me kahi waiwai boolean.
    ///
    /// Hana i kahi hana "or" logical ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
    ///
    /// Hoʻihoʻi i ka waiwai mua.
    ///
    /// `fetch_or` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// ʻO Logical "xor" me kahi waiwai boolean.
    ///
    /// Hana i kahi hana "xor" logical ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
    ///
    /// Hoʻihoʻi i ka waiwai mua.
    ///
    /// `fetch_xor` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Hoʻi he mutable laʻau kuhikuhi i ka hp'pnphp [`bool`].
    ///
    /// ʻO ka heluhelu ʻana i nā non-atomic heluhelu a kākau i ka helu i hiki ke lilo i heiheiʻikepili.
    /// ʻOi aku ka maikaʻi o kēia hana no FFI, kahi e hoʻohana ai ka pūlima inoa i ka `*mut bool` ma kahi o `&AtomicBool`.
    ///
    /// ʻO ka hoʻihoʻi ʻana i kahi kuhikuhi `*mut` mai kahi ʻāpana like i kēia atomic palekana no ka mea palekana nā ʻano atomic me ka mutability o loko.
    /// Hoʻololi nā hoʻololi āpau o kahi atika i ka waiwai ma o ka loiloi like, a hiki ke hana me ka palekana ke hoʻohana lākou i nā hana atomic.
    /// ʻO ka hoʻohana ʻana o ka pointer raw i hoʻihoʻi ʻia e koi ana i kahi poloka `unsafe` a mau nō naʻe e mālama i ka palena o ka palena like.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Loaʻa i ka waiwai, a pili i kahi hana iā ia e hoʻihoʻi i kahi waiwai hou koho.Hoʻihoʻi i kahi `Result` o `Ok(previous_value)` inā hoʻihoʻi ka hana iā `Some(_)`, a laila `Err(previous_value)`.
    ///
    /// Note: Kāhea paha kēia i ka hana i nā manawa he nui inā ua hoʻololi ʻia ka waiwai mai nā pae ʻē aʻe i kēia manawa, ʻoiai ke hoʻihoʻi ka hana i `Some(_)`, akā e hoʻopili ʻia ka hana i hoʻokahi wale nō i ka waiwai i mālama ʻia.
    ///
    ///
    /// `fetch_update` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// Hōʻike ka mea mua i ke kauoha i koi ʻia no ka wā e holo pono ai ka hana a ʻo ka lua e wehewehe i ke kauoha i koi ʻia no nā ukana.
    /// Kūlike kēia mau mea i ka kūleʻa a me nā hoʻonohonoho pono ʻole o [`AtomicBool::compare_exchange`] i kēlā me kēia.
    ///
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hana i ka hale kūʻai i kahi o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana i ka hopena hope loa [`Relaxed`].
    /// Ka (failed) haawe hoonoho papa hiki wale nō ia [`SeqCst`], [`Acquire`] a [`Relaxed`] a me ka pono e like no paha hemahema ma mua o ka pomaikai hoonoho papa.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Hana i kahi `AtomicPtr` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka kuhikuhi kuhikuhi.
    ///
    /// Palekana kēia ma muli o ka hoʻohuli ʻana o ka mutable e hōʻoia i ka loaʻa ʻole o nā pae ʻē aʻe i ke ʻikepili ʻtoma.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// E kiʻi i ke kiʻi ʻtoma i kahi kuhikuhi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - hōʻoia ka ʻōlelo kūmole i nā kuleana kū hoʻokahi.
        //  - ke kaulike o `*mut T` a me `Self` like ia ma nā paepae āpau i kākoʻo ʻia e rust, e like me ka mea i hōʻoia ʻia ma luna.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Pau i ka atomic a hoʻihoʻi i ka waiwai i loaʻa.
    ///
    /// Palekana kēia ma muli o ka hala ʻana o `self` e ka waiwai e hoʻohiki ai ʻaʻohe pae ʻē aʻe e komo pū ana i ka ʻikepili atomic.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Hoʻouka i kahi waiwai mai ka kuhikuhi.
    ///
    /// `load` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// ʻO [`SeqCst`], [`Acquire`] a me [`Relaxed`] paha nā waiwai i hiki.
    ///
    /// # Panics
    ///
    /// Panics inā `order` ʻo [`Release`] a [`AcqRel`] paha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// E mālama i kahi waiwai i ka kuhikuhi.
    ///
    /// `store` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// ʻO [`SeqCst`], [`Release`] a me [`Relaxed`] paha nā waiwai i hiki.
    ///
    /// # Panics
    ///
    /// Panics inā `order` ʻo [`Acquire`] a [`AcqRel`] paha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// E mālama i kahi waiwai i ka kuhikuhi, e hoʻihoʻi ana i ka waiwai i hala.
    ///
    /// `swap` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
    /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
    ///
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma nā pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// E mālama i kahi waiwai i ka pointer inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻO ka waiwai hoʻihoʻi ka waiwai mua.Inā like ia me `current`, a laila hōʻano hou ʻia ka waiwai.
    ///
    /// `compare_and_swap` lawe pū i kahi manaʻo [`Ordering`] e wehewehe ana i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// Hoʻomaopopo i ka wā e hoʻohana ana iā [`AcqRel`], e holo paha ka hana a no laila e hana wale i kahi `Acquire` ukana, akā ʻaʻohe `Release` semantics.
    /// Hoʻohana ka [`Acquire`] i ka hale kūʻai i kahi o kēia hana [`Relaxed`] inā kū, a me ka hoʻohana ʻana i [`Release`] e hana i ka ʻāpana [`Relaxed`].
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma nā pointers.
    ///
    /// # Ke neʻe nei i `compare_exchange` a me `compare_exchange_weak`
    ///
    /// `compare_and_swap` ua like ia me `compare_exchange` me kēia palapala ʻāina no nā ʻōkuhi hoʻomanaʻo.
    ///
    /// Kumu |Holomua |Hoka
    /// -------- | ------- | -------
    /// Hoʻomaha |nanea wale |Loaʻa Loaʻa |Loaʻa |Loaʻa Loaʻa Hoʻokuʻu |Hoʻokuʻu |Hoʻomaha AcqRel |AcqRel |Loaʻa iā SeqCst |SeqCst |ʻO SeqCst
    ///
    /// `compare_exchange_weak` Ua 'ae' ia pau spuriously a hiki i ka wa a ke hoʻohālike pani ihola ma hope, e leie aku ka compiler hiki paha ke maikaʻi anaina kanaka karaima ia ka hoohalike a me ka ua ia kuapo i loko o ka loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// E mālama i kahi waiwai i ka pointer inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
    /// Ma ka kūleʻa e hōʻoia ʻia kēia waiwai e like me `current`.
    ///
    /// `compare_exchange` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
    /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
    ///
    /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma nā pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// E mālama i kahi waiwai i ka pointer inā like ka waiwai o kēia manawa me ka `current` waiwai.
    ///
    /// ʻAʻole like me [`AtomicPtr::compare_exchange`], ʻae ʻia kēia hana e holomua me ke kūleʻa ʻole o ka hoʻohālikelike ʻana, kahi e hopena ai i ke code ʻoi aku ka maikaʻi ma kekahi pae.
    ///
    /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
    ///
    /// `compare_exchange_weak` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
    /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
    /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma nā pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: Palekana ʻole kēia intrinsic no ka mea e holo ana ia ma kahi kuhikuhi pono
        // akā, ua ike no kaʻoiaʻiʻo i ka laʻau kuhikuhi mea i pololei ia (mākou e loaa ia ia mai ka `UnsafeCell` ia mākou i ka kūmole) a me ka'ātoma hana iho e leie aku iā mākou i ka maluhia mutate i ka `UnsafeCell` Contents.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Loaʻa i ka waiwai, a pili i kahi hana iā ia e hoʻihoʻi i kahi waiwai hou koho.Hoʻihoʻi i kahi `Result` o `Ok(previous_value)` inā hoʻihoʻi ka hana iā `Some(_)`, a laila `Err(previous_value)`.
    ///
    /// Note: Kāhea paha kēia i ka hana i nā manawa he nui inā ua hoʻololi ʻia ka waiwai mai nā pae ʻē aʻe i kēia manawa, ʻoiai ke hoʻihoʻi ka hana i `Some(_)`, akā e hoʻopili ʻia ka hana i hoʻokahi wale nō i ka waiwai i mālama ʻia.
    ///
    ///
    /// `fetch_update` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
    /// Hōʻike ka mea mua i ke kauoha i koi ʻia no ka wā e holo pono ai ka hana a ʻo ka lua e wehewehe i ke kauoha i koi ʻia no nā ukana.
    /// Kūlike kēia mau mea i ka kūleʻa a me nā hoʻonohonoho pono ʻole o [`AtomicPtr::compare_exchange`] i kēlā me kēia.
    ///
    /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hana i ka hale kūʻai i kahi o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana i ka hopena hope loa [`Relaxed`].
    /// Ka (failed) haawe hoonoho papa hiki wale nō ia [`SeqCst`], [`Acquire`] a [`Relaxed`] a me ka pono e like no paha hemahema ma mua o ka pomaikai hoonoho papa.
    ///
    /// **Note:** Loaʻa kēia hana ma nā paepae e kākoʻo i nā hana atomic ma nā pointers.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Hoʻohuli i `bool` i `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Pau ʻole kēia makona i hoʻohana ʻole ʻia ma kekahi mau kālai hale.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ʻO kahi ʻano helu hiki ke kaʻana like ʻia ma waena o nā pae.
        ///
        /// Loaʻa i kēia ʻano ke ʻano hoʻomanaʻo hoʻomanaʻo i loko o ke ʻano o ka integer type, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// No ka hou e pili ana i na oko ma waena o'ātoma ano a me ka 'ole-'ātoma ano like nō hoʻi me ka' ike e pili ana i ka portability o kēia 'ano, e ike i ka [module-level documentation].
        ///
        ///
        /// **Note:** Aia wale nō kēia ʻano ma nā paepae e kākoʻo i nā ukana ʻtoma a me nā hale kūʻai o ['
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Hoʻomaka ʻia kahi helu aniani i `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Hoʻohana pili pono ʻia ka hoʻouna ʻana.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Hoʻokumu i ka helu helu atomic hou.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// E hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i ka integer o lalo.
            ///
            /// Palekana kēia ma muli o ka hoʻohuli ʻana o ka mutable e hōʻoia i ka loaʻa ʻole o nā pae ʻē aʻe i ke ʻikepili ʻtoma.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// e mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - hōʻoia ka ʻōlelo kūmole i nā kuleana kū hoʻokahi.
                //  - ke kaulike o `$int_type` a me `Self` like, e like me ka mea i hoʻohiki ʻia e $cfg_align a hōʻoia ʻia ma luna.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Pau i ka atomic a hoʻihoʻi i ka waiwai i loaʻa.
            ///
            /// Palekana kēia ma muli o ka hala ʻana o `self` e ka waiwai e hoʻohiki ai ʻaʻohe pae ʻē aʻe e komo pū ana i ka ʻikepili atomic.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Hoʻouka i kahi waiwai mai ka helu o ka atom.
            ///
            /// `load` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            /// ʻO [`SeqCst`], [`Acquire`] a me [`Relaxed`] paha nā waiwai i hiki.
            ///
            /// # Panics
            ///
            /// Panics inā `order` ʻo [`Release`] a [`AcqRel`] paha.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Mālama i kahi waiwai i loko o ka helu helu ʻtoma.
            ///
            /// `store` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            ///  ʻO [`SeqCst`], [`Release`] a me [`Relaxed`] paha nā waiwai i hiki.
            ///
            /// # Panics
            ///
            /// Panics inā `order` ʻo [`Acquire`] a [`AcqRel`] paha.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// E mālama ana i kahi waiwai i loko o ka helu helu ʻtoma, e hoʻihoʻi ana i ka waiwai mua.
            ///
            /// `swap` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// E mālama i kahi waiwai i loko o ka helu o nā atomika inā like ka waiwai o kēia manawa me ka `current` waiwai.
            ///
            /// ʻO ka waiwai hoʻihoʻi ka waiwai mua.Inā like ia me `current`, a laila hōʻano hou ʻia ka waiwai.
            ///
            /// `compare_and_swap` lawe pū i kahi manaʻo [`Ordering`] e wehewehe ana i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            /// Hoʻomaopopo i ka wā e hoʻohana ana iā [`AcqRel`], e holo paha ka hana a no laila e hana wale i kahi `Acquire` ukana, akā ʻaʻohe `Release` semantics.
            ///
            /// Hoʻohana ka [`Acquire`] i ka hale kūʻai i kahi o kēia hana [`Relaxed`] inā kū, a me ka hoʻohana ʻana i [`Release`] e hana i ka ʻāpana [`Relaxed`].
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Ke neʻe nei i `compare_exchange` a me `compare_exchange_weak`
            ///
            /// `compare_and_swap` ua like ia me `compare_exchange` me kēia palapala ʻāina no nā ʻōkuhi hoʻomanaʻo.
            ///
            /// Kumu |Holomua |Hoka
            /// -------- | ------- | -------
            /// Hoʻomaha |nanea wale |Loaʻa Loaʻa |Loaʻa |Loaʻa Loaʻa Hoʻokuʻu |Hoʻokuʻu |Hoʻomaha AcqRel |AcqRel |Loaʻa iā SeqCst |SeqCst |ʻO SeqCst
            ///
            /// `compare_exchange_weak` Ua 'ae' ia pau spuriously a hiki i ka wa a ke hoʻohālike pani ihola ma hope, e leie aku ka compiler hiki paha ke maikaʻi anaina kanaka karaima ia ka hoohalike a me ka ua ia kuapo i loko o ka loop.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// E mālama i kahi waiwai i loko o ka helu o nā atomika inā like ka waiwai o kēia manawa me ka `current` waiwai.
            ///
            /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
            /// Ma ka kūleʻa e hōʻoia ʻia kēia waiwai e like me `current`.
            ///
            /// `compare_exchange` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
            /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
            /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
            ///
            /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// E mālama i kahi waiwai i loko o ka helu o nā atomika inā like ka waiwai o kēia manawa me ka `current` waiwai.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// keia kuleana pili i ua 'ae' ia spuriously pau a hiki i ka wā o ka hoʻohālike ka holomua 'ana, a hiki ka hopena i oi efficient kivila ma kekahi mau paepae ai.
            /// ʻO ke kumu kūʻai hoʻihoʻi kahi hopena e hōʻike ana inā ua kākau ʻia ka waiwai hou a loaʻa ka waiwai i hala.
            ///
            /// `compare_exchange_weak` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            /// `success` wehewehe i ke kauoha e koi ʻia ana no ka hana heluhelu-hoʻololi-kākau e kū ana inā kū ka hoʻohālikelike me `current`.
            /// `failure` wehewehe i ke kauoha e koi ʻia ana no ka hana hoʻoili e hana ana ke holo ʻole ka hoʻohālikelike.
            /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka [`Relaxed`] ukana holomua.
            ///
            /// Hiki i ka ʻoka ʻole ke [`SeqCst`], [`Acquire`] a i ʻole [`Relaxed`] a pono e like a i ʻole nāwaliwali ma mua o ke kūleʻa ʻana.
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// e mut kahiko= val.load(Ordering::Relaxed);
            /// loop {e hou=kahiko * 2;
            ///     hoʻokūkū i val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Hoʻohui i ka waiwai o kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
            ///
            /// Hoʻopuni kēia hana a puni i ka kahawai.
            ///
            /// `fetch_add` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Lawe ʻia nā waiwai mai kēia manawa, e hoʻihoʻi nei i ka waiwai mua.
            ///
            /// Hoʻopuni kēia hana a puni i ka kahawai.
            ///
            /// `fetch_sub` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// ʻO Bitwise "and" me ka waiwai o kēia manawa.
            ///
            /// Hana i kahi hana "and" bitwise ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_and` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// ʻO Bitwise "nand" me ka waiwai o kēia manawa.
            ///
            /// Hana i kahi hana "nand" bitwise ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_nand` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// ʻO Bitwise "or" me ka waiwai o kēia manawa.
            ///
            /// Hana i kahi hana "or" bitwise ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_or` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// ʻO Bitwise "xor" me ka waiwai o kēia manawa.
            ///
            /// Hana i kahi hana "xor" bitwise ma ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_xor` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Loaʻa i ka waiwai, a pili i kahi hana iā ia e hoʻihoʻi i kahi waiwai hou koho.Hoʻihoʻi i kahi `Result` o `Ok(previous_value)` inā hoʻihoʻi ka hana iā `Some(_)`, a laila `Err(previous_value)`.
            ///
            /// Note: Kāhea paha kēia i ka hana i nā manawa he nui inā ua hoʻololi ʻia ka waiwai mai nā pae ʻē aʻe i kēia manawa, ʻoiai ke hoʻihoʻi ka hana i `Some(_)`, akā e hoʻopili ʻia ka hana i hoʻokahi wale nō i ka waiwai i mālama ʻia.
            ///
            ///
            /// `fetch_update` lawe i nā paio [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.
            /// Hōʻike ka mea mua i ke kauoha i koi ʻia no ka wā e holo pono ai ka hana a ʻo ka lua e wehewehe i ke kauoha i koi ʻia no nā ukana.Kūlike kēia mau mea i ke kūleʻa a me ka hoʻonohonoho pono ʻole o
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Ke hoʻohana nei iā [`Acquire`] e like me ke kauoha kūleʻa e hana i ka hale kūʻai i kahi o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana i ka hopena hope loa [`Relaxed`].
            /// Ka (failed) haawe hoonoho papa hiki wale nō ia [`SeqCst`], [`Acquire`] a [`Relaxed`] a me ka pono e like no paha hemahema ma mua o ka pomaikai hoonoho papa.
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (ka hoʻouka i: : SeqCst, Ordering::SeqCst, |! m | Some(x + 1)), Ok(7));
            /// assert_eq (x.fetch_update (ka hoʻouka i: : SeqCst, Ordering::SeqCst, |! m | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// I kā mākou i kaʻikena cia.
            ///
            /// ʻIke i ka nui o ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_max` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// hoʻokuʻu pā=42;
            /// e max_foo=foo.fetch_max (pa, Ordering::SeqCst).max(bar);
            /// e hoʻokūpaʻa! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Ka liʻiliʻi me ka waiwai o kēia manawa.
            ///
            /// ʻIke i ka palena iki o ka waiwai o kēia manawa a me ka hoʻopaʻapaʻa `val`, a hoʻonohonoho i ka waiwai hou i ka hopena.
            ///
            /// Hoʻihoʻi i ka waiwai mua.
            ///
            /// `fetch_min` lawe i kahi manaʻo [`Ordering`] e wehewehe i ka hoʻonohonoho hoʻomanaʻo ʻana o kēia hana.e hiki All hoonoho papa 'ole.
            /// E hoʻomaopopo i ka hoʻohana ʻana iā [`Acquire`] e hoʻolilo i ka hale kūʻai i ʻāpana o kēia hana [`Relaxed`], a me ka hoʻohana ʻana i [`Release`] e hana ai i ka ʻāpana [`Relaxed`].
            ///
            ///
            /// **Kahakaha**: Loaʻa kēia ala ma nā paepae e kākoʻo i nā hana atomic ma
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// hoʻokuʻu pā=12;
            /// let min_foo=foo.fetch_min (pā, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: pale ʻia nā lāhui ʻikepili e nā intricics atomic.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// E hoʻihoʻi i kahi kuhikuhi kuhi i ka integer o lalo.
            ///
            /// ʻO ka heluhelu ʻana i nā non-atomic heluhelu a kākau i ka helu i hiki ke lilo i heiheiʻikepili.
            /// ʻOi aku ka maikaʻi o kēia hana no FFI, kahi e hoʻohana ai i ka pūlima hana
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ʻO ka hoʻihoʻi ʻana i kahi kuhikuhi `*mut` mai kahi ʻāpana like i kēia atomic palekana no ka mea palekana nā ʻano atomic me ka mutability o loko.
            /// Hoʻololi nā hoʻololi āpau o kahi atika i ka waiwai ma o ka loiloi like, a hiki ke hana me ka palekana ke hoʻohana lākou i nā hana atomic.
            /// ʻO ka hoʻohana ʻana o ka pointer raw i hoʻihoʻi ʻia e koi ana i kahi poloka `unsafe` a mau nō naʻe e mālama i ka palena o ka palena like.
            ///
            ///
            /// # Examples
            ///
            /// `` nānā (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// waho "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SAFETY: Palekana ʻoiai ʻo `my_atomic_op` he atomic.
            /// maikaʻi ʻole {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Hoʻihoʻi i ka waiwai mua (e like __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Hoʻihoʻi i ka waiwai ma mua (e like me __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Ka maluhia: o ka Caller pono kākoʻo i ka maluhia aelike no `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// hoʻihoʻi i ka waiwai max (hoʻohālikelike ʻia)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// hoʻihoʻi i ka waiwai min (hoʻohālikelike ʻia)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// hoʻihoʻi i ka waiwai max (hoʻohālikelike inoa ʻole)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// hoʻihoʻi i ka waiwai min (hoʻohālikelike ʻole ʻia)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// He pā atomic.
///
/// Kaukaʻi ʻia i ka ʻoka kikoʻī, pale ka pā i ka mea hoʻopili a me ka CPU mai ka hoʻonohonoho hou ʻana i kekahi ʻano o nā hana hoʻomanaʻo a puni iā ia.
/// Hana kēlā i nā synchronises-me nā pilina ma waena o ia a me nā hana atomic a i ʻole nā pā i nā pae ʻē aʻe.
///
/// A pa 'A' i mea (ma ka liʻiliʻi) [`Release`] hoonoho papa semantics, synchronizes me ka pa 'B' me (ma ka liʻiliʻi) [`Acquire`] semantics, ina a wale ina he like paha i kahi hana X a me Y, nā pae'ōnaehana ma kekahi'ātoma mea 'M' ia i A ua kaʻina mua Hoʻohui pū ʻia ʻo X, Y ma mua o ka ʻike ʻana o B a me Y i ka loli iā M.
/// Hāʻawi kēia i kahi hanana-ma mua o ka hilinaʻi ma waena o A a me B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Hiki ke hoʻopili pū ʻia nā hana Atomic me [`Release`] a i ʻole [`Acquire`] semantics me kahi pā.
///
/// ʻO kahi pā i loaʻa iā [`SeqCst`] e kauoha ana, me ka hoʻohui ʻana i ka [`Acquire`] a me ka [`Release`] semantics, komo pū i ka papahana papahana honua o nā hana [`SeqCst`] ʻē aʻe a me/a i ʻole nā pā.
///
/// ʻAe i ka ʻokaʻina [`Acquire`], [`Release`], [`AcqRel`] a me [`SeqCst`].
///
/// # Panics
///
/// Panics inā `order` ʻo [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ʻO ka primitive exclusification mutual based on spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // E kali a hiki i ka waiwai kahiko `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Hoʻopili like kēia pā-me ka hale kūʻai ma `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SAFETY: palekana ka hoʻohana ʻana i ka pā atomika.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// He pā hoʻomanaʻo hoʻomanaʻo.
///
/// `compiler_fence` ʻaʻole ia e hoʻokuʻu i kekahi code mīkini, akā pāpā i nā ʻano o ka hoʻomanaʻo hou ʻana i ka hoʻonohonoho ʻana e ʻae ʻia ka mea hoʻopili.ʻO ke kikoʻī, ke kaukaʻi ʻia nei i nā semantics [`Ordering`] i hāʻawi ʻia, e ʻae ʻia paha ka mea hoʻopili mai ka neʻe ʻana i nā heluhelu a i ʻole ke kākau ʻana ma mua a ma hope paha o ke kāhea ʻana i kekahi ʻaoʻao o ke kāhea iā `compiler_fence`.Hoʻomaopopo ʻaʻole **e** ālai i ka *lako pono* mai ka hana ʻana i kēlā ʻano hoʻonohonoho ʻana.
///
/// Kēia mea,ʻaʻole he pilikia i loko o ka hookahi-wili, hooko pōʻaiapili, akā, ka wā 'ē aʻe pae paha e hoʻololi iaiyoe i ka ia manawa, ua koi ikaika hoʻononiakahi primitives e like me [`fence`].
///
/// Ka hou-hoonoho papa Hāʻule maila lākou ma kaʻokoʻa hoonoho papa semantics i:
///
///  - me [`SeqCst`], ʻaʻohe hoʻonohonoho hou ʻana i nā heluhelu a kākau ma o kēia kiko i ʻae ʻia.
///  - me [`Release`], heluhelu ma mua a ʻaʻole hiki ke neʻe i nā kākau ma mua o nā kākau aʻe.
///  - me [`Acquire`], nā heluhelu aʻe a ʻaʻole hiki ke neʻe i nā kākau ma mua o nā heluhelu i hala.
///  - me [`AcqRel`], ua hoʻokō ʻia nā kānāwai ʻelua i luna.
///
/// `compiler_fence` he mea pono wale nō no ka pale ʻana i kahi pae mai ka heihei *me iā ia iho*.ʻO ia, inā e hana ana kahi pae i hoʻokahi ʻāpana o ke code, a laila hoʻopau ʻia, a hoʻomaka i ka hoʻokō ʻana i ke code ma kahi ʻē aʻe (ʻoiai e paʻa ana i ka pae like, a me ka manaʻo like ma ke kumu like.Ma ku una papa hana, ua hiki wale nō i hoʻomaka ai ka wā i hōʻailona handler ua kakau.
/// I ke code pae haʻahaʻa ʻoi aku ka liʻiliʻi, hiki ke kū aʻe i kēlā mau hanana ke mālama i nā mea keʻakeʻa, ke hoʻokō nei i nā pae ʻōmaʻomaʻo me ka hana mua, a pēlā aku.
/// Hana heluhelu i hooluoluia mai ai e heluhelu i ka Linux Kernel ka kūkākūkā o [memory barriers].
///
/// # Panics
///
/// Panics inā `order` ʻo [`Relaxed`].
///
/// # Examples
///
/// Me `compiler_fence`, ka `assert_eq!` ma hope o ka pāʻālua ʻaʻole * hōʻoia ʻia e kūleʻa, ʻoiai ʻo nā mea āpau e hana ana i kahi pae.
/// E ʻike ai i ke kumu, e hoʻomanaʻo i ka manuahi ka mea hoʻopili e hoʻololi i nā hale kūʻai iā `IMPORTANT_VARIABLE` a me `IS_READ` ʻoiai he `Ordering::Relaxed` lāua.Inā hana ia, a kāhea ʻia ka mea lawe lima hōʻailona ma hope pono o `IS_READY` hōʻano hou, a laila e ʻike ka mea lawe lima iā `IS_READY=1`, akā `IMPORTANT_VARIABLE=0`.
/// Ke hoʻohana nei i kahi `compiler_fence` hoʻoponopono i kēia kūlana.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // pale i nā kākau mua mai ka neʻe ʻana ma ʻō aku o kēia kiko
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SAFETY: palekana ka hoʻohana ʻana i ka pā atomika.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Hōʻailona nā mea unu lawelawe aia ia i loko o kahi rot-wait spin-loop ("spin lock").
///
/// Hoʻopau ʻia kēia hana ma ka ʻaoʻao o [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}