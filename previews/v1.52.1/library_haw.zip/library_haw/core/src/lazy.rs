//! Nā loina palaualelo a me ka manawa hoʻokahi o ka hoʻomaka ʻana o ka ʻikepili kūpaʻa.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Kele e hiki ke kākau ʻia i hoʻokahi wale nō manawa.
///
/// Haʻalele `RefCell`, he `OnceCell` wale hoakaka i kaʻana like `&T` i maopopo nä haumäna i kona mea.
/// ʻAʻole like me `Cell`, ʻaʻole koi ka `OnceCell` i ke kope a i ʻole ka hoʻololi ʻana i ka waiwai e komo ai.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: palapala ia ma ka hapanui koke.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// I ka mea hou nele halepaahao.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Loaʻa i ka pili a hiki i ka nń ku cia.
    ///
    /// Huli `None` ina ka halepaahao mea nele.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // Maluhia: maluhia ma muli o ka 'inner` ka invariant
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Loaʻa ka mutable pili i ka nń ku cia.
    ///
    /// Huli `None` ina ka halepaahao mea nele.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // Maluhia: maluhia no ka mea, ua kū hoʻokahi ka hookipaia
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Nā pūʻulu kahi o ka halepaahao i `value`.
    ///
    /// # Errors
    ///
    /// Hoʻihoʻi kēia ala i `Ok(())` inā hakahaka ka pūnaewele a me `Err(value)` inā piha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SAFETY: palekana no ka mea ʻaʻole hiki iā mākou ke loaʻa nā ʻaiʻē e hiki ke hoʻopili ʻia
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAFETY: ʻO kēia wale nō kahi e hoʻonohonoho ai mākou i ka slot, ʻaʻohe heihei
        // ma muli o reentrancy/concurrency hiki, a ua nānā mākou i kēia manawa `None` i kēia manawa, no laila ke mālama nei kēia kākau i ka invariant o ka ʻaoʻao i loko.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Loaʻa i nā ʻike o ke kolamu, ke hoʻomaka ʻana me `f` inā hakahaka ka pūnaewele.
    ///
    /// # Panics
    ///
    /// Inā `f` panics, ka panic ua hoʻopulapula i ka Caller, a me ka halepaahao noho uninitialized.
    ///
    ///
    /// He he hewa e reentrantly initialize i ka halepaahao mai `f`.Hana no laila, hualoaʻa ma ka panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Loaʻa i nā ʻike o ke kolamu, ke hoʻomaka ʻana me `f` inā hakahaka ka pūnaewele.
    /// Inā ka halepaahao ua kaawale, a `f` nele, ua hoʻi i ka hewa.
    ///
    /// # Panics
    ///
    /// Inā `f` panics, ka panic ua hoʻopulapula i ka Caller, a me ka halepaahao noho uninitialized.
    ///
    ///
    /// He he hewa e reentrantly initialize i ka halepaahao mai `f`.Hana no laila, hualoaʻa ma ka panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Note e *kekahi* ano o reentrant initialization ke alakai i UB (ike `reentrant_init` ho'āʻo).
        // I manaoio i pono hoonee keia `assert`, oiai e malama ana `set/get` makemake e kani, akā, e pono e aho ia panic, aole i ma mua o ka hāmau hoʻohana i kahiko cia.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// I pau ai i ka halepaahao, hoi mai i ka wahi waiwai.
    ///
    /// Huli `None` ina ka halepaahao ua kaawale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // No ka mea, `into_inner` lawe `self` ma ka waiwai, i ka compiler statically verifies i ka mea, ua ole a ianoiyuaa a aie.
        // Pela ka mea, he pomaikai, e neʻe mai `Option<T>`.
        self.inner.into_inner()
    }

    /// Lawe i ka waiwai mai kēia `OnceCell`, hoʻoneʻe iā ia i kahi kūlana uninitialized.
    ///
    /// Aohe like me ia, a huli `None` ina ka `OnceCell` i ole, ua initialized.
    ///
    /// Hōʻoiaʻiʻo ʻia ka palekana e ke koi ʻana i kahi kuhikuhi e hiki ai ke hoʻololi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ʻO kahi waiwai i hoʻomaka mua ʻia ma ke kiʻi mua.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   makaukau initializing
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Hoʻokumu i kahi waiwai palaualelo hou me ka hana initializing i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Koa a pau i ka loiloi 'ana o kēia palaualelo waiwai, a hoi mai i ka pili a hiki i ka hopena.
    ///
    ///
    /// Kēia mea like i ka `Deref` impl, akā, he pelapela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// I ka mea hou palaualelo cia hoʻohana `Default` like me ka initializing kuleana pili i.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}