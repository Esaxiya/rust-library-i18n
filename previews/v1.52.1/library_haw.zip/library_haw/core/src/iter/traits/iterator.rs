// kāpae'ōlelo-tidy-filelength kēia waihona kokoke wale nō he o ka ho'ākāka 'ana o `Iterator`.
// Mākou hiki ole Wāwahi i loko o mau AEIU.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// An mau 'no ka Hana me iterators.
///
/// 'O kēia ka papa kuhikuhiE iterator trait.
/// No ka hou e pili ana i ka manaʻo o nā iterators nui, e ike i ka [module-level documentation].
/// Ma kekahi, oe i makemake e ike pehea i [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ʻO ke ʻano o nā mea i hoʻoiho ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// E hana 'ia ka iterator, a huli i ka kekahi cia.
    ///
    /// Hoʻi [`None`] ka wā iteration ua pau.
    /// Kanaka iterator implementations e koho i ka hoʻomau 'iteration, a no laila, kahea `next()` hou e paha e ole e ho'ōla hoʻomaka hoi [`Some(Item)`] hou ma kekahi mau wahi.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Hoʻihoʻi kahi kāhea iā next() i ka waiwai aʻe ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... a laila None koke ka mea, Aloha no.
    /// assert_eq!(None, iter.next());
    ///
    /// // More kāhea aku a ke hiki 'ole paha,ʻaʻole hoʻi `None`.Eia, ka mea mau e.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Huli i ka palena ma ka lōʻihi o ka iterator i koe.
    ///
    /// Ua hōʻike hewa, `size_hint()`, hoi mai i ka tuple kahi o ka mua hehee ai o ka lalo nakinaki aku la ia, a me ka lua o ka hehee ai o ka luna e paa ana.
    ///
    /// I ka lua o ka hapalua o ka tuple i ua hoʻi mea he ['Option`]' <'[' usize`] '>'.
    /// A [`None`] ʻaneʻi mea i kekahi ole ma laila ua ike keena e paa ana, a me na luna e paa ana ka nui ma mua o [`usize`].
    ///
    /// # Nā memo hoʻokō
    ///
    /// ʻAʻole ia e hoʻokō ʻia i kahi hoʻokō iterator e hāʻawi ai i ka helu o nā mea i haʻi ʻia.A buggy iterator e hoohua emi ma mua o ka lalo me ka paa, a oi ma mua o ka luna e paa ana o ka oihana mua.
    ///
    /// `size_hint()` ua kuhikuhi manaoia e e hoʻohana no ka optimizations e like me koe wa no na kumu o ka iterator, akā, pono ole e hilinaʻi i IAOEIAaO, omit iho i pale a loaʻa, e kaha i ka unsafe kivila.
    /// An pololei ole manaʻo o `size_hint()` e ole e alakai i ka iaiyoe palekana 'aʻe'.
    ///
    /// ʻO kēlā i ʻōlelo ʻia, pono i ka hoʻokō ʻana e hāʻawi i kahi kuhi kūpono, no ka mea inā ʻaʻole ia he mea hōʻeha i ka protocol o trait.
    ///
    /// Ka paʻamau manaʻo hoike `(0,` ['None`]') 'i mea pololei no kekahi iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ʻO kahi laʻana ʻoi aku ka paʻakikī:
    ///
    /// ```
    /// // ʻO nā helu kaulike mai ka ʻole a i ka ʻumi.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mākou e iterate mai Aʻohe hiki i ka umi manawa.
    /// // Ke ʻike nei ʻaʻole hiki ke loaʻa ʻelima mau kikoʻī ke ʻole ka hoʻokō ʻana iā filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // E hoʻohui i nā helu hou ʻelima me chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // kēia manawa, ua hoʻonuiʻia nā palena ma ka elima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// A hoʻi hou aʻela `None` no kekahi keena paa ai.
    ///
    /// ```
    /// // he mana loa iterator i ole luna, me ka paa, a me ka i kā mākou hiki lalo ua nakiiia ma na
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// I pau ai ka iterator, helu i ka helu ana o iterations, a hoi mai ia.
    ///
    /// E kāhea pinepine kēia hana iā [`next`] a hiki i ka manawa e loaʻa ai iā [`None`], e hoʻihoʻi nei i ka helu o nā manawa i ʻike ai iā [`Some`].
    /// E hoʻomaopopo he pono e kāhea ʻia ʻo [`next`] ma ka liʻiliʻi i hoʻokahi manawa inā ʻaʻohe o nā mea i ka iterator.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # hoʻohālana hana
    ///
    /// Ka papa hana i ole e ku e kiai iho la e hālanaʻia, no laila, helu oihana mua o ka iterator me ka oi ma mua o [`usize::MAX`] hehee wale kekahi produces ka hewa hopena paha panics.
    ///
    /// Inā debug assertions i 'ā, he panic ua ua hoʻohiki.
    ///
    /// # Panics
    ///
    /// ʻO panic kēia hana inā ʻoi aku ma mua o ka [`usize::MAX`] mau mea ka mea iterator.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Pau ka iterator, hoʻihoʻi i ka mea hope loa.
    ///
    /// Kēia hana, e loiloi i ka iterator a ka mea i hoi mai [`None`].
    /// ʻOiai e hana ana pēlā, mālama ia i ka mea o kēia wā.
    /// [`None`] ua hoʻi mai ma hope, `last()` e laila, e hoʻi i ka hope hehee ai ia i ike ai.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// E hana 'ia ka iterator ma `n` hehee wale.
    ///
    /// Kēia hana, e eagerly skip `n` nā kumumea ma ke kahea [`next`] i ke `n` manawa a [`None`] ua pilikia.
    ///
    /// `advance_by(n)` E hoʻi [`Ok(())`][Ok] ina ka iterator ana E hana 'ia ma `n` hehee wale, a [`Err(k)`][Err] ina [`None`] ua pilikia, kahi `k` o ka helu ana o hehee wale ka iterator ka holomua ma mua holo ana o ka oihana mua (' o ia hoʻi
    /// ka lōʻihi o ka iterator).
    /// E hoʻomaopopo he emi mau ka `k` ma mua o `n`.
    ///
    /// Kahea `advance_by(0)` aʻole e hoopau ia i kekahi kumu, a mau loa, e huli hou [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // wale `&4` Ua skipped
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Hoike i ka `n`th hehee ai o ka iterator.
    ///
    /// Like loa hōʻinideka 'ana, ka huina hoomaka mai Aʻohe, no laila, `nth(0)` huli ke kumukuai mua, `nth(1)` ka lua, a no laila, ma luna o.
    ///
    /// Note i pau mua hehee wale, e like me ka mea hoi mai hehee ai, e hoʻopauʻia, mai ka iterator.
    /// Ia mea i ka mua o hehee wale, e e kāpaeʻia, a me nā pū e kahea `nth(0)` mau manawa ma ka ia iterator, e hoʻi kekahi mau oihana mua.
    ///
    ///
    /// `nth()` E hoʻi [`None`] ina `n`, ua oi aku ma mua o paha e like me ka lōʻihi o ka iterator.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ke kāhea nei iā `nth()` i nā manawa he nui ʻaʻole hoʻi ia i ka iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Ke hoʻihoʻi nei iā `None` inā aia ma lalo o `n + 1` mau mea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Hana i mea iterator e hoʻomaka ana i ka ia wahi, akā, hehi ma ka haawi dala ma kēlā me kēia iteration.
    ///
    /// Note 1: Ka mua hehee ai o ka iterator, e mau e hoi mai, nānā 'ole o kaʻanuʻu i haawiia mai.
    ///
    /// Note 2: Ka manawa i i AOON oihana mua i huki ua i paa.
    /// `StepBy` hoi e like me ka ke kaʻina, `next(), nth(step-1), nth(step-1),…`, akā, ka i noa ke hele e like me ka ke kaʻina,
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Ma ka ÿaoÿao hea ua hoʻohana 'ia e hoʻololi i kekahi iterators no ka lawelawe kumu.
    /// ʻO ke ala ʻelua e mua i ka iterator ma mua a hoʻopau paha i nā mea hou aku.
    ///
    /// `advance_n_and_return_first` ka mea like o:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// I ka papa hana e panic ina ka haawiʻanuʻu o `0`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Lawe i ʻelua mau iterator a hana i kahi iterator hou ma luna o nā mea ʻelua i ke kaʻina.
    ///
    /// `chain()` e hoʻihoʻi i kahi iterator hou e iterate mua ma luna o nā waiwai mai ka iterator mua a laila ma luna o nā kumukūʻai mai ka lua o ka iterator.
    ///
    /// I nā huaʻōlelo ʻē aʻe, hoʻopili ia i ʻelua mau iterator pū, i kahi kaulahao.🔗
    ///
    /// [`once`] Hoʻohana mau ʻia e hoʻololi i hoʻokahi waiwai i loko o ke kaulahao o nā ʻano ʻē aʻe.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mai ka manaʻo hoʻopiʻi kū'ē i `chain()` hoʻohana [`IntoIterator`], ua hiki ke hele i kekahi mea e hiki ke hoohuliia mai i loko o ka [`Iterator`],ʻaʻole like ka [`Iterator`] iho.
    /// ʻO kahi laʻana, hoʻopili nā (`&[T]`) i nā [`IntoIterator`], a no laila hiki ke hoʻoili pololei ʻia iā `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Inā e hana me Windows API, oe e makemake, e hoohuli [`OsStr`] i `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Amelika a helu kuhi mai' mau iterators i loko o ka hookahi iterator o ka hui.
    ///
    /// `zip()` hoike i ka hou iterator mea e iterate ma luna o nā 'ē aʻe iterators, hoi mai i ka tuple kahi o ka mua hehee ai mai, mai ka iterator mua, a me ka lua o ka hehee ai mai loko mai o ka lua o ka iterator.
    ///
    ///
    /// Ma na olelo e ae, ia Amelika a helu kuhi mau iterators pu, i loko o ka hoʻokahi kekahi.
    ///
    /// Inā kekahi iterator huli [`None`], [`next`] mai ka zipped iterator e hoʻi [`None`].
    /// Inā hoʻihoʻi ka iterator mua iā [`None`], e pōkole ʻo `zip` a ʻaʻole e kāhea ʻia ʻo `next` i ka iterator ʻelua.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mai ka manaʻo hoʻopiʻi kū'ē i `zip()` hoʻohana [`IntoIterator`], ua hiki ke hele i kekahi mea e hiki ke hoohuliia mai i loko o ka [`Iterator`],ʻaʻole like ka [`Iterator`] iho.
    /// No ka laʻana, slices (`&[T]`) hoʻokō [`IntoIterator`], a no laila, hiki ke hele i ke `zip()` 'ana:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ua pinepine hoʻohana 'ia e zip he mana loa iterator i ka finite kekahi.
    /// Hana kēia ma muli o ka hope o ka iterator e hoʻi ai iā [`None`], e hoʻopau ana i ka zip.Hiki ke nānā aku i ka Zipping ʻana me `(0..)` e like me [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// I ka mea hou iterator i wahi he kope o `separator` ma waena e pili 'ikamu o ka palapala iterator.
    ///
    /// I Ina `separator` 'aʻole i hoʻokō i [`Clone`] paha e pono ai, e e Me kela manawa, e hoʻohana [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // ʻO ka mea mua mai `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ka separator.
    /// assert_eq!(a.next(), Some(&1));   // ʻO ka mea aʻe aʻe mai `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ka separator.
    /// assert_eq!(a.next(), Some(&2));   // ʻO ka mea hope loa mai `a`.
    /// assert_eq!(a.next(), None);       // Ke iterator Ua pau.
    /// ```
    ///
    /// `intersperse` hiki e loa pono e hui me ka iterator ka 'ikamu ka hoʻohana' ana i ka hoʻomaopopo like hehee ai:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Hoʻokumu i kahi iterator hou e kau i kahi mea i hana ʻia e `separator` ma waena o nā mea e pili kokoke ana i ka iterator kumu.
    ///
    /// Ka panina e e kapaʻia e like koke kēlā manawa i'ikamu ua kau ma waena o nā e pili 'ikamu mai ka hp'pnphp iterator;
    /// ua hōʻike hewa, ua i kapaʻia ka panina ina ka nń ku iterator e haawi i ko emi ma mua o nā 'ikamu, a ma hope o ka hope mau ukana ua alaila kuu aku la.
    ///
    ///
    /// Inā ka iterator ka ukana e kakau mai [`Clone`], mea paha e aho e hoʻohana [`intersperse`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // ʻO ka mea mua mai `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ka separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // ʻO ka mea aʻe aʻe mai `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ka separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // ʻO ka mea hope loa mai `v`.
    /// assert_eq!(it.next(), None);               // Ke iterator Ua pau.
    /// ```
    ///
    /// `intersperse_with` hiki ke hoʻohana 'ia i loko o kahi wahi, i hiki ai ka separator pono ia e Me:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ka panina mutably noi wale aku kona pōʻaiapili e paha i ka'ikamu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// I ka panina, a hana i mea iterator i kahea aku i ka panina ma luna o kēlā me kēia hehee ai.
    ///
    /// `map()` transforms kekahi iterator i loko o kekahi, ma ka mea o kona loulou:
    /// mea i mea lapaʻau [`FnMut`].Hoʻopuka ia i kahi iterator hou e kāhea ana i kēia pani ma kēlā me kēia mea o ka iterator kumu.
    ///
    /// Inā maikaʻi ʻoe i ka noʻonoʻo ʻana i nā ʻano, hiki iā ʻoe ke noʻonoʻo iā `map()` e like me kēia:
    /// Inā 'oe i ka iterator e haawi oe oihana mua o kekahi mau' ano `A`, a me 'oe makemake i ka iterator o kekahi'ē aʻe type `B`, e hiki ke hoʻohana `map()`, Eʻoi mai ana i ka panina e lawe i ka `A`, a hoi mai i ka `B`.
    ///
    ///
    /// `map()` ʻano like manaʻo like me ka loop [`for`].Eia naʻe, e like me `map()` mea palaualelo, ka mea, ua pono hoʻohana 'ia ka wā e huli hana mua a me nā iterators.
    /// Inā ʻoe e hana nei i kahi ʻano looping no kahi hopena ʻaoʻao, manaʻo ʻia ʻoi aku ka idiomatic e hoʻohana i [`for`] ma mua o `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Inā 'oe e huli hana i kekahiʻano o kaʻaoʻao hookoia, makemake [`for`] i `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // mai hana i kēia:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ka mea e ole e hoopai aku, e like me ka mea mea palaualelo.Rust, e ao aku oe e pili ana i keia.
    ///
    /// // Ma kahi o, e hoʻohana no:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kāhea i kahi pani ʻana ma kēlā me kēia mea o ka iterator.
    ///
    /// Kēia mea like i ka hoʻohana 'ana i kekahi [`for`] loop ma ka iterator, naʻe `break` a me `continue` e ole e hiki mai ka panina.
    /// O ke ano nui oi idiomatic e hoʻohana i ka `for` loop, akā, `for_each` i e oi a moākāka ka wā aaioee ikamu i ka pau ana o ka hou iterator kaulahao.
    ///
    /// Ma kekahi hihia `for_each` i kekahi e wikiwiki ma mua o ka loop, no ka mea, e hoʻohana maloko iteration ma adapters e like `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// No ka mea, he uuku hoʻohālike, he `for` loop i e wahine holoi, akā, `for_each` paha e e ahoʻia e malama i ka loiloi kaila me ka hou iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Hoʻokumu i kahi iterator e hoʻohana i ka pani e hoʻoholo inā e hāʻawi ʻia kahi mea.
    ///
    /// Ua haawiia i hehee ai ka panina pono hoʻi `true` a `false`.Hāʻawi ka iterator i hoʻihoʻi ʻia i nā mea wale nō e hoʻi ai ka pani.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No ka mea, o ka panina hala ia `filter()` lawe i ka maopopo, a me ka nui iterators iterate ma kūmole, ua hiki aku i ka hiki i hookahuli ai i kulana, ma ke 'ano o ka panina o ka papalua i maopopo kahi:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // pono ʻelua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// e like me ka mea mau i kahi hoʻohana destructuring ma luna o ka manaʻo hoʻopiʻi kū'ē i ka waiwai pio aku kekahi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // nā&a *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ole 'elua:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ʻelua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o kēia mau papa.
    ///
    /// E noke i `iter.filter(f).next()` mea like paha ke `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Hana i mea iterator i nā kānana, a me nā palapala.
    ///
    /// Hāʻawi ka iterator i hoʻihoʻi ʻia i nā `waiwai 'no ka mea i hoʻihoʻi ʻia ka lako i `Some(value)`.
    ///
    /// `filter_map` hiki ke hoʻohana 'ia e na kaulahao o [`filter`] a me [`map`] hou concise.
    /// Hōʻike ka laʻana ma lalo nei pehea e hiki ai i `map().filter().map()` ke hoʻopōkole ʻia i hoʻokahi kāhea iā `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eia kahi laʻana like, akā me [`filter`] a me [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Hana i mea iterator i haawi mai i kaʻikena iteration helu like hoʻi me ka mea e hiki mai ana cia.
    ///
    /// Ke iterator hoi mai la e haawi i ko hui `(i, val)`, kahi `i` o ka papa 'inideka o iteration a me `val` o ka nui hoi ma ka iterator.
    ///
    ///
    /// `enumerate()` malama i kona helu me ka [`usize`].
    /// Inā 'oe makemake e helu ma ka okoa pepa paia helu, ke kuleana pili i [`zip`] hoʻolako ano like functionality.
    ///
    /// # hoʻohālana hana
    ///
    /// Ka papa hana i ole e kiai ana i ku e hālana lākou, no laila, kēia heluna o oi ma mua o [`usize::MAX`] hehee wale kekahi produces ka hewa hopena paha panics.
    /// Inā debug assertions i 'ā, he panic ua ua hoʻohiki.
    ///
    /// # Panics
    ///
    /// Ka hoi hou iterator paha panic ina ka i-e-hoi 'inideka e hālanaʻia i ka [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Hana i mea iterator i hiki ke hoʻohana [`peek`] e nānā i ka mea e hiki mai hehee ai o ka iterator ole ia e hoopau ana ia.
    ///
    /// Hoʻohui i kahi hana [`peek`] i kahi iterator.E ʻike i kāna palapala no ka ʻike hou aku.
    ///
    /// Note i ka hp'pnphp iterator ua nō i hoʻonoho mai ka wā [`peek`] ua kapaia no ka manawa mua: I mea e loaʻa nā i ka kekahi hehee ai, [`next`] ua kapaʻia ma luna o ka hp'pnphp iterator, mai keia wahi aku kekahiʻaoʻao waiwai ('o ia hoʻi
    ///
    /// i kekahi mea'ē aʻe ma mua o pā ka aʻe cia) o ka [`next`] iaoia e kānāwai.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ke hoike nei makou ike i loko o ka future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ua hiki peek() mau manawa, i ka iterator e ole mua
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ma hope o ka iterator ua pau, no laila, o peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Hana i mea iterator i ['skip`] mau oihana mua me ka nānā' ana ma o ka predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` i ka panina me ka loulou.Ka mea, e kapa aku i kēia panina ma luna o kēlā me kēia hehee ai o ka iterator, a kāpae'ōlelo nā kumumea a ka mea i hoi mai `false`.
    ///
    /// `false` ua hoʻi mai ma hope, `skip_while()`'s 'oihana mea ma luna, a me ke koena o na kumu mua i alaila kuu aku la.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No ka mea, o ka panina hala ia `skip_while()` lawe i ka maopopo, a me ka nui iterators iterate ma kūmole, ua hiki aku i ka hiki i hookahuli ai i kulana, ma ke 'ano o ka panina UAOAaIOIUE mea he papalua maopopo:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // pono ʻelua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Noho ma hope o ka loiloi mua `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ʻoiai he wahaheʻe kēia, ʻoiai ua loaʻa iā mākou ka wahaheʻe, skip_while() ʻaʻole hoʻohana hou ʻia
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Hana i mea iterator ia e haawi i ko kumu mua me ka nānā 'ana ma o ka predicate.
    ///
    /// `take_while()` i ka panina me ka loulou.Kāhea ia i kēia pani ʻana ma kēlā me kēia meahana o ka iterator, a hāʻawi i nā mea i ka wā e hoʻi ai ʻo `true`.
    ///
    /// `false` ua hoʻi mai ma hope, `take_while()`'s 'oihana mea ma luna, a me ke koena o na kumu mua AOON.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ma muli o ka pani ʻia ʻana i `take_while()` i kahi kūmole, a nui nā iterator e hoʻohuli i nā kuhikuhi, alakaʻi kēia i kahi hanana huikau paha, kahi o kahi ʻano o ka pani ʻana he ʻōlelo kūlua.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // pono ʻelua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Noho ma hope o ka loiloi mua `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Mākou i oi hehee wale i ka mea emi o Aʻohe, akā, mahope mai o mākou, ua loaa i ka wahahee, take_while() ua i hoʻohana hou
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No ka mea pono ʻo `take_while()` e nānā i ka waiwai i mea e ʻike ai inā e hoʻokomo ʻia a i ʻole ʻaʻole, e ʻike ana ka lawe ʻana i nā iterators ua hemo ʻia.
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ke `3` mea hou ma laila, no ka mea, i ka make ma ka mea e ike ina o ka iteration e ana, akā, Ua i hoʻonoho hoʻi i loko o ka iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Hana i mea iterator i nā e haawi i ko kumu mua me ka nānā 'ana ma o ka predicate a me ka palapala.
    ///
    /// `map_while()` i ka panina me ka loulou.
    /// Kāhea ia i kēia pani ʻana ma kēlā me kēia meahana o ka iterator, a hāʻawi i nā mea i ka wā e hoʻi ai ʻo [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eia ka ia kumu hoʻohālike, akā, me [`take_while`] a me [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ke kū nei ma hope o [`None`] mua:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Loaʻa iā mākou nā mea hou aʻe i hiki ke komo i u32 (4, 5), akā hoʻihoʻi ʻo `map_while` iā `None` no `-3` (e like me ka `predicate` i hoʻihoʻi ai iā `None`) a kū ʻo `collect` i ka `None` mua i loaʻa.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// No ka mea pono ʻo `map_while()` e nānā i ka waiwai i mea e ʻike ai inā e hoʻokomo ʻia a i ʻole ʻaʻole, e ʻike ana ka lawe ʻana i nā iterators ua hemo ʻia.
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ke `-3` mea hou ma laila, no ka mea, i ka make ma ka mea e ike ina o ka iteration e ana, akā, Ua i hoʻonoho hoʻi i loko o ka iterator.
    ///
    /// Note e like [`take_while`] keia iterator mea **i** fused.
    /// Ua ua no hoi i hoakaka ia mea keia iterator hoike ma hope o ka [`None`] mua ua hoi mai.
    /// Inā pono ʻoe i fusi iterator, e hoʻohana iā [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Hana i mea iterator e skips ka mua `n` hehee wale.
    ///
    /// ka mea, ua oki loa ma hope, i ka koena o na kumu mua i alaila kuu aku la.
    /// E aho ma mua o overriding i kēia hana 'ana, kahi aʻe i ka `nth` hana.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Hoʻokumu i kahi iterator e hāʻawi i kāna mau `n` mua.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` Hoʻohana pinepine ʻia me ka iterator palena ʻole, e hoʻopau ai:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Inā emi o `n` oihana mua i loaʻa, `take` e kali ana ia ia iho i ka nui o ka nń ku iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator mea hoʻopili like ia [`fold`] mea kaua kūloko ma moku'āina a produces he hou iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` lawe mau manaʻo hoʻopiʻi kū'ē: ka loiloi mua cia i na anoano o ka na moku'āina, a me ka panina me nā manaʻo hoʻopiʻi kū'ē, ka mea i mua o ka mutable pili i ke kipi ana a me ka lua o ka iterator hehee ai.
    ///
    /// Ka panina ke hāʻawi aku i ka mea maloko moku'āina i kaʻana like 'ana moku'āina ma waena o iterations.
    ///
    /// Ma ka iteration, e hoʻopili ʻia ka pani i kēlā me kēia mea o ka iterator a me ka waiwai hoʻihoʻi mai ka pani ʻana, kahi [`Option`], i hāʻawi ʻia e ka iterator.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // kēlā me kēia iteration, mākou e hoonui i ka moku'āina ma ka hehee ai
    ///     *state = *state * x;
    ///
    ///     // a laila, e hāʻawi mākou i ka hōʻole o ka mokuʻāina
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Hana i kahi iterator e hana e like me ka palapala ʻāina, akā pālahalaha i ke ʻano o ka hale.
    ///
    /// Ke [`map`] mea hoʻopili ka loa pono keia mau mea, akā, wale i ka wa a ka panina UAOAaIOIUE produces loina.
    /// Inā ka mea, produces i iterator kahi, aole ka he keu ahu iho la ka indirection.
    /// `flat_map()` e wehe i kēia papa keu ma kāna iho.
    ///
    /// Oe ke manaʻo o `flat_map(f)` like me ka semantic like paha o ka ['map`] ping, a laila, [`flatten`] ana me ia ma `map(f).flatten()`.
    ///
    /// Kekahi aoao o ka noʻonoʻo e pili ana i `flat_map()`: ['map`]' ke panina hoike kekahi'ikamu no kela a me keia hehee ai, a me `flat_map()`'s panina hoike i iterator no kēlā me kēia hehee ai.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoʻi he iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Hana i mea iterator e flattens pūnana 'ole.
    ///
    /// He mea maikaʻi kēia inā loaʻa iā ʻoe kahi iterator o iterators a i ʻole he iterator o nā mea i hiki ke hoʻolilo ʻia i iterators a makemake ʻoe e hemo i hoʻokahi pae o ka nīnaninau.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Palapala ─ina a laila flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoʻi he iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Hiki iā ʻoe ke kākau hou i kēia ma nā ʻōlelo o [`flat_map()`], ka mea ʻoi aku ka maikaʻi i kēia hihia ʻoiai e hōʻike akāka ana ka manaʻo.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoʻi he iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening lawe aku oe i kekahi kiʻekiʻe o aiacayueony i kekahi manawa wale:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Here ke ike i `flatten()` 'aʻole e hana i ka "deep" flatten.
    /// Akā, wale kekahiʻilikai o aiacayueony ua wehe.Ia mea, ina oe `flatten()` he ekolu-dimensional hoʻouka, i ka hopena e e elua-dimensional, aʻaʻole hoʻokahi-dimensional.
    /// No kiʻi i kekahi i kekahi-dimensional 'ole,' oe i ke `flatten()` hou.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Hana i mea iterator i na welau ma hope o ka [`None`] mua.
    ///
    /// Ma hope o ka iterator huli [`None`], future kelepona 'i paha e ole hua [`Some(T)`] hou.
    /// `fuse()` hakuloli i ka iterator, kaulike ana ma hope o ka [`None`] ua hāʻawiʻia, ka mea e mau hoʻi [`None`] ka wa pau ole.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // he iterator a koho 'ē aʻe ma waena o kekahi a me ka None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // inā ʻo ia, Some(i32), ʻē aʻe ʻAʻohe
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // hiki iā mākou ke ʻike i kā mākou iterator e hoʻi i hope
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // nae, koke mākou kaula hō'ā ia ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ka mea, e mau hoʻi `None` ma hope o ka manawa mua.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Hana i kekahi mea me kēlā me kēia mehana o kahi iterator, e waiho ana i ka waiwai ma.
    ///
    /// I ka hoʻohana 'ana i iterators, oe e pinepine hoopaa aku kekahi mau o ia pu.
    /// Oiai e hana ana ma ia kivila, oe e makemake, e nānā mai i Ka hanaia ma nā wahi likeʻole i loko o ka pipeline.I ka hana ana, hookomo i ke kapa i `inspect()`.
    ///
    /// ʻOi aku ka maʻamau no ka `inspect()` e hoʻohana ʻia ma ke ʻano he debugging mea hana ma mua o ka noho ʻana i kāu code hope loa, akā ʻike paha nā palapala noi he mea pono ia i kekahi mau hanana ke pono e kāpae i nā hewa ma mua o ka hoʻolei ʻia ʻana.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // keia iterator kaʻina ka luna '.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // e hoʻohui i kekahi mau kāhea inspect() e nānā i nā mea e hana nei
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Kēia e kakau:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Kālai lāʻauʻana hewa ma mua i kāpaeʻia ia:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Kēia e kakau:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Noi wale aku ka iterator, aole i hoopau ia.
    ///
    /// He mea pono kēia e ʻae i ka hoʻopili ʻana i nā mea hoʻopili iterator me ka hoʻomau ʻana i ka ʻona o ka iterator kumu.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ina ua ho'āʻo e hana hou iter,ʻaʻole ia e hana.
    /// // Hāʻawi ka laina aʻe i ka "hemahema: hoʻohana i ka waiwai i neʻe ʻia: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // e ka ho'āʻo mea hou
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // kahi, ke hui aku i loko o ka .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // manawa i kēia mea pono uku:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforms he iterator i loko o ka ohi.
    ///
    /// `collect()` hiki ke lawe i kekahi mea iterable, a huli ia i loko o ka pili ohi.
    /// 'O kēia kekahi o nā kiʻina hana hou mana i loko o ka hale waihona puke maʻamau, hoʻohana' ia i loko o ka likeʻole ma o nā pōʻaiapili '.
    ///
    /// ʻO ke kumu maʻamau i hoʻohana ʻia ai `collect()` e hoʻohuli i kahi hōʻiliʻili i kahi ʻohi ʻē aʻe.
    /// E lawe i ka ohi, kahea [`iter`] ma luna o ka mea, ke hanaʻoukou i pūpū o ka loli ', a laila, `collect()` i ka hopena.
    ///
    /// `collect()` hiki no hoi i hana nui o ke ano i mea ole typical hoiliili ole.
    /// No ka laʻana, hiki ke kūkulu i [`String`] mai ['char`] s, a me ka iterator o [`Result<T, E>`][`Result`] ikamu hiki ke ohi i `Result<Collection<T>, E>`.
    ///
    /// E nānā i nā examples ma lalo no ka oi.
    ///
    /// Ma muli o ka nui o `collect()`, hiki iā ia ke hoʻopilikia i nā pilikia me ka ʻano o ka manaʻo.
    /// Like me neia, `collect()` mea kekahi o oe e ike i ka Ka Mooolelo O ke aloha pumehana, ike like me ka 'turbofish' ka mau manawa: `::<>`.
    /// He kōkua ke kuhi algorithm maopopo ua hōʻike hewa i ohi āu e makemake ana e ohi i loko.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Note e pono mākou i ka `: Vec<i32>` maʻaoʻao ma ka hema-lima.ʻO kēia no ka mea hiki iā mākou ke hōʻiliʻili i, i laʻana, a [`VecDeque<T>`] ma kahi o:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// E ho ohana i ka 'turbofish' kahi o annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// No ka mea, `collect()` wale manaʻo e pili ana i mea e huli kaʻohiʻana i loko, e hiki nō ke hoʻohana 'ia i kekahi hapa type, hoʻomaoe, `_`, a me ka turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ke hoʻohana nei iā `collect()` e hana i [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Inā he papa inoa kāu o [`Hualoaʻa<T, E>`]['Result`] mau, e hiki ke hoʻohana `collect()` e ike ina kekahi o ia wa:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // e hāʻawi mai iā mākou i ka hewa mua
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // hāʻawi iā mākou i ka papa inoa o nā pane
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Pau ka iterator, e hana ana i ʻelua hōʻiliʻili mai iā ia.
    ///
    /// Hiki i ka predicate i `partition()` ke hoʻihoʻi iā `true`, a i ʻole `false`.
    /// `partition()` hoʻi he mau, a pau no na kumu no i ka mea, hoi aku la `true`, a me nā mea a pau o na kumu no i ka mea, hoi aku la `false`.
    ///
    ///
    /// E nānā pū [`is_partitioned()`] a me [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders na kumu o keia iterator *ma-wahi* e like me ka haawi mai predicate, e like me ia a pau ka poʻe i hoʻi `true` e pākuʻi mua a pau ka poʻe i hoʻi `false`.
    ///
    /// Hoike ka helu o `true` hehee wale loaʻa.
    ///
    /// Ka hoahanau mea o ka i pohā 'ikamu ua i malamaia.
    ///
    /// E nānā hoʻi [`is_partitioned()`] a me [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Paku ma-wahi ma waena o evens a me paʻewa
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: E mākou hopohopo e pili ana i ka helu pono ia ana ua kahe?Ka mea wale nōʻaoʻao i ka i oi ma mua o
        // `usize::MAX` mutable kūmole mea me ZSTs, i mea e pono i ka paku ...

        // Kū kēia mau hana pani "factory" e pale i ka laulima ma `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Pinepine huli i ka `false` mua, a kuapo ia me ka hope `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// E kaha makau i ina na kumu o keia iterator i i pohā e like me ka haawi mai predicate, e like me ia a pau ka poʻe i hoʻi `true` e pākuʻi mua a pau ka poʻe i hoʻi `false`.
    ///
    ///
    /// E nānā hoʻi [`partition()`] a me [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Kekahi a pau 'ikamu hoao `true`, a me ka mea mua o kēia aɃe ma `false` a mākou e nānā i ka mea e ole hou `true` ikamu ma hope ia.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator hana i pili i kekahi kuleana pili i like loa me ka mea hoi mai ana, ka hana i ka hookahi, hope cia.
    ///
    /// `try_fold()` lawe mau manaʻo hoʻopiʻi kū'ē: ka loiloi mua waiwai, a me ka panina me nā manaʻo hoʻopiʻi kū'ē: he 'accumulator', a me ka hehee ai.
    /// E hoʻi maikaʻi paha ka pani ʻana, me ka waiwai e loaʻa ai i ka mea hōʻuluʻulu no ka hana hou aʻe, a i ʻole hoʻi e hoʻi ʻole ka maikaʻi, me kahi helu hemahema i hoʻolaha ʻia i ka mea e kāhea koke iā (short-circuiting).
    ///
    ///
    /// Ka loiloi mua waiwai o ka waiwai o ka accumulator e i ma luna o ke kahea mua.Inā ana i ka panina pomaikai ae la lakou e ku ei na hehee ai o ka iterator, `try_fold()` huli ka accumulator hope me ka pomaikai.
    ///
    /// Ua keena nei mea pono i ka wa 'oe i ka ohi ana o kekahi mea, a me ka makemake e paka i hookahi waiwai mai ia.
    ///
    /// # Note i Implementors
    ///
    /// ʻO kekahi o nā ʻano (forward) ʻē aʻe i loaʻa nā hana maʻamau e pili ana i kēia, no laila e hoʻāʻo e hoʻokō pono i kēia inā hiki iā ia ke hana i kahi mea ʻoi aku ka maikaʻi ma mua o ka hoʻokō `for` loop loop.
    ///
    /// Eia kekahi, e hoʻāʻo i kēia kāhea `try_fold()` ma nā ʻaoʻao kūloko kahi i haku ʻia ai kēia iterator.
    /// Inā pono he mau kāhea, hiki i ka mea hoʻohana `?` ke maʻalahi no ke hoʻopaʻa ʻana i ka waiwai accumulator, akā e makaʻala i nā invariants e pono e mālama ʻia ma mua o kēlā mau hoʻi mua.
    /// ʻO kēia kahi hana `&mut self`, no laila pono e resumable ka iteration ma hope o ka pā ʻana i kahi hemahema ma aneʻi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ka hōʻuluʻulu helu o nā mea āpau o ka lālau
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Keia puu dala e hālanaʻia ka wā ka hoʻokuʻi i ka 100 hehee ai
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ma muli o ka pōkole o ka holo ʻana, loaʻa mau nā mea i koe ma o ka iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator hana i pili i ka fallible papa i kēlā me kēia aia i loko o ka iterator, noho ma ka hewa mua a me ka hoi ia hewa.
    ///
    ///
    /// Hiki ke noʻonoʻo ʻia kēia ma ke ʻano fallible o [`for_each()`] a i ʻole ka mana stateless o [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ua pōkole-ka hele kaʻapuni, no laila, 'ikamu i ka i koe, i noho i loko o ka iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Hoʻopili i kēlā me kēia mea i loko o kahi mea hōʻiliʻili e ka noi ʻana i kahi hana, hoʻihoʻi i ka hopena hope.
    ///
    /// `fold()` lawe mau manaʻo hoʻopiʻi kū'ē: ka loiloi mua waiwai, a me ka panina me nā manaʻo hoʻopiʻi kū'ē: he 'accumulator', a me ka hehee ai.
    /// Ka panina huli i ka waiwai i ke accumulator e i no ka mea e hiki mai ana iteration.
    ///
    /// Ka loiloi mua waiwai o ka waiwai o ka accumulator e i ma luna o ke kahea mua.
    ///
    /// Hope ana keia panina i kela hehee ai o ka iterator, `fold()` huli i ka accumulator.
    ///
    /// Keia hana ua kekahi manawa kapaia 'reduce' a 'inject'.
    ///
    /// Ua keena nei mea pono i ka wa 'oe i ka ohi ana o kekahi mea, a me ka makemake e paka i hookahi waiwai mai ia.
    ///
    /// Note: `fold()`, a me ka like ano e kāʻalo ana kēlā i ka iterator holoʻokoʻa, e ole 'ōlelo no ka mana loa iterators, a hiki ma traits no i ka hopena o determinable i ka finite manawa.
    ///
    /// Note: [`reduce()`] hiki ke hoʻohana 'e hoʻohana i ka hehee ai mua me ka loiloi mua cia, ina ka accumulatorʻano, aʻano ikamu i ka ia.
    ///
    /// # Note i Implementors
    ///
    /// ʻO kekahi o nā ʻano (forward) ʻē aʻe i loaʻa nā hana maʻamau e pili ana i kēia, no laila e hoʻāʻo e hoʻokō pono i kēia inā hiki iā ia ke hana i kahi mea ʻoi aku ka maikaʻi ma mua o ka hoʻokō `for` loop loop.
    ///
    ///
    /// Ma kekahi, e ho'āʻo i ka i keia leo kahea `fold()` ma ka na māhele mai i keia iterator ua haku.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // i ka huina o nā mea a pau o nā kumu o ke ku
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// E ka hele ma kēlā me kēiaʻanuʻu o ka iterationʻaneʻi.
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// A no laila,, ko makou hope loa hopena, `6`.
    ///
    /// Ia ka pono ole, no ka poʻe i i ole hoʻohana iterators i kekahi puu, e hoʻohana i ka `for` loop me ka papa inoa o ka mea e kūkulu i ka hopena.Ka poe hiki ke huli i `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // no ka loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ka mea, makemake i ka ia
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ho'ēmi i kā nā kumu mua i ka hookahi kekahi, ma Hoomau pinepine ana i ka hoemi ana.
    ///
    /// Inā ka iterator mea kaawale, hoi mai [`None`];i ʻole, hoʻihoʻi i ka hopena o ka hōʻemi.
    ///
    /// No ka iterators me ma ka liʻiliʻi loa hoʻokahi hehee ai, keia mea ka ia me [`fold()`] me ka hehee ai mua o ka iterator like me ka loiloi mua cia, e pelu ana o kela mea keia hope hehee ai i loko o ia.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// E huli i ka i kā mākou waiwai:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// E ho'āʻo ai ina kela hehee ai o ka iterator 'ākau a he predicate.
    ///
    /// `all()` i ka panina e hoi mai `true` a `false`.Ua pili keia panina i kēlā me kēia hehee ai o ka iterator, a ina ka mea, a pau hoʻi `true`, laila, no laila, hana `all()`.
    /// Inā hoʻi kekahi o ia `false`, ka mea, hoi mai `false`.
    ///
    /// `all()` He pōkole-circuiting;i loko o nā hua'ōlelo, ia aaioee, e pau ana i ka wa i ka mea loaʻa he `false`, haawi mai ia i mea mea'ē aʻe, ke hana, i ka hopena, e hoi e `false`.
    ///
    ///
    /// An nele iterator huli `true`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Noho ma ka `false` mua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// E ho'āʻo ai ina kekahi hehee ai o ka iterator 'ākau a he predicate.
    ///
    /// `any()` i ka panina e hoi mai `true` a `false`.Pili kēia pani i kēlā me kēia mea o ka iterator, a inā hoʻi kekahi o lākou i ka `true`, a laila ʻo `any()` kekahi.
    /// Inā ka mea, a pau hoʻi `false`, ka mea, hoi mai `false`.
    ///
    /// `any()` ke kaapuni pōkole nei;i nā huaʻōlelo ʻē aʻe, e hoōki ia i ka hana ʻana ke loaʻa iā ia kahi `true`, hāʻawi ʻia i kēlā me kēia mea ʻole e hana ʻia, ʻo `true` ka hopena.
    ///
    ///
    /// Hoʻihoʻi kahi iterator hakahaka iā `false`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ke kū nei ma ka `true` mua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Searches no i hehee ai o ka iterator i satisfies he predicate.
    ///
    /// `find()` lawe i kahi pani e hoʻi iā `true` a i ʻole `false`.
    /// Ua pili keia panina i kēlā me kēia hehee ai o ka iterator, a ina hoi kekahi o ia `true`, laila `find()` hoi mai [`Some(element)`].
    /// Inā ka mea, a pau hoʻi `false`, ka mea, hoi mai [`None`].
    ///
    /// `find()` He pōkole-circuiting;i loko o nā hua'ōlelo, ka mea, e pau ana aaioee like koke i ka panina huli `true`.
    ///
    /// No ka mea, `find()` i ka maopopo, a me ka nui iterators iterate ma kūmole, ua hiki aku i ka hiki i hookahuli ai i kulana home 'ole kahi ka manaʻo hoʻopiʻi kū'ē mea he papalua i maopopo nä haumäna.
    ///
    /// Oe ke 'ike i kēia hopena i loko o nā examples ma lalo, a me `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ke kū nei ma ka `true` mua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// E hoʻomaopopo he like ka `iter.find(f)` me `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Pili hana i na oihana mua o iterator, a huli i ka mua ole-aohe hopena.
    ///
    ///
    /// `iter.find_map(f)` mea like paha ke `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Pili hana i na oihana mua o iterator, a huli i ka oiaio hopena mua a me ka mea mua hewa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Huli i kahi mea i kahi iterator, e hoʻihoʻi nei i kāna papa kuhikuhi.
    ///
    /// `position()` lawe i kahi pani e hoʻi iā `true` a i ʻole `false`.
    /// Ua pili keia panina i kēlā me kēia hehee ai o ka iterator, a ina kekahi o ia hoi mai `true`, laila `position()` hoi mai [`Some(index)`].
    /// Inā hoʻi a pau o ia `false`, ka mea, hoi mai [`None`].
    ///
    /// `position()` He pōkole-circuiting;i loko o nā hua'ōlelo, ia aaioee, e pau ana i ka wa i ka mea loaʻa he `true`.
    ///
    /// # hoʻohālana hana
    ///
    /// ʻAʻole kiaʻi ke ʻano i nā wai kahe, no laila inā ʻoi aku ma mua o [`usize::MAX`] nā mea kūlike ʻole, hana paha ia i ka hopena hewa a panics paha.
    ///
    /// Inā debug assertions i 'ā, he panic ua ua hoʻohiki.
    ///
    /// # Panics
    ///
    /// Kēia papa ikaika panic ina ka iterator ua oi ma mua o `usize::MAX` ole-'ālike hehee wale.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ke kū nei ma ka `true` mua:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Aia ka papa kuhikuhi i hoʻihoʻi ʻia i ka mokuʻāina iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Searches no i hehee ai i loko o ka iterator, mai ka akau, hoi kona 'inideka.
    ///
    /// `rposition()` lawe i kahi pani e hoʻi iā `true` a i ʻole `false`.
    /// Ua pili keia panina i kēlā me kēia hehee ai o ka iterator, e hoʻomaka ana ma ka welau, a ina kekahi o ia hoi mai `true`, laila `rposition()` hoi mai [`Some(index)`].
    ///
    /// Inā hoʻi a pau o ia `false`, ka mea, hoi mai [`None`].
    ///
    /// `rposition()` He pōkole-circuiting;i loko o nā hua'ōlelo, ia aaioee, e pau ana i ka wa i ka mea loaʻa he `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ke kū nei ma ka `true` mua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // No nele no ka hoʻohālana kikooʻaneʻi, no ka mea, `ExactSizeIterator` hoʻohuʻu i ka helu o ka hehee wale fits i loko o ka `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Hoʻi i ka mea nui o ka iterator.
    ///
    /// Inā mau oihana mua i like i kā mākou, ua hoʻi hou mai ka hope hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Hoʻihoʻi i ka mea liʻiliʻi o ka iterator.
    ///
    /// Inā mau oihana mua e like palena iki, ua hoi aku la ka mua hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Hoʻihoʻi i ka mea e hāʻawi i ka waiwai nui mai ka hana i kuhikuhi ʻia.
    ///
    ///
    /// Inā mau oihana mua i like i kā mākou, ua hoʻi hou mai ka hope hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Hoike i ka hehee ai e haawi i ka i kā mākou waiwai a me ka mahalo i ka hoʻohālike kuleana pili i ke koho 'ia.
    ///
    ///
    /// Inā mau oihana mua i like i kā mākou, ua hoʻi hou mai ka hope hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Hoʻihoʻi i ka mea i hāʻawi i ka palena iki o ka waiwai mai ka hana i kuhikuhi ʻia.
    ///
    ///
    /// Inā mau oihana mua e like palena iki, ua hoi aku la ka mua hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Hoʻihoʻi i ka mea i hāʻawi i ka waiwai liʻiliʻi e pili ana i ka hana hoʻohālikelike i kuhikuhi ʻia.
    ///
    ///
    /// Inā mau oihana mua e like palena iki, ua hoi aku la ka mua hehee ai.
    /// Inā nele ka iterator, hoʻihoʻi ʻia ʻo [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Nana e hoole i iterator ka ao ao.
    ///
    /// IeAUPIIe, IAa IO, iterators iterate, mai haʻalele i ka akau.
    /// Ma hope o ka hoʻohana ʻana iā `rev()`, kahi iterator e hoʻololi ai mai ka ʻākau a ka hema.
    ///
    /// Hiki wale nō kēia inā he hopena ka iterator, no laila `rev()` e hana wale ana ma ['DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Pio he iterator o ka hui i loko o ka paʻa o ka pahu.
    ///
    /// `unzip()` e hoʻopau i kahi iterator holoʻokoʻa o nā pālua, e hana ana i ʻelua hōʻiliʻili: hoʻokahi mai nā mea hema o nā pālua, a ʻo kekahi mai nā mea kūpono.
    ///
    ///
    /// Kēia kuleana pili i ka, ma kekahi ano, i ke ku pono ana o [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Hana i mea iterator i na kope a pau o kona oihana mua.
    ///
    /// He mea pono ia oe i ka iterator ma luna o `&T`, akā, e pono i ka iterator no `T`.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // e hana kope i ka ka ia me .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Hoʻokumu i kahi iterator a [`clone`] mau mea āpau.
    ///
    /// He mea pono ia oe i ka iterator ma luna o `&T`, akā, e pono i ka iterator no `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned o ka ia me .map(|&x| x), no ka integers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Hana hou i kahi iterator me ka pau ʻole.
    ///
    /// Ma kahi o ka noho ma [`None`], ka iterator e kahi hoʻomaka hou, mai ka kinohi mai.Ma hope o iterating hou, ia e hoʻomaka i ka hoʻomaka hou.A me ka hou.
    /// A hou aku.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Puu na kumu o ka iterator.
    ///
    /// I kēlā hehee ai, kō ia pu, a hoi mai i ka hopena.
    ///
    /// An nele iterator huli i ka 'Aʻohe waiwai o keʻano.
    ///
    /// # Panics
    ///
    /// I ka kahea `sum()`, a me ka primitive heluʻano ua i hoʻi, i kēia hana, e panic ina ka computation e hālanaʻia a me debug assertions i pūnaewele.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates ma ka iterator holoʻokoʻa, hoonui i na kumu mua
    ///
    /// An nele iterator huli i ka kekahi waiwai o keʻano.
    ///
    /// # Panics
    ///
    /// Ke kāhea ʻana iā `product()` a me kahi ʻano integer primitive e hoʻihoʻi ʻia nei, panic ke ʻano hana inā hiki ke hoʻonui ʻia ka helu a me nā manaʻo debug i hiki ai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hoʻohālikelike i nā mea o kēia [`Iterator`] me nā mea ʻē aʻe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hoʻohālikeʻana i nā kumu o kēia [`Iterator`] me ka poe o kekahi me ka manao i ka hoʻohālike kuleana pili i ke koho 'ia.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hoʻohālikelike i nā mea o kēia [`Iterator`] me nā mea ʻē aʻe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) hoʻohālikeʻana i nā kumu o kēia [`Iterator`] me ka poe o kekahi me ka manao i ka hoʻohālike kuleana pili i ke koho 'ia.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Hoʻoholo inā kūlike nā mea o kēia [`Iterator`] i kekahi o kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Hoʻoholo inā na kumu o keia [`Iterator`] e like me ka poe o kekahi me ka manao ana i ka mea e hoʻokolokolo pono kuleana pili i ke koho 'ia.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Hoʻoholo inā kūlike ʻole nā mea o kēia [`Iterator`] i kekahi o kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Hoʻoholo inā na kumu o keia [`Iterator`] i [lexicographically](Ord#lexicographical-comparison) emi ma mua o ka poe o ko kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Hoʻoholo inā ʻo nā mea o kēia [`Iterator`] [lexicographically](Ord#lexicographical-comparison) ʻoi aku a i ʻole like paha me kekahi o kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Hoʻoholo inā na kumu o keia [`Iterator`] i [lexicographically](Ord#lexicographical-comparison) oi aku mamua o ka poe o ko kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Hoʻoholo inā na kumu o keia [`Iterator`] i [lexicographically](Ord#lexicographical-comparison) ÿoi aku ma mua o paha i keia i ka poe o kekahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Nānā inā hoʻonohonoho ʻia nā mea o kēia iterator.
    ///
    /// Ia mea, no kela a me keia hehee ai `a` a me kona hahai hehee ai `b`, `a <= b` pono paa.Inā ka iterator e haawi i ko pono Aʻohe paha kekahi hehee ai, `true` ua hoi aku la.
    ///
    /// E hoʻomaopopo inā ʻo `Self::Item` `PartialOrd` wale nō, akā ʻaʻole `Ord`, hōʻike ka wehewehe i luna e hoʻi kēia hana i `false` inā ʻaʻole hoʻohālikelike ʻia nā mea ʻelua ʻelua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// E kaha makau i ina e hoʻokaʻina 'na kumu o keia iterator ka hoʻohana' ana i ka haawiia mai comparator kuleana pili i.
    ///
    /// Ma kahi o ka hoʻohana ʻana iā `PartialOrd::partial_cmp`, hoʻohana kēia hana i ka hana `compare` i hāʻawi ʻia e hoʻoholo ai i ka hoʻonohonoho ʻana o nā mea ʻelua.
    /// Kaawale mai ia, ua like ia me [`is_sorted`];ike kona nā moʻolelo no ka 'ike hou aku.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// E kaha makau i ina e hoʻokaʻina 'na kumu o keia iterator ka hoʻohana' ana i ka haawi kī pōʻalo kuleana pili i.
    ///
    /// Ma kahi o ke kapakai a ka iterator ka hehee wale 'ana, ua papa hoʻohālikeʻana i ka ki o na kumu mua, e like me ka manao ana `f`.
    /// Kaawale mai ia, ua like ia me [`is_sorted`];ike kona nā moʻolelo no ka 'ike hou aku.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// E nānā iā [TrustedRandomAccess]
    // Ka hana inoa mea e pale aku inoa hookui hookahe koko ana ma ka hana hoʻonā ike #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}