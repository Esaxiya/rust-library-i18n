/// An iterator e mau ana mau i ka hua `None` ia ana.
///
/// Kahea ae ma ka fused iterator mea i hoi `None` kekahi manawa, ua ua hoʻohiki e hoʻi [`None`] hou.
/// Keia trait E e hoʻokōʻia nā mea a pau iterators i hoi keia aoao, no ka mea, e leie aku optimizing [`Iterator::fuse()`].
///
///
/// Note: I mau, oe e ole hoʻohana `FusedIterator` ma nōhie iho i pale a ina e pono ke fused iterator.
/// Akā, pono ʻoe e kāhea iā [`Iterator::fuse()`] ma ka iterator.
/// Inā ua hoʻopili ʻia ka iterator, ʻo ka mea hoʻopili [`Fuse`] hou aʻe he no-op me ka hoʻopaʻi ʻole o ka hana.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// An iterator i mau moʻolelo i pololei loa ka hoʻohana 'ana size_hint.
///
/// Na iterator mau moʻolelo i ka nui, hoʻomaoe hou akula kahi ia o kekahi mau (lalo, i nakinaki ai mea like i ka uka e paa ana), a me na luna e paa ana o [`None`].
///
/// I ka luna ua nakiiia ma na pono wale nō e [`None`] ina ka maoli iterator lōʻihi ka nui ma mua o [`usize::MAX`].
/// Ma ia hihia, i ka lalo me ka paa, pono e [`usize::MAX`], kūpono ma ka [`Iterator::size_hint()`] o `(usize::MAX, None)`.
///
/// Pono ka iterator e hana kikoʻī i ka helu o nā mea i hōʻike ʻia a i ʻole diverge ma mua o ka hiki ʻana i ka hopena.
///
/// # Safety
///
/// Keia trait pono wale nō e hoʻokō i ka wa o ka aelike ua kokuaia oia.
/// Pono nā mea kūʻai mai kēia trait e nānā iā [`Iterator::size_hint()`]’s i luna e paʻa ana.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// ʻO kahi iterator i ka manawa e hāʻawi ana i kahi mea i lawe ʻia ma ka liʻiliʻi i hoʻokahi mea mai kāna [`SourceIter`] kumu.
///
/// Kahea ana i kekahi hana i hana 'ia he ka iterator, e like
/// [`next()`] a [`try_fold()`], hoʻohiki ia no kela a me keia anu u ma ka liʻiliʻi loa i kekahi waiwai o ka iterator ka nń ku kumu i ua hoʻoneʻe mai a me ka hopena o ka iterator kaula hiki e hookomo ma kona wahi, holoholo mall nā palena o ke kumu ae like me ka hookomo.
///
/// I nā huaʻōlelo ʻē aʻe e hōʻike ana kēia trait hiki ke hōʻiliʻili ʻia kahi paipu iterator ma kahi.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}