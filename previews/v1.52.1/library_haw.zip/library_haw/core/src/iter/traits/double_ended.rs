use crate::ops::{ControlFlow, Try};

/// An iterator hiki ke haawi aku nā kumumea, mai nā kihi aku.
///
/// I kekahi mea i mea lapaʻau `DoubleEndedIterator` i hoʻokahi keu ioeaie ma luna o kekahi mea i mea lapaʻau [`Iterator`]: ka hiki ia i lawe 'Item`s mai ka hope, e like me ka pono me ke alo.
///
///
/// He mea nui e hoʻomaopopo i ka hana o ka hope a me ka hana ma ka pae like, a mai hele i kēlā ʻaoʻao: ua hala ka hana i ka wā a lākou e hui ai ma waena.
///
/// Ma ka like like i ka [`Iterator`] Hola Pūnaewele, koke ka `DoubleEndedIterator` hoʻi [`None`] mai ka [`next_back()`], e kahea ana ka mea hou e paha eʻaʻole loa hoʻi [`Some`] hou.
/// [`next()`] a me [`next_back()`] i interchangeable no keia mea.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// E lawe aku oe a hoike i hehee ai, mai ka pau ana mai o ka iterator.
    ///
    /// Hoʻi `None` ka wā loaʻa nā ole hou hehee wale.
    ///
    /// Ka [trait-level] Palapala pihaʻi hou lāliʻi.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Na kumu mua alaila kuu aku la ia e `DoubleEndedIterator` mau ki ina hana like i oko mai o ka mea haawi ma ka ['Iterator`]' mau ki ina hana:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// E hana 'ia ka iterator mai ka hoʻi ma `n` hehee wale.
    ///
    /// `advance_back_by` o ka mea nana e hoole mana o [`advance_by`].Kēia hana, e eagerly skip `n` hehee wale e hoʻomaka ana mai o ka hoʻi ma ke kahea [`next_back`] i ke `n` manawa a [`None`] ua pilikia.
    ///
    /// `advance_back_by(n)` E hoʻi [`Ok(())`] ina ka iterator ana E hana 'ia ma `n` hehee wale, a [`Err(k)`] ina [`None`] ua pilikia, kahi `k` o ka helu ana o hehee wale ka iterator ka holomua ma mua holo ana o ka oihana mua (' o ia hoʻi
    /// ka lōʻihi o ka iterator).
    /// E hoʻomaopopo he emi mau ka `k` ma mua o `n`.
    ///
    /// Kahea `advance_back_by(0)` aʻole e hoopau ia i kekahi kumu, a mau loa, e huli hou [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` wale nō i heʻe ʻia
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Hoike i ka `n`th hehee ai, mai ka pau ana mai o ka iterator.
    ///
    /// Heʻano nui i ka nana e hoole mana o [`Iterator::nth()`].
    /// ʻOiai hapanui hōʻinideka 'ana e like, me ka huina hoomaka mai Aʻohe, no laila, `nth_back(0)`, hoi mai ka mua cia, mai ka hopena, `nth_back(1)` ka lua, a no laila, ma luna o.
    ///
    ///
    /// E noke i nā kumu ma waena o ka hopena, a me ka hoi mai hehee ai e e hoʻopau, a me ka hoi mai hehee ai.
    /// ʻO ia hoʻi ke kāhea ʻana iā `nth_back(0)` i mau manawa ma ka iterator like e hoʻihoʻi i nā mea like ʻole.
    ///
    /// `nth_back()` E hoʻi [`None`] ina `n`, ua oi aku ma mua o paha e like me ka lōʻihi o ka iterator.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Kahea `nth_back()` mau manawa 'aʻole i rewind i ka iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Ke hoʻihoʻi nei iā `None` inā aia ma lalo o `n + 1` mau mea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// 'O kēia ka mea nana e hoole mana o [`Iterator::try_fold()`]: ka mea, e kaili hehee wale e hoʻomaka ana, mai ke kua mai o ka iterator.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ma muli o ka pōkole o ka holo ʻana, loaʻa mau nā mea i koe ma o ka iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ʻO kahi hana iterator e hōʻemi ana i nā mea o ka iterator i hoʻokahi, waiwai hope loa, e hoʻomaka ana mai ka hope.
    ///
    /// 'O kēia ka mea nana e hoole mana o [`Iterator::fold()`]: ka mea, e kaili hehee wale e hoʻomaka ana, mai ke kua mai o ka iterator.
    ///
    /// `rfold()` lawe mau manaʻo hoʻopiʻi kū'ē: ka loiloi mua waiwai, a me ka panina me nā manaʻo hoʻopiʻi kū'ē: he 'accumulator', a me ka hehee ai.
    /// Ka panina huli i ka waiwai i ke accumulator e i no ka mea e hiki mai ana iteration.
    ///
    /// Ka loiloi mua waiwai o ka waiwai o ka accumulator e i ma luna o ke kahea mua.
    ///
    /// Hope ana keia panina i kela hehee ai o ka iterator, `rfold()` huli i ka accumulator.
    ///
    /// Keia hana ua kekahi manawa kapaia 'reduce' a 'inject'.
    ///
    /// Ua keena nei mea pono i ka wa 'oe i ka ohi ana o kekahi mea, a me ka makemake e paka i hookahi waiwai mai ia.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // i ka huina o nā mea a pau o na kumu o ka
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Kēia hana kūkulu i ke kaula, e hoʻomaka ana me ka loiloi mua waiwai a me ka hoomau ana i kēlā me kēia hehee ai, mai ka hope a me ka mua:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Searches no i hehee ai o ka iterator, mai ke kua i satisfies he predicate.
    ///
    /// `rfind()` lawe i kahi pani e hoʻi iā `true` a i ʻole `false`.
    /// Ua pili keia panina i kēlā me kēia hehee ai o ka iterator, e hoʻomaka ana i ka hopena, a ina hoi kekahi o ia `true`, laila `rfind()` hoi mai [`Some(element)`].
    /// Inā ka mea, a pau hoʻi `false`, ka mea, hoi mai [`None`].
    ///
    /// `rfind()` He pōkole-circuiting;i loko o nā hua'ōlelo, ka mea, e pau ana aaioee like koke i ka panina huli `true`.
    ///
    /// No ka mea, `rfind()` i ka maopopo, a me ka nui iterators iterate ma kūmole, ua hiki aku i ka hiki i hookahuli ai i kulana home 'ole kahi ka manaʻo hoʻopiʻi kū'ē mea he papalua i maopopo nä haumäna.
    ///
    /// Oe ke 'ike i kēia hopena i loko o nā examples ma lalo, a me `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Ke kū nei ma ka `true` mua:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ua hiki nō ke hoʻohana `iter`, me he mea hou aku hehee wale.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}