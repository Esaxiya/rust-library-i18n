/// Hoʻololi mai kahi [`Iterator`].
///
/// Ma ka hoʻokō ʻana iā `FromIterator` no kahi ʻano, wehewehe ʻoe pehea e hana ʻia ai mai kahi iterator.
/// Keia mea, he pono ole i ke ano a wehewehe mai i ka ohi ana i kekahi mau ano keia ano.
///
/// [`FromIterator::from_iter()`] mea kākaʻikahi kapa kūlike loa, a ua kahi hoʻohana ma [`Iterator::collect()`] hana.
///
/// E ʻike i nā palapala [`Iterator::collect()`]'s no nā laʻana hou aʻe.
///
/// E nānā i kekahi: [`IntoIterator`].
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// E ho ohana i [`Iterator::collect()`] e implicitly hoʻohana `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ke hoʻokō nei i `FromIterator` no kāu ʻano:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A Laʻana ohi, i ka pololei i ka wrapper no Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // E ka haawi aku ia i kekahi mau ki ina hana like ai mākou ke hana i kekahi, a hui na mea ia ia.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ae hoʻokō mākou iā FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ano, ua hiki e i hou iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... a e ka MyCollection mai o ka mea
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ohi hana pū kekahi!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Hana i ka waiwai mai ka iterator.
    ///
    /// E ʻike i ka [module-level documentation] no ka mea hou aʻe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Hoʻololi i [`Iterator`].
///
/// Ma ka hoʻokō 'ia' `IntoIterator` no ka hoailona, e hoakaka pehea ia e e huli i ka iterator.
/// Keia mea, he pono ole i ke ano a wehewehe mai i ka ohi ana i kekahi mau ano keia ano.
///
/// Kekahi pono o ka hoʻokō 'ia' `IntoIterator` mea i kouʻano e [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// E nānā i kekahi: [`FromIterator`].
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Hoʻokō `IntoIterator` no kou 'ano:
///
/// ```
/// // A Laʻana ohi, i ka pololei i ka wrapper no Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // E ka haawi aku ia i kekahi mau ki ina hana like ai mākou ke hana i kekahi, a hui na mea ia ia.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a mākou e hoʻokō i IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ano, ua hiki e i hou ohi ...
/// let mut c = MyCollection::new();
///
/// // ... hoʻohui i kekahi mea iā ia ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a laila hoʻololi iā ia i Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ua mea, he pono ole, e hoʻohana `IntoIterator` like me ka trait bound.ʻAe kēia i ka ʻano hōʻiliʻili hoʻokomo e loli, ʻoiai he iterator ia.
/// Hiki ke ho'ākāka 'ia nā palena hou aʻe ma ke kaohi' ana ma
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ʻO ke ʻano o nā mea i hoʻoiho ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// I ke ano o ka iterator i ke haliu ae la ia i kēia i loko o?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Hana i mea iterator mai ka nui.
    ///
    /// E ʻike i ka [module-level documentation] no ka mea hou aʻe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Ana i ka ohi ana me kahi o ka iterator.
///
/// Iterators paka i ka moʻo o cia, a me ka hoiliili ole hiki e hoomanao iho la hoi o like me ka moʻo o ka loina.
/// Ka `Extend` trait iinoia keia nahā i, hiki oe e hohola aku i ka ohi ana a me kahi o ia iterator.
/// I ka holo ana i ka ohi ana me ka ua na kī, i komo ua moʻolelo paha, ma ka hihia o ka hoiliili i ae mau 'ikamu i like ki, i komo ua hookomoia.
///
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// // Oe ke ana i ke kaula me kekahi Mike Char.
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Ka hoʻokō `Extend`:
///
/// ```
/// // A Laʻana ohi, i ka pololei i ka wrapper no Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // E ka haawi aku ia i kekahi mau ki ina hana like ai mākou ke hana i kekahi, a hui na mea ia ia.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // hope MyCollection i ka papa inoa o nā i32s, ua hoʻokō E ho'ākea i no i32
/// impl Extend<i32> for MyCollection {
///
///     // ʻOi aku ka maʻalahi o kēia me ka pūlima ʻano konkona: hiki iā mākou ke kāhea i nā mea āpau i hiki ke hoʻolilo ʻia i Iterator e hāʻawi iā mākou i32s.
///     // No ka mea, ua pono i32s e hoʻokomo i loko o MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ke manaʻo He loa straightforward: loop ma ka iterator, a me add() kēlā hehee ai ia makou.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // e mau ana mākou ohi me ekolu hou nui
/// c.extend(vec![1, 2, 3]);
///
/// // ua pākuʻi mākou i kēia mau mea i ka hopena
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Hoʻonui i kahi hōʻiliʻili me nā ʻike o ka iterator.
    ///
    /// E like me keia mea i ka wale koi ano no keia trait, ka [trait-level] Palapala komo hou lāliʻi.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // Oe ke ana i ke kaula me kekahi Mike Char.
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// KŰlń ao ka ohi me ka pono kekahi hehee ai.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Me ke koe nona iho i loko o ka ohi no ka mea i haawiia ka helu o nā kumu mua.
    ///
    /// Ka paʻamau manaʻo i mea ole.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}