/// He iterator i ʻike i kona lōʻihi kikoʻī.
///
/// He nui [`Iterator`] mau mai i ike pehea nui o na manawa a lakou e makemake ai iterate, akā, i kekahi mau hana.
/// Inā i iterator ike pehea nui o na manawa e hiki iterate, ka hoʻolako 'komo i ia' ike hiki e maikaʻi kēia.
/// No kekahi laʻana, ina e makemake ia iterate ia ma ka hope, i ka hoʻomaka maikaʻi mea, e ike i kahi o ka hopena o.
///
/// I ka hoʻokō 'ia' ka `ExactSizeIterator`, e pono no hoi hoʻokō [`Iterator`].
/// I ka hana ana pela, i ka manaʻo o [`Iterator::size_hint`]*pono* e hoʻi i ka kiko'ī ka nui o ka iterator.
///
/// Na [`len`] papa hana i ka paʻamau manaʻo, no laila, oe IeAUPIIe, IAa IO E ole hoʻokō i ia.
/// Eia nō naʻe, hiki paha iā ʻoe ke hāʻawi i kahi hoʻokō ʻoi aku ka hoʻokō ma mua o ka paʻamau, no laila he mea kūpono ke hoʻokahuli iā ia i kēia hihia.
///
///
/// Note i keia trait mea he maluhia trait, a me ia hana *i* a *e hiki ole* kumu hoʻomalu i ka hoi loa i pololei.
/// ʻO ka manaʻo o `unsafe` code **ʻaʻole pono** e kaukaʻi i ka pololei o [`Iterator::size_hint`].
/// Hāʻawi ka XB [`TrustedLen`](super::marker::TrustedLen) trait paʻa ʻole a palekana ʻole i kēia hōʻoia hou.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// // ʻike maopopo kahi laulā palena i ka nui o nā manawa
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I ka [module-level docs], ua hoʻokō mākou i [`Iterator`], `Counter`.
/// E ka hoʻokō `ExactSizeIterator` no ka mea, e like me ka pono:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Mākou ke maʻalahi e huli i ka i koe helu o iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ano, ua hiki ke hana ia!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Huli i ka mau loa ana o ka iterator.
    ///
    /// Hoʻomaopopo ka hoʻokō i ka iterator e hoʻihoʻi pololei iā `len()` i nā manawa hou i [`Some(T)`] waiwai, ma mua o ka hoʻihoʻi ʻana iā [`None`].
    ///
    /// Kēia hana i ka paʻamau manaʻo, no lailaʻoe IeAUPIIe, IAa IO E ole hoʻokō i mea pololei.
    /// Eia naʻe, inā e hiki i kekahi hou efficient manaʻo, e hiki ke hana pela.
    /// E nānā i ke [trait-level] Palapala no lakou i mea hoike.
    ///
    /// Kēia papa i ka ia ka maluhia hoʻohiki me ke kuleana pili i [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // ʻike maopopo kahi laulā palena i ka nui o nā manawa
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Kēia assertion He overly kūlana pale, akā, e loaʻa, e kaha i ka invariant
        // ua hoʻohiki ma ka trait.
        // Inā keia trait he rust-na, ua hiki ke hoʻohana debug_assert !;assert_eq!e kaha a pau Rust hoʻohana implementations kekahi.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Hoʻi iā `true` inā hakahaka ka iterator.
    ///
    /// Kēia hana i ka paʻamau manaʻo hoʻohana [`ExactSizeIterator::len()`], no laila, 'aʻole' oe pono e hoʻokō ia oe iho.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}