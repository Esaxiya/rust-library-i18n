//! Composable mawaho iteration.
//!
//! Inā 'oe he paena loaʻa oe ia oe iho me ka ohi ana i kekahi mau ano keia ano, a ua pono, e hana i ka hana ma luna o nā kumu o ka olelo mai ohi, oe e koke holo i 'iterators'.
//! Hoʻohana nui ʻia nā Iterators i ka code idiomatic Rust, no laila pono ke kamaʻāina me lākou.
//!
//! Mamua o ka weheweheʻana aku, e ka olelo e pili ana i keia Module ua mea kūkulu:
//!
//! # Organization
//!
//! Hoʻonohonoho nui ʻia kēia module e ka ʻano:
//!
//! * [Traits] nō ka 'ōlelo hapa: mau traits IeXAaAeAaIEN mea' ano o nā iterators like paha i kahi a me ka mea e hiki ke hana me ia.Nā hakakā o kēia mau traits pono kau aku la i kekahi mau keu study manawa i loko o.
//! * [Functions] i kekahi kōkua maikaʻi aoao, e ho okumu i kekahi kumu o iterators.
//! * [Structs] mea pinepine o ka hoʻi 'ano o nā kiʻina hana likeʻole ma luna o kēia māhele Module ka traits.Oe e IeAUPIIe, IAa IO makemake, e nana i ka hana e hana ai ka `struct`, ma mua o ka `struct` iho.
//! No ka hou au mamuli e pili ana i ke kumu, e nānā '[i hoʻokō i Iterator](#hoʻokō-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! O ia wale nō!E ka eli i iterators.
//!
//! # Iterator
//!
//! I ka naau a me ka naau o keia Module o ka [`Iterator`] trait.ʻO kāna mau 'ōlelo a [`Iterator`] nana me keia:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! He ʻano hana kā ka iterator, [`next`], ke kāhea ʻia, hoʻihoʻi i kahi [`ʻAno`]<Item>`.
//! [`next`] E hoʻi [`Some(Item)`] like loa me he mau oihana mua, a koke ka mea, hulina a pau 'ana, e hoʻi `None` i ka hōʻike i iteration ua pau.
//! Kanaka iterators e koho i ka hoʻomau 'iteration, a no laila, ke kahea hou [`next`] e paha e ole e ho'ōla hoʻomaka hoi [`Some(Item)`] hou ma kekahi mau wahi (no ka laʻana, ike [`TryIter`]).
//!
//!
//! [`Iterator`] 's piha ka wehewehena ka loaʻa o ka helu ana o na ano like ola, akā, ka mea, i ka paʻamau ano, kūkuluʻia ma luna o [`next`], a no laila, lawe oe ia no ka noa.
//!
//! Iterators mea i composable, a ia ka hui i ka kaulahao la lakou a pau, e hana hou luna 'ano o ka aaioee.E ʻike i ka ʻāpana [Adapters](#adapters) ma lalo no nā kikoʻī hou aʻe.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Ka ekolu ano o ka iteration
//!
//! ʻEkolu mau hana maʻamau i hiki ke hana i nā iterators mai kahi hōʻuluʻulu:
//!
//! * `iter()`, a iterates ma luna o `&T`.
//! * `iter_mut()`, a iterates ma luna o `&mut T`.
//! * `into_iter()`, a iterates ma luna o `T`.
//!
//! Hiki i nā mea like ʻole i ka waihona waihona maʻamau ke hoʻokō i hoʻokahi a ʻoi paha o nā mea ʻekolu, kahi kūpono.
//!
//! # ka hoʻokō 'Iterator
//!
//! E pili ana i ka iterator o kou mau kŰia mauʻanuʻu: e pili ana i ka `struct`, e hoopaa i ka iterator ka moku'āina, a laila, i hoʻokō i [`Iterator`] no ia `struct`.
//! 'O kēia ke kumu, ua ai nui' struct`s i loko o kēia māhele Module: he mea hoʻokahi no kēlā me kēia iterator a me iterator mea hoʻopili.
//!
//! E ka hana i iterator inoa `Counter` i helu mai `1` a hiki i `5`:
//!
//! ```
//! // ʻO ka mea mua,
//!
//! /// An iterator i helu mai kekahi i ka elima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ua makemake mākou helu e hoʻomaka i kekahi, no laila, e ka hookui he new() papa hana no ke kōkua.
//! // Kēia mea,ʻaʻole pololei pono, akā, ua pono.
//! // Note e mākou hoʻomaka `count` ma Aʻohe, mākou e ike ke kumu i loko o `next()`'s manaʻo ma lalo.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // A laila, ua hoʻokō `Iterator` no mākou `Counter`:
//!
//! impl Iterator for Counter {
//!     // mākou e e helu me ka usize
//!     type Item = usize;
//!
//!     // next() ʻo ia wale nō ka hana i koi ʻia
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Xi mākou helu.ʻO kēia ke kumu a mākou i hoʻomaka ai ma ka ʻole.
//!         self.count += 1;
//!
//!         // E nānā inā ua pau kā mākou helu ʻana ʻaʻole paha.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ano, ua hiki ke hana ia!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Kahea [`next`] kēiaʻaoʻao loaʻa repetitive.He kūkulu ʻo Rust i hiki ke kāhea iā [`next`] ma kāu iterator, a hiki i `None`.E ka hele ma ia e hiki mai ana.
//!
//! No hoi e hoailona oukou i `Iterator` hoʻolako i ka paʻamau manaʻo o nā kiʻina hana e like me `nth` a me `fold` i kapa aku `next` i loko o.
//! Eia naʻe, ia mea no hoi e hiki ke kākauʻana i ka hana mau manaʻo o kāu kiʻina hana e like `nth` a me `fold` ina ka iterator hiki compute ia aku ka maiau, me ke kahea `next`.
//!
//! # `for` puka lou a me `IntoIterator`
//!
//! Rust ka `for` loop Ka Mooolelo O mea nae kōpaʻa no iterators.Eia kahi laʻana maʻamau o `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! E paʻi kēia i nā helu hoʻokahi a ʻelima, kēlā me kēia ma kā lākou laina ponoʻī.Akā, oe e hai i kekahi meaʻaneʻi: mākou loa kapa i kekahi mea ma luna o mākou vector e paka i iterator.He aha ka mea e hāʻawi ai?
//!
//! Aia O kekahi trait i loko o ka hale waihona puke maʻamau no ka hoʻololi 'ana i kekahi mea i loko o ka iterator: [`IntoIterator`].
//! He trait i kekahi papa hana, [`into_iter`], i pio i ka mea hoʻokō [`IntoIterator`] i loko o ka iterator.
//! E ka lawe i ka nana aku i ua `for` loop hou, a me ka mea i ka compiler pio ia i loko o:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars i kēia i:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Mua, ua kahea `into_iter()` i ka nui.A laila, kūlike mākou ma ka iterator e hoʻi, e kāhea nei iā [`next`] ma mua a ʻike mākou i `None`.
//! Ma ia wahi, ua `break` mai o ka loop, a mākou oe hana iterating.
//!
//! Ka I hoʻokahi hou maalea iki 'aneʻi: ka maʻamau waihona he he hoihoi' manaʻo o [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! I nā huaʻōlelo ʻē aʻe, e hoʻokō nā mea āpau [`Iterator`] iā [`IntoIterator`], ma ka hoʻihoʻi ʻana iā lākou iho.ʻO kēia ke ʻano o nā mea ʻelua:
//!
//! 1. Inā 'oe e huli kākau ka [`Iterator`], e hiki ke hana ia me ka `for` loop.
//! 2. Inā 'oe e huli e pili ana i ka ohi, i hoʻokō i [`IntoIterator`] no ka mea, e ae i kou manawalea ana i ka e hoʻohana i ka `for` loop.
//!
//! # Iterating ma ka pili
//!
//! No ka [`into_iter()`] lawe `self` ma ka waiwai, ka hoʻohana 'ana i kekahi `for` loop i iterate ma luna o ka ohi i pau ai i ohi.Pinepine, oe e makemake, e iterate ma luna o ka ohi ole ia e hoopau ana ia.
//! He nui hoiliili ole e kaumaha aku i kāu kiʻina hana i hoomakaukau iterators ma kūmole, conventionally kapa `iter()` a me `iter_mut()` niioaaonoaaiii.
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ua nō waiwai ma keia kuleana pili i.
//! ```
//!
//! Inā he ohiʻano `C` hoʻolako `iter()`, ia IeAUPIIe, IAa IO kekahi mea lapaʻau `IntoIterator` no `&C`, me ka manaʻo e pono ke kahea `iter()`.
//! No hoi, he ohi `C` i hoʻolako `iter_mut()` ano laulā, e kakau mai `IntoIterator` no `&mut C` ma delegating i `iter_mut()`.He mau hiʻohiʻona nō he pono shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ia me `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // like me `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! ʻOiai hāʻawi nā hōʻiliʻili he nui `iter()`, ʻaʻole hāʻawi āpau iā `iter_mut()`.
//! No ka laʻana, mutating na ki o ka [`HashSet<T>`] a [`HashMap<K, V>`] hiki i ka ohi i loko o kekahi kue ana ina ke ki hashes loli, no laila, i kēia mau i hoiliili ole wale kaumaha `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Oihana a lawe i ka [`Iterator`], a hoʻi kekahi [`Iterator`] i pinepine i kapa 'iterator adapters', e like me ka mea, makou heʻano o ka 'mea hoʻopili
//! pattern'.
//!
//! Common iterator adapters nā [`map`], [`take`], a me [`filter`].
//! No ka mea hou aku, e ʻike i kā lākou palapala.
//!
//! Inā kahi adapter iterator panics, aia ka iterator i kahi kūlana i hōʻike ʻole ʻia (akā palekana palekana).
//! Kēia moku'āina ua no hoi i ua hoʻohiki e noho i ka ia ma XAaOOEN o Rust, no lailaʻoe e pakele e hilinai ana ma ka kiko'ī nā loina hoi ma kekahi iterator i'ā'ā.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ʻO Iterators (a ʻo iterator [adapters](#adapters)) he *palaualelo*. ʻO ke ʻano o ka hana ʻana i kahi iterator ʻaʻole _do_ nui āpau. ʻAʻohe mea maoli a kāhea ʻoe iā [`next`].
//! Kēia mea kekahi manawa he kumu o ka haunaele i ka wa e pili ana i iterator wale nō ke no konaʻaoʻao ole.
//! ʻO kahi laʻana, kāhea ka [`map`] hana i ka pani ʻana ma kēlā me kēia mea i lawe ʻia ma luna:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Kēia e ole e kakau i kekahi waiwai, e like me mākou i hana wale he iterator, aole i ka hoʻohana 'ia.Ke compiler e ao mai e pili ana i keia ano o ka hana:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ke idiomaticʻaoʻao, e kākau i kekahi [`map`] no konaʻaoʻao ona mea e hoʻohana i ka `for` loop ole e kelepona i ka [`for_each`] iaoiaeii:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Kekahi hana maʻamau ma e loiloi i ka iterator mea e hoʻohana i ka [`collect`] papa hana e paka i ka hou ohi.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators e mai i ke e finite.E like me he kumu, he hamama-i pau ai huahelu mea he mana loa iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! He pono e hoʻohana i ka [`take`] iterator mea hoʻopili i ka huli i ka mana loa iterator i loko o ka finite hoʻokahi:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! E paʻi kēia i nā helu `0` ma o `4`, kēlā me kēia ma kā lākou laina ponoʻī.
//!
//! Bear ma ka manaʻo i epekema ma ka mana loa iterators,ʻo ia mau mea no i ka hopena hiki e hooponoponoia ia mea, mathematically i finite manawa, e ole 'ōlelo.
//! Ua hōʻike hewa, ki ina hana like e like me [`min`], i loko o ka mau hihia e noi mai ana kāʻalo ana kēlā i na hehee ai i loko o ka iterator, e paha,ʻaʻole e hoʻi ana no kekahi mana loa iterators.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh no!He loop pau ʻole!
//! // `ones.min()` ke kumu o kahi loop loop, no laila ʻaʻole mākou e hiki i kēia kiko!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;