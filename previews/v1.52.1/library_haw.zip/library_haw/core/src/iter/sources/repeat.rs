use crate::iter::{FusedIterator, TrustedLen};

/// I ka mea hou iterator i endlessly 'oe a he hookahi hehee ai.
///
/// Hoʻohana hou ka hana `repeat()` i hoʻokahi waiwai i mau a mau.
///
/// Mana loa iterators e like `repeat()` mea pinepine hoʻohana me adapters e like [`Iterator::take()`], ma ka mea e hana ia finite.
///
/// Inā ʻaʻole hoʻokomo ka ʻano element o ka iterator iā `Clone`, a i ʻole inā ʻaʻole ʻoe makemake e mālama i ka mea i hoʻomanaʻo ʻia i ka hoʻomanaʻo, hiki iā ʻoe ke hoʻohana i ka hana [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::iter;
///
/// // ka helu ʻehā 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, nō eha
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Hele finite me [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ʻO kēlā hiʻohiʻona hope loa he nui ʻehā.E ka wale i eha, eha.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... a ua pau mākou
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// An iterator e 'oe a he hehee ai endlessly.
///
/// Hana ʻia kēia `struct` e ka hana [`repeat()`].E ʻike i kāna palapala no nā mea hou aʻe.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}