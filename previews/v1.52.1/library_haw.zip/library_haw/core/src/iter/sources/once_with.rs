use crate::iter::{FusedIterator, TrustedLen};

/// Hoʻokumu i kahi iterator e hana palaualelo i kahi waiwai i hoʻokahi manawa e kahea ʻana i ka pani i hāʻawi ʻia.
///
/// Keia ia olelo hoʻohana i ke hakuloli i hookahi cia mīkini hana wāwahie i loko o ka [`chain()`] o na ia a pau o ke iteration.
/// Loaʻa paha iā ʻoe kahi iterator e uhi kokoke i nā mea āpau, akā pono ʻoe i kahi hihia keu.
/// Malia paha 'oe i kekahi kuleana pili i ka mea hana ma luna o iterators, akā, oe wale Pono e kō kekahi waiwai.
///
/// ʻAʻole like me [`once()`], hana maʻalahi kēia hana i ka waiwai ma ke noi.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::iter;
///
/// // kekahi o ka loneliest helu
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // hoʻokahi wale nō, ʻo ia kā mākou loaʻa
/// assert_eq!(None, one.next());
/// ```
///
/// Ke kaulahao pū nei me kekahi iterator ʻē aʻe.
/// E ʻōlelo mākou makemake mākou e hoʻokele ma luna o kēlā me kēia faila o ka papa kuhikuhi `.foo`, akā me kahi faila hoʻonohonoho,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // pono mākou e hoʻololi mai kahi iterator o DirEntry-s i kahi iterator o PathBufs, no laila hoʻohana mākou i ka palapala ʻāina
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 'Ānō hoʻi, mākou iterator pono mākou config waihona no
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kaulahao nā iterator ʻelua i hoʻokahi iterator nui
/// let files = dirs.chain(config);
///
/// // keia, e haawi mai a pau o ka waihona ma .foo like pono me .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator e haawi i ko he hookahi hehee ai o ke 'ano `A` e ana i ka hoakaka panina `F: FnOnce() -> A`.
///
///
/// Keia `struct` ua hana ia e ke kuleana pili i [`once_with()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}