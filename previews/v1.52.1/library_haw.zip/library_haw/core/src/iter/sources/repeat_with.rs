use crate::iter::{FusedIterator, TrustedLen};

/// Hoʻokumu i kahi iterator hou e hana hou i nā mea o ke ʻano `A` pau ʻole ma o ka noi ʻana i ka pani pani ʻia, ka repeater, `F: FnMut() -> A`.
///
/// Kāhea ka hana `repeat_with()` i ka mea hana hou a pinepine.
///
/// Mana loa iterators e like `repeat_with()` mea pinepine hoʻohana me adapters e like [`Iterator::take()`], ma ka mea e hana ia finite.
///
/// Inā ka hehee ai 'ano o ka iterator oe e pono ai e kakau mai [`Clone`], a me ia mea OK, e malama i ke kumu hehee ai ma ka hoomanao, oe e ke kuleana pili i [`repeat()`] ma ke hoʻohana' ia.
///
///
/// An iterator hua mai la ia e `repeat_with()` mea,ʻaʻole he [`DoubleEndedIterator`].
/// Inā makemake ʻoe iā `repeat_with()` e hoʻihoʻi i kahi [`DoubleEndedIterator`], e ʻoluʻolu e wehe i kahi pilikia GitHub e wehewehe nei i kāu hihia hoʻohana.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::iter;
///
/// // e ka lawe mākou i kekahi waiwai o keʻano i mea ole `Clone` paha i aʻole 'oe makemake i ka i loko o iaiyoe pono nō, no ka mea, ua pipiʻi:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // he mau cia mau loa:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// E ho ohana i mutation a hele finite:
///
/// ```rust
/// use std::iter;
///
/// // Mai ka zeroth i ke kolu o ka mana o ka elua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... a ua pau mākou
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// An iterator e 'oe a oihana mua o ke' ano `A` endlessly e ana i ka hoakaka panina `F: FnMut() -> A`.
///
///
/// Keia `struct` ua hana ia e ke kuleana pili i [`repeat_with()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}