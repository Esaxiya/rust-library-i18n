use crate::{fmt, iter::FusedIterator};

/// I ka mea hou iterator kahi kēlā me kēia ka mea i hahai ana ka mea mamuli o kekahi ikamu ua Me ka nānā 'ana ma luna o ka māhele ma mua o kekahi.
///
/// Ke iterator hoomaka me ka haawi mua mau ukana (ina kekahi) a kahea aku me ka haawi `FnMut(&T) -> Option<T>` panina e compute kēlā'ikamu ka hope.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Inā keia kuleana pili i hoi `impl Iterator<Item=T>` mea hiki ke nānā 'ana i `unfold`, aʻaʻole e pono ai i ka mea laʻa type.
    //
    // Eia naʻe me ka inoa `Successors<T, F>` hoailona e leie aku ia ia e `Clone` ia `T` a me `F` mea.
    Successors { next: first, succ }
}

/// ʻO kahi iterator hou kahi i helu ʻia ai kēlā me kēia mea i kū i ka hopena.
///
/// Keia `struct` ua hana ia e ke kuleana pili i [`iter::successors()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}