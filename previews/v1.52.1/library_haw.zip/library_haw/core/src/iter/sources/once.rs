use crate::iter::{FusedIterator, TrustedLen};

/// Hana i mea iterator e haawi i ko ka hehee ai me kēia nui kekahi manawa.
///
/// Keia ia olelo hoʻohana i ke hakuloli i hookahi waiwai i loko o ka [`chain()`] o na ia a pau o ke iteration.
/// Loaʻa paha iā ʻoe kahi iterator e uhi kokoke i nā mea āpau, akā pono ʻoe i kahi hihia keu.
/// Malia paha 'oe i kekahi kuleana pili i ka mea hana ma luna o iterators, akā, oe wale Pono e kō kekahi waiwai.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::iter;
///
/// // kekahi o ka loneliest helu
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // hoʻokahi wale nō, ʻo ia kā mākou loaʻa
/// assert_eq!(None, one.next());
/// ```
///
/// Ke kaulahao pū nei me kekahi iterator ʻē aʻe.
/// E ʻōlelo mākou makemake mākou e hoʻokele ma luna o kēlā me kēia faila o ka papa kuhikuhi `.foo`, akā me kahi faila hoʻonohonoho,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // pono mākou e hoʻololi mai kahi iterator o DirEntry-s i kahi iterator o PathBufs, no laila hoʻohana mākou i ka palapala ʻāina
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 'Ānō hoʻi, mākou iterator pono mākou config waihona no
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // kaulahao nā iterator ʻelua i hoʻokahi iterator nui
/// let files = dirs.chain(config);
///
/// // keia, e haawi mai a pau o ka waihona ma .foo like pono me .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// An iterator e haawi i ko ka hehee ai me kēia nui kekahi manawa.
///
/// Hana ʻia kēia `struct` e ka hana [`once()`].E ʻike i kāna palapala no nā mea hou aʻe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}