use crate::fmt;

/// Hoʻokumu i kahi iterator hou kahi e kāhea ai kēlā me kēia iteration i ka panina i hāʻawi ʻia `F: FnMut() -> Option<T>`.
///
/// Ua apono 'e pili ana i ka oihana iterator me kekahi hana me ka hoʻohana' ana i ka nui verbose Ka Mooolelo no e pili ana i ka mea laʻaʻano a me ka hoʻokō i ka [`Iterator`] trait no ka mea.
///
/// E hoʻomaopopo ʻaʻole hana ka iterator `FromFn` i nā manaʻo e pili ana i ka lawena o ka pani ʻana, a no laila ʻaʻole hoʻokō ʻo conservative i [`FusedIterator`], a i ʻole hoʻokahuli iā [`Iterator::size_hint()`] mai kāna `(0, None)` paʻamau.
///
///
/// Hiki i ka pani ʻana ke hoʻohana i nā kiʻi a me kona kaiapuni e nānā i ka mokuʻāina ma nā ʻano iterations.Kaukaʻi ʻia pehea e hoʻohana ai ka iterator, koi paha kēia i ka kikoʻī ʻana i ka huaʻōlelo [`move`] ma ka pani.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// E iho mai ka ka hou hoʻokō i ka eea iterator mai [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Xi mākou helu.ʻO kēia ke kumu a mākou i hoʻomaka ai ma ka ʻole.
///     count += 1;
///
///     // E nānā inā ua pau kā mākou helu ʻana ʻaʻole paha.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// An iterator kahi kēlā me kēia iteration kahea ka hoakaka panina `F: FnMut() -> Option<T>`.
///
/// Hana ʻia kēia `struct` e ka hana [`iter::from_fn()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}