use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Keia trait hoʻolako transitive ke kōkua o ke kumu-kahua i loko o ka interator-mea hoʻopili pipeline ma lalo o nā hana i
/// * ka iterator kumu `S` iho lapaʻau `SourceIter<Source = S>`
/// * aia kahi ʻelele e hoʻokō ana i kēia trait no kēlā me kēia adapter i ka paipu ma waena o ke kumu a me ka mea kūʻai mai pipeline.
///
/// Ke loaʻa nei kahi kumu waiwai iterator (i kapa ʻia ʻo `IntoIter`) a laila hiki ke hoʻohana pono ʻia no ka hana kūikawā ʻana i ka [`FromIterator`] hoʻokō a i ʻole ke kiʻi ʻana i nā mea i koe ma hope o ka pau ʻana o ka iterator.
///
///
/// Note i implementations mai i pono i ka i komo i ka pā-loa kumu o ka pipeline.Kuhi paha kahi mea hoʻopili waena waena i ka ʻāpana i kahi ʻāpana o ka paipu a hōʻike i kona waihona waho ma ke ʻano he kumu.
///
/// Ke trait Ua unsafe no ka mea, implementers pono kokua hou maluhia waiwai.
/// E nānā i [`as_inner`] no lāliʻi.
///
/// # Examples
///
/// Kiʻi 'ia i ka hapa' ia 'hoopauia kahi:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// A kahi kahua i loko o ka iterator pipeline.
    type Source: Iterator;

    /// Loaʻa nā i ke kumu o ka iterator pipeline.
    ///
    /// # Safety
    ///
    /// Implementations o ka Pono e hoʻi i ka ua mutable pili no ko lakou wa e ola ana, ke ole UAIAaIN ma ka Caller.
    /// Callers e puku wale i ka olua ia mea, oki iho la ka iteration, a mai hapai ku i ka iterator pipeline ma hope o extracting i ke kumu.
    ///
    /// Keia mea iterator adapters ke hilinai aku maluna o ke kumu,ʻaʻole hoʻololi i iteration akā, hiki ole e hilinai aku maluna o ia i loko o kā lākou mau kulu implementations.
    ///
    /// Hoʻokō i kēia hana 'ana adapters hāʻawipio i wahi uku-wale komo i kā lākou mau kumu, a hiki wale hilinai aku maluna o hoʻohiki i ka nānā' ana ma luna o iaoia pa alimaʻAno.
    /// I ka nele o? Aiiui ainooiii kekahi pono i adapters pono kākoʻo i ke kumu o ka lehulehu API a hiki i ka wa a lakou i komo i kona kūloko ma.
    ///
    /// Pono nā mea e kāhea ana i kahi kumu i kēlā me kēia mokuʻāina e kūlike me kāna API lehulehu no ka mea aia nā mea hoʻopili e noho ana ma waena o ia a me ke kumu.
    /// I loko o kahi adapter i pau i ka nui o nā mea ma mua o ka pono.
    ///
    /// Ka pono pahuhopu o kēia mau koi mea e e ka consumer o ka pipeline i
    /// * nā mea i koe i ke kumu ma hope o ka pau ʻana o ka iteration
    /// * ka paʻa i ua lilo ua hanaʻole ma ka hoʻokikina i ka hoopau ana iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Kahi adapter iterator nāna e hoʻopuka i nā huahana i ka lōʻihi o ka iterator e hoʻokumu i nā waiwai `Result::Ok`.
///
///
/// Inā i hewa ua pilikia, i ka iterator mahana, a me ka hewa ua waiho waho.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Ke kō i ka hāʻawi iterator me ina mea, nolaila, he `T` kahi o ka `Result<T, _>`.
/// E kū kekahi mau hewa i ka iterator o loko a ʻo ka hopena holoʻokoʻa e hewa ana.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}