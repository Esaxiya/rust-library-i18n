//! Ka `Clone` trait no ke ano i ole e hiki 'implicitly mānewanewa'.
//!
//! Ma Rust, kekahi mea ano e "implicitly copyable" a me ka wā e hāʻawi aku iā lākou a me kekahi, ia lakou i kekahi manaʻo hoʻopiʻi kū'ē, me ka pa alima e kiʻi i ke kope, e waiho ana i ka palapala cia ma ka wahi.
//! Mau ano mai i koi e auaaeaiea e kope a me ka mai ole i finalizers ('o ia hoʻi, ka mea e apo ia waiwai poho a hoʻokō i [`Drop`]), no laila, ke compiler E hoomanao i ia nike a me ka maluhia, e kope.
//!
//! No nā 'ano kope pono e i kūlike loa, ma ke Kuikahi hoʻokō i ka [`Clone`] trait, a kii aku la i ka [`clone`] hana.
//!
//! [`clone`]: Clone::clone
//!
//! ʻO kahi laʻana hoʻohana maʻamau:
//!
//! ```
//! let s = String::new(); // Hoʻokomo ke ʻano string iā Clone
//! let copy = s.clone(); // no laila, ua hiki clone ia
//! ```
//!
//! E hoʻohana maʻalahi i ka Clone trait, hiki iā ʻoe ke hoʻohana iā `#[derive(Clone)]`.Laʻana:
//!
//! ```
//! #[derive(Clone)] // ua hui ka Clone trait i Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // a me kēia manawa, ua hiki clone ia!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ʻO trait maʻamau no ka hiki ke hana maʻalahi i kahi mea.
///
/// ʻO nā mea ʻokoʻa mai [`Copy`] i kēlā [`Copy`] implicit a pipiʻi loa, ʻoiai ʻo `Clone` e hōʻike mau ana a ʻaʻole paha he kumukūʻai.
/// I mea e hoʻokō ai i kēia mau ʻano, ʻaʻole ʻae ʻo Rust iā ʻoe e hoʻohana hou iā [`Copy`], akā hiki paha iā ʻoe ke hoʻohana hou iā `Clone` a holo i ka pāʻālua kūpono ʻole.
///
/// No ka mea ʻoi aku ka nui o `Clone` ma mua o [`Copy`], hiki iā ʻoe ke hana maʻalahi iā [`Copy`] i `Clone` pū kekahi.
///
/// ## Derivable
///
/// Keia trait hiki ke hoʻohana 'ia me `#[derive]` ina nā mahinaʻai i `Clone`.ʻO ka hoʻokō `derive`d o [`Clone`] kāhea iā [`clone`] ma kēlā me kēia kahua.
///
/// [`clone`]: Clone::clone
///
/// No kahi kumu hana, `#[derive]` e hoʻokō pono iā `Clone` i ke ʻano me ka hoʻohui ʻana i ka `Clone` i hoʻopaʻa ʻia ma nā palena generic.
///
/// ```
/// // `derive` mea hana Clone no ka Heluhelu ʻana<T>ia T o Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Pehea hiki au hoʻokō `Clone`?
///
/// Ano i mea [`Copy`] e i ka AICIeOEOI manaʻo o `Clone`.More formally:
/// ina `T: Copy`, `x: T`, a me `y: &T`, laila `let x = y.clone();` mea like paha ke `let x = *y;`.
/// Manual implementations e e hoomau, e kokua ana i keia invariant;nae, unsafe kivila pono ole hilinai aku maluna o ka mea e hōʻoia 'iaiyoe palekana.
///
/// An hana mea he nōhie struct paʻa ana i kekahi kuleana pili i laʻau kuhikuhi.I kēia hihia, ʻaʻole hiki i ka hoʻokō ʻana o `Clone` ke `derive`d, akā hiki ke hoʻokō ʻia e like me:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Nā mea hoʻokō hou aʻe
///
/// Ma waho aʻeo ia ka [implementors listed below][impls], i kēia 'ano i hoʻokō i `Clone`:
///
/// * Launch'ikamuʻAno ('o ia hoʻi, ka mea okoa ke ano i ho'ākāka' ana no kēlā me kēia kuleana pili i)
/// * Launch laʻau kuhikuhiʻAno (e like, `fn() -> i32`)
/// * E kaua iʻAno, no ka pau nui like 'ole, ina keʻano ikamu i mea lapaʻau `Clone` (e like, `[i32; 123456]`)
/// * Tuple ano, ina kēlā me kēia ke keʻena i mea lapaʻau `Clone` (e like, `()`, `(i32, bool)`)
/// * PaninaʻAno, ina e hoʻopio i waiwai, mai ka i hoʻolilo 'ia ai ina mea a pau e like me pio nā loina hoʻokō `Clone` lakou iho.
///   E hoʻomaopopo i nā loli i hopu ʻia e ka hōʻike kūkaʻi e hoʻokō mau i ka `Clone` (ʻoiai inā ʻaʻole ka referent)
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Hoʻihoʻi i kahi kope o ka waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str mea lapaʻau Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Hanaʻia kope-paha mai `source`.
    ///
    /// `a.clone_from(&b)` like ia me `a = b.clone()` i ka hana, akā hiki ke hoʻokahuli ʻia e hoʻohana hou i nā kumuwaiwai o `a` e hōʻalo ai i nā hoʻokaʻawale pono ʻole.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Hoʻokumu i ka macro e hoʻokumu i kahi impl o ka trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): Hoʻohana wale ʻia kēia mau kaula e#[derive] e ʻōlelo ai i kēlā me kēia māhele o kahi ʻano e hoʻokō i ka Clone a i ʻole Kope.
//
//
// Mau structs e loa hou i loko o mea hoʻohana kuhi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementations o `Clone` no primitive ano.
///
/// Implementations i ole e ho'ākāka 'ia i loko o Rust hiki i hoʻokō ma `traits::SelectionContext::copy_clone_conditions()` ma `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Kaʻana kūmole hiki ke cloned, akā, mutable kūmole *hiki ole*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Kaʻana kūmole hiki ke cloned, akā, mutable kūmole *hiki ole*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}