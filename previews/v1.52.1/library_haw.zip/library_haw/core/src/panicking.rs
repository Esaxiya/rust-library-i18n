//! Kākoʻo Panic no ka libcore
//!
//! ʻAʻole hiki i ka waihona puke nui ke wehewehe i ka panicking, akā hoʻolaha ia * panicking.
//! ʻO kēia ka mea i ʻae ʻia nā hana i loko o ka libcore iā panic, akā pono ia crate i uka pono e wehewehe i ka panicking no ka libcore e hoʻohana ai.
//! ʻO ke kikowaena o kēia manawa no ka panicking:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Kēia ho'ākāka 'ana no ka apono''ā'ā me kekahi mau memo, akā, ka mea, aole e ae no ka nele i ka `Box<Any>` waiwai.
//! (`PanicInfo` wale kekahi i ka `&(dyn Any + Send)`, no ka a mākou hoʻopiha i loko o ka mhihi waiwai i loko o 'PanicInfo: : internal_constructor`.) Ke kumu no keia mea i libcore ua ole ae i ka līkaia no.
//!
//!
//! Aia i kēia module kekahi mau hana panicking ʻē aʻe, akā ʻo kēia wale nō nā mea lang pono no ka mea hoʻopili.Hoʻopili ʻia nā panics āpau ma o kēia hana hoʻokahi.
//! Hōʻike ʻia ka hōʻailona maoli ma o ka hiʻona `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ʻO ka hoʻokō ʻana o ka libcore's `panic!` macro ke hoʻohana ʻole ʻia kahi hoʻonohonoho.
#[cold]
// mai kū i ka laina ke ʻole panic_immediate_abort e hōʻalo ai i ka bloat code ma nā pūnaewele kelepona i hiki ke hiki
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // makemake ʻia e codegen no panic ma luna o ka hālana a me nā mea hoʻopau `Assert` MIR ʻē aʻe
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // E hoʻohana i Arguments::new_v1 ma kahi o format_args! ("{}", Expr) e hoʻemi ai i ka nui ma luna.
    // ʻO ka format_args!Hoʻohana ka macro i kā Z's hōʻike trait e kākau i ka expr, ka mea e kāhea iā Formatter::pad, kahi e pono ai ke hoʻopaʻa i ke kaula a me ka pale (ʻoiai ʻaʻole hoʻohana ʻia ma aneʻi).
    //
    // E ho ohana i Arguments::new_v1 e ae i ka compiler e omit Formatter::pad mai ka auoiaea aeaie, ke ole ia mai i kekahi mau kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // pono ai no ka mea, loiloi ʻia ʻo panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // makemake ʻia e codegen no panic ma ke komo ʻana o OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ʻO ka hoʻokō ʻana o ka libcore's `panic!` macro ke hoʻohana ʻia ka formatting.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // KA MANAʻO ʻAʻole hana kēia hana i ka palena FFI;He kāhea Rust-to-Rust i hoʻonā ʻia i ka hana `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: wehewehe ʻia ʻo `panic_impl` i ka code Rust palekana a pēlā e palekana ai e kāhea.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Hana kūloko no `assert_eq!` a me `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}