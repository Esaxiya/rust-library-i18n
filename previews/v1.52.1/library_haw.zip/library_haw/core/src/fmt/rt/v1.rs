//! ʻO kēia kahi module i hoʻohana ʻia e ka ifmt!runtime.Mau hale i kinoea i kūpaʻa huihui ikehu lā i precompile waihona kaula ma mua o ka manawa.
//!
//! Mau wehewehena e like me kā lākou `ct` hoʻokoe, akā, oko i loko o ia mau mea hiki ke statically anao? Aou a me ka mea iki hoʻomākaukau leʻa no ka runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Hiki ke hoʻopili ʻia i hiki ke noi ʻia ma ke ʻano he ʻāpana o kahi ʻōnaehana hoʻonohonoho.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// PAaIEN i Contents e e hema-ua kūponoʻia.
    Left,
    /// PAaIEN i Contents e e pono-ua kūponoʻia.
    Right,
    /// PAaIEN i Contents e e-oaio?-Ua kūponoʻia.
    Center,
    /// ʻAʻole i noi ʻia kahi kaulike.
    Unknown,
}

/// Hoʻohana 'ia e [width](https://doc.rust-lang.org/std/fmt/#width) a me [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Kuhi ʻia me kahi helu maoli, mālama i ka waiwai
    Is(usize),
    /// I hoakaka ia ka hoʻohana 'ana `$` a me `*` syntaxes, hale kūʻai o ka' inideka i `args`
    Param(usize),
    /// ʻAʻole hōʻike ʻia
    Implied,
}