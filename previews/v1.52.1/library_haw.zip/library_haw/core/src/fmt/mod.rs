//! Nā pono hana no ka formatting a me ka paʻi ʻana i nā aho.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Hiki pono hoi e `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// PAaIEN i Contents e e hema-ua kūponoʻia.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// PAaIEN i Contents e e pono-ua kūponoʻia.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// PAaIEN i Contents e e-oaio?-Ua kūponoʻia.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Keʻano hoʻi e formatter ki ina hana like.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Ka hewaʻano a ua hoʻi mai, mai formatting i ka memo i loko o ke kahawai.
///
/// ʻAʻole kākoʻo kēia ʻano i ka lawe ʻana o kahi hemahema ʻē aʻe ma mua o ka loaʻa ʻana o kahi hemahema.
/// Kekahi keu 'ike pono ke hoonohonoho ia e pū i hiki ma kekahi'ē aʻe ano.
///
/// ʻO kahi mea nui e hoʻomanaʻo ai ʻaʻole pono e huikau ka ʻano `fmt::Error` me [`std::io::Error`] a i ʻole [`std::error::Error`], a loaʻa paha iā ʻoe i ka laulā.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait no ke kākau ʻana a i ʻole ka ʻohi ʻana i loko o nā buffer a ʻae i nā Unicode.
///
/// Ke ʻae wale nei kēia trait i ka ʻikepili UTF-8 - encode a ʻaʻole ʻo [flushable].
/// Inā 'oe makemake wale eʻae Unicode a oe hana ole e pono flushing, oe e hoʻokō i keia trait;
/// i ʻole ʻoe e hoʻokō iā [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Kākau i kahi ʻāpana kaula i loko o kēia mea kākau, e hoʻihoʻi ana inā ua kūleʻa ka palapala.
    ///
    /// Hiki ke kūleʻa wale kēia hana inā kākau maikaʻi ʻia ka ʻāpana kaula āpau, a ʻaʻole hoʻi e hoʻi kēia ala a kākau ʻia nā ʻikepili āpau a i ʻole e loaʻa kahi hewa.
    ///
    ///
    /// # Errors
    ///
    /// Kēia papa, e hoi hou i ka manawa o [`Error`] ma ka hewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Kākau i ka [`char`] i loko o kēia mea kākau, hoi mai paha ka palapala pomaikai ae la lakou.
    ///
    /// A hookahi [`char`] i e encoded like oi ma mua o kekahiʻai.
    /// Hiki ke kūleʻa wale kēia hana inā kākau maikaʻi ʻia ke kaʻina byte āpau, a ʻaʻole hoʻi e hoʻi kēia ala a kākau ʻia nā ʻikepili āpau a i ʻole e loaʻa ana kahi kuhihewa.
    ///
    ///
    /// # Errors
    ///
    /// Kēia papa, e hoi hou i ka manawa o [`Error`] ma ka hewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Pākuʻi no ka hoʻohana ʻana o ka [`write!`] macro me nā mea hoʻokō o kēia trait.
    ///
    /// Kēia hana e nui ole e 'auʻa' hana lima, aka, ma ka [`write!`] nunui iho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Hoʻonohonoho no ka hōʻano ʻana.
///
/// Hōʻike kahi `Formatter` i nā koho like ʻole e pili ana i ka hōʻano ʻana.
/// Mea hoʻohana mai i kükulu 'Formatter`s' ana;he mutable pili i kekahi ua hala aku i ka `fmt` ano o nā mea a pau formatting traits, e like [`Debug`] a me [`Display`].
///
///
/// E launa pū me `Formatter`, e kāhea ʻoe i nā ʻano hana like ʻole e hoʻololi i nā koho like ʻole e pili ana i ka hōʻano ʻana.
/// No nā laʻana, e ʻoluʻolu e ʻike i nā palapala o nā kiʻina i wehewehe ʻia ma `Formatter` ma lalo.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// ʻO ka hoʻopaʻapaʻa ka mea nui i hoʻonui ʻia me ka hoʻohana ʻana i kahi hana formatting, e like me `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Kēia struct ho i ka nōhie "argument" a ua laweʻia e ka Xprintfʻohana o ka hana.Ua loaʻa i ka papa, e waihona i ka haawi waiwai.
/// Ia i hoʻouluulu manawa ka mea, ua i hōʻoiaʻiʻo aku i ka papa, a me ka waiwai i ka pololeiʻano, a laila, i kēia struct ua hoʻohana 'ia e canonicalize manaʻo hoʻopiʻi kū'ē i ka type hoʻokahi.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Hōʻoia kēia i kahi waiwai paʻa hoʻokahi no ka kuhikuhi kuhikuhi e pili ana me indices/counts i ka hanana hōʻano.
//
// E hoʻomaopopo he pololei ʻole kahi hana i wehewehe ʻia e like me ka hana ʻana i nā inoa mau ʻole i inoa inoa ʻole ʻia me ka hoʻohaʻahaʻa ʻana i LLVM IR, no laila ʻaʻole i manaʻo ʻia kā lākou kamaʻilio nui iā LLVM a no laila hiki ke kuhi hewa ʻia ka cast as_usize.
//
// I ka mea, ke ike ole e kahea as_usize i 'ole-usize i loaʻa ka' ikepili (e like me ka mea ana i kūpaʻa hanauna o ka formatting kekahi manaʻo hoʻopiʻi kū'ē), no laila, i kēia mea wale no i hou ponopono.
//
// Makemake mua mākou e hōʻoia i ka helu kuhikuhi ma `USIZE_MARKER` i kahi helu e pili ana *wale nō* i nā hana e lawe pū iā `&usize` ma ke ʻano o kā lākou paio mua.
// Ke read_volatileʻaneʻi e hōʻoiaʻiʻo ana mākou hiki maluhia hoomakaukau mai i ka usize mai i ka hala i maopopo kahi, a i keia helu wahi hana iʻoi ma ka pili-usize lawe kuleana pili i.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // Maluhia: ptr mea he olua
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // Maluhia: `mem::transmute(x)` mea pakele no ka mea,
        //     1. `&'b T` malama i ka wa e ola ana ka mea originated me `'b` (no laila, e like me ka ole i ka wa e ola ana unbounded)
        //     2.
        //     `&'b T` a ʻo `&'b Opaque` ka hoʻonohonoho hoʻomanaʻo like (ke `T` ʻo `Sized`, ʻoiai ma aneʻi) palekana ʻo `mem::transmute(f)` ma muli o `fn(&T, &mut Formatter<'_>) -> Result` a me `fn(&Opaque, &mut Formatter<'_>) -> Result` ka ABI like (ʻoiai ʻo `T` `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // Maluhia: The `formatter` ke kahua ua wale kau i USIZE_MARKER ina
            // i ka waiwai o ka usize, no laila, i kēia mea pakele
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// loaʻa nā hae i ka mana v1 o format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// na format_args! () nunui I ka hoʻohana 'ana i, keia kuleana pili i ua hoʻohana' ia paha i ka 'oihana' ole.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// He kuleana pili i ua hoʻohana 'ia ke koho' nonstandard formatting kiko'î.
    /// Ka `pieces` kaua pono e ma ka liʻiliʻi loa i lōʻihi me `fmt` e kükulu i kekahi palapala i pololei ia 'oihana' ole.
    /// Nō hoʻi, i kekahi `Count` i loko o `fmt` i ka `CountIsParam` paha `CountIsNextParam` i ka wahi i kekahi manaʻo hoʻopiʻi hana me `argumentusize`.
    ///
    /// Eia naʻe, ʻaʻole e hana i ka unsafety unsafety, akā e nānā pono ʻole i ka pono ʻole.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Koho i ka lōʻihi o ka formatted kikokikona.
    ///
    /// Hoʻohana ʻia kēia e hoʻohana no ka hoʻonohonoho ʻana i ka mana `String` mua i ka hoʻohana ʻana i `format!`.
    /// Note: keia mea aole ka lalo loa, aole hoi i luna e paa ana.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Inā hoʻomaka ke kaula hōʻano me kahi paio, mai hoʻokae i kekahi mea, inā ʻaʻole nui ka lōʻihi o nā ʻāpana.
            //
            //
            0
        } else {
            // Aia kekahi mau hoʻopaʻapaʻa, no laila ʻo kekahi pahu hou e hoʻoliʻiliʻi i ke aho.
            //
            // E pale i, ua oe "pre-doubling" i ka 'auhau' aneʻi.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Kēia 'ole ho i ka maluhia precompiled hoʻokolohua o ka waihona kui a me kona manaʻo hoʻopiʻi kū'ē.
/// ʻAʻole hiki ke hana ʻia kēia i ka wā holo no ka mea ʻaʻole hiki ke hana palekana ʻia, no laila ʻaʻole hāʻawi ʻia nā mea kūkulu a pilikino nā kahua e pale i ka hoʻololi.
///
///
/// E hana palekana ka [`format_args!`] macro i kahi hanana o kēia ʻano.
/// Ka nunui validates ka waihona kaula i i hoʻouluulu-manawa no laila, 'ae o ka [`write()`] a me [`format()`] hana hiki e maluhia hana.
///
/// Hiki iā ʻoe ke hoʻohana i ka `Arguments<'a>` e hoʻi ai ʻo [`format_args!`] i nā hanana `Debug` a me `Display` e like me ka mea i ʻike ʻia ma lalo.
/// Ke kumu no hoi E hoike mai i `Debug` a me `Display` waihona i ka mea hookahi: ka interpolated waihona kaula ma `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Format kui apana e kakau.
    pieces: &'a [&'static str],

    // Nā kikoʻī Placeholder, a i ʻole `None` inā paʻamau nā kikoʻī āpau (e like me "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Nā hoʻopaʻapaʻa hōʻeuʻeu no ka interpolation, e interleaved me nā ʻāpana aho.
    // (ʻO kēlā me kēia hoʻopaʻapaʻa i mua ʻia e kahi ʻāpana aho.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// E kiʻi i ka formatted kaula, ina ka mea,ʻaʻohe manaʻo hoʻopiʻi kū'ē i ka e formatted.
    ///
    /// Hiki ke hoʻohana i kēia i mea e hōʻalo ai i nā hoʻokaʻawale i ka hihia nui ʻole.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` E waihona i ka auoiaea i loko o ka programmer-ʻalo maila nō lākou, debugging pōʻaiapili.
///
/// Ano laulā, e olelo ana, e pono e `derive` he `Debug` manaʻo.
///
/// Ke hoʻohana ʻia me kahi hōʻike kikoʻī ʻokoʻa `#?`, paʻi maikaʻi ʻia ka hoʻopuka.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Hiki ke hoʻohana ʻia kēia trait me `#[derive]` inā hoʻokomo nā kahua āpau i `Debug`.
/// I ka `derive`d no structs, ka mea e hana i ka inoa o ka `struct`, laila `{`, laila, he comma-kaawale papa inoa o ka inoa a me kēlā kahua ka `Debug` waiwai, laila `}`.
/// No ka `enum`s, ka mea e hana i ka inoa o ka Lolina, a, ina pono, `(`, laila, i ka `Debug` aiee o nā mahinaʻai, a laila `)`.
///
/// # Stability
///
/// ʻAʻole kūpaʻa nā mana `Debug` i loaʻa, a no laila e loli paha me nā mana future Rust.
/// Eia kekahi, `Debug` implementations o ke ano i hoakaka ia ma ka maʻamau hale waihona puke ('libstd`, `libcore`, `liballoc`, etc.) e i ka pilina paʻa, a ua hiki no hoi hoʻololi me future Rust wale nō.
///
///
/// # Examples
///
/// Napuelua ka manaʻo:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// E hoʻokō lima ʻana:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Aia kekahi mau ʻano hana kōkua ma ka [`Formatter`] struct e kōkua iā ʻoe me nā hoʻokō lima, e like me [`debug_struct`].
///
/// `Debug` implementations hoʻohana 'ana i kekahi `derive` a me ka debug hana API ma [`Formatter`] kākoʻo nani-pai ana ka hoʻohana' ana i ka 'ē aʻe hae: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Pai-paʻi me `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// E hoʻokaʻawale aʻe Module e reexport i ka nunui `Debug` mai prelude me ka trait `Debug`.
pub(crate) mod macros {
    /// Loaa nunui hoʻomakaʻia ka impl o ka trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format Ka trait no ka nele waihona, `{}`.
///
/// `Display` Ua like ia [`Debug`], akā, `Display` mea no ka hoʻohana-alo auaiaea, a no laila, hiki ole ke loko.
///
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Hoʻokō `Display` ma kekahiʻano.
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Ka `Octal` trait E waihona kona auoiaea like me ka helu ana ma base-8.
///
/// No nā helu helu kau inoa ʻia (`i8` a i `i128`, a me `isize`), hoʻonohonoho ʻia nā waiwai maikaʻi ʻole e like me ke ʻano o ke ʻano o ke ʻano o ke kōlua.
///
///
/// Ka 'ē aʻe hae, `#`, kō ka `0o` ma ke alo o ka auoiaea.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// XIX. OAaEeIeIAaIAeO me `i32`:
///
/// ```
/// let x = 42; // ʻO 42 ka '52' i ka ʻokala
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Hoʻokō `Octal` ma kekahiʻano.
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // elele 'o ia i32 ka manaʻo
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Ka `Binary` trait E waihona kona auoiaea like me ka helu ma ka aeaie.
///
/// No ka primitive kakau inoa integers ([`i8`] i [`i128`], a me [`isize`]), e formatted io aiee like me ka mau o ka hoʻokō e hoohalike ai.
///
///
/// Ka 'ē aʻe hae, `#`, kō ka `0b` ma ke alo o ka auoiaea.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// XIX. OAaEeIeIAaIAeO me [`i32`]:
///
/// ```
/// let x = 42; // 42 o '101010' ma aeaie
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Ke hoʻokomo nei i `Binary` ma kahi ʻano:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // elele 'o ia i32 ka manaʻo
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Pono ka `LowerHex` trait e hoʻolālā i kāna mea i puka ma ke ʻano he helu i ka hexadecimal, me `a` ma o `f` ma ka haʻahaʻa.
///
/// No nā helu helu kau inoa ʻia (`i8` a i `i128`, a me `isize`), hoʻonohonoho ʻia nā waiwai maikaʻi ʻole e like me ke ʻano o ke ʻano o ke ʻano o ke kōlua.
///
///
/// ʻO ka hae ʻē aʻe, `#`, hoʻohui i kahi `0x` i mua o ka hopena.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// XIX. OAaEeIeIAaIAeO me `i32`:
///
/// ```
/// let x = 42; // 42 o '2a' ma hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Ke hoʻokomo nei i `LowerHex` ma kahi ʻano:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // elele 'o ia i32 ka manaʻo
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Pono ka `UpperHex` trait e hoʻolālā i kāna puka ma ke ʻano he helu i ka hexadecimal, me `A` ma o `F` ma ka hihia kiʻekiʻe.
///
/// No nā helu helu kau inoa ʻia (`i8` a i `i128`, a me `isize`), hoʻonohonoho ʻia nā waiwai maikaʻi ʻole e like me ke ʻano o ke ʻano o ke ʻano o ke kōlua.
///
///
/// ʻO ka hae ʻē aʻe, `#`, hoʻohui i kahi `0x` i mua o ka hopena.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// XIX. OAaEeIeIAaIAeO me `i32`:
///
/// ```
/// let x = 42; // 42 o '2A' ma hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Ke hoʻokomo nei i `UpperHex` ma kahi ʻano:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // elele 'o ia i32 ka manaʻo
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Pono ka `Pointer` trait e hoʻolālā i kāna mea i puka ma ke ʻano he wahi hoʻomanaʻo.
/// Hōʻike maʻamau ʻia kēia ma ke ʻano he hexadecimal.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Hoʻohana maʻamau me `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // hana kēia i kekahi mea e like me '0x7f06092ac6d0'
/// ```
///
/// Hoʻokō `Pointer` ma kekahiʻano.
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // hoʻohana iā `as` e hoʻololi i kahi `*const T`, e hoʻopili ana i ka Pointer, kahi e hiki ai iā mākou ke hoʻohana
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Pono ka `LowerExp` trait e hōʻano i kāna huahana i ka nota ʻepekema me kahi `e` hihia haʻahaʻa.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Hoʻohana maʻamau me `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ʻo '4.2e1' i ka nota ʻepekema
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Ke hoʻokomo nei i `LowerExp` ma kahi ʻano:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // elele 'o ia f64 ka manaʻo
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Pono ka `UpperExp` trait e hōʻano i kāna huahana i ka nota ʻepekema me `E` hihia kiʻekiʻe.
///
/// No ka 'ike hou ma luna o formatters, ike [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Hoʻohana maʻamau me `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ʻo '4.2E1' i ka nota ʻepekema
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Hoʻokō `UpperExp` ma kekahiʻano.
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // elele 'o ia f64 ka manaʻo
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Hōʻike i ka waiwai i ka hoʻohana ʻana i ka formatter i hāʻawi ʻia.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Lawe ka hana `write` i kahi kahawai puka, a me kahi `Arguments` mea i hiki ke hoʻopili ʻia me ka `format_args!` macro.
///
///
/// E hōʻano ʻia nā hoʻopaʻapaʻa e like me ke aho i hōʻike ʻia i loko o ka kahawai i hāʻawi ʻia.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Eʻoluʻolu, e hoailona oukou i ka hoʻohana 'ana [`write!`] paha e e ahoʻia.Laʻana:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // E hiki ke hoʻohana 'ia ka paʻamau formatting kiko'î a no nā manaʻo hoʻopiʻi kū'ē.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Kela a me keia spec i ka like i kekahi manaʻo hoʻopiʻi i ua ma mua ma ke kui apana.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SAFETY: mai arg a me args.args mai nā hoʻopaʻapaʻa like,
                // ka mea e hōʻoiaʻiʻo ai i nā papa kuhikuhi ma waena o nā palena.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Aia hiki e wale kekahi trailing kui apana i koe.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SAFETY: mai nā hoʻopaʻapaʻa like nā arg a me nā args,
    // ka mea e hōʻoiaʻiʻo ai i nā papa kuhikuhi ma waena o nā palena.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Extract i ka pololei manaʻo hoʻopiʻi kū'ē
    debug_assert!(arg.position < args.len());
    // SAFETY: mai nā hoʻopaʻapaʻa like nā arg a me nā args,
    // i hoʻohiki kona inideka mea mau i loko o iho i pale a.
    let value = unsafe { args.get_unchecked(arg.position) };

    // A laila hana maoli i kahi paʻi
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SAFETY: mai ka hoʻopaʻapaʻa like nā cnt a me nā args,
            // a hoʻohiki i kēia 'inideka mea mau i loko o iho i pale a.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Nenelu loa ma hope o ka pauʻana o kekahi mea.Hoi e `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Kākau i kēia pou nenelu loa.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Makemake mākou e hoʻololi i kēia
            buf: wrap(self.buf),

            // A e hookoe mai i ua mau
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Kokua epekema hoʻohana no ka nenelu loa, a me ka manaʻoe hana formatting manaʻo hoʻopiʻi kū'ē i nā mea a pau formatting traits hiki ke hoʻohana 'ia.
    //

    /// Hana i ka pale kūpono no ka huina i hoʻoili ʻia i loko o kahi str.
    /// ʻAʻole pono ka *str* i ka hōʻailona no ka helu nui, e hoʻohui ʻia e kēia hana.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, inā paha he maikaʻi a ʻaʻohe paha ka helu helu kumu.
    /// * pākuʻina kau, ina ka '#' ano (Alternate) ua hoʻolako, keia mea i ka pākuʻina kau e hahao i loko o ke alo o ka helu.
    ///
    /// * buf, i kaʻai e kū'ē i ka helu i ua formatted i loko o
    ///
    /// Kēia papa, e pono hoike no na lepa hoakaka like hoʻi me ka palena iki ka laula.
    /// ʻAʻole ia e lawe i ka pololei.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // E Pono e wehe i "-", mai ka helu auoiaea.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Kākau i ka hoailona ina mea i koe, a laila, i ka pākuʻina kau ina mea i noi
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // ʻO ka māla `width` ʻoi aku ka nui o kahi `min-width` parameter ma kēia kiko.
        match self.width {
            // Inā loaʻa ka ole palena iki lōʻihi koi laila, ua hiki e kākau i nā nāʻai.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Hōʻoia inā ua 'oe ma ka palena iki laula, ina pela laila mākou e hiki no hoi e kakau iho i na nāʻai.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Hele ka hōʻailona a me ka pīpī ma mua o ka pale inā zero ka huapalapala hoʻopihapiha
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // I ole ia, o ka hoailona a me ka pākuʻina kau hele ma hope o ka nenelu loa
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Lawe kēia hana i kahi ʻāpana kaula a hoʻokuʻu iā ia i ka pale o loko ma hope o ka hoʻopili ʻana i nā hae hoʻoliʻiliʻi pili i kuhikuhi ʻia.
    /// Nā lepa ike no nōhie kaula i:
    ///
    /// * laula, ka palena iki laula o ka mea e kī
    /// * fill/align - mea, e hoʻokuʻu akula, a ma kahi e hoʻokuʻu akula ia ina ke kaula i hoʻolako pono ai e e ka nenelu loa
    /// * miomio, i ka i kā mākou lōʻihi ia kī, ke kaula ua truncated ina ia mea hou ma mua o kēia lōʻihi
    ///
    /// Nō hoʻi i kēia papa ignores ka `flag` kiko'î.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // E hōʻoia i ka loaʻa 'o ka hoʻokēʻai ala i ke alo
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Hiki ke unuhi ʻia ka māla `precision` ma ke ʻano he `max-width` no ka hōʻano ʻana i ke aho.
        //
        let s = if let Some(max) = self.precision {
            // Inā mākou kui mea hou i ka miomio, laila mākou e loaʻa truncation.
            // Eia nō naʻe nā hae ʻē aʻe e like me `fill`, `width` a me `align` pono e hana e like me ka mau.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVMʻaneʻi hiki ole hooiaio i `..i` e ole panic `&s[..i]`, akā, ua ike i ka mea hiki ole panic.
                // E hoʻohana iā `get` + `unwrap_or` e hōʻalo iā `unsafe` a i ʻole e hoʻokuʻu i kekahi code e pili ana iā panic ma aneʻi.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // ʻO ka māla `width` ʻoi aku ka nui o kahi `min-width` parameter ma kēia kiko.
        match self.width {
            // Inā mākou e makemake e ma lalo o ka i kā mākou lōʻihi, a laila kaʻaʻohe palena iki lōʻihi koi, a laila, ua hiki e hoʻokuʻu akula i ke kaula
            //
            None => self.buf.write_str(s),
            // Inā mākou ma lalo o ka laulā nui, nānā inā ʻoi aku mākou i ka laulā liʻiliʻi, inā pēlā e maʻalahi e like me ka hoʻokuʻu ʻana i ke aho.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Inā mākou makemake e ma lalo o nā ka i kā mākou, a me ka palena iki laula, laila, hoʻopiha i ka palena iki laula me ka hoakaka kaula + kekahi hoʻopololei.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// E kakau iho i ka mālama '-nenelu loa, a hoʻi i ka unwritten kia-nenelu loa.
    /// ʻO nā mea e kelepona ana ke kuleana no ka hōʻoia ʻana i nā pale kau ma hope o ka mea i uhi ʻia.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// I ka formatted māhele, a pili i ka nenelu loa.
    /// Kuhi i ka Caller ano i ana i nā māhele i koi 'ia e neʻe, no laila, ua `self.precision` hiki ke AOON.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // no ka mea, o ka hoailona-Ike e Aʻohe nenelu loa, ua hoʻihoʻi i ka hoailona mua a me ka hoi me ina mākou he hoailona ole, mai ke kumu mai.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // hele mua kahi hōʻailona
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // wehe i ka hoailona o ka formatted wahi
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // hele nā ʻāpana i koe ma o ke kaʻina padding maʻamau.
            let len = formatted.len();
            let ret = if width <= len {
                // i ka nenelu loa
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ʻo kēia ka hihia maʻamau a lawe mākou i kahi pōkole
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SAFETY: Hoʻohana ʻia kēia no `flt2dec::Part::Num` a me `flt2dec::Part::Copy`.
            // ʻO maluhia, e hana no `flt2dec::Part::Num` mai kela Mike Char `c` mea ma waena o `b'0'` a me `b'9'`, a 'o ia hoʻi `s` mea i pololei ia UTF-8.
            // Maluhia paha ia i ka hana e hoʻohana no `flt2dec::Part::Copy(buf)` ʻoiai ʻo `buf` ka ASCII maʻamau, akā hiki i kekahi ke hele i kahi waiwai maikaʻi ʻole no `buf` i `flt2dec::to_shortest_str` ʻoiai he hana ākea ia.
            //
            // FIXME: Ike ai i ko keia hiki ka hopena ma UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zeroes
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Kākau i kekahi ʻikepili i ka buffer kumu i loaʻa i loko o kēia formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Ua like kēia me:
    ///         // kahakaha iho! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Kākau i kahi ʻike i hōʻano ʻia i kēia hanana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Hae no ka formatting
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Hoʻohana ʻia ke ʻano e like me 'fill' i kēlā me kēia manawa ke kau pono.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Mākou i hoʻopololei i ka akau me ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flag e hoike ana i ke ano o ka hoʻopololei i noi aku ai.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Kohoʻia i hoakaka ia helu laula i ka auoiaea e ia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Inā mākou i loaa i ka laula, ua hana ia
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Inā ʻaʻole mākou e hana i kahi mea kūikawā
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Kohoʻia i hoakaka ia e neʻe no ka laulā ano.
    /// ʻOkoʻa, ka laulā nui no nā ʻano aho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Inā mākou i loaa i ka miomio, ua hana ia.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Ole mākou i ka paʻamau i 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Hoʻoholo inā Ua hoakaka ia ka `+` ia? Aiina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Hoʻoholo inā Ua hoakaka ia ka `-` ia? Aiina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Makemake ʻoe i kahi hōʻailona hōʻemi?Loaʻa i hoʻokahi!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Hoʻoholo inā Ua hoakaka ia ka `#` ia? Aiina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Hoʻoholo inā Ua hoakaka ia ka `0` ia? Aiina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Hōʻalo mākou i nā koho a ka mea hoʻohuli.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: E hoʻoholo i nā lehulehu API mākou makemake no kēia mau hae.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Hana i ka hana, ai kukulu [`DebugStruct`] ke hoʻololi e kōkua me ka haku o [`fmt::Debug`] implementations no structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Hoʻokumu i kahi mea hana `DebugTuple` i hoʻolālā ʻia e kōkua me ka hoʻokumu ʻana i nā hoʻokō `fmt::Debug` no nā hana tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Hana i ka hana, ai kukulu `DebugList` ke hoʻololi e kōkua me ka haku o `fmt::Debug` implementations no ka papa-me nā hale.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Hana i ka hana, ai kukulu `DebugSet` ke hoʻololi e kōkua me ka haku o `fmt::Debug` implementations no ka huapalapala-me nā hale.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// I kēia laʻana ʻoi aku ka paʻakikī, hoʻohana mākou i [`format_args!`] a me `.debug_set()` e kūkulu i kahi papa inoa o nā lima hoʻokūkū.
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Hana i ka hana, ai kukulu `DebugMap` ke hoʻololi e kōkua me ka haku o `fmt::Debug` implementations no ka palapala-me nā hale.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Nā hana o ka hoʻokumu ʻōnaehana traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Inā Mike Char e pono ai pakele, poni o laila, a hiki backlog a me ka palapala, e ae lele
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Ka mea 'ē aʻe hae ua ua malamaia lakou nei, e LowerHex like i special-ia Kû paha i ka pākuʻina kau me 0x.
        // Hoʻohana mākou ia e hana inā ʻaʻole a hoʻonui paha ka zero, a laila hoʻonohonoho ʻole ʻia e kiʻi i ka pākuʻina.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Manaʻo o Display/Debug no kela kāna mau 'ōleloʻAno

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Hoʻolālā ʻē ʻia ʻo RefCell i hiki ʻole iā mākou ke nānā i kāna waiwai ma aneʻi.
                // Hōʻike i kahi wahi.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Inā 'oe e ho'āʻo ai manao e noho maanei, e nana kahi i ka core/tests/fmt.rs waihona, ka mea,' o ka hailona hiki mua e pili ana a pau o ka hale a rt::Piece ʻaneʻi.
//
// Aia kekahi mau ho'āʻo ma ka hoʻokaʻawale crate, no kēlā mau mea e pono ai ka hoʻokaʻawale.