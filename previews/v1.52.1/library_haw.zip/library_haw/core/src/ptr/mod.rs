//! Mālama ʻelima i ka hoʻomanaʻo ʻana ma o nā kuhikuhi maka.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Lawe nā hana he nui i kēia kōmike i nā kuhi maka he mau hoʻopaʻapaʻa a heluhelu mai a kākau iā lākou.No ka palekana o kēia, pono *kuhikuhi* kēia mau kuhikuhi.
//! Pili paha ke kuhikuhi i ka hana e hoʻohana ʻia ai ia (heluhelu a kākau paha), a me ka nui o ka hoʻomanaʻo i kiʻi ʻia (ie, ehia mau byte i read/written).
//! Hoʻohana ka hapa nui o nā hana i `*mut T` a me `* const T` e kiʻi ai i hoʻokahi wale nō waiwai, a laila haʻalele ka palapala i ka nui a manaʻo kuhi ʻia ia he `size_of::<T>()` bytes.
//!
//! ʻAʻole hoʻoholo ʻia nā lula kikoʻī no ka pono.ʻO nā hōʻoia i hāʻawi ʻia i kēia kiko he liʻiliʻi loa:
//!
//! * A [null] laʻau kuhikuhi o *loa* i pololei ia,ʻaʻole hiki no accesses o [size zero][zst].
//! * No ka laʻau kuhikuhi ia e lilo, ia mea pono, akā,ʻaʻole manawa lawa, i ka laʻau kuhikuhi e *dereferenceable*: ka iaiyoe huahelu o ka haawi nui e hoʻomaka ana i ka laʻau kuhikuhi pono a pau ia i loko o nā palena o ka hookahi anao? Aou mea.
//!
//! E hoʻomaopopo ma Rust, kēlā me kēia ʻano (stack-allocated) i manaʻo ʻia he mea hoʻokaʻawale ʻia.
//! * ʻOiai no nā hana o [size zero][zst], pono ʻole ke kuhikuhi i ka hoʻomanaʻo i hana ʻia, ʻo ia hoʻi, hana i ka pointlocation i pololei ʻole nā pointers a hiki i nā hana zero-nui.
//! Eia naʻe, hoolei iho la i kekahi ole-Aʻohe helu *literal* i ka laʻau kuhikuhi mea i pololei ia no ka 'Aʻohe-pepa paia accesses, a hiki ina kekahi iaiyoe hana e nei ma ia helu wahi a meʻia deallocated.
//! Ua hoʻopili like i kākau i kou mau allocator: ka hoʻokaʻawale 'Aʻohe-pepa paia mea mea,ʻaʻole loa paakiki.
//! ʻO ke ala canonical e kiʻi ai i kahi kuhikuhi i kūpono no nā komo zero ʻole ʻo [`NonNull::dangling`].
//! * ʻO nā komo āpau i hana ʻia e nā hana i kēia kōmike he *non-atomic* ma ke ʻano o [atomic operations] i hoʻohana ʻia e hoʻopili like ma waena o nā pae.
//! Kuhi kēia i ka hana i hoʻoholo ʻole ʻia e hana i nā komo ʻelua i ka wahi like mai nā pae like ʻole ke ʻole e heluhelu ʻia nā ʻaoʻao ʻelua mai ka hoʻomanaʻo.
//! Hoʻomaopopo e pili pono ana i kēia me [`read_volatile`] a me [`write_volatile`]: ʻaʻole hiki ke hoʻohana i nā komo i hiki ke hoʻololi ʻia no ka syn-thread synchronization.
//! * Kūpono ka hopena o ka hoʻolei ʻana i kahi kuhikuhi i kahi kuhikuhi i ka wā e ola ana ka mea i hoʻokumu ʻia a ʻaʻohe kuhikuhi (hoʻohana wale ʻia nā kuhi maka) e kiʻi ai i ka hoʻomanaʻo like.
//!
//! ʻO kēia mau axioms, me ka hoʻohana akahele o [`offset`] no ka helu kuhikuhi, lawa pono e hoʻokō pono i nā mea pono he nui i ke code palekana.
//! E hoʻolako ʻia nā hōʻoia ʻoi aku ka ikaika, no ka mea e hoʻoholo ʻia ana nā rula [aliasing].
//! No ka ʻike hou aku, e ʻike i ka [book] a me ka ʻāpana i ka kuhikuhi i hoʻolaʻa ʻia iā [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Valid maka mea kuhikuhi i ho'ākāka 'ia ma luna o ka mea,ʻaʻole pono pono ua kūponoʻia (kahi "proper" hoʻopololei ua ho'ākāka' ia ma ka pointeeʻano, 'o ia hoʻi, pono e ua kūponoʻia i `mem::align_of::<T>()` `*const T`).
//! Eia nō naʻe, koi ka hapanui o nā hana i kā lākou mau paio e hoʻopili pono ʻia, a e hōʻike kikoʻī i kēia koi i loko o kā lākou palapala.
//! ʻO [`read_unaligned`] a me [`write_unaligned`] nā mea ʻokoʻa i ʻike ʻia.
//!
//! Ke koi pono kahi hana i kahi kaulike kūpono, hana ia inā ʻo ke kiʻi i ka nui 0, ʻo ia hoʻi, inā ʻaʻole pili maoli ka hoʻomanaʻo.E noʻonoʻo e hoʻohana iā [`NonNull::dangling`] i kēlā mau hihia.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Hana i ka mea luku (inā kekahi) o ke kumukūʻai kuhikuhi.
///
/// Ua like kēia me ka semantically i ke kāhea ʻana iā [`ptr::read`] a me ka hoʻolei ʻana i ka hopena, akā loaʻa nā mea maikaʻi aʻe:
///
/// * Koi ʻia * e hoʻohana i `drop_in_place` e hoʻoiho i nā ʻano unsized e like me nā mea trait, no ka mea ʻaʻole hiki ke heluhelu ʻia i ka papa a hāʻule maʻamau.
///
/// * ʻOi aku ka maikaʻi o ka optimizer e hana i kēia ma luna o [`ptr::read`] ke waiho nei i ka hoʻomanaʻo i hāʻawi lima ʻia (e laʻa me ka hoʻokō ʻana o `Box`/`Rc`/`Vec`), no ka mea ʻaʻole pono ka mea nāna e hoʻopili e hōʻoia i ke kani o ka elide kope.
///
///
/// * Hiki ke hoʻohana ʻia e hoʻokuʻu i ka ʻikepili [pinned] ke `T` ʻaʻole `repr(packed)` (ʻaʻole pono e hoʻoneʻe ʻia i ka ʻikepili pined ma mua o ka hāʻule ʻana).
///
/// ʻAʻole hiki ke hoʻokuʻu ʻia i nā helu unaligned, pono e kope ʻia i kahi wahi kūpono me ka hoʻohana mua ʻana iā [`ptr::read_unaligned`].No nā kaula i ʻūlū ʻia, hana maʻalahi ʻia kēia neʻe e ka mea hōʻuluʻulu.
/// ʻO kēia ka manaʻo ʻaʻole i hoʻokuʻu ʻia nā māla o nā kaula i hoʻopaʻa ʻia i kahi.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `to_drop` pono e [valid] no nā heluhelu ʻelua a kākau hoʻi.
///
/// * `to_drop` pono e hoʻopili pono.
///
/// * Pono ke kuhi `to_drop` e kūpono no ka waiho ʻana, ʻo ia hoʻi ka mea e pono ai e kākoʻo i nā invariants hou aʻe, pili kēia i ka ʻano.
///
/// Hoʻohui ʻia, inā ʻaʻole `T` ka [`Copy`], me ka hoʻohana ʻana i ka waiwai i kuhikuhi ʻia ma hope o ke kāhea ʻana iā `drop_in_place` hiki ke hana i nā hana i hoʻoholo ʻole ʻia.E noke i `*to_drop = foo` helu like me ka hoʻohana no ka mea, e i ka waiwai e e haule hou.
/// [`write()`] hiki ke hoʻohana ʻia e hoʻonui i ka ʻikepili me ka waiho ʻole ʻana iā ia e hāʻule.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// E wehe lima i ka mea hope loa mai vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // E kiʻi i kahi kuhikuhi maka i ka mea hope loa ma `v`.
///     let ptr = &mut v[1] as *mut _;
///     // E hoʻopōkole iā `v` e pale i ka hāʻule ʻana o ka mea hope loa.
///     // Hana mua mākou i kēlā, e pale i nā pilikia inā ka `drop_in_place` ma lalo o panics.
///     v.set_len(1);
///     // Me ke kāhea ʻole ʻana iā `drop_in_place`, ʻaʻole e hoʻokuʻu ʻia ka mea hope loa, a e kī pū ʻia ka hoʻomanaʻo a ia e hoʻomalu ai.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // E hōʻoia i ka hoʻokuʻu ʻia ʻana o ka mea hope loa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// E hoʻomaopopo i ka hana a ka mea hōʻuluʻulu i kēia kope i ka wā e waiho ana i nā hana i hoʻopaʻa ʻia, ʻo ia hoʻi, ʻaʻole ʻoe e hopohopo e pili ana i kēlā mau pilikia ke ʻole ʻoe e kāhea iā `drop_in_place` me ka lima.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ʻAʻole pili kēia code ma aneʻi, ua hoʻololi ʻia kēia e ke kulu kulu maoli e ka mea hoʻopili.
    //

    // SAFETY: e nānā i ka manaʻo ma luna
    unsafe { drop_in_place(to_drop) }
}

/// Hoʻokumu i kahi pointer maka ʻole.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Hoʻokumu i kahi kuhikuhi maka maka ʻole hiki ʻole ke hoʻololi ʻia.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Pono pono manual impl e pale iā `T: Clone` i paʻa.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Pono pono manual impl e pale iā `T: Copy` i paʻa.
impl<T> Copy for FatPtr<T> {}

/// Hana i kahi ʻāpana maka mai kahi kuhikuhi a me ka lōʻihi.
///
/// Ke `len` i kekahi manaʻo hoʻopiʻi o ka helu ana o **oihana mua**, i ka helu o nāʻai.
///
/// Palekana kēia hana, akā palekana ʻole ka hoʻohana ʻana i ka waiwai hoʻihoʻi.
/// E ʻike i nā palapala o [`slice::from_raw_parts`] no nā koi palekana ʻoki.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ho okumu i kekahi māhele laʻau kuhikuhi wā e hoʻomaka ana me ka laʻau kuhikuhi i ka hehee ai mua
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // Maluhia: Ua pakele lolouila i ke dala, mai ka `Repr` hui ana mai ka * const [T]
        //
        // a me FatPtr like nā hoʻonohonoho hoʻomanaʻo.Hiki iā std ke hana i kēia hōʻoia.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Hana i nā hana like me [`slice_from_raw_parts`], koe wale nō ka hoʻihoʻi ʻia o kahi ʻāpana mutable maka, i kūʻē i kahi ʻāpana hiki ʻole ke hoʻololi ʻia.
///
///
/// E ʻike i nā palapala o [`slice_from_raw_parts`] no nā kikoʻī hou aʻe.
///
/// Palekana kēia hana, akā palekana ʻole ka hoʻohana ʻana i ka waiwai hoʻihoʻi.
/// E nānā i ka moʻolelo o [`slice::from_raw_parts_mut`] no ka māhele maluhia koi.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // hāʻawi i kahi waiwai ma ka papa kuhikuhi ma ka ʻāpana
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // Maluhia: Ua pakele mai * mut [T] lolouila i ke dala, mai ka `Repr` hoao ana
        // a me FatPtr like nā hoʻonohonoho hoʻomanaʻo
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Kuapo i nā waiwai ma nā wahi hoʻololi ʻelua o ka ʻano like, me ka ʻole o ka deinitializing ʻana.
///
/// Akā, no ka mea kēia mau 'ia, i kēia kuleana pili i ka semantically like ia [`mem::swap`]:
///
///
/// * Hoʻohana ia ma nā point maka ma kahi o nā kūmole.
/// Ke loaʻa nā kūmole, pono e makemake ʻia ʻo [`mem::swap`].
///
/// * Hiki paha ke kāwili ʻia nā waiwai kuhi ʻelua.
/// Inā piʻi ka waiwai, a laila e hoʻohana ʻia ka māhele o ka hoʻomanaʻo o `x`.
/// Hōʻike ʻia kēia i ka lua o nā hiʻohiʻona ma lalo.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * Pono `x` a me `y` i [valid] no nā mea heluhelu a kākau hoʻi.
///
/// * Pono e hoʻopili pono ʻia nā `x` a me `y`.
///
/// Note e hiki ina `T` ua nui `0`, na mea kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ke hoʻololi nei i ʻelua mau ʻāpana kuhi ʻole:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ʻo `array[0..2]` kēia
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ʻo `array[2..4]` kēia
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ke hoʻololi nei i nā ʻāpana ʻelua.
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ʻo `array[0..3]` kēia
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ʻo `array[1..4]` kēia
///
/// unsafe {
///     ptr::swap(x, y);
///     // ʻO nā huaʻōlelo `1..3` o ka ʻāpana i uhi ʻia ma waena o `x` a me `y`.
///     // ʻO nā hualoaʻa kūpono no lākou `[2, 3]`, no laila ʻo `0..3` nā helu helu `[1, 2, 3]` (kūlike me `y` ma mua o `swap`);aiʻole no lākou e `[0, 1]` no laila ʻo X0 `1..4` nā kuhi `[0, 1, 2]` (e like me `x` ma mua o `swap`).
/////
///     // Ua wehewehe ʻia kēia hoʻokō e hana i ka koho hope loa.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Hāʻawi iā mākou iho i kahi lewalewa e hana pū.
    // ʻAʻole mākou e hopohopo e pili ana i nā kulu: ʻaʻole hana ʻo `MaybeUninit` i ka wā e hāʻule ana.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Hana i ke kuapo maluhia: ka Caller pono kumu hoʻomalu i `x` a me `y` i henua pololei i kakau iho ai, a pono ua kūponoʻia.
    // `tmp` ʻaʻole hiki ke hoʻokuʻi ʻia i `x` a i ʻole `y` no ka mea ua hoʻokaʻawale wale ʻia ʻo `tmp` ma ka puʻu ma ke ʻano he mea hoʻokaʻawale ʻokoʻa.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` a `y` paha e hāwī
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Kuapo i nā bytes `count * size_of::<T>()` ma waena o nā mahele ʻelua o ka hoʻomanaʻo e hoʻomaka ana ma `x` a me `y`.
/// ʻAʻole pono nā ʻāpana ʻelua.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * Pono `x` a me `y` i [valid] no nā heluhelu ʻelua a kākau hoʻi i ka ʻhelu helu *
///   size_of: :<T>() `bytes.
///
/// * Pono e hoʻopili pono ʻia nā `x` a me `y`.
///
/// * E hoʻomaka ana ka ʻāpana o ka hoʻomanaʻo ma `x` me ka nui o ka `helu *
///   size_of: :<T>() `Nāʻai pono *i* ano a me ka māhele o ka iaiyoe e hoomaka ana me ka ia nui ma `y`.
///
/// Note e hiki ina na ka pono mānewanewa kanikau nui ('helu * size_of: :<T>() `) O `0`, na mea kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: pono i ka mea kelepona e hōʻoia i `x` a me `y`
    // kūpono no nā kākau a kaulike kūpono ʻia.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // No ano uuku ma mua o ka aeie kaʻoi loa o lalo, e kuapo 'ana, e pale aku pessimizing codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka pololei o `x` a me `y`
        // no kakau iho ai, pono ua kūponoʻia, a me ka 'ole-overlapping.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // ʻO ke ala e hoʻohana ai i ka simd e hoʻololi x&y me ka maikaʻi.
    // Hōʻike ka hōʻike i ke kuapo ʻana i nā bytes 32 a i ʻole 64 bytes i ka manawa kūpono loa no nā Intel prosesor Intel Haswell E.
    // Hiki i ka LLVM ke ʻoi aku ka maikaʻi inā hāʻawi mākou i kahi #[repr(simd)], ʻoiai inā ʻaʻole mākou e hoʻohana pololei i kēia mea.
    //
    //
    // FIXME repr(simd) wawahiia ma emscripten a me ka redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop ma o x&y, kope ʻana iā lākou `Block` i ka manawa pono ka loiloi e wehe pono i ka loop no ka nui o nā ʻano NB
    // Mākou hiki ole hana i kekahi no ka loop like me ka `range` impl kahea `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // E hana i kekahi uninitialized hoomanao like kūikawā makahiki he wehewehe ana `t` 'aneʻi hookaaokoa ae mai o aligning ka noae ia keia loop mea ua hanaʻole
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: E like me `i < len`, a e like me ka mea e pono ai ke kelepona pono ʻo `x` a me `y` i ka pololei
        // no ka `len` bytes, `x + i` a me `y + i` pono he mau wahi noho kūpono, e hoʻokō ana i ka ʻaelike palekana no `add`.
        //
        // Nō hoʻi, ke Caller pono kumu hoʻomalu i `x` a me `y` i henua pololei no kakau iho ai, pono ua kūponoʻia, a me ka 'ole-overlapping, a hoʻokōʻana i ka maluhia aelike no `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Kuapo i kahi palaka o nā by&x, e hoʻohana ana i ke ʻano he buffer manawa ʻole E pono kēia e hoʻonui ʻia i nā hana SIMD kūpono inā loaʻa
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Kuapo i nā bytes i koe
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: e nānā i ka ʻōlelo palekana ma mua.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Kolo ana `src` i loko o ke kuhikuhi mai la lakou `dst`, hoi mai ka mua `dst` waiwai.
///
/// ʻAʻole hāʻule ka waiwai.
///
/// ʻO kēia hana he semantically like ia me [`mem::replace`] koe wale nō e hana ia ma nā kuhikuhi maka ma kahi o nā kūmole.
/// Ke loaʻa nā kūmole, pono e makemake ʻia ʻo [`mem::replace`].
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `dst` pono e [valid] no nā heluhelu ʻelua a kākau hoʻi.
///
/// * `dst` pono e hoʻopili pono.
///
/// * `dst` pono e kuhikuhi i kahi waiwai hoʻomaka mua o ka type `T`.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` e loaʻa ka hopena like me ke koi ʻole i ka palaka palekana.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // Ka maluhia: o ka Caller pono kumu hoʻomalu i `dst` mea i pololei ia ia e
    // hoʻolei i kahi kūmole hiki ke hoʻololi (kūpono no nā kākau, kaulike ʻia, hoʻomaka mua ʻia), ʻaʻole hiki ke hoʻokau iā `src` mai ka `dst` e kuhikuhi i kahi mea i hoʻokaʻawale ʻia.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ʻaʻole hiki ke hoʻopili aku
    }
    src
}

/// Heluhelu i ka waiwai mai `src` me ka neʻe ʻole.Waiho kēia i ka hoʻomanaʻo i `src` i hoʻololi ʻole.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `src` pono e [valid] no nā heluhelu.
///
/// * `src` pono e hoʻopili pono.E hoʻohana iā [`read_unaligned`] inā ʻaʻole kēia ka hihia.
///
/// * `src` pono e kuhikuhi i kahi waiwai hoʻomaka mua o ka type `T`.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// E hoʻokō lima iā [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // E hana i kahi kope liʻiliʻi o ka waiwai ma `a` ma `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exiting i keia wahi (kekahi ma ka kūlike loa hoi paha ma ka kahea ana i kekahi kuleana pili i a panics) makemake i ka waiwai i loko o `tmp` e e haule ana o ka ia cia ua nō i maopopo nä haumäna e `a`.
///         // Ua hiki ke kāhea undefined hana ina `T` mea ole `Copy`.
/////
/////
///
///         // E hana i kahi kope liʻiliʻi o ka waiwai ma `b` ma `a`.
///         // Palekana kēia no ka mea ʻaʻole hiki i nā kūmole hiki ke hoʻohuli ʻia ke alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // E like me ma luna, hiki i ka puka ʻana ma aneʻi ke hoʻomaka i nā hana i hoʻoholo ʻole ʻia no ka mea ua hōʻike ʻia ka waiwai like e `a` a me `b`.
/////
///
///         // E hoʻoneʻe i `tmp` i `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ua hoʻoneʻe ʻia (lawe ʻo `write` i kāna kuleana ʻelua), no laila ʻaʻohe mea i hāʻule ma aneʻi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## ʻO ka mea nona ka waiwai i hoʻihoʻi ʻia
///
/// `read` hana i kekahi bitwise kope o `T`, nānā 'ole o ka ina paha `T` o [`Copy`].
/// Inā `T` ʻaʻole [`Copy`], e hoʻohana ana i ka waiwai i hoʻihoʻi ʻia a me ka waiwai ma `*src` hiki ke hōʻeha i ka palekana o ka hoʻomanaʻo.
/// E noke i ka lanakila ana i `*src` helu like me ka hoʻohana no ka mea, e hoao mai i ka papa i ka waiwai ma `* src`.
///
/// [`write()`] hiki ke hoʻohana ʻia e hoʻonui i ka ʻikepili me ka waiho ʻole ʻana iā ia e hāʻule.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` kuhikuhi i kēia manawa i ka hoʻomanaʻo paʻa like me `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Hāʻawi ka hāʻawi ʻana i `s2` i kāna kumu kumu i hāʻule.
///     // Ma waho o kēia kiko, ʻaʻole pono e hoʻohana hou ʻia ka `s`, no ka mea ua hoʻokuʻu ʻia ka hoʻomanaʻo paʻa.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Hāʻawi ka hāʻawi ʻana iā `s` i ke kumu waiwai e hoʻokau hou ʻia, a laila e hopena ai ka hana.
/////
///     // s= String::from("bar");//Hewa
///
///     // `ptr::write` hiki ke hoʻohana ʻia e hoʻonui i kahi waiwai me ka waiho ʻole ʻana iā ia.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Ka maluhia: o ka Caller pono kumu hoʻomalu i `src` mea i pololei ia no ka heluhelu.
    // `src` ʻaʻole hiki ke hoʻokau iā `tmp` no ka mea ua hoʻokaʻawale wale ʻia ʻo `tmp` ma ka stack ma ke ʻano he mea hoʻokaʻawale ʻokoʻa.
    //
    //
    // Nō hoʻi, no ka mea, ua pono, palapala iho la i ka henua pololei waiwai i loko o `tmp`, ka mea, ua ua hoʻohiki ia e pono initialized.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Heluhelu i ka waiwai mai `src` me ka neʻe ʻole.Waiho kēia i ka hoʻomanaʻo i `src` i hoʻololi ʻole.
///
/// ʻAʻole like me [`read`], hana ʻo `read_unaligned` me nā kuhikuhi kuhi ʻole.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `src` pono e [valid] no nā heluhelu.
///
/// * `src` pono e kuhikuhi i kahi waiwai hoʻomaka mua o ka type `T`.
///
/// E like me [`read`], hana ʻo `read_unaligned` i kope liʻiliʻi o `T`, me ka nānā ʻole inā `T` ʻo [`Copy`].
/// Inā `T` ʻaʻole [`Copy`], e hoʻohana ana i ka waiwai i hoʻihoʻi ʻia a me ka waiwai ma `*src` hiki iā [violate memory safety][read-ownership].
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ma nā kaha `packed`
///
/// ʻAʻole hiki i kēia manawa ke hana i nā kuhikihi maka ʻole i nā kahua unaligned o kahi pack pack.
///
/// Ke hoʻāʻo nei e hana i kahi kuhikuhi maka i kahi kahua `unaligned` me kahi manaʻo e like me `&packed.unaligned as *const FieldType` e hana i kahi kūmole unaligned waena ma mua o ka hoʻololi ʻana i kahi kuhikuhi maka.
///
/// I keia pili ka pokole a koke hoolei mea inconsequential like me ka compiler mau manao i maopopo nä haumäna e e pono ua kūponoʻia.
/// E like me ka hopena, ka hoʻohana 'ana `&packed.unaligned as *const FieldType` kumu koke* undefined hana * i loko o kāu polokalamu.
///
/// An kumu o ka mea,ʻaʻole i ka hana, a pehea keia pili i `read_unaligned` nei:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Eia hoao mākou e lawe i ka helu wahi o ka 32-iki helu i ua ole ua kūponoʻia.
///     let unaligned =
///         // Hoʻokumu ʻia kahi kūmole unaligned pili ʻole ma aneʻi e hopena ai i nā hana undefined me ka nānā ʻole inā e hoʻohana ʻia ka kūmole a i ʻole.
/////
///         &packed.unaligned
///         // ʻAʻole kōkua ka hoʻolei ʻana i kahi kuhikuhi maka;ua hala ka hewa.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ka loaʻa'an unaligned mahinaʻai 'ana me ka e like `packed.unaligned` Ua pakele nō naʻe.
///
///
///
///
///
///
// FIXME: Hoʻohou i nā palapala e pili ana i ka hopena o RFC #2582 a me nā hoaaloha.
/// # Examples
///
/// E heluhelu i kahi waiwai hoʻohana mai kahi buffer byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Ka maluhia: o ka Caller pono kumu hoʻomalu i `src` mea i pololei ia no ka heluhelu.
    // `src` ʻaʻole hiki ke hoʻokau iā `tmp` no ka mea ua hoʻokaʻawale wale ʻia ʻo `tmp` ma ka stack ma ke ʻano he mea hoʻokaʻawale ʻokoʻa.
    //
    //
    // Nō hoʻi, no ka mea, ua pono, palapala iho la i ka henua pololei waiwai i loko o `tmp`, ka mea, ua ua hoʻohiki ia e pono initialized.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Kaha i kahi wahi hoʻomanaʻo me ka waiwai i hāʻawi ʻia me ka heluhelu ʻole a hoʻokuʻu ʻana paha i ka waiwai kahiko.
///
/// `write` ʻaʻole kulu i nā ʻike o `dst`.
/// Palekana kēia, akā hiki iā ia ke hoʻokahe i nā hoʻokaʻawale a i ʻole nā kumuwaiwai, no laila e mālama pono ʻaʻole e hoʻokau i kahi mea e hoʻokuʻu ʻia.
///
///
/// Hoʻohui, ʻaʻole ia e hoʻokuʻu iā `src`.Semantically, hoʻoneʻe ʻia ʻo `src` i kahi i kuhikuhi ʻia e `dst`.
///
/// Kūpono kēia no ka hoʻomaka ʻana i ka hoʻomanaʻo uninitialized, a i ʻole ke kāohi ʻana i ka hoʻomanaʻo i [`read`] ma mua.
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `dst` pono e [valid] no nā kākau.
///
/// * `dst` pono e hoʻopili pono.E hoʻohana iā [`write_unaligned`] inā ʻaʻole kēia ka hihia.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// E hoʻokō lima iā [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // E hana i kahi kope liʻiliʻi o ka waiwai ma `a` ma `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exiting i keia wahi (kekahi ma ka kūlike loa hoi paha ma ka kahea ana i kekahi kuleana pili i a panics) makemake i ka waiwai i loko o `tmp` e e haule ana o ka ia cia ua nō i maopopo nä haumäna e `a`.
///         // Ua hiki ke kāhea undefined hana ina `T` mea ole `Copy`.
/////
/////
///
///         // E hana i kahi kope liʻiliʻi o ka waiwai ma `b` ma `a`.
///         // Palekana kēia no ka mea ʻaʻole hiki i nā kūmole hiki ke hoʻohuli ʻia ke alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // E like me ma luna, hiki i ka puka ʻana ma aneʻi ke hoʻomaka i nā hana i hoʻoholo ʻole ʻia no ka mea ua hōʻike ʻia ka waiwai like e `a` a me `b`.
/////
///
///         // E hoʻoneʻe i `tmp` i `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ua hoʻoneʻe ʻia (lawe ʻo `write` i kāna kuleana ʻelua), no laila ʻaʻohe mea i hāʻule ma aneʻi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Mākou e kii aku i ka intrinsics 'ana i ka pale papa kāhea aku a ke i loko o ka ua loaʻa kivila like `intrinsics::copy_nonoverlapping` mea he kuleana pili i wrapper.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // Ka maluhia: o ka Caller pono kumu hoʻomalu i `dst` mea i pololei ia i kakau iho ai.
    // `dst` ʻaʻole hiki ke hoʻokau iā `src` no ka mea hiki i ka mea kāhea ke komo i `dst` ʻoiai ʻo `src` ke kuleana o kēia hana.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Kaha i kahi wahi hoʻomanaʻo me ka waiwai i hāʻawi ʻia me ka heluhelu ʻole a hoʻokuʻu ʻana paha i ka waiwai kahiko.
///
/// ʻAʻole like me [`write()`], kuhi ʻole paha ke kuhikuhi.
///
/// `write_unaligned` ʻaʻole kulu i nā ʻike o `dst`.Kēia mea pakele, akā, e hiki liu allocations a waiwai, no laila, malama e e lawe mai i ka overwrite o kekahi mea i mea e haule iho la iluna.
///
/// Hoʻohui, ʻaʻole ia e hoʻokuʻu iā `src`.Semantically, hoʻoneʻe ʻia ʻo `src` i kahi i kuhikuhi ʻia e `dst`.
///
/// Kūpono kēia no ka hoʻomaka ʻana i ka hoʻomanaʻo uninitialized, a i ʻole ke kāohi ʻana i ka hoʻomanaʻo i heluhelu ʻia me [`read_unaligned`].
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `dst` pono e [valid] no nā kākau.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard.
///
/// [valid]: self#safety
///
/// ## Ma nā kaha `packed`
///
/// ʻAʻole hiki i kēia manawa ke hana i nā kuhikihi maka ʻole i nā kahua unaligned o kahi pack pack.
///
/// Ke hoʻāʻo nei e hana i kahi kuhikuhi maka i kahi kahua `unaligned` me kahi manaʻo e like me `&packed.unaligned as *const FieldType` e hana i kahi kūmole unaligned waena ma mua o ka hoʻololi ʻana i kahi kuhikuhi maka.
///
/// I keia pili ka pokole a koke hoolei mea inconsequential like me ka compiler mau manao i maopopo nä haumäna e e pono ua kūponoʻia.
/// E like me ka hopena, ka hoʻohana 'ana `&packed.unaligned as *const FieldType` kumu koke* undefined hana * i loko o kāu polokalamu.
///
/// ʻO kahi laʻana o ka mea ʻaʻole e hana a pehea e pili ai kēia iā `write_unaligned`:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Eia hoao mākou e lawe i ka helu wahi o ka 32-iki helu i ua ole ua kūponoʻia.
///     let unaligned =
///         // Hoʻokumu ʻia kahi kūmole unaligned pili ʻole ma aneʻi e hopena ai i nā hana undefined me ka nānā ʻole inā e hoʻohana ʻia ka kūmole a i ʻole.
/////
///         &mut packed.unaligned
///         // ʻAʻole kōkua ka hoʻolei ʻana i kahi kuhikuhi maka;ua hala ka hewa.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ka loaʻa'an unaligned mahinaʻai 'ana me ka e like `packed.unaligned` Ua pakele nō naʻe.
///
///
///
///
///
///
///
///
///
// FIXME: Hoʻohou i nā palapala e pili ana i ka hopena o RFC #2582 a me nā hoaaloha.
/// # Examples
///
/// E kākau i kahi waiwai hoʻohana i kahi buffer byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // Ka maluhia: o ka Caller pono kumu hoʻomalu i `dst` mea i pololei ia i kakau iho ai.
    // `dst` ʻaʻole hiki ke hoʻokau iā `src` no ka mea hiki i ka mea kāhea ke komo i `dst` ʻoiai ʻo `src` ke kuleana o kēia hana.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Mākou e kii aku i ka waiwai kūʻiʻoo 'ana i ka pale papa kāhea aku a ke i loko o ka ua loaʻa kuhi.
        intrinsics::forget(src);
    }
}

/// Hana i kahi heluhelu maʻalahi o ka waiwai mai `src` me ka neʻe ʻole.Waiho kēia i ka hoʻomanaʻo i `src` i hoʻololi ʻole.
///
/// Hana ʻia nā hana maʻalahi e hana ma ka hoʻomanaʻo I/O, a hōʻoia ʻia ʻaʻole e elided a i hoʻonohonoho hou ʻia paha e ka mea hōʻuluʻulu ma o nā hana maʻalahi.
///
/// # Notes
///
/// Rust aʻole ole a ianoiyuaa a i ka rigorously a formally hoakaka iaiyoe ÷, no laila, ke kūlike loa semantics o ka mea "volatile" 'o ia hoʻi' aneʻi ka hoʻokuleana i ka loli no manawa.
/// ʻO ka ʻōlelo ʻia, kokoke pau nā semantics i like me [C11's definition of volatile][c11].
///
/// Ke compiler E ole hoʻololi i ka pili pono a me ka helu o yiaeaiiacaaeneiie iaiyoe hana.
/// Eia nō naʻe, nā hana hoʻomanaʻo hoʻomanaʻo i nā ʻano zero-nui (e laʻa, inā i hāʻawi ʻia kahi ʻano zero-nui i `read_volatile`) nā kihi a nānā paha ʻia.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `src` pono e [valid] no nā heluhelu.
///
/// * `src` pono e hoʻopili pono.
///
/// * `src` pono e kuhikuhi i kahi waiwai hoʻomaka mua o ka type `T`.
///
/// E like me [`read`], hana ʻo `read_volatile` i kope liʻiliʻi o `T`, me ka nānā ʻole inā `T` ʻo [`Copy`].
/// Inā `T` ʻaʻole [`Copy`], e hoʻohana ana i ka waiwai i hoʻihoʻi ʻia a me ka waiwai ma `*src` hiki iā [violate memory safety][read-ownership].
/// Eia nō naʻe, ʻo ka mālama ʻana i nā ʻano non-[`Copy`] i loko o ka hoʻomanaʻo hoʻomanaʻo maʻalahi ʻole paha.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// E like me C, inā he volility kahi hana ʻaʻohe ona kuleana ma nā nīnau e pili ana i ke kiʻi like ʻana mai nā pae he nui.Hana pono nā komo uila i like me ke komo ʻole o nā atomic i kēlā ʻano.
///
/// Ma kekahi, he heihei ma waena o ka `read_volatile` a me kekahi kākau ana i ka ia wahi mea undefined kolohe.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ole'ā'ā e malama codegen hopena uuku.
        abort();
    }
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Hanaʻia he yiaeaiiacaaeneiie kahakaha iho o ka iaiyoe wahi me ka haawi waiwai me ka heluhelu 'ole e kahe mai ana i ka mea kahiko cia.
///
/// Hana ʻia nā hana maʻalahi e hana ma ka hoʻomanaʻo I/O, a hōʻoia ʻia ʻaʻole e elided a i hoʻonohonoho hou ʻia paha e ka mea hōʻuluʻulu ma o nā hana maʻalahi.
///
/// `write_volatile` ʻaʻole kulu i nā ʻike o `dst`.Kēia mea pakele, akā, e hiki liu allocations a waiwai, no laila, malama e e lawe mai i ka overwrite o kekahi mea i mea e haule iho la iluna.
///
/// Hoʻohui, ʻaʻole ia e hoʻokuʻu iā `src`.Semantically, hoʻoneʻe ʻia ʻo `src` i kahi i kuhikuhi ʻia e `dst`.
///
/// # Notes
///
/// Rust aʻole ole a ianoiyuaa a i ka rigorously a formally hoakaka iaiyoe ÷, no laila, ke kūlike loa semantics o ka mea "volatile" 'o ia hoʻi' aneʻi ka hoʻokuleana i ka loli no manawa.
/// ʻO ka ʻōlelo ʻia, kokoke pau nā semantics i like me [C11's definition of volatile][c11].
///
/// Ke compiler E ole hoʻololi i ka pili pono a me ka helu o yiaeaiiacaaeneiie iaiyoe hana.
/// Eia nō naʻe, nā hana hoʻomanaʻo hoʻomanaʻo i nā ʻano zero-nui (e laʻa, inā i hāʻawi ʻia kahi ʻano zero-nui i `write_volatile`) nā kihi a nānā paha ʻia.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ua undefined hana ina kekahi o na ana ma lalo nei i hehi:
///
/// * `dst` pono e [valid] no nā kākau.
///
/// * `dst` pono e hoʻopili pono.
///
/// Note e hiki ina `T` ua nui `0`, ka laʻau kuhikuhi pono e 'ole-Yard, a pono ua kūponoʻia.
///
/// [valid]: self#safety
///
/// E like me C, inā he volility kahi hana ʻaʻohe ona kuleana ma nā nīnau e pili ana i ke kiʻi like ʻana mai nā pae he nui.Hana pono nā komo uila i like me ke komo ʻole o nā atomic i kēlā ʻano.
///
/// Ma kahi kikoʻī, he heihei ma waena o `write_volatile` a me nā hana ʻē aʻe (heluhelu a kākau ʻana paha) ma ka wahi like ka hana i hoʻoholo ʻole ʻia.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ole'ā'ā e malama codegen hopena uuku.
        abort();
    }
    // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// E hoʻolālani i ka pointer `p`.
///
/// E helu i ka offset (i nā ʻōlelo o nā pae o `stride` stride) e hoʻopili ʻia i ka pointer `p` i mea e hoʻopili ai ka poʻomanaʻo `p` iā `a`.
///
/// Note: Kēia manaʻo i ua akahele kā i ole panic.He UB no keia i panic.
/// ʻO ka loli maoli i hiki ke hana ʻia ma aneʻi ka loli o `INV_TABLE_MOD_16` a me nā mea paʻa e pili ana.
///
/// Inā mākou mau loa olelo e e ka mea e hiki ai, e hea aku i ka waiwai kūʻiʻoo me `a` i mea ole i ka mana-o-elua, ka mea e paha e oi me ke akamai i ka pono loli i ka naʻaupō manaʻo ma mua o ho'āʻo e ke hakuloli i keia, e lawa i ka loli.
///
///
/// Hele kekahi nīnau iā@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Hoʻonui ka hoʻohana pono ʻana i kēia mau intrinsics i ka codegen ma ka opt-level <=
    // 1, ma ke ano wale nō o kēia mau hana i ole inlined.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// E helu i ka huli modular multiplicative o `x` modulo `m`.
    ///
    /// Kēia manaʻo Ua kā no `align_offset`, a ua hahai preconditions:
    ///
    /// * `m` he mana-ʻelua;
    /// * `x < m`; (inā `x ≥ m`, holo i `x % m` ma kahi)
    ///
    /// ʻAʻole e panic ka hoʻokō ʻana i kēia hana.Mau loa
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Pālua multiplexative pākaukau huli modulo 2⁴=16.
        ///
        /// Hoʻomaopopo, ʻaʻole i loko o kēia pākaukau nā waiwai ma kahi i kū ʻole o ka inverse (ie, no `0⁻¹ mod 16`, `2⁻¹ mod 16`, a pēlā aku.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo no ka `INV_TABLE_MOD_16` i manaʻo ʻia.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: Koi ʻia ʻo `m` i mana-o-ʻelua, no laila ʻaʻole nol.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Hoʻomaopopo mākou iā "up" me ka hoʻohana ʻana i kēia ʻano hana:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // a hiki i 2²ⁿ ≥ m.A laila hiki iā mākou ke hōʻemi i kā mākou `m` i makemake ʻia e ka lawe ʻana i ka hopena `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Note, hoʻi i wahīʻia ana e mākou hoʻohana 'aneʻi intentionally-ka palapala haʻilula hoʻohana IAOEIAaO, subtraction `mod n`.
                // He loa ka ie, e hana ia `mod usize::MAX` i pānaʻi, no ka mea, ua lawe i ka hopena `mod n` ma ka hopena Hehe.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: ʻO `a` kahi mana-o-ʻelua, no laila non-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` hiki e Me hihia nui wale ma `-p (mod a)`, akā, hana no laila, inhibits LLVM ka hana e koho i olelo ao e like `lea`.Ma kahi mākou e helu
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ka mea e hāʻawi i nā hana a puni ka halihali ʻana, akā pessimizing `and` lawa no LLVM e hiki ai ke hoʻohana i nā optimization like ʻole āna i ʻike ai.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Ua kaulike.ʻAe!
        return 0;
    } else if stride == 0 {
        // Inā ʻaʻole kūlike ka pointer, a ʻaʻohe o ka nui o ke kumumanaʻo, no laila ʻaʻohe nui o nā mea e hoʻopili pono i ka kuhikuhi.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // Maluhia: he mea mana-o-mau mai keia wahi aku 'ole-Aʻohe.stride==0 hihia ma luna.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: he palena kiʻekiʻe ko gcdpow ʻo ia ka nui o nā ʻāpana i kahi usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // Maluhia: gcd mea mau nui a me ka ewaewa ole i ka 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Hoʻoholo kēia branch no ka hoʻohālikelike laina laina like:
        //
        // ` p + so = 0 mod a `
        //
        // `p` eia ka helu kuhikuhi, `s`, stride o `T`, `o` offset i loko o `T, a me `a`, ke noi i noi ʻia.
        //
        // Me `g = gcd(a, s)`, a me ka luna ana asserting ana `p` mea i divisible ma `g`, ua hiki Kû ke `a' = a/g`, `s' = s/g`, `p' = p/g`, a laila, i kēia i like i ka:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // ʻO "the relative alignment of `p` to `a`" ka huaʻōlelo mua (mahele ʻia e `g`), ʻo ka lua o ka manawa ʻo "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (mahele hou ʻia e `g`).
        //
        // Pono ka mahele e `g` e hana pono i ka inverse inā ʻaʻole ʻo `a` a me `s` i co-prime.
        //
        // Eia kekahi, o ka hopena hua mai ma keia pāʻoihana mea ole "minimal", no laila hoi e pono ke lawe i ka hopena `o mod lcm(s, a)`.Hiki iā mākou ke hoʻololi iā `lcm(s, a)` me kahi `a'` wale nō.
        //
        //
        //
        //
        //

        // SAFETY: ʻO `gcdpow` kahi palena kiʻekiʻe ʻaʻole i ʻoi aku ma mua o ka helu o nā 0 i huki ʻia i `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` ʻaʻohe-ʻole.ʻAʻole hiki ke hoʻololi i `a` e `gcdpow` i kekahi o nā ʻāpana i hoʻonohonoho ʻia
        // i `a` (nona hoʻokahi kikoʻī).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: ʻO `gcdpow` kahi palena kiʻekiʻe ʻaʻole i ʻoi aku ma mua o ka helu o nā 0 i huki ʻia i `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: ʻO `gcdpow` kahi palena kiʻekiʻe ʻaʻole i ʻoi aku ma mua o ka helu o nā 0 e hemo ana i loko
        // `a`.
        // Eia kekahi, ʻaʻole hiki i ka unuhi ke hoʻonui, no ka mea, ʻoi aku ka nui o `a2 = a >> gcdpow` ma mua o `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: ʻO `a2` kahi mana-o-ʻelua, e like me ka mea i hōʻike ʻia ma luna.ʻOi loa ka `s2` ma mua o `a2`
        // no ka mea, ʻoi aku ka liʻiliʻi o `(s % a) >> gcdpow` ma mua o `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // ʻAʻole hiki ke kaulike iki.
    usize::MAX
}

/// Hoʻohālikelike i nā kuhikuhi maka no ke kaulike.
///
/// Ua like kēia me ka hoʻohana ʻana i ka mea hoʻohana `==`, akā ʻoi aku ka liʻiliʻi.
/// pono nā hoʻopaʻapaʻa i `*const T` raw pointers, ʻaʻole i kekahi mea e hoʻokō iā `PartialEq`.
///
/// Ua hiki ke hoʻohana 'e hoohalike `&T` kūmole (a coerce i `*const T` implicitly) ma kā lākou helu wahi, aole i ka ke kapakai a me nā loina e kuhikuhi i (i ka mea i ka `PartialEq for &T` manaʻo i).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Hoʻohālikelike ʻia nā ʻāpana e ko lākou lōʻihi (nā kuhi momona):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Hoʻohālikelike ʻia ʻo Traits e kā lākou hoʻokō ʻana:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Kahi kikoʻi like nā helu kuhi.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Loaʻa nā helu like i nā mea, akā he ʻano ʻokoʻa ka `Trait`.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ke hoʻololi nei i ka kuhikuhi i kahi `*const u8` e hoʻohālikelike ʻia e ka helu wahi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash i kahi kuhikuhi maka.
///
/// Hiki ke hoʻohana i kēia e kuhi i kahi kuhikuhi `&T` (kahi e koi iā `*const T` implicitly) e kāna kamaʻilio ma mua o ka waiwai i kuhikuhi ʻia (ʻo ia ka hana a `Hash for &T` e hana ai).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Hoʻopili no nā kuhikuhi kuhikuhi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Koi ʻia ka mea waena waena e like me ka usize no AVR
                // no laila mālama ʻia ka hakahaka o ka kuhikuhi kuhikuhi kumu i ka kuhikuhi hope loa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Koi ʻia ka mea waena waena e like me ka usize no AVR
                // no laila mālama ʻia ka hakahaka o ka kuhikuhi kuhikuhi kumu i ka kuhikuhi hope loa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // ʻAʻohe hana variadic me nā palena ʻo 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Hana i kekahi `const` maka laʻau kuhikuhi i kekahi wahi, me ka pili ana i ka palapala i maopopo nä haumäna.
///
/// ʻAe ʻia ka hana ʻana i kahi kūmole me `&`/`&mut` inā e hoʻopili pololei ʻia ka pointer a kuhikuhi i ka ʻikepili mua.
/// No ka hihia kahi mau koi mai e hoopaa, heʻiʻo maka nō mea kuhikuhi e e hoʻohana hakahaka.
/// Eia nō naʻe, hana ʻo `&expr as *const _` i kahi kūmole ma mua o ka hoʻolei ʻana iā ia i kahi kuhikuhi maka, a aia ia ʻōlelo i nā lula like me nā kuhikuhi ʻē aʻe.
///
/// Kēia nunui ke hana i kekahi maka laʻau kuhikuhi *me* e pili ana i ka maopopo mua.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` e hana i kahi kuhikuhi pili ʻole, a no laila e Undefined Behaviour!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// E hana i kahi māka kuhikuhi `mut` i kahi, me ka hana ʻole ʻana i kahi kuhikuhi waena.
///
/// ʻAe ʻia ka hana ʻana i kahi kūmole me `&`/`&mut` inā e hoʻopili pololei ʻia ka pointer a kuhikuhi i ka ʻikepili mua.
/// No ka hihia kahi mau koi mai e hoopaa, heʻiʻo maka nō mea kuhikuhi e e hoʻohana hakahaka.
/// Eia nō naʻe, hana ʻo `&mut expr as *mut _` i kahi kūmole ma mua o ka hoʻolei ʻana iā ia i kahi kuhikuhi maka, a aia ia ʻōlelo i nā kānāwai like me nā kuhikuhi ʻē aʻe.
///
/// Kēia nunui ke hana i kekahi maka laʻau kuhikuhi *me* e pili ana i ka maopopo mua.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` e hana i kahi kuhikuhi pili ʻole, a no laila e Undefined Behaviour!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` nā koa e kope i ka māla ma kahi o ka hoʻokumu ʻana i kahi kūmole.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}