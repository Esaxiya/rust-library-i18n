use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Hoʻi iā `true` inā he nul ke kuhikuhi.
    ///
    /// Hoʻomaopopo i nā ʻano unsized he nui nā kuhi null hiki, no ka mea, ʻo ka pointer ʻikepili maka wale nō i manaʻo ʻia, ʻaʻole ko lākou lōʻihi, papa, a pēlā aku.
    /// No laila, ʻelua mau poʻomanaʻo nul ʻaʻole paha e hoʻohālikelike i kekahi i kekahi.
    ///
    /// ## ʻO ka lawena i ka manawa o ka loiloi
    ///
    /// Ke hoʻohana ʻia kēia hana i ka wā o ka loiloi const, hiki paha iā ia ke hoʻihoʻi iā `false` no nā pointers e huli ʻole i ka holo ʻole.
    /// ʻO ke kikoʻī, ke offset ʻia kahi poʻomanaʻo i kekahi hoʻomanaʻo ma waho o kāna mau palena i ke ala i null ai ka pointer hopena, e hoʻi hou ka hana iā `false`.
    ///
    /// ʻAʻohe ala e ʻike ai ʻo CTFE i ke kūlana paʻa loa o ia hoʻomanaʻo, no laila ʻaʻole hiki iā mākou ke haʻi inā he null a ʻaʻole paha ka mea kuhikuhi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Hoʻohālikelike ma o ka hoʻolei ʻana i kahi kuhikuhi kikoʻī, no laila e noʻonoʻo wale nā mea kuhikuhi momona i kā lākou "data" ʻāpana no ka null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Kuhi i kahi kuhikuhi o kekahi ʻano.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// E hoʻopau i kahi kuhikuhi (hiki ākea paha) i kahi helu a me nā ʻikepili metadata.
    ///
    /// Hiki ke kūkulu hou ʻia ka kuhikuhi ma hope me [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Hoʻi iā `None` inā he ʻole ka kuhikuhi, a i ʻole hoʻi e hoʻi i kahi kuhikuhi i ka waiwai i wahī ʻia i `Some`.Inā uninitialized paha ka waiwai, pono e hoʻohana ma kahi o [`as_uninit_ref`].
    ///
    /// No ka counterpart mutable ʻike iā [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono e kuhikuhi i ka kuhikuhi i kahi hanana mua o `T`.
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    /// (ʻO ka ʻāpana e pili ana i ka hoʻomaka mua ʻia ʻaʻole i hoʻoholo piha ʻia, akā a hiki i kēia manawa, ʻo ke ala palekana wale nō e hōʻoia ai ua hoʻokumu ʻia lākou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Mana hōʻole ʻole ʻia
    ///
    /// Inā maopopo ʻoe ʻaʻole hiki i ka pointer ke null a keʻimi nei i kekahi ʻano `as_ref_unchecked` e hoʻihoʻi i ka `&T` ma kahi o `Option<&T>`, ʻike hiki iā ʻoe ke hōʻalo pololei i ka kuhikuhi.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka pololei o `self` no a
        // kūmole inā ʻaʻole nul.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Hoʻi iā `None` inā he ʻole ka kuhikuhi, a i ʻole hoʻi e hoʻihoʻi i kahi kuhikuhi i ka waiwai i wahī ʻia i `Some`.
    /// I ka hoʻohālikelike ʻana iā [`as_ref`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka counterpart mutable ʻike iā [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ho omaulia i ke ka offset mai ka laʻau kuhikuhi.
    ///
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Inā kekahi o ka ana ma lalo nei i hehi, i ka hopena mea Undefined hana:
    ///
    /// * ʻO ka poʻomaka hoʻomaka a hopena hoʻi ma ka palena a i ʻole hoʻokahi byte i hala o ka hopena o ka mea like.
    /// E hoʻomaopopo ma Rust, kēlā me kēia ʻano (stack-allocated) i manaʻo ʻia he mea hoʻokaʻawale ʻia.
    ///
    /// * ʻO ka offset i helu ʻia,**i nā bytes**, ʻaʻole hiki ke hoʻonui i kahi `isize`.
    ///
    /// * Na offset i ka pale a hiki i hilinai aku maluna o "wrapping around" ka helu makahiki.ʻO ia, ka huina kikoʻī palena ʻole,**i nā bytes** pono e komo i kahi usize.
    ///
    /// Ke compiler a me ka maʻamau waihona nui UOAAaOON e hōʻoia 'allocations ole i ka nui kahi i offset mea he mea e hopohopo nei.
    /// No ka laʻana, `Vec` a me `Box` e hōʻoia ʻaʻole lākou e hoʻokaʻawale ma mua o nā `isize::MAX` bytes, no laila palekana ʻo `vec.as_ptr().add(vec.len())`.
    ///
    /// ʻAʻole hiki i ka hapanui o nā paepae ke kūkulu i kahi hoʻokaʻawale.
    /// ʻO kahi laʻana, ʻaʻole hiki i kahi paona 64-bit i ʻike ke lawelawe i kahi noi no 2 <sup>63</sup> bytes ma muli o nā palena o ka ʻaoʻao a i ʻole ka hoʻokaʻawale ʻana i kahi wahi.
    /// Eia nō naʻe, lawelawe maikaʻi paha kekahi mau papa 32-bit a me 16-bit i kahi noi no nā bytes `isize::MAX` me nā mea e like me Physical Address Extension.
    ///
    /// Like me neia, hoomanao loaa ana mai allocators a iaiyoe kaha palapala AEIU *i* eʻoi aku ka nui, e lawelawe i keia kuleana pili i.
    ///
    /// E hoomanao i ka hoʻohana 'ana [`wrapping_offset`] kahi ina mau nā palena e pilikia e māʻona.
    /// ʻO ka maikaʻi wale nō o kēia hana ʻo ia ka mea e hiki ai i nā optimizer compiler hōʻeuʻeu hou aʻe.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `offset`.
        // Kūpono ka pointer i loaʻa no nā kākau mai ka mea e pono ai ka mea e kāhea ana e kuhikuhi ia i ka mea like i hoʻokaʻawale ʻia me `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Hoʻomaulia i ka offset mai kahi kuhikuhi ma ka hoʻohana ʻana i ka helu aramika.
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Palekana mau kēia hana, akā ʻaʻole hoʻohana ka kuhikuhi i ka hopena.
    ///
    /// Hoʻopili ka helu kuhikuhi i ka mea like i hoʻokaʻawale ʻia e `self` kuhikuhi.
    /// ʻAʻole paha e hoʻohana ʻia e kiʻi i kahi mea i hoʻokaʻawale ʻia.Note i loko o Rust, ua noʻonoʻo kēlā (stack-allocated) ee iaaanu aey i kaawale anao? Aou mea.
    ///
    /// Ma nā hua'ōlelo, `let z = x.wrapping_offset((y as isize) - (x as isize))` i *i* hana `z` no ia me `y` a hiki ina ua kuhi `T` ua nui `1`, a aole no he hoʻohālana: `z` ua no pili i ka mea `x` ua pili ia, a dereferencing ia mea Undefined hana ole `x`, a Kuhi `y` i ka mea like i hoʻokaʻawale ʻia.
    ///
    /// Hoʻohālikelike ʻia iā [`offset`], hoʻolohi kēia hana i ka koi o ka noho ʻana i loko o ka mea like i hoʻokaʻawale ʻia: ʻo [`offset`] kahi hana i hoʻoholo ʻole ʻia i ka wā e hele ana i nā palena o nā mea.Hoʻokumu ʻo `wrapping_offset` i kahi kuhikuhi akā ke alakaʻi nei i Undefined Behaviour inā e kuhikuhi ʻia kahi kuhikuhi i waho o nā palena o ka mea i hoʻopili ʻia iā ia.
    /// [`offset`] hiki ke hoʻonui maikaʻi ʻia a ʻoi aku ka makemake o ka pāʻālua hana.
    ///
    /// ʻO ka loiloi lohi wale nō ka mea e noʻonoʻo ai i ka waiwai o ka helu kuhikuhi i hāʻawi ʻia, ʻaʻole nā helu waena i hoʻohana ʻia i ka helu ʻana o ka hopena.
    /// ʻO kahi laʻana, like mau ka `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` me `x`.Ma nā hua'ōlelo, e waiho ana i ka anao? Aou mea, a laila, hou-komo ia hope ua ae.
    ///
    /// Inā pono ʻoe e hele i nā palena mea, hoʻolei i ka pointer i ka integer a hana i ka helu ma laila.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // Iterate me ka hoʻohana ʻana i kahi kuhikuhi maka i nā hoʻonui o ʻelua mau mea
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: ʻaʻohe pono o ka `arith_offset` intrinsic e kāhea ʻia ai.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Hoʻi iā `None` inā he ʻole ka kuhikuhi, a i ʻole hoʻi e hoʻihoʻi i kahi kū hoʻokahi i ka waiwai i wahī ʻia i `Some`.Inā uninitialized paha ka waiwai, pono e hoʻohana ma kahi o [`as_uninit_mut`].
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono e kuhikuhi i ka kuhikuhi i kahi hanana mua o `T`.
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    /// (ʻO ka ʻāpana e pili ana i ka hoʻomaka mua ʻia ʻaʻole i hoʻoholo piha ʻia, akā a hiki i kēia manawa, ʻo ke ala palekana wale nō e hōʻoia ai ua hoʻokumu ʻia lākou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // E paʻi ia: "[4, 2, 3]".
    /// ```
    ///
    /// # Mana hōʻole ʻole ʻia
    ///
    /// Inā maopopo ʻoe ʻaʻole hiki i ka pointer ke null a keʻimi nei i kekahi ʻano `as_mut_unchecked` e hoʻihoʻi i ka `&mut T` ma kahi o `Option<&mut T>`, ʻike hiki iā ʻoe ke hōʻalo pololei i ka kuhikuhi.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // E paʻi ia: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka pololei o `self` no
        // kahi kūmole hiki ke hoʻololi inā ʻaʻole nul.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Hoʻi iā `None` inā he ʻole ka kuhikuhi, a i ʻole hoʻi e hoʻihoʻi i kahi kū hoʻokahi i ka waiwai i wahī ʻia i `Some`.
    /// I ka hoʻohālikelike ʻana iā [`as_mut`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// E hoʻihoʻi inā ʻae ʻia nā kuhi ʻelua e like.
    ///
    /// Ma ka holo manawa e like me kēia hana me `self == other`.
    /// Eia nō naʻe, i kekahi mau pōʻaiapili (e laʻa, hōʻuluʻulu manawa loiloi), ʻaʻole hiki ke hoʻoholo i ke kaulike o nā kuhikuhina ʻelua, no laila hiki i kēia hana ke hoʻi mai me ka `false` no nā kuhikuhipuhi ma hope he kaulike.
    ///
    /// Akā ke hoʻi mai ʻo `true`, hōʻoia ʻia nā pointers e like.
    ///
    /// Kēia papa o ke aniani o [`guaranteed_ne`], akā, i kona inverse.Aia nā hoʻohālikelike kuhikuhi no ka hoʻi ʻana o nā hana ʻelua i `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Ke hoʻi waiwai e hoʻololi i ke kaumaha ma muli o ka compiler mana a me ka unsafe kivila e ole hilinai aku ma ka hopena o keia kuleana pili i no imua.
    /// I? Aaeaaaaony e hoʻohana wale i kēia hana no ka lawelawe ana o optimizations kahi spurious `false` hoʻi aiee ma keia papa mai i pili i ka neʻeʻana, akā, pono ka hana ana.
    /// ʻAʻole ʻimi ʻia nā hopena o ka hoʻohana ʻana i kēia hana e hana i ka runtime a me ka code time compile.
    /// ʻAʻole pono e hoʻohana i kēia hana e hoʻolauna i kēlā mau ʻokoʻa, a ʻaʻole pono ia e hoʻokūpaʻa ma mua o ka ʻike maikaʻi ʻana i kēia pilikia.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// E hoʻihoʻi inā ʻae ʻia nā kuhi ʻelua ʻaʻole kaulike.
    ///
    /// Ma ka holo manawa e like me kēia hana me `self != other`.
    /// Eia nō naʻe, i kekahi mau pōʻaiapili (e laʻa, hōʻuluʻulu manawa loiloi), ʻaʻole hiki ke hoʻoholo i ke kaulike ʻole o nā kuhikuhina ʻelua, no laila hiki i kēia hana ke hoʻi mai me ka `false` no nā kuhikuhipuhi ma hope he kaulike ʻole.
    ///
    /// Akā, i ka wa e hoi mai `true`, e ua hoʻohiki nā mea kuhikuhi i e kaiʻewaʻewa.
    ///
    /// ʻO kēia aniani ke aniani o [`guaranteed_eq`], akā ʻaʻole ia ʻo kona keke.Aia nō laʻau kuhikuhi Hoʻohālikelike maikaʻi no ka i nā mana hoʻi `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Ke hoʻi waiwai e hoʻololi i ke kaumaha ma muli o ka compiler mana a me ka unsafe kivila e ole hilinai aku ma ka hopena o keia kuleana pili i no imua.
    /// I? Aaeaaaaony e hoʻohana wale i kēia hana no ka lawelawe ana o optimizations kahi spurious `false` hoʻi aiee ma keia papa mai i pili i ka neʻeʻana, akā, pono ka hana ana.
    /// ʻAʻole ʻimi ʻia nā hopena o ka hoʻohana ʻana i kēia hana e hana i ka runtime a me ka code time compile.
    /// ʻAʻole pono e hoʻohana i kēia hana e hoʻolauna i kēlā mau ʻokoʻa, a ʻaʻole pono ia e hoʻokūpaʻa ma mua o ka ʻike maikaʻi ʻana i kēia pilikia.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Hoʻomaulia i ka mamao ma waena o ʻanuʻu ʻelua.Ka hoi hou waiwai i loko o huahelu o T: ka mamao i loko o nāʻai ua puunaueia e `mem::size_of::<T>()`.
    ///
    /// ʻO kēia ke kekeke o [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Inā kekahi o ka ana ma lalo nei i hehi, i ka hopena mea Undefined hana:
    ///
    /// * pono e kekahi i iho i pale a nā ka ho a me kekahi laʻau kuhikuhi ai kekahiʻai hala i ka hopena o ka ia anao? aou mea.
    /// E hoʻomaopopo ma Rust, kēlā me kēia ʻano (stack-allocated) i manaʻo ʻia he mea hoʻokaʻawale ʻia.
    ///
    /// * He mau mea kuhikuhi pono e *loko mai* ka laʻau kuhikuhi no ka ia mea.
    ///   (E nānā ma lalo no kahi laʻana.)
    ///
    /// * ʻO ka mamao ma waena o nā kuhikuhipuʻuone, i nā byte, pono e helu pono i ka nui o `T`.
    ///
    /// * Ka mamao ma waena o ka mea kuhikuhi,**i loko o nāʻai**, hiki ole hālana ka `isize`.
    ///
    /// * ʻAʻole hiki i ka mamao ma nā palena ke hilinaʻi iā "wrapping around" i kahi kikoʻī.
    ///
    /// ʻAʻole i ʻoi aku ka nui o nā ʻano Rust ma mua o `isize::MAX` a me Rust hoʻokaʻawale a puni ka helu wahi, no laila ʻelua mau kiko i loko o kekahi waiwai o kekahi ʻano Rust `T` e māʻona mau i nā kūlana hope ʻelua.
    ///
    /// Ka mea maʻamau waihona kekahi ano laulā, e hōʻoiaʻiʻo i allocations ole i ka nui kahi i offset mea he mea e hopohopo nei.
    /// No ka laʻana, `Vec` a me `Box` e hōʻoia ʻaʻole lākou e hoʻokaʻawale ma mua o nā `isize::MAX` bytes, no laila e māʻona mau ʻo `ptr_into_vec.offset_from(vec.as_ptr())` i nā kūlana hope ʻelua.
    ///
    /// ʻAʻole hiki i ka hapa nui o nā paepae ke kūkulu i kahi hoʻokaʻawale nui.
    /// ʻO kahi laʻana, ʻaʻole hiki i kahi paona 64-bit i ʻike ke lawelawe i kahi noi no 2 <sup>63</sup> bytes ma muli o nā palena o ka ʻaoʻao a i ʻole ka hoʻokaʻawale ʻana i kahi wahi.
    /// Eia nō naʻe, lawelawe maikaʻi paha kekahi mau papa 32-bit a me 16-bit i kahi noi no nā bytes `isize::MAX` me nā mea e like me Physical Address Extension.
    /// Like me neia, hoomanao loaa ana mai allocators a iaiyoe kaha palapala AEIU *i* eʻoi aku ka nui, e lawelawe i keia kuleana pili i.
    /// (Hoʻomaopopo he palena like kā [`offset`] a me [`add`] a no laila ʻaʻole hiki ke hoʻohana ʻia i nā hoʻokaʻawale nui like ʻole.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Kēia kuleana pili i panics ina `T` mea he 'Aʻohe-pepa paiaʻAno ("ZST").
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Pololei ʻole* hoʻohana:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Hana i ptr2_other i "alias" o ptr2, akā ua kiʻi ʻia mai ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ma muli o ka ptr2_other a me ptr2 i lawe ʻia mai nā kuhikuhina i nā mea like ʻole, ke kuhi ʻana i kā lākou offset ka lawena kūpono ʻole, ʻoiai e kuhikuhi ana lākou i ka helu like.
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Hana Kūpono ʻole
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ho omaulia i ke ka offset mai ka laʻau kuhikuhi (pono no `.offset(count as isize)`).
    ///
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Inā kekahi o ka ana ma lalo nei i hehi, i ka hopena mea Undefined hana:
    ///
    /// * ʻO ka poʻomaka hoʻomaka a hopena hoʻi ma ka palena a i ʻole hoʻokahi byte i hala o ka hopena o ka mea like.
    /// E hoʻomaopopo ma Rust, kēlā me kēia ʻano (stack-allocated) i manaʻo ʻia he mea hoʻokaʻawale ʻia.
    ///
    /// * ʻO ka offset i helu ʻia,**i nā bytes**, ʻaʻole hiki ke hoʻonui i kahi `isize`.
    ///
    /// * ʻAʻole hiki i ka offset i nā palena ke hilinaʻi iā "wrapping around" i ka helu wahi.Ia mea, e pono i ka mana-miomio dala i loko o ka `usize`.
    ///
    /// Ke compiler a me ka maʻamau waihona nui UOAAaOON e hōʻoia 'allocations ole i ka nui kahi i offset mea he mea e hopohopo nei.
    /// No ka laʻana, `Vec` a me `Box` e hōʻoia ʻaʻole lākou e hoʻokaʻawale ma mua o nā `isize::MAX` bytes, no laila palekana ʻo `vec.as_ptr().add(vec.len())`.
    ///
    /// ʻAʻole hiki i ka hapanui o nā paepae ke kūkulu i kahi hoʻokaʻawale.
    /// ʻO kahi laʻana, ʻaʻole hiki i kahi paona 64-bit i ʻike ke lawelawe i kahi noi no 2 <sup>63</sup> bytes ma muli o nā palena o ka ʻaoʻao a i ʻole ka hoʻokaʻawale ʻana i kahi wahi.
    /// Eia nō naʻe, lawelawe maikaʻi paha kekahi mau papa 32-bit a me 16-bit i kahi noi no nā bytes `isize::MAX` me nā mea e like me Physical Address Extension.
    ///
    /// Like me neia, hoomanao loaa ana mai allocators a iaiyoe kaha palapala AEIU *i* eʻoi aku ka nui, e lawelawe i keia kuleana pili i.
    ///
    /// E noʻonoʻo e hoʻohana iā [`wrapping_add`] ma kahi inā paʻakikī paʻakikī kēia mau mea paʻa.
    /// ʻO ka maikaʻi wale nō o kēia hana ʻo ia ka mea e hiki ai i nā optimizer compiler hōʻeuʻeu hou aʻe.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Hoʻomaulia i ke offset mai kahi kuhikuhi (pono no `.offset ((helu ʻia ʻo isize).wrapping_neg())`).
    ///
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Inā kekahi o ka ana ma lalo nei i hehi, i ka hopena mea Undefined hana:
    ///
    /// * ʻO ka poʻomaka hoʻomaka a hopena hoʻi ma ka palena a i ʻole hoʻokahi byte i hala o ka hopena o ka mea like.
    /// E hoʻomaopopo ma Rust, kēlā me kēia ʻano (stack-allocated) i manaʻo ʻia he mea hoʻokaʻawale ʻia.
    ///
    /// * ʻAʻole hiki ke hoʻonui ʻia i ka offset `isize::MAX`**bytes**.
    ///
    /// * Na offset i ka pale a hiki i hilinai aku maluna o "wrapping around" ka helu makahiki.ʻO ia, pono e hoʻopili i ka huina palena ʻole kikoʻī i ka usize.
    ///
    /// Ke compiler a me ka maʻamau waihona nui UOAAaOON e hōʻoia 'allocations ole i ka nui kahi i offset mea he mea e hopohopo nei.
    /// No ka laʻana, `Vec` a me `Box` e hōʻoia ʻaʻole lākou e hoʻokaʻawale ma mua o nā `isize::MAX` bytes, no laila palekana ʻo `vec.as_ptr().add(vec.len()).sub(vec.len())`.
    ///
    /// ʻAʻole hiki i ka hapanui o nā paepae ke kūkulu i kahi hoʻokaʻawale.
    /// ʻO kahi laʻana, ʻaʻole hiki i kahi paona 64-bit i ʻike ke lawelawe i kahi noi no 2 <sup>63</sup> bytes ma muli o nā palena o ka ʻaoʻao a i ʻole ka hoʻokaʻawale ʻana i kahi wahi.
    /// Eia nō naʻe, lawelawe maikaʻi paha kekahi mau papa 32-bit a me 16-bit i kahi noi no nā bytes `isize::MAX` me nā mea e like me Physical Address Extension.
    ///
    /// Like me neia, hoomanao loaa ana mai allocators a iaiyoe kaha palapala AEIU *i* eʻoi aku ka nui, e lawelawe i keia kuleana pili i.
    ///
    /// E hoomanao i ka hoʻohana 'ana [`wrapping_sub`] kahi ina mau nā palena e pilikia e māʻona.
    /// ʻO ka maikaʻi wale nō o kēia hana ʻo ia ka mea e hiki ai i nā optimizer compiler hōʻeuʻeu hou aʻe.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Hoʻomaulia i ka offset mai kahi kuhikuhi ma ka hoʻohana ʻana i ka helu aramika.
    /// (pono no `.wrapping_offset(count as isize)`)
    ///
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Palekana mau kēia hana, akā ʻaʻole hoʻohana ka kuhikuhi i ka hopena.
    ///
    /// Hoʻopili ka helu kuhikuhi i ka mea like i hoʻokaʻawale ʻia e `self` kuhikuhi.
    /// ʻAʻole paha e hoʻohana ʻia e kiʻi i kahi mea i hoʻokaʻawale ʻia.Note i loko o Rust, ua noʻonoʻo kēlā (stack-allocated) ee iaaanu aey i kaawale anao? Aou mea.
    ///
    /// I nā huaʻōlelo ʻē aʻe, ʻaʻole `let z = x.wrapping_add((y as usize) - (x as usize))` * e hana i ka `z` i like me ka `y` inā paha mākou e noʻonoʻo he nui ka `T` i ka `1` a ʻaʻohe mea kahawai Kuhi `y` i ka mea like i hoʻokaʻawale ʻia.
    ///
    /// Hoʻohālikelike ʻia iā [`add`], hoʻolohi kēia hana i ka koi o ka noho ʻana i loko o ka mea like i hoʻokaʻawale ʻia: ʻo [`add`] kahi hana i hoʻoholo ʻole ʻia i ka wā e hele ana i nā palena o nā mea.`wrapping_add` produces ka laʻau kuhikuhi akā nō hiki aku ai i Undefined hana ina ua dereferenced ka laʻau kuhikuhi ia ia mea mai-o-palena o ka mea ka mea, ua pili no.
    /// [`add`] hiki ke hoʻonui maikaʻi ʻia a ʻoi aku ka makemake o ka pāʻālua hana.
    ///
    /// ʻO ka loiloi lohi wale nō ka mea e noʻonoʻo ai i ka waiwai o ka helu kuhikuhi i hāʻawi ʻia, ʻaʻole nā helu waena i hoʻohana ʻia i ka helu ʻana o ka hopena.
    /// ʻO kahi laʻana, like mau ka `x.wrapping_add(o).wrapping_sub(o)` me `x`.I nā huaʻōlelo ʻē aʻe, e waiho ana i ka mea i hoʻokaʻawale ʻia a laila komo hou ʻana ma hope ua ʻae ʻia.
    ///
    /// Inā pono ʻoe e hele i nā palena mea, hoʻolei i ka pointer i ka integer a hana i ka helu ma laila.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // Iterate me ka hoʻohana ʻana i kahi kuhikuhi maka i nā hoʻonui o ʻelua mau mea
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Pai kēia loop "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Hoʻomaulia i ka offset mai kahi kuhikuhi ma ka hoʻohana ʻana i ka helu aramika.
    /// (pono no `.wrapping_offset ((helu ʻia ma isize).wrapping_neg())`)
    ///
    /// `count` aia i loko o nā anakuhi o T;e laʻa, he `count` o 3 e hōʻike ana i kahi kuhikuhi kuhikuhi o nā byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Palekana mau kēia hana, akā ʻaʻole hoʻohana ka kuhikuhi i ka hopena.
    ///
    /// Hoʻopili ka helu kuhikuhi i ka mea like i hoʻokaʻawale ʻia e `self` kuhikuhi.
    /// ʻAʻole paha e hoʻohana ʻia e kiʻi i kahi mea i hoʻokaʻawale ʻia.Note i loko o Rust, ua noʻonoʻo kēlā (stack-allocated) ee iaaanu aey i kaawale anao? Aou mea.
    ///
    /// I nā huaʻōlelo ʻē aʻe, ʻaʻole `let z = x.wrapping_sub((x as usize) - (y as usize))` e * hana i ka `z` i like me ka `y` ʻoiai inā manaʻo mākou he nui ka `T` i ka `1` a ʻaʻohe mea kahawai Kuhi `y` i ka mea like i hoʻokaʻawale ʻia.
    ///
    /// Hoʻohālikelike ʻia iā [`sub`], hoʻolohi kēia hana i ka koi o ka noho ʻana i loko o ka mea like i hoʻokaʻawale ʻia: ʻo [`sub`] kahi hana i hoʻoholo ʻole ʻia i ka wā e hele ana i nā palena o nā mea.Hoʻokumu ʻo `wrapping_sub` i kahi kuhikuhi akā ke alakaʻi nei i Undefined Behaviour inā e kuhikuhi ʻia kahi kuhikuhi i waho o nā palena o ka mea i hoʻopili ʻia iā ia.
    /// [`sub`] hiki ke hoʻonui maikaʻi ʻia a ʻoi aku ka makemake o ka pāʻālua hana.
    ///
    /// ʻO ka loiloi lohi wale nō ka mea e noʻonoʻo ai i ka waiwai o ka helu kuhikuhi i hāʻawi ʻia, ʻaʻole nā helu waena i hoʻohana ʻia i ka helu ʻana o ka hopena.
    /// ʻO kahi laʻana, like mau ka `x.wrapping_add(o).wrapping_sub(o)` me `x`.I nā huaʻōlelo ʻē aʻe, e waiho ana i ka mea i hoʻokaʻawale ʻia a laila komo hou ʻana ma hope ua ʻae ʻia.
    ///
    /// Inā pono ʻoe e hele i nā palena mea, hoʻolei i ka pointer i ka integer a hana i ka helu ma laila.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // Iterate me ka hoʻohana ʻana i ka pointer maka i nā hoʻonui o nā mea (backwards) ʻelua
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Pai kēia loop "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Hoʻonohonoho i ka helu kuhikuhi i `ptr`.
    ///
    /// Inā ʻo `self` kahi kuhi (fat) i kahi ʻano unsized, e hoʻopili wale kēia hana i ka ʻaoʻao kuhikuhi, akā no nā kuhikuhi (thin) i nā ʻano nui, like ka hopena o kēia me kahi hana maʻalahi.
    ///
    /// Loaʻa ka helu kuhi ma hope o `val`, ʻo ia hoʻi, no ka kuhikuhi kuhi momona, like kēia hana me ka hoʻokumu ʻana i kahi kuhikuhi momona hou me ka helu kuhikuhi kikoʻī o `val` akā ka metadata o `self`.
    ///
    ///
    /// # Examples
    ///
    /// ʻOi aku ka maikaʻi o kēia hana no ka ʻae ʻana i ka helu kuhikuhi ma mua o ka pointer ma luna o nā kuhikihi momona.
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // e paʻi "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // Maluhia: Ma Ina o ka lahilahi laʻau kuhikuhi, keia hana mea'ālike
        // i kahi hana maʻalahi.
        // Inā he kuhi kuhi momona, me ka hoʻonohonoho hoʻonohonoho kuhikuhi momona o kēia manawa, ʻo ka māla mua o kēlā ʻano kuhikuhi mau ke kuhi ʻikepili, a hāʻawi ʻia hoʻi pēlā.
        //
        unsafe { *thin = val };
        self
    }

    /// Heluhelu i ka waiwai mai `self` me ka neʻe ʻole.
    /// Waiho kēia i ka hoʻomanaʻo i `self` i hoʻololi ʻole.
    ///
    /// E ʻike iā [`ptr::read`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no ``.
        unsafe { read(self) }
    }

    /// Hana i kahi heluhelu maʻalahi o ka waiwai mai `self` me ka neʻe ʻole.Waiho kēia i ka hoʻomanaʻo i `self` i hoʻololi ʻole.
    ///
    /// Hana ʻia nā hana maʻalahi e hana ma ka hoʻomanaʻo I/O, a hōʻoia ʻia ʻaʻole e elided a i hoʻonohonoho hou ʻia paha e ka mea hōʻuluʻulu ma o nā hana maʻalahi.
    ///
    ///
    /// E ʻike iā [`ptr::read_volatile`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Heluhelu i ka waiwai mai `self` me ka neʻe ʻole.
    /// Waiho kēia i ka hoʻomanaʻo i `self` i hoʻololi ʻole.
    ///
    /// ʻAʻole like me `read`, kuhi ʻole paha ke kuhikuhi.
    ///
    /// E ʻike iā [`ptr::read_unaligned`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kope i nā bytes `count * size_of<T>` mai `self` a i `dest`.
    /// Pili paha ke kumu a me kahi e hele ai.
    ///
    /// NOTE: kēia ke ʻae like hoʻopaʻapaʻa like me [`ptr::copy`].
    ///
    /// E ʻike iā [`ptr::copy`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kope i nā bytes `count * size_of<T>` mai `self` a i `dest`.
    /// ʻO ke kumu a me kahi e hele aku ai ʻaʻole paha * e hāwele.
    ///
    /// NOTE: kēia ke ʻae like hoʻopaʻapaʻa like me [`ptr::copy_nonoverlapping`].
    ///
    /// E ʻike iā [`ptr::copy_nonoverlapping`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kope i nā bytes `count * size_of<T>` mai `src` a i `self`.
    /// Pili paha ke kumu a me kahi e hele ai.
    ///
    /// NOTE: kēia ka ʻaoʻao ʻaoʻao * kūʻē o [`ptr::copy`].
    ///
    /// E ʻike iā [`ptr::copy`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kope i nā bytes `count * size_of<T>` mai `src` a i `self`.
    /// ʻO ke kumu a me kahi e hele aku ai ʻaʻole paha * e hāwele.
    ///
    /// NOTE: kēia ka ʻaoʻao ʻaoʻao * kūʻē o [`ptr::copy_nonoverlapping`].
    ///
    /// E ʻike iā [`ptr::copy_nonoverlapping`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Hana i ka mea luku (inā kekahi) o ke kumukūʻai kuhikuhi.
    ///
    /// E ʻike iā [`ptr::drop_in_place`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Kaha i kahi wahi hoʻomanaʻo me ka waiwai i hāʻawi ʻia me ka heluhelu ʻole a hoʻokuʻu ʻana paha i ka waiwai kahiko.
    ///
    ///
    /// E ʻike iā [`ptr::write`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `write`.
        unsafe { write(self, val) }
    }

    /// Kāhea i ka memset ma ke kuhikuhi kikoʻī, e hoʻonohonoho ana i nā bytes o `count * size_of::<T>()` o ka hoʻomanaʻo e hoʻomaka ana ma `self` a i `val`.
    ///
    ///
    /// E ʻike iā [`ptr::write_bytes`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Hanaʻia he yiaeaiiacaaeneiie kahakaha iho o ka iaiyoe wahi me ka haawi waiwai me ka heluhelu 'ole e kahe mai ana i ka mea kahiko cia.
    ///
    /// Hana ʻia nā hana maʻalahi e hana ma ka hoʻomanaʻo I/O, a hōʻoia ʻia ʻaʻole e elided a i hoʻonohonoho hou ʻia paha e ka mea hōʻuluʻulu ma o nā hana maʻalahi.
    ///
    ///
    /// E ʻike iā [`ptr::write_volatile`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Kaha i kahi wahi hoʻomanaʻo me ka waiwai i hāʻawi ʻia me ka heluhelu ʻole a hoʻokuʻu ʻana paha i ka waiwai kahiko.
    ///
    ///
    /// ʻAʻole like me `write`, kuhi ʻole paha ke kuhikuhi.
    ///
    /// E ʻike iā [`ptr::write_unaligned`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Hoʻololi i ka waiwai ma `self` me `src`, hoʻihoʻi i ka waiwai kahiko, me ka waiho ʻole ʻana i kekahi.
    ///
    ///
    /// E ʻike iā [`ptr::replace`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `replace`.
        unsafe { replace(self, src) }
    }

    /// Kuapo i nā waiwai ma nā wahi hoʻololi ʻelua o ka ʻano like, me ka ʻole o ka deinitializing ʻana.
    /// Pākuʻi paha lākou, ʻaʻole like me `mem::swap` i like like.
    ///
    /// E ʻike iā [`ptr::swap`] no nā hopohopo palekana a me nā laʻana.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `swap`.
        unsafe { swap(self, with) }
    }

    /// Hoʻomaulia i ka offset e pono ai e hoʻopili i ka pointer i mea e hoʻopili ai iā `align`.
    ///
    /// Inā hiki ʻole ke kaulike i ka kuhikuhi, hoʻi ka hoʻokō iā `usize::MAX`.
    /// ʻAe ʻia no ka hoʻokō ʻana e *hoʻi*`usize::MAX` mau.
    /// Wale nō kāu algorithm ka hana hiki hilinaʻi i noho i ka usable offsetʻaneʻi, i kona pono.
    ///
    /// Na offset Ua olelo ia ma ka helu o `T` hehee wale, aʻaʻole nāʻai.Hiki ke hoʻohana ʻia ke kumukūʻai me ka hana `wrapping_add`.
    ///
    /// ʻAʻohe mea e hōʻoia i kēlā me kēia e offsetting i ka pointer ʻaʻole e kahe a hele paha ma mua o ka hoʻokaʻawale a ke kuhikuhi.
    ///
    /// Aia i ka mea kelepona e hōʻoia i ka hoʻihoʻi o ka hoʻihoʻi pololei i nā huaʻōlelo ʻē aʻe ma mua o ke kaulike.
    ///
    /// # Panics
    ///
    /// ʻO ka hana panics inā ʻaʻole `align` ka mana-o-ʻelua.
    ///
    /// # Examples
    ///
    /// Ke kiʻi nei i ka `u8` e pili ana me `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ʻoiai hiki ke hoʻopili i ka pointer ma o `offset`, kuhikuhi ʻia ma waho o ka hoʻokaʻawale ʻana
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` ua nānā ʻia e lilo i mana o 2 ma luna
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Hoʻihoʻi i ka lōʻihi o kahi ʻāpana maka.
    ///
    /// ʻO ka waiwai i hoʻihoʻi ʻia ka helu o **mau mea**, ʻaʻole ka helu o nā byte.
    ///
    /// Palekana kēia hana, ʻoiai ʻaʻole hiki ke hoʻolei ʻia i ka ʻāpana maka i kahi ʻāpana slice no ka mea null a unaligned paha ka kuhikuhi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: palekana kēia no ka mea aia iā `*const [T]` a me `FatPtr<T>` ke ʻano like.
            // Hiki iā `std` ke hana i kēia hōʻoia.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Hoʻi i ka maka laʻau kuhikuhi ana i ka māhele o ka aooa.
    ///
    /// Ua like kēia me ka hoʻolei ʻana iā `self` i ka `*mut T`, akā ʻoi aku ka palekana-ʻano.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Hoʻihoʻi i kahi kuhikuhi maka i kahi mea a i ʻole mea lawelawe, me ka hana ʻole ʻana i nā palena.
    ///
    /// Kahea ana keia hana i ka mai-o-iho i pale a inideka paha ia `self` mea ole dereferencable ka *[undefined hana]* a hiki ina ua ole hoʻohana 'ia i ke kūpono laʻau kuhikuhi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: hōʻoia ka mea kāhea i ka `self` hiki ke hoʻoliʻiliʻi a me ka `index` i loko o nā palena.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Hoʻi iā `None` inā he ʻole ka kuhikuhi, a i ʻole hoʻi e hoʻihoʻi i kahi ʻāpana like i ka waiwai i wahī ʻia i `Some`.
    /// I ka hoʻohālikelike ʻana iā [`as_ref`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka counterpart mutable ʻike iā [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Ka laʻau kuhikuhi pono e [valid] no ka heluhelu no ka `ptr.len() * mem::size_of::<T>()` he nui nāʻai, a me ka mea pono e pono ua kūponoʻia.ʻO kēia ke ʻano:
    ///
    ///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
    ///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.
    ///
    ///     * Pono e hoʻopili pono i ka pointer no nā ʻoki lōʻihi ʻole.
    ///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
    ///
    ///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
    ///
    /// * pono e ole ka nui ma mua o `isize::MAX` Ka huina nui `ptr.len() * mem::size_of::<T>()` o ka māhele.
    ///   E ʻike i nā palapala palekana o [`pointer::offset`].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// E nānā pū [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Hoʻi iā `None` inā he nul ka pointer, a i ʻole hoʻi e hoʻihoʻi i kahi ʻāpana kū hoʻokahi i ka waiwai i wahī ʻia i `Some`.
    /// I ka hoʻohālikelike ʻana iā [`as_mut`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Ke kāhea ʻana i kēia hana, pono ʻoe e ʻike pono *ʻo* ka poʻomanaʻo ʻo NULL *a i ʻole* ʻoiaʻiʻo nā mea āpau:
    ///
    /// * Pono ka pointer i [valid] no nā heluhelu a kākau no `ptr.len() * mem::size_of::<T>()` i nā bytes he nui, a pono e hoʻopili pono ʻia.ʻO kēia ke ʻano:
    ///
    ///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
    ///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.
    ///
    ///     * Pono e hoʻopili pono i ka pointer no nā ʻoki lōʻihi ʻole.
    ///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
    ///
    ///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
    ///
    /// * pono e ole ka nui ma mua o `isize::MAX` Ka huina nui `ptr.len() * mem::size_of::<T>()` o ka māhele.
    ///   E ʻike i nā palapala palekana o [`pointer::offset`].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// E nānā pū [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Kaulike no nā kuhikuhi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}