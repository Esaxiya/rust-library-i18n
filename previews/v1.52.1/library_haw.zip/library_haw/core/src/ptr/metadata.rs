#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Hāʻawi i ke ʻano metadata kuhikuhi o kekahi ʻano kuhi.
///
/// # Metadata pointer
///
/// Hiki ke noʻonoʻo ʻia nā ʻano pointer maka a me nā ʻano kūmole ma Rust i hana ʻia i ʻelua ʻāpana:
/// heʻikepili laʻau kuhikuhi e paka me ka iaiyoe aae? ana o ka waiwai, a me kekahi metadata.
///
/// No ka statically-pepa paia ano (e hoʻokō i ka `Sized` traits) i maikai like no `extern` ano, mea kuhikuhi i mai la ia ia e "lahilahi": metadata mea Aʻohe-pepa paia a me kona 'ano o `()`.
///
///
/// ʻO nā pointers iā [dynamically-sized types][dst] i ʻōlelo ʻia he "ākea" a i ʻole "momona", he metadata non-zero-nui kā lākou.
///
/// * No nā ʻohana nona ka kahua hope loa he DST, ʻo metadata ka metadata no ka pā hope loa
/// * No ka mea `str` ʻano, metadata o ka lōʻihi o nāʻai like `usize`
/// * No ka māheleʻAno e like `[T]`, metadata o ka lōʻihi ma ka 'ikamu like `usize`
/// * No ka trait nā mea e like `dyn SomeTrait`, metadata o [`DynMetadata<Self>`][DynMetadata] (e like `DynMetadata<dyn SomeTrait>`)
///
/// I ka future, loaʻa i ka ʻōlelo Rust nā ʻano ʻano hou i loaʻa nā metadata kuhikuhi kikoʻī.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # ʻO `Pointee` trait
///
/// ʻO ke kiko o kēia trait kāna `Metadata` ʻano pili, ʻo ia ʻo `()` a i ʻole `usize` a i ʻole `DynMetadata<_>` e like me ia i hōʻike ʻia ma luna.
/// Hoʻokomo ʻia ia no kēlā me kēia ʻano.
/// Hiki ke manaʻo ʻia e hoʻokō ʻia i kahi pōʻaiapili generic, ʻoiai me ka ʻole o ka pili e pili ana.
///
/// # Usage
///
/// Hiki ke hoʻopau ʻia nā pointers maka i ka helu ʻikepili a me nā ʻikepili metadata me kā lākou hana [`to_raw_parts`].
///
/// ʻOkoʻa, hiki ke huki ʻia nā metadata me ka hana [`metadata`].
/// Hiki ke hāʻawi ʻia i kahi kūmole i [`metadata`] a koi ikaika ʻia.
///
/// A (possibly-wide) laʻau kuhikuhi hiki e kau hoʻi i kahi hookahi, mai kona helu wahi a me ka metadata me [`from_raw_parts`] a [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ke 'ano no ka metadata i ka mea kuhikuhi, a i maopopo nä haumäna i `Self`.
    #[lang = "metadata_type"]
    // NOTE: E mālama iā trait bounds ma `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` i lōkahi me kēlā mau mea:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ʻO nā kuhi kuhikuhi i nā ʻano e hoʻokō nei i kēia trait alias he "lahilahi".
///
/// Hoʻopili kēia i nā ʻano statically-`Sized` a me nā ʻano `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: mai stabilize keia mua trait Iu i ka pilina paʻa i loko o ka 'ōlelo?
pub trait Thin = Pointee<Metadata = ()>;

/// Unuhi i ka metadata ʻāpana o kahi kuhikuhi.
///
/// ʻO nā waiwai o ke ʻano `*mut T`, `&T`, a i ʻole `&mut T` hiki ke hoʻoili pololei ʻia i kēia ʻoihana ke koi ikaika lākou iā `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Ke palekana nei ke kiʻi ʻana i ka waiwai mai ka hui `PtrRepr` mai ka * const T
    // a me nā PtrComponents<T>i nā hoʻonohonoho hoʻomanaʻo like.
    // Hiki iā std ke hana i kēia hōʻoia.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ano he (possibly-wide) maka laʻau kuhikuhi mai i kaʻikepili helu wahi a me ka metadata.
///
/// Palekana kēia hana akā ʻaʻole palekana ka kuhikuhi kuhikuhi i ka pale.
/// No ka slices, ike i ka palapala kuhikuhi o [`slice::from_raw_parts`] no ka palekana koi.
/// No nā mea trait, pono e hele mai ka metadata mai kahi kuhikuhi i kahi ʻano like i hoʻomoe ʻia.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Ke palekana nei ke kiʻi ʻana i ka waiwai mai ka hui `PtrRepr` mai ka * const T
    // a me nā PtrComponents<T>i nā hoʻonohonoho hoʻomanaʻo like.
    // Hiki iā std ke hana i kēia hōʻoia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Hana i nā hana like me [`from_raw_parts`], koe wale nō ka hoʻihoʻi ʻia ʻana o kahi kuhikuhi kuhi `*mut` maka, i kūʻē i kahi kuhikuhi `* const` maka.
///
///
/// E ʻike i nā palapala o [`from_raw_parts`] no nā kikoʻī hou aʻe.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Ke palekana nei ke kiʻi ʻana i ka waiwai mai ka hui `PtrRepr` mai ka * const T
    // a me nā PtrComponents<T>i nā hoʻonohonoho hoʻomanaʻo like.
    // Hiki iā std ke hana i kēia hōʻoia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Pono pono manual impl e pale iā `T: Copy` i paʻa.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Pono pono manual impl e pale iā `T: Clone` i paʻa.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Ke metadata no ka `Dyn = dyn SomeTrait` trait mea type.
///
/// He kuhikuhi ia i ka vtable (virtual call table) e hōʻike ana i nā ʻike kūpono āpau e manipulate ai i ke ʻano pōhaku paʻa i mālama ʻia i loko o kahi trait mea.
/// Aia i loko o ka vtable:
///
/// * nui ʻano
/// * kaulike kaulike
/// * kahi kuhikuhi i ka `drop_in_place` impl o ke ʻano (he no-op paha no ka ʻikepili kahiko-maʻamau)
/// * kuhikuhi i nā ʻano hana āpau no ka hoʻokomo o ka ʻano o ka trait
///
/// E hoʻomaopopo he kūikawā nā mea mua ʻekolu no ka mea pono lākou e hoʻokaʻawale, hoʻoiho, a hana i kekahi mea trait.
///
/// Hiki ke kapa inoa i kēia mea kūkulu me kahi ʻāpana ʻano ʻaʻole ia he `dyn` trait mea (e laʻa me `DynMetadata<u64>`) akā ʻaʻole no ka loaʻa ʻana o kahi waiwai kūpono o ia mea.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// ʻO ka prefiks maʻamau o nā vtables āpau.Hahai ʻia e nā ʻōkuhi hana no nā kiʻina trait.
///
/// ʻO ka kikoʻī hoʻokō pilikino o `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Hoʻihoʻi i ka nui o ke ʻano e pili ana i kēia vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Hoʻihoʻi i ke kaulike o ke ʻano e pili ana i kēia vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Hoike i ka nui a me ka hoʻopololei pu me ka `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: ua hoʻokuʻu ka mea hoʻopili i kēia vtable no kahi ʻano Rust paʻa
        // ʻike ʻia he hoʻonohonoho kūpono.ʻO ke kumu kūpono e like me `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Pono nā impls manual e hōʻalo i nā palena `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}