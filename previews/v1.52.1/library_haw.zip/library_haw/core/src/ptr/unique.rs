use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ʻO kahi wahī e hoʻopuni ana i kahi `*mut T` non-null maka e hōʻike ana he ʻona ka mea nona kēia wahī.
/// Pono no ke kūkulu ʻana i nā abstractions e like me `Box<T>`, `Vec<T>`, `String`, a me `HashMap<K, V>`.
///
/// ʻAʻole like me `*mut T`, `Unique<T>` ʻano "as if" kahi hanana o `T`.
/// Hoʻohana ia `Send`/`Sync` inā `T` ʻo `Send`/`Sync`.
/// Hōʻike ia i ke ʻano o ka aliasing ikaika e hōʻoia i kahi hanana o `T` hiki ke manaʻo:
/// ʻaʻole pono e hoʻololi i ka mea kuhikuhi o ka pointer me ka ʻole o kahi ala kūʻokoʻa i ka ʻona nona.
///
/// Inā kānalua ʻoe inā he pololei e hoʻohana i `Unique` no kāu mau kumu, e noʻonoʻo e hoʻohana i `NonNull`, nona nā semantics nāwaliwali.
///
///
/// ʻAʻole like me `*mut T`, pono ʻole ke kuhikuhi i ka manawa ʻole, ʻoiai inā ʻaʻole i hoʻowahāwahā ʻia ka kuhikuhi.
/// Pēlā kēia e hoʻohana ai nā enum i kēia waiwai i pāpā ʻia ma ke ʻano he hoʻokae-like ka nui o `Option<Unique<T>>` me `Unique<T>`.
/// Eia nō naʻe hiki ke kau i ka helu inā ʻaʻole ia i hoʻokuʻu ʻia.
///
/// ʻAʻole like me `*mut T`, `Unique<T>` covariant ma luna o `T`.
/// Pono pololei kēia i kēlā me kēia ʻano no ka mea e kākoʻo ana i nā koi ʻae inoa a Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ʻaʻohe hopena o kēia māka no ka ʻokoʻa, akā pono
    // no ka dropck e hoʻomaopopo he loiloi mākou i `T`.
    //
    // No nā kikoʻī, e ʻike:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `Send` ke kuhi inā X0 `T` ʻo `Send` no ka mea ʻaʻole i unuhi ʻia ka ʻikepili a lākou e kuhikuhi ai.
/// E hoʻomaopopo he mana ʻole kēia invasant aliasing e ka ʻōnaehana ʻano;ʻo ka abstraction e hoʻohana ana i ka `Unique` pono e hoʻokō iā ia.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `Sync` ke kuhi inā X0 `T` ʻo `Sync` no ka mea ʻaʻole i unuhi ʻia ka ʻikepili a lākou e kuhikuhi ai.
/// E hoʻomaopopo he mana ʻole kēia invasant aliasing e ka ʻōnaehana ʻano;ʻo ka abstraction e hoʻohana ana i ka `Unique` pono e hoʻokō iā ia.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// I ka mea hou `Unique` i ua dangling, akā, pono-ua kūponoʻia.
    ///
    /// He mea pono kēia no ka hoʻomaka ʻana i nā ʻano a ka palaualelo e hoʻokaʻawale ai, e like me kā `Vec::new` hana.
    ///
    /// E hoʻomaopopo he hiki ke kuhikuhi i ka helu kuhikuhi i kahi kuhikuhi kūpono i kahi `T`, ʻo ia hoʻi ʻaʻole pono e hoʻohana ʻia kēia ma ke ʻano he "not yet initialized" sentinel waiwai.
    /// ʻO nā ʻano e hoʻokaʻawale palaualelo e nānā pono i ka hoʻomaka ʻana e kekahi ʻano ʻē aʻe.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: hoʻihoʻi ʻo mem::align_of() i kahi kuhikuhi kūpono ʻole.ʻO ka
        // mahalo ʻia nā ʻano e kāhea iā new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Hana i kahi `Unique` hou.
    ///
    /// # Safety
    ///
    /// `ptr` pono ole-nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka ʻole o `ptr`.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Hana i kahi `Unique` hou inā `ptr` non-null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Ua hōʻoia ʻia ka kuhikuhi a ʻaʻole nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Loaʻa iā ia ke kumumanaʻo `*mut` kumu.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dere rujukan i ka ʻike.
    ///
    /// Ke kūpono wa e ola ana ua paa ia i ka pakiko ai keia hoi "as if" ka mea, he nae he manawa no T mea e noho aie.
    /// Inā makemake ʻia kahi lōʻihi (unbound) lōʻihi, e hoʻohana iā `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        unsafe { &*self.as_ptr() }
    }

    /// Hoʻopau hou ʻia ka ʻike i ka ʻike.
    ///
    /// Ke kūpono wa e ola ana ua paa ia i ka pakiko ai keia hoi "as if" ka mea, he nae he manawa no T mea e noho aie.
    /// Inā makemake ʻia kahi lōʻihi (unbound) lōʻihi, e hoʻohana iā `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole hiki ke hoʻololi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kuhi i kahi kuhikuhi o kekahi ʻano.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Hana ʻo Unique::new_unchecked() i kahi kū hoʻokahi a me nā pono e pono ai
        // ka mea kuhikuhi i hāʻawi ʻole ʻia e nul.
        // ʻOiai ke hele nei mākou iā mākou iho ma ke ʻano he kuhikuhi, ʻaʻole hiki ke nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Maluhia: A mutable maopopo kahi hiki ole e Yard
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}