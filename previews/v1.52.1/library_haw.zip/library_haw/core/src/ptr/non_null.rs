use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` akā non-zero a me covariant.
///
/// He pinepine ka pololei mea, i ka wa e hana anaʻikepili hale a ka hoʻohana maka mea kuhikuhi i ka hana, akā, ua ultimately oi mea e hana no ka mea, o kona mau waiwai.Inā ʻaʻole ʻoe e maopopo inā ʻoe e hoʻohana i `NonNull<T>`, hoʻohana wale iā `*mut T`!
///
/// Like `*mut T`, ka laʻau kuhikuhi pono mau e ole-Yard, a hiki ina ka laʻau kuhikuhi ua loa dereferenced.Kēia mea ai i enums e hoʻohana i kēia papaia waiwai me ka discriminant-`Option<NonNull<T>>` i ka like ka nui me `* mut T`.
/// Eia nō naʻe hiki ke kau i ka helu inā ʻaʻole ia i hoʻokuʻu ʻia.
///
/// Haʻalele `*mut T`, `NonNull<T>` i wae ia e covariant ma `T`.Hoʻohana kēia i hiki ke hoʻohana i ka `NonNull<T>` ke kūkulu ʻana i nā ʻano covariant, akā hoʻolauna i ka makaʻu o ka unsoundness inā hoʻohana ʻia i kahi ʻano pono ʻole e covariant.
/// (ʻO ke koho ʻē aʻe i hana ʻia no `*mut T` ʻoiai ʻo ke ʻano ʻenehana ke kumu o ka unsoundness i ke kāhea ʻana i nā hana palekana.)
///
/// Pololei ʻo Covariance no nā abstraction palekana, e like me `Box`, `Rc`, `Arc`, `Vec`, a me `LinkedList`.ʻO kēia ka hihia no ka mea hāʻawi lākou i kahi API lehulehu e ukali i nā lula maʻamau XOR hiki ke hoʻololi ʻia o Rust.
///
/// Inā ʻaʻole hiki i kāu ʻano ke lilo i covariant, pono ʻoe e hōʻoia aia i loko o kahi kahua hou aʻe e hoʻolako i ka invariance.ʻO ka pinepine o kēia kahua he ʻano [`PhantomData`] e like me `PhantomData<Cell<T>>` a i ʻole `PhantomData<&'a mut T>`.
///
/// E hoʻomaopopo he `From` kahi hanana `NonNull<T>` no `&T`.Eia naʻe, ʻaʻole kēia e hoʻololi i ka ʻoiaʻiʻo o ka hoʻololi ʻana ma o kahi (pointer i lawe ʻia mai kahi) kuhikuhi kūlike ʻole ʻia ka lawena pili ʻole inā kū ka hoʻololi i loko o [`UnsafeCell<T>`].Pēlā nō ia no ka hoʻokumu ʻana i kahi kūmole hiki ke hoʻololi ʻia mai kahi kūkaʻi like
///
/// Ke hoʻohana nei i kēia hanana `From` me ka ʻole o `UnsafeCell<T>`, nāu ke kuleana e hōʻoia ʻaʻole e kāhea ʻia ʻo `as_mut`, a ʻaʻole hoʻohana ʻia ʻo `as_ptr` no ka hoʻololi.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ʻaʻole `Send` nā kuhi no ka mea ua ʻae ʻia ka ʻikepili a lākou e kuhikuhi ai.
// NB, pono ʻole kēia impl, akā pono e hāʻawi i nā leka uila ʻoi aku ka maikaʻi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ʻaʻole `Sync` nā kuhi no ka mea ua ʻae ʻia ka ʻikepili a lākou e kuhikuhi ai.
// NB, pono ʻole kēia impl, akā pono e hāʻawi i nā leka uila ʻoi aku ka maikaʻi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// I ka mea hou `NonNull` i ua dangling, akā, pono-ua kūponoʻia.
    ///
    /// He mea pono kēia no ka hoʻomaka ʻana i nā ʻano a ka palaualelo e hoʻokaʻawale ai, e like me kā `Vec::new` hana.
    ///
    /// E hoʻomaopopo he hiki ke kuhikuhi i ka helu kuhikuhi i kahi kuhikuhi kūpono i kahi `T`, ʻo ia hoʻi ʻaʻole pono e hoʻohana ʻia kēia ma ke ʻano he "not yet initialized" sentinel waiwai.
    /// ʻO nā ʻano e hoʻokaʻawale palaualelo e nānā pono i ka hoʻomaka ʻana e kekahi ʻano ʻē aʻe.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: hoʻihoʻi ʻo mem::align_of() i kahi usize non-zero a laila hoʻolei ʻia
        // iā a * mut T.
        // No laila, ʻaʻole nul ka `ptr` a mahalo ʻia nā ʻano no ke kāhea ʻana iā new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// E hoʻihoʻi i nā kuhikuhi pili i ka waiwai.I ka hoʻohālikelike ʻana iā [`as_ref`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka counterpart mutable ʻike iā [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Hoʻihoʻi i kahi kuhikuhi kūikawā i ka waiwai.I ka hoʻohālikelike ʻana iā [`as_mut`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Hana i kahi `NonNull` hou.
    ///
    /// # Safety
    ///
    /// `ptr` pono ole-nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka ʻole o `ptr`.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Hana i kahi `NonNull` hou inā `ptr` non-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Ua hōʻoia ʻia ka kuhikuhi a ʻaʻole nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Hana i nā hana like me [`std::ptr::from_raw_parts`], koe wale nō i hoʻihoʻi ʻia kahi kuhikuhi `NonNull`, i kūʻē i kahi kuhikuhi `*const` maka.
    ///
    ///
    /// E ʻike i nā palapala o [`std::ptr::from_raw_parts`] no nā kikoʻī hou aʻe.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: ʻO ka hopena o `ptr::from::raw_parts_mut` non-null no ka mea ʻo `data_address` ka.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// E hoʻopau i kahi kuhikuhi (hiki ākea paha) i kahi helu a me nā ʻikepili metadata.
    ///
    /// Hiki ke kūkulu hou ʻia ka kuhikuhi ma hope me [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Loaʻa iā ia ke kumumanaʻo `*mut` kumu.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// E hoʻihoʻi i kahi kuhikuhi pili i ka waiwai.Inā uninitialized paha ka waiwai, pono e hoʻohana ma kahi o [`as_uninit_ref`].
    ///
    /// No ka counterpart mutable ʻike iā [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono e kuhikuhi i ka kuhikuhi i kahi hanana mua o `T`.
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    /// (ʻO ka ʻāpana e pili ana i ka hoʻomaka mua ʻia ʻaʻole i hoʻoholo piha ʻia, akā a hiki i kēia manawa, ʻo ke ala palekana wale nō e hōʻoia ai ua hoʻokumu ʻia lākou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole.
        unsafe { &*self.as_ptr() }
    }

    /// Hoʻihoʻi i kahi kuhikuhi kūikawā i ka waiwai.Inā uninitialized paha ka waiwai, pono e hoʻohana ma kahi o [`as_uninit_mut`].
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Pono e hoʻopili pono i ka pointer.
    ///
    /// * Pono e "dereferencable" i ke ʻano i wehewehe ʻia ma [the module documentation].
    ///
    /// * Pono e kuhikuhi i ka kuhikuhi i kahi hanana mua o `T`.
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    /// (ʻO ka ʻāpana e pili ana i ka hoʻomaka mua ʻia ʻaʻole i hoʻoholo piha ʻia, akā a hiki i kēia manawa, ʻo ke ala palekana wale nō e hōʻoia ai ua hoʻokumu ʻia lākou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: pono i ka mea kelepona e hōʻoia i ka hui ʻana o `self` me nā mea āpau
        // nā koi no kahi kūmole hiki ke hoʻololi.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kuhi i kahi kuhikuhi o kekahi ʻano.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // Maluhia: `self` mea he `NonNull` laʻau kuhikuhi i ka pono 'ole-Yard
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Hoʻokumu i kahi ʻoki maka ʻole nul mai kahi pointer a lahilahi a me ka lōʻihi.
    ///
    /// Ke `len` i kekahi manaʻo hoʻopiʻi o ka helu ana o **oihana mua**, i ka helu o nāʻai.
    ///
    /// Palekana kēia hana, akā palekana ʻole ka hoʻoneʻe ʻana i ka waiwai hoʻihoʻi.
    /// E ʻike i nā palapala o [`slice::from_raw_parts`] no nā koi palekana ʻoki.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ho okumu i kekahi māhele laʻau kuhikuhi wā e hoʻomaka ana me ka laʻau kuhikuhi i ka hehee ai mua
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Note i keia hana artificially hōʻike i ka hoʻohana 'ana i kēia hana, akā,' e māhele= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: ʻO `data` kahi kuhikuhi `NonNull` i kūpono ʻole ʻole
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Hoʻihoʻi i ka lōʻihi o kahi ʻoki maka ʻole nul.
    ///
    /// ʻO ka waiwai i hoʻihoʻi ʻia ka helu o **mau mea**, ʻaʻole ka helu o nā byte.
    ///
    /// Palekana kēia hana, ʻoiai ʻaʻole hiki i ka non-null raw slice ke hoʻoiho ʻia i kahi ʻāpana no ka mea ʻaʻohe wahi kūpono o ka kuhikuhi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Hoʻihoʻi i kahi kuhikuhi kuhi ʻole i ka buffer o ka ʻāpana.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: ʻike mākou he non-null ʻo `self`.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Hoʻi i ka maka laʻau kuhikuhi ana i ka māhele o ka aooa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// E hoʻihoʻi i kahi kuhikuhi pili i kahi ʻāpana o nā waiwai uninitialized paha.I ka hoʻohālikelike ʻana iā [`as_ref`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka counterpart mutable ʻike iā [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Ka laʻau kuhikuhi pono e [valid] no ka heluhelu no ka `ptr.len() * mem::size_of::<T>()` he nui nāʻai, a me ka mea pono e pono ua kūponoʻia.ʻO kēia ke ʻano:
    ///
    ///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
    ///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.
    ///
    ///     * Pono e hoʻopili pono i ka pointer no nā ʻoki lōʻihi ʻole.
    ///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
    ///
    ///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
    ///
    /// * pono e ole ka nui ma mua o `isize::MAX` Ka huina nui `ptr.len() * mem::size_of::<T>()` o ka māhele.
    ///   E ʻike i nā palapala palekana o [`pointer::offset`].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   I ke kikoʻī, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono e hoʻomanaʻo ʻia ka hoʻomanaʻo o ka pointer (koe wale nō ma loko o `UnsafeCell`).
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// E nānā pū [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Hoʻihoʻi i kahi kuhikuhi kūikawā i kahi ʻāpana o nā waiwai uninitialized paha.I ka hoʻohālikelike ʻana iā [`as_mut`], ʻaʻole koi kēia i ka waiwai e hoʻomaka mua ʻia.
    ///
    /// No ka ʻāpana like i ʻike ʻia iā [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ka wā hea keia hana, e loaʻa i ka hōʻoia 'ana a pau o ka penei ka oiaio:
    ///
    /// * Pono ka pointer i [valid] no nā heluhelu a kākau no `ptr.len() * mem::size_of::<T>()` i nā bytes he nui, a pono e hoʻopili pono ʻia.ʻO kēia ke ʻano:
    ///
    ///     * pono e iloko o ke holoʻokoʻa hoomanao huahelu ana o kēia māhele i loko o ka hookahi anao? aou mea!
    ///       ʻAʻole hiki i nā ʻāpana ke kau ma waena o nā mea i hoʻokaʻawale ʻia.
    ///
    ///     * Pono e hoʻopili pono i ka pointer no nā ʻoki lōʻihi ʻole.
    ///     Hoʻokahi kumu no kēia ka hilinaʻi ʻana o ka hoʻonohonoho hoʻonohonoho enum i nā kuhikuhi (me nā ʻāpana o nā lōʻihi) e kaulike a ʻole ʻole e hoʻokaʻawale iā lākou mai nā ʻikepili ʻē aʻe.
    ///
    ///     Hiki iā ʻoe ke loaʻa kahi kuhikuhi i hiki ke hoʻohana ʻia ma ke ʻano he `data` no nā ʻoki lōʻihi ʻole me [`NonNull::dangling()`].
    ///
    /// * pono e ole ka nui ma mua o `isize::MAX` Ka huina nui `ptr.len() * mem::size_of::<T>()` o ka māhele.
    ///   E ʻike i nā palapala palekana o [`pointer::offset`].
    ///
    /// * Pono ʻoe e hoʻokō i nā rula hoʻohiki a Rust, no ka mea, ua koho wale ʻia ke ola `'a` a ʻaʻole ia e hōʻike i ke ola maoli o ka ʻikepili.
    ///   Eia kekahi, no ka lōʻihi o kēia ola ʻana, ʻaʻole pono ke kiʻi ʻia ka hoʻomanaʻo i kuhikuhi ʻia (heluhelu a kākau ʻia) ma o nā kuhikuhi ʻē aʻe.
    ///
    /// Pili kēia inā ʻaʻole hoʻohana ʻia ka hopena o kēia hana!
    ///
    /// E nānā pū [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // He maluhia like `memory` mea i pololei ia no ka heluhelu a kākau no ka `memory.len()` he nui nāʻai.
    /// // E noke i ke kahea `memory.as_mut()` ua i 'ae' aneʻi me ka maʻiʻo i ke uninitialized.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Hoʻihoʻi i kahi kuhikuhi maka i kahi mea a i ʻole mea lawelawe, me ka hana ʻole ʻana i nā palena.
    ///
    /// Kahea ana keia hana i ka mai-o-iho i pale a inideka paha ia `self` mea ole dereferencable ka *[undefined hana]* a hiki ina ua ole hoʻohana 'ia i ke kūpono laʻau kuhikuhi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: hōʻoia ka mea kāhea i ka `self` hiki ke hoʻoliʻiliʻi a me ka `index` i loko o nā palena.
        // A ʻo kahi hopena, ʻaʻole hiki ke kuhikuhi i ka hopena.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: ʻAʻole hiki ke null kahi kuhikuhi kuhikuhi kūikawā, no laila nā kūlana no
        // new_unchecked() mahalo ʻia.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Maluhia: A mutable maopopo kahi hiki ole e Yard.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: ʻAʻole hiki ke null kahi kūmole, no laila nā kūlana no
        // new_unchecked() mahalo ʻia.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}