//! Hewa i ka lawelawe ʻana me ke ʻano `Result`.
//!
//! [`Result<T, E>`][`Result`] ʻo ia ke ʻano i hoʻohana ʻia no ka hoʻi ʻana a hoʻolaha ʻana i nā hewa.
//! He enum ia me nā ʻano, [`Ok(T)`], e hōʻike nei i ke kūleʻa a loaʻa kahi waiwai, a me [`Err(E)`], e hōʻike nei i nā hemahema a me kahi waiwai hewa.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Hoʻihoʻi nā hana i [`Result`] i nā manawa a pau i manaʻo ʻia e hewa a loaʻa hou.I ka `std` crate, hoʻohana nui ʻia ʻo [`Result`] no [I/O](../../std/io/index.html).
//!
//! E wehewehe a hoʻohana ʻia kahi hana maʻalahi e hoʻi ana i [`Result`] e like me:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! Maʻemaʻe a maʻalahi hoʻi ka hoʻohālikelike ʻana i ke kumu hoʻohālikelike ma [`Hualoaʻa] no nā hihia maʻalahi, akā hele mai ʻo [`Result`] me kekahi mau ʻano hana maʻalahi e ʻoi aku ka succinct.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // Hana nā hana `is_ok` a me `is_err` i kā lākou e ʻōlelo ai.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` hoʻopau i ka `Result` a hana i kekahi.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // E hoʻohana iā `and_then` e hoʻomau i ka helu ʻana.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // E hoʻohana i `or_else` e lawelawe i ka hewa.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Pau ka hopena a hoʻihoʻi i nā ʻike me `unwrap`.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Pono e hoʻohana i nā hopena
//!
//! ʻO kahi pilikia maʻamau me ka hoʻohana ʻana i nā waiwai hoʻihoʻi e hōʻike i nā hemahema he maʻalahi ke nānā ʻole i ka waiwai hoʻihoʻi, a laila ʻaʻole e lawelawe i ka hewa.
//! [`Result`] ua hōʻike ʻia me ka hiʻona `#[must_use]`, ka mea e hoʻopuka i ka mea hōʻuluʻulu i kahi ʻōlelo aʻoaʻo ke nānā ʻia kahi waiwai Result.
//! Hoʻohana kēia i [`Result`] me nā hana i hiki ke hālāwai i nā hemahema akā ʻaʻole hoʻi e hoʻihoʻi i kahi waiwai kūpono.
//!
//! E noʻonoʻo i ka hana [`write_all`] i wehewehe ʻia no nā ʻano I/O e ka [`Write`] trait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: Hoʻohana ka wehewehe maoli o [`Write`] iā [`io::Result`], ʻo ia ka mea like me ka manaʻo like [[hopena]]<T, `[`io: :Error`]`>...*
//!
//! ʻAʻole hana kēia hana i kahi waiwai, akā e holo paha ke kākau.He mea koʻikoʻi ka lawelawe ʻana i ka hihia hemahema, a ʻaʻole * kākau i kahi mea e like me kēia:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Inā `write_all` mau hewa, a laila ʻaʻole mākou e ʻike, no ka mea nānā ʻole ʻia ka waiwai hoʻihoʻi.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Inā ʻoe e hana * kākau i kēlā ma Rust, hāʻawi ka mea hōʻuluʻulu iā ʻoe i kahi ʻōlelo aʻoaʻo (ma ka paʻamau, kaohi ʻia e `unused_must_use` lint).
//!
//! Hiki paha iā ʻoe, inā ʻaʻole ʻoe makemake e kālele i ka hemahema, e hōʻoia wale i ka kūleʻa me [`expect`].
//! Kēia makemake panic ina ke kahakaha iho ke aloha, ina he marginally maikaʻi kēia memo e hoike ana i ke kumu:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! E hōʻoiaʻiʻo paha ʻoe i ka kūleʻa:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! A i ʻole hoʻolaha i ka hemahema i ka stack call me [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # ʻO ka mea nīnau nīnau, `?`
//!
//! Ke kākau ʻana i ka pāʻālua e kāhea ana i nā hana he nui e hoʻihoʻi i ke ʻano [`Result`], hiki ke hoʻoluhi ka hana hewa.
//! Ke ninau mark Aʻole, [`?`], hūnā iā kekahi o ka boilerplate o nä ÿale e hewa i ka hea noae.
//!
//! Hoʻololi ʻia kēia:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Hoʻi wawe i ka hewa
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Me kēia:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Hoʻi wawe i ka hewa
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *ʻOi aku ka maikaʻi!*
//!
//! ʻO ka hoʻopau ʻana i ka manaʻo me [`?`] e hopena i ka waiwai ([`Ok`]) holomua i wehe ʻole ʻia, ke ʻole ʻo [`Err`] ka hopena, a laila hoʻi ʻo [`Err`] i ka wanaʻao mai ka hana hoʻopili.
//!
//!
//! [`?`] hiki ke hoʻohana wale ʻia i nā hana e hoʻihoʻi iā [`Result`] ma muli o ka hoʻi mua o [`Err`] e hāʻawi ai.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` he ʻano e hōʻike i ka ([`Ok`]) kūleʻa a i ʻole ([`Err`]) kūleʻa.
///
/// E ʻike i ka [module documentation](self) no nā kikoʻī.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Loaʻa ka waiwai kūleʻa
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Loaʻa ka helu hewa
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// ʻAno hoʻokō
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Ke noi nei i nā waiwai i loaʻa
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻi iā `true` inā [`Ok`] ka hopena.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Hoʻi iā `true` inā [`Err`] ka hopena.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Hoʻi iā `true` inā he [`Ok`] ka hopena i loaʻa ka waiwai i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Hoʻi iā `true` inā he [`Err`] ka hopena i loaʻa ka waiwai i hāʻawi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Mea hoʻopili no kēlā me kēia ʻano
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻololi mai `Result<T, E>` a [`Option<T>`].
    ///
    /// Pio `self` i loko o ka [`Option<T>`], e hoopau ana `self`, a i kāpaeʻia i ka hewa, ina kekahi.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Hoʻololi mai `Result<T, E>` a [`Option<E>`].
    ///
    /// Hoʻololi iā `self` i [`Option<E>`], e hoʻopau ana iā `self`, a hoʻolei i ka waiwai kūleʻa, inā kekahi.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter no ka hana ʻana me nā kūmole
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻololi mai `&Result<T, E>` a `Result<&T, &E>`.
    ///
    /// Produces he hou `Result`, i loaʻa i ka olua i loko o ka palapala, e waiho ana i ka palapala ma ka wahi.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Hoʻololi mai `&mut Result<T, E>` a `Result<&mut T, &mut E>`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ke hoʻololi nei i nā waiwai i loaʻa
    /////////////////////////////////////////////////////////////////////////

    /// Nā palapala ʻāina i `Result<T, E>` i `Result<U, E>` ma ke noi ʻana i kahi hana i kahi waiwai [`Ok`] i loaʻa, e waiho nei i kahi [`Err`] waiwai i hoʻopili ʻole ʻia.
    ///
    ///
    /// Hiki ke hoʻohana ʻia kēia hana e haku i nā hopena o nā hana ʻelua.
    ///
    /// # Examples
    ///
    /// E paʻi i nā helu ma kēlā me kēia laina o ke aho i hoʻonui ʻia i ʻelua.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Pili i kahi hana i ka waiwai i loaʻa (inā [`Ok`]), a i ʻole hoʻihoʻi i ka paʻamau i hāʻawi ʻia (inā [`Err`]).
    ///
    /// Manaʻo hoʻopiʻi kū'ē i hooholoia i `map_or` i eagerly loiloi ';inā ʻoe e hele i ka hopena o kahi kāhea hana, makemake ʻia e hoʻohana iā [`map_or_else`], i loiloi lohi ʻia.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Nā palapala 'āina `Result<T, E>` a `U` ma ke noi ʻana i kahi hana i kahi waiwai [`Ok`] i loaʻa, a i ʻole kahi hana fallback i kahi waiwai [`Err`] i loaʻa.
    ///
    ///
    /// Hiki ke hoʻohana ʻia kēia hana e wehe i kahi hopena kūleʻa ke lawelawe nei i kahi hemahema.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Nā palapala ʻāina i `Result<T, E>` i `Result<T, F>` ma ke noi ʻana i kahi hana i kahi waiwai [`Err`] i loaʻa, e waiho nei i kahi [`Ok`] waiwai i hoʻopili ʻole ʻia.
    ///
    ///
    /// Hiki ke hoʻohana ʻia kēia hana e hele i loko o kahi hopena kūleʻa ke lawelawe nei i kahi hemahema.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ʻO nā mea kūkulu Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻihoʻi i kahi iterator ma luna o ka waiwai i loaʻa paha.
    ///
    /// Hāʻawi ka iterator i hoʻokahi waiwai inā [`Result::Ok`] ka hopena, inā ʻaʻole.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Hoʻihoʻi i kahi iterator hiki ke hoʻololi ʻia ma luna o ka waiwai i loaʻa i loko.
    ///
    /// Hāʻawi ka iterator i hoʻokahi waiwai inā [`Result::Ok`] ka hopena, inā ʻaʻole.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Hana ʻo Boolean i nā waiwai, hoihoi a palaualelo
    /////////////////////////////////////////////////////////////////////////

    /// Hoʻi iā `res` inā [`Ok`] ka hopena, a i ʻole hoʻi e hoʻihoʻi i ka [`Err`] waiwai o `self`.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Aloha `op` ina o ka hopena o [`Ok`], ai ole, e huli hou i ka [`Err`] waiwai o `self`.
    ///
    ///
    /// Hiki ke hoʻohana i kēia hana no ka kahe kaohi ma muli o nā waiwai `Result`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Hoʻi iā `res` inā [`Err`] ka hopena, a i ʻole hoʻi e hoʻihoʻi i ka [`Ok`] waiwai o `self`.
    ///
    /// Kuhi ʻia nā hoʻopaʻapaʻa i `or`;ina oe e hele ana i ka hopena o ka papa hea, ka mea, ua? aeiiaiaoaony e hoʻohana [`or_else`], i ua lazily loiloi '.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Kāhea iā `op` inā [`Err`] ka hopena, a i ʻole hoʻi e hoʻihoʻi i ka [`Ok`] waiwai o `self`.
    ///
    ///
    /// Hiki ke hoʻohana i kēia hana no ka kahe kaohi ma muli o nā helu hopena.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Ok`] i loaʻa a i ʻole kahi paʻamau i hāʻawi ʻia.
    ///
    /// Kuhi ʻia nā hoʻopaʻapaʻa i `unwrap_or`;inā ʻoe e hele i ka hopena o kahi kāhea hana, makemake ʻia e hoʻohana iā [`unwrap_or_else`], i loiloi lohi ʻia.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Ok`] i hoʻopaʻa ʻia a helu ʻia paha mai kahi pani.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Ok`] i loko, e hoʻopau ana i ka waiwai `self`, me ka nānā ʻole ʻana ʻaʻole ka [`Err`] ka waiwai.
    ///
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana ma [`Err`] ka *[ʻano hana ʻole i hoʻoholo ʻia**.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Undefined ana!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // Maluhia: pono e kokuaia oia e ka Caller ka maluhia like.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Err`] i loko, e hoʻopau ana i ka waiwai `self`, me ka nānā ʻole ʻana ʻaʻole ka [`Ok`] ka waiwai.
    ///
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia hana ma [`Ok`] ka *[ʻano hana ʻole i hoʻoholo ʻia**.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Undefined ana!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // Maluhia: pono e kokuaia oia e ka Caller ka maluhia like.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Maps he `Result<&T, E>` i ka `Result<T, E>` ma ka hoʻopiliʻana kahi o ka `Ok` mahele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Maps he `Result<&mut T, E>` i ka `Result<T, E>` ma ka hoʻopiliʻana kahi o ka `Ok` mahele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Nā palapala 'āina `Result<&T, E>` i kahi `Result<T, E>` ma ke kāloli ʻana i nā ʻike o ka ʻāpana `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Nā palapala 'āina `Result<&mut T, E>` i kahi `Result<T, E>` ma ke kāloli ʻana i nā ʻike o ka ʻāpana `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Hoʻihoʻi i ka waiwai [`Ok`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// # Panics
    ///
    /// Panics inā he [`Err`] ka waiwai, me kahi leka panic me ka leka i hala, a me ka ʻike o ka [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Ok`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// Ma muli o kēia hana panic, hoʻonāwaliwali ʻia ka hoʻohana ʻana.
    /// Ma kahi o, makemake e hoʻohana i ke ʻano hoʻohālikelike a lawelawe i ka hihia [`Err`] me ka maopopo, a i ʻole kāhea iā [`unwrap_or`], [`unwrap_or_else`], a i ʻole [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics inā he [`Err`] ka waiwai, me kahi leka panic i hāʻawi ʻia e ka waiwai [`Err`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Hoʻihoʻi i ka waiwai [`Err`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// # Panics
    ///
    /// Panics inā he [`Ok`] ka waiwai, me kahi leka panic me ka leka i hala, a me ka ʻike o ka [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Hoʻihoʻi i ka waiwai [`Err`] i loko, e hoʻopau ana i ka waiwai `self`.
    ///
    /// # Panics
    ///
    /// Panics inā he [`Ok`] ka waiwai, me kahi leka panic maʻamau i hāʻawi ʻia e ka waiwai [`Ok`] 's.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Hoʻihoʻi i ka waiwai [`Ok`] i hoʻopaʻa ʻia a i ʻole kahi paʻamau
    ///
    /// Pau ka hoʻopaʻapaʻa `self` a laila, inā [`Ok`], hoʻihoʻi i ka waiwai i loaʻa, a i ʻole inā [`Err`], hoʻihoʻi i ka helu paʻamau no kēlā ʻano.
    ///
    ///
    /// # Examples
    ///
    /// Pio he kaula i ka helu, huli poorly-hana kaula i loko o 0 (ka paʻamau waiwai io no integers).
    /// [`parse`] hoʻololi i kahi aho i kekahi ʻano ʻē aʻe e hoʻopili iā [`FromStr`], e hoʻihoʻi nei i kahi [`Err`] ma ka hemahema.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Hoʻihoʻi i ka waiwai [`Ok`] i loaʻa, ʻaʻole naʻe panics.
    ///
    /// ʻAʻole like me [`unwrap`], ʻike ʻia kēia ʻano hana ʻaʻole panic e pili ana i nā ʻano hopena i hoʻokō ʻia ai.
    /// No laila, hiki ke hoʻohana ʻia ma kahi o `unwrap` ma ke ʻano he mālama mālama mālama ʻole e hōʻuluʻulu inā hoʻololi ʻia ke ʻano hemahema o ka `Result` i kahi hewa i hiki ke hana maoli.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Hoʻololi mai `Result<T, E>` (a i ʻole `&Result<T, E>`) a i `Result<&<T as Deref>::Target, &E>`.
    ///
    /// Coerces ka [`Ok`] ʻano ʻokoʻa o ka [`Result`] kumu ma o [`Deref`](crate::ops::Deref) a hoʻihoʻi i ka [`Result`] hou.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Hoʻololi mai `Result<T, E>` (a i ʻole `&mut Result<T, E>`) a i `Result<&mut <T as DerefMut>::Target, &mut E>`.
    ///
    /// Coerces ka [`Ok`] ʻano ʻokoʻa o ka [`Result`] kumu ma o [`DerefMut`](crate::ops::DerefMut) a hoʻihoʻi i ka [`Result`] hou.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Hoʻololi i `Result` o `Option` i `Option` o `Result`.
    ///
    /// `Ok(None)` e kiʻi ʻia i `None`.
    /// `Ok(Some(_))` a kiʻi ʻia ʻo `Err(_)` i `Some(Ok(_))` a me `Some(Err(_))`.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Hoʻololi mai `Result<Result<T, E>, E>` a `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Flattening lawe aku oe i kekahi kiʻekiʻe o aiacayueony i kekahi manawa wale:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Hoike i ka [`Ok`] waiwai ina `self` o `Ok`, a me ka [`Err`] waiwai ina `self` o `Err`.
    ///
    /// I nā huaʻōlelo ʻē aʻe, hoʻihoʻi kēia hana i ka waiwai (ka `T`) o kahi `Result<T, T>`, me ka nānā ʻole inā `Ok` a `Err` paha ka hopena.
    ///
    /// Hiki ke hoʻohana pono ʻia i kēia me nā API e like me [`Atomic*::compare_exchange`], a i ʻole [`slice::binary_search`], akā i nā hihia kahi āu e mālama ʻole ai inā `Ok` ka hopena a ʻaʻole paha.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// He hana kaʻawale kēia e hōʻemi ai i ka nui o nā kiʻina hana
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Nā hoʻokō Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Hoʻihoʻi i kahi iterator e hoʻopau ana ma luna o ka waiwai i loaʻa i loko.
    ///
    /// Hāʻawi ka iterator i hoʻokahi waiwai inā [`Result::Ok`] ka hopena, inā ʻaʻole.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ʻO nā hopena Iterators
/////////////////////////////////////////////////////////////////////////////

/// He iterator ma kahi kuhikuhi i ka [`Ok`] ʻano o [`Result`].
///
/// Hāʻawi ka iterator i hoʻokahi waiwai inā [`Ok`] ka hopena, inā ʻaʻole.
///
/// Hana ʻia e [`Result::iter`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// He iterator ma luna o kahi kuhikuhi hiki ke hoʻololi i ka [`Ok`] ʻano o [`Result`].
///
/// Hana ʻia e [`Result::iter_mut`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// He iterator ma luna o ka waiwai ma ka [`Ok`] ʻano o ka [`Result`].
///
/// Hāʻawi ka iterator i hoʻokahi waiwai inā [`Ok`] ka hopena, inā ʻaʻole.
///
/// Hoʻokumu ʻia kēia estr e ka hana [`into_iter`] ma [`Result`] (hāʻawi ʻia e [`IntoIterator`] trait).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Lawe i kēlā me kēia mehana i ka `Iterator`: inā he `Err`, ʻaʻohe mea i lawe hou ʻia, a hoʻihoʻi ʻia ka `Err`.
    /// Inā ʻaʻole `Err` e kū mai, hoʻihoʻi ʻia kahi ipu me nā waiwai o kēlā me kēia `Result`.
    ///
    /// Eia ka he kumu hoohalike i xi na helu i loko o ka vector, o kéu no hoʻohālana:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Eia kekahi laʻana e hoʻāʻo e unuhi i kekahi mai kekahi papa inoa o nā integers, i kēia manawa ke nānā nei i ka underflow:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Eia kahi hoʻololi ma ka laʻana ma mua, e hōʻike ana ʻaʻole lawe ʻia nā mea hou mai `iter` ma hope o ka `Err` mua.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Ma muli o ke kolu o ka mea i hoʻokumu i kahi kahe, ʻaʻole i lawe ʻia nā mea hou aʻe, no laila ʻo ka waiwai hope loa o `shared` he 6 (= `3 + 2 + 1`), ʻaʻole 16.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Hiki ke hoʻololi i kēia me Iterator::scan ke pani ʻia kēia hewa hana.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}