#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! ʻAha hui uila e pili pū ana i na hana mau (FFI) ka pū'āʻana.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Kūlike ia i ko C's `void` ʻano ke hoʻohana ʻia ma ke ʻano he [pointer].
///
/// I ke kumu, `*const c_void` like ia me C's `const void*` a me `*mut c_void` like ia me C's `void*`.
/// I aku la, keia mea *ole* o ka ia me C ka `void` hoʻi type, i mea Rust ka `()` type.
///
/// E ÷ ike mea kuhikuhi i opaque hoailona ia mea i loko o FFI, a `extern type` ua stabilized, ka mea, ua? Aeiiaiaoaony e hoʻohana i ka newtype wrapper puni ka neleʻai ke kaua.
///
/// E ʻike i ka [Nomicon] no nā kikoʻī.
///
/// Kekahi hiki hoʻohana `std::os::raw::c_void` ina e makemake e kākoʻo elemakule Rust compiler ia i 1.1.0.
/// Ma hope o Rust 1.30.0, ka mea i hou-hoʻoliloʻia kēia ho'ākāka 'ana.
/// No ka 'ike hou aku, e heluhelu [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, no ka LLVM e ike i ka mea ole laʻau kuhikuhiʻano a me ka hoʻolōʻihi 'ia' oihana e like malloc(), ua pono, e loaʻa ia poe me i8 * ma LLVM bitcode.
// Ke enum hoʻohanaʻaneʻi e hōʻoiaʻiʻo keia a kāohi 'ia paha hoʻohana kūpono' ole o ka "raw" 'ano ma ka paulele i ka hoʻomana Lolina wale ka.
// Pono mākou i ʻelua mau mea like, no ka mea hoʻopiʻi ka mea hoʻopukapuka e pili ana i ke ʻano repr a i ʻole a pono mākou i hoʻokahi ʻano ʻokoʻa a i ʻole e noho ʻole ʻia ka enum a ma ka liʻiliʻi e hoʻowahāwahā i nā kuhikuhi i UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Ka hoʻokumu maʻamau o `va_list`.
// I ka inoa o WIP, ka hoʻohana 'ana `VaListImpl` no ka manawa.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant ma `'f`, no laila, kēlā me kēia `VaListImpl<'f>` mea ua nakinakiʻia i ka māhele o ke kuleana pili i ka mea Ka ho'ākāka 'ia i loko o
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Abiezera manaʻo o ka `va_list`.
/// E ʻike i ka [AArch64 Procedure Call Standard] no nā kikoʻī hou aʻe.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Abiezera manaʻo o ka `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Abiezera manaʻo o ka `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// A wrapper no ka `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Hoohuli i ka `VaListImpl` i loko o ka `VaList` i mea aeaie-hana maʻalahi me C ka `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Hoohuli i ka `VaListImpl` i loko o ka `VaList` i mea aeaie-hana maʻalahi me C ka `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Pono e hoʻohana i ka VaArgSafe trait i nā kikowaena lehulehu, akā naʻe, ʻaʻole pono ka trait pono e ʻae ʻia e hoʻohana ma waho o kēia kōmike.
// I hiki mea hoʻohana e? Ii ka trait no ka hou type (ma ia hele 'ana o ka va_arg kūʻiʻoo e e hoʻohana ma o ka hou type) hoʻoneʻe' ia paha i ka i undefined kolohe.
//
// FIXME(dlrobertson): I mea e hoʻohana ai i ka VaArgSafe trait i kahi kikowaena lehulehu akā e hōʻoia ʻaʻole hiki ke hoʻohana ʻia ma kahi ʻē aʻe, pono e hoʻolaha ākea ka trait ma waena o kahi mana pilikino.
// Once RFC 2145, ua hoʻokō nana aku i loko o ka hoʻomaikaʻi i kēia.
//
//
//
//
mod sealed_trait {
    /// Trait e ʻae ana i nā ʻano ʻae ʻia e hoʻohana ʻia me [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Mua i ka mea e hiki mai ana arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Kope i ka `va_list` ma kēia wahi.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SAFETY: kākau mākou i ka `MaybeUninit`, no laila ua hoʻomaka mua ʻia a kū kānāwai ʻo `assume_init`
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: e kāhea kēia iā `va_end`, akā ʻaʻohe ala maʻemaʻe i
        // kumu hoʻomalu i `drop` mauʻia inlined i loko o kona Caller, no laila, ke `va_end` e loaa ka pololei hea aku, mai ka ia hana me ka like `va_copy`.
        // `man va_end` Hawaii i C pono keia, a me LLVM holo nōhie penei ka C semantics, no laila mākou e pono e mālama pono ana i `va_end` ua mau kapa, mai ka ia kuleana pili i like `va_copy`.
        //
        // No nā kikoʻī hou aʻe, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ke hana nei kēia no kēia manawa, ʻoiai ʻo `va_end` kahi no-op ma nā pahuhopu LLVM āpau.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Luku i ka arglist `ap` ma hope o ka hoʻomaka ʻana me `va_start` a i ʻole `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// E kope i ka wahi o ka helu `src` i ka papa inoa `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Wahie, ka hoʻopaʻapaʻa o ka 'ano `T` mai ka `va_list` `ap` a xi i ka manaʻo hoʻopiʻi kū'ē `ap` wahi no.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}