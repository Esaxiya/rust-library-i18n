#![stable(feature = "core_hint", since = "1.27.0")]

//! Eʻauʻa i ka compiler mea e loli ai pehea kuhi e ke kinoea a hoʻomākaukau leʻa.
//! Eʻauʻa i e i hoʻouluulu manawa paha runtime.

use crate::intrinsics;

/// Hoʻomaopopo 'o ia i ka compiler i keia wahi i loko o ka eiae mea ole reachable, ka ho'ā hou optimizations.
///
/// # Safety
///
/// ʻO ke kiʻi ʻana i kēia hana he hana maʻamau *undefined behavior*(UB).ʻO ka mea kikoʻī, kuhi ka mea hōʻuluʻulu ʻaʻole pono e hiki i nā UB āpau, a no laila e hoʻopau i nā lālā āpau i hiki i kahi kāhea iā `unreachable_unchecked()`.
///
/// Like a pau he nui o UB, ina keia mea mahuʻi huli mai ia e hewa, 'o ia hoʻi, ka `unreachable_unchecked()` kahea mea nae reachable i waena o nā mea a pau e hiki i ka mana hoʻomalu kahe, ka compiler e pili i ka hewa kaʻoi loa kou akamai, a me ka hiki i kekahi manawa, a hiki ino seemingly unrelated kivila, e kauoha ana difficult-pilikia pilikia.
///
///
/// E hoʻohana i kēia hana wale nō ke hōʻoia ʻoe ʻaʻole e kāhea ke code iā ia.
/// Inā ʻole, e noʻonoʻo e hoʻohana i ka [`unreachable!`] macro, ka mea i ʻae ʻole i ka optimization akā e panic ke hoʻokō ʻia.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` He mau maikaʻi (ole 'Aʻohe), mai keia wahi aku `checked_div` e loa hoʻi `None`.
/////
///     // No laila, ʻo ka mea ʻē aʻe branch hiki ʻole ke kiʻi ʻia.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // Maluhia: o ka maluhia aelike no `intrinsics::unreachable` pono
    // e kokuaia oia e ka Caller.
    unsafe { intrinsics::unreachable() }
}

/// Hoʻouna i kahi kuhikuhi mīkini e hōʻailona i ka mea hana e holo nei ia i kahi loop-loop spin-busy ("spin lock").
///
/// Ma ka loaʻa 'ka milo-loop neaiaea ka unu lawelawe hiki hoʻoikaika kona hana ana, no ka hoʻohālike, ke ole ia ka mana a me ka hoʻololiʻana hyper-pae.
///
/// Kēia kuleana pili i He okoa mai [`thread::yield_now`] a pololei e haawi i ko i ka'ōnaehana ka scheduler, no ka mea hoi `spin_loop` i ole E hoʻolauna me ka pae'ōnaehana nenoaiu.
///
/// A ho'ānoʻole hihia no ka `spin_loop` ua hoʻokō kau palena ia ana optimistic spinning i loko o ka CAS loop ma ka hoʻononiakahi primitives.
/// Eʻaloʻana pilikia e like makakoho hahana, ka mea, ua ikaika pono i ua 'ōlelo ka milo loop ma hope o ka finite nui o iterations, a he kūpono wahi syscall ua i.
///
///
/// **Kahakaha**: Ma nā paepae i kākoʻo ʻole i ka loaʻa ʻana o nā hōʻailona wili-loop ʻaʻole hana iki kēia hana.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A kaʻana'ātoma waiwai ia pae paha, e hana i kūlike o
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ma ke kāʻei kua ka pae mākou e ho'ōla i ka waiwai
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Hana i kahi hana, a laila ola ka waiwai
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Back ma luna o mākou heʻulaʻula, ua kali no ka waiwai e e huapalapala
/// while !live.load(Ordering::Acquire) {
///     // Ka milo loop mea he hoʻomaoe hou akulaʻo ia i ka CPU ia mākou huli akā, e kali ana, paha,ʻaʻole no ka nui loa
/////
///     hint::spin_loop();
/// }
///
/// // I ka waiwai ua manawa hoʻonoho
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // Maluhia: ʻo `cfg` attr hōʻoia 'ia ai ia mākou wale hooko i kēia ma x86 pale.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // Maluhia: ʻo `cfg` attr hōʻoia 'ia ai ia mākou wale hooko i kēia ma x86_64 pale.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // Maluhia: ʻo `cfg` attr hōʻoia 'ia ai ia mākou wale hooko i kēia ma aarch64 pale.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // Maluhia: ʻo `cfg` attr hōʻoia 'ia ai ia mākou wale hooko i kēia ma lima pale
            // me ka kākoʻo no ka v6 hiʻona.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// ʻO kahi hana e ʻike ai *__ kuhikuhi __* i ka mea hoʻopili e pessimistic maximally e pili ana i ka `black_box` i hiki ke hana.
///
/// Haʻalele [`std::convert::identity`], he Rust compiler ua paipai e kuhi ana `black_box` ke hana `dummy` i loko o kekahi mea hiki henua pololei ala i Rust karaima mai ua 'ae' ia me ka undefined hana i loko o ka oihana kuhi i hoʻolaunaʻia ma.
///
/// Hoʻohana kēia waiwai i ka `black_box` pono no ke kākau ʻana i ke code kahi i makemake ʻole ʻia ai kekahi optimization, e like me nā pae hoʻohālikelike.
///
/// 'Ōlelo Aʻo nae, i `black_box` mea wale (a hiki wale nō ke) i hoakaka ia ma ka "best-effort" manawa.Ke loa ia i ka mea hiki aeie optimisations e oko ma luna o ka anuu, a kuhi-gen backend hoʻohana.
/// hiki ole papahana hilinai aku maluna o `black_box` no *pono* ma kekahi aoao.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Pono mākou e "use" i ka paio ma kekahi ʻano ʻaʻole hiki i ka LLVM ke komo i loko, a ma nā pahuhopu e kākoʻo iā ia hiki iā mākou ke leverage i ka hui i loko e hana i kēia.
    // LLVM ka hoohalike ana hoi, o ka LIKE LIKEʻaha kanaka a pau o ia mea, ka, pono, heʻeleʻele pahu.
    // ʻAʻole kēia ka hoʻokō ʻoi loa ma muli o ka deoptimize o nā mea ʻoi aku ma mua o kā mākou makemake, akā maikaʻi ia.
    //
    //

    #[cfg(not(miri))] // He mea pono i ka, hoʻomaoe hou akula, no laila ka mea, o ka lole e skip ma Miri.
    // Ka maluhia: o ka LIKE LIKE aha mea he ole-Kaiaulu.
    unsafe {
        // FIXME: Hiki ole hoʻohana `asm!` no ka mea, aole ia i kākoʻo MIPS a me nā architectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}