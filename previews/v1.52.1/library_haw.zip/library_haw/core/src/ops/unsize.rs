use crate::marker::Unsize;

/// Trait e hōʻike ana he kuhikuhi kēia a i ʻole kahi mea wahī no hoʻokahi, kahi e hiki ai ke hana unsizing ma ka pointee.
///
/// E ʻike i ka [DST coercion RFC][dst-coerce] a me [the nomicon entry on coercion][nomicon-coerce] no nā kikoʻī hou aʻe.
///
/// No nā ʻano pointer builtin, kipaku nā kuhi i `T` i nā kuhikuhi i `U` inā `T: Unsize<U>` ma o ka hoʻololi ʻana mai kahi kuhikuhi kikoʻī i kahi kuhikuhi kuhi momona.
///
/// No nā ʻano maʻamau, hana ka coercion ma o ke kāohi ʻana iā `Foo<T>` i `Foo<U>` i hāʻawi ʻia i impl o `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Hiki ke kākau ʻia kēlā ʻano impl inā `Foo<T>` kahi kahua non-phantomdata hoʻokahi e pili ana iā `T`.
/// Inā `Bar<T>` ke ʻano o kēlā kahua, pono e ola kahi hoʻokō o `CoerceUnsized<Bar<U>> for Bar<T>`.
/// E holo ka coercion e ka coercing i ka `Bar<T>` kahua i `Bar<U>` a hoʻopiha i ke koena o nā kahua mai `Foo<T>` e hana i `Foo<U>`.
/// E huki pono kēia i lalo i kahi kahua kuhikuhi a koi iā ia.
///
/// ʻO ka maʻamau, no nā mea kuhikuhi akamai e hoʻokō ʻoe i `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, me kahi `?Sized` koho i hoʻopaʻa ʻia ma `T` ponoʻī.
/// No nā ʻano wahī e hoʻopili pono iā `T` e like me `Cell<T>` a me `RefCell<T>`, hiki iā ʻoe ke hoʻokomo pololei iā `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// E hoʻokuʻu kēia i nā koikoi o nā ʻano e like me ka hana `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] Ua hoʻohana 'ia i hoailona ia ano i hiki ke coerced i DSTs inā ma hope o mea kuhikuhi.Hoʻokomo ʻia ia e ka mea hoʻopili.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Hoʻohana ʻia kēia no ka palekana mea, e nānā ai hiki ke hoʻouna ʻia i kahi ʻano o ka mea loaʻa.
///
/// ʻO kahi laʻana o ka trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}