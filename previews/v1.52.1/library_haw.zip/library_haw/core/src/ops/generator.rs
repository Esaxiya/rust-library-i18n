use crate::marker::Unpin;
use crate::pin::Pin;

/// ʻO ka hopena o ka hoʻomaka ʻana o kahi generator.
///
/// Ua hoʻihoʻi ʻia kēia enum mai ke ʻano `Generator::resume` a hōʻike i nā kumukūʻai hoʻihoʻi hiki ke hiki i kahi generator.
/// I kēia manawa kūlike kēia i kahi kuhi kau (`Yielded`) a i ʻole kahi kiko hoʻopau (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Hoʻomaha ʻia ka mīkini hana wāwahie me kahi waiwai.
    ///
    /// Kuhi kēia mokuʻāina ua kāpae ʻia kahi mea hana, a kūlike ia i kahi ʻōlelo `yield`.
    /// ʻO ke kumukūʻai i hāʻawi ʻia i loko o kēia ʻano ʻokoʻa e kūlike i ka manaʻo i hāʻawi ʻia iā `yield` a ʻae i nā mea hana i ka hāʻawi i kahi waiwai i kēlā me kēia manawa a lākou e hāʻawi ai.
    ///
    ///
    Yielded(Y),

    /// Hoʻopau ka mea hana generator me ka waiwai hoʻihoʻi.
    ///
    /// Kuhi kēia mokuʻāina ua hoʻopau ka hana a kahi mea hana me ka waiwai i hāʻawi ʻia.
    /// I ka manawa i hoʻihoʻi mai kahi mea hana mana iā `Complete` manaʻo ʻia he hewa programmer e kāhea hou iā `resume`.
    ///
    Complete(R),
}

/// Hoʻokomo ʻia ka trait e nā ʻano hana generator builtin.
///
/// ʻO nā mea hana uila, i kapa ʻia he coroutine, i kēia manawa he hiʻohiʻona ʻōlelo hoʻokolohua ma Rust.
/// Hoʻohui ʻia i nā mea hana [RFC 2033] i kēia manawa e hāʻawi mua i kahi palaka hale no ka async/await syntax akā e hoʻonui paha ia i ka hāʻawi ʻana i ka wehewehe ergonomic no nā iterators a me nā primitives ʻē aʻe.
///
///
/// Kūleʻa ka syntax a me nā semantics no nā mea hana a e koi ana i kahi RFC hou aʻe no ka hoʻopaʻa ʻana.I kēia manawa naʻe, ua like ke ʻano o ka syntax:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Hiki ke loaʻa nā palapala hou aʻe o nā mea hana i loko o ka puke paʻa ʻole.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Ke ʻano o ka waiwai a kēia generator.
    ///
    /// Kūlike kēia ʻano pili i ka hōʻike `yield` a me nā waiwai i ʻae ʻia e hoʻihoʻi ʻia i kēlā me kēia manawa e hoʻohua ai ka generator.
    ///
    /// ʻO kahi laʻana he iterator-as-a-generator paha e loaʻa i kēia ʻano me `T`, ke ʻano o ka ʻano.
    ///
    type Yield;

    /// Ke ʻano o ka waiwai i hoʻihoʻi ʻia kēia mea hana.
    ///
    /// Ua hoʻopili like me ke 'ano hoʻi maila, mai ka mīkini hana wāwahie kekahi me ka `return` hoike a implicitly like me ka hope hōʻike o ka mīkini hana wāwahie literal.
    /// ʻO kahi laʻana futures e hoʻohana i kēia ma ke ʻano `Result<T, E>` ma ke ʻano he future i hoʻopau ʻia.
    ///
    ///
    type Return;

    /// Hoʻomau hou i ka hoʻokō ʻana o kēia mīkini hana.
    ///
    /// E hoʻomaka hou kēia hana i ka hoʻokō ʻana o ka generator a hoʻomaka i ka hoʻokō inā ʻaʻole ia.
    /// E hoʻi hou kēia kelepona i ka helu hoʻomaha hope loa o ka generator, e hoʻomaka hou ana i ka hoʻokō ʻana mai `yield` hou loa.
    /// Ka mīkini hana wāwahie e hoʻomau hana a ka mea kekahi e haawi i ko paha hoike, ma i wahi e hoʻi i kēia kuleana pili i.
    ///
    /// # Waiwai hoʻihoʻi
    ///
    /// Ua hoʻihoʻi ʻia ka `GeneratorState` enum mai kēia hana e hōʻike ana i ka mokuʻāina i ka wā e hoʻi mai ana.
    /// Inā hoʻihoʻi ʻia ka ʻokoʻa `Yielded` a laila ua hōʻea ka mea hana i kahi kiko hoʻomaha a ua hāʻawi ʻia kahi waiwai.
    /// Loaʻa nā mea hana i kēia moku'āina no ka hoʻomaka hou ʻana ma kahi kiko hope.
    ///
    /// Inā `Complete` ua hoʻi laila, ua paʻa pau ka mīkini hana wāwahie me ka waiwai i hoakaka ia.He kūpono ʻole kēia no ka hoʻomaka ʻana o ka mea hana.
    ///
    /// # Panics
    ///
    /// Hiki paha i kēia hana panic ke kāhea ʻia ma hope o ka hoʻoliʻiliʻi `Complete` i hoʻihoʻi ʻia ma mua.
    /// ʻOiai e hōʻoia ʻia nā literator generator i ka ʻōlelo i panic ma ka hoʻomaka hou ʻana ma hope o `Complete`, ʻaʻole paʻa kēia no nā hoʻokō āpau o ka `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}