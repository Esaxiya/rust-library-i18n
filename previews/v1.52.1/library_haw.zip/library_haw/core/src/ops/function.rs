/// ʻO ka mana o ka mea kāhea kelepona e lawe i kahi mea loaʻa hoʻololi ʻole.
///
/// Hiki ke kāhea pinepine ʻia nā hanana o `Fn` me ka ʻole o ka mokuʻāina mutating.
///
/// *ʻAʻole huikau kēia trait (`Fn`) me [function pointers] (`fn`).*
///
/// `Fn` hoʻokō 'ia' akomi e nā pani pani 'ia e lawe i nā loiloi loli ʻole i nā loli pio a i ʻole hopu i kekahi mea āpau, a me (safe) [function pointers] (me kekahi mau ana, ʻike i kā lākou palapala no nā kikoʻī hou aʻe).
///
/// Hoʻohui ʻia, no kekahi ʻano `F` e hoʻokomo iā `Fn`, `&F` e hoʻokomo iā `Fn`.
///
/// No ka mea ʻo [`FnMut`] a me [`FnOnce`] nā supertraits o `Fn`, hiki ke hoʻohana ʻia kekahi hanana o `Fn` ma ke ʻano he palena ma kahi o [`FnMut`] a [`FnOnce`] paha i manaʻo ʻia.
///
/// E hoʻohana iā `Fn` ma ke ʻano he palena ke makemake ʻoe e ʻae i kahi palena o ke ʻano o ka hana a pono e kāhea pinepine iā ia me ka ʻole o ka mutating state (e like me ke kāhea pū ʻana).
/// Inā ʻaʻole ʻoe e pono i nā koi koʻikoʻi e like me ka palena, e hoʻohana iā [`FnMut`] a i ʻole [`FnOnce`] i nā palena.
///
/// E ʻike i ka [chapter on closures in *The Rust Programming Language*][book] no kekahi ʻike hou aku e pili ana i kēia kumuhana.
///
/// Eia kekahi o ka note ka syntax kūikawā no `Fn` traits (e laʻa
/// `Fn(usize, bool) -> hoʻohana us`).ʻO ka poʻe makemake i nā kikoʻī loea o kēia hiki ke kuhikuhi iā [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ke kāhea nei i kahi pani
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Ke hoʻohana nei i kahi kikowaena `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // i hiki iā regex ke hilinaʻi i kēlā `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Hana i ka hana kāhea.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ʻO ka mana o ka mea kāhea kelepona e lawe i kahi mea lawe lima hiki ke hoʻololi.
///
/// Hiki ke kāhea pinepine ʻia nā hanana o `FnMut` a hoʻololi paha i ka mokuʻāina.
///
/// `FnMut` hoʻokō ʻiʻo ʻia e nā pani pani e lawe i nā kūmole hiki ke hoʻololi ʻia i nā loli i hoʻopaʻa ʻia, a me nā ʻano āpau e hoʻokō iā [`Fn`], eg, (safe) [function pointers] (ʻoiai ʻo `FnMut` kahi supertrait o [`Fn`]).
/// Hoʻohui ʻia, no kekahi ʻano `F` e hoʻokomo iā `FnMut`, `&mut F` e hoʻokomo iā `FnMut`.
///
/// No ka mea ʻo [`FnOnce`] kahi supertrait o `FnMut`, hiki ke hoʻohana ʻia kekahi hanana o `FnMut` kahi e manaʻo ʻia ai kahi [`FnOnce`], a ʻoiai ʻo [`Fn`] kahi subtrait o `FnMut`, hiki ke hoʻohana ʻia kekahi hanana [`Fn`] ma kahi e manaʻo ʻia ai ʻo `FnMut`.
///
/// E hoʻohana iā `FnMut` ma ke ʻano he palena ke makemake ʻoe e ʻae i kahi palena o ke ʻano o ka hana a pono e kāhea pinepine iā ia, ʻoiai e ʻae iā ia e hoʻololi i ka mokuʻāina.
/// Inā ʻaʻole ʻoe makemake i ka parameter e hoʻololi i ka mokuʻāina, e hoʻohana iā [`Fn`] ma ke ʻano he paʻa;inā ʻaʻole pono ʻoe e kāhea pinepine ia, e hoʻohana iā [`FnOnce`].
///
/// E ʻike i ka [chapter on closures in *The Rust Programming Language*][book] no kekahi ʻike hou aku e pili ana i kēia kumuhana.
///
/// Eia kekahi o ka note ka syntax kūikawā no `Fn` traits (e laʻa
/// `Fn(usize, bool) -> hoʻohana us`).ʻO ka poʻe makemake i nā kikoʻī loea o kēia hiki ke kuhikuhi iā [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ke kāhea nei i kahi pani pani hopu ʻia
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Ke hoʻohana nei i kahi kikowaena `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // i hiki iā regex ke hilinaʻi i kēlā `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Hana i ka hana kāhea.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ʻO ka mana o ka mea kāhea kelepona e lawe i kahi mea loaʻa ma-waiwai.
///
/// Hiki ke kāhea ʻia nā hanana o `FnOnce`, akā ʻaʻole paha e kāhea ʻia i mau manawa.Ma muli o kēia, inā ʻo ka mea wale nō i ʻike ʻia e pili ana i kahi ʻano e hoʻokomo iā `FnOnce`, hiki ke kāhea ʻia i hoʻokahi manawa wale nō.
///
/// `FnOnce` hoʻokō ʻia e nā pani pani e hoʻopau ai i nā loli i hopu ʻia, a me nā ʻano āpau e hoʻokō i [`FnMut`], eg, (safe) [function pointers] (ʻoiai ʻo `FnOnce` kahi supertrait o [`FnMut`]).
///
///
/// No ka mea ʻo [`Fn`] a me [`FnMut`] nā subtraits o `FnOnce`, hiki ke hoʻohana ʻia kekahi hanana o [`Fn`] a i ʻole [`FnMut`] i kahi e manaʻo ʻia ai ka `FnOnce`.
///
/// E hoʻohana iā `FnOnce` ma ke ʻano he palena ke makemake ʻoe e ʻae i kahi palena o ke ʻano o ka hana a pono wale nō e kāhea iā ia i hoʻokahi manawa.
/// Inā pono ʻoe e kāhea pinepine i ka parameter, e hoʻohana iā [`FnMut`] ma ke ʻano he paʻa;inā pono ʻoe e haʻalele i ka mokuʻāina, e hoʻohana iā [`Fn`].
///
/// E ʻike i ka [chapter on closures in *The Rust Programming Language*][book] no kekahi ʻike hou aku e pili ana i kēia kumuhana.
///
/// Eia kekahi o ka note ka syntax kūikawā no `Fn` traits (e laʻa
/// `Fn(usize, bool) -> hoʻohana us`).ʻO ka poʻe makemake i nā kikoʻī loea o kēia hiki ke kuhikuhi iā [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ke hoʻohana nei i kahi kikowaena `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` hoʻopau i kāna mau loli i hopu ʻia, no laila ʻaʻole hiki ke holo ʻoi aku i hoʻokahi manawa.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ke hoʻāʻo nei e noi hou iā `func()` e hoʻolei i kahi hewa `use of moved value` no `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` hiki ʻole ke kāhea ʻia i kēia manawa
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // i hiki iā regex ke hilinaʻi i kēlā `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ʻO ke ʻano i hoʻihoʻi ʻia ma hope o ka hoʻohana ʻia ʻana o ka mea kāhea.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Hana i ka hana kāhea.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}