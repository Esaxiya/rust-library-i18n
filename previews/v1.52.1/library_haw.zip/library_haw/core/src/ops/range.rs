use crate::fmt;
use crate::hash::Hash;

/// Kahi palena palena ʻole (`..`).
///
/// `RangeFull` Hoʻohana mua ʻia ma ke ʻano he [slicing index], kona pōkole ʻo `..`.
/// ʻAʻole hiki ke lawelawe ma ke ʻano he [`Iterator`] no ka mea ʻaʻohe ona wahi hoʻomaka.
///
/// # Examples
///
/// ʻO ka `..` syntax kahi `RangeFull`:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// ʻAʻohe ona [`IntoIterator`] hoʻokō, no laila ʻaʻole hiki iā ʻoe ke hoʻohana ia mea i kahi loop `for` pololei.
/// ʻAʻole kēia e hōʻuluʻulu:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// Hoʻohana ʻia ma ke ʻano he [slicing index], `RangeFull` e hoʻopuka i ka hoʻonohonoho piha ma ke ʻano he ʻāpana.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ʻO kēia ka `RangeFull`
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// Hoʻopili ʻia kahi pae (half-open) ma lalo a ma luna wale nō o (`start..end`).
///
///
/// Aia ka pae `start..end` i nā waiwai āpau me `start <= x < end`.
/// Hakahaka inā `start >= end`.
///
/// # Examples
///
/// ʻO ka `start..end` syntax kahi `Range`:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // He `Range` kēia
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ʻaʻole kope-ʻike iā #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// ʻO ka palena lalo o ka pae (inclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// ʻO ka palena kiʻekiʻe o ka laulā (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// Hoʻi iā `true` inā ʻaʻohe mea i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// Hakahaka ka pae inā hiki ʻole ke hoʻohālikelike ʻia kekahi ʻaoʻao.
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// Hoʻopili wale ʻia kahi pae ma lalo o (`start..`).
///
/// Aia ka `RangeFrom` `start..` i nā waiwai āpau me `x >= start`.
///
/// *Nānā*: Holo i ka hoʻokō [`Iterator`] (ke hiki i ka ʻikepili i loaʻa i kāna palena helu) ʻae ʻia iā panic, wahī, a saturate paha.
/// Hoʻomaopopo ʻia kēia hana e ka hoʻokō ʻana o [`Step`] trait.
/// No nā helu helu primitive, pili kēia i nā lula maʻamau, a mahalo i ka ʻike loiloi overflow (panic i ka debug, wahī i ka hoʻokuʻu).
/// E hoʻomaopopo hoʻi i ka hana ʻana o ka hoʻoheheʻe ma mua o ka mea āu e manaʻo ai: hiki ke kahe i ke kāhea iā `next` e hāʻawi ana i ka nui o ke kumukūʻai, ʻoiai e hoʻonohonoho ʻia ka pae i kahi mokuʻāina e hāʻawi i ka waiwai aʻe.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// ʻO ka `start..` syntax kahi `RangeFrom`:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // He `RangeFrom` kēia
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ʻaʻole kope-ʻike iā #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// ʻO ka palena lalo o ka pae (inclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// Hoʻopili wale ʻia kahi pae ma luna o (`..end`).
///
/// Ka `RangeTo` `..end` kekahi mau mea a pau aiee me `x < end`.
/// ʻAʻole hiki ke lawelawe ma ke ʻano he [`Iterator`] no ka mea ʻaʻohe ona wahi hoʻomaka.
///
/// # Examples
///
/// ʻO ka `..end` syntax kahi `RangeTo`:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// ʻAʻohe ona [`IntoIterator`] hoʻokō, no laila ʻaʻole hiki iā ʻoe ke hoʻohana ia mea i kahi loop `for` pololei.
/// ʻAʻole kēia e hōʻuluʻulu:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// Ke hoʻohana ʻia ma ke ʻano he [slicing index], `RangeTo` e hana i kahi ʻāpana o nā mea āpau i mua o ka papa kuhikuhi i hōʻike ʻia e `end`.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // He `RangeTo` kēia
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// ʻO ka palena kiʻekiʻe o ka laulā (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// Hoʻopili ʻia kahi pae i lalo a ma luna o (`start..=end`).
///
/// Aia ka `RangeInclusive` `start..=end` i nā waiwai āpau me `x >= start` a me `x <= end`.Hakahaka ke ʻole `start <= end`.
///
/// [fused] kēia iterator, akā ʻo nā kumukūʻai kikoʻī o `start` a me `end` ma hope o ka pau ʻana o ka hana ʻana **ʻike ʻole ʻia** ʻē aʻe ma mua o [`.is_empty()`] e hoʻihoʻi iā `true` ke hana hou ʻole ʻia nā waiwai.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// ʻO ka `start..=end` syntax kahi `RangeInclusive`:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // He `RangeInclusive` kēia
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ʻaʻole kope-ʻike iā #27186
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // E noke i ka mahinaʻai nei i ole lehulehu e ae hoʻololi i ka hoohalike ai i loko o ka future;ke kikoʻī, ʻoiai hiki iā mākou ke hōʻike pono iā start/end, ke hoʻololi ʻana iā lākou me ka hoʻololi ʻole ʻana i nā kahua pilikino (future/current) hiki i ke ʻano kūpono ʻole, no laila ʻaʻole mākou e kākoʻo i kēlā ʻano.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ʻO kēia kahua:
    //  - `false` ma ke kūkulu ʻana
    //  - `false` ke hāʻawi ka iteration i kahi mea a ʻaʻole i pau ka iterator
    //  - `true` ke hoʻohana ʻia ka iteration e hoʻopau i ka iterator
    //
    // Koi ʻia kēia e kākoʻo iā PartialEq a me Hash me ka ʻole o ka PartialOrd i hoʻopaʻa ʻia a i ʻole he loea.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// Hoʻokumu i kahi laulā komo hou.Kūlike like i ke kākau `start..=end`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// Hoʻihoʻi i ka palena lalo o ka laulā (inclusive).
    ///
    /// Ke hoʻohana nei i kahi laulā komo no ka iteration, ʻike ʻole ʻia nā kumukūʻai o `start()` a me [`end()`] ma hope o ka pau ʻana o ka hōʻike.
    /// No ka hoʻoholo ʻana inā hakahaka ka pae komo, e hoʻohana i ka hana [`is_empty()`] ma kahi o ka hoʻohālikelike ʻana iā `start() > end()`.
    ///
    /// Note: ʻaʻole hōʻike ʻia ka waiwai i hoʻihoʻi ʻia e kēia hana ma hope o ka hāʻawi ʻia ʻana o ka pae i ka luhi.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// Hoʻihoʻi i ka palena kiʻekiʻe o ka laulā (inclusive).
    ///
    /// Ke hoʻohana nei i kahi laulā komo no ka iteration, ʻike ʻole ʻia nā kumukūʻai o [`start()`] a me `end()` ma hope o ka pau ʻana o ka hōʻike.
    /// No ka hoʻoholo ʻana inā hakahaka ka pae komo, e hoʻohana i ka hana [`is_empty()`] ma kahi o ka hoʻohālikelike ʻana iā `start() > end()`.
    ///
    /// Note: ʻaʻole hōʻike ʻia ka waiwai i hoʻihoʻi ʻia e kēia hana ma hope o ka hāʻawi ʻia ʻana o ka pae i ka luhi.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// Hoʻopau i ka `RangeInclusive` i (lalo paʻa, i luna (inclusive) paʻa).
    ///
    /// Note: ʻaʻole hōʻike ʻia ka waiwai i hoʻihoʻi ʻia e kēia hana ma hope o ka hāʻawi ʻia ʻana o ka pae i ka luhi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// Hoʻololi i kahi `Range` wale nō no `SliceIndex` hoʻokō.
    /// ʻO ka mea kāhea ke kuleana no ka hana pū ʻana me `end == usize::MAX`.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // Inā ʻaʻole mākou luhi, makemake mākou e ʻokiʻoki i `start..end + 1` wale nō.
        // Inā ua luhi mākou, a laila ka ʻoki ʻana me `end + 1..end + 1` e hāʻawi iā mākou i kahi laulā ʻole e hiki ke kau ʻia i nā palena palena.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// Hoʻihoʻi pinepine kēia ala i `false` ma hope o ka pau ʻana o ka hana.
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // ʻAʻole kuhi ʻia nā kumukūʻai kahua kikoʻī ma aneʻi
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// Hoʻi iā `true` inā ʻaʻohe mea i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// Hakahaka ka pae inā hiki ʻole ke hoʻohālikelike ʻia kekahi ʻaoʻao.
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// Hoʻihoʻi kēia ala i `true` ma hope o ka pau ʻana o ka hana.
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // ʻAʻole kuhi ʻia nā kumukūʻai kahua kikoʻī ma aneʻi
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// Hoʻopili wale ʻia kahi pae ma luna o (`..=end`).
///
/// Aia ka `RangeToInclusive` `..=end` i nā waiwai āpau me `x <= end`.
/// ʻAʻole hiki ke lawelawe ma ke ʻano he [`Iterator`] no ka mea ʻaʻohe ona wahi hoʻomaka.
///
/// # Examples
///
/// ʻO ka `..=end` syntax kahi `RangeToInclusive`:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// ʻAʻohe ona [`IntoIterator`] hoʻokō, no laila ʻaʻole hiki iā ʻoe ke hoʻohana ia mea i kahi loop `for` pololei.ʻAʻole kēia e hōʻuluʻulu:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// Ke hoʻohana ʻia ma ke ʻano he [slicing index], `RangeToInclusive` e hana i kahi ʻāpana o nā mea āpau āpau a hiki a hoʻokomo i ka papa kuhikuhi i hōʻike ʻia e `end`.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // He `RangeToInclusive` kēia
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// ʻO ka palena kiʻekiʻe o ka laulā (inclusive)
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// KūlanaToInclusive<Idx>hiki ole impl Mai <RangeTo<Idx>> no ka mea hiki ke loaʻa ka underflow me (..0).into()
//

/// Kahi kiko o ke kī o nā kī.
///
/// # Examples
///
/// ʻO nā palena palena palena palena.
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// Ke hoʻohana nei i kahi tuple o `Bound`s ma ke ʻano he hoʻopaʻapaʻa iā [`BTreeMap::range`].
/// Hoʻomaopopo i ka hapanui o nā hihia, ʻoi aku ka maikaʻi o ka hoʻohana ʻana i ka syntax (`1..5`) ma kahi.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// Kuhi paʻa ʻia.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ʻO kahi palena paʻa.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// Kahi hopena palena ʻole.Hōʻike i ka mea, ua ole e paa ana i loko o kēia ao.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// Hoʻololi mai `&Bound<T>` a `Bound<&T>`.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// Hoʻololi mai `&mut Bound<T>` a `Bound<&T>`.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// Palapala 'āina i `Bound<&T>` i kahi `Bound<T>` ma ke kala ʻana i nā ʻike o ka paʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` hoʻokō ʻia e Rust's built-in range range, hana ʻia e ka syntax range e like me `..`, `a..`, `..b`, `..=c`, `d..e`, a i ʻole `f..=g`.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// Hoʻopaʻa ʻia ka papa kuhikuhi hoʻomaka.
    ///
    /// Hoʻihoʻi i ka waiwai hoʻomaka ma ke ʻano he `Bound`.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// Hoʻopau paʻa helu kuhikuhi.
    ///
    /// Hoʻihoʻi i ka waiwai hope ma ke ʻano he `Bound`.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// Hoʻi iā `true` inā loaʻa ʻo `item` i ka pae.
    ///
    /// # Examples
    ///
    /// ```
    /// e hoʻokūpaʻa! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// e hoʻokūpaʻa! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // Ke pau ka iterator, hoʻomaka mākou==hoʻomaka, akā makemake mākou e hele wale ka pae, ʻaʻohe mea i loaʻa.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}