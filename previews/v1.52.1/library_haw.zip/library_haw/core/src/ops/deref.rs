/// Hoʻohana ʻia no nā hana dereferencing immutable, e like me `*v`.
///
/// Hoʻohui ʻia me ka hoʻohana ʻia no nā hana dereferencing explicit me ka (unary) `*` mea hoʻohana ma nā ʻano neʻe ʻole, hoʻohana pono ʻia ʻo `Deref` e ka mea hoʻopili i nā ʻano he nui.
/// Kapa ʻia kēia ʻano hana ʻo ['`Deref` coercion'][more].
/// I nā pōʻaiapili hiki ke hoʻololi, hoʻohana ʻia ʻo [`DerefMut`].
///
/// Ke hoʻokomo nei i ka `Deref` no nā mea kuhikuhi akamai e kiʻi maʻalahi i ka ʻikepili ma hope o lākou, ʻo ia ke kumu e hoʻokō ai iā `Deref`.
/// Ma ka ʻaoʻao ʻē aʻe, ua hoʻonohonoho pono ʻia nā lula e pili ana iā `Deref` a me [`DerefMut`] i mea e ʻae ai i nā poʻomanaʻo akamai.
/// Ma muli o kēia,**pono e hoʻokō ʻia ʻo ``Deref` no nā mea kuhikuhi akamai** e hōʻalo ai i ka huikau.
///
/// No ka like kumu,**keia trait e ole**.Ole i dereferencing hiki ke loa i hookahuli ai i ka wā `Deref` maluna o lakou implicitly.
///
/// # ʻO nā mea hou aʻe ma ka `Deref` coercion
///
/// Inā hoʻokomo ʻo `T` iā `Deref<Target = U>`, a me `x` kahi waiwai o ka ʻano `T`, a laila:
///
/// * I nā pōʻaiapili hiki ʻole ke hoʻololi ʻia, ʻo `*x` (kahi a `T` ʻaʻole kuhikuhi a ʻaʻohe kuhikuhi kuhikuhi maka) e like ia me `* Deref::deref(&x)`.
/// * Koi ʻia nā waiwai o ke ʻano `&T` i nā waiwai o ke ʻano `&U`
/// * `T` implicitly mea lapaʻau i ka (immutable) ki ina hana like o keʻano `U`.
///
/// No nā kikoʻī hou aku, e kipa iā [the chapter in *The Rust Programming Language*][book] a me nā ʻāpana kūmole ma [the dereference operator][ref-deref-op], [method resolution] a me [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Kahi me kahi kahua hoʻokahi i hiki ke kiʻi ʻia e ka hoʻomaʻemaʻe ʻana i ke kumu.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ke ʻano hopena ma hope o ka hoʻopau ʻana.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Hoʻopau i ka waiwai.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Hoʻohana ʻia no nā hana dereferencing hiki ke hoʻololi ʻia, e like me `*v = 1;`.
///
/// Ma waho aʻe o ka hoʻohana ʻia no nā hana dereferencing explicit me ka (unary) `*` mea hoʻohana i nā pōʻaiapili hiki ke hoʻololi ʻia, hoʻohana pū ʻia ʻia ʻo `DerefMut` e ka mea hoʻopili i nā ʻano he nui.
/// Kapa ʻia kēia ʻano hana ʻo ['`Deref` coercion'][more].
/// I nā ʻano kūlohelohe ʻole, hoʻohana ʻia ʻo [`Deref`].
///
/// Ke hoʻokō nei i ka `DerefMut` no nā mea kuhikuhi akamai e hoʻololi i ka ʻikepili ma hope o lākou i maʻalahi, ʻo ia ke kumu e hoʻokō ai iā `DerefMut`.
/// Ma ka ʻaoʻao ʻē aʻe, ua hoʻonohonoho pono ʻia nā lula e pili ana iā [`Deref`] a me `DerefMut` i mea e ʻae ai i nā poʻomanaʻo akamai.
/// Ma muli o kēia, pono e hoʻokō ʻia ʻo **`DerefMut` no nā mea kuhikuhi akamai** e hōʻalo ai i ka huikau.
///
/// No nā kumu like,**ʻaʻole e pau ʻole kēia trait**.Hiki ke huikau loa ka kūleʻa ʻole i ka wā ke noi ʻia ʻana ke noi ʻia `DerefMut` me ka manaʻo ʻole.
///
/// # ʻO nā mea hou aʻe ma ka `Deref` coercion
///
/// Inā hoʻokomo ʻo `T` iā `DerefMut<Target = U>`, a me `x` kahi waiwai o ka ʻano `T`, a laila:
///
/// * I nā pōʻaiapili hiki ke hoʻololi ʻia, ʻo `*x` (kahi a `T` ʻaʻole kuhikuhi a ʻaʻohe kuhikuhi kuhikuhi maka) e like ia me `* DerefMut::deref_mut(&mut x)`.
/// * Koi ʻia nā waiwai o ke ʻano `&mut T` i nā waiwai o ke ʻano `&mut U`
/// * `T` hoʻokomo pono i nā kiʻina (mutable) o ke ʻano `U`.
///
/// No nā kikoʻī hou aku, e kipa iā [the chapter in *The Rust Programming Language*][book] a me nā ʻāpana kūmole ma [the dereference operator][ref-deref-op], [method resolution] a me [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Kahi me kahi kahua hoʻokahi i hiki ke hoʻololi ʻia e ka haʻalele ʻana i ka mea kūkulu.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Hoʻopau hou i ka waiwai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Kuhi hiki ke hoʻohana ʻia i kahi mea hoʻokipa e like me ka mea loaʻa hana, me ka ʻole o ka hiʻohiʻona `arbitrary_self_types`.
///
/// Hoʻohana ʻia kēia e stdlib ʻano kuhikuhi e like me `Box<T>`, `Rc<T>`, `&T`, a me `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}