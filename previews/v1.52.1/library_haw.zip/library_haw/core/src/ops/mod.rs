//! Nā mea hana overloadable.
//!
//! Ke hoʻokō nei i kēia traits e ʻae iā ʻoe e hoʻonui i kekahi mau mea hana.
//!
//! Hoʻokomo ʻia kekahi o kēia traits e ka prelude, no laila loaʻa lākou i kēlā me kēia polokalamu Rust.ʻO nā mea hana wale i kākoʻo ʻia e traits hiki ke hoʻonui ʻia.
//! ʻO kahi laʻana, hiki ke hoʻonui ʻia ka mea hoʻokomo (`+`) ma o ka [`Add`] trait, akā no ka mea ʻaʻohe kākoʻo o ka mea hoʻokele (`=`) iā trait, ʻaʻohe ala e hoʻonui ai i kāna mau semantics.
//! Hoʻohui, ʻaʻole hāʻawi kēia module i kekahi ʻano hana e hana i nā mea hana hou.
//! Inā koi ʻia ka overloading traitless a i ʻole nā mea lawelawe maʻamau, pono ʻoe e nānā i nā macros a i ʻole nā plugins compiler e hoʻonui i ka syntax o Rust.
//!
//! Pono ʻole nā hana o ka mea hoʻohana traits i kā lākou pōʻaiapili, e hoʻomanaʻo nei i ka manaʻo maʻamau a me [operator precedence].
//! Eia kekahi laʻana, i ka hoʻokō ʻana i [`Mul`], pono ke ʻano o ka hana i ka hoʻonui ʻana (a kaʻana like i nā waiwai i manaʻo ʻia e like me ka pili.
//!
//! E hoʻomaopopo he pōkole ke kaʻa uila ʻo `&&` a me `||`, ʻo ia hoʻi, loiloi wale lākou i kā lākou operand lua inā hāʻawi ia i ka hopena.Ma muli o ka hoʻokō ʻole ʻia o kēia ʻano e traits, ʻaʻole kākoʻo ʻia ʻo `&&` a me `||` ma ke ʻano he nui nā mea lawelawe.
//!
//! Lawe ka hapa nui o nā mea hana i kā lākou operand e ka waiwai.I 'ole-nōhie pōʻaiapili' pili i kūkulu-ma ke ano, keia mea ana i ka pilikia.
//! Eia nō naʻe, e hoʻohana ana i kēia mau mea lawelawe i ke code generic, koi i kahi nānā inā pono e hoʻohana hou i nā waiwai i kū ʻole i ka ʻae ʻana i nā mea lawelawe.ʻO kahi koho e hoʻohana i ka [`clone`] i kekahi manawa.
//! ʻO kahi koho ʻē aʻe e kaukaʻi i nā ʻano e pili ana i ka hāʻawi ʻana i nā hoʻokō ʻoihana hou aʻe no nā kūmole.
//! ʻO kahi laʻana, no kahi ʻano `T` i ho'ākāka ʻia e ka mea hoʻohana i manaʻo ʻia e kākoʻo i ka hoʻohui, he mea maikaʻi paha e loaʻa iā `T` a me `&T` i ka traits [`Add<T>`][`Add`] a me [`Add<&T>`][`Add`] i hiki ai ke kākau ʻia nā code generic me ka ʻole o ka cloning pono ʻole.
//!
//!
//! # Examples
//!
//! Hoʻokumu kēia laʻana i kahi `Point` mea hoʻopili e hoʻopili iā [`Add`] a me [`Sub`], a laila hōʻike i ka hoʻohui ʻana a me ka unuhi ʻana i ʻelua mau Point.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! E ʻike i nā palapala no kēlā me kēia trait no kahi laʻana hoʻokō.
//!
//! Hoʻokomo ʻia ka [`Fn`], [`FnMut`], a me [`FnOnce`] traits e nā ʻano i hiki ke kāhea ʻia e like me nā hana.E hoʻomaopopo i [`Fn`] i `&self`, [`FnMut`] i `&mut self` a i [`FnOnce`] i `self`.
//! Kūlike kēia i nā ʻano o nā ʻano ʻekolu i hiki ke kāhea ʻia ma kahi hanana: kāhea-i-kahi kūmole, kāhea-a-hoʻololi ʻia, a me ke kāheaheahea.
//! ʻO ka hoʻohana maʻamau o kēia traits e hana ma ke ʻano he palena i nā ʻoihana kiʻekiʻe e lawe i nā hana a i ʻole nā panina ma ke ʻano he paio.
//!
//! Lawe iā [`Fn`] ma ke ʻano he parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Lawe iā [`FnMut`] ma ke ʻano he parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Lawe iā [`FnOnce`] ma ke ʻano he parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` hoʻopau i kāna mau loli i hopu ʻia, no laila ʻaʻole hiki ke holo ʻoi aku i hoʻokahi manawa
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ke hoʻāʻo nei e noi hou iā `func()` e hoʻolei i kahi hewa `use of moved value` no `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` hiki ʻole ke kāhea ʻia i kēia manawa
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;