/// Pāʻālua dute i loko o ka luku.
///
/// Ke makemake hou ʻole ʻia kahi kumukūʻai, e holo ʻo Rust i kahi "destructor" ma kēlā waiwai.
/// ʻO ke ala maʻamau e pono ʻole ai kahi waiwai ke hele aku ia i waho o kahi pae.E holo mau paha nā mea hoʻopau i nā kūlana ʻē aʻe, akā e nānā mākou i ka laulā no nā hiʻohiʻona ma aneʻi.
/// E aʻo e pili ana i kekahi o kēlā mau hihia ʻē aʻe, e ʻoluʻolu e ʻike i ka ʻaoʻao [the reference] ma nā mea hōʻino.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Aia kēia destructor i ʻelua mau mea:
/// - He kāhea iā `Drop::drop` no kēlā waiwai, inā hoʻokō ʻia kēia `Drop` trait kūikawā no kāna ʻano.
/// - ʻO "drop glue" ka mea i hana maʻalahi i kahea hou i nā mea hōʻino o nā kahua āpau o kēia waiwai.
///
/// E like me kā Rust kelepona ʻana i nā mea hōʻino o nā kahua āpau i loaʻa, ʻaʻole pono ʻoe e hoʻokō iā `Drop` i ka hapanui o nā hihia.
/// Akā aia kekahi mau hihia kahi kūpono, no kahi laʻana no nā ʻano e mālama pololei i kahi waiwai.
/// Hoʻomanaʻo paha kēlā kumuwaiwai, he wehewehe faila paha ia, he kumu pūnaewele paha ia.
/// Ke hoʻohana hou ʻia kahi waiwai o kēlā ʻano, pono iā "clean up" i kāna kumuwaiwai ma o ka hoʻokuʻu ʻana i ka hoʻomanaʻo a i ʻole ke pani ʻana i ka faila a i ʻole ke kumu.
/// ʻO kēia ka hana a kahi mea luku, a no laila ʻo ka hana a `Drop::drop`.
///
/// ## Examples
///
/// E ʻike ai i nā mea luku i ka hana, e nānā i ka papahana aʻe:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// E kāhea mua ʻo Rust iā `Drop::drop` no `_x` a laila no `_x.one` a me `_x.two`, ʻo ia hoʻi ka paʻi ʻana o ka holo ʻana i kēia.
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ʻOiai inā mākou e kāpae i ka hoʻokō ʻana o `Drop` no `HasTwoDrop`, kāhea mau ʻia nā mea hōʻemi o kāna mau kahua.
/// E hopena kēia i
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## ʻAʻole hiki iā ʻoe ke kāhea iā `Drop::drop` iā ʻoe iho
///
/// Ma muli o ka hoʻohana ʻia ʻana o `Drop::drop` e hoʻomaʻemaʻe i kahi waiwai, he mea weliweli paha ke hoʻohana i kēia waiwai ma hope o ke kāhea ʻia ʻana o kēia hana.
/// Ma muli o ka lawe ʻole ʻana o `Drop::drop` i kāna hoʻokomo, Rust kaohi i ka hoʻohana hewa ʻana ma ka ʻae ʻole ʻana iā ʻoe e kāhea pololei iā `Drop::drop`.
///
/// I nā huaʻōlelo ʻē aʻe, inā ua hoʻāʻo ʻoe e kāhea kikoʻī iā `Drop::drop` i ke laʻana ma luna, e loaʻa iā ʻoe kahi hewa hōʻuluʻulu.
///
/// Inā makemake ʻoe e kāhea kikoʻī i ka mea hōʻino i kahi waiwai, hiki ke hoʻohana ʻia ʻo [`mem::drop`] ma kahi.
///
/// [`mem::drop`]: drop
///
/// ## Kau kulu
///
/// ʻO wai o kā mākou `HasDrop` ʻelua e hāʻule mua?No nā kaula, like ke ʻano o ke kauoha a lākou i haʻi ai: `one` mua, a laila `two`.
/// Inā makemake ʻoe e hoʻāʻo i kēia iho, hiki iā ʻoe ke hoʻololi i ka `HasDrop` ma luna e loaʻa ai kekahi mau ʻikepili, e like me ka integer, a laila e hoʻohana ia i ka `println!` i loko o `Drop`.
/// Hōʻoia kēia hana e ka ʻōlelo.
///
/// ʻAʻole like me nā kaula, hāʻule nā loli kūloko i ka ʻaoʻao huli:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// E paʻi kēia
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// E ʻoluʻolu e ʻike iā [the reference] no nā lula piha.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` a he `Drop` wale nō
///
/// ʻAʻole hiki iā ʻoe ke hoʻokomo i ka [`Copy`] a me ka `Drop` ma ke ʻano like.ʻO nā ʻano `Copy` e hoʻopili kope ʻia e ka mea hoʻopili, e paʻakikī ana e wānana i ka wā hea, a i ka manawa hea e hoʻokō ʻia ai nā mea hōʻino.
///
/// E like me ia, ʻaʻole hiki i kēia ʻano ke loaʻa nā mea hōʻino.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Hana i ka mea luku no kēia ʻano.
    ///
    /// Kāhea maoli ʻia kēia hana ke hele aku ka waiwai mai waho o ka laulā, a ʻaʻole hiki ke kāhea pololei ʻia (ʻo ka hewa compiler [E0040] kēia).
    /// Eia nō naʻe, hiki ke hoʻohana i ka hana [`mem::drop`] i ka prelude e kāhea i ka hoʻokō o `Drop` o ka hoʻopaʻapaʻa.
    ///
    /// Ke kāhea ʻia kēia hana, ʻaʻole i hāʻawi ʻia ʻo `self` i kahi manawa.
    /// Hana wale ia ma hope o ka pau ʻana o ke ʻano.
    /// Inā ʻaʻole kēia ka hihia, `self` e kuhikuhi kuhikuhi.
    ///
    /// # Panics
    ///
    /// Hāʻawi ʻia e [`panic!`] e kāhea iā `drop` i kona hemo ʻana, e hoʻopau paha kekahi [`panic!`] i kahi hoʻokō `drop`.
    ///
    /// E hoʻomaopopo inā ʻo kēia panics, manaʻo ʻia e hāʻule ka waiwai;
    /// pono ʻole ʻoe e kāhea hou iā `drop`.
    /// Mālama maʻamau ʻia kēia e ka mea hōʻuluʻulu, akā ke hoʻohana ʻana i ka pāʻālua palekana ʻole, hiki i kekahi manawa ke hana me ka manaʻo ʻole, ke hoʻohana ʻia me [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}