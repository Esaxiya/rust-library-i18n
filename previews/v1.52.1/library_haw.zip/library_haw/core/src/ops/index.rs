/// Hoʻohana ʻia no ka hana helu (`container[index]`) i nā pōʻaiapili ʻole.
///
/// `container[index]` ʻo ia ke kō syntactic maoli no `*container.index(index)`, akā ke hoʻohana ʻia ia ma ke ʻano he waiwai pio ʻole.
/// Inā noi ʻia kahi waiwai hiki ke hoʻololi ʻia, hoʻohana ʻia ʻo [`IndexMut`] ma kahi.
/// ʻAe kēia i nā mea maikaʻi e like me `let value = v[index]` inā hoʻopili ke ʻano o `value` iā [`Copy`].
///
/// # Examples
///
/// Hoʻokomo ka hiʻohiʻona aʻe i ka `Index` ma kahi pahu `NucleotideCount` heluhelu wale nō, e ʻae ai i nā helu a kēlā me kēia me ka syntax index.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// ʻO ka ʻano i hoʻihoʻi ʻia ma hope o ka helu ʻana.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Hana i ka hana (`container[index]`) indexing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Hoʻohana ʻia no ka hana helu (`container[index]`) i nā pōʻaiapili hiki ke hoʻololi.
///
/// `container[index]` ʻo ia ke kō syntactic maoli no `*container.index_mut(index)`, akā ke hoʻohana ʻia ia ma ke ʻano he waiwai loli.
/// Inā he luli ole waiwai ua noi, ke [`Index`] trait ua i hoʻohana hakahaka.
/// ʻAe kēia i nā mea maikaʻi e like me `v[index] = value`.
///
/// # Examples
///
/// ʻO kahi hoʻokō maʻalahi o kahi `Balance` struct i loaʻa nā ʻaoʻao ʻelua, kahi e hiki ai i kēlā me kēia ke kope ʻia a hiki ʻole ke hoʻololi.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Ma keia hihia, `balance[Side::Right]` mea kō no `*balance.index(Side::Right)`, no ka mea, ua i wale* heluhelu * `balance[Side::Right]`,ʻaʻole kākau ia.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Eia nō naʻe, i kēia hihia `balance[Side::Left]` he kō no `*balance.index_mut(Side::Left)`, ʻoiai ke kākau nei mākou iā `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Hana i ka loiloi (`container[index]`) hiki ke hoʻololi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}