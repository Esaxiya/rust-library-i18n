/// A trait no ka hoʻopilikino ʻana i ka lawena o ka mea hoʻohana `?`.
///
/// ʻO kahi ʻano e hoʻokomo nei iā `Try` kahi ala canonical e nānā iā ia e pili ana i ka dichotomy success/failure.
/// Hāʻawi kēia trait i ka ʻelua e lawe i kēlā mau kūleʻa a i ʻole nā helu kūleʻa mai kahi hanana e kū nei a hana i kahi hanana hou mai kahi kūleʻa a waiwai ʻole paha.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ke ʻano o kēia waiwai ke nānā ʻia me he kūleʻa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ke ʻano o kēia waiwai ke nānā ʻia ua kūleʻa.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Pili i ka mea hoʻohana "?".A hoʻi o `Ok(t)` o ia hoʻi, i ka hooko e hoomau oe maʻamau, a me ka hopena o `?` o ka waiwai `t`.
    /// ʻO ka hoʻihoʻi o `Err(e)` ke kumu o ka hoʻokō ʻana iā branch i ka `catch` i loko o loko, a i ʻole hoʻi mai ka hana.
    ///
    /// Inā hoʻihoʻi ʻia kahi hopena `Err(e)`, ʻo `e` ka waiwai "wrapped" i ka ʻano hoʻihoʻi o ka pae i hoʻopili ʻia (a pono e hoʻokō iā `Try`).
    ///
    /// ʻO ke kikoʻī, hoʻihoʻi ʻia ka waiwai `X::from_error(From::from(e))`, kahi `X` ke ʻano hoʻihoʻi o ka hana hoʻopili.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Hoʻopili i kahi helu hemahema e kūkulu i ka hopena hui.
    /// ʻO kahi laʻana, `Result::Err(x)` a me `Result::from_error(x)` like.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Hoʻopili i kahi waiwai OK e kūkulu i ka hopena ahupapaʻa.
    /// ʻO kahi laʻana, `Result::Ok(x)` a me `Result::from_ok(x)` like.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}