use crate::iter::FromIterator;

/// Uhaʻi i nā ʻāpana āpau mai kahi iterator i hoʻokahi.
///
/// ʻOi aku ka maikaʻi o kēia ke hoʻohui ʻia me nā abstraction pae kiʻekiʻe, e like me ka hōʻiliʻili ʻana i `Result<(), E>` kahi āu e mālama wale ai i nā hemahema.
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}