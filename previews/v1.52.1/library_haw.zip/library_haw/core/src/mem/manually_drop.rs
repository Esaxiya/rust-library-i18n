use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper e inhibit compiler mai akomi kahea `T` ka destructor.
/// Kēia wrapper He 0-kāki.
///
/// `ManuallyDrop<T>` mea paha i ka ia kūpono optimizations me `T`.
/// E like me ia i kaʻilihune, ka mea i *ole ia* i na nā mea mahuʻi i ka compiler mea e pili ana i kona Contents.
/// ʻO kahi laʻana, ke hoʻomaka nei i kahi `ManuallyDrop<&mut T>` me [`mem::zeroed`] ka hana i hoʻoholo ʻole ʻia.
/// Inā pono ʻoe e lawelawe i ka ʻikepili uninitialized, e hoʻohana ma kahi o [`MaybeUninit<T>`].
///
/// E hoʻomaopopo he palekana ʻo ke kiʻi ʻana i ka waiwai i loko o `ManuallyDrop<T>`.
/// Kēiaʻano i ka `ManuallyDrop<T>` kona maʻiʻo, ua haule iho la iluna pono ole e waiho kokoke ana ma o ka lehulehu maluhia API.
/// Correspondingly, `ManuallyDrop::drop` mea unsafe.
///
/// # `ManuallyDrop` a mai hapai ku e kauoha.
///
/// Rust i ka luawai-hoakaka [drop order] o nā loina.
/// I ka e hōʻoia i ia kula a me na kamaaina i haule ma ka kekahi mea, reorder na declarations ia i ka implicit e like mea o ka pololei kekahi.
///
/// Hiki ke hoʻohana iā `ManuallyDrop` e kaohi i ke kauoha kulu, akā koi kēia i ke code palekana a paʻakikī e hana pololei i ke alo o ka hoʻomaha ʻole.
///
///
/// No kekahi laʻana, ina e makemake e mālama pono ana i kekahi mau 'ke kahua ua haule ma hope o ka mea e ae, e ia i ke kula hope o ka struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` E e kulu ma hope o `children`.
///     // Rust hoʻohiki i mahinaʻai i haule ma ka mea o ka hoike ana'ku.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Uhi i ka waiwai no e hana lima, Nakulukulu no.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Oe hiki nō paa hana ma luna o ka waiwai
    /// assert_eq!(*x, "Hello");
    /// // Akā, `Drop` e ole e holo 'aneʻi
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Nā pōʻalo i ka waiwai, mai ka `ManuallyDrop` ipu.
    ///
    /// Kēia e leie aku ka waiwai i ke kulu hou.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Kulu kēia i ka `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Lawe i ka waiwai mai ka `ManuallyDrop<T>` ipu mai.
    ///
    /// Kēia papa hana ua kuhikuhi manao no ka neʻe mai aiee i kulu.
    /// Ma kahi o ka hoʻohana 'ana [`ManuallyDrop::drop`] e hana lima haule i ka waiwai, e hiki ke hoʻohana i kēia papa hana, e lawe i ka waiwai a me ka hana ia nae makemake.
    ///
    /// Inā hiki, ia mea e ahoʻia e hoʻohana [`into_inner`][`ManuallyDrop::into_inner`] kahi, a kāohi 'ia paha duplicating ka maʻiʻo o ka `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Kēia kuleana pili i semantically kolo ana mai i ka i kakauiaʻi maluna waiwai ole pale hou oAaEeIeIAaIAeO, e waiho ana i ka moku'āina o keia ipu ua hoʻololiʻia.
    /// Na kou kuleana e hōʻoia i ka hoʻohana ʻole ʻana o kēia `ManuallyDrop`.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Maluhia: mākou i heluhelu mai i ka olua, i ua ua hoʻohiki
        // e lilo no ka heluhelu.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Hana lima paka ua o ka kakauiaʻi maluna waiwai.He mea pono like i kahea [`ptr::drop_in_place`] me ka laʻau kuhikuhi i ka mea i kakauiaʻi maluna waiwai.
    /// E like me ia, ke ole ka mea i kakauiaʻi maluna waiwai o ka Paka struct, e e kapaʻia ai ka destructor ma-wahi ole e neʻe i ka waiwai, a pela hiki ke hoʻohana 'ana i ka maluhia papa [pinned] ʻikepili.
    ///
    /// Inā loaʻa iā ʻoe ka waiwai, hiki iā ʻoe ke hoʻohana iā [`ManuallyDrop::into_inner`] ma kahi.
    ///
    /// # Safety
    ///
    /// Kēia papa holo ka destructor o ka kakauiaʻi maluna waiwai.
    /// Ma mua o nā loli i hana ʻia e ka mea luku ponoʻī, waiho paʻa ʻole ka hoʻomanaʻo, a hiki i ka mea nāna e hoʻopili ka mea e paʻa nei i kahi ʻano i kūpono no ka ʻano `T`.
    ///
    ///
    /// Naʻe, e ole e hooleiiaʻi mawaho keia "zombie" waiwai i palekana kivila, a me ka pono ole e kapaʻia aku ma mua o ka manawa hookahi i kēia kuleana pili i.
    /// E hoʻohana i ka waiwai ma hope o ka mea, Ka ua haule, a mai hapai ku i ka waiwai mau manawa, hiki i Undefined hana (ke kaumaha ma muli mea `drop` i).
    /// Kāohi ʻia kēia e ka ʻōnaehana ʻano, akā pono nā mea hoʻohana o `ManuallyDrop` e hoʻokūpaʻa i kēlā mau hōʻoia me ka ʻole o ke kōkua mai ka mea hoʻopili.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Maluhia: mākou e kahe mai ana he ka waiwai kuhikuhi ia ma ka mutable maopopo kahi
        // i ua ua hoʻohiki ia e henua pololei i kakau iho ai.
        // Aia ia i ka mea e kelepona ana e hōʻoia ʻaʻole i hāʻule hou ʻo `slot`.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}