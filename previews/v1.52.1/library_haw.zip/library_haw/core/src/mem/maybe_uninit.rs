use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A wrapperʻano e? Ieoaeunoai uninitialized nui o `T`.
///
/// # Initialization invariant
///
/// Ke compiler, ma ka mau, kuhi i ka ee iaaanu aey ua pono initialized e like me na olelo o ka ee iaaanu aey ka type.ʻO kahi laʻana, pono e hoʻopili ʻia kahi ʻano o nā ʻano kūmole a ʻaʻole hoʻi ʻo NULL.
/// Kēia mea he invariant mea pono *mau* e kokuaia oia, a hiki i ka unsafe kivila.
/// E like me ia i kaʻilihune, Aʻohe-initializing he ee iaaanu aey o ka maopopo kahi type ke kumu instantaneous [undefined behavior][ub],ʻaʻohe mea, ina ia olua mau loaʻia hoʻohana 'ana i ke kōkua o iaiyoe.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined ana!️
/// // Ua like paha kivila me `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined ana!️
/// ```
///
/// Keia ua exploited ma ka compiler no kela optimizations, e like me eliding holo-manawa loaʻa, e kaha a optimizing `enum` ʻia.
///
/// Like me, loa uninitialized hoomanao hiki i kekahi maʻiʻo, oiai he `bool` mau pono e `true` paha `false`.No laila, ke hana nei i kahi `bool` uninitialized ʻole ka hana i hoʻoholo ʻole ʻia:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined ana!️
/// // Ua like paha kivila me `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined ana!️
/// ```
///
/// A, uninitialized hoomanao mea kūikawā ma ia mea, aole ia i i ka paa waiwai ("fixed" la me ka manao "it won't change without being written to").ʻO ka heluhelu ʻana i ka byte uninitialized like i nā manawa he nui i hiki ke hāʻawi i nā hopena ʻokoʻa.
/// Hana kēia i ka hana i hoʻoholo ʻole ʻia e loaʻa i ka ʻikepili uninitialized i kahi loli ʻoiai he ʻano helu integer kēlā ʻano, a i ʻole e paʻa i kekahi kumu hoʻohālike i hoʻopaʻa ʻia.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined ana!️
/// // ʻO ka pāʻālua like me `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined ana!️
/// ```
/// (Hoolaha i na rula a puni uninitialized integers ka mea,ʻaʻole finalized manawa, akā, a ka mea e, ka mea mea kupono, e pale aku ia lakou.)
///
/// Ma luna o ka mea, e hoomanao i ka hapanui ke ano i nā invariants ma kela aoao o ka alawa i noʻonoʻo initialized ma keʻano kiʻekiʻe.
/// No ka laʻana, he '1`-initialized [`Vec<T>`] ua noʻonoʻo initialized (ma lalo o ka he manaʻo; keia, aole ia e hoolilo i ka hale lio kumu hoʻomalu) no ka mea, ke koi wale ka compiler ike e pili ana ia mea i kaʻikepili laʻau kuhikuhi pono e' ole-Yard.
/// ʻAʻole ka hoʻokumu ʻana i kahi `Vec<T>` i kumu *koke* hana hewa ʻole, akā e hoʻokau i ka hana undefined me nā hana palekana (me ka waiho ʻana iā ia).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` lawelawe 'ana e hiki ai unsafe kivila, e hana me ka uninitializedʻikepili.
/// He He hōʻailona no ka compiler nui ana i ka 'ikepili' aneʻi paha *ole* e initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // E hana i kūlike loa uninitialized i maopopo nä haumäna.
/// // Ke compiler ike iʻikepili i loko o ka `MaybeUninit<T>` i e helu kuhi, a nolaila keia mea,ʻaʻole UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // E hoʻonoho i kahi waiwai kūpono.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // E unuhi i ka ʻikepili i hoʻomaka mua ʻia-ʻae ʻia kēia *ma hope o* ka hoʻomaka mua ʻana o `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Ke compiler laila, ike e ole e kekahi pololei ole nā mea mahuʻi paha optimizations ma keia kuhi.
///
/// Oe ke manaʻo o `MaybeUninit<T>` like i he iki e like `Option<T>` akā, me kekahi o ka holo-manawa ka hoʻokoloʻana, a me kekahi o ka palekana loaʻa, e kaha.
///
/// ## out-pointers
///
/// Hiki nō ke hoʻohana `MaybeUninit<T>` e hoʻokō "out-pointers": kahi o ka hoi anaʻikepili mai kekahi papa, kekahi mea i ka laʻau kuhikuhi i kekahi (uninitialized) iaiyoe e waiho i ka hopena i loko.
/// Kēia hiki e pono keia mau mea ia ia mea pono no ka Caller e hooponopono ana i ka hoomanao ana i ka hopena ua waiho i loko oʻia anao? Aou, a me 'oe makemake i pale aku hoʻokali kūpono' Pńk'pika.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` aole i papa i nā mea kahiko, i mea nui.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ano, ua ike `v` ua initialized!Hoʻomaopopo pū kēia i ka hāʻule pono o vector.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Hoʻomaka i kahi huina huina-e-element
///
/// `MaybeUninit<T>` hiki ke hoʻohana ʻia e hoʻomaka i kahi ʻōnaehana nui-ma-kaho:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // E hana i ka uninitialized kū'ē o `MaybeUninit`.
///     // Ke `assume_init` Ua pakele no ka mea, ke 'ano mākou e ana i ua initializedʻaneʻi mea he pua kiele o' MaybeUninit`s, i mai ole koi initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // E kahe mai ana he `MaybeUninit` i mea ole.
///     // Penei ka hoʻohana 'ana maka laʻau kuhikuhi paha kahi o `ptr::write` aʻole ole i ka mea kahiko uninitialized cia e e haule iho la iluna.
/////
///     // No hoi ina he mea kekahi panic oiai keia loop, mākou i ka iaiyoe liu, akā,ʻaʻohe mea i hoomanaoia mai maluhia ana keiki.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // A pau ua initialized.
///     // Transmute i ka hoʻouka i ke initialized type.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// E hiki no hoi ke hana me ka hapa 'ia' initialized huihui ikehu lā, i hiki ke loaʻa ma ka haʻahaʻa-ʻilikai datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // E hana i ka uninitialized kū'ē o `MaybeUninit`.
/// // Ke `assume_init` Ua pakele no ka mea, ke 'ano mākou e ana i ua initializedʻaneʻi mea he pua kiele o' MaybeUninit`s, i mai ole koi initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Helu i ka helu o ka hehee wale mākou i hāʻawi.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // No kēlā me kēia mea i ka lālani, hāʻule inā mākou e hoʻokaʻawale iā ia.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing he struct kahua-ma-kahua
///
/// Hiki nō ke hoʻohana `MaybeUninit<T>`, a me ka [`std::ptr::addr_of_mut`] nunui, e initialize structs kahua ma ka mahinaʻai:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing ka `name` kahua
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing ka `list` kula Inā he mea he panic ʻaneʻi, laila, i ka `String` ma ka `name` kula liu i.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // A pau o ka mahinaʻai i initialized, no laila mākou e kāhea aku `assume_init` e kiʻi i initialized Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ua ua hoʻohiki ia i na ia nui, hoʻopololei, a Abiezera like `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Eia naʻe hoomanao i keʻano *i loaʻa ka* kekahi `MaybeUninit<T>` mea i pono i ka hookahiʻia;Rust i ole i mau kumu hoʻomalu i nā mahinaʻai o ka `Foo<T>` i ka ia mea me he `Foo<U>` a hiki ina `T` a me `U` i na ia nui, a hoʻopololei.
///
/// Eia no ka mea, i kekahi wahi waiwai mea i pololei ia no ka `MaybeUninit<T>` hiki ole i ka compiler pili non-zero/niche-filling optimizations, palena papaha kūpono ai i loko o ka nui size:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Inā `T` mea FFI-pakele, laila, pela o `MaybeUninit<T>`.
///
/// Ia `MaybeUninit` o `#[repr(transparent)]` (e hoike ana i ka mea hoʻohiki ma ka ia nui, hoʻopololei, a Abiezera like `T`), keia hana *i* hoʻololi i kekahi o ka mua caveats.
/// `Option<T>` a me `Option<MaybeUninit<T>>` hiki nō i okoa nui like 'ole, a ua hiki ke waiho' ano i loaʻa i ke kahua o ke 'ano `T` mai (a me ka pepa paia) okoa ma mua, inā ua mahinaʻai he `MaybeUninit<T>`.
/// `MaybeUninit` mea he hui anaʻano, a me `#[repr(transparent)]` ma uniona kālepa i lolelua ka (nānā [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Over manawa, i ka kiko'ī hoʻohiki o `#[repr(transparent)]` ma uniona kālepa i Hawaiʻi, a me `MaybeUninit` e paha e ole noho `#[repr(transparent)]`.
/// I mai la, `MaybeUninit<T>` e *mau* kumu hoʻomalu i ka mea i loaa o ka ia nui, hoʻopololei, a Abiezera like `T`;ʻo ia wale nō ke ala `MaybeUninit` e hoʻokō ai i ka hōʻoia e ulu paha.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang'ikamu no laila mākou e uhi nāʻano i loko o laila.He kūpono kēia no nā mea hoʻoulu.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // I kahea `T::clone()`, ua hiki ole ike ina e initialized mākou a lawa no ia.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Hoʻokumu i kahi `MaybeUninit<T>` hou i hoʻokumu ʻia me ka waiwai i hāʻawi ʻia.
    /// He maluhia, e kahea aku [`assume_init`] ma ka hoʻi waiwai io o keia kuleana pili i.
    ///
    /// Note e kahe mai ana he he `MaybeUninit<T>` e loa i kapa 'T` ka kulu kuhi.
    /// Ka mea, o kou kuleana ia e hōʻoia i `T` ʻia kulu ina mea ho'āpono initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// I ka mea hou `MaybeUninit<T>` i loko o ka uninitialized moku'āina.
    ///
    /// Note e kahe mai ana he he `MaybeUninit<T>` e loa i kapa 'T` ka kulu kuhi.
    /// Ka mea, o kou kuleana ia e hōʻoia i `T` ʻia kulu ina mea ho'āpono initialized.
    ///
    /// E nānā i ke [type-level documentation][MaybeUninit] no kekahi examples.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Hana i kekahi hou kaua o `MaybeUninit<T>` 'ikamu, i loko o ka uninitialized moku'āina.
    ///
    /// Note: i kahi mana future Rust lilo kēia hana i mea ʻole ke keu ka syntax literal e ʻae iā [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Ke kumu ma lalo hiki laila hoʻohana `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Hoʻi he (hiki uuku) māhele o kaʻikepili i i heluhelu maoli
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: Kuhi ʻia kahi `[MaybeUninit<_>; LEN]` uninitialized pono.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// I ka mea hou `MaybeUninit<T>` i loko o ka uninitialized moku'āina, a me ka piha i ka hoomanao ana me `0` nāʻai.Aia ia i ka `T` inā paha e hana i kēlā me kēia no ka hoʻomaka pono ʻana.
    ///
    /// No ka laʻana, `MaybeUninit<usize>::zeroed()` ua initialized, akā, `MaybeUninit<&'static i32>::zeroed()` mea,ʻaʻole no ka mea, kūmole pono ole e Yard.
    ///
    /// Note e kahe mai ana he he `MaybeUninit<T>` e loa i kapa 'T` ka kulu kuhi.
    /// Ka mea, o kou kuleana ia e hōʻoia i `T` ʻia kulu ina mea ho'āpono initialized.
    ///
    /// # Example
    ///
    /// Pololei oAaEeIeIAaIAeO o kēia papa: initializing he struct me Aʻohe, ma nā mahinaʻai o ka struct ke paa i ka iki-kumu 0 like me ka i pololei ia waiwai.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Pololei ole* oAaEeIeIAaIAeO o kēia papa: kahea `x.zeroed().assume_init()` ia `0` mea ole ka i pololei ia iki-kumu no keʻano:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ma loko o kahi pālua, hana mākou i `NotZero` i loaʻa ʻole kahi hoʻokae kūpono.
    /// // Kēia mea undefined kolohe.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // Maluhia: `u.as_mut_ptr()` wahi i anao? Aou iaiyoe.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nā pūʻulu i ka waiwai o ka `MaybeUninit<T>`.
    /// Keia overwrites kekahi mua waiwai ole e kahe mai ana ia, no laila e mālama mai i ka hoʻohana 'ana i kēia manawa elua ke ole oe makemake e skip e holo mai ana i ka destructor.
    ///
    /// No kou pono, keia hoi, e huli hou i ka mutable pili i ka (e maluhia initialized) Contents o `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // Maluhia: mākou e initialized keia nui.
        unsafe { self.assume_init_mut() }
    }

    /// Loaʻa i kahi kuhikuhi i ka waiwai i loaʻa.
    /// Heluhelu mai keia laʻau kuhikuhi a huli ia i loko o ka olua mea undefined hana ole ua initialized ka `MaybeUninit<T>`.
    /// Ke kākau nei i ka hoʻomanaʻo e kuhikuhi nei kēia poʻomanaʻo (non-transitively) i ka hana i hoʻoholo ʻole ʻia (koe wale nō i loko o `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // E haku i pili i loko o ka `MaybeUninit<T>`.He Ka Moana no ka mea, ua initialized mea.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Pololei ole* oAaEeIeIAaIAeO o keia hana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // i hana mākou i ka olua i ka uninitialized vector!Kēia mea undefined kolohe.⚠️
    /// ```
    ///
    /// (Ka leka hoʻomaopopo i na rula a puni i maopopo nä haumäna i uninitializedʻikepili ka mea,ʻaʻole finalized manawa, akā, a ka mea e, ka mea mea kupono, e pale aku ia lakou.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` a me `ManuallyDrop` nō o `repr(transparent)` no laila mākou e hoolei aku i ka laʻau kuhikuhi.
        self as *const _ as *const T
    }

    /// Loaʻa he mutable laʻau kuhikuhi i ka mea i kakauiaʻi maluna waiwai.
    /// Heluhelu mai keia laʻau kuhikuhi a huli ia i loko o ka olua mea undefined hana ole ua initialized ka `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // E haku i pili i loko o ka `MaybeUninit<Vec<u32>>`.
    /// // He Ka Moana no ka mea, ua initialized mea.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Pololei ole* oAaEeIeIAaIAeO o keia hana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // i hana mākou i ka olua i ka uninitialized vector!Kēia mea undefined kolohe.⚠️
    /// ```
    ///
    /// (Ka leka hoʻomaopopo i na rula a puni i maopopo nä haumäna i uninitializedʻikepili ka mea,ʻaʻole finalized manawa, akā, a ka mea e, ka mea mea kupono, e pale aku ia lakou.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` a me `ManuallyDrop` nō o `repr(transparent)` no laila mākou e hoolei aku i ka laʻau kuhikuhi.
        self as *mut _ as *mut T
    }

    /// Nā pōʻalo i ka waiwai, mai ka `MaybeUninit<T>` ipu.He He ala nui, e hōʻoia 'ia ka' ikepili e hele, Nakulukulu no, no ka mea, ka mea kūpono `T` mea malalo i ka mau kulu pēpēʻana.
    ///
    /// # Safety
    ///
    /// He mai i ka Caller i kumu hoʻomalu i ka `MaybeUninit<T>` maoli nō mea i loko o ka initialized moku'āina.Kii aku la keia i ka wa a ka maʻiʻo ua ole i maopopo initialized mea, lalau mai koke undefined kolohe.
    /// Aia ka [type-level documentation][inv] i ka ʻike hou aku e pili ana i kēia invitation hoʻomaka.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ma luna o ka mea, e hoomanao i ka hapanui ke ano i nā invariants ma kela aoao o ka alawa i noʻonoʻo initialized ma keʻano kiʻekiʻe.
    /// No ka laʻana, he '1`-initialized [`Vec<T>`] ua noʻonoʻo initialized (ma lalo o ka he manaʻo; keia, aole ia e hoolilo i ka hale lio kumu hoʻomalu) no ka mea, ke koi wale ka compiler ike e pili ana ia mea i kaʻikepili laʻau kuhikuhi pono e' ole-Yard.
    ///
    /// ʻAʻole ka hoʻokumu ʻana i kahi `Vec<T>` i kumu *koke* hana hewa ʻole, akā e hoʻokau i ka hana undefined me nā hana palekana (me ka waiho ʻana iā ia).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Pololei ole* oAaEeIeIAaIAeO o keia hana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ʻaʻole i hoʻomaka mua ʻia, no laila kēia laina hope i kumu i ka lawena i hoʻoholo ʻole ʻia.️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // Maluhia: o ka Caller pono kumu hoʻomalu i `self` ua initialized.
        // Ua hoi o ia hoʻi, ua `self` pono e he `value` Lolina.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Heluhelu i ka waiwai, mai ka `MaybeUninit<T>` ipu.Aia ka hopena `T` i ka lawelawe ʻana i ka hāʻule maʻamau.
    ///
    /// Inā hiki, ʻoi aku ka maikaʻi e hoʻohana i ka [`assume_init`] ma kahi o, kahi e pale ai i ka hoʻopili ʻana i ka ʻike o ka `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// He mai i ka Caller i kumu hoʻomalu i ka `MaybeUninit<T>` maoli nō mea i loko o ka initialized moku'āina.Kii aku la keia i ka wa a ka maʻiʻo ua ole i maopopo initialized mea, lalau mai undefined kolohe.
    /// Aia ka [type-level documentation][inv] i ka ʻike hou aku e pili ana i kēia invitation hoʻomaka.
    ///
    /// Eia kekahi, haʻalele kēia i kahi kope o ka ʻikepili like ma hope i ka `MaybeUninit<T>`.
    /// I ka hoʻohana 'ana i kope mau o nā ikepili (ma ke kahea `assume_init_read` mau manawa, a mua kahea `assume_init_read`, a laila [`assume_init`]), ka mea, o kou kuleana e hōʻoia' ia i no ia aeaiiuo eʻia i kekahi.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` o `Copy`, no laila mākou e heluhelu mau manawa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicating he `None` waiwai o Ka Moana, no laila mākou e heluhelu mau manawa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Pololei ole* oAaEeIeIAaIAeO o keia hana:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Mākou e hana elua kope o ka ua vector, e alakai ana i ka waʻa-noa ⚠️ ka wā e nā E hāʻule!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // Maluhia: o ka Caller pono kumu hoʻomalu i `self` ua initialized.
        // Heluhelu mai `self.as_ptr()` Ua pakele mai `self` e e initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Paka ua o ka kakauiaʻi maluna cia ma ka wahi.
    ///
    /// Inā 'oe i ona o ka `MaybeUninit`, e hiki ke hoʻohana [`assume_init`] hakahaka.
    ///
    /// # Safety
    ///
    /// He mai i ka Caller i kumu hoʻomalu i ka `MaybeUninit<T>` maoli nō mea i loko o ka initialized moku'āina.Kii aku la keia i ka wa a ka maʻiʻo ua ole i maopopo initialized mea, lalau mai undefined kolohe.
    ///
    /// Ma luna o ka mea, pono e māʻona a pau nā invariants o keʻano `T`, e like me ka `Drop` manaʻo o `T` (ai kona lala) e ku paa ma keia.
    /// No ka laʻana, he '1`-initialized [`Vec<T>`] ua noʻonoʻo initialized (ma lalo o ka he manaʻo; keia, aole ia e hoolilo i ka hale lio kumu hoʻomalu) no ka mea, ke koi wale ka compiler ike e pili ana ia mea i kaʻikepili laʻau kuhikuhi pono e' ole-Yard.
    ///
    /// E kahe mai ana ia he `Vec<T>` nae e i undefined kolohe.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // Maluhia: o ka Caller pono kumu hoʻomalu i `self` ua initialized a
        // māʻona nā mea invariants a pau o `T`.
        // E kahe mai ana i ka waiwai ma ka wahi mea pakele ina mea o ka hihia.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Loaʻa he kaʻana pili i ka kakauiaʻi maluna waiwai.
    ///
    /// Kēia hiki e pono mākou makemake i ka nānā 'ana i ka `MaybeUninit` ia i ua initialized akā, e mai i ona o ka `MaybeUninit` (hikiʻole i ka hoʻohana' ana o `.assume_init()`) wā.
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i hoʻoholo ʻole ʻia: aia i ka mea e kelepona ana e hōʻoia i ka `MaybeUninit<T>` maoli i kahi kūlana mua.
    ///
    ///
    /// # Examples
    ///
    /// ### Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ano, i ko kakou `MaybeUninit<_>` ua ikeia ia e initialized, ia mea Moana, e hana i kekahi i kaʻana like olua ia ia:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // Maluhia: `x` i ua initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Pololei ole*'Āpana o keia hana:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // i hana mākou i ka olua i ka uninitialized vector!Kēia mea undefined kolohe.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize ka `MaybeUninit` hoʻohana `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Kākau i kahi `Cell<bool>` uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // Maluhia: o ka Caller pono kumu hoʻomalu i `self` ua initialized.
        // Ua hoi o ia hoʻi, ua `self` pono e he `value` Lolina.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Loaʻa he mutable (unique) pili i ka kakauiaʻi maluna waiwai.
    ///
    /// Kēia hiki e pono mākou makemake i ka nānā 'ana i ka `MaybeUninit` ia i ua initialized akā, e mai i ona o ka `MaybeUninit` (hikiʻole i ka hoʻohana' ana o `.assume_init()`) wā.
    ///
    /// # Safety
    ///
    /// Ke kāhea nei i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i hoʻoholo ʻole ʻia: aia i ka mea e kelepona ana e hōʻoia i ka `MaybeUninit<T>` maoli i kahi kūlana mua.
    /// ʻO kahi laʻana, ʻaʻole hiki ke hoʻohana ʻia ʻo `.assume_init_mut()` e hoʻomaka mua i `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Hoʻohana pololei i kēia hana:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *a pau* na nāʻai o ka hoʻokomo o aooa?.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // I kēia manawa ʻike mākou ua hoʻokumu ʻia ʻo `buf`, no laila hiki iā mākou ke `.assume_init()` iā ia.
    /// // Eia nō naʻe, e hoʻohana ana i ka `.assume_init()` i kahi `memcpy` o nā byte 2048.
    /// // I hoʻike mākou aooa? Ua ua initialized me ka hoʻopiliʻana ia, ua upgrade ka `&mut MaybeUninit<[u8; 2048]>` a hiki i ka `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Maluhia: `buf` i ua initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ano, ua hiki ke hoʻohana `buf` like me ka maʻamau māhele:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Pololei ole*'Āpana o keia hana:
    ///
    /// ʻAʻole hiki iā ʻoe ke hoʻohana iā `.assume_init_mut()` e hoʻomaka i kahi waiwai:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // i hana mākou i ka (mutable) pili i ka uninitialized `bool`!
    ///     // Kēia mea undefined kolohe.⚠️
    /// }
    /// ```
    ///
    /// No ka mea he nui, e hiki ole [`Read`] i loko o kekahi uninitialized aooa?:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) pili i ka uninitialized iaiyoe!
    ///                             // Kēia mea undefined kolohe.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ʻAʻole hiki iā ʻoe ke hoʻohana i ke komo pololei ʻana i ke kahua e hana i ka hoʻomaka mua ʻana i ka māla.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) pili i ka uninitialized iaiyoe!
    ///                  // Kēia mea undefined kolohe.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) pili i ka uninitialized iaiyoe!
    ///                  // Kēia mea undefined kolohe.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Ke hilinaʻi nei mākou i ka hewa o luna aʻe, ʻo ia hoʻi, he kuhikuhi mākou i ka ʻikepili uninitialized (e laʻa, ma `libcore/fmt/float.rs`).
    // E hoʻoholo hope loa e pili ana i nā lula ma mua o ka hoʻokūpaʻa ʻana.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // Maluhia: o ka Caller pono kumu hoʻomalu i `self` ua initialized.
        // Ua hoi o ia hoʻi, ua `self` pono e he `value` Lolina.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Hoʻopili i nā waiwai mai kahi hoʻonohonoho o nā pahu `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// He mai i ka Caller ke kumu hoʻomalu i nā kumu o ke kaua i loko o ka initialized moku'āina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Maluhia: Ano, maluhia me mākou initialised nā kumu mua
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Hōʻoia ka mea kelepona i nā mea āpau o ka lālau i hoʻomaka mua ʻia
        // * `MaybeUninit<T>` a i ua hoʻohiki T e i ka ia'ōkuene
        // * MaybeUnint aʻole i haule, no laila, loaʻa nō i waʻa-noa ai A pela i ka huli ana i palekana
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Holoholo i na kumu mua i initialized, kiʻi i ka māhele no ia.
    ///
    /// # Safety
    ///
    /// Aia ia i ka mea kelepona e hōʻoia i ka loaʻa maoli o nā mea `MaybeUninit<T>` i kahi kūlana mua.
    ///
    /// Kii aku la keia i ka wa a ka maʻiʻo ua ole i maopopo initialized mea, lalau mai undefined kolohe.
    ///
    /// E ʻike iā [`assume_init_ref`] no nā kikoʻī a me nā laʻana.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // Maluhia: Ua palekana o Anederea, e māhele i ka `*const [T]` mai ka Caller hoʻohiki i
        // `slice` mea initialized, and`MaybeUninit` ua ua hoʻohiki ia i ka mea likeʻia me `T`.
        // Ke laʻau kuhikuhi loaa mea i pololei ia mai ka mea pili i ka iaiyoe waiwai e `slice` i mea i maopopo, a pela ua hoʻohiki ia e henua pololei no ka heluhelu.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Holoholo i na kumu mua i initialized, kiʻi i ka mutable māhele ia ia.
    ///
    /// # Safety
    ///
    /// Aia ia i ka mea kelepona e hōʻoia i ka loaʻa maoli o nā mea `MaybeUninit<T>` i kahi kūlana mua.
    ///
    /// Kii aku la keia i ka wa a ka maʻiʻo ua ole i maopopo initialized mea, lalau mai undefined kolohe.
    ///
    /// E ʻike iā [`assume_init_mut`] no nā kikoʻī a me nā laʻana.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Maluhia: like i ka palekana memo no `slice_get_ref`, akā, ua loaʻa he
        // mutable pili i ua i ua hoʻohiki ia e henua pololei i kakau iho ai.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Loaʻa i ka laʻau kuhikuhi i ka hehee ai mua o ka hoʻonohonoho.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Loaʻa he mutable laʻau kuhikuhi i ka hehee ai mua o ka hoʻonohonoho.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// E kope i nā mea mai `src` a `this`, e hoʻihoʻi nei i kahi kuhikuhi hiki ke hoʻololi i nā ʻike i loko o `this` i kēia manawa.
    ///
    /// Inā `T` aʻole i hoʻokō i `Copy`, hoʻohana [`write_slice_cloned`]
    ///
    /// Kēia mea i 'ano like ke [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Kēia papa, e panic ina na slices elua i okoa ka loa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Maluhia: mākou i pono mānewanewa i na oihana mua o Len i loko o ka hoʻokoe nona iho
    /// // ka mua src.len() hehee wale o ka vec mea i pololei ia manawa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // Maluhia: &[T] a&[MaybeUninit<T>] I ka mea hookahiʻia
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // Maluhia: Valid oihana mua i pono ua mānewanewa i `this` no laila ka mea, ua initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones na kumu mua, mai `src` a hiki i `this`, hoi i ka mutable pili i ka manawa initalized Contents o `this`.
    /// Kekahi ua initalized oihana mua e ole e haule.
    ///
    /// Inā `T` mea lapaʻau `Copy`, hoʻohana [`write_slice`]
    ///
    /// Kēia mea i 'ano like ke [`slice::clone_from_slice`] akā,' aʻole i ninini na oihana mua.
    ///
    /// # Panics
    ///
    /// E panic kēia hana inā ʻokoʻa nā lōʻihi o nā ʻāpana ʻelua, a i ʻole inā ʻo ka hoʻokō ʻana o `Clone` panics.
    ///
    /// Inā he panic, e hāʻule ana nā mea i kālani ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Maluhia: mākou i pono cloned i na oihana mua o Len i loko o ka hoʻokoe nona iho
    /// // ka mua src.len() hehee wale o ka vec mea i pololei ia manawa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ʻokoʻa ka copy_from_slice ʻaʻole kēia e kāhea iā clone_from_slice ma ka ʻāpana no ka mea ʻaʻole `MaybeUninit<T: Clone>` e hoʻokō iā Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // Maluhia: keia maka māhele, e komo wale initialized mea
                // ʻo ia ke kumu, ʻae ʻia e hoʻokuʻu iā ia.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: E Pono e kūlike loa māhele ia i ka ia loa
        // no ka iho i pale a kéu ia e elided, a me ka optimizer e paha memcpy no na mea a pau (no ka hoʻohālike T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // koa ua pono b/c panic ke hiki mai i ka clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // Maluhia: Valid oihana mua ua pono, ua kākau i loko o `this` no laila ka mea, ua initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}