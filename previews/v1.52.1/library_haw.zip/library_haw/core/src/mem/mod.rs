//! XIX. Oihana no ka Hana me ka iaiyoe.
//!
//! Kēia māhele Module kekahi mau oihana no querying i ka nui a me ka hoʻopololei o ke ano, initializing a manipulating iaiyoe.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// I kuleana a me "forgets" e pili ana i ka waiwai **me ka holo kona destructor**.
///
/// , E lohi loa kekahi waiwai o ka waiwai hooponopono iho i, e like me puʻu iaiyoe a me ka waihona i lawelawe, i loko o ka unreachable moku'āina.Naʻe, ka mea, 'aʻole i kumu hoʻomalu i mea kuhikuhi i keia iaiyoe e noho i pololei ia.
///
/// * Inā makemake ʻoe e kulu i ka hoʻomanaʻo, e ʻike iā [`Box::leak`].
/// * Inā 'oe makemake e loaa i ka maka laʻau kuhikuhi i ka hoomanao ana, ike [`Box::into_raw`].
/// * Inā 'oe makemake e hoolilo aku i ka waiwai pono, holo kona destructor, ike [`mem::drop`].
///
/// # Safety
///
/// `forget` Ua ole ia me `unsafe`, no ka mea, Rust ka maluhia hoʻohiki mai i loaʻa he kumu hoʻomalu i destructors, e mau ana ka holo.
/// No ka laʻana, he polokalamu hiki ke hana i kekahi olua kalapona hoʻohana [`Rc`][rc], a kāhea aku [`process::exit`][exit] e OAAIeOO me ka holo destructors.
/// Penei, hiki `mem::forget` mai palekana kivila mai, aole ia i fundamentally hoʻololi Rust ka maluhia hoʻohiki.
///
/// I mai la, leaking waiwai e like me iaiyoe a I/O mea mea IeAUPIIe, IAa IO undesirable.
/// Piʻi ka pono i loko o kekahi mau hihia hoʻohana kūikawā no FFI a i ʻole kuhi palekana ʻole, akā ʻoiai, ʻoi aku ka makemake o [`ManuallyDrop`].
///
/// No ka mea, e hoopoina ana au i ka waiwai ua ae, e ae kekahi `unsafe` pā'ālua e kākau i kēia manawa kūpono.Oe ke ole hoʻi i ka waiwai a me ka nui ana o ka Caller, e pono e holo aku au i ka waiwai o ka destructor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// ʻO ka hoʻohana palekana canonical o `mem::forget` e pale i kahi mea hōʻino waiwai i hoʻokō ʻia e `Drop` trait.No ka laʻana, keia e liu i `File`, oa
/// hoopakele mai ai i ka wa ia e ka ee iaaanu aey akā, aole pili i ka nń ku kahua o nā kumu waiwai:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// He mea pono i ka wa o ka ona o ka hp'pnphp 'o nā kumu waiwai i mua Neʻe i ka hoopai karaima waho o Rust, no ka laʻana ma ka pū i hiki i ka maka waihona descriptor i C kuhi.
///
/// # Pilina me `ManuallyDrop`
///
/// Ia `mem::forget` hiki ke hoʻohana 'no hoi, e hoolilo *iaiyoe* ona, e hana ai ka hewa-prone.
/// [`ManuallyDrop`] E e hoʻohana hakahaka.Noonoo, no ka laʻana, keia kuhi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Hana i kahi `String` me ka hoʻohana ʻana i nā ʻike o `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // kulu `v` no ka mea ua mālama ʻia kona hoʻomanaʻo e `s`
/// mem::forget(v);  // Hewa, V mea kūponoʻole a me ka pono ole e hele i kekahi kuleana pili i
/// assert_eq!(s, "Az");
/// // `s` ua implicitly haule a deallocated kona iaiyoe.
/// ```
///
/// Aia nō nā nīnūnē ka luna kumu hoʻohālike me:
///
/// * Inā nui hoopai karaima i hoʻohuiʻia ma waena o ke kūkulu o `String` a me ka invocation o `mem::forget()`, he panic i loko o ka mea makemake i ka papalua noa, no ka mea ua hoomanao ua lawelawe ia e nā `v` a me `s`.
/// * Ma hope o ke kahea `v.as_mut_ptr()` a me ka pū i hiki i ka ona o kaʻikepili no `s`, ka `v` waiwai i helu kuhi.
/// ʻO ka wā i ka waiwai ua pololei hoʻoneʻe i `mem::forget` (a e ole nānā ia), kekahi ano i ikaika lakou e pono ai ma luna o lākou nā loina e hana mai ia lakou helu kuhi ole hou nona ka wā dangling paha.
/// Ke hoʻohana nei i nā waiwai kūpono ʻole i kēlā me kēia ʻano, me ka hāʻawi ʻana iā lākou iā lākou a i ʻole hoʻihoʻi ʻana iā lākou mai nā hana, he hana kūpono ʻole ia a e haki paha i nā manaʻo i hana ʻia e ka mea hoʻopili.
///
/// Ke hoʻololi nei i `ManuallyDrop` e hōʻalo i nā pilikia ʻelua:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Mua mākou disassemble `v` i loko o kona maka māhele, hoikeʻoiaʻiʻo ka mea, aole i loaaʻi, haule iho!
/////
/// let mut v = ManuallyDrop::new(v);
/// // I kēia manawa disassemble `v`.Mau hana hiki ole panic, no laila,ʻaʻole hiki ole e he liu.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // ʻO ka hope, kūkulu i `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ua implicitly haule a deallocated kona iaiyoe.
/// ```
///
/// `ManuallyDrop` pale ikaika aku i ka papalua-manuahi no ka mea hiki ʻole iā mākou ke hana ʻino i mua o ka hana ʻana i kekahi mea ʻē aʻe.
/// `mem::forget()` ʻaʻole ʻae i kēia no ka mea hoʻopau ia kāna hoʻopaʻapaʻa, ke koi nei iā mākou e kāhea iā ia ma hope wale nō o ka unuhi ʻana i kekahi mea a mākou e pono ai mai `v`.
/// ʻOiai inā panic i hoʻolauna ʻia ma waena o ke kūkulu ʻana o `ManuallyDrop` a me ke kūkulu ʻana i ke aho (ʻaʻole hiki ke hana ʻia i ke code e like me ia i hōʻike ʻia), e hopena ia i ka liu ʻana a ʻaʻole he lua manuahi.
/// I nā huaʻōlelo ʻē aʻe, hewa ʻo `ManuallyDrop` ma ka ʻaoʻao o ka liu ʻana ma kahi o ke kuhi hewa ʻana ma ka ʻaoʻao o (ka pālua) kulu ʻana.
///
/// Eia kekahi, pale ʻo `ManuallyDrop` iā mākou mai ka loaʻa iā "touch" `v` ma hope o ka hoʻoili ʻana i ka ona iā `s`-ke kaʻina hope loa o ka launa pū ʻana me `v` e hoʻolei aku me ka holo ʻole ʻana o kāna mea hōʻino.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// E like me [`forget`], akā ʻae pū kekahi i nā waiwai unsized.
///
/// ʻO kahi hana wale nō kahi shim i manaʻo ʻia e hemo ke kūpaʻa ʻia ka hiʻohiʻona `unsized_locals`.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Hoʻihoʻi i ka nui o kahi ʻano ma nā byte.
///
/// ʻOi aku ke kikoʻī, ʻo kēia ka offset ma nā bytes ma waena o nā mea i kūleʻa i ka lālani me kēlā ʻano mea me ke kaulike kaulike.
///
/// No laila, no kekahi ʻano `T` a me ka lōʻihi `n`, he `n *size_of::<T>()` ka nui o `n* size_of::<T>()`.
///
/// Ma ka laulaha, ʻaʻole kūpaʻa ka nui o kahi ʻano ma o nā compilations, akā ʻo nā ʻano kikoʻī e like me nā primitives.
///
/// Hāʻawi ka papa aʻe i ka nui no nā primitives.
///
/// ʻAno |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Eia kekahi, ua like ka nui o `usize` a me `isize`.
///
/// Loaʻa i nā ʻano `*const T`, `&T`, `Box<T>`, `Option<&T>`, a me `Option<Box<T>>` āpau i ka nui like.
/// Inā nui ka `T`, like ka nui o kēlā me kēia ʻano me `usize`.
///
/// ʻAʻole hoʻololi ka loli o kahi kuhikuhi i kona nui.E like me, `&T` a me `&mut T` like ka nui.
/// Pēlā nō no `*const T` a me `* mut T`.
///
/// # Ka nui o nā huahana `#[repr(C)]`
///
/// Loaʻa i kahi hōʻike `C` no nā mea i hoʻonohonoho hoʻonohonoho.
/// Me kēia hoʻonohonoho, kūpaʻa hoʻi ka nui o nā mea i ka wā o nā māla āpau i kahi nui paʻa.
///
/// ## Ka nui o nā hana
///
/// No `structs`, hoʻoholo ʻia ka nui e kēia algorithm.
///
/// No kēlā me kēia māla i ka mea i kauoha ʻia e ke ʻaha hoʻolaha:
///
/// 1. Hoʻohui i ka nui o ke kahua.
/// 2. E hoʻohālua i ka nui o kēia manawa i ka helu kokoke loa o ka [alignment] kahua āpau.
///
/// ʻO ka hope, e hoʻopuni i ka nui o ka struct i ka nui kokoke o kāna [alignment].
/// ʻO ke kaulike o ka mea hoʻohui ka mea nui o nā āpau āpau;hiki ke hoʻololi i kēia me ka hoʻohana ʻana o `repr(align(N))`.
///
/// ʻAʻole like me `C`, ʻaʻole i hoʻopuni ʻia nā kaha zero i hoʻokahi paona i ka nui.
///
/// ## Ka nui o nā Enum
///
/// ʻAno like ka nui o nā enum me ka lawe ʻole i kahi ʻikepili ʻē aʻe ma mua o ka hoʻokae e like me nā enum C ma ka paepae i hōʻuluʻulu ʻia lākou.
///
/// ## Ka nui o nā ʻuniona
///
/// ʻO ka nui o kahi uniona ka nui o kāna māla nui loa.
///
/// ʻAʻole like me `C`, ʻaʻohe puni ʻia nā uniona nui i hoʻokahi byte i ka nui.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // kekahi primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // ʻO kekahi hoʻonohonoho
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Laʻau kuhikuhi nui like
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Ke hoʻohana nei iā `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ka nui o ke kula mua, he 1, no laila, hui 1 i ka nui.ʻO 1 ka nui.
/// // ʻO ke kaulike o ka pā lua ka 2, no laila e hoʻohui i 1 i ka nui no ka pale.Size He 2.
/// // I ka nui o ka lua o ke kahua, he 2, no laila, hui 2 a hiki i ka nui.ʻO 4 ka nui.
/// // Ka hoʻopololei o ke kolu o ka mea ma ke kahua 1, no laila, hui 0 a hiki i ka nui no ka nenelu loa.Size He 4.
/// // ʻO ka nui o ke kolu o ke kahua he 1, no laila e hoʻohui i 1 i ka nui.Size He 5.
/// // Eia hoi, i ka hoʻopololei o ka struct ka 2 (no ka mea, ka mea nui hoʻopololei i waena o kona mau kihapai o 2), no laila, hui 1 i ka nui no ka nenelu loa.
/// // ʻO 6 ka nui.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs hahai i ka ia rula.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // E noke i reordering i nā mahinaʻai ke lalo i ka nui.
/// // Mākou ke wehe i nā nenelu loa nāʻai e kau `third` mua `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union nui o ka nui o ka nui loa kula.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Hoʻihoʻi i ka nui o ke kuhi-i ka waiwai i nā bytes.
///
/// Kūlike kēia me `size_of::<T>()`.
/// Eia nō naʻe, i ka loaʻa ʻole o `T` * i kahi nui i ʻike ʻia, e laʻa, kahi ʻāpana [`[T]`][slice] a i ʻole [trait object], a laila hiki ke hoʻohana ʻia ka `size_of_val` e kiʻi i ka nui i ʻike ʻia e ka dynamically.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: He kuhikuhi kahi `val`, no laila he kuhikuhi maka maka kūpono
    unsafe { intrinsics::size_of_val(val) }
}

/// Hoʻihoʻi i ka nui o ke kuhi-i ka waiwai i nā bytes.
///
/// Kūlike kēia me `size_of::<T>()`.Eia nō naʻe, i ka loaʻa ʻole o `T` * i kahi nui i ʻike ʻia statically, e laʻa, kahi ʻāpana [`[T]`][slice] a i ʻole [trait object], a laila hiki ke hoʻohana ʻia ka `size_of_val_raw` e kiʻi i ka nui i ʻike ʻia e ka dynamically.
///
/// # Safety
///
/// Palekana wale kēia hana e kāhea inā paʻa nā ʻano aʻe:
///
/// - Inā `T` ka `Sized`, palekana kēia hana i ke kāhea mau ʻana.
/// - Inā ka unsized huelo o `T` mea:
///     - he [slice], a laila ʻo ka lōʻihi o ka huelo ʻokiʻoki e pono ai he integer i hoʻokumu ʻia, a me ka nui o ka *waiwai holoʻokoʻa*(ka lōʻihi o ka huelo hōʻeuʻeu + kuhī nui statically) pono e komo i `isize`.
///     - a [trait object], a laila pono e kuhikuhi i ka ʻāpana vtable o ka pointer i kahi vtable kūpono i loaʻa iā ia e ka coercion unsizing, a me ka nui o ka *waiwai holoʻokoʻa*(ka huelo huelo lōʻihi + kuhī nui statically) e pono ma `isize`.
///
///     - he (unstable) [extern type], a laila palekana kēia hana i ke kāhea ʻana, akā e panic a i ʻole hoʻi e hoʻoliʻiliʻi i ka waiwai hewa, no ka mea ʻaʻole ʻike ʻia ka ʻano o ka ʻano extern.
///     ʻO kēia ka hana e like me [`size_of_val`] ma ke kuhikuhi ʻana i kahi ʻano me ka huelo o waho.
///     - i ole ia, ka mea, ua conservatively ole ae, e kapa aku i kēia kuleana pili i.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: pono i ka mea e kāhea ke hāʻawi i kahi kuhikuhi kūpono kūpono
    unsafe { intrinsics::size_of_val(val) }
}

/// Hoʻihoʻi i ka [ABI]-ke koi kaulike kaulike o kahi ʻano.
///
/// ʻO kēlā me kēia kuhikuhi i kahi waiwai o ke ʻano `T` pono he mau helu o kēia helu.
///
/// ʻO kēia ke kaulike i hoʻohana ʻia no nā māla estr.Heʻuʻuku paha ia ma mua o ke kau pono i makemake ʻia.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Hoʻihoʻi i ka [ABI]-ke koi kaulike kaulike o ke ʻano o ka waiwai i kuhikuhi ʻia e `val`.
///
/// ʻO kēlā me kēia kuhikuhi i kahi waiwai o ke ʻano `T` pono he mau helu o kēia helu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: he kuhikuhi kahi val, no laila he kuhikuhi maka maka kūpono ia
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hoʻihoʻi i ka [ABI]-ke koi kaulike kaulike o kahi ʻano.
///
/// ʻO kēlā me kēia kuhikuhi i kahi waiwai o ke ʻano `T` pono he mau helu o kēia helu.
///
/// ʻO kēia ke kaulike i hoʻohana ʻia no nā māla estr.Heʻuʻuku paha ia ma mua o ke kau pono i makemake ʻia.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Hoʻihoʻi i ka [ABI]-ke koi kaulike kaulike o ke ʻano o ka waiwai i kuhikuhi ʻia e `val`.
///
/// ʻO kēlā me kēia kuhikuhi i kahi waiwai o ke ʻano `T` pono he mau helu o kēia helu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: he kuhikuhi kahi val, no laila he kuhikuhi maka maka kūpono ia
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hoʻihoʻi i ka [ABI]-ke koi kaulike kaulike o ke ʻano o ka waiwai i kuhikuhi ʻia e `val`.
///
/// ʻO kēlā me kēia kuhikuhi i kahi waiwai o ke ʻano `T` pono he mau helu o kēia helu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Palekana wale kēia hana e kāhea inā paʻa nā ʻano aʻe:
///
/// - Inā `T` ka `Sized`, palekana kēia hana i ke kāhea mau ʻana.
/// - Inā ka unsized huelo o `T` mea:
///     - he [slice], a laila ʻo ka lōʻihi o ka huelo ʻokiʻoki e pono ai he integer i hoʻokumu ʻia, a me ka nui o ka *waiwai holoʻokoʻa*(ka lōʻihi o ka huelo hōʻeuʻeu + kuhī nui statically) pono e komo i `isize`.
///     - a [trait object], a laila pono e kuhikuhi i ka ʻāpana vtable o ka pointer i kahi vtable kūpono i loaʻa iā ia e ka coercion unsizing, a me ka nui o ka *waiwai holoʻokoʻa*(ka huelo huelo lōʻihi + kuhī nui statically) e pono ma `isize`.
///
///     - he (unstable) [extern type], a laila palekana kēia hana i ke kāhea ʻana, akā e panic a i ʻole hoʻi e hoʻoliʻiliʻi i ka waiwai hewa, no ka mea ʻaʻole ʻike ʻia ka ʻano o ka ʻano extern.
///     ʻO kēia ka hana e like me [`align_of_val`] ma ke kuhikuhi ʻana i kahi ʻano me ka huelo o waho.
///     - i ole ia, ka mea, ua conservatively ole ae, e kapa aku i kēia kuleana pili i.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: pono i ka mea e kāhea ke hāʻawi i kahi kuhikuhi kūpono kūpono
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Hoʻi iā `true` inā haʻalele i nā waiwai o ka ʻano `T` mea.
///
/// ʻO kēia wale nō kahi hint optimization, a hoʻokō ʻia paha me ka conservative.
/// hiki ke hoʻihoʻi iā `true` no nā ʻano pono ʻole e hoʻokau.
/// E like me ka hoʻihoʻi mau ʻana iā `true` e lilo ia i hoʻokō pono i kēia ʻoihana.Eia naʻe inā hoʻihoʻi maoli kēia hana i `false`, a laila hiki iā ʻoe ke ʻike i ka waiho ʻana i ka `T` ʻaʻohe hopena ʻaoʻao.
///
/// ʻO nā pae haʻahaʻa o nā mea e like me nā hōʻiliʻili, pono e hāʻule lima i kā lākou ʻikepili, pono e hoʻohana i kēia hana e hōʻalo ai i ka hoʻāʻo pono ʻole ʻana e hāʻule i kā lākou ʻike āpau ke anai ʻia.
///
/// ʻAʻole paha kēia e hoʻokaʻawale i nā kūkulu hoʻokuʻu (kahi i ʻike maʻalahi ʻia a hoʻopau ʻia kahi loop i loaʻa ʻole nā hopena ʻaoʻao), akā lanakila pinepine ia no nā kūkulu debug.
///
/// E hoʻomaopopo i ka hana ʻana o [`drop_in_place`] i kēia kaha, no laila inā hiki ke hoʻemi ʻia kāu ukana hana i kekahi helu liʻiliʻi o nā kelepona [`drop_in_place`], pono ʻole kēia e hoʻohana ana i kēia.
/// I kahi kikoʻī e hiki iā ʻoe ke [`drop_in_place`] i kahi ʻāpana, a e hana ana i hoʻokahi pono_drop hōʻoia no nā waiwai āpau.
///
/// ʻO nā ʻano e like me Vec no laila `drop_in_place(&mut self[..])` wale nō me ka hoʻohana ʻole ʻana i ka `needs_drop`.
/// ʻO nā ʻano e like me [`HashMap`], ma ka ʻaoʻao ʻē aʻe, pono e hoʻokuʻu i nā waiwai i kēlā me kēia manawa a pono e hoʻohana i kēia API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Eia kahi laʻana o pehea e hoʻohana ai kahi hōʻiliʻili iā `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // papa i ka ʻikepili
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// E hoʻihoʻi i ka waiwai o ke ʻano `T` i hoʻohālikelike ʻia e ka-byte-pattern āpau.
///
/// ʻO kēia ke kumu, no ka laʻana, ʻaʻole pono ka zero padding byte i `(u8, u16)`.
///
/// ʻAʻohe mea hōʻoia e hōʻike ana kahi hiʻohiʻona byte-zero āpau i kahi waiwai kūpono o kekahi ʻano `T`.
/// ʻO kahi laʻana, ʻaʻohe waiwai kūpono ka-byte-pattern a pau no nā ʻano kūmole (`&T`, `&mut T`) a me nā kuhikuhi kuhikuhi.
/// Ke hoʻohana nei i ka `zeroed` ma ia ʻano ʻano ke kumu koke o [undefined behavior][ub] no ka mea ʻo [the Rust compiler assumes][inv] aia kekahi waiwai kūpono i nā manawa āpau i manaʻo ʻia ua hoʻomaka mua ʻia.
///
///
/// Loaʻa ka hopena like me [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// He mea pono ia no FFI i kekahi manawa, akā pono e hōʻalo ʻia.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Hoʻohana pololei i kēia hana: ke hoʻomaka nei i ka integer me ka ʻole.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Hewa* ka hoʻohana ʻana i kēia hana: ke hoʻomaka nei i kahi kūmole me ka ʻole.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefined ana!
/// let _y: fn() = unsafe { mem::zeroed() }; // A hou!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: pono i ka mea kelepona e hōʻoia i ka waiwai o ka helu zero āpau no `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Koho ʻo Bypass Rust i kahi hoʻomanaʻo hoʻomanaʻo-hoʻomaka ʻana ma ke kuhi ʻana e hana i kahi waiwai o ke ʻano `T`, ʻoiai e hana iki ʻole.
///
/// **Ua hoʻonele ʻia kēia hana.** E hoʻohana ma kahi o [`MaybeUninit<T>`].
///
/// ʻO ke kumu o ka hoʻohaʻahaʻa ʻaʻole hiki i ka hana maʻamau ke hoʻohana pololei ʻia: like ka hopena me [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// E like me ka [`assume_init` documentation][assume_init] e wehewehe ai, [the Rust compiler assumes][inv] i hoʻokumu ʻia nā waiwai i kumu mua ʻia.
/// A ʻo kahi hopena, ke kāhea ʻana eg
/// `mem::uninitialized::<bool>()` ke kumu o ka hana kūpono ʻole no ka hoʻihoʻi ʻana i `bool` ʻaʻole maopopo ia `true` a i ʻole `false`.
/// ʻOi aku ka maikaʻi, hoʻomanaʻo maoli ʻole uninitialized e like me ka mea i hoʻihoʻi ʻia ma aneʻi he mea kūikawā i ka ʻike o ka mea hoʻopili ʻaʻole kahi waiwai paʻa.
/// Hana kēia i ka hana i hoʻoholo ʻole ʻia e loaʻa i ka ʻikepili uninitialized i kahi loli ʻoiai he ʻano helu integer kēlā ʻano.
/// (Hoolaha i na rula a puni uninitialized integers ka mea,ʻaʻole finalized manawa, akā, a ka mea e, ka mea mea kupono, e pale aku ia lakou.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: pono i ka mea kelepona e hōʻoia i ka waiwai o ka unitialized kūpono no `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Kuapo i nā waiwai i nā wahi loli ʻelua, me ka hoʻopau ʻole ʻana i kekahi i kekahi.
///
/// * Inā makemake ʻoe e kuapo me kahi waiwai paʻamau a i ʻole dummy waiwai, ʻike iā [`take`].
/// * Inā makemake ʻoe e kuapo me kahi waiwai i hala, e hoʻihoʻi ana i ka waiwai kahiko, e ʻike iā [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SAFETY: ua hana ʻia nā pointers maka mai nā kūmole hiki ʻole ke hoʻololi ʻia e hōʻoluʻolu ana i nā mea āpau
    // nā mea kāohi ma `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Hoʻololi hou iā `dest` me ka waiwai paʻamau o `T`, e hoʻihoʻi nei i ka waiwai `dest` i hala.
///
/// * Inā makemake ʻoe e pani i nā waiwai o nā loli ʻelua, ʻike iā [`swap`].
/// * Inā makemake ʻoe e pani me kahi waiwai i hala ma kahi o ka waiwai paʻamau, e ʻike iā [`replace`].
///
/// # Examples
///
/// ʻO kahi laʻana maʻalahi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ʻae i ka lawe ʻana i kahi mālamana ma ka hoʻololi ʻana iā ia me kahi waiwai "empty".
/// Me `take` hiki iā ʻoe ke holo i nā pilikia e like me kēia:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// E hoʻomaopopo ʻaʻole pono ka `T` e hoʻokō iā [`Clone`], no laila ʻaʻole hiki ke clone a hoʻonohonoho hou iā `self.buf`.
/// Akā hiki ke hoʻohana ʻia ʻo `take` e hoʻokaʻawale i ka waiwai kumu o `self.buf` mai `self`, e ʻae ana e hoʻihoʻi ʻia:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// E hoʻoneʻe iā `src` i ka `dest` i kuhikuhi ʻia, e hoʻihoʻi nei i ka waiwai `dest` i hala.
///
/// ʻAʻole hāʻule ka waiwai.
///
/// * Inā makemake ʻoe e pani i nā waiwai o nā loli ʻelua, ʻike iā [`swap`].
/// * Inā makemake ʻoe e pani me kahi waiwai paʻamau, e ʻike iā [`take`].
///
/// # Examples
///
/// ʻO kahi laʻana maʻalahi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ʻae i ka hoʻohana ʻana i kahi māla kūkulu i ka hoʻololi ʻana iā ia me kahi waiwai ʻē aʻe.
/// Me `replace` hiki iā ʻoe ke holo i nā pilikia e like me kēia:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// E hoʻomaopopo ʻaʻole pono ʻo `T` e hoʻokō iā [`Clone`], no laila ʻaʻole hiki iā mākou ke clone `self.buf[i]` e hōʻalo i ka neʻe.
/// Akā hiki ke hoʻohana ʻia ʻo `replace` e hoʻokaʻawale i ka waiwai kumu ma kēlā papa kuhikuhi mai `self`, e ʻae iā ia e hoʻihoʻi:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Heluhelu mākou mai `dest` akā kākau pololei iā `src` i loko o laila ma hope,
    // ʻo ia ka mea ʻaʻole i hoʻopili ʻia ka waiwai kahiko.
    // ʻAʻohe mea i hāʻule a ʻaʻohe mea ma aneʻi hiki iā panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Nā hōʻike o kahi waiwai.
///
/// Hana kēia pēlā ma ke kāhea ʻana i ka hoʻokō o ka hoʻopaʻapaʻa o [`Drop`][drop].
///
/// ʻAʻole hana maikaʻi kēia no nā ʻano e hoʻokomo iā `Copy`, e laʻa
/// integers.
/// Kope ʻia ia mau waiwai a hoʻoneʻe ʻia ʻo _then_ i ka hana, no laila ke hoʻomau nei ke kumukūʻai ma hope o kēia kelepona ʻana.
///
///
/// ʻAʻole kilokilo kēia hana;ho'ākāka maoli ʻia ia
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ma muli o ka hoʻoneʻe ʻia o `_x` i ka hana, hāʻule wale ia ma mua o ka hoʻi ʻana o ka hana.
///
/// [drop]: Drop
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // kūlike loa papa i ka vector
/// ```
///
/// Ma muli o ka hoʻokō ʻana o [`RefCell`] i nā lula hōʻaiʻe i ka wā holo, hiki iā `drop` ke hoʻokuʻu i kahi hōʻaiʻē [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // hāʻawipio i ka mutable kēia kanaka ma luna o kēia kau
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// ʻAʻole hoʻopili ʻia nā helu helu helu a me nā ʻano ʻē aʻe i ka [`Copy`] e `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // neʻe a kulu kahi kope o `x`
/// drop(y); // neʻe a kulu kahi kope o `y`
///
/// println!("x: {}, y: {}", x, y.0); // loaʻa nō
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Unuhi i ka `src` ma ke ʻano he `&U`, a laila heluhelu `src` me ka neʻe ʻole o ka waiwai i loko.
///
/// Kuhi ʻole kēia hana i ka pointer `src` kūpono no nā [`size_of::<U>`][size_of] bytes ma o ka hoʻoili ʻana i `&T` i `&U` a laila e heluhelu ana i ka `&U` (koe wale nō ua hana ʻia kēia i kahi ala pololei a ʻo `&U` e hana i nā koi kaulike ʻoi aku ka nui ma mua o `&T`).
/// E hana palekana ʻole ia i kahi kope o ka waiwai i loaʻa ma kahi o ka neʻe ʻana mai `src`.
///
/// ʻAʻole ia he kuhi manawa hōʻuluʻulu inā he ʻokoʻa ka nui o `T` a me `U`, akā paipai nui ʻia e kāhea wale i kēia hana i like ka nui o `T` a me `U`.Hoʻokomo kēia hana i [undefined behavior][ub] inā ʻo `U` ʻoi aku ka nui ma mua o `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // E hoʻokope i kaʻikepili mai 'foo_array', a hana ia me he 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Hoʻololi i ka mānewanewaʻikepili
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // ʻAʻole pono e loli nā ʻike o 'foo_array'
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Inā he koina koina kiʻekiʻe ʻo U, ʻaʻole pono e hoʻopili pono ʻia ʻo src.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: ʻO `src` kahi kūmole i hōʻoia ʻia e kūpono no nā heluhelu.
        // Pono ka mea e kelepona ana e hōʻoia i ka palekana o ka transmutation maoli.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: ʻO `src` kahi kūmole i hōʻoia ʻia e kūpono no nā heluhelu.
        // Nānā wale mākou ua hoʻopili pololei ʻia ʻo `src as *const U`.
        // Pono ka mea e kelepona ana e hōʻoia i ka palekana o ka transmutation maoli.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ʻO ke ʻano opaque e hōʻike ana i ka mea hoʻokae o kahi enum.
///
/// E ʻike i ka hana [`discriminant`] i kēia modula no ka ʻike hou aku.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ʻAʻole hiki ke kiʻi ʻia kēia mau mea trait no ka mea ʻaʻole makemake mākou i nā palena ma luna o T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// E hoʻihoʻi i kahi waiwai e hōʻikeʻike kū hoʻokahi ana i ka vari enum ma `v`.
///
/// Inā ʻaʻole `T` kahi enum, ke kāhea ʻana i kēia hana ʻaʻole e hopena i ka lawena i hoʻoholo ʻole ʻia, akā ʻaʻole hōʻike ʻia ka waiwai hoʻihoʻi.
///
///
/// # Stability
///
/// Hiki ke loli ka mea hoʻokae o ka ʻokoʻa enum inā hoʻololi ka wehewehe enum.
/// ʻAʻole e loli kahi hoʻokae o kekahi ʻano i waena o nā mea hoʻohui me ka mea hoʻopili like.
///
/// # Examples
///
/// Hiki ke hoʻohana i kēia e hoʻohālikelike i nā enum e lawe i ka ʻikepili, ʻoiai e nānā ʻole ana i ka ʻike maoli.
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Hoʻihoʻi i ka helu o nā ʻano ʻokoʻa i ka enum type `T`.
///
/// Inā ʻaʻole `T` kahi enum, ke kāhea ʻana i kēia hana ʻaʻole e hopena i ka lawena i hoʻoholo ʻole ʻia, akā ʻaʻole hōʻike ʻia ka waiwai hoʻihoʻi.
/// ʻO ke kaulike, inā he enum ka `T` me nā mea ʻoi aku ka nui ma mua o `usize::MAX` ʻike ʻole ʻia ka waiwai hoʻihoʻi.
/// E helu ʻia nā ʻano kanaka ʻole.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}