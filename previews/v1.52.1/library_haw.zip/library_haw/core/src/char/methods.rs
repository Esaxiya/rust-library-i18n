//! impl Mike Char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// ʻO ke kiko kiko kuhi kūpono kiʻekiʻe a `char` i loaʻa.
    ///
    /// A `char` mea he [Unicode Scalar Value], i mea e ana ia mea he [Code Point], akā, wale poʻe i loko o ka kekahi huahelu.
    /// `MAX` ʻo ia ka helu kuhi pono ʻoi loa ʻo ia [Unicode Scalar Value] kūpono.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () ua hoʻohana 'ia i loko o Unicode e ho i ka ho omńkalakala i hewa.
    ///
    /// Ua hiki ke hana, no ka laʻana, ka wā e hāʻawi ino-i hanaʻia UTF-8 nāʻai i [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// ʻO ka mana o [Unicode](http://www.unicode.org/) i hoʻokumu ʻia nā ʻāpana Unicode o nā ʻano `char` a me `str`.
    ///
    /// Hoʻokuʻu pinepine ʻia nā mana hou o Unicode a ma hope iho ua hōʻano hou ʻia nā ʻano hana āpau i ka waihona waihona maʻamau ma muli o Unicode.
    /// No laila ke ʻano o kekahi mau ʻano `char` a me `str` a me ka waiwai o kēia kū mau i loli i ka manawa.
    /// Kēia mea,ʻaʻole * * manaoia e ia i ka wawahi loli.
    ///
    /// Ua wehewehe ʻia ka papa helu helu mana i [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Hana i mea iterator ma luna o ka UTF-16 encoded kivila kumumanao ma `iter`, hoi mai unpaired surrogates like `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Hiki ke kiʻi i kahi decoder lossy ma ke kuapo ʻana i nā hualoaʻa `Err` me ke ʻano pani:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Hoʻohuli i `u32` i `char`.
    ///
    /// E hoʻomaopopo he pono nā ʻā Char āpau [ʻu32`] s, a hiki ke hoʻolei ʻia i kekahi me
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Naʻe, ka mea nana e hoole mea i oiaio: i nā mea a pau i pololei ia ['u32`] mau mea i pololei ia`char`s.
    /// `from_u32()` e hoʻihoʻi iā `None` inā ʻaʻole kūpono ka hoʻokomo i kahi `char`.
    ///
    /// No kahi mana palekana ʻole o kēia hana i nānā ʻole i kēia mau kaha, e nānā iā [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ke hoʻihoʻi nei iā `None` ke ʻole ka hoʻokomo he `char` kūpono:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Hoʻololi i `u32` i `char`, me ka nānā ʻole i ka pono.
    ///
    /// E hoʻomaopopo he pono nā ʻā Char āpau [ʻu32`] s, a hiki ke hoʻolei ʻia i kekahi me
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Naʻe, ka mea nana e hoole mea i oiaio: i nā mea a pau i pololei ia ['u32`] mau mea i pololei ia`char`s.
    /// `from_u32_unchecked()` e kāpae'ōlelo i kēia, a me ka blindly hoolei ia `char`, o hiki mai e pili ana i ka helu kuhi kekahi.
    ///
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana, no ka mea hiki ke kūkulu i nā koina `char` kūpono ʻole.
    ///
    /// No kahi mana palekana o kēia hana, e nānā i ka hana [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // Maluhia: pono e kokuaia oia e ka Caller ka maluhia like.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Pio i ka huahelu i loko o ka hāʻawi radix i ka `char`.
    ///
    /// A 'radix' ʻaneʻi ua kekahi manawa i kapaʻia he 'base'.
    /// Kuhi kahi radix o ʻelua i kahi helu binary, kahi radix o ʻumi, decimal, a me kahi radix o ʻumikūmāono, hexadecimal, e hāʻawi i kekahi mau helu maʻamau.
    ///
    /// Ākeʻakeʻa kumu radices i kākoʻo.
    ///
    /// `from_digit()` E hoʻi `None` ina ka hoʻokomo o mea,ʻaʻole he huahelu i loko o ka haawi mai ai radix.
    ///
    /// # Panics
    ///
    /// Panics inā hāʻawi ʻia i kahi radix ʻoi aku ma mua o 36.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ʻO Decimal 11 kahi helu hoʻokahi ma ke kumu 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ke hoʻihoʻi nei iā `None` ke ʻole he helu ke komo.
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ke hele nei i kahi radix nui, e hoʻoulu ana i panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Nānā inā he `char` kahi kikohoʻe i ka radix i hāʻawi ʻia.
    ///
    /// A 'radix' ʻaneʻi ua kekahi manawa i kapaʻia he 'base'.
    /// Kuhi kahi radix o ʻelua i kahi helu binary, kahi radix o ʻumi, decimal, a me kahi radix o ʻumikūmāono, hexadecimal, e hāʻawi i kekahi mau helu maʻamau.
    ///
    /// Ākeʻakeʻa kumu radices i kākoʻo.
    ///
    /// Ke hoʻohālikelike i [`is_numeric()`], i kēia papa wale nō ke hoʻomaopopo iho i ka huapalapala `0-9`, `a-z` a me `A-Z`.
    ///
    /// 'Digit' ua wehewehe ʻia kēia mau huapalapala wale nō:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// No ka oi kelakela hoomaopopo o 'digit', ike [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics inā hāʻawi ʻia i kahi radix ʻoi aku ma mua o 36.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ke hele nei i kahi radix nui, e hoʻoulu ana i panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Hoʻololi i `char` i kekona i ka radix i hāʻawi ʻia.
    ///
    /// A 'radix' ʻaneʻi ua kekahi manawa i kapaʻia he 'base'.
    /// Kuhi kahi radix o ʻelua i kahi helu binary, kahi radix o ʻumi, decimal, a me kahi radix o ʻumikūmāono, hexadecimal, e hāʻawi i kekahi mau helu maʻamau.
    ///
    /// Ākeʻakeʻa kumu radices i kākoʻo.
    ///
    /// 'Digit' ua wehewehe ʻia kēia mau huapalapala wale nō:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Huli `None` ina ka `char` aole ia e hoʻohuli i i ka huahelu i loko o ka haawi mai ai radix.
    ///
    /// # Panics
    ///
    /// Panics inā hāʻawi ʻia i kahi radix ʻoi aku ma mua o 36.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ke hala nei i nā hopena huahelu ʻole i ka holomua.
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ke hele nei i kahi radix nui, e hoʻoulu ana i panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ua hoʻokaʻawale ʻia ke code ma aneʻi e hoʻomaikaʻi ai i ka wikiwiki hoʻokō no nā hihia kahi mau ka `radix` a 10 a ʻoi iki paha
        //
        let val = if likely(radix <= 10) {
            // Ināʻaʻole he huahelu, he helu i oi aku ma mua o radix e e hana.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Hoʻihoʻi i kahi iterator e hāʻawi i ka hexadecimal Unicode pakele o ke ʻano he "char`s.
    ///
    /// E pakele kēia i nā huapalapala me ka syntax Rust o ka palapala `\u{NNNNNN}` ma kahi o `NNNNNN` kahi hōʻike hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // a i ʻole-ing 1 e hōʻoia no c==0 ka helu kuhi ʻana e pono e paʻi i hoʻokahi huahelu a (ʻo ia ka mea like) e pale i ka (31, 32) kahawai i lalo
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ka Papa kuhikuhi o ka loa nui hex huahelu
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// An, ua kīkoʻo akula mana o `escape_debug` i kohoʻia pela pakele hoopomaikai io Grapheme codepoints.
    /// ʻAe kēia iā mākou e hōʻano i nā huapalapala e like me nā māka nonspacing ʻoi aku ka maikaʻi ke hoʻomaka lākou i kahi kaula.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Hoike he iterator e haawi i ko ka literal e pakele ai kivila mai o ke ano like 'char`s.
    ///
    /// Kēia e pakele i ka huapalapala i 'ano like me ka `Debug` implementations o `str` a `char`.
    ///
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Hoike he iterator e haawi i ko ka literal e pakele ai kivila mai o ke ano like 'char`s.
    ///
    /// Koho ʻia ka paʻamau me kahi bias i ka hana ʻana i nā leka i kū kānāwai i nā ʻano ʻōlelo like ʻole, me C++ 11 a me nā ʻōlelo ʻohana C like.
    /// ʻO nā lula kikoʻī:
    ///
    /// * Pakele ʻo Tab ma ke ʻano he `\t`.
    /// * Pakele ka hoʻihoʻi kaʻa ma ke ʻano `\r`.
    /// * Pakele ka hānai laina ma ke ʻano `\n`.
    /// * Single kea ua pakele like `\'`.
    /// * Pakele ka ʻōlelo pālua ma `\"`.
    /// * Backslash Ua pakele like `\\`.
    /// * ʻO kēlā me kēia ʻano ma ka pae 'printable ASCII' `0x20` .. ʻAʻole i pakele ʻo `0x7e`.
    /// * Hāʻawi ʻia nā huapalapala ʻē aʻe āpau i nā hexadecimal Unicode e pakele ai;ike [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Huli i ka helu o nāʻai keia `char` makemake pono ina encoded ma UTF-8.
    ///
    /// Aia kēlā helu o nā bytes ma waena o 1 a me 4 mau.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Hōʻoia ka ʻano `&str` i ka ʻike ma loko o UTF-8, a no laila hiki iā mākou ke hoʻohālikelike i ka lōʻihi o ka lōʻihi inā e hōʻike ʻia kēlā me kēia kiko helu ma ke ʻano he `char` vs ma `&str` ponoʻī.
    ///
    ///
    /// ```
    /// // e like me nā chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // nā hiki ke hoʻokū 'like ekolu nāʻai
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ma ke ʻano he &str, ua hoʻopili ʻia kēia mau mea i ka UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // hiki iā mākou ke ʻike i lawe lākou i ʻeono paona ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... pono e like me ka &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Hoʻihoʻi i ka helu o nā anakuhi huahelu 16-bit e pono ai i kēia `char` inā i encode ʻia i UTF-16.
    ///
    ///
    /// E nānā i ka moʻolelo no ka [`len_utf8()`] no ka nui wehewehe ana i kēia manaʻo.
    /// Kēia kuleana pili i He He aniani, akā, no ka UTF-16 kahi o UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encodes keia ano like UTF-8 i loko o ka hoakakaʻai aooa, a laila, e huli hou i ka subslice o ka aooa? E paka me ka encoded ano.
    ///
    ///
    /// # Panics
    ///
    /// Panics ina ka aooa mea,ʻaʻole nui nui iho la ia.
    /// ʻO kahi pale pale o ka loa ʻehā ka nui e encode i kekahi `char`.
    ///
    /// # Examples
    ///
    /// Ma nā o kēia mau hoailona, 'ß' lawe mau nāʻai i ka encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ʻO kahi pale pale liʻiliʻi loa:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // Maluhia: `char` mea,ʻaʻole he surrogate, no laila, i kēia mea i pololei ia UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes keia ano like UTF-16 i loko o ka hoakaka `u16` aooa, a laila, e huli hou i ka subslice o ka aooa? E paka me ka encoded ano.
    ///
    ///
    /// # Panics
    ///
    /// Panics ina ka aooa mea,ʻaʻole nui nui iho la ia.
    /// ʻO kahi pale pale o ka lōʻihi 2 ua lawa ka nui e encode i kekahi `char`.
    ///
    /// # Examples
    ///
    /// Ma nā o kēia mau hoailona, '𝕊' lawe mau 'u16`s e encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ʻO kahi pale pale liʻiliʻi loa:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Hoʻi iā `true` inā loaʻa kēia `char` i ka waiwai `Alphabetic`.
    ///
    /// `Alphabetic` ua ho'ākāka 'ia i loko o ka Mokuna 4 (pūʻulu ÿike) o ka [Unicode Standard], a i hoakaka ia ma ka [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // he nui nā mea ke aloha, akā ʻaʻole ia he pīʻāpā
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Hoike `true` ina keia `char` i ka `Lowercase` waiwai.
    ///
    /// `Lowercase` ua ho'ākāka 'ia i loko o ka Mokuna 4 (pūʻulu ÿike) o ka [Unicode Standard], a i hoakaka ia ma ka [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // ʻAʻohe o nā kākau kākau Kina like ʻole a me nā pākuhi, a no laila:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Hoike `true` ina keia `char` i ka `Uppercase` waiwai.
    ///
    /// `Uppercase` ua ho'ākāka 'ia i loko o ka Mokuna 4 (pūʻulu ÿike) o ka [Unicode Standard], a i hoakaka ia ma ka [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // ʻAʻohe o nā kākau kākau Kina like ʻole a me nā pākuhi, a no laila:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Hoike `true` ina keia `char` i ka `White_Space` waiwai.
    ///
    /// `White_Space` ua hōʻike ʻia ma ka [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // he ole-wawahi ae la,
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Hoʻi `true` ina keia `char` satisfies kekahi [`is_alphabetic()`] a [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Hoʻihoʻi iā `true` inā loaʻa kēia `char` i ka waeʻano maʻamau no nā code control.
    ///
    /// i ho'ākāka 'ia ma ka pāʻana o nā loina (kivila helu me ka mau waeʻano o `Cc`) i loko o ka Mokuna 4 (pūʻulu ÿike) o ka [Unicode Standard], a i hoakaka ia ma ka [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // U + 009C, kui TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Hoʻi iā `true` inā loaʻa kēia `char` i ka waiwai `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ua ho'ākāka 'ia i loko o [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29], a i hoakaka ia ma ka [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Hoʻi `true` ina keia `char` i kekahi o na mau waeʻano no ka helu.
    ///
    /// ʻO kekahi mau waeʻano no ka huina (`Nd` no kekimala huahelu, `Nl` no ka palapala-e like laulā huapalapala, a me `No` no nā laulā huapalapala) e hoakaka ia ma ka [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Hoike he iterator e haawi i ko ka lowercase kŰia ha o keia `char` me kekahi a oi
    /// `char`s.
    ///
    /// Inā keia `char` 'aʻole i loaʻa ka lowercase kŰia ha, ka iterator e haawi i ko ka ia `char`.
    ///
    /// Inā keia `char` i kekahi i kekahi-i-kekahi lowercase kŰia ha haawiia mai e ka [Unicode Character Database][ucd] [`UnicodeData.txt`], ka iterator e haawi i ko ia `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Inā koi kēia `char` i nā manaʻo kūikawā (e laʻa me nā "char" he nui) hāʻawi ka iterator i nā "char" i hāʻawi ʻia e [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Kēia hana hanaʻia he unconditional kŰia ha me kā.Ia mea, no ka huli ana i kūʻokoʻa o ka pōʻaiapili a me ka 'ōlelo.
    ///
    /// Ma ka [Unicode Standard], Chapter 4 (ano waiwai) discusses hihia kŰia ha i ka nui a me ka Chapter 3 (Conformance) discusses ka paʻamau algorithm no ka hihia huli ana.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // I kekahi manawa ʻoi aku ka hopena ma mua o hoʻokahi ʻano.
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Hoʻohuli nā huapalapala ʻaʻohe o nā kaha nui a me nā mea liʻiliʻi i loko o lākou iho.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Hoike he iterator e haawi i ko ka UPPERCASE_OR kŰia ha o keia `char` me kekahi a oi
    /// `char`s.
    ///
    /// Inā keia `char` aʻole ole i ka UPPERCASE_OR kŰia ha, ka iterator e haawi i ko ka ia `char`.
    ///
    /// Inā keia `char` i kekahi i kekahi-i-kekahi UPPERCASE_OR kŰia ha haawiia mai e ka [Unicode Character Database][ucd] [`UnicodeData.txt`], ka iterator e haawi i ko ia `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Inā koi kēia `char` i nā manaʻo kūikawā (e laʻa me nā "char" he nui) hāʻawi ka iterator i nā "char" i hāʻawi ʻia e [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Kēia hana hanaʻia he unconditional kŰia ha me kā.Ia mea, no ka huli ana i kūʻokoʻa o ka pōʻaiapili a me ka 'ōlelo.
    ///
    /// Ma ka [Unicode Standard], Chapter 4 (ano waiwai) discusses hihia kŰia ha i ka nui a me ka Chapter 3 (Conformance) discusses ka paʻamau algorithm no ka hihia huli ana.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // I kekahi manawa ʻoi aku ka hopena ma mua o hoʻokahi ʻano.
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Hoʻohuli nā huapalapala ʻaʻohe o nā kaha nui a me nā mea liʻiliʻi i loko o lākou iho.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Note ma ka'ōlelo a aupuni
    ///
    /// Ma Turkish, ka like o 'i' ma Roma, he elima mauʻano a kahi o ka elua:
    ///
    /// * 'Dotless': I/ı, kākau ʻia i kekahi manawa
    /// * 'Dotted': ʻI/i
    ///
    /// E noke i ka lowercase dotted 'i' o ka ia me ka Roma.Nolaila:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ka waiwai o `upper_i` ʻaneʻi nui ma luna o ka 'ōlelo' o ke kikokikona: ina mākou 'oe i loko o `en-US`, ka mea, e ia `"I"`, akā, inā ua' oe i loko o `tr_TR`, ka mea, e ia `"İ"`.
    /// `to_uppercase()` aole e lawe i kēia i loko o no, a pela:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// paa i nā 'ōlelo.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// E kaha makau i ina o ka waiwai o loko o ka ASCII laulā.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Hana i kope o ka waiwai i ka like o ka hihia kiʻekiʻe ASCII.
    ///
    /// Kuhi ʻia nā leka ASCII 'a' a i 'z' i 'A' a i 'Z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E ka UPPERCASE_OR i ka waiwai i loko o-wahi, e hoʻohana [`make_ascii_uppercase()`].
    ///
    /// E hoʻonui i nā huapalapala ASCII me ka hoʻohui ʻole i nā huapalapala ʻole ASCII, e hoʻohana iā [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Make i ke kope o ka waiwai i loko o kona ASCII haʻahaʻa hihia like paha.
    ///
    /// Kuhi ʻia nā leka ASCII 'A' a i 'Z' i 'a' a i 'z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E lowercase i ka waiwai i loko o-wahi, e hoʻohana [`make_ascii_lowercase()`].
    ///
    /// E lowercase ASCII huapalapala i hou i ka politika-ASCII huapalapala, e hoʻohana [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// E kaha makau i mea mau loina i ka ASCII hihia-insensitive ń.
    ///
    /// Kūlike ʻia me `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Hoʻololi i kēia ʻano i kāna ASCII hihia kiʻekiʻe i kūlike i ka wahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'a' a i 'z' i 'A' a i 'Z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou aʻe me ka ʻole o ka hoʻololi ʻana i kahi e kū nei, e hoʻohana iā [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Hoʻololi i kēia ʻano i kāna ASCII hihia haʻahaʻa e kū like ana ma kahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'A' a i 'Z' i 'a' a i 'z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou i hoʻemi ʻia me ka hoʻololi ʻole i kahi e kū nei, e hoʻohana iā [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII alphabetic ano:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', a i ʻole
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Nānā inā he ASCII huapalapala nui ke kumu kūʻai.
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII lowercase ano:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII alphanumeric ano:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', a i ʻole
    /// - U + 0061 'a' ..=U + 007A 'z', a
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII kekimala huahelu:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII hexadecimal huahelu:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', a i ʻole
    /// - U + 0041 'A' ..=U + 0046 'F', a
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII punctuation ano:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, a i ʻole
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, a
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, a i ʻole
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII Kimia ano:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII whitespace ano:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, a i ʻole U + 000D CARRIAGE RETURN.
    ///
    /// Rust hoʻohana i ka WhatWG Infra Koo ka [definition of ASCII whitespace][infra-aw].Aia nō kekahi mau 'ē aʻe wehewehe ma akea ana.
    /// No ka paha, [the POSIX locale][pct] nā U + 000B vertical uku pila like hoʻi me nā mea a pau me ka luna huapalapala, akā,-mai ka loa ia specification-[ka paʻamau rula no "field splitting" ma ka Bourne shell][bfs] E hoomanao i *wale* makahiki, papamoe uku pila, a LINE Feed like whitespace.
    ///
    ///
    /// Inā ʻoe e kākau nei i kahi papahana e hoʻoponopono ai i kahi faila faila e kū nei, e nānā i ka wehewehe o kēlā ʻano keokeo ma mua o ka hoʻohana ʻana i kēia hana.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// E kaha makau i ina o ka waiwai o ka ASCII hoʻoholo ano:
    /// U + 0000 NUL ..=U + 001F Mokuna SEPARATOR, a U + 007F kāpae i.
    /// Note e hapanui ASCII whitespace huapalapala i ka mana hoʻomalu ma huapalapala, akā, hookahi mea ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encodes he maka u32 waiwai like UTF-8 i loko o ka hoakakaʻai aooa, a laila, e huli hou i ka subslice o ka aooa? E paka me ka encoded ano.
///
///
/// Haʻalele `char::encode_utf8`, keia iaoia kekahi mea e paʻa ai codepoints ma ka surrogate laulā.
/// (Ke hana nei i kahi `char` i ka palena o UB.) Kūpono ka hopena [generalized UTF-8] akā ʻaʻole kūpono UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ina ka aooa mea,ʻaʻole nui nui iho la ia.
/// ʻO kahi pale pale o ka loa ʻehā ka nui e encode i kekahi `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Hoʻopili i kahi waiwai u32 maka e like me UTF-16 i loko o ka buffer `u16` i hāʻawi ʻia, a laila hoʻihoʻi i ka subslice o ka buffer i loaʻa ka ʻano encode.
///
///
/// ʻAʻole like me `char::encode_utf16`, lawelawe pū kēia hana i nā codepoints i ka palena o ka palena.
/// (E pili ana i ka `char` i loko o ka surrogate huahelu o UB.)
///
/// # Panics
///
/// Panics ina ka aooa mea,ʻaʻole nui nui iho la ia.
/// ʻO kahi pale pale o ka lōʻihi 2 ua lawa ka nui e encode i kekahi `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: ke nānā nei kēlā me kēia lima inā lawa nā ʻāpana e kākau ai i loko
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Ka BMP moe ma
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Kula hope Kekoa e uhaʻi ai i loko o surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}