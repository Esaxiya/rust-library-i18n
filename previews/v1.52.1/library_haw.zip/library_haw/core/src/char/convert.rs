//! Hoʻololi ʻano.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Hoʻohuli i `u32` i `char`.
///
/// Note mea a pau ['char`] mau mea i pololei ia [' u32`] s, a hiki e hoolei i kekahi me
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Naʻe, ka mea nana e hoole mea i oiaio: i nā mea a pau i pololei ia ['u32`] mau mea i pololei ia [' char`] mau.
/// `from_u32()` e hoʻihoʻi iā `None` inā ʻaʻole kūpono ke hoʻokomo i kahi [`char`].
///
/// No kahi mana palekana ʻole o kēia hana i nānā ʻole i kēia mau kaha, e nānā iā [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Ke hoʻihoʻi nei iā `None` ke ʻole ka hoʻokomo he [`char`] kūpono:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Hoʻololi i `u32` i `char`, me ka nānā ʻole i ka pono.
///
/// Note mea a pau ['char`] mau mea i pololei ia [' u32`] s, a hiki e hoolei i kekahi me
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Naʻe, ka mea nana e hoole mea i oiaio: i nā mea a pau i pololei ia ['u32`] mau mea i pololei ia [' char`] mau.
/// `from_u32_unchecked()` e nānā ʻole i kēia, a hoʻolei makapō iā [`char`], malia e hana ana i kahi kūpono ʻole.
///
///
/// # Safety
///
/// Palekana ʻole kēia hana, no ka mea hiki ke kūkulu i nā koina `char` kūpono ʻole.
///
/// No kahi mana palekana o kēia hana, e nānā i ka hana [`from_u32`].
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: pono i ka mea kelepona e hōʻoia i ka `i` he waiwai char kūpono.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Pio he [`char`] i loko o ka [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Pio he [`char`] i loko o ka [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ka Mike Char ua, i hoʻolei ai i ka waiwai o ke kivila wahi, a laila, 'Aʻohe-io i ka 64 iki.
        // E nānā iā [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Hoʻohuli i [`char`] i [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Hoʻolei ʻia ke char i ka waiwai o ke kuhi kuhi, a laila hoʻolōʻihi ʻia i 128 iki.
        // E nānā iā [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Palapala 'āina i ka byte ma 0x00 ..=0xFF i kahi `char` nona ke kiko kikoʻī i like ka waiwai, ma U + 0000 ..=U + 00FF.
///
/// Unicode ua papahana ia i keia kuleʻa decodes nāʻai me ka hoʻopā'ālua 'ia Iana kahea ISO-8859-1.
/// Kēia hoʻopā'ālua He hana maʻalahi me ka ASCII.
///
/// E hoʻomaopopo he ʻokoʻa kēia mai ISO/IEC 8859-1 aka
/// ISO 8859-1 (me hoʻokahi hyphen liʻiliʻi), e waiho ana i kekahi "blanks", nā helu byte i hāʻawi ʻole ʻia i kekahi ʻano.
/// Hāʻawi ʻo ISO-8859-1 (ka IANA hoʻokahi iā lākou i nā code control C0 a me C1.
///
/// Note i keia mea *i* okoa mai Windows-1252 'aka
/// ʻaoʻao code 1252, ʻo ia ka superset ISO/IEC 8859-1 e hāʻawi ana i kekahi (ʻaʻole āpau!) i nā hakahaka i nā kiko a me nā ʻano Lakina like ʻole.
///
/// E hookahuli ai i na mea hou, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, a me `windows-1252` nō a pau Iu no ka superset o Windows-1252 i hoopiha i ka laina i koena me ka like C0 a me C1 hooponopono ana nā loina.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Hoʻohuli i [`u8`] i [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ʻO kahi hemahema i hiki ke hoʻihoʻi ʻia i ka wā e ʻoki ana i kahi char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: hōʻoia ʻia he waiwai unicode kū kānāwai
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Ka hewaʻano hoʻi ka wā o ka huli ana mai u32 e Mike Char ke aloha.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Pio i ka huahelu i loko o ka hāʻawi radix i ka `char`.
///
/// A 'radix' ʻaneʻi ua kekahi manawa i kapaʻia he 'base'.
/// Kuhi kahi radix o ʻelua i kahi helu binary, kahi radix o ʻumi, decimal, a me kahi radix o ʻumikūmāono, hexadecimal, e hāʻawi i kekahi mau helu maʻamau.
///
/// Ākeʻakeʻa kumu radices i kākoʻo.
///
/// `from_digit()` E hoʻi `None` ina ka hoʻokomo o mea,ʻaʻole he huahelu i loko o ka haawi mai ai radix.
///
/// # Panics
///
/// Panics inā hāʻawi ʻia i kahi radix ʻoi aku ma mua o 36.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ʻO Decimal 11 kahi helu hoʻokahi ma ke kumu 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Ke hoʻihoʻi nei iā `None` ke ʻole he helu ke komo.
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Ke hele nei i kahi radix nui, e hoʻoulu ana i panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}