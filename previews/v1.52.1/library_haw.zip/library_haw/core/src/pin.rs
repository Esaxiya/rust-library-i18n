//! Nā ʻano i pin i ka ʻikepili i kona wahi i ka hoʻomanaʻo.
//!
//! He mea pono i kekahi manawa ke loaʻa nā mea i hōʻoia ʻole ʻia e neʻe, ma ke ʻano ʻaʻole e loli ko lākou kau ʻana i ka hoʻomanaʻo, a hiki ke hilinaʻi ʻia pēlā.
//! ʻO ke kumu hoʻohālikelike o kēlā ʻano hanana e kūkulu ana i nā hana kūʻē iā ia iho, ʻoiai ke neʻe nei i kahi mea me nā kuhi iā ia iho e hōʻino iā lākou, a he kumu ia no ka hana kūpono ʻole.
//!
//! Ma ka 'ilikai kiʻekiʻe, he [`Pin<P>`] e hōʻoiaʻiʻo ana i ka pointee o kekahi laʻau kuhikuhi type `P` mai i ka hale lio wahi ma ka hoomanao ana, ke ano, ka mea hiki ole ke naueue na wahi e ae, aʻaʻole hiki ke deallocated kona hoomanao ana a ka meaʻia, Nākulukulu nō.ʻLelo mākou ʻo ka pointee "pinned".Mea e oi maalea wā kūkā ana ano i hui pu iho pinned me ka 'ole-pinnedʻikepili;[see below](#projections-and-structural-pinning) no nā kikoʻī hou aʻe.
//!
//! Ma ka paʻamau, hiki ke hoʻoneʻe ʻia nā ʻano āpau ma Rust.
//! Rust E ho oku ui maalo ae a pau ano ma-waiwai, a me ka ho'ānoʻole akamai-laʻau kuhikuhiʻAno like me [`Box<T>`] a me `&mut T` ae ke kūapoʻana a me ka neʻe maila i nā loina ka mea, aia no iloko olaila: oe ke hoʻoneʻe mai o ka [`Box<T>`], a me 'oe ke hoʻohana [`mem::swap`].
//! [`Pin<P>`] wahī mai ka laʻau kuhikuhiʻano `P`, no laila, [`Pin`] '<' ['Box`]`<T>> `hana e like me ka maʻamau
//!
//! [`Box<T>`]: when a [`Pin`] ʻ <<[ʻĀ Box`] ʻ<T>> hāʻule ʻo ia, no laila hana i kāna ʻike, a loaʻa ka hoʻomanaʻo
//!
//! kuʻikahi.Pēlā nō, like ʻo [Pin]] <&mut T> ʻ e like me `&mut T`.Eia nō naʻe, ʻaʻole ʻae ʻo [`Pin<P>`] i nā mea kūʻai mai e loaʻa maoli iā [`Box<T>`] a i ʻole `&mut T` e hoʻopili i ka ʻikepili, e hōʻike nei ʻaʻole hiki iā ʻoe ke hoʻohana i nā hana e like me [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` pono iā `&mut T`, akā ʻaʻole hiki iā mākou ke kiʻi.
//!     // Paʻa mākou, ʻaʻole hiki iā mākou ke hoʻololi i nā ʻike o kēia mau kūmole.
//!     // Hiki iā mākou ke hoʻohana iā `Pin::get_unchecked_mut`, akā palekana ia no kahi kumu:
//!     // ʻaʻole ʻae ʻia mākou e hoʻohana ia no ka neʻe ʻana i nā mea mai ka `Pin`.
//! }
//! ```
//!
//! Pono ia e ʻōlelo hou ʻaʻole [`Pin<P>`]*hoʻololi* i ka ʻoiaʻiʻo o ka mea hoʻopili Rust e noʻonoʻo i nā ʻano neʻe like ʻole.[`mem::swap`] noho kāhea ʻia no kekahi `T`.Akā, pale ʻo [`Pin<P>`] i kekahi mau helu * (kuhikuhi ʻia e nā kuhikihi i ʻūlū ʻia i [`Pin<P>`]) mai ka neʻe ʻana e ka hiki ʻole ke kāhea i nā kiʻina e koi iā `&mut T` ma luna o lākou (e like me [`mem::swap`]).
//!
//! [`Pin<P>`] hiki ke hoʻohana 'e uhi i kekahi laʻau kuhikuhi type `P`, a me ka mea hana me [`Deref`] a me [`DerefMut`].A [`Pin<P>`] kahi e manaʻo ʻia ai ʻo `P: Deref` ma ke ʻano he "`P`-style pointer" i kahi `P::Target` i pin ʻia-no laila, he [`Pin`]`<`['Box`] ʻ<T>> ʻo ia kahi kuhikuhi i kahi `T` i pin ʻia, a me kahi [`Pin`]` <`['Rc`] ʻ<T>> 'O ka olua-manaoia laʻau kuhikuhi i ka pinned `T`.
//! No ka pololei, hilinaʻi ʻo [`Pin<P>`] i ka hoʻokō ʻana o [`Deref`] a me [`DerefMut`] ʻaʻole e neʻe i waho o kā lākou `self` parameter, a e hoʻihoʻi wale i kahi kuhikuhi i nā ʻike pinned ke kāhea ʻia lākou i kahi kuhikuhi kikoʻī.
//!
//! # `Unpin`
//!
//! Hiki ke hoʻoneʻe maʻamau i nā ʻano he nui, ʻoiai ke pine ʻia, no ka mea ʻaʻole lākou i ka hilinaʻi i ka loaʻa ʻana o kahi wahi paʻa.Hoʻopili kēia i nā ʻano kumu āpau (e like me [`bool`], [`i32`], a me nā kūmole) a me nā ʻano i loaʻa wale i kēia ʻano.ʻAno e nānā ʻole e pili ana i ka pinini ʻana i ka [`Unpin`] auto-trait, ka mea e kāpae i ka hopena o [`Pin<P>`].
//! No `T: Unpin`, [`Pin`] ʻ <<[`Box`] ʻ<T>> `a me [`Box<T>`] hana like, e like me [` Pin`]`<&mut T>` a me `&mut T`.
//!
//! E hoʻomaopopo wale i ka pinning a me [`Unpin`] e hoʻopili wale ana i ka X-`P::Target` kiko kiko, ʻaʻole ka ʻano kuhikuhi `P` ponoʻī i wahī ʻia i [`Pin<P>`].ʻO kahi laʻana, inā [`Box<T>`] a [`Unpin`] paha ʻaʻole hopena i ka lawena o [`Pin`]`<`['Box`] ʻ<T>>`(ma aneʻi, ʻo `T` ke kiko kuhikuhi-i ke ʻano).
//!
//! # ʻO kahi laʻana: nā mea kuhikuhi ponoʻī
//!
//! Ma mua o ka hele ʻana i nā kikoʻī hou aku e wehewehe i nā hōʻoia a me nā koho i pili me `Pin<T>`, kūkākūkā mākou i kekahi mau laʻana no ka pehea e hoʻohana ai ia.
//! Aloha iā [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // ʻO kēia kahi mea kuhikuhi ponoʻī no ka mea ke kuhikuhi nei ka ʻāpana slice i ka ʻikepili.
//! // ʻAʻole hiki iā mākou ke hoʻomaopopo i ka mea hoʻopili e pili ana i kēlā me kahi kuhikuhi maʻamau, ʻoiai ʻaʻole hiki ke wehewehe ʻia kēia ʻano me nā rula hōʻaiʻē maʻamau.
//! //
//! // Ma ia pōʻaiapili, ua ho ohana i ka maka laʻau kuhikuhi, aole nae kekahi i ua ike ole ia e Yard, me mākou i ike ia ka kuhikuhi ana ma ke kaula.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // E hoʻopaʻa i nā ikepiliʻoniʻole ka wā o ka papa hoike, ua waiho ia i loko o ka puu, kahi ia e noho ai no ka wa e ola ana o ke kiʻi, a me ka mea wale ala e hoʻohana ka mea, e ia ma ka laʻau kuhikuhi ia ia.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // hana wale mākou i ka kuhikuhi ma kahi o ka ʻikepili ma kahi ʻē inā ua neʻe mua ia ma mua o kā mākou hoʻomaka
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // ua ike no keia mea pakele no ka mea, modifying i ka mahinaʻai,ʻaʻole ia e hoʻoneʻe i ka pau struct
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ka laʻau kuhikuhi E kuhikuhi i ka pololei wahi, no laila, lōʻihi e like me ka struct i hoonaue ole iaʻi.
//! //
//! // I kēia manawa, manuahi mākou e hoʻoneʻe i ka mea kuhikuhi.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // ʻOiai ʻaʻole hoʻokō kā mākou ʻano iā Unpin, ʻaʻole e hōʻuluʻulu kēia:
//! // let mut new_unmove= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Laʻana: papa inoa hoʻopili pālua i hoʻopili ʻia
//!
//! I loko o kahi papa inoa hoʻopili pālua i hoʻopili ʻia, ʻaʻole hoʻokaʻawale ka hōʻiliʻili i ka hoʻomanaʻo no nā mea ponoʻī.
//! Mālama ʻia ka hoʻokaʻawale e nā mea kūʻai aku, a hiki i nā mea ke noho ma kahi papa stack e ola ana ka pōkole ma mua o ka hōʻiliʻili.
//!
//! E hana i kēia hana, i kēlā me kēia meʻe i kuhikuhi i kona mua a me ka hope o ka papa inoa.Hiki ke hoʻohui wale ʻia nā mea ke hoʻopili ʻia lākou, no ka mea, ʻo ka neʻe ʻana o nā ʻaoʻao a puni e hōʻoia ʻole i nā kuhikuhi.Eia kekahi, ʻo ka hoʻokō ʻana o [`Drop`] o kahi mea papa inoa papa inoa e hoʻopili i nā kuhi o kona mua a me ka hope e wehe iā ia iho mai ka papa inoa.
//!
//! Ma ke ʻano koʻikoʻi, hiki iā mākou ke hilinaʻi iā [`drop`] i kāhea ʻia.Inā hiki ke kuapo ʻia kahi mea a i ʻole hoʻokahuli ʻia me ka ʻole o ke kāhea ʻana iā [`drop`], e lilo nā kuhi kuhi i loko ona mai nā mea e pili kokoke ana i mea kūpono ʻole, kahi e haki ai i ka ʻikepili.
//!
//! No laila, hele pū ka pinning me kahi [`drop`]-ʻaelike pili.
//!
//! # `Drop` guarantee
//!
//! Ke kumu o ka pinning mea e e hiki ke hilinai aku ma luna o ka hoʻokomo 'ana o kekahi' ike i loko o iaiyoe.
//! E hana i kēia hana, ʻaʻole ka hoʻoneʻe i ka ʻikepili i kapu ʻia;deallocating, repurposing, a ano e ae paha invalidating ka iaiyoe hoʻohana e hoahu i kaʻikepili ua kapu, no hoi.
//! Concretely, no ka ʻikepili pinin e pono ʻoe e mālama i ka invariant e *ʻole e hoʻopau ʻia a hoʻomanaʻo hou ʻole ʻia kāna hoʻomanaʻo mai ka manawa e pinia ai a hiki i ka wā e kapa ʻia ai ʻo [`drop`]*.Wale koke [`drop`] hoike a panics, i ka hoomanao ana i ke hoʻohana hou 'ia.
//!
//! Paʻa hiki ia "invalidated" ma deallocation, akā, no hoi ma ke kūapoʻana i ka [`Some(v)`] ma [`None`], a kahea [`Vec::set_len`] i "kill" kekahi kumu aku o ka vector.Hiki iā ia ke repurposed ma o ka hoʻohana ʻana iā [`ptr::write`] e hoʻokau iā ia me ke kāhea ʻole ʻana i ka mea luku.ʻAʻohe o kēia e ʻae ʻia no ka ʻikepili pinin me ke kāhea ʻole ʻana iā [`drop`].
//!
//! ʻO kēia nō ke ʻano o ka hōʻoia e pono ke hana pololei i ka papa inoa hoʻopili hoʻopili ʻia.
//!
//! E nānā i ka ʻole o kēia ʻōlelo hoʻohiki *ʻaʻole* manaʻo ʻole e kulu ka hoʻomanaʻo.ʻAno maikaʻi inā ʻaʻole e kāhea iā [`drop`] ma kahi mea i pinned (e laʻa, hiki iā ʻoe ke kāhea iā [`mem::forget`] ma kahi [`Pin`]`<`[Box`] '<T>>`).I ka laʻana o ka papa inoa hoʻopili pālua, e noho wale kēlā mea i ka papa inoa.Eia naʻe ʻaʻole ʻoe e manuahi a hoʻohana hou paha i ka waihona *me ke kāhea ʻole ʻana iā [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Inā hoʻohana kāu ʻano i ka pinini (e like me nā hiʻohiʻona ʻelua ma luna), pono ʻoe e akahele i ka hoʻokō ʻana iā [`Drop`].Lawe ka hana [`drop`] iā `&mut self`, akā kāhea ʻia kēia *ʻoiai inā i pin ʻia ʻia kāu ʻano ma mua*!Me he mea lā i kapa ʻia ka mea hoʻohui [`Pin::get_unchecked_mut`].
//!
//! Ua hiki loa i ka pilikia ma ka palekana kivila, no ka hoʻokō 'ia kekahi' ano e nui ma luna o pinning pono unsafe kivila, akā, e makaala i ka hoʻoholo 'ana i e hoʻohana ana i pinning i loko o kou' ano (no ka laʻana ma ka hoʻokō i kekahi hana ma luna o ['Pin`]' <&ka hoʻoponopono '>`a ['Pin`]' <&mut iho>`) he hopena no kou [`Drop`] manaʻo like hoʻi: inā he hehee ai o kou 'ano hiki i ua pinned, e pono e hana [`Drop`] like implicitly lawe [`Pin`]' <&mut Iho> `.
//!
//!
//! ʻO kahi laʻana, hiki iā ʻoe ke hoʻokomo iā `Drop` penei:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ua maikaʻi no ka mea ʻike mākou ʻaʻole hoʻohana hou ʻia kēia waiwai ma hope o ka waiho ʻia ʻana.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Hele ma aneʻi ke code kulu kikoʻī.
//!         }
//!     }
//! }
//! ```
//!
//! Ka papa `inner_drop` i ke 'ano i [`drop`]*e* i, no laila, i kēia meaʻoiaʻiʻo ia oe e ole accidentally hoʻohana `self`/`this` ma ke ala i mea i kue me pinning.
//!
//! Eia kekahi, inā ʻo `#[repr(packed)]` kāu ʻano, e neʻe a maʻalahi ka mea hoʻopili i nā pā a hiki ke hoʻokuʻu iā lākou.Ia paha i hana ia no ka mahinaʻai e hiki mai ana i ka e lawa ua kūponoʻia.A ʻo kahi hopena, ʻaʻole hiki iā ʻoe ke hoʻohana i ka pinna ʻana me kahi ʻano `#[repr(packed)]`.
//!
//! # Nā Papahana a me nā Pining Structural
//!
//! Ke hana nei me nā kaula i kui ʻia, e kupu ana ka nīnau pehea e hiki ai i kekahi ke komo i nā māla o ia mea i loko o ke ʻano hana e lawe wale ai [Pin]] <&mut Struct> `.
//! Ke mau kokoke mea e kahakaha iho e kokua mai epekema (no laila, i kapaʻia *nā wānana waiwai*) e huli [`Pin`] '<&mut Struct>' i loko o ka pili a hiki i ke kula, akā, mea 'ano e ia olua i?Ua mea ['Pin`]' <&mut Field>`paha `&mut Field`?
//! Kū aʻe ka nīnau like me nā kahua o `enum`, a ke noʻonoʻo pū nei hoʻi i nā ʻano container/wrapper e like me [`Vec<T>`], [`Box<T>`], a i ʻole [`RefCell<T>`].
//! (Pili kēia nīnau i nā kūmole pili ʻelua a me nā kaʻana like, hoʻohana wale mākou i ka hihia maʻamau o nā kūmole hiki ke hoʻololi ʻia ma aneʻi no ke kiʻi.)
//!
//! ʻIke ʻia aia ia i ka mea kākau o ka ʻikepili ʻikepili e hoʻoholo inā hoʻohuli ʻia ke koho pinned no kekahi kahua ["Pin`]"<&mut Struct>`i loko o"Pin`] "<&mut Field>` a i ʻole `&mut Field`.Eia nō naʻe kekahi mau mea keakea, a ʻo ka mea nui i kaupalena ʻia ʻo *kūlike ʻole*:
//! hiki i kēlā me kēia māla ke *kuhi ʻia* i kahi kuhikuhi pinned,*a i ʻole* ua hoʻoneʻe ʻia ka pinning ma ke ʻāpana o ke wānana.
//! Inā hana ʻia nā mea ʻelua no ka pā like, he unsound paha ia.
//!
//! E like me ka mea kākau o ka 'ike' ole 'oe kiʻi i hooholo ai no kēlā me kēia mahinaʻai, ina pinning "propagates" a hiki i keia kahua paha,ʻaʻole.
//! Kāhea ʻia ka pinning e hoʻolaha ana he "structural", no ka mea e ukali ia i ke ʻano o ke ʻano.
//! I nā ʻāpana aʻe, wehewehe mākou i nā manaʻo e pono ai e koho ʻia.
//!
//! ## ʻAʻole Pinning * kumu no `field`
//!
//! A kohu mea, ee-intuitive ole e i ke kahua o ka pinned struct paha pinned, akā, i ka mea nae i ka easiest koho: ina he ['Pin`]' <&mut Field> 'ua ike ole e hana, i ka mea e hiki ke hele hewa!No laila, inā hoʻoholo ʻoe ʻaʻohe pinna kūkulu o kekahi kahua, ʻo nā mea āpau āu e ʻike ai ʻaʻole loa ʻoe e hana i kahi kuhikuhi pin i kēlā kahua.
//!
//! Loaʻa paha i kahi pā kula me ka ʻole o ka pinning struktural i kahi hana wānana e huli ai [`Pin`]`<&mut Struct>`i `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Maikaʻi kēia no ka mea ʻaʻole manaʻo ʻia ʻo `field` i pin ʻia.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! E hiki no hoi `impl Unpin for Struct`*a hiki ina* i ke 'ano o `field` mea ole [`Unpin`].He aha eʻano manaʻo e pili ana i pinning mea i pili ka wāʻaʻohe ['Pin`]' <&mut Field> ua loa hana`.
//!
//! ## ʻO Pinning * kahi hana no `field`
//!
//! ʻO ka koho ʻē aʻe e hoʻoholo i ka pinning "structural" no `field`, ʻo ia hoʻi inā i pin ʻia ke kumu a laila ka pā.
//!
//! ʻAe kēia i ke kākau ʻana i kahi wanana e hana i kahi [`Pin`]`<&mut Field>`, no laila ke hōʻike nei ua pili ʻia ke kahua:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ua maikaʻi kēia no ka mea ua pin ʻia ʻo `field` ke aia ʻo `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Eia nō naʻe, hele mai ka pinning hanganga me kekahi mau koi hou aku:
//!
//! 1. Ke struct pono wale nō e [`Unpin`] ina mea a pau i ka mall kihapai i [`Unpin`].ʻO kēia ka paʻamau, akā ʻo [`Unpin`] kahi palekana trait, no laila ʻo ka mea kākau o ka hana ʻo ia kou kuleana *ʻaʻole* e hoʻohui i kahi mea e like me `impl<T> Unpin for Struct<T>`.
//! (E hoʻomaopopo i ka hoʻohui ʻana i kahi hana wānana e koi ai i kahi code palekana, no laila ʻo ka ʻoiaʻiʻo ʻo [`Unpin`] kahi palekana trait ʻaʻole ia e uhaʻi i ke kumumanaʻo āu e hopohopo wale ai no kekahi o kēia inā ʻoe e hoʻohana i `unsafe`.)
//! 2. Ke destructor o ka struct pono ole hoʻoneʻe mall kihapai mai o kona loulou.ʻO kēia ke kiko kikoʻī i hāpai ʻia i ka [previous section][drop-impl]: `drop` e lawe iā `&mut self`, akā ʻo ke kumu (a no laila kona mau māla) i pinin ma mua.
//!     Oe i ke kumu hoʻomalu ia oe e ole hoʻoneʻe i ka mahinaʻai ma loko o kou [`Drop`] manaʻo.
//!     Ma kekahi, e like me ka wehewehe mua, keia mea i kou struct pono *ole* e `#[repr(packed)]`.
//!     E nānā i ka māhele no ana e kākau [`drop`] ma ke ala i ka compiler ke kōkuaʻoe i accidentally uhai pinning.
//! 3. Pono ʻoe e mālama pono iā [`Drop` guarantee][drop-guarantee]:
//!     i ka pine o kāu kumu, ʻaʻole hoʻomanaʻo ʻia ka memo e loaʻa ana i ka ʻike me ka ʻole o ke kāhea ʻana i nā mea hōʻino o ka ʻike.
//!     Hiki ke maʻalahi kēia, e like me ka mea i hōʻike ʻia e [`VecDeque<T>`]: hiki i ka mea hōʻino o [`VecDeque<T>`] ke kāhea iā [`drop`] ma nā mea āpau inā kekahi o nā mea hōʻino panics.Hōʻino kēia i ka hōʻoia [`Drop`], no ka mea hiki iā ia ke alakaʻi i nā mea i hana ʻia me ka ʻole e kāhea ʻia kā lākou mea hōʻino.(ʻAʻohe o X proxing pinning wanana, no laila ʻaʻole kumu kēia unsoundness.)
//! 4. Oe pono e kaumaha i kekahi'ē aʻe hana i hiki ke alakai i kaʻikepili ua hoʻoneʻe mai o ka mahinaʻai mall ka wā i kou 'ano ua pinned.ʻO kahi laʻana, inā loaʻa ka [`Option<T>`] i ka mea kūkulu a aia kahi hana like 'like' me ka ʻano `fn(Pin<&mut Struct<T>>) -> Option<T>`, hiki ke hoʻohana i kēlā hana e hoʻoneʻe i kahi `T` mai kahi `Struct<T>` i hoʻopili ʻia-ʻo ia hoʻi ʻaʻole hiki i ka pinning ke hana no ka pā e paʻa ana i kēia. ʻikepili.
//!
//!     No ka hou luna 'mamuli o ka neʻe' ike mai o ka pinned 'ano, ke manao wale ina [`RefCell<T>`] i kekahi iaoia `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     A laila hiki iā mākou ke hana i kēia:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     He pōʻino kēia, ʻo ia hoʻi hiki iā mākou ke pine mua i ka ʻike o ka [`RefCell<T>`] (e hoʻohana ana i `RefCell::get_pin_mut`) a laila neʻe i kēlā ʻike i ka hoʻohana ʻana i ka kūmole hiki ke loaʻa iā mākou ma hope.
//!
//! ## Examples
//!
//! No kahi ʻano e like me [`Vec<T>`], hiki ke kūpono i nā hiki āpau (pinning hanganga a i ʻole).
//! Hiki i kahi [`Vec<T>`] me ke kui ʻana i ke ʻano ke loaʻa nā ʻano `get_pin`/`get_pin_mut` e kiʻi ai i nā kuhikuhi pinned i nā element.Eia naʻe, ʻaʻole hiki *hiki* ke kāhea iā [`pop`][Vec::pop] ma kahi [`Vec<T>`] i pin ʻia no ka mea e hoʻoneʻe i nā mea (hoʻopili ʻia) i nā ʻike!Aole hiki ia ae [`push`][Vec::push], a ke reallocate, a pela no hoi hoʻoneʻe i nā mea.
//!
//! A [`Vec<T>`] me ka ʻole o ka pinest struktural hiki iā `impl<T> Unpin for Vec<T>`, no ka mea ʻaʻole i pin ʻia nā ʻike a maikaʻi ka [`Vec<T>`] pono me ka neʻe pū ʻia.
//! Ma ia wahi pinning pono i ole ia ma ka vector ma nā mea a pau.
//!
//! I ka hale waihona puke maʻamau, ʻaʻohe o ka pinest struktural nā ʻano kuhikuhi, a no laila ʻaʻole lākou e hāʻawi i ka pā ʻana i nā pine.ʻO kēia ke kumu e paʻa ai ʻo `Box<T>: Unpin` no `T` āpau.
//! Ka mea, i hoohalike e hana i kēia no ka laʻau kuhikuhiʻAno, no ka mea, e neʻe i ka `Box<T>` aʻole ole nae hoʻoneʻe i ka `T`: ka [`Box<T>`] hiki e ke alalai ole hoʻoneʻe (aka `Unpin`) a hiki ina ka `T` mea ole.I ka mea, a hiki [`Pin`] '<' ['Box`]`<T>> `a [` Pin`]`<&mut T>` mau [`Unpin`] iā lākou iho, no ke kumu like: ua kī ʻia ko lākou mau ʻike (ka `T`), akā hiki ke hoʻoneʻe ʻia nā kuhi iho me ka neʻe ʻole o ka ʻikepili i pin ʻia.
//! No [`Box<T>`] a me [`Pin`] ʻ <<[ʻ Box`] ʻ<T>>`, inā pinni ka ʻike ʻike kūʻokoʻa ʻia ia inā paha i pin ʻia ka pointer, ʻo ia hoʻi ka pinning ʻaʻole *ʻaʻole* hanganga.
//!
//! I ka hoʻokō 'ia' he [`Future`] combinator, oe e ana pono mall pinning no ka pūnana futures, e like me kou pono no ka pinned Nā Kūmole ia ia, e kapa aku [`poll`].
//! Akā, inā kou combinator kekahi i kekahi'ē aʻe ikepili i mea ole pono ia e pinned, e hiki e ia mau kula i mall, a ma keia hope aku ka 'elele i keʻeʻe ia me ka mutable maopopo kahi hiki ia oe wale i [' Pin`] '<&mut iho>`(ia e like me kāu [`poll`] hoʻokō pono).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Kahi kuhikuhi kuhikuhi.
///
/// He He wrapper puni ke ano o ka laʻau kuhikuhi aʻo ia laʻau kuhikuhi "pin" kona waiwai ma ka wahi, hikiʻole i ka waiwai i maopopo nä haumäna ma ia laʻau kuhikuhi mai ka neʻe ke ole ia mea lapaʻau [`Unpin`].
///
///
/// *E ʻike i ka palapala [`pin` module] no ka wehewehe o ka pinini ʻana.*
///
/// [`pin` module]: self
///
// Note: ka `Clone` loaa ke kumu unsoundness like ia ka hiki ke hoʻokō i lalo
// `Clone` no nā kūmole hiki ke hoʻololi.
// E ʻike iā <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> no nā kikoʻī hou aʻe.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// ʻAʻole i lawe ʻia nā hoʻokō aʻe i mea e hōʻalo ai i nā pilikia maikaʻi.
// `&self.pointer` pono ʻole ke kiʻi ʻia i nā hoʻokō trait i hilinaʻi ʻole ʻia.
//
// E ʻike iā <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> no nā kikoʻī hou aʻe.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Kūkulu i kahi `Pin<P>` hou a puni kahi kuhikuhi i kekahi ʻikepili o kahi ʻano e hoʻokō iā [`Unpin`].
    ///
    /// ʻAʻole like me `Pin::new_unchecked`, palekana kēia ʻano ma muli o ka kuhikuhi ʻana o ka pointer `P` i kahi ʻano [`Unpin`], kahi e hoʻopau ai i nā hōʻoia pin.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: ʻo ka waiwai i kuhikuhi ʻia ʻo `Unpin`, a no laila ʻaʻohe koi
        // puni pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Wehe i kēia `Pin<P>` e hoʻihoʻi nei i ka kuhikuhi kuhikuhi.
    ///
    /// Pono kēia i ka ʻikepili i loko o kēia `Pin` ʻo [`Unpin`] i hiki iā mākou ke nānā ʻole i nā invariants pinning ke wehe ia.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Kükulu i ka hou `Pin<P>` puni i ka olua i kekahi 'ike o ke' ano i hiki 'ole paha e hoʻokō i `Unpin`.
    ///
    /// Inā makemake ʻo `pointer` i kahi ʻano `Unpin`, pono e hoʻohana ʻo `Pin::new` ma kahi.
    ///
    /// # Safety
    ///
    /// Kēia constructor He unsafe no ka mea, ua hiki ole kumu hoʻomalu i nā ikepili kuhikuhi ia ma `pointer` ua pinned, la me ka manao ana e ole ai ka 'ikepili e hoʻoneʻe ai kona pūnaewele invalidated a iaʻia, Nākulukulu nō.
    /// Inā ʻaʻole e hōʻoia ka `Pin<P>` i kūkulu ʻia i ka helu `P` i kuhikuhi ʻia, he hewa ia o ka ʻaelike API a alakaʻi ʻia i ka lawehala ʻole i nā hana ma hope (safe).
    ///
    /// Ma ka hoʻohana ʻana i kēia hana, ke hana nei ʻoe i kahi promise e pili ana i nā hoʻokō `P::Deref` a me `P::DerefMut`, inā aia lākou.
    /// Loa importantly, ka mea pono ole hoʻoneʻe mai o ko lākou `self` manaʻo hoʻopiʻi kū'ē: `Pin::as_mut` a me `Pin::as_ref` e kāhea `DerefMut::deref_mut` a me `Deref::deref`*ma ka pinned laʻau kuhikuhi* a manaʻo i kēia mau kiʻina hana e kākoʻo i ka pinning invariants.
    /// Eia kekahi, ma ke kāhea ʻana i kēia hana iā ʻoe promise ʻaʻole e hoʻoneʻe hou ʻia ke kūmole `P`.i kikoʻī, ʻaʻole pono e loaʻa kahi `&mut P::Target` a laila neʻe i waho o kēlā kūmole (e hoʻohana ana, no ka laʻana [`mem::swap`]).
    ///
    ///
    /// No ka laʻana, kahea `Pin::new_unchecked` ma ka `&'a mut T` mea unsafe no ka mea, oiai oe e hiki ke kui ia no ka haawiia mai wa e ola ana `'a`, oe i ole hooponopono no paha ka mea, ua mālama pinned koke `'a` welau:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // ʻO kēia ke kumu o ka pointee `a` ʻaʻole hiki ke neʻe hou.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Ua loli ka helu wahi o `a` i ka slot b stack, no laila ua hoʻoneʻe ʻia ʻo `a` ʻoiai ua hoʻokui mua mākou iā ia.Ua uhaʻi mākou i ka ʻaelike API pinning.
    /////
    /// }
    /// ```
    ///
    /// A kumukuai, koke pinned, pono ke koe pinned mau loa (ole kona 'ano mea lapaʻau `Unpin`).
    ///
    /// Pēlā nō, ʻaʻole palekana ʻo ke kāhea ʻana iā `Pin::new_unchecked` ma kahi `Rc<T>` no ka mea aia paha he mau ʻauhau i ka ʻikepili like i pili ʻole i nā kaohi ʻana.
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // ʻO kēia ke kumu ʻaʻole hiki i ka pointee ke neʻe hou.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // I kēia manawa, inā ʻo `x` wale nō ke kūmole, loaʻa iā mākou kahi kuhikuhi e hiki ai ke hoʻololi i ka ʻikepili a mākou i hoʻopaʻa ai ma luna, kahi e hiki ai iā mākou ke hoʻohana e hoʻoneʻe iā ia e like me kā mākou i ʻike ai ma ka hiʻohiʻona mua.
    ///     // Ua uhaʻi mākou i ka ʻaelike API pinning.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Loaʻa i kahi kuhikuhi i pinned ʻia mai kēia kuhikuhi kuhikuhi pinned.
    ///
    /// He hana maʻamau kēia e hele mai `&Pin<Pointer<T>>` a i `Pin<&T>`.
    /// Palekana ia no ka mea, ma ke ʻāpana o ka ʻaelike o `Pin::new_unchecked`, ʻaʻole hiki ke neʻe ke pointee ma hope o ka hoʻokumu ʻia ʻana o `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Hoʻoholo pū ʻia nā hoʻokō o `Pointer::Deref` e ka ʻaelike a `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: e nānā i nā palapala e pili ana i kēia hana
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Wehe i kēia `Pin<P>` e hoʻihoʻi nei i ka kuhikuhi kuhikuhi.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana.Pono ʻoe e hōʻoia e hoʻomau ʻoe i ka mālama ʻana i ka pointer `P` e like me ka pine ma hope o kou kāhea ʻana i kēia hana, i hiki ai ke mālama ʻia nā invariants ma ka `Pin` ʻano.
    /// Inā ka kivila ka hoʻohana 'ana i ke kūpono `P` aʻole e hoʻomau i ka malama i ka pinning invariants i mea he' aʻe 'ana o ka API aelike, a ke alakai i undefined hana ma hope (safe) hana.
    ///
    ///
    /// Inā ʻo [`Unpin`] ka ʻike ma lalo, e hoʻohana ʻo [`Pin::into_inner`] ma kahi.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Loaʻa i kahi kūmole hiki ke hoʻololi ʻia mai kēia pointer pinned.
    ///
    /// He hana maʻamau kēia e hele mai `&mut Pin<Pointer<T>>` a i `Pin<&mut T>`.
    /// Palekana ia no ka mea, ma ke ʻāpana o ka ʻaelike o `Pin::new_unchecked`, ʻaʻole hiki ke neʻe ke pointee ma hope o ka hoʻokumu ʻia ʻana o `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Hoʻoholo pū ʻia nā hoʻokō o `Pointer::DerefMut` e ka ʻaelike a `Pin::new_unchecked`.
    ///
    /// He mea pono kēia hana ke hana i nā kāhea he nui i nā hana e hoʻopau i ka ʻano pinned.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // hana i kekahi mea
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` i pau ai `self`, no laila, reborrow ka `Pin<&mut Self>` Via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: e nānā i nā palapala e pili ana i kēia hana
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Hāʻawi i kahi waiwai hou i ka hoʻomanaʻo ma hope o ke kuhikuhi pin pin.
    ///
    /// Hoʻopili ʻia kēia i ka ʻikepili, akā maikaʻi ia: holo ʻia kāna mea hōʻemi ma mua o ka hoʻokahuli ʻia ʻana, no laila ʻaʻohe mea e haki ai ka hōʻoia pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Kūkulu i kahi pine hou ma ka palapala ʻana i ka waiwai o loko.
    ///
    /// ʻO kahi laʻana, inā makemake ʻoe e kiʻi i kahi `Pin` o kahi māla o kekahi mea, hiki iā ʻoe ke hoʻohana i kēia e kiʻi i ke kahua i hoʻokahi laina o ke code.
    /// Eia nō naʻe, aia kekahi mau gotchas me kēia "pinning projections";
    /// ike i ka [`pin` module] nā moʻolelo no ka hou lāliʻi ma luna o ia kumuhana.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana.
    /// Pono ʻoe e hōʻoia i ka neʻe ʻole o ka ʻikepili āu e hoʻi ai inā ʻaʻole neʻe ke kumukūʻai hoʻopaʻapaʻa (ʻo kahi laʻana, no ka mea ʻo ia kekahi o nā kahua o ia waiwai), a mai hele pū hoʻi ʻoe mai ka paio āu e loaʻa ai ka hana o loko.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // Ka maluhia: o ka maluhia aelike no `new_unchecked` pono e
        // kokuaia oia ma ka Caller.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Loaʻa i kahi kūmole i kaʻana like ʻia mai kahi pin.
    ///
    /// He maluhia no ka mea, mea,ʻaʻole e hiki i ka hoʻoneʻe mai o ka kaʻana maopopo kahi.
    /// Me he mea lā aia kekahi pilikia ma aneʻi me ka hoʻololi o loko: ʻo ka ʻoiaʻiʻo, hiki * hiki ke hoʻoneʻe i kahi `T` mai kahi `&RefCell<T>`.
    /// Eia nō naʻe, ʻaʻole ia he pilikia inā ʻaʻole kahi `Pin<&T>` e kuhikuhi nei i ka ʻikepili like, a ʻaʻole ʻo `RefCell<T>` e ʻae iā ʻoe e hana i kahi kuhikuhi pin i kāna ʻike.
    ///
    /// E ʻike i ke kūkā kamaʻilio ma ["pinning projections"] no nā kikoʻī hou aʻe.
    ///
    /// Note: Hoʻokomo pū ʻo `Pin` iā `Deref` i ka pahu hopu, hiki ke hoʻohana ʻia e komo ai i ka waiwai o loko.
    /// Eia nō naʻe, hāʻawi wale ʻo `Deref` i kahi kūmole e ola nei no ka lōʻihi o ka hōʻaiʻē o `Pin`, ʻaʻole i ke ola o `Pin` ponoʻī.
    /// ʻAe kēia hana i ka hoʻohuli ʻana i ka `Pin` i kahi kūmole me ke ola like e like me ka `Pin` kumu.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Hoʻololi i kēia `Pin<&mut T>` i `Pin<&T>` me ke ola like.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Loaʻa i kahi kuhikuhi hiki ke hoʻololi i ka ʻikepili i loko o kēia `Pin`.
    ///
    /// Pono kēia i ka ʻikepili i loko o kēia `Pin` ʻo `Unpin`.
    ///
    /// Note: Hoʻokomo pū ʻo `Pin` iā `DerefMut` i ka ʻikepili, hiki ke hoʻohana ʻia e kiʻi ai i ka waiwai o loko.
    /// Eia naʻe, `DerefMut` wale hoakaka i maopopo kahi e ola ana no ka like loa me ka nonoi ana o ka `Pin`, i ka wa e ola ana o ka `Pin` iho.
    ///
    /// ʻAe kēia hana i ka hoʻohuli ʻana i ka `Pin` i kahi kūmole me ke ola like e like me ka `Pin` kumu.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Loaʻa i kahi kuhikuhi hiki ke hoʻololi i ka ʻikepili i loko o kēia `Pin`.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana.
    /// Pono ʻoe e hoʻohiki ʻaʻole loa ʻoe e neʻe i ka ʻikepili mai kahi kuhikuhi hiki ke loaʻa iā ʻoe ke kāhea ʻoe i kēia hana, i hiki ai ke mālama ʻia nā invariants ma ka `Pin` ʻano.
    ///
    ///
    /// Inā ʻo `Unpin` ka ʻike ma lalo, e hoʻohana ʻo `Pin::get_mut` ma kahi.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Kūkulu i kahi pine hou ma ka palapala ʻana i ka waiwai o loko.
    ///
    /// ʻO kahi laʻana, inā makemake ʻoe e kiʻi i kahi `Pin` o kahi māla o kekahi mea, hiki iā ʻoe ke hoʻohana i kēia e kiʻi i ke kahua i hoʻokahi laina o ke code.
    /// Eia nō naʻe, aia kekahi mau gotchas me kēia "pinning projections";
    /// ike i ka [`pin` module] nā moʻolelo no ka hou lāliʻi ma luna o ia kumuhana.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana.
    /// Pono ʻoe e hōʻoia i ka neʻe ʻole o ka ʻikepili āu e hoʻi ai inā ʻaʻole neʻe ke kumukūʻai hoʻopaʻapaʻa (ʻo kahi laʻana, no ka mea ʻo ia kekahi o nā kahua o ia waiwai), a mai hele pū hoʻi ʻoe mai ka paio āu e loaʻa ai ka hana o loko.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: ke kuleana o ka mea kāhea no ka neʻe ʻole o ka
        // waiwai mai loko mai o kēia kūmole.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: e like me ka waiwai o `this` hoʻohiki ʻole ʻia e loaʻa
        // ua hoʻoneʻe ʻia, palekana kēia kāhea iā `new_unchecked`.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// E kiʻi i kahi kuhikuhi pin pin mai kahi kūmole kūpaʻa.
    ///
    /// Palekana kēia, no ka mea, hōʻaiʻē ʻo `T` no ke ola `'static`, ʻaʻole pau.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: ʻO ka 'static loan e hōʻoia i ka ʻikepili ʻaʻole
        // moved/invalidated a hāʻule i lalo (ʻaʻole loa).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// E kiʻi i kahi kuhikuhi e hiki ai ke hoʻololi ʻia.
    ///
    /// Palekana kēia, no ka mea, hōʻaiʻē ʻo `T` no ke ola `'static`, ʻaʻole pau.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: ʻO ka 'static loan e hōʻoia i ka ʻikepili ʻaʻole
        // moved/invalidated a hāʻule i lalo (ʻaʻole loa).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ʻO kēia ka manaʻo o kekahi impl o `CoerceUnsized` e ʻae i ka coercing mai
// kahi ʻano e hoʻopili `Deref<Target=impl !Unpin>` i kahi ʻano e hoʻopili `Deref<Target=Unpin>` unsound.
// Kūpono ʻole paha kēlā ʻano impl no nā kumu ʻē aʻe, akā naʻe, no laila pono mākou e akahele ʻaʻole e ʻae i kēlā mau impls e pae i std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}