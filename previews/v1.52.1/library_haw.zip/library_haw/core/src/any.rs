//! Hoʻokomo kēia module i ka `Any` trait, i hiki ai i ka kikokiko ʻana i nā ʻano `'static` ma o ka hōʻike manawa.
//!
//! `Any` hiki ke hoʻohana iā ia iho e kiʻi i kahi `TypeId`, a ʻoi aku kona mau hiʻohiʻona ke hoʻohana ʻia ma ke ʻano he trait mea.
//! Me `&dyn Any` (ka aie trait mea), ka mea, ua ka `is` a me `downcast_ref` ki ina hana like, e ho'āʻo ina ka kakauiaʻi maluna waiwai mea o ka hāʻawi 'ano, a me ke kiʻi i ka pili a hiki i ka pā cia me keʻano.
//! E like me `&mut dyn Any`, aia kekahi me ke ʻano `downcast_mut`, no ka loaʻa ʻana o kahi kuhikuhi e hiki ke hoʻololi i ka waiwai o loko.
//! `Box<dyn Any>` hoʻohui i ka hana `downcast`, e hoʻāʻo nei e hoʻohuli i `Box<T>`.
//! E ʻike i ka palapala [`Box`] no nā kikoʻī piha.
//!
//! Note i `&dyn Any` ua kaupalena 'ia hoao ina paha he waiwai mea o ka hoakaka pōhaku punaʻano, aʻaʻole hiki ke hoʻohana' ia hoao aku paha i kekahiʻano mea lapaʻau i ka trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Akamai kuhikuhi a `dyn Any`
//!
//! Kekahi'āpana o ka hana, e malama i ka manao o ka hoʻohana 'ana `Any` like me ka trait e hoopii mai ai, o ka oi aku i ke ano e like `Box<dyn Any>` a `Arc<dyn Any>`, ka mea hoʻi kahea `.type_id()` ma ka waiwai, e paka i ka `TypeId` o ka *ipu*, i ka hp'pnphp trait mea.
//!
//! Ua hiki e käpae 'ia e hoʻololi i ka akamai laʻau kuhikuhi i loko o ka `&dyn Any` kahi, a e hoʻi i ka mea o ka `TypeId`.
//! O kahi laʻana:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Makemake paha ʻoe i kēia:
//! let actual_id = (&*boxed).type_id();
//! // ... ma mua o kēia:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! E noʻonoʻo i kahi kūlana kahi e makemake ai e haʻalele i kahi waiwai i hāʻawi ʻia i kahi hana.
//! Mākou i ka mea waiwai, ua huli hana i mea lapaʻau Debug, akā, ua e mai i kona pōhaku puna type.Makemake mākou e hāʻawi i kahi lapaʻau kūikawā i kekahi ʻano: i kēia hihia e paʻi ana i ka lōʻihi o nā kumukūʻai String ma mua o kā lākou waiwai.
//! Aole makou i ike i ka pōhaku punaʻano o ko mākou waiwai i i hoʻouluulu manawa, no laila, ua pono e hoʻohana runtime noʻonoʻo kahi.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ʻO ka hana logger no kēlā me kēia ʻano i hoʻokō ʻia ʻo Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // E ho'āʻo i ka hoohuli mākou mea i ka `String`.
//!     // Inā kūleʻa, makemake mākou e hoʻopuka i ka lōʻihi o ke String` a me kāna waiwai.
//!     // Ināʻaʻole, e ka he okoa type: e kakau ia mai unadorned.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Makemake kēia hana e haʻalele i kāna palena ma mua o ka hana ʻana me ia.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... hana i kekahi hana 'ē aʻe
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Kekahi trait
///////////////////////////////////////////////////////////////////////////////

/// A trait e hoʻohālike i ka kikokiko ʻana.
///
/// Hoʻokomo ka hapa nui o nā ʻano iā `Any`.Eia nō naʻe, ʻaʻohe ʻano i loaʻa kahi kūmole non-`ʻtatic`.
/// E ʻike i ka [module-level documentation][mod] no nā kikoʻī hou aʻe.
///
/// [mod]: crate::any
// ʻAʻole palekana kēia trait, ʻoiai mākou e hilinaʻi nei i nā kikoʻī o kāna hana ponoʻī `type_id` i ka code unsafe (e laʻa, `downcast`).ʻO ka maʻamau, he pilikia kēlā, akā no ka mea ʻo ka impl wale nō o `Any` kahi uhi kapa, ʻaʻohe code ʻē aʻe e hiki ke hoʻokomo iā `Any`.
//
// Hiki iā mākou ke hana i kēia trait i palekana ʻole-ʻaʻole ia e kumu o ka haki, ʻoiai mākou kaohi i nā hoʻokō āpau-akā koho mākou ʻaʻole no ka mea ʻaʻole pono ia ʻelua a huikau paha i nā mea hoʻohana e pili ana i ka hoʻokaʻawale ʻana o traits a me nā ʻano palekana ʻole (ie, E palekana ʻo `type_id` i ke kāhea ʻana, akā makemake paha mākou e hōʻike e like me ia i nā palapala).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Loaʻa iā `TypeId` o `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Nā hana hoʻolōʻihi no kekahi mea trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Hōʻoia 'ia ai ka hopena o IAOEIAaO, e pili ana i ka pae hiki ke paiia, a nolaila hoʻohana me `unwrap`.
// ʻAʻohe pono i Mei inā hana hou ka hana me ka upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Hoʻi iā `true` inā like ka ʻano pahu me `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // E kiʻi `TypeId` o keʻano kēia kuleana pili i ua instantiated me.
        let t = TypeId::of::<T>();

        // E kiʻi `TypeId` o ke 'ano i loko o ka trait mea (`self`).
        let concrete = self.type_id();

        // Hoʻohālikelike i nā ʻ TypeId ʻelua ma ke kaulike.
        t == concrete
    }

    /// Hoʻi kekahi pili ana i ka 'ikepili cia ina ia mea o ke ano `T`, a `None` ina ia mea ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: nānā wale inā mākou e kuhikuhi nei i ka ʻano pololei, a hiki iā mākou ke hilinaʻi
            // i ponopono no ka iaiyoe maluhia no ka mea, ua hoʻokō mākou i kekahi no ka mea a pau ano;ole'ē aʻe impls hiki nei me ka mea e kue ai me mākou impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka waiwai pahu inā he ʻano `T`, a `None` inā ʻaʻole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: nānā wale inā mākou e kuhikuhi nei i ka ʻano pololei, a hiki iā mākou ke hilinaʻi
            // i ponopono no ka iaiyoe maluhia no ka mea, ua hoʻokō mākou i kekahi no ka mea a pau ano;ole'ē aʻe impls hiki nei me ka mea e kue ai me mākou impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// I mua i ke kiʻina hana i wehewehe ʻia ma ke ʻano `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID a me kāna mau hana
///////////////////////////////////////////////////////////////////////////////

/// Hōʻike kahi `TypeId` i kahi ʻike kū hoʻokahi a puni ka honua no kahi ʻano.
///
/// ʻO kēlā me kēia `TypeId` kahi mea opaque ʻaʻole i ʻae i ka nānā ʻana i nā mea o loko akā ʻae i nā hana maʻamau e like me ke kala ʻana, ka hoʻohālikelike ʻana, ka paʻi ʻana, a me ka hōʻike ʻana.
///
///
/// Loaʻa kahi `TypeId` wale nō no nā ʻano e noi nei iā `'static`, akā hiki ke hoʻoneʻe ʻia kēia palena i ka future.
///
/// ʻOiai `TypeId` e hoʻokō iā `Hash`, `PartialOrd`, a me `Ord`, pono e hoʻomaopopo he ʻokoʻa ka hashes a me ke kauoha ma waena o Rust hoʻokuʻu.
/// E makaʻala i ka hilinaʻi iā lākou i loko o kāu code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Huli i ka `TypeId` o keʻano kēia nōhie kuleana pili i ua instantiated me.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Hoʻi ka inoa o kekahi 'ano like me ka kui māhele.
///
/// # Note
///
/// Hoʻonohonoho ʻia kēia no ka hoʻohana diagnostic.
/// ʻAʻole hōʻike ʻia nā ʻike kikoʻī a me ke ʻano o ke aho, ʻē aʻe ma mua o ke ʻano o kahi ʻano maikaʻi loa o ka ʻano.
/// No ka laʻana, i waena o na kaula i paha hoʻi `type_name::<Option<String>>()` i `"Option<String>"` a me `"std::option::Option<std::string::String>"`.
///
///
/// Ka hoi mai la kaula pono ole e manaoia ia e kekahi hanana hōʻike no o ke ano like o kekahi mau ano e palapala i ka ia type inoa.
/// Like, aole he kumu hoʻomalu i nā māhele o ka hoailona, eʻikea au i loko o ka hoi mai kaula: no ka laʻana, wa e ola ana specifiers Ke i komo.
/// Eia hou, hiki ke hoʻololi i ka hopena ma waena o nā mana o ka mea hoʻopili.
///
/// Ka papa manaʻo hoʻohana i ka ia aeuiiai ieaia? Me compiler lapaʻau 'ana a me ka debuginfo, akā, i kēia ua i ua hoʻohiki.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Hoʻi i ka inoa o ke 'ano o ke kuhikuhi mai la lakou-i ka waiwai, e like me ke kui māhele.
/// Ua like kēia me `type_name::<T>()`, akā hiki ke hoʻohana ʻia kahi ʻaʻole maʻalahi ka ʻano o ka loli.
///
/// # Note
///
/// Hoʻonohonoho ʻia kēia no ka hoʻohana diagnostic.ʻAʻole hōʻike ʻia nā kikoʻī kikoʻī a me ke ʻano o ke aho, ʻē aʻe ma mua o ke ʻano o kahi ʻano maikaʻi loa o ka ʻano.
/// ʻO kahi laʻana, hiki i ka `type_name_of_val::<Option<String>>(None)` ke hoʻihoʻi iā `"Option<String>"` a i ʻole `"std::option::Option<std::string::String>"`, akā ʻaʻole `"foobar"`.
///
/// Eia hou, hiki ke hoʻololi i ka hopena ma waena o nā mana o ka mea hoʻopili.
///
/// ʻAʻole hoʻonā kēia hana i nā mea trait, ʻo ia hoʻi `type_name_of_val(&7u32 as &dyn Debug)` e hoʻihoʻi iā `"dyn Debug"`, akā ʻaʻole `"u32"`.
///
/// ʻAʻole pono e noʻonoʻo ʻia ka inoa ʻano i kahi ʻano ʻokoʻa o kahi ʻano;
/// mahele like nā ʻano he nui i ka inoa ʻano like.
///
/// Ka papa manaʻo hoʻohana i ka ia aeuiiai ieaia? Me compiler lapaʻau 'ana a me ka debuginfo, akā, i kēia ua i ua hoʻohiki.
///
/// # Examples
///
/// Paʻi i ka huinakomo integer a me nā lana lana.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}