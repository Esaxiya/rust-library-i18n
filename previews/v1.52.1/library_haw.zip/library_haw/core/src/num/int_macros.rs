macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ʻO ka waiwai liʻiliʻi e hiki ke hōʻike ʻia e kēia ʻano helu.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// ʻO ke kumukūʻai nui loa i hiki ke hōʻike ʻia e kēia ʻano helu.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// ʻO ka nui o kēia ʻano helu o nā helu.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Hoʻololi i kahi ʻāpana kaula i kahi waihona i hāʻawi ʻia i ka helu helu.
        ///
        /// Manaʻo ʻia ke aho he `+` koho a i ʻole `-` hōʻailona e ukali ʻia e nā helu.
        /// Ke hōʻike nei i ke keʻokeʻo alakaʻi a me ke ala ʻana.
        /// ʻO nā Digits kahi ʻāpana o kēia mau huapalapala, kaukaʻi ʻia ma `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Kēia hana panics inā ʻaʻole ʻo `radix` i ka pae mai 2 a 36.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Hoʻihoʻi i ka helu o nā mea i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Hoʻihoʻi i ka helu o nā zeros i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Hoʻihoʻi i ka helu o nā zeros alakaʻi i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Hoʻihoʻi i ka helu o nā zeros trailing i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Hoʻihoʻi i ka helu o nā mea alakaʻi i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Hoʻihoʻi i ka helu o nā trailing i ka hōʻike binary o `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Hoʻololi i nā ʻāpana i ka hema e kahi kikoʻī kikoʻī, `n`, a ʻūlū i nā ʻāpana i kāʻoki ʻia a hiki i ka hopena o ka helu i helu ʻia.
        ///
        ///
        /// E ʻoluʻolu ʻaʻole kēia hana like me kā `<<` hoʻololi hoʻololi!
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Hoʻololi i nā ʻāpana i ka ʻākau e kahi kikoʻī kikoʻī, `n`, a ʻūlū i nā ʻāpana i ʻoki ʻia i ka hoʻomaka o ka helu i loaʻa.
        ///
        ///
        /// E ʻoluʻolu ʻaʻole kēia hana like me kā `>>` hoʻololi hoʻololi!
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Huli i ke kaʻina byte o ka integer.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// e hoʻokuʻu m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Huli i ka ʻaoʻao o nā ʻāpana i ka helu.
        /// Lilo ka mea nui liʻiliʻi i mea nui nui, ʻelua ʻāpana nui e lilo i ʻāpana nui nui, a pēlā aku.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// e hoʻokuʻu m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Hoʻohuli i ka helu helu mai endian nui a i ka hopena o ka pahu hopu.
        ///
        /// Ma endian nui he no-op kēia.Ma endian liʻiliʻi ua hoʻololi ʻia nā byte.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// inā cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ʻē aʻe {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Hoʻohuli i ka helu helu mai kahi endian liʻiliʻi i ka hopena o ka pahu hopu.
        ///
        /// Ma endian liʻiliʻi he no-op kēia.Ma endian nui ua hoʻololi ʻia nā byte.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// inā cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ʻē aʻe {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Hoʻololi iā `self` i endian nui mai ka hopena o ka pahu hopu.
        ///
        /// Ma endian nui he no-op kēia.Ma endian liʻiliʻi ua hoʻololi ʻia nā byte.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// inā cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ʻē aʻe { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // a i ʻole ʻaʻole e lilo?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Hoʻololi i `self` i endianness liʻiliʻi mai ka hopena o ka pahu hopu.
        ///
        /// Ma endian liʻiliʻi he no-op kēia.Ma endian nui ua hoʻololi ʻia nā byte.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// inā cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ʻē aʻe { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Loipālākiō integer hoʻohui.
        /// Hoʻomaulia iā `self + rhs`, e hoʻihoʻi nei iā `None` inā loaʻa ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Pākuʻi huahelu unchecked.Helu `self + rhs`, manaʻo ʻaʻole hiki ke piʻi aʻe.
        /// ʻO kēia ka hopena i nā hana undefined ke
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Wehe ʻia ka unuhi helu.
        /// Hoʻomaulia iā `self - rhs`, e hoʻihoʻi nei iā `None` inā loaʻa ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ʻO ka unuhi kaha helu ʻole i unchecked.Helu `self - rhs`, manaʻo ʻaʻole hiki ke piʻi aʻe.
        /// ʻO kēia ka hopena i nā hana undefined ke
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Hoʻonui helu.
        /// Hoʻomaulia iā `self * rhs`, e hoʻihoʻi nei iā `None` inā loaʻa ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Hoʻonui helu hoʻouka helu ʻole ʻia.Helu `self * rhs`, manaʻo ʻaʻole hiki ke piʻi aʻe.
        /// ʻO kēia ka hopena i nā hana undefined ke
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Māhele helu helu.
        /// Hoʻomaulia iā `self / rhs`, e hoʻihoʻi nei iā `None` inā `rhs == 0` a i ʻole nā hopena i nā hopena i ka hoʻonui ʻia.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div e ʻole a ma INT_MIN i nānā ʻia ma luna
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Nānā ʻia ka māhele Euclidean.
        /// Hoʻomaulia iā `self.div_euclid(rhs)`, e hoʻihoʻi nei iā `None` inā `rhs == 0` a i ʻole nā hopena i nā hopena i ka wai kahe.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Koe i nā koena helu.
        /// Hoʻomaulia iā `self % rhs`, e hoʻihoʻi nei iā `None` inā `rhs == 0` a i ʻole nā hopena i nā hopena i ka wai kahe.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div e ʻole a ma INT_MIN i nānā ʻia ma luna
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Nānā ʻia ke koena o Euclidean.
        /// Hoʻomaulia iā `self.rem_euclid(rhs)`, e hoʻihoʻi nei iā `None` inā `rhs == 0` a i ʻole nā hopena i nā hopena i ka wai kahe.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Hōʻole ʻia.
        /// Helu `-self`, e hoʻihoʻi nei iā `None` inā `self == MIN`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ua huli ke ʻano hema.
        /// Helu `self << rhs`, hoʻihoʻi iā `None` inā ʻoi aku ka nui o `rhs` ma mua a i ʻole ia i ka helu o nā ʻāpana i `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nānā pololei ʻia.
        /// Helu `self >> rhs`, hoʻihoʻi iā `None` inā ʻoi aku ka nui o `rhs` ma mua a i ʻole ia i ka helu o nā ʻāpana i `self`.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Loiloi ʻia ka waiwai piha.
        /// Helu `self.abs()`, e hoʻihoʻi nei iā `None` inā `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Hōʻoia exponentiation.
        /// Hoʻomaulia iā `self.pow(exp)`, e hoʻihoʻi nei iā `None` inā loaʻa ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // mai exp!=0, ʻo ka hope he 1 paha ia.
            // Hana me ka hapa hope o ka exponent i kaawale, no ka mea ʻaʻole pono ka squaring ʻana o ka waihona ma hope a hiki i kahi kahe pono ʻole.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Pākuʻi helu hoʻohelu.
        /// Helu `self + rhs`, e māʻona ana i nā palena helu ma kahi o ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Hoʻohaʻahaʻa integer saturating.
        /// Helu `self - rhs`, e māʻona ana i nā palena helu ma kahi o ka hoʻonui.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// ʻO ka hōʻole helu Integer.
        /// Hoʻomaulia iā `-self`, e hoʻihoʻi nei iā `MAX` inā `self == MIN` ma kahi o ka hoʻonui ʻana.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// ʻO ke kumu kūʻai piha.
        /// Hoʻomaulia iā `self.abs()`, e hoʻihoʻi nei iā `MAX` inā `self == MIN` ma kahi o ka hoʻonui ʻana.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Hoʻonui helu hoʻouluulu.
        /// Helu `self * rhs`, māona i nā palena helu ma kahi o ka hoʻonui.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// ʻO ka exponentiation huina holoʻokoʻa.
        /// Helu `self.pow(exp)`, māona i nā palena helu ma kahi o ka hoʻonui.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Hoʻohui (modular) hoʻohui.
        /// Hoʻomaulia iā `self + rhs`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Hoʻopau ʻana i ka hoʻoliʻiliʻi (modular).
        /// Hoʻomaulia iā `self - rhs`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Hoʻopau i ka hoʻonui (modular).
        /// Hoʻomaulia iā `self * rhs`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Wāwahi (modular).Hoʻomaulia iā `self / rhs`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// ʻO ka hihia wale nō kahi e hiki ai ke hoʻopili ʻana pēlā ke hoʻokaʻawale kekahi iā `MIN / -1` ma kahi ʻano i kau inoa ʻia (kahi `MIN` ka waiwai liʻiliʻi maikaʻi ʻole no ke ʻano);ua like kēia me `-MIN`, kahi waiwai maikaʻi i nui loa e hōʻike i ke ʻano.
        /// I kēlā hihia, hoʻi kēia hana iā `MIN` iho.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Ke hoʻopili ʻana i ka ʻāpana Euclidean.
        /// Hoʻomaulia iā `self.div_euclid(rhs)`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// E hiki wale mai ka wahī ʻana ma `MIN / -1` ma kahi ʻano i kau inoa ʻia (kahi ʻo `MIN` ka waiwai liʻiliʻi maikaʻi ʻole no ke ʻano).
        /// Ua like kēia me `-MIN`, kahi waiwai maikaʻi i nui loa e hōʻike i ke ʻano.
        /// I kēia hihia, hoʻihoʻi kēia hana iā `MIN` iho.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Pepa ana (modular) koena.Hoʻomaulia iā `self % rhs`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// ʻAʻole kū maoli kēlā pēpē i ka makemakika;hoʻokō pono ʻole i nā mea hana i `x % y` i kūpono ʻole no `MIN / -1` ma kahi ʻano i kau inoa ʻia (kahi ʻo `MIN` ka waiwai liʻiliʻi maikaʻi ʻole).
        ///
        /// I kēlā hihia, hoʻi kēia hana i `0`.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Hoʻopili i nā koena Euclidean.Hoʻomaulia iā `self.rem_euclid(rhs)`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// E hiki wale mai ka wahī ʻana ma `MIN % -1` ma kahi ʻano i kau inoa ʻia (kahi ʻo `MIN` ka waiwai liʻiliʻi maikaʻi ʻole no ke ʻano).
        /// I kēia hihia, hoʻihoʻi kēia hana iā 0.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Hoʻopau nei i ka hōʻole (modular).Hoʻomaulia iā `-self`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// ʻO ka hihia wale nō kahi e hiki ai ke hoʻopili ʻana pēlā ke hōʻole kekahi iā `MIN` ma kahi ʻano i kau inoa ʻia (kahi `MIN` ka waiwai liʻiliʻi maikaʻi ʻole no ke ʻano);He waiwai maikaʻi kēia i nui loa e hōʻike i ke ʻano.
        /// I kēlā hihia, hoʻi kēia hana iā `MIN` iho.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-manuahi hoʻololi iki-hema;hāʻawi iā `self << mask(rhs)`, kahi `mask` e hoʻoneʻe ai i nā ʻāpana kiʻekiʻe o `rhs` e hoʻonā i ka hoʻololi i ʻoi aku i ka bitwidth o kēia ʻano.
        ///
        /// E hoʻomaopopo ʻaʻole kēia *like* me ka rotate-hema;ua kaupalena ʻia ka RHS o kahi ʻūlū hema-hema i ka laulā o ke ʻano, ma mua o ka hoʻoliʻiliʻi ʻana o nā ʻāpana mai ka LHS e hoʻihoʻi ʻia i kekahi hopena.
        ///
        /// Hoʻokomo nā integer primitive i kahi hana [`rotate_left`](Self::rotate_left), ʻo ia paha ka mea āu e makemake ai ma kahi o.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: ʻo ka masking e nā bitsize o ke ʻano e hōʻoia ʻaʻole mākou e neʻe
            // ma waho o nā palena
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-manuahi ka neʻe iki;hāʻawi iā `self >> mask(rhs)`, kahi `mask` e hoʻoneʻe ai i nā ʻāpana kiʻekiʻe o `rhs` e hoʻonā i ka hoʻololi i ʻoi aku i ka bitwidth o kēia ʻano.
        ///
        /// E hoʻomaopopo ʻaʻole kēia *like* me ka huli ʻana-ʻākau;ua kaupalena ʻia ka RHS o kahi wili ʻākau i ka laulā o ke ʻano, ma mua o ka hoʻoliʻiliʻi ʻana o nā ʻāpana mai ka LHS i hoʻihoʻi ʻia i kekahi hopena.
        ///
        /// Hoʻokomo nā integer primitive i kahi hana [`rotate_right`](Self::rotate_right), ʻo ia paha ka mea āu e makemake ai ma kahi o.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: ʻo ka masking e nā bitsize o ke ʻano e hōʻoia ʻaʻole mākou e neʻe
            // ma waho o nā palena
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Hoʻopau nei i ka waiwai (modular).Hoʻomaulia iā `self.abs()`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// ʻO ka hihia wale nō kahi e hiki ai ke kāpili pēlā ke lawe kekahi i ka waiwai piha o ka waiwai liʻiliʻi maikaʻi no ka ʻano;He waiwai maikaʻi kēia i nui loa e hōʻike i ke ʻano.
        /// I kēlā hihia, hoʻi kēia hana iā `MIN` iho.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Hoʻomaulia i ka waiwai piha o `self` me ka ʻole o ka wahī ʻana a i ʻole ka panicking.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// ʻO ka hoʻopili ʻana iā (modular) exponentiation.
        /// Hoʻomaulia iā `self.pow(exp)`, e hoʻopili ana ma ka palena o ke ʻano.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // mai exp!=0, ʻo ka hope he 1 paha ia.
            // Hana me ka hapa hope o ka exponent i kaawale, no ka mea ʻaʻole pono ka squaring ʻana o ka waihona ma hope a hiki i kahi kahe pono ʻole.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Helu 'ia `self` + `rhs`
        ///
        /// Hoʻihoʻi i kahi tuple o ka hoʻohui a me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā ua hiki i kahi kahe ana a laila hoʻihoʻi ʻia ka waiwai i wahī ʻia.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Helu 'ia `self`, `rhs`
        ///
        /// E hoʻihoʻi i kahi tuple o ka unuhi me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā ua hiki i kahi kahe ana a laila hoʻihoʻi ʻia ka waiwai i wahī ʻia.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Hoʻomaulia i ka hoʻonui ʻana o `self` a me `rhs`.
        ///
        /// Hoʻihoʻi i kahi tuple o ka hoʻonui a me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā ua hiki i kahi kahe ana a laila hoʻihoʻi ʻia ka waiwai i wahī ʻia.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, ʻoiaʻiʻo));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Hoʻomaulia i ka mea hoʻokaʻawale ke hoʻokaʻawale ʻia ʻo `self` e `rhs`.
        ///
        /// Hoʻihoʻi i kahi tuple o ka mea hoʻokaʻawale a me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā kū ka wai kahe a laila hoʻihoʻi ʻia iā ʻoe iho.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Heluhelu i ka huina o ka Euclidean mahele `self.div_euclid(rhs)`.
        ///
        /// Hoʻihoʻi i kahi tuple o ka mea hoʻokaʻawale a me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā loaʻa kahi kahawai a laila hoʻihoʻi ʻia ʻo `self`.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Hoʻomaulia i ke koena ke mahele ʻia ʻo `self` e `rhs`.
        ///
        /// E hoʻihoʻi i kahi tuple o ke koena ma hope o ka hoʻokaʻawale ʻana me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā piʻi ka hālana a laila hoʻihoʻi ʻia ka 0.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// E hoʻonui ana i ke koena Euclidean.Helu 'ia `self.rem_euclid(rhs)`.
        ///
        /// E hoʻihoʻi i kahi tuple o ke koena ma hope o ka hoʻokaʻawale ʻana me kahi boolean e hōʻike ana inā e ulu ka arithmetic overflow.
        /// Inā piʻi ka hālana a laila hoʻihoʻi ʻia ka 0.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā `rhs` ka 0.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negates iā ʻoe iho, kahe ana inā like kēia me ka palena iki o ka waiwai.
        ///
        /// Hoʻihoʻi i kahi tuple o ka mana i hōʻole ʻia o ʻoe iho me kahi boolean e hōʻike ana inā paha ua ulu ka ʻāpana.
        /// Inā ʻo `self` ka palena iki o ka waiwai (e laʻa, `i32::MIN` no nā waiwai o ke ʻano `i32`), a laila e hoʻihoʻi hou ʻia ka palena iki a hoʻihoʻi ʻia ʻo `true` no kahi hanana e ulu ana.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Hoʻololi iā ia iho i waiho ʻia e `rhs` bits.
        ///
        /// Hoʻihoʻi i kahi tuple o ka mana i hoʻoneʻe ʻia o ʻoe iho me kahi boolean e hōʻike ana inā ʻoi aku ka nui o ka neʻe ma mua a i ʻole ka helu o nā ʻāpana.
        /// Inā nui ka nui o ka hoʻololi, a laila uhi ʻia ka waiwai (N-1) kahi N ka helu o nā ʻāpana, a laila hoʻohana ʻia kēia waiwai e hana i ka neʻe.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, ʻoiaʻiʻo));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Hoʻololi pono iā ʻoe iho e `rhs` bits.
        ///
        /// Hoʻihoʻi i kahi tuple o ka mana i hoʻoneʻe ʻia o ʻoe iho me kahi boolean e hōʻike ana inā ʻoi aku ka nui o ka neʻe ma mua a i ʻole ka helu o nā ʻāpana.
        /// Inā nui ka nui o ka hoʻololi, a laila uhi ʻia ka waiwai (N-1) kahi N ka helu o nā ʻāpana, a laila hoʻohana ʻia kēia waiwai e hana i ka neʻe.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, ʻoiaʻiʻo));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Hoʻomaulia i ka waiwai piha o `self`.
        ///
        /// E hoʻihoʻi i kahi tuple o ka mana ponoʻī o ʻoe iho me kahi boolean e hōʻike ana inā paha ua holo ka nui.
        /// Inā ʻo ʻoe iho ka waiwai palena iki
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// a laila e hoʻihoʻi hou ʻia ka waiwai liʻiliʻi a hoʻihoʻi ʻia ka ʻoiaʻiʻo no ka ulu ʻana o kahi kahawai.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Hoʻokiʻekiʻe iā ʻoe iho i ka mana o `exp`, e hoʻohana nei i ka exponentiation e ka squaring.
        ///
        /// Hoʻihoʻi i kahi tuple o ka exponentiation a me bool e hōʻike ana inā ua hiki mai kahi hoʻonui.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, ʻoiaʻiʻo));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ʻUmi i kahi no ka mālama ʻana i nā hopena o over_hola_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // mai exp!=0, ʻo ka hope he 1 paha ia.
            // Hana me ka hapa hope o ka exponent i kaawale, no ka mea ʻaʻole pono ka squaring ʻana o ka waihona ma hope a hiki i kahi kahe pono ʻole.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Hoʻokiʻekiʻe iā ʻoe iho i ka mana o `exp`, e hoʻohana nei i ka exponentiation e ka squaring.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // mai exp!=0, ʻo ka hope he 1 paha ia.
            // Hana me ka hapa hope o ka exponent i kaawale, no ka mea ʻaʻole pono ka squaring ʻana o ka waihona ma hope a hiki i kahi kahe pono ʻole.
            //
            //
            acc * base
        }

        /// Heluhelu i ka huina o ka Euclidean mahele o `self` e `rhs`.
        ///
        /// Hoʻomaulia kēia i ka helu helu `n` e like me `self = n * rhs + self.rem_euclid(rhs)`, me `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// I nā huaʻōlelo ʻē aʻe, ʻo `self / rhs` ka hopena i poepoe ʻia i ka integer `n` e like me `self >= n * rhs`.
        /// Inā `self > 0`, like kēia me ka pōʻai i zero (ʻo ka paʻamau ma Rust);
        /// inā `self < 0`, like kēia me ka pōʻai i +/-infinity.
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā ʻo `rhs` ka 0 a i ʻole nā hopena e hopena i ka hālana.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// e b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Heluhelu i nā koena nonnegative liʻiliʻi loa o `self (mod rhs)`.
        ///
        /// Hana ʻia kēia me he mea lā e ka Euclidean mahele algorithm-hāʻawi ʻia iā `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, a me `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// E panic kēia hana inā ʻo `rhs` ka 0 a i ʻole nā hopena e hopena i ka hālana.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// e b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Hoʻomaulia i ka waiwai piha o `self`.
        ///
        /// # ʻAha hoʻokahuli
        ///
        /// Ka waiwai piha o
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// hiki ʻole ke hōʻike ʻia ma ke ʻano he
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// a i ka hoʻāʻo ʻana e helu ia mea e hoʻonui ai ka wai.
        /// ʻO kēia ke kumu o ke code i ka mode debug e hoʻomaka i kahi panic ma kēia hihia a hoʻi mai ka code optimised
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// me ka ʻole panic.
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // E hoʻomaopopo i ka#[laina] ma luna nei ke ʻano o ka hilinaʻi o ka semantics overflow ma muli o crate a mākou e kuhikuhi nei i loko.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Hoʻihoʻi i kahi helu e hōʻike ana i ka hōʻailona o `self`.
        ///
        ///  - `0` inā he helu ʻole
        ///  - `1` inā maikaʻi ka helu
        ///  - `-1` inā maikaʻi ʻole ka helu
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Hoʻi iā `true` inā maikaʻi ka `self` a me `false` inā ʻole a helu ʻole paha ka helu.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Hoʻi iā `true` inā maikaʻi ʻole `self` a me `false` inā zero a maikaʻi paha ka helu.
        ///
        ///
        /// # Examples
        ///
        /// Hoʻohana maʻamau:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia integer ma ke ʻano he byte array ma ka ʻaoʻao (network) byte nui.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia integer ma ke ʻano he byte array ma ka ʻaoʻao byte-endian byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia integer ma ke ʻano he byte array ma ka ʻōiwi byte order.
        ///
        /// E like me ka hoʻohana ʻia ʻana o ka endianness ʻōiwi o ka pahu hopu, pono e hoʻohana i ka code lawe [`to_be_bytes`] a i ʻole [`to_le_bytes`], inā kūpono, ma kahi.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, inā ʻo CF! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ʻē aʻe {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: kani ke kani no ka mea he helu datatypes kahiko nā integers i hiki iā mākou ke hana mau
        // E hoʻolilo iā lākou i nā kāʻei o nā byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: he helu helu kahiko nā integers i hiki ai iā mākou ke lawe mau iā lākou i
            // nā hoʻonohonoho o nā byte
            unsafe { mem::transmute(self) }
        }

        /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia integer ma ke ʻano he byte array ma ka ʻōiwi byte order.
        ///
        ///
        /// [`to_ne_bytes`] pono e ʻoi aku ma mua o kēia inā hiki.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, inā ʻo CF! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ʻē aʻe {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: he helu helu kahiko nā integers i hiki ai iā mākou ke lawe mau iā lākou i
            // nā hoʻonohonoho o nā byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// E hana i helu helu mai kona hōʻike ʻia ma ke ʻano he lālani byte i ka endian nui.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// hoʻohana std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * hoʻokomo=hoʻomaha;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// E hana i helu helu mai kona hōʻike ʻia ma ke ʻano he byte array i endian liʻiliʻi.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// hoʻohana std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * hoʻokomo=hoʻomaha;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// E hana i helu waiwai mai kāna moʻo hoʻomanaʻo ma ke ʻano he byte array i ka endianness ʻōiwi.
        ///
        /// E like me ka hoʻohana ʻia ʻana o ka endianness ʻōiwi o ka pahu hopu, makemake paha ka code lawe e hoʻohana i [`from_be_bytes`] a i ʻole [`from_le_bytes`], ke kūpono ma kahi.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } ʻē aʻe {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// hoʻohana std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * hoʻokomo=hoʻomaha;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: kani ke kani no ka mea he helu datatypes kahiko nā integers i hiki iā mākou ke hana mau
        // hoʻoili iā lākou
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: ʻo nā integers he datatypes kahiko maʻalahi i hiki ai iā mākou ke lawe mau iā lākou
            unsafe { mem::transmute(bytes) }
        }

        /// Pono nā code hou e makemake e hoʻohana
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Hoʻihoʻi i ka waiwai liʻiliʻi i hiki ke hōʻike ʻia e kēia ʻano helu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Pono nā code hou e makemake e hoʻohana
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Hoʻi i ka waiwai nui loa i hiki ke hōʻike ʻia e kēia ʻano helu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}