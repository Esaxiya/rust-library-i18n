//! Kūpono mau i ka `f32` kiko kiko kiko lana hoʻokahi.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Hāʻawi ʻia nā helu makemakika koʻikoʻi i ka sub-module `consts`.
//!
//! No nā paʻa mau i wehewehe pololei ʻia i kēia kōmike (ma ke ʻano ʻokoʻa mai nā mea i ho'ākāka ʻia ma ka `consts` sub-module), e hoʻohana nā pāʻālua hou i nā konohiki pili i wehewehe pono ʻia ma ka `f32` ʻano.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// ʻO ka radix a i ʻole kumu o ka hōʻike kūloko o `f32`.
/// E hoʻohana i [`f32::RADIX`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ala i manaʻo ʻia
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Ka helu o nā helu kikoʻī i ke kumu 2.
/// E hoʻohana i [`f32::MANTISSA_DIGITS`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ala i manaʻo ʻia
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Ka helu kūpono o nā hua helu nui ma ka waihona 10.
/// E hoʻohana i [`f32::DIGITS`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ala i manaʻo ʻia
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] waiwai no `f32`.
/// E hoʻohana i [`f32::EPSILON`] ma kahi.
///
/// ʻO kēia ka ʻokoʻa ma waena o `1.0` a me ka helu hope aʻe ʻoi aku ka nui.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ala i manaʻo ʻia
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ʻO ka palena iki loa `f32` waiwai.
/// E hoʻohana i [`f32::MIN`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ala i manaʻo ʻia
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// ʻO ka liʻiliʻi `f32` waiwai maʻamau ka liʻiliʻi.
/// E hoʻohana i [`f32::MIN_POSITIVE`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ala i manaʻo ʻia
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// ʻO ka palena nui loa `f32` waiwai.
/// E hoʻohana i [`f32::MAX`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ala i manaʻo ʻia
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// ʻOi aku ka nui ma mua o ka palena iki o ka mana maʻamau o 2 exponent.
/// E hoʻohana i [`f32::MIN_EXP`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ala i manaʻo ʻia
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// ʻO ka mana hiki ke kiʻekiʻe o 2 exponent.
/// E hoʻohana i [`f32::MAX_EXP`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ala i manaʻo ʻia
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Ka palena iki o ka mana maʻamau o 10 exponent.
/// E hoʻohana i [`f32::MIN_10_EXP`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ala i manaʻo ʻia
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// ʻO ka mana hiki ke kiʻekiʻe o 10 exponent.
/// E hoʻohana i [`f32::MAX_10_EXP`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ala i manaʻo ʻia
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// ʻAʻole helu (NaN).
/// E hoʻohana i [`f32::NAN`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ala i manaʻo ʻia
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// E hoʻohana i [`f32::INFINITY`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ala i manaʻo ʻia
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negative infinity (−∞).
/// E hoʻohana i [`f32::NEG_INFINITY`] ma kahi.
///
/// # Examples
///
/// ```rust
/// // ala hoʻohaʻahaʻa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ala i manaʻo ʻia
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Mau mea makemakika maʻamau.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: e kuapo me nā mea makemakika mai cmath.

    /// (π) paʻa mau o Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Ke anapuni piha (τ)
    ///
    /// Kaulike i 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// ʻO ka helu a Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// ʻO ka radix a i ʻole kumu o ka hōʻike kūloko o `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Ka helu o nā helu kikoʻī i ke kumu 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Ka helu kūpono o nā hua helu nui ma ka waihona 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] waiwai no `f32`.
    ///
    /// ʻO kēia ka ʻokoʻa ma waena o `1.0` a me ka helu hope aʻe ʻoi aku ka nui.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ʻO ka palena iki loa `f32` waiwai.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// ʻO ka liʻiliʻi `f32` waiwai maʻamau ka liʻiliʻi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// ʻO ka palena nui loa `f32` waiwai.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// ʻOi aku ka nui ma mua o ka palena iki o ka mana maʻamau o 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// ʻO ka mana hiki ke kiʻekiʻe o 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Ka palena iki o ka mana maʻamau o 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// ʻO ka mana hiki ke kiʻekiʻe o 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// ʻAʻole helu (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negative infinity (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Hoʻi iā `true` inā `NaN` kēia waiwai.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): ʻAʻole loaʻa ʻo `abs` i ka libcore ma muli o nā hopohopo e pili ana i ka lawena, no laila kēia hoʻohana no ka hoʻohana pilikino ʻana o loko.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Hoʻi iā `true` inā he infinity maikaʻi a i ʻole infinity maikaʻi ʻole kēia waiwai, a me `false` i kahi ʻē aʻe.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Hoʻi iā `true` inā ʻaʻole palena ʻole kēia helu a i ʻole `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // ʻAʻole pono e lawelawe ʻokoʻa iā NaN: inā ʻo NaN iho ʻoe, ʻaʻole ʻoiaʻiʻo ka hoʻohālikelike ʻana, e like me ka makemake.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Hoʻi iā `true` inā [subnormal] ka helu.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Nā Subnormal nā waiwai ma waena o `0` a me `min`.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Hoʻi iā `true` inā ʻaʻole zero ka helu, palena ʻole, [subnormal], a i ʻole `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Nā Subnormal nā waiwai ma waena o `0` a me `min`.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Hoʻihoʻi i ka mahele kiko lana o ka helu.
    /// Inā e hoʻāʻo wale ʻia kahi waiwai, ʻoi aku ka wikiwiki o ka hoʻohana ʻana i ka predicate kikoʻī ma kahi.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Hoʻi iā `true` inā he hōʻailona maikaʻi kā `self`, me `+0.0`, `NaN me kahi hōʻailona maikaʻi a me ka palena pau ʻole.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Hoʻi iā `true` inā he hōʻailona maikaʻi ʻole ka `self`, me `-0.0`, `NaN me nā ʻōuli maikaʻi ʻole a me ka infinity maikaʻi ʻole.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Ua ʻōlelo ʻo IEEE754: He ʻoiaʻiʻo isSignMinus(x) inā a inā he x ka hōʻailona maikaʻi ʻole.
        // Pili ʻo isSignMinus i nā zeros a me nā NaNs pū kekahi.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Lawe i ka (inverse) pālua o kahi helu, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Hoʻohuli i nā radian i kekelē.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // E hoʻohana i ka paʻa no ka kikoʻī ʻoi aku.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Hoʻololi i nā kekelē i nā radian.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Hoʻihoʻi i ke kiʻekiʻena o nā helu ʻelua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Inā ʻo NaN kekahi o nā paio, a laila hoʻihoʻi ʻia ka paio ʻē aʻe.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Hoʻihoʻi i ka palena iki o nā helu ʻelua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Inā ʻo NaN kekahi o nā paio, a laila hoʻihoʻi ʻia ka paio ʻē aʻe.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Kuhi i ka zero a hoʻololi i kekahi ʻano helu integer primitive, e manaʻo nei he palena ka waiwai a kūpono i kēlā ʻano.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Pono ka waiwai:
    ///
    /// * ʻAʻole `NaN`
    /// * ʻAʻole palena ʻole
    /// * E lilo i mea koho i ka ʻano hoʻi `Int`, ma hope o ka ʻoki ʻana i kāna ʻāpana hakina
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Ka hoʻoili maka i `u32`.
    ///
    /// ʻAno like kēia i kēia manawa me `transmute::<f32, u32>(self)` ma nā anuu āpau.
    ///
    /// E ʻike iā `from_bits` no kekahi mau kūkākūkā ʻana no ka hiki i kēia hana (ʻaneʻane ʻaʻohe pilikia).
    ///
    /// E hoʻomaopopo he ʻokoʻa kēia hana mai ka hoʻolei ʻana i `as`, ka mea e hoʻāʻo e mālama i ka helu *helu*, ʻaʻole ka helu iki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ʻaʻole hoʻolei!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: ʻO `u32` kahi datatype kahiko i hiki ai iā mākou ke lawe mau iā ia
        unsafe { mem::transmute(self) }
    }

    /// ʻO ka transmutation maka mai `u32`.
    ///
    /// ʻAno like kēia i kēia manawa me `transmute::<u32, f32>(v)` ma nā anuu āpau.
    /// ʻIke ʻia he lawe maʻalahi kēia, no nā kumu ʻelua:
    ///
    /// * Loaʻa iā Floats a me Ints ka hopena like ma nā paepae kākoʻo āpau.
    /// * ʻIke kikoʻī ʻo IEEE-754 i ka hoʻonohonoho iki o nā lana.
    ///
    /// Eia nō naʻe aia hoʻokahi ana: ma mua o ka mana 2008 o IEEE-754, pehea e wehewehe ai i ka NaN hōʻailona hōʻailona ʻaʻole i kikoʻī ʻia.
    /// ʻO ka hapa nui o nā paepae (ʻo x86 a me ARM) i koho i ka wehewehe ʻana i hoʻokau ʻia i ka makahiki 2008, akā ʻaʻole kekahi (ʻo MIPS paha).
    /// ʻO ka hopena, nā NaN hōʻailona āpau ma MIPS e noho mālie NaNs ma x86, a ʻo ka ʻaoʻao ʻē aʻe.
    ///
    /// Ma mua o ka hoʻāʻo ʻana e mālama i ka cross-platform cross-platform, makemake kēia hoʻokō i ka mālama ʻana i nā ʻāpana kikoʻī.
    /// ʻO kēia ka mālama ʻia ʻana o nā uku i hoʻopili ʻia i NaNs ʻoiai e hoʻouna ʻia ka hopena o kēia hana ma ka pūnaewele mai kahi mīkini x86 a MIPS paha.
    ///
    ///
    /// Inā hoʻohana wale ʻia nā hopena o kēia hana e ka hoʻolālā like i hana iā lākou, a laila ʻaʻohe hopohopo lawe.
    ///
    /// Inā ʻaʻole NaN ka hoʻokomo, a laila ʻaʻohe hopohopo lawe.
    ///
    /// Inā ʻaʻole ʻoe e noʻonoʻo e pili ana i ka hōʻailona (aia paha), a laila ʻaʻohe hopohopo lawe.
    ///
    /// E hoʻomaopopo he ʻokoʻa kēia hana mai ka hoʻolei ʻana i `as`, ka mea e hoʻāʻo e mālama i ka helu *helu*, ʻaʻole ka helu iki.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SAFETY: ʻO `u32` kahi datatype kahiko no laila hiki iā mākou ke transmute mau iā ia
        // Ua hoʻololi ʻia nā pilikia palekana me sNaN ua hoʻokahuli ʻia!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia helu helu lana ma ke ʻano he byte array ma ka ʻaoʻao (network) byte nui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// E hoʻihoʻi i ka hoʻomanaʻo hoʻomanaʻo o kēia helu helu lana ma ke ʻano he byte array ma ka ʻaoʻao byte-endian byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// E hoʻihoʻi i ka hōʻike hoʻomanaʻo o kēia helu helu lana ma ke ʻano he byte array ma ke kaʻina byte ʻōiwi.
    ///
    /// E like me ka hoʻohana ʻia ʻana o ka endianness ʻōiwi o ka pahu hopu, pono e hoʻohana i ka code lawe [`to_be_bytes`] a i ʻole [`to_le_bytes`], inā kūpono, ma kahi.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// E hoʻihoʻi i ka hōʻike hoʻomanaʻo o kēia helu helu lana ma ke ʻano he byte array ma ke kaʻina byte ʻōiwi.
    ///
    ///
    /// [`to_ne_bytes`] pono e ʻoi aku ma mua o kēia inā hiki.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SAFETY: ʻO `f32` kahi datatype kahiko i hiki ai iā mākou ke lawe mau iā ia
        unsafe { &*(self as *const Self as *const _) }
    }

    /// E hana i kahi waiwai lana mai kāna mea i hōʻike ai ma ke ʻano he byte array i big endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// E hana i kahi waiwai lana mai kāna mea i hōʻike ai ma ke ʻano he byte array i endian liʻiliʻi.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// E hana i kahi waiwai lana mai kāna mea i hōʻike ai ma ke ʻano he byte array i ʻōiwi endian.
    ///
    /// E like me ka hoʻohana ʻia ʻana o ka endianness ʻōiwi o ka pahu hopu, makemake paha ka code lawe e hoʻohana i [`from_be_bytes`] a i ʻole [`from_le_bytes`], ke kūpono ma kahi.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Hoʻihoʻi i kahi kauoha ma waena o nā waiwai a me nā waiwai ʻē aʻe.
    /// ʻAʻole like me ka hoʻohālikelike hapa maʻamau ma waena o nā helu lana lana, hoʻopuka mau kēia hoʻohālikelike i kahi hoʻonohonoho e like me ka totalOrder predicate e like me ia i ho'ākāka ʻia ma ka IEEE 754 (2008 hoʻoponopono) lana lana pae.
    /// Kauoha ʻia nā waiwai i ke kaʻina penei:
    /// - Noho mālie maikaʻi ʻole NaN
    /// - Hōʻailona maikaʻi ʻole NaN
    /// - ʻO ka palena ʻole maikaʻi ʻole
    /// - Nā helu maikaʻi ʻole
    /// - Nā helu subnormal maikaʻi ʻole
    /// - ʻAno maikaʻi ʻole
    /// - ʻAilona maikaʻi
    /// - Nā helu subnormal maikaʻi
    /// - Nā helu maikaʻi
    /// - Makahiki maikaʻi ʻole
    /// - Hōʻailona hōʻailona maikaʻi NaN
    /// - Noho malie NaN
    ///
    /// E hoʻomaopopo ʻaʻole kūlike kēia hana me nā [`PartialOrd`] a me [`PartialEq`] o `f32`.I ke kikoʻī, nānā lākou i ka maikaʻi ʻole a maikaʻi ʻole e like me ka `total_cmp` ʻaʻole.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // I nā mea maikaʻi ʻole, e hoʻohuli i nā ʻāpana āpau a koe ka hōʻailona e hoʻokō ai i kahi hoʻonohonoho like e like me nā huina hoʻokō
        //
        // No ke aha e holo pono ai kēia?ʻElua kahua ʻo IEEE 754 i lana:
        // Hōʻailona, exponent a me mantissa.Loaʻa i ka pūʻulu o nā māla exponent a me mantissa i kahi waiwai āpau e like me kā lākou ʻanalike kauoha me ka nui o ka helu i wehewehe ʻia ai ka nui.
        // ʻAʻole wehewehe ʻia ka nui ma nā waiwai NaN, akā ʻo IEEE 754 huinaOrder e wehewehe i nā waiwai NaN pū kekahi e ukali i ka ʻaoʻao bitwise.Alakaʻi kēia i ke kauoha i wehewehe ʻia i ka manaʻo doc.
        // Eia nō naʻe, like ka hōʻike ʻana o ka nui no nā helu maikaʻi ʻole a me nā helu maikaʻi-ʻokoʻa wale nō ka hōʻailona liʻiliʻi.
        // E hoʻohālikelike maʻalahi i nā lana e like me nā integers i pūlima ʻia, pono mākou e hoʻohuli i ka exponent a me nā mantissa bits i ka helu o nā helu maikaʻi ʻole.
        // Hoʻololi kūpono mākou i nā helu i ka "two's complement" form.
        //
        // No ka hana ʻana i ka palaka, kūkulu mākou i kahi mask a me XOR e kūʻē iā ia.
        // Hoʻomaopopo mākou i kahi mask "all-ones except for the sign bit" mai nā waiwai i kau inoa ʻole ʻia: ʻo ka neʻe pololei ʻana e hoʻonui i ka integer, no laila mākou "fill" i ka pale maka me nā ʻāpana hōʻailona, a laila hoʻohuli iā unsigned e pahu i hoʻokahi iki iki.
        //
        // Ma nā waiwai maikaʻi, ʻo ka mask ka zeros āpau, no laila he no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Kāohi i kahi waiwai i kekahi wā ke ʻole ʻo NaN.
    ///
    /// Hoʻi iā `max` inā ʻo `self` ʻoi aku ma mua o `max`, a ʻo `min` inā ʻo `self` ma lalo o `min`.
    /// Inā ʻaʻole kēia hoʻihoʻi `self`.
    ///
    /// E hoʻomaopopo i ka hoʻihoʻi ʻana o kēia hana iā NaN inā ʻo NaN ka waiwai mua.
    ///
    /// # Panics
    ///
    /// Panics inā `min > max`, `min` ʻo NaN, a i ʻole `max` ʻo NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}