//! Mau no ka 8-iki unsigned integer type.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Pono e hoʻohana i nā pāʻālua hou i nā konohiki pili pono ma ke ʻano primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }