//! Kū mau no ka 16-bit i hoʻopaʻa inoa helu integer.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Pono e hoʻohana i nā pāʻālua hou i nā konohiki pili pono ma ke ʻano primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }