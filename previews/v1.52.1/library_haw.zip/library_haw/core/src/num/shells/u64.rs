//! Kū mau no ka 64-bit unsigned integer type.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Pono e hoʻohana i nā pāʻālua hou i nā konohiki pili pono ma ke ʻano primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }