//! Kū mau no ka 32-bit i hoʻopaʻa inoa helu integer.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Pono e hoʻohana i nā pāʻālua hou i nā konohiki pili pono ma ke ʻano primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }