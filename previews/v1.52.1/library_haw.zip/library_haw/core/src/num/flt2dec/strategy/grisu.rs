//! Hoʻololi ʻo Rust o ka Grisu3 algorithm i wehewehe ʻia ma "Ka paʻi ʻana i nā helu lana lana wale a pololei me nā helu helu" [^ 1].
//! Hoʻohana ia e pili ana iā 1KB o ka papa i hoʻomaʻamaʻa mua ʻia, a ma ka ʻaoʻao, wikiwiki ia no ka nui o nā hoʻokomo.
//!
//! [^1]: Florian Loitsch.2010. Ke paʻi wikiwiki nei i nā helu lana lana a
//!   pololei me nā helu.SIGPLAN ʻAʻole.45, 6 (Iune 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ʻike i nā manaʻo ma `format_shortest_opt` no ke kumu kūpono.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Hāʻawi ʻia `x > 0`, hoʻihoʻi iā `(k, 10^k)` e like me kēlā `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// ʻO ka hoʻokō mode pōkole loa no Grisu.
///
/// E hoʻihoʻi iā `None` ke hoʻi ia i kahi hōʻike inexact i kahi ʻano ʻē aʻe.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // pono mākou i ʻekolu mau ʻāpana o ka kikoʻī hou aʻe

    // e hoʻomaka me nā waiwai maʻamau me ka exponent like
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // e ʻike i kekahi `cached = 10^minusk` e like me kēlā `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // mai ka normalized o `plus`, ʻo ia hoʻi `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // hāʻawi ʻia i kā mākou koho o `ALPHA` a me `GAMMA`, hāʻawi kēia i `plus * cached` i `[4, 2^32)`.
    //
    // maopopo leʻa makemake ʻia e hoʻonui i ka `GAMMA - ALPHA`, no laila ʻaʻole pono mākou i nā mana cached he 10, akā aia kekahi mau manaʻo.
    //
    //
    // 1. makemake mākou e mālama iā `floor(plus * cached)` ma waena o `u32` mai ka pono o ka mahele kumukūʻai.
    //    (ʻaʻole hiki ke hōʻalo maoli ʻia kēia, koi ʻia ke koena no ka koho pololei.)
    // 2.
    // ke koena o `floor(plus * cached)` hoʻonui pinepine ʻia e 10, a ʻaʻole pono e hoʻonui.
    //
    // hāʻawi ka mea mua iā `64 + GAMMA <= 32`, ʻo ka lua hāʻawi iā `10 * 2^-ALPHA <= 2^64`;
    // -60 aʻo -32 ka pae kiʻekiʻe me kēia kaohi, a hoʻohana pū ʻo V8 iā lākou.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // pālākiō fps.hāʻawi kēia i ka hewa nui o 1 ulp (hōʻoia ʻia mai Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-laulā maoli o ka ʻemi
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ma luna o `minus`, `v` a me `plus` he *helu ʻia* kokoke (hewa <1 ulp).
    // ʻoiai ʻaʻole maopopo iā mākou he maikaʻi a maikaʻi ʻole paha ka hewa, hoʻohana mākou i ʻelua mau hoʻokokoke ʻia i hoʻokae like ʻia a loaʻa iā mākou ka hewa nui o 2 ulps.
    //
    // ka "unsafe region" kahi manawa kūʻokoʻa a mākou i hana mua ai.
    // ka "safe region" kahi wā conservative a mākou e ʻae wale ai.
    // hoʻomaka mākou me ka repr pololei ma loko o ka ʻāpana palekana, a hoʻāʻo e ʻike i ka repr kokoke loa iā `v` a i loko nō hoʻi o ka wahi palekana.
    // inā ʻaʻole hiki iā mākou, hāʻawi wale mākou.
    //
    let plus1 = plus.f + 1;
    // e plus0 = plus.f, 1;//wale no ka wehewehe e waiho minus0 = minus.f + 1;//wale no ka wehewehe ʻana
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // ʻelele hoʻokaʻaʻike

    // mahele i ka `plus1` i nā ʻāpana hoʻohui a me nā hakina.
    // hoʻohui ʻia nā ʻāpana hoʻohui e komo i ka u32, ʻoiai ka mana cache e hōʻoia i `plus < 2^32` a ʻo `plus.f` maʻamau ma lalo o `2^64 - 2^4` ma muli o ke koi kikoʻī.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // e hoʻomaulia i ka `10^max_kappa` nui loa ma mua o `plus1` (pēlā `plus1 < 10^(max_kappa+1)`).
    // he palena luna kēia o `kappa` ma lalo.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: inā ʻo `k` ka helu nui ʻo st
    // `0 <= y mod 10^k <= y - x`,              a laila `V = floor(y / 10^k) * 10^k` ma `[x, y]` a me kekahi o nā hōʻike pōkole loa (me ka helu liʻiliʻi o nā helu nui) i kēlā pae.
    //
    //
    // e ʻike i ka lōʻihi o ka helu `kappa` ma waena o `(minus1, plus1)` e like me ka Theorem 6.2.
    // Hiki ke ʻae ʻia ka Theorem 6.2 e kāpae i ka `x` ma ke noi ʻana iā `y mod 10^k < y - x` ma kahi.
    // (eg, `x` =32000, `y` =32777; `kappa` =2 mai `y mod 10 ^ 3=777 <y, x=777`.) Hilinaʻi ka algorithm i ka ʻāpana hōʻoia ma hope e haʻalele iā `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) as usize;//wale no ka wehewehe ʻana
    let delta1frac = delta1 & ((1 << e) - 1);

    // hāʻawi i nā ʻāpana hoʻohui, ʻoiai e hōʻoia ana i ka pololei i kēlā me kēia ʻanuʻu.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // e hāʻawi ʻia nā helu
    loop {
        // Loaʻa iā mākou ma ka liʻiliʻi he hoʻokahi kikoʻī e hāʻawi, ma ke ʻano he invariants `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (hāhai kēia `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // mahele i `remainder` e `10^kappa`.ua hoʻonui ʻia nā mea ʻelua e `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ua loaʻa iā mākou ka `kappa` pololei.
            let ten_kappa = (ten_kappa as u64) << e; // pālākiō 10 ^ kappa hoʻi i ka exponent kaʻana like
            return round_and_weed(
                // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // e uhaʻi i ka loop i ka wā a mākou i hāʻawi ai i nā helu āpau.
        // ʻo ka helu kikoʻī o nā huahelu ʻo `max_kappa + 1` ma ke ʻano `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // hoʻihoʻi i nā invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // hāʻawi i nā ʻāpana haʻihaʻi, ʻoiai e nānā ana i ka pololei i kēlā me kēia ʻanuʻu.
    // i kēia manawa ke hilinaʻi nei mākou i ka hoʻonui pinepine ʻana, no ka mea, e lilo ka mahele i ka pololei.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // pono ka helu hou aʻe e like me kā mākou i hoʻāʻo ai ma mua o ka haki ʻana i nā invariants, kahi `m = max_kappa + 1` (#o nā helu i ka ʻāpana hoʻohui):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ʻaʻole e lana, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // mahele i `remainder` iā `10^kappa`.
        // Hoʻohālikelike ʻia nā mea ʻelua e `2^e / 10^kappa`, no laila pili ka hopena ma aneʻi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ʻelekū implicit
            return round_and_weed(
                // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // hoʻihoʻi i nā invariants
        kappa -= 1;
        remainder = r;
    }

    // ua hana mākou i nā helu nui a pau o `plus1`, akā ʻaʻole maopopo inā ʻo ia ka mea maikaʻi loa.
    // ʻo kahi laʻana, inā ʻo `minus1` ka 3.14153 ... a ʻo `plus1` ka 3.14158 ..., aia he 5 mau hiʻohiʻona pōkole ʻokoʻa loa mai 3.14154 a i 3.14158 akā ʻo mākou wale nō ka mea nui loa.
    // pono mākou e hōʻemi kūʻē i ka helu hope loa a nānā inā ʻo kēia ka repr maikaʻi loa.
    // aia ma kahi o 9 mau moho (..1 a ..9), no laila wikiwiki kēia.("rounding" pae)
    //
    // Nānā ka hana inā aia kēia "optimal" repr i loko o nā pae ulp, a ʻo ia nō, hiki i ka "second-to-optimal" repr ke lilo i mea ʻoi loa ma muli o ke kuhi hewa.
    // i nā hihia ʻelua i kēia hoʻi iā `None`.
    // ("weeding" pae)
    //
    // helu ʻia nā hoʻopaʻapaʻa āpau e ka waiwai maʻamau (akā implicit) `k`, no laila:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (a ʻo ia hoʻi, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (a ʻo ia hoʻi, `threshold > plus1v` mai nā poʻe invariants mua)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // e hana i ʻelua mau hoʻokokoke ʻana i `v` (maoli `plus1 - v`) ma loko o 1.5 ulps.
        // ʻo ka hopena e hōʻike i kahi hōʻike kokoke loa i nā mea ʻelua.
        //
        // Maʻaneʻi e hoʻohana ʻia ʻo `plus1 - v` ma muli o ka helu ʻana e pili ana iā `plus1` i mea e hōʻalo ai iā overflow/underflow (no laila nā inoa i hoʻololi ʻia).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // e hoʻēmi i ka huahelu hope loa a kū ma kahi hōʻike kokoke loa iā `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // hana mākou me nā huahelu kokoke `w(n)`, i like mua me `plus1 - plus1 % 10^kappa`.ma hope o ka holo ʻana o ke kino loop `n` mau manawa, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // hoʻonohonoho mākou iā `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (pēlā `koena= plus1w(0)`) e hoʻomaʻalahi i nā loiloi.
            // e hoʻomaopopo e hoʻonui mau ana ʻo `plus1w(n)`.
            //
            // he ʻekolu kā mākou mau kūlana e hoʻopau ai.kekahi o lākou e hiki ʻole i ka loop ke hele i mua, akā aia iā mākou ma kahi o hoʻokahi hōʻike kūpono i ʻike ʻia kokoke loa iā `v + 1 ulp`.
            // e hōʻike mākou iā lākou ma ke ʻano TC1 ma o TC3 no ka pōkole.
            //
            // TC1: `w(n) <= v + 1 ulp`, ʻo ia hoʻi, ʻo kēia ka repr hope loa i hiki ke lilo i kahi kokoke loa.
            // ua like kēia me `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // hui pū ʻia me TC2 (ka mea e nānā inā `w(n+1)` is valid), pale kēia i ka hiki ke kahe ma ka helu ʻana o `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ʻo ia hoʻi, ʻaʻole puni ka repr i `v`.
            // ua like kēia me `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // hiki i ka ʻaoʻao ʻaoʻao hema ke kahe, akā ʻike mākou `threshold > plus1v`, no laila inā TC1 he wahaheʻe, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` a hiki iā mākou ke hōʻoia palekana inā `threshold - plus1w(n) < 10^kappa` ma kahi.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ʻo ia hoʻi, ka repr hou aʻe
            // ʻaʻole kokoke i `v + 1 ulp` ma mua o ka repr o kēia manawa.
            // hāʻawi ʻia `z(n) = plus1v_up - plus1w(n)`, lilo kēia i `abs(z(n)) <= abs(z(n+1))`.ke manaʻo hou nei he wahaheʻe ʻo TC1, aia iā `z(n) > 0`.ʻelua mau hihia e noʻonoʻo ai:
            //
            // - ke `z(n+1) >= 0`: TC3 i `z(n) <= z(n+1)`.
            // i ka hoʻonui ʻana o `plus1w(n)`, e emi ana ʻo `z(n)` a he wahaheʻe maoli kēia.
            // - ke `z(n+1) < 0`:
            //   - TC3a: ʻo ka precondition `plus1v_up < plus1w(n) + 10^kappa`.ke manaʻo nei he wahaheʻe ʻo TC2, `threshold >= plus1w(n) + 10^kappa` no laila ʻaʻole hiki ke hoʻonui.
            //   - TC3b: lilo ʻo TC3 i `z(n) <= -z(n+1)`, ʻo ia hoʻi `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   Hāʻawi ka TC1 i hōʻole ʻia iā `plus1v_up > plus1w(n)`, no laila ʻaʻole hiki ke overflow a i ʻole underflow ke hoʻohui ʻia me TC3a.
            //
            // a laila, pono mākou e kū i ka wā `TC1 || TC2 || (TC3a && TC3b)`.like ka mea aʻe me kona kekeke, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ʻaʻole hiki i ka repr pōkole loa ke hoʻopau me `0`
                plus1w += ten_kappa;
            }
        }

        // e nānā inā ʻo kēia hōʻike ka hōʻike kokoke loa iā `v - 1 ulp`.
        //
        // like kēia me nā kūlana hoʻopau no `v + 1 ulp`, me `plus1v_up` āpau i pani ʻia e `plus1v_down` ma kahi.
        // mālama like i ka nānā ʻana
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // I kēia manawa iā mākou kahi hōʻike kokoke loa i `v` ma waena o `plus1` a me `minus1`.
        // ʻoi loa ka liberal, no laila, hōʻole mākou i kekahi `w(n)` ʻaʻole ma waena o `plus0` a me `minus0`, ʻo ia hoʻi, `plus1 - plus1w(n) <= minus0` a i ʻole `plus1 - plus1w(n) >= plus0`.
        // hoʻohana mākou i nā mea i `threshold = plus1 - minus1` a me `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ʻO ka hoʻokō mode pōkole loa no Grisu me Dragon fallback.
///
/// E hoʻohana ʻia kēia no ka nui o nā hihia.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETY: ʻAʻole akamai ka mea hōʻaiʻē e hāʻawi iā mākou e hoʻohana iā `buf`
    // i ka lua o branch, no laila mākou e holoi holoʻokoʻa i ke ola holoʻokoʻa ma aneʻi.
    // Akā hoʻohana wale mākou iā `buf` inā hoʻihoʻi ʻo `format_shortest_opt` iā `None` no laila maikaʻi kēia.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// ʻO ka hoʻokō pololei a paʻa hoʻi no Grisu.
///
/// E hoʻihoʻi iā `None` ke hoʻi ia i kahi hōʻike inexact i kahi ʻano ʻē aʻe.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // pono mākou i ʻekolu mau ʻāpana o ka kikoʻī hou aʻe
    assert!(!buf.is_empty());

    // normalize a pālākiō `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // mahele i ka `v` i nā ʻāpana hoʻohui a me nā hakina.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ʻo `v` ʻelua a me `v` hou (hoʻonui ʻia e `10^-k`) he hemahema o <1 ulp (Theorem 5.1).
    // ʻoiai ʻaʻole mākou e ʻike he maikaʻi a maikaʻi ʻole paha ka hewa, hoʻohana mākou i ʻelua mau hoʻokokoke ʻia i hoʻokaʻawale like ʻia a loaʻa ka hewa nui o 2 ulps (like me ka hihia pōkole loa).
    //
    //
    // ʻo ka pahuhopu e ʻike i ka moʻo o nā huahelu i hoʻopuni ʻia i maʻa mau i nā `v - 1 ulp` a me `v + 1 ulp`, i mea e hilinaʻi nui ai mākou.
    // inā hiki ʻole kēia, ʻaʻole mākou e ʻike i kahi o ka hoʻopuka pololei no `v`, no laila hāʻawi mākou a hāʻule hope.
    //
    // `err` ua wehewehe ʻia e like me `1 ulp * 2^e` ma aneʻi (like me ka ulp ma `vfrac`), a e pākuʻi mākou ia i ka manawa a `v` e hoʻonui ʻia.
    //
    //
    //
    let mut err = 1;

    // e hoʻomaulia i ka `10^max_kappa` nui loa ma mua o `v` (pēlā `v < 10^(max_kappa+1)`).
    // he palena luna kēia o `kappa` ma lalo.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // inā mākou e hana nei me ka palena helu hope loa, pono mākou e hoʻopōkole i ka buffer ma mua o ka hāʻawi maoli ʻana i mea e pale ai i ka hoʻopālua ʻana.
    //
    // e hoʻomaopopo he pono mākou e hoʻonui hou i ka buffer ke hele a puni ka hanana.
    let len = if exp <= limit {
        // auwē, ʻaʻole hiki iā mākou ke hana i kahi hua paʻi *hoʻokahi*.
        // hiki nō kēia ke, ke, loaʻa iā mākou kahi mea e like me 9.5 a ke hoʻopuni ʻia nei i 10.
        //
        // i ke kumu hiki iā mākou ke kāhea koke iā `possibly_round` me kahi buffer hakahaka, akā ʻo ka hoʻonui ʻana i ka `max_ten_kappa << e` e 10 hiki ke hopena i ka hālana.
        //
        // Pēlā mākou e sloppy nei a hoʻonui i ke kikowaena hewa e kahi helu o 10.
        // e hoʻonui kēia i ka helu maikaʻi ʻole wahaheʻe, akā ʻo ia wale nō,*loa* iki;
        // hiki ke ʻike wale ʻia ke nui aʻe ka mantissa ma mua o 60 mau ʻāpana.
        //
        // SAFETY: `len=0`, no laila he mea nui ʻole ke kuleana o ka hoʻokumu ʻana i kēia hoʻomanaʻo.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // hāʻawi i nā ʻāpana hoʻohui.
    // ʻo ka hemahema he hakina āpau ia, no laila ʻaʻole pono mākou e nānā iā ia i kēia ʻāpana.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // e hāʻawi ʻia nā helu
    loop {
        // Loaʻa iā mākou ma ka liʻiliʻi he hoʻokahi kikoʻī e hāʻawi i nā invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (hāhai kēia `remainder = vint % 10^(kappa+1)`)
        //
        //

        // mahele i `remainder` e `10^kappa`.ua hoʻonui ʻia nā mea ʻelua e `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ua piha ka pūhaka?holo i ka passing pass me ke koena.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: ua hoʻomaka mua mākou iā `len` i nā byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // e uhaʻi i ka loop i ka wā a mākou i hāʻawi ai i nā helu āpau.
        // ʻo ka helu kikoʻī o nā huahelu ʻo `max_kappa + 1` ma ke ʻano `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // hoʻihoʻi i nā invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // hāʻawi i nā ʻāpana haʻihaʻi.
    //
    // i ke kumumanaʻo hiki iā mākou ke hoʻomau i ka helu hope loa i loaʻa a nānā i ka pololei.
    // Eia naʻe ke hana nei mākou me nā helu helu palena palena, no laila pono mākou i kahi pae e kuhikuhi ai i ka kahe.
    // V8 hoʻohana i ka `remainder > err`, a lilo i wahaheʻe ke ʻokoʻa nā helu nui `i` mua o `v - 1 ulp` a me `v`.
    // akā hōʻole kēia i nā manaʻo komo kūpono ʻē aʻe.
    //
    // ʻoiai loaʻa i ka ʻāpana hope loa kahi ʻike pono overflow, ke hoʻohana nei mākou i kahi ana ʻoi loa:
    // hoʻomau mākou a hiki i ka `err` ʻoi aku ma mua o `10^kappa / 2`, no laila ke loaʻa nei i ka laulā ma waena o `v - 1 ulp` a me `v + 1 ulp` i ʻelua a ʻoi paha mau hiʻohiʻona i hoʻopuni ʻia.
    //
    // like kēia me nā hoʻohālikelike mua ʻelua mai `possibly_round`, no ke kuhikuhi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // nā invariants, kahi `m = max_kappa + 1` (#o nā helu i ka ʻāpana hoʻohui):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ʻaʻole e lana, `2^e * 10 < 2^64`
        err *= 10; // ʻaʻole e lana, `err * 10 < 2^e * 5 < 2^64`

        // mahele i `remainder` iā `10^kappa`.
        // Hoʻohālikelike ʻia nā mea ʻelua e `2^e / 10^kappa`, no laila pili ka hopena ma aneʻi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ua piha ka pūhaka?holo i ka passing pass me ke koena.
        if i == len {
            // SAFETY: ua hoʻomaka mua mākou iā `len` i nā byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // hoʻihoʻi i nā invariants
        remainder = r;
    }

    // makehewa ka helu hou ʻana (pono ʻole ʻo `possibly_round`), no laila hāʻawi mākou.
    return None;

    // ua hana mākou i nā helu a pau i noi ʻia o `v`, a like nō ia me nā helu like o `v - 1 ulp`.
    // I kēia manawa ke nānā aku mākou inā aia kahi hiʻohiʻona kūlike i kaʻana ʻia e `v - 1 ulp` a me `v + 1 ulp`;hiki i kēia ke like i nā helu i haku ʻia, a i ʻole ka mana i hoʻopuni ʻia o kēlā mau helu.
    //
    // inā loaʻa i ka pae ka nui o nā hiʻohiʻona o ka lōʻihi like, ʻaʻole hiki iā mākou ke maopopo a hoʻi mākou i `None` ma kahi.
    //
    // helu ʻia nā hoʻopaʻapaʻa āpau e ka waiwai maʻamau (akā implicit) `k`, no laila:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAFETY: pono e hoʻomaka mua ʻia nā byte `len` o `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (no ke kuhikuhi, hōʻike ka laina kiko i ka waiwai kikoʻī no nā hōʻike i hiki ke helu ʻia i nā helu.)
        //
        //
        // hewa nui loa aia ma ka liʻiliʻi he ʻekolu mau hiʻohiʻona ma waena o `v - 1 ulp` a me `v + 1 ulp`.
        // ʻaʻole hiki iā mākou ke hoʻoholo i kahi o ka pololei.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // i ka ʻoiaʻiʻo, ua lawa ka 1/2 ulp e hoʻolauna ai i ʻelua mau hiʻohiʻona hiki.
        // (E hoʻomanaʻo pono mākou i kahi hiʻohiʻona kū hoʻokahi no nā `v - 1 ulp` a me ka 'v + 1 ulp`.) ʻaʻole kēia e kahe, e like me `ulp < ten_kappa` mai ka hōʻoia mua.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // inā kokoke ʻo `v + 1 ulp` i ka hōʻike poepoe-i lalo (aia i `buf`), a laila hiki iā mākou ke hoʻi palekana.
        // e hoʻomaopopo he `v - 1 ulp`*hiki* ke ʻoi aku ma mua o ke ʻano o kēia manawa, akā ʻo `1 ulp < 10^kappa / 2`, ua lawa kēia ʻano:
        // ʻo ka mamao ma waena o `v - 1 ulp` a me nā hōʻike i kēia manawa ʻaʻole hiki ke ʻoi aku ma mua o `10^kappa / 2`.
        //
        // kūlike ke kūlana me `remainder + ulp < 10^kappa / 2`.
        // ʻoiai hiki ke maʻalahi i kēia, e nānā mua inā `remainder < 10^kappa / 2`.
        // ua hōʻoia mākou i kēlā `ulp < 10^kappa / 2`, no laila ʻaʻole ʻo `10^kappa` i kahe nui ma hope o nā mea āpau, maikaʻi ka helu ʻelua.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: ʻo kā mākou mea kelepona i hoʻomaka i kēlā hoʻomanaʻo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------koena------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ma nā lima ʻē aʻe, inā kokoke ʻo `v - 1 ulp` i ka hōʻike i puni ʻia, pono mākou e hoʻopuni a hoʻi.
        // no ke kumu hoʻokahi ʻaʻole pono mākou e nānā iā `v + 1 ulp`.
        //
        // kūlike ke kūlana me `remainder - ulp >= 10^kappa / 2`.
        // nānā hou mākou inā `remainder > ulp` (e hoʻomaopopo ʻaʻole kēia `remainder >= ulp`, ʻoiai ʻo `10^kappa` ʻaʻole zero).
        //
        // e hoʻomaopopo pū nō hoʻi iā `remainder - ulp <= 10^kappa`, no laila ʻaʻole piʻi ka lua o ka hōʻoia.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAFETY: pono i kā mākou mea kelepona e hoʻomaka i kēlā hoʻomanaʻo.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // hoʻohui wale i kahi helu hou ke noi ʻia mākou i ke kikoʻī paʻa.
                // pono mākou e nānā i kēlā, inā nele ka buffer kumu, hiki ke hoʻohui wale ʻia ka helu hou ke `exp == limit` (edge case).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAFETY: ʻo mākou a me kā mākou mea kāhea i hoʻomaka i kēlā hoʻomanaʻo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // i ʻole mākou e luku ʻia (ʻo ia hoʻi, ke kuhi nei kekahi mau waiwai ma waena o `v - 1 ulp` a me `v + 1 ulp` a ke hoʻopuni nei nā mea ʻē aʻe) a hāʻawi.
        //
        None
    }
}

/// ʻO ke ʻano pololei a paʻa hoʻi no ka Grisu me Dragon fallback.
///
/// E hoʻohana ʻia kēia no ka nui o nā hihia.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETY: ʻAʻole akamai ka mea hōʻaiʻē e hāʻawi iā mākou e hoʻohana iā `buf`
    // i ka lua o branch, no laila mākou e holoi holoʻokoʻa i ke ola holoʻokoʻa ma aneʻi.
    // Akā hoʻohana wale mākou iā `buf` inā hoʻihoʻi ʻo `format_exact_opt` iā `None` no laila maikaʻi kēia.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}