//! ʻO ka mea koho manaʻo hoʻopuka.

/// Loaʻa iā `k_0` e like me kēlā `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Hoʻohana ʻia kēia e hoʻokokoke iā `k = ceil(log_10 (mant * 2^exp))`;
/// ʻo ka `k` maoli ka `k_0` a i ʻole `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits inā mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) no laila hoʻohaʻahaʻa loa kēia (a pololei paha), akā ʻaʻole nui.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}