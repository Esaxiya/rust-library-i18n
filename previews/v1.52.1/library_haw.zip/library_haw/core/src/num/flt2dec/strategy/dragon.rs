//! ʻAneʻane pololei (akā ua hoʻokau pono iki ʻia) Rust unuhi o ke Kiʻi 3 o "Ka paʻi ʻana i nā helu lana lana wale a pololei" [^ 1].
//!
//!
//! [^1]: Burger, RG a me Dybvig, RK 1996. Ke paʻi nei i nā helu kiko lana
//!   wikiwiki a pololei hoʻi.SIGPLAN ʻAʻole.31, 5 (Mei. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// i hoʻonohonoho mua ʻia o nā Digit ʻs no 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// hiki ke hoʻohana wale ʻia ke `x < 16 * scale`;`scaleN` pono iā `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ʻO ka hoʻokō mode pōkole loa no Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ʻo ka helu `v` i ka hōʻano ʻike ʻia e:
    // - kūlike i `mant * 2^exp`;
    // - i mua o `(mant - 2 *minus)* 2^exp` i ke ʻano kumu;a
    // - ukali ʻia e `(mant + 2 *plus)* 2^exp` i ke ʻano kumu.
    //
    // ʻoiai, ʻaʻole hiki iā `minus` a me `plus` ke zero.(no ka infinities, hoʻohana mākou i nā waiwai ma waho o ka palena.) no mākou ke kuhi ʻia ma ka liʻiliʻi he hoʻokahi huahelu, ʻo ia hoʻi, ʻaʻole hiki i `mant` ke ʻole.
    //
    // ʻo ia hoʻi kahi palapala ma waena o `low = (mant - minus)*2^exp` a me `high = (mant + plus)* 2^exp` e palapala ʻāina i kēia helu kiko lana kikoʻī, me nā palena i hoʻopili ʻia i ka wā a ka mantissa kumu (ie, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ʻO `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // kuhi `k_0` mai nā huakomo kumu i māʻona ai `10^(k_0-1) < high <= 10^(k_0+1)`.
    // Kuhi ʻia ka paʻa paʻa `k` ʻoluʻolu `10^(k-1) < high <= 10^k` ma hope.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // hoʻololi iā `{mant, plus, minus} * 2^exp` i ka mana haʻihaʻi i:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // mahele i `mant` e `10^k`.i kēia manawa `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // hoʻoponopono inā `mant + plus > scale` (a `>=` paha).
    // ʻaʻole mākou e hoʻololi maoli iā `scale`, ʻoiai hiki iā mākou ke lele i ka hoʻonui mua ma kahi.
    // I kēia manawa `scale < mant + plus <= scale * 10` a mākaukau mākou e hana i nā helu.
    //
    // e hoʻomaopopo he `d[0]`*hiki* ke ʻole, ke `scale - plus < mant < scale`.
    // i kēia hihia e hoʻopiʻi koke ʻia ke kūlana poepoe (`up` ma lalo).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // kūlike i ka scaling `scale` e 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` no ka hanauna huahelu.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // nā invariants, kahi a `d[0..n-1]` i huahelu ai i kēia manawa:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (pela `mant / scale < 10`) kahi `d[i..j]` kahi pōkole no `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // hana i hoʻokahi huahelu: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ʻO kēia kahi wehewehe maʻalahi o ka Dragon algorithm i hoʻololi ʻia.
        // haʻalele ʻia nā derivations waena he nui a me nā hoʻopaʻapaʻa piha no ka maʻalahi.
        //
        // e hoʻomaka me nā invariants i hoʻololi ʻia, e like me kā mākou i hoʻohou ai i `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // kuhi ʻo `d[0..n-1]` ka hōʻike pōkole loa ma waena o `low` a me `high`, ʻo ia hoʻi, māʻona ʻo `d[0..n-1]` i nā mea ʻelua aʻe akā ʻaʻole ʻo `d[0..n-2]`.
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: huahelu a puni i `v`);a
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (pololei ka helu hope loa).
        //
        // hoʻomaikaʻi ka lua o nā kūlana i `2 * mant <= scale`.
        // ke hoʻoponopono nei i nā invariants ma nā ʻōlelo o `mant`, `low` a me `high` e hāʻawi i kahi mana maʻalahi o ke kūlana mua: `-plus < mant < minus`.
        // mai ka `-plus < 0 <= mant`, loaʻa iā mākou ka hōʻike pōkole pololei loa ke `mant < minus` a me `2 * mant <= scale`.
        // (lilo ka mua i `mant <= minus` ke kūlike ka mantissa kumu.)
        //
        // ke paʻa ʻole ka lua (`2 * mant> pālākiō), pono mākou e hoʻonui i ka huahelu hope loa.
        // ua lawa kēia no ka hoʻihoʻi ʻana i kēlā kūlana: ʻike ʻē mākou i ka hanauna kikoʻī e hōʻoiaʻiʻo iā `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // i kēia hihia, lilo ke kūlana mua i `-plus < mant - scale < minus`.
        // mai `mant < scale` ma hope o ka hanauna, aia iā `scale < mant + plus`.
        // (hou, lilo kēia i `scale <= mant + plus` ke kūlike ka mantissa kumu.)
        //
        // i ka pōkole:
        // - kū a hoʻopuni iā `down` (mālama i nā helu e like me) ke `mant < minus` (a i ʻole `<=`).
        // - kū a kāwili iā `up` (e hoʻonui i ka huahelu hope) ke `scale < mant + plus` (a i ʻole `<=`).
        // - hoʻomau i ka hana ʻana i kahi ʻē aʻe.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // Loaʻa iā mākou kahi hōʻike pōkole loa, e hele i ka pōʻaiapuni

        // hoʻihoʻi hou i ka poʻe hoʻolale.
        // hana kēia i ka algorithm hoʻopau mau: `minus` a me `plus` mau ka hoʻonui, akā `mant` ua kāʻei ʻia modulo `scale` a paʻa `scale`.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // hana ʻia ke ʻōwili ʻana inā i) ʻo ke ʻano hoʻopuni wale nō ka mea i hoʻomaka ʻia, a i ʻole ii) hoʻonāuki ʻia nā kūlana ʻelua a hoʻopaʻa ʻia ka uhaʻi i ka haʻihaʻi.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // inā hoʻololi ka hoʻopuni ʻana i ka lōʻihi, pono e hoʻololi i ka exponent.
        // me he mea paʻakikī loa kēia ʻano e hōʻoluʻolu (hiki ʻole paha), akā ke palekana nei mākou a kū mau ma aneʻi.
        //
        // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ʻO ka hoʻokō pololei a paʻa hoʻi no ka Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // kuhi `k_0` mai nā huakomo kumu i māʻona ai `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // mahele i `mant` e `10^k`.i kēia manawa `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // hoʻoponopono inā `mant + plus >= scale`, kahi `plus / scale = 10^-buf.len() / 2`.
    // i mea e mālama ai i ka bignum nui i hoʻopaʻa ʻia, hoʻohana maoli mākou i `mant + floor(plus) >= scale`.
    // ʻaʻole mākou e hoʻololi maoli iā `scale`, ʻoiai hiki iā mākou ke lele i ka hoʻonui mua ma kahi.
    // hou me ka algorithm pōkole loa, hiki i `d[0]` ke ʻole akā e hoʻopuni ʻia.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // kūlike i ka scaling `scale` e 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // inā mākou e hana nei me ka palena helu hope loa, pono mākou e hoʻopōkole i ka buffer ma mua o ka hāʻawi maoli ʻana i mea e pale ai i ka hoʻopālua ʻana.
    //
    // e hoʻomaopopo he pono mākou e hoʻonui hou i ka buffer ke hele a puni ka hanana.
    let mut len = if k < limit {
        // auwē, ʻaʻole hiki iā mākou ke hana i kahi hua paʻi *hoʻokahi*.
        // hiki nō kēia ke, ke, loaʻa iā mākou kahi mea e like me 9.5 a ke hoʻopuni ʻia nei i 10.
        // hoʻihoʻi mākou i kahi pale pale hakahaka, me ka ʻokoʻa o ka hihia hoʻopuni puni aʻe e kū nei i ka wā `k == limit` a pono e hana i hoʻokahi kikoʻī.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` no ka hanauna huahelu.
        // (He pipiʻi paha kēia, no laila mai helu ʻoe iā lākou ke hakahaka ke buffer.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // Ma hope o nā helu he zero nā, pau mākou ma aneʻi mai *mai* hoʻāʻo e hana i ke kaʻapuni ʻana.akā, e hoʻopiha i nā helu i koe.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ke hoʻopuni nei inā kū mākou i ka waena o nā huahelu inā he 5000 mau mau helu aʻe ..., e nānā i ka hua helu mua a hoʻāʻo e hoʻopuni i (ʻo ia hoʻi, pale i ka hoʻopuni ʻana ke kūlike ka helu mua).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` hoʻomaka mua ʻia.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // inā hoʻololi ka hoʻopuni ʻana i ka lōʻihi, pono e hoʻololi i ka exponent.
        // akā ua noi ʻia mākou i kahi helu paʻa o nā helu, no laila mai hoʻololi i ka buffer ...
        // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ke ʻole mākou e noi ʻia i ke kikoʻī paʻa.
            // pono mākou e nānā i kēlā, inā nele ka buffer kumu, hiki ke hoʻohui wale ʻia ka helu hou ke `k == limit` (edge case).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: ua hoʻomaka mākou i kēlā hoʻomanaʻo ma luna.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}