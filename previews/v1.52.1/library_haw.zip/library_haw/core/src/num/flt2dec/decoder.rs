//! Hoʻohālikelike i kahi helu lana lana i nā ʻāpana pākahi a me nā pae kuhi hewa.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Ua hoʻopau ʻia ka waiwai palena ʻole i hoʻopaʻa inoa ʻia, e like me:
///
/// - Ua like ka waiwai kumu me `mant * 2^exp`.
///
/// - Kekahi helu mai `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` e pōʻaiapuni i ka waiwai kumu.
/// Hoʻokomo wale ʻia ka pae i ka `inclusive` ʻo `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// ʻO ka mantissa i hoʻonui ʻia.
    pub mant: u64,
    /// Ka pae hema haʻahaʻa.
    pub minus: u64,
    /// Ka pae hema kiʻekiʻe.
    pub plus: u64,
    /// ʻO ka exponent kaʻana like i ka waihona 2.
    pub exp: i16,
    /// ʻOiaʻiʻo ke hoʻopili ʻia ka pae hewa.
    ///
    /// I ka IEEE 754, he ʻoiaʻiʻo kēia i ka wā a ke kumu kumu mantissa.
    pub inclusive: bool,
}

/// Ua hoʻopau ʻia ka waiwai i ʻole inoa ʻia.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, maikaʻi a maikaʻi ʻole paha.
    Infinite,
    /// ʻO Zero, maikaʻi a maikaʻi ʻole paha.
    Zero,
    /// Hoʻopau nā helu me nā kahua decoded hou aʻe.
    Finite(Decoded),
}

/// ʻO kahi ʻano lana lana e hiki ai ke `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// ʻO ka palena palena palena palena palena iki maikaʻi kūpono.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Hoʻihoʻi i kahi hōʻailona (ʻoiaʻiʻo ke maikaʻi ʻole) a me ka waiwai `FullDecoded` mai ka helu helu lana i hāʻawi ʻia.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // hoalauna: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode mālama mau i ka exponent, no laila hoʻonui ʻia ka mantissa no nā subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // hoalauna: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kahi maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // hoalauna: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}