/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ʻoiai e kākau nui ʻia kēia, aia ia i kahi pilikino pilikino e hoʻolaha wale ʻia no ka hoʻāʻo ʻana.
// mai hōʻike iā mākou.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Nā algorithms hanauna Digit.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Ka palena iki o ka buffer e pono ai no ke ʻano pōkole loa.
///
/// He mea liʻiliʻi ʻole ia e kiʻi ai, akā ʻo kēia kahi me ka helu nui o nā helu kikoʻī kikoʻī mai ka hoʻopili ʻana i nā algorithms me ka hopena pōkole loa.
///
/// ʻO `ceil(# bits in mantissa * log_10 2 + 1)` ke kumuhana kikoʻī.
pub const MAX_SIG_DIGITS: usize = 17;

/// Ke loaʻa nā helu kekimala i `d`, e hoʻonui i ka huahelu hope loa a hoʻolaha i ka hāpai ʻana.
/// Hoʻihoʻi i kahi huahelu aʻe ke kumu e loli ai ka lōʻihi.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] he nines āpau
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 puni i 1000..000 me ka exponent hoʻonui
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // puni ka buffer hakahaka (ʻano ʻē a ʻano kūpono paha)
            Some(b'1')
        }
    }
}

/// Nā ʻāpana i hōʻano ʻia.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Hāʻawi ʻia ka helu o nā helu ʻole.
    Zero(usize),
    /// ʻO kahi helu maoli a i 5 mau helu.
    Num(u16),
    /// Kope kope o nā bytes i hāʻawi ʻia.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Hoʻihoʻi i ka lōʻihi byte o ka ʻāpana i hāʻawi ʻia.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Kākau i kahi ʻāpana i ka pale i hoʻolako ʻia.
    /// Hoʻihoʻi i ka helu o nā bytes i kākau ʻia, a i ʻole `None` inā ʻaʻole lawa ka buffer.
    /// (E waiho hapa paha ia i nā bytes i ka buffer; mai paulele i kēlā.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Ka hopena i hōʻano ʻia me hoʻokahi a ʻoi paha nā ʻāpana.
/// Hiki ke kākau ʻia kēia i ka buffer byte a i hoʻohuli ʻia i ke aho i hoʻokaʻawale ʻia.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// ʻO kahi ʻāpana byte e hōʻike ana i kahi hōʻailona, ʻo `""` paha, `"-"` a i ʻole `"+"`.
    pub sign: &'static str,
    /// E hāʻawi ʻia nā ʻāpana i hoʻohina ʻia ma hope o kahi hōʻailona a me ka pale ʻole o ke koho.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Hoʻoiho i ka lōʻihi byte o ka hopena i hoʻopili ʻia i hoʻopili ʻia.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Kākau i nā ʻāpana i hoʻopaʻa ʻia i loko o ka pale pale i hoʻolako ʻia.
    /// Hoʻihoʻi i ka helu o nā bytes i kākau ʻia, a i ʻole `None` inā ʻaʻole lawa ka buffer.
    /// (E waiho hapa paha ia i nā bytes i ka buffer; mai paulele i kēlā.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Hāʻawi ʻia nā palapala i nā helu kekimala `0.<...buf...> * 10^exp` i ka palapala kekala me ka hapa liʻiliʻi i hāʻawi ʻia i nā helu haʻihaʻi.
///
/// Mālama ʻia ka hopena i nā lālani ʻāpana i hoʻolako ʻia a hoʻihoʻi ʻia kahi ʻāpana o nā ʻāpana i kākau ʻia.
///
/// `frac_digits` hiki ke emi ma mua o ka helu o nā helu hakina maoli i `buf`;
/// e nānā ʻole ʻia ia a paʻi ʻia nā helu piha.Hoʻohana wale ʻia ia e paʻi i nā zero hou aʻe ma hope o nā helu i hāʻawi ʻia.
/// No laila ʻo `frac_digits` o 0 ka manaʻo e paʻi ia i nā huahelu i hāʻawi ʻia a ʻaʻohe mea ʻē aʻe.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // inā aia ka palena ma ke kūlana helu hope loa, manaʻo ʻia ʻo `buf` e waiho-waiho ʻia me nā nū virtual.
    // ʻo ka helu o nā zero zero, `nzeroes`, like ia me `max(0, exp + frac_digits - buf.len())`, no laila ʻaʻole i ʻoi aku ke kūlana o ka helu `exp - buf.len() - nzeroes` ma mua o `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |na nol |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ua helu pākahi ʻia no kēlā me kēia hihia i mea e hōʻalo ai i ka hoʻonui ʻana.
    //

    if exp <= 0 {
        // ʻo ka kiko decimal ka mea ma mua o nā helu. [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // aia ka kiko decimal i loko o nā helu. [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // SAFETY: ua hoʻomaka mua mākou i nā mea `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: ua hoʻomaka mua mākou i nā mea `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // aia ka kiko decimal ma hope o nā helu i hāʻawi ʻia: [1234][____0000] a i ʻole [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // SAFETY: ua hoʻomaka mua mākou i nā mea `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: ua hoʻomaka mua mākou i nā mea `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Hōʻike i nā helu kekimaka `0.<...buf...> * 10^exp` i hāʻawi ʻia i loko o ka palapala exponential me ka liʻiliʻi i hāʻawi ʻia i nā helu nui.
///
/// Ke `upper` ka `true`, e hoʻolaha ʻia ka exponent e `E`;a i ʻole ʻo `e` kēlā.
/// Mālama ʻia ka hopena i nā lālani ʻāpana i hoʻolako ʻia a hoʻihoʻi ʻia kahi ʻāpana o nā ʻāpana i kākau ʻia.
///
/// `min_digits` hiki ke emi ma mua o ka helu o nā helu nui maoli i `buf`;
/// e nānā ʻole ʻia ia a paʻi ʻia nā helu piha.Hoʻohana wale ʻia ia e paʻi i nā zero hou aʻe ma hope o nā helu i hāʻawi ʻia.
/// No laila, `min_digits == 0` ke ʻano e paʻi wale ia i nā helu i hāʻawi ʻia a ʻaʻohe mea ʻē aʻe.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // pale i ka underflow ke exp ʻo i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // SAFETY: ua hoʻomaka mua mākou i nā mea `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Nā koho hōʻaʻo hōʻailona.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Paʻi `-` wale nō no nā waiwai maikaʻi ʻole zero.
    Minus, // -inf -1 0 0 1 inf nan
    /// Paʻi `-` wale nō no nā waiwai kūpono ʻole (e like me ka ʻole zero).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Nā paʻi `-` no nā koina ʻole-ʻole maikaʻi ʻole, a i ʻole `+` i kahi ʻē aʻe.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Nā paʻi `-` no nā waiwai maikaʻi ʻole (me ka zero maikaʻi ʻole), a i ʻole `+` i kahi ʻē aʻe.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// E hoʻihoʻi i ka string byte static e pili ana i ka hōʻailona e hōʻano ʻia.
/// Hiki iā `""`, `"+"` a i ʻole `"-"` paha.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Hōʻike i ka helu helu lana i hāʻawi ʻia i ka palapala decimal me ka helu o nā helu haʻihaʻi i hāʻawi ʻia.
/// Mālama ʻia ka hopena i nā ʻāpana o nā ʻāpana i hoʻolako ʻia me ka hoʻohana ʻana i ka buffer byte ma ke ʻano he ʻō.
/// `upper` hoʻohana ʻole ʻia i kēia manawa akā ua waiho no ka hoʻoholo future e hoʻololi i ka hihia o nā koina palena ʻole, ʻo ia hoʻi, `inf` a me `nan`.
///
/// ʻO ka ʻāpana mua e hāʻawi ʻia he `Part::Sign` mau (kahi hiki ke lilo i kahi kaula hakahaka ke hāʻawi ʻole ʻia kahi hōʻailona).
///
/// `format_shortest` pono ia i ke kumumanaʻo o ka hanauna huahelu kumu.
/// Pono e hoʻihoʻi i ka ʻāpana o ka buffer i hoʻokumu ʻia.
/// Makemake paha ʻoe iā `strategy::grisu::format_shortest` no kēia.
///
/// `frac_digits` hiki ke emi ma mua o ka helu o nā helu hakina maoli i `v`;
/// e nānā ʻole ʻia ia a paʻi ʻia nā helu piha.Hoʻohana wale ʻia ia e paʻi i nā zero hou aʻe ma hope o nā helu i hāʻawi ʻia.
/// No laila ʻo `frac_digits` o 0 ka manaʻo e paʻi ia i nā huahelu i hāʻawi ʻia a ʻaʻohe mea ʻē aʻe.
///
/// ʻO ka buffer byte ma ka liʻiliʻi `MAX_SIG_DIGITS` bytes ka lōʻihi.
/// E loaʻa ma kahi o 4 mau ʻāpana, no ka hihia ʻoi loa e like me `[+][0.][0000][2][0000]` me `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Hōʻike i ka helu wahi lana lana i ka palapala decimal a i ʻole ka palapala exponential, kaukaʻi ʻia i ka exponent hopena.
/// Mālama ʻia ka hopena i nā ʻāpana o nā ʻāpana i hoʻolako ʻia me ka hoʻohana ʻana i ka buffer byte ma ke ʻano he ʻō.
/// `upper` Hoʻohana ʻia e hoʻoholo ai i ka hihia o nā helu palena ʻole (`inf` a me `nan`) a i ʻole ka hihia o ka unuhi mua (`e` a i ʻole `E`).
/// ʻO ka ʻāpana mua e hāʻawi ʻia he `Part::Sign` mau (kahi hiki ke lilo i kahi kaula hakahaka ke hāʻawi ʻole ʻia kahi hōʻailona).
///
/// `format_shortest` pono ia i ke kumumanaʻo o ka hanauna huahelu kumu.
/// Pono e hoʻihoʻi i ka ʻāpana o ka buffer i hoʻokumu ʻia.
/// Makemake paha ʻoe iā `strategy::grisu::format_shortest` no kēia.
///
/// ʻO ka `dec_bounds` kahi tuple `(lo, hi)` e like me ka helu ʻana o ka helu i kekelima wale nō ke `10^lo <= V < 10^hi`.
/// E hoʻomaopopo ʻo kēia ka *maopopo*`V` ma kahi o ka `v` maoli!Pēlā ʻaʻole hiki i kekahi exponent i paʻi ʻia i ka palapala exponential i kēia pae, e pale ana i kahi huikau.
///
///
/// ʻO ka buffer byte ma ka liʻiliʻi `MAX_SIG_DIGITS` bytes ka lōʻihi.
/// Aia ma kahi o 6 mau ʻāpana i loaʻa, no ka hihia ʻoi loa e like me `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Hoʻihoʻi i kahi kokoke i ka crude (luna i luna) no ka nui o ka buffer nui i helu ʻia mai ka exponent decoded i hāʻawi ʻia.
///
/// ʻO ka palena kikoʻī:
///
/// - i ka `exp < 0`, ʻo ka lōʻihi o ka lōʻihi `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - i ka `exp >= 0`, ʻo ka lōʻihi o ka lōʻihi `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` ʻoi aku ka liʻiliʻi ma mua o `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, a ʻo ka mea i emi ma lalo o `20 + (1 + exp* log_10 x)`.
/// Hoʻohana mākou i nā ʻoiaʻiʻo `log_10 2 < 5/16` a me `log_10 5 < 12/16`, i lawa no kā mākou kumu.
///
/// No ke aha mākou e pono ai i kēia?E hoʻopihapiha nā hana `format_exact` i ka buffer holoʻokoʻa ke ʻole i kaupalena ʻia e ka palena o ka helu hope loa, akā hiki nō paha i ka helu o nā huahelu i noi ʻia he nui hoʻomākeʻaka (e ʻōlelo, 30,000 mau helu).
///
/// E hoʻopiha ʻia ka hapanui o ka buffer me nā zero, no laila ʻaʻole mākou makemake e hoʻokaʻawale i nā pale āpau ma mua.
/// No laila, no nā manaʻo paio i hāʻawi ʻia,
/// Pono e lawa nā 826 bytes o buffer no `f64`.Hoʻohālikelike i kēia me ka helu maoli no ka hihia ʻoi loa: 770 bytes (ke `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Hāʻawi ʻia nā palapala i ka helu lana lana i loko o ka palapala exponential me nā helu kikoʻī i hāʻawi ʻia.
/// Mālama ʻia ka hopena i nā ʻāpana o nā ʻāpana i hoʻolako ʻia me ka hoʻohana ʻana i ka buffer byte ma ke ʻano he ʻō.
/// `upper` Hoʻohana ʻia e hoʻoholo ai i ka hihia o ka preonent nauna (`e` a i ʻole `E`).
/// ʻO ka ʻāpana mua e hāʻawi ʻia he `Part::Sign` mau (kahi hiki ke lilo i kahi kaula hakahaka ke hāʻawi ʻole ʻia kahi hōʻailona).
///
/// `format_exact` pono ia i ke kumumanaʻo o ka hanauna huahelu kumu.
/// Pono e hoʻihoʻi i ka ʻāpana o ka buffer i hoʻokumu ʻia.
/// Makemake paha ʻoe iā `strategy::grisu::format_exact` no kēia.
///
/// ʻO ka buffer byte ma ka liʻiliʻi `ndigits` bytes ka lōʻihi ke ʻole ʻo `ndigits` nui a kākau ʻia ka helu paʻa o nā helu.
/// (ʻO ke kiko kiko no `f64` ma kahi o 800, no laila ua lawa nā byte 1000.) Aia ma kahi o 6 mau ʻāpana i loaʻa, no ka hihia maikaʻi loa e like me `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Hāʻawi ʻia nā palapala i ka helu lana lana i ka palapala decimal me ka helu kikoʻī o nā hua helu.
/// Mālama ʻia ka hopena i nā ʻāpana o nā ʻāpana i hoʻolako ʻia me ka hoʻohana ʻana i ka buffer byte ma ke ʻano he ʻō.
/// `upper` hoʻohana ʻole ʻia i kēia manawa akā ua waiho no ka hoʻoholo future e hoʻololi i ka hihia o nā koina palena ʻole, ʻo ia hoʻi, `inf` a me `nan`.
/// ʻO ka ʻāpana mua e hāʻawi ʻia he `Part::Sign` mau (kahi hiki ke lilo i kahi kaula hakahaka ke hāʻawi ʻole ʻia kahi hōʻailona).
///
/// `format_exact` pono ia i ke kumumanaʻo o ka hanauna huahelu kumu.
/// Pono e hoʻihoʻi i ka ʻāpana o ka buffer i hoʻokumu ʻia.
/// Makemake paha ʻoe iā `strategy::grisu::format_exact` no kēia.
///
/// Pono ka buffer byte no ka hoʻopuka ʻana ke ʻole ʻo `frac_digits` nui loa e kākau wale ʻia ka helu paʻa o nā helu.
/// (ʻO ke kiko kiko no `f64` ma kahi o 800, a ua lawa nā byte 1000.) Aia ma kahi o 4 mau ʻāpana i loaʻa, no ka hihia ʻoi loa e like me `[+][0.][0000][2][0000]` me `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // hiki paha iā `frac_digits` ke henehene nui.
            // `format_exact` e pau ka hāʻawi ʻana i nā helu ma mua o kēia hihia, no ka mea, kaupalena ʻia mākou e `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ʻAʻole hiki ke hoʻokō ʻia ke kapu, no laila hāʻawi kēia e like me ka ʻole `exp`.
                // ʻaʻole pili kēia i ka hihia i hoʻokō ʻia ka palena kapu ma hope o ke kaʻina hope loa;he hihia maʻamau me `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // SAFETY: ua hoʻomaka mua mākou i nā mea `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // SAFETY: ua hoʻomaka mua mākou i nā mea `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}