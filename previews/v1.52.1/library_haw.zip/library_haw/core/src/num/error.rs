//! Nā ʻano kuhi hewa no ka hoʻololi ʻana i nā ʻano hoʻohui.

use crate::convert::Infallible;
use crate::fmt;

/// Ua hoʻi ka ʻano hewa ke holo pono ʻole kahi huli ʻano ʻano integral.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Pākuʻi ma mua o ka coerce e hōʻoia i kēlā code e like me `From<Infallible> for TryFromIntError` ma luna e hoʻomau i ka hana ke lilo ʻo `Infallible` i kahi inoa i `!`.
        //
        //
        match never {}
    }
}

/// He kuhi hewa i hiki ke hoʻihoʻi ʻia i ka wā e ʻoki nei i ka integer.
///
/// Hoʻohana ʻia kēia hemahema e like me ke ʻano hemahema no nā hana `from_str_radix()` ma nā ʻano integer primitive, e like me [`i8::from_str_radix`].
///
/// # Nā kumu kūpono
///
/// Ma waena o nā kumu ʻē aʻe, hiki ke kiola ʻia ʻo `ParseIntError` ma muli o ke alakaʻi ʻana a i ʻole ke kuhi ʻana i ke keʻokeʻo i ke aho e laʻa, ke loaʻa ia mai ke komo maʻamau.
///
/// Ke hoʻohana nei i ka hana [`str::trim()`] e hōʻoia i ka waiho ʻole o kahi keʻokeʻo ma mua o ka pā ʻana.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum e mālama i nā ʻano ʻano hewa like ʻole e hiki ai ke holo pono i ka hoʻopili ʻana i ka integer.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Hakahaka ka helu ʻia ʻana.
    ///
    /// Ma waena o nā kumu ʻē aʻe, e kūkulu ʻia kēia ʻano ʻē ke kīnā i kahi kaula hakahaka.
    Empty,
    /// Loaʻa nā hua paʻi kūpono ʻole i kāna pōʻaiapili.
    ///
    /// Ma waena o nā kumu ʻē aʻe, e kūkulu ʻia kēia ʻano ʻē ke kīnā i kahi kaula i loaʻa kahi char ASCII ʻole.
    ///
    /// Kūkulu ʻia kēia ʻano ʻē ke kuhi hewa ʻia kahi `+` a i ʻole `-` i loko o kahi kaula iā ia iho a i ʻole ma waena o kahi helu.
    ///
    ///
    InvalidDigit,
    /// Nui loa ka integer e mālama ai i ka integer type.
    PosOverflow,
    /// Heʻuʻuku ʻo Integer e mālama i ka integer type.
    NegOverflow,
    /// ʻO Zero ka waiwai
    ///
    /// E hoʻokuʻu ʻia kēia ʻano ʻē ke loaʻa ka waiwai o ke string parsing i kahi zero, kahi kūpono ʻole ia no nā ʻano non-zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Hoʻopuka i nā kumu kikoʻī o ka haʻi ʻana i kahi helu o ka helu.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}