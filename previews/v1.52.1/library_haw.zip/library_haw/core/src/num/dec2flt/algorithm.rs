//! ʻO nā algorithms like ʻole mai ka pepa.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Ka helu o nā mea nui i Fp
const P: u32 = 64;

// Mālama wale mākou i ka hoʻokokoke loa no *nā mea a pau* exponents, no laila hiki ke haʻalele ʻia ka loli "h" a me nā kūlana pili.
// Kūʻai kēia hana i kekahi kilobytes o kahi.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I ka hapanui o nā kuhikuhipuʻuone, he wahi kikoʻī kā ka pae lana e lana ana, no laila ua hoʻoholo ʻia ka kikoʻī o ka helu ma kēlā me kēia hana.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ma x86, hoʻohana ʻia ka x87 FPU no nā hana lana inā ʻaʻole loaʻa nā mea hoʻonui SSE/SSE2.
// Hana ka x87 FPU me 80 mau kikoʻī o ke kikoʻī ma o ka paʻamau, ʻo ia hoʻi e hoʻopuni nā hana i 80 mau ʻāpana e hana ana i ka pālua ʻana ke koho ʻia nā waiwai ma hope.
//
// 32/64 lana waiwai.I mea e lanakila ai i kēia, hiki ke hoʻonohonoho ʻia ka ʻōlelo mana FPU i mea e hoʻokō ʻia ai nā helu i ka kikoʻī i makemake ʻia.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Hoʻohana ʻia kahi hale e mālama i ka waiwai kumu o ka mana hoʻomalu ʻo FPU, i hiki ai iā ia ke hoʻihoʻi hou ke waiho ʻia ka hale.
    ///
    ///
    /// ʻO ka x87 FPU kahi 16-bits register a nona nā kahua penei:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Loaʻa nā palapala no nā māla āpau i ka IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// ʻO ka māla wale nō e pili ana no kēia code ʻo PC, ka Mīkini Mīkini.
    /// Hoʻoholo kēia kahua i ka kikoʻī o nā hana i hana ʻia e ka FPU.
    /// Hiki ke hoʻonohonoho ʻia i:
    ///  - 0b00, hoʻokahi kikoʻī kikoʻī, 32-ʻāpana
    ///  - 0b10, pālua pono ʻo ia hoʻi, 64-ʻāpana
    ///  - 0b11, pālua i hoʻonui ʻia me ka pololei ie, 80-ʻāpana (kūlana paʻamau) Ua mālama ʻia ka waiwai 0b01 a ʻaʻole pono e hoʻohana.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: ua hōʻoia ʻia ke aʻo `fldcw` i hiki ke hana pololei me
        // kekahi `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Ke hoʻohana nei mākou i ka syntax ATT e kākoʻo iā LLVM 8 a me LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Hoʻonohonoho i ke kahua kikoʻī o ka FPU iā `T` a hoʻihoʻi i `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // E helu i ka waiwai no ka māla Precision Control e kūpono no `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 mau ʻāpana
            8 => 0x0200, // 64 ʻāpana
            _ => 0x0300, // paʻamau, 80 ʻāpana
        };

        // E kiʻi i ka waiwai kumu o ka ʻōlelo hoʻomalu e hoʻihoʻi iā ia ma hope, ke hāʻule ka hanana `FPUControlWord` SAFETY: ua hōʻoia ʻia ke aʻo `fnstcw` i hiki ke hana pololei me kekahi `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Ke hoʻohana nei mākou i ka syntax ATT e kākoʻo iā LLVM 8 a me LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // E hoʻonoho i ka ʻōlelo hoʻomalu i ke kikoʻī i makemake ʻia.
        // Loaʻa kēia i ka pale ʻana i ka miomio kahiko (bits 8 a me 9, 0x300) a hoʻololi iā ia me ka hae kikoʻī i helu ʻia ma luna.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ke ala wikiwiki o Bellerophon e hoʻohana nei i nā integers a me nā lana o ka mīkini.
///
/// Lawe ʻia kēia i kahi hana kaʻawale i hiki ke hoʻāʻo ʻia ma mua o ke kūkulu ʻana i kahi bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Hoʻohālikelike mākou i ka waiwai kikoʻī iā MAX_SIG kokoke i ka hopena, he hōʻole wikiwiki wale kēia (a hoʻokuʻu hoʻi i ke koena o ke code mai ka hopohopo e pili ana i ka wai kahe.
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Pili ke ala wikiwiki i ka helu i hoʻopuni ʻia i ka helu pono o nā ʻāpana me ka ʻole o ka hoʻopuni waena.
    // Ma x86 (me ka ʻole o SSE a i ʻole SSE2) koi kēia i ka kikoʻī o ka x87 FPU stack e hoʻololi ʻia a laila ʻōwili pololei ia i ka 64/32 bit.
    // Mālama ka hana `set_precision` i ka hoʻonohonoho ʻana i ke kikoʻī i nā kuhikuhipuʻuone e koi ai e hoʻonohonoho iā ia e ka hoʻololi ʻana i ka mokuʻāina honua (e like me ka ʻōlelo hoʻomalu o ka x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // ʻAʻole hiki ke pelu ʻia ka hihia e <0 i loko o ka branch ʻē aʻe.
    // Nā hopena maikaʻi ʻole e hopena i kahi ʻāpana haʻihaʻi i ka binary, i hoʻopuni ʻia, a ʻo ia ke kumu o nā hewa maoli (a me kekahi manawa a koʻikoʻi paha!) I ka hopena.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// ʻO Algorithm Bellerophon kahi code trivial i hoʻāpono ʻia e ka hōʻuluʻulu helu helu ʻole.
///
/// Hoʻopuni ia `` f '' i kahi lana me 64 iki kiko nui a hoʻonui iā ia e ka hoʻokokoke ʻoi loa o `10^e` (i ke ʻano lana lana like).Lawa pinepine kēia e loaʻa ai ka hopena pololei.
/// Eia nō naʻe, ke kokoke ka hopena i ka hapalua ma waena o nā lana (ordinary) e pili ana, ua hewa ka pōʻai puni ʻana mai ka hoʻonui ʻana i ʻelua mau hoʻokokoke ʻana no ka hopena o kekahi mau ʻāpana.
/// Ke kū kēia, hoʻoponopono ka Algorithm R iterative i nā mea i luna.
///
/// Hana pololei ʻia ka lima Wavy "close to halfway" e ka hoʻopili helu ʻana i ka pepa.
/// I nā ʻōlelo a Clinger:
///
/// > Slop, i hōʻike ʻia i loko o nā anakuhi o ka liʻiliʻi nui, kahi paʻa i paʻa ʻia no ka hewa
/// > i hōʻiliʻili ʻia i ka helu helu lana o ka hoʻokokoke ʻana i f * 10 ^ e.(ʻO Slop kahi
/// > ʻaʻole i nakinaki ʻia no ka hewa maoli, akā palena i ka ʻokoʻa ma waena o ka hoʻokokoke ʻana z a me
/// > ka hoʻokokoke hiki loa ke hoʻohana i nā ʻāpana p o###and.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // ʻO nā hihia abs(e) <log5(2^N) ma fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ua lawa anei ka pahee e hiki ai ke hoʻololi i ke kaʻapuni ʻana i nā n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// He hāmeʻa iterative e hoʻomaikaʻi i kahi kiko lana o `f * 10^e`.
///
/// Loaʻa i kēlā me kēia iteration hoʻokahi anakahi ma kahi hope loa, kahi e lōʻihi loa ai ke hui pū inā `z0` ua pio mālie.
/// Laki, ke hoʻohana ʻia me he fallback no Bellerophon, hoʻopau ʻia ka hoʻomaka hoʻomaka ʻana e ka hapanui o kahi ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // E ʻike i nā helu helu maikaʻi `x`, `y` e like me `x / y` kikoʻī `(f *10^e) / (m* 2^k)`.
        // Hōʻalo wale kēia i ka hana ʻana i nā hōʻailona o `e` a me `k`, hoʻopau pū mākou i ka mana o ʻelua maʻamau i `10^e` a me `2^k` e hoʻoliʻiliʻi i nā helu.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Kākau iki ʻia kēia mea no ka mea ʻaʻole kākoʻo kā mākou bignums i nā helu maikaʻi ʻole, no laila mākou e hoʻohana nei i ka waiwai piha + ʻike ʻike.
        // ʻAʻole hiki ke hoʻonui i ka hoʻonui ʻana me nā m_digits.
        // Inā nui ka `x` a i ʻole `y` a mākou e pono ai e hopohopo e pili ana i ka hoʻoheheʻe ʻana, a laila nui nō lākou i hōʻemi ʻia e `make_ratio` ka hakina e ka helu o 2 ^ 64 a ʻoi paha.
        //
        //
        let (d2, d_negative) = if x >= y {
            // ʻAʻole pono ʻoe x hou aku, e mālama i clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Eia nō naʻe y, e hana kope.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Hāʻawi ʻia ʻo `x = f` a me `y = m` ma kahi o `f` e hōʻike ai i nā helu kekimala komo e like me ka maʻamau a ʻo `m` ke kikoʻī o kahi kiko lana e hoʻokokoke ana, e hoʻohālikelike i ka lakio `x / y` me `(f *10^e) / (m* 2^k)`, e hoʻoliʻiliʻi ʻia paha e ka mana o ʻelua.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, koe wale nō e hoʻemi mākou i ka hakina me kekahi mana o ʻelua.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m ʻAʻole hiki i kēia ke huakaʻi no ka mea pono ka `e` maikaʻi a me ka `k` maikaʻi ʻole, kahi e hiki ai ke pili no nā waiwai kokoke loa i ka 1, ʻo ia hoʻi `e` a me `k` e liʻiliʻi ana.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k ʻAʻole hiki i kēia ke hoʻonui pū, e ʻike ma luna.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), e hoʻemi hou nei i ka mana maʻamau o ʻelua.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// No ka noʻonoʻo ʻana, ʻo Algorithm M ke ala maʻalahi loa e hoʻololi i kahi kekelima i kahi lana.
///
/// Hana mākou i kahi lakio i like ia me `f * 10^e`, a laila hoʻolei i nā mana o ʻelua a hiki i ka hāʻawi ʻana i kahi float kikoʻī kūpono.
/// ʻO ka exponent binary `k` ka helu o nā manawa a mākou i hoʻonui ai i ka helu a i ʻole denominator e nā ʻelua, ʻo ia hoʻi, i nā manawa āpau `f *10^e` like ia me `(u / v)* 2^k`.
/// Ke loaʻa iā mākou ka mahu, pono mākou e hoʻopuni i ka nānā ʻana i ke koena o ka mahele, i hana ʻia i nā hana kōkua ma lalo aʻe.
///
///
/// ʻOi aku ka lohi o kēia algorithm, ʻoiai me ka optimization i wehewehe ʻia ma `quick_start()`.
/// Eia naʻe, ʻo ia ka mea maʻalahi o nā algorithms e hoʻopili no ka overflow, underflow, a me nā hopena subnormal.
/// Lawe kēia hana i ka wā e hoʻokahuli ʻia ai ʻo Bellerophon a me Algorithm R.
/// Maʻalahi ke ʻike ʻana i ka underflow a me ka hoʻoheheʻe ʻana: ʻAʻole nō ka lakio i kahi kikoʻī i loko, akā ua kiʻi ʻia ka minimum/maximum exponent.
/// I ka hihia o ke kahe, hoʻi wale mākou i ka infinity.
///
/// ʻOi aku ka maʻalahi ka lawelawe ʻana i ka underflow a me nā subnormals.
/// ʻO kahi pilikia nui, ʻo ia me ka exponent palena iki, nui loa paha ka lakio no kahi hata.
/// E ʻike iā underflow() no nā kikoʻī.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME hiki optimization: generalize big_to_fp i hiki iā mākou ke hana i ka like o fp_to_float(big_to_fp(u)) ma aneʻi, me ka ʻole o ka pālua ʻana.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Pono mākou e kū ma ka exponent palena iki, inā mākou e kali a hiki i ka `k < T::MIN_EXP_INT`, a laila hele mākou ma kahi o ʻelua.
            // Minamina kēia mea pono mākou e kūikawā-hihia nā helu maʻamau me ka exponent palena iki.
            // FIXME e ʻike i kahi hoʻolālā nani aʻe, akā holo i ka `tiny-pow10` hōʻike e hōʻoia i ka pololei maoli.
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Hōʻalo ma luna o ka hapanui o nā Algorithm M ma ke kaha ʻana i ka lōʻihi iki.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // ʻO ka lōʻihi iki kahi kuhi o ke kumu ʻelua logarithm, a me log(u / v) = log(u), log(v).
    // Pau ka koho ma ka hapanui o 1, akā ma lalo o ke kuhi manaʻo, no laila ʻo ka hemahema ma log(u) a me log(v) o ka hōʻailona like a kāpae (inā nui nā mea ʻelua).
    // No laila ʻo ka hewa no log(u / v) ʻoi aku ma mua o hoʻokahi.
    // ʻO ka lākiō pahuhopu kahi kahi u/v i loko o kahi kiko waena.Pēlā ko mākou kūlana hoʻopau log2(u / v) ʻo ia nā kikoʻī kikoʻī, plus/minus hoʻokahi.
    // FIXME Ke nānā nei i ka lua o ka mea hiki ke hoʻomaikaʻi i ka kuhi a pale i kekahi mau mahele hou aʻe.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Lalo a subnormal paha.E waiho iā ia i ka hana nui.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Kaheʻe.E waiho iā ia i ka hana nui.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // ʻAʻole ka lakio helu kikoʻī kikoʻī me ka exponent palena iki, no laila pono mākou e hoʻopuni i nā mea nui a hoʻomaʻamaʻa i ka exponent e like me.
    // Penei ke ʻano o ka waiwai maoli i kēia manawa:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    ʻoki pū.(pani ʻia e rem)
    //
    // No laila, ke hiki i nā ʻāpana poepoe!= 0.5 ULP, hoʻoholo lākou i ka pōʻaiapuni ma o lākou iho.
    // Ke kūlike lākou a ʻo ka koena non-zero, pono e hoʻopuni ʻia ke kumukūʻai.
    // Aia wale nō ke 1/2 i nā ʻāpana i hoʻopoepoe ʻia a zero ka mea i koe, loaʻa iā mākou kahi hanana hapa-i-like.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// ʻO ka pōʻai maʻamau a i ke kaulike, obfuscated e ka hoʻopuni ʻana ma muli o ke koena o ka mahele.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}