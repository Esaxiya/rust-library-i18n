//! Bit fidling i nā lana IEEE 754 maikaʻi.ʻAʻole pono e lawelawe i nā helu maikaʻi ʻole.
//! Loaʻa nā helu helu lana maʻamau i kahi hōʻike canonical e like me (frac, exp) e like me ka waiwai ʻo 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) kahi N ka helu o nā ʻāpana.
//!
//! ʻOkoʻa iki a ʻano ʻē hoʻi nā Subnormals, akā pili ka mea like.
//!
//! Eia nō naʻe, pani mākou iā lākou ma ke ʻano (sig, k) me f maikaʻi, e like me ka waiwai he f *
//! 2 <sup>e</sup> .Ma waho aʻe o ka wehewehe ʻana i ka "hidden bit", hoʻololi kēia i ka exponent e ka mea i kapa ʻia ʻo mantissa shift.
//!
//! E kau i kahi ala ʻē aʻe, kākau ʻia nā lana maʻamau ma ke ʻano (1) akā eia lākou ke kākau ʻia ma ke ʻano (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kāhea mākou iā (1) i ka **ʻāpana haʻihaʻi** a me (2) i ka **hōʻike hoʻohui**.
//!
//! Hana wale nā hana he nui i kēia module i nā helu maʻamau.Lawe ke kaʻina hana dec2flt i ke ala lohi a pololei-pololei (Algorithm M) no nā helu liʻiliʻi a nui loa.
//! Pono kēlā algorithm next_float() e lawelawe i nā subnormals a me nā zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Kahi mea kōkua trait e hōʻalo i ka hoʻopili pālua ʻana i nā code hoʻololi a pau no `f32` a me `f64`.
///
/// E ʻike i ka ʻōlelo a ka module module makua no ke aha e pono ai kēia.
///
/// ʻAʻole **e hoʻokō ʻia** no nā ʻano ʻē aʻe a i ʻole e hoʻohana ʻia ma waho o ka modula dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// ʻAno i hoʻohana ʻia e `to_bits` a me `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Hana i kahi transmutation maka i ka integer.
    fn to_bits(self) -> Self::Bits;

    /// Hana i kahi transmutation maka mai kahi helu.
    fn from_bits(v: Self::Bits) -> Self;

    /// Hoʻihoʻi i ka mahele i hāʻule ai kēia helu.
    fn classify(self) -> FpCategory;

    /// Hoʻihoʻi i ka mantissa, exponent a kau inoa ma ke ʻano he integers.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Hoʻoholo i ka lana.
    fn unpack(self) -> Unpacked;

    /// Kuhi mai kahi helu liʻiliʻi i hiki ke hōʻike pololei ʻia.
    /// Panic inā ʻaʻole hiki ke hōʻike i ka helu nui, ʻo ka pāʻālua ʻē aʻe i kēia anakuhi e hōʻoia ʻaʻole loa e kū kēlā.
    fn from_int(x: u64) -> Self;

    /// Loaʻa ka waiwai 10 <sup>e</sup> mai ka papa i helu mua ʻia.
    /// Panics no `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ka mea a ka inoa e ʻōlelo ai.
    /// ʻOi aku ka maʻalahi i ka pāʻālua paʻakikī ma mua o ka hoʻopili ʻana i nā intrinsics a me ka lana o ka manaʻo e hoʻopili mau ʻo LLVM iā ia.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ʻO kahi conservative i hoʻopaʻa ʻia ma nā helu kekimaka o nā hoʻokomo i hiki ʻole ke hana i ka overflow a i ʻole ʻole
    /// subnormals.Malia paha ka exponent decimal o ka waiwai maʻamau maʻamau, no laila ka inoa.
    const MAX_NORMAL_DIGITS: usize;

    /// Ke loaʻa ka helu kikoʻī kikoʻī i kahi waiwai i ʻoi aku ma mua o kēia, e hoʻopuni ʻia ka helu i ka palena pau.
    ///
    const INF_CUTOFF: i64;

    /// Ke loaʻa ka helu kikoʻī kikoʻī i ka helu o ka helu ma mua o kēia, e poepoe ʻia ka helu i ka ʻole.
    ///
    const ZERO_CUTOFF: i64;

    /// Ka helu o nā ʻāpana i ka exponent.
    const EXP_BITS: u8;

    /// ʻO ka helu o nā ʻāpana i ke kiko,*me* ka huna huna.
    const SIG_BITS: u8;

    /// ʻO ka helu o nā ʻāpana i ka hata,*kāpae ʻole* i ka huna huna.
    const EXPLICIT_SIG_BITS: u8;

    /// ʻO ka exponent loio kiʻekiʻe loa i ka hōʻike haʻi.
    const MAX_EXP: i16;

    /// ʻO ka exponent loiloi liʻiliʻi loa i ka hōʻike haʻi, koe ʻole nā subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` no ke kūlike ʻana o ka hiʻohiʻona, ʻo ia hoʻi, me ka hoʻololi i noi ʻia.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` hoʻopā'ālua ʻia (ie, me ka hoʻopilikia offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` no ke kūlike ʻana o ka hiʻohiʻona, ʻo ia hoʻi, me ka hoʻololi i noi ʻia.
    const MIN_EXP_INT: i16;

    /// ʻO ka maximumand normalized kiʻekiʻe i ka hoʻohālikelike hoʻohui.
    const MAX_SIG: u64;

    /// ʻO ka palena palena palena pau normalized i ka hoʻohālikelike hoʻohui.
    const MIN_SIG: u64;
}

// ʻO ka hapanui kahi hana no #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Hoʻihoʻi i ka mantissa, exponent a kau inoa ma ke ʻano he integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ʻO bias bias + mantissa hoʻololi
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe maopopo inā `as` puni pono ma nā paepae āpau.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Hoʻihoʻi i ka mantissa, exponent a kau inoa ma ke ʻano he integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ʻO bias bias + mantissa hoʻololi
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe maopopo inā `as` puni pono ma nā paepae āpau.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Hoʻololi i kahi `Fp` i kahi ʻano lana mīkini kokoke loa.
/// ʻAʻole mālama i nā hopena subnormal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ʻo 64 bit, no laila xe loaʻa kahi hoʻololi mantissa o 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// E kolikoli i ka 64 bit iki i ka T::SIG_BITS bits me ka hapalua a i ke ahiahi.
/// ʻAʻole mālama i ka exponent overflow.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Hoʻololi i ka shift mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Huli o `RawFloat::unpack()` no nā helu maʻamau.
/// Panics inā ʻaʻohe kūpono ka signifikan a exponent paha no nā helu maʻamau.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Wehe i kahi huna
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Hoʻololi i ka exponent no ka bias exponent a me ka shift mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // E waiho iki i ka hōʻailona ma 0 ("+"), maikaʻi nā helu a mākou
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Kūkulu i kahi subnormal.ʻAe ʻia kahi mantissa o 0 a kūkulu zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ʻO 0 ka exponent i hoʻopili ʻia, ʻo ka hōʻailona ka 0, no laila pono mākou e wehewehe hou i nā ʻāpana.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// E hoʻokokoke i kahi bignum me kahi Fp.Kuhi ma waena o 0.5 ULP me ka hapalua a ke ahiahi.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ua ʻoki mākou i nā ʻāpana āpau ma mua o ka helu `start`, ʻo ia hoʻi, ke hoʻololi pololei nei mākou e kahi nui o `start`, no laila ʻo kēia ka exponent a mākou e pono ai.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // E kolikoli (half-to-even) ma muli o nā ʻāpana i kī ʻia.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// ʻIke i ka helu helu lana nui loa ma mua o ka paio.
/// ʻAʻole mālama i nā subnormals, ʻole, a i ʻole exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// E ʻike i ka helu wahi lana lana liʻiliʻi loa ma mua o ka paio.
// Hoʻopiha kēia hana, ʻo ia hoʻi, next_float(inf) ==inf.
// ʻAʻole like me ka hapa nui o ke code i kēia module, lawelawe kēia hana i nā zero, nā subnormals, a me nā infinities.
// Eia nō naʻe, e like me nā code ʻē aʻe āpau, ʻaʻole pili ia me NaN a me nā helu maikaʻi ʻole.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Me he mea lā he maikaʻi loa kēia akāʻoiaʻiʻo.
        // 0.0 ua encode ʻia e like me ka huaʻōlelo zero āpau.ʻO nā subnormals he 0x000m ... m kahi o ka mantissa.
        // I ka mea kikoʻī, ʻo ka subnormal ʻoi loa ka 0x0 ... 01 a ʻo ka mea nui he 0x000F ... F.
        // ʻO ka helu maʻamau liʻiliʻi ʻo 0x0010 ... 0, no laila e hana pū ana kēia hihia kihi.
        // Inā hoʻonui ka hoʻonui i ka mantissa, hoʻonui ka lawe i ka exponent e like me kā mākou e makemake ai, a lilo nā ʻāpana mantissa i ʻole.
        // Ma muli o ka ʻaha hūnā hūnā, ʻo kēia nō ka mea a mākou e makemake ai.
        // ʻO ka hope, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}