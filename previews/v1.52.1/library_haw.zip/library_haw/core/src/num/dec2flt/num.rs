//! Nā hana hoʻohana no nā bignums hana ʻole i ke ʻano nui e lilo i ʻano hana.

// FIXME He pōmaikaʻi iki ka inoa o kēia module, ʻoiai lawe mai nā modula ʻē aʻe iā `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// E hoʻāʻo inā he truncating nā ʻāpana āpau i ʻoi aku ka nui ma mua o `ones_place` e hoʻolauna i kahi kuhi hewa i emi iho, like, a ʻoi aku paha ma mua o 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Inā ʻaʻohe nā koena i koe, ʻo ia= 0.5 ULP, a i ʻole> 0.5 Inā ʻaʻohe ʻūlū hou aʻe (half_bit==0), hoʻihoʻi pololei ka lalo i ka Kaulike.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Hoʻohuli i kahi aho ASCII i loaʻa nā kekona kekona wale nō i `u64`.
///
/// ʻAʻole hana i nā kaha no ka overflow a hewa ʻole paha o nā huapalapala, no laila inā ʻaʻole akahele ka mea e kāhea ana, hewa ʻole ka hopena a hiki iā panic (ʻoiai ʻaʻole `unsafe`).
/// Hoʻohui ʻia, mālama ʻia nā kaula kau ʻole ma ke ʻano he ʻole.
/// Aia kēia hana no ka mea
///
/// 1. me ka hoʻohana ʻana i `FromStr` ma `&[u8]` pono iā `from_utf8_unchecked`, maikaʻi ʻole, a
/// 2. ʻOi aku ka paʻakikī o ka hoʻopili ʻana i nā hopena o `integral.parse()` a me `fractional.parse()` ma mua o kēia hana holoʻokoʻa.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Hoʻohuli i kahi aho o nā helu ASCII i loko o kahi bignum.
///
/// E like me `from_str_unchecked`, pili kēia hana i ka parser e hoʻopau i nā helu ʻole.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Unwraps a bignum into a 64 bit integer.Panics inā nui ka helu.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Hoʻopili i kahi laulā o nā ʻāpana.

/// ʻO ka helu helu ʻo 0 ka mea nui nui a ʻo ka pae he hapa hāmama e like me ka mau.
/// Panics inā noi ʻia e huki i nā ʻāpana he nui aʻe ma mua o ke komo i loko o ka ʻano hoʻihoʻi.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}