//! Ke hōʻoia nei a me ka decompose ʻana i kahi string decimal o ke ʻano.
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! I nā huaʻōlelo ʻē aʻe, syntax pae lana maʻamau, me ʻokoʻa ʻelua: ʻAʻohe hōʻailona, a ʻaʻohe lawelawe ʻana o "inf" a me "NaN".Mālama ʻia kēia mau mea e ka hana hoʻokele (super::dec2flt).
//!
//! ʻOiai maʻalahi ka maʻalahi o ka ʻike ʻana i nā hoʻokomo kūpono, pono ʻole kēia module e hōʻole i nā ʻano helu kūpono ʻole he nui, ʻaʻole loa ʻo panic, a hana i nā loiloi he nui i hilinaʻi ʻia nā modula ʻē aʻe ʻaʻole iā panic (a i ʻole overflow) i ka huli.
//!
//! ʻO ka mea i ʻoi aku ka hewa, nā mea āpau āpau i ka pā hoʻokahi ma luna o ka hoʻokomo.
//! No laila, e akahele i ka hoʻololi ʻana i kekahi mea, a nānā pālua me nā modula ʻē aʻe.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Nā ʻāpana hoihoi o kahi kaula decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ʻO ka exponent decimal, hōʻoia ʻia e loaʻa ma lalo o 18 mau helu kekimala.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Nānā inā he helu helu lana kūpono ke aho hoʻokomo a inā pēlā, e ʻimi i ka ʻāpana hoʻohui, ka ʻāpana haʻihaʻi, a me ka exponent i loko.
/// ʻAʻole mālama i nā hōʻailona.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // ʻAʻohe helu ma mua o 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Koi mākou i ka helu hoʻokahi ma mua a ma hope paha o ke kiko.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Hoʻopau i ka ʻōpala ma hope o ka ʻāpana haʻihaʻi
            }
        }
        _ => Invalid, // Hoʻopau i ka ʻōpala ma hope o ke kaula helu mua
    }
}

/// Kālai i nā helu decimal a hiki i ke ʻano hua paʻi huaʻōlelo ʻole.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ʻO ka unuhi exponent a me ka hōʻoia hewa ʻana.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Hoʻopau i ka ʻōpala ma hope o ka exponent
    }
    if number.is_empty() {
        return Invalid; // Hōʻike hakahaka
    }
    // I kēia manawa, loaʻa iā mākou kahi aho o nā helu.Lōʻihi paha ia e hoʻokomo i kahi `i64`, akā inā nui ia, ʻaʻohe a he palena ʻole paha ke komo.
    // Ma muli o ka hoʻololi ʻana o kēlā me kēia nul i nā helu kekimala i ka exponent e +/-1, ma exp=10 ^ 18 he 17 exabyte (!) o nā zeros ke hoʻokomo a hiki i kahi kokoke loa i ka palena.
    //
    // ʻAʻole kēia kahi hoʻohana pono e pono ai mākou e lawelawe.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}