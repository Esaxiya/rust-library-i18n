use crate::future::Future;

/// Huli ana i loko o ka `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// ʻO ka huahana e hoʻopuka ai ka future i ka pau ʻana.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ʻO kēia ʻano future mākou e hoʻohuli ai i kēia?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Hana he future mai ka nui.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}