#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Hōʻike kahi future i kahi helu like ʻole.
///
/// A future mea he waiwai i i pau ole i Me keia manawa.
/// Kēiaʻano o "asynchronous value" ʻo ia ka mea e hiki no i ka pae e hoʻomau hana maikaʻi kēia hana ana e ka iini nui i ka waiwai i loaʻa mai.
///
///
/// # ʻO ka hana `poll`
///
/// ʻO kāna mau 'ōlelo ano o future, `poll`,*ho'āʻo* e hoʻonā i ka future i loko o ka waiwai hope loa.
/// ʻAʻole pāpā kēia hana inā ʻaʻole mākaukau ka waiwai.
/// Akā, ua hoʻāla ʻia ka hana o kēia manawa e ala aʻe ke hiki ke holomua hou aʻe ma o ke koho hou ʻana.
/// Ka `context` i hooholoia i ka `poll` iaoiaeii hiki i kekahi [`Waker`], i mea ka i lawelawe, no ka makaala na i kaʻikena hana.
///
/// Ke hoʻohana nei ʻoe iā future, ʻaʻole ʻoe e kelepona pololei iā `poll`, akā ma kahi o `.await` ka waiwai.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Ke ano o ka waiwai i na ma ka paʻaʻana.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Hoao e hoʻonā i ka future a hiki i ke kumukuai hope, ke kau helu keleponaʻana i ka he hana no wakeup ina ka waiwai mea,ʻaʻole i loaʻa.
    ///
    /// # Waiwai hoʻihoʻi
    ///
    /// Kēia kuleana pili i hoike:
    ///
    /// - [`Poll::Pending`] inā ʻaʻole mākaukau ka future
    /// - [`Poll::Ready(val)`] me ka hopena `val` o kēia future inā ua pau ka maikaʻi.
    ///
    /// Once kekahi future i pau, nā mea mālama mai e `poll` ia hou ole.
    ///
    /// Ke mākaukau ʻole kahi future, hoʻihoʻi ʻo `poll` iā `Poll::Pending` a mālama i kahi clone o ka [`Waker`] i kope ʻia mai ka [`Context`] o kēia manawa.
    /// Keia [`Waker`] Ua laila woken koke ka future hiki e holomua.
    /// ʻO kahi laʻana, kahi future e kali nei no kahi kumu e lilo i heluhelu e kāhea iā `.clone()` ma ka [`Waker`] a mālama iā ia.
    /// I ka wā o ka neaiae nei kakou e hoike ana i ke kumu i readable, [`Waker::wake`] ua kapaʻia, a me nā kumu future ka hana, ua awoken.
    /// I ke ala ʻana o kahi hana, pono ia e hoʻāʻo iā `poll` ka future hou, a i ʻole hua paha i kahi waiwai hope loa.
    ///
    /// Note ia i mau kāhea aku a ke i `poll`, wale ka [`Waker`], mai ka [`Context`] i hele i ka loa nā kāhea E e hoʻopaʻa 'e loaa i ka wakeup.
    ///
    /// # Nā helehelena Runtime
    ///
    /// Futures wale nō *inert*;pono lākou e ʻeleu * `poll`ed e holomua, ʻo ia hoʻi i kēlā me kēia manawa ke ala aʻe o ka hana i kēia manawa, pono ia e hoʻouka hou iā`poll` e kali ana iā futures e hoihoi mau ana ia.
    ///
    /// Ua i kapaʻia ke kuleana pili i `poll` pinepine ae la oia ma ka pilipaa loop-kahi, ka mea e wale nō ke kapa i ka wa a ka future Hōʻike ia ia mea makaukau ia e holo nei (ma ka kahea `wake()`).
    /// Inā 'oe makemake e kama'āina i ka `poll(2)` a `select(2)` syscalls ma Unix ia ka waiwai' ana i kumumanaʻo ana futures nō kāu hana *i* ae aku i ka mea pilikia o "all wakeups must poll all events";ka mea, ua nui e like `epoll(4)`.
    ///
    /// An manaʻo o `poll` e hooikaika e hoʻi koke aku, a me ka pono ole kal.Ke hoʻi wikiwiki nei i ka pale ʻana i nā pale a i ʻole nā puka lou hanana.
    /// Inā ʻike ʻia ma mua o ka manawa e pau ai ke kāhea ʻana iā `poll` i kahi manawa, pono e hoʻokau ʻia ka hana i kahi wai wili (a i ʻole kekahi mea like) e hōʻoia ai e hoʻi koke ʻo `poll`.
    ///
    /// # Panics
    ///
    /// Once kekahi future i ana (hoi `Ready` mai `poll`), e kahea ana kona `poll` iaoia hou ke panic, aeie ka wa pau ole, a me ke kumu 'ē aʻe ano o ka pilikia;ka `Future` trait kau ʻole i nā koi i nā hopena o ia kāhea ʻana.
    /// Eia nō naʻe, no ke ʻano `poll` i kaha ʻole ʻia ai `unsafe`, pili nā rula maʻamau a Rust: ʻaʻole pono nā kāhea e hana i nā hana i hoʻoholo ʻole ʻia (ka palaho hoʻomanaʻo, hoʻohana hewa ʻole o nā hana `unsafe`, a i ʻole nā mea like)
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}