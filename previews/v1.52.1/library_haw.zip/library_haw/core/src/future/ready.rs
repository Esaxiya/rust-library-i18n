use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Hana i kahi future i mākaukau koke me kahi waiwai.
///
/// Hana ʻia kēia `struct` e [`ready()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// Hana i kahi future i mākaukau koke me kahi waiwai.
///
/// Hana ʻia ʻo Futures ma o kēia hana e like me ka mea i hana ʻia ma o `async {}`.
/// I ka papa kuhikuhiE koena unuhi mea i futures i hana ai ma kēia kuleana pili i ka inoa a me ka hoʻokō `Unpin`.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}