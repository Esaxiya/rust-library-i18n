Panics kaʻikena pae.

Kēia e leie aku i ka polokalamu, e 'ōlelo koke, a i kou manaʻo ma ka Caller o ka polokalamu.
`panic!` E e hoʻohana 'ia ka wā o ka polokalamu i unrecoverable moku'āina ihoiho.

ʻO kēia macro ke ala kūpono e hōʻoia ai i nā kūlana i ke code laʻana a me nā hoʻokolohua.
`panic!` ua pili loa nakinaki me ka `unwrap` ano o nā [`Option`][ounwrap] a me [`Result`][runwrap] enums.
He mau implementations kapa `panic!` ia mea e kau aku i [`None`] a [`Err`] Lolina.

I ka hoʻohana 'ana `panic!()` oe Hiki ke koho i ke kui payload, i ua kūkuluʻia ka hoʻohana' ana i ka [`format!`] Ka Mooolelo O.
Hoʻohana ʻia kēlā uku i ka wā e hoʻokomo ana i ka panic i ke kāhea Rust, e hoʻohuli i ka pae iā panic āpau.

I ka hana o ka paʻamau `std` hook, oa
ka hoopai karaima e holo 'ana ma hope o ka panic maluna o lakou, o ke kakau i ka memo payload i `stderr` a me ka file/line/column ike o ka `panic!()` kahea.

Hiki iā ʻoe ke hoʻokahuli i ka panic hook me ka hoʻohana ʻana iā [`std::panic::set_hook()`].
I loko o ka hook he panic hiki ke lolouila me he `&dyn Any + Send`, a iloko ona i kakauia kekahi he `&str` a `String` no regular `panic!()` invocations.
I panic me kahi waiwai o kekahi ʻano ʻē aʻe, hiki ke hoʻohana ʻia ʻo [`panic_any`].

[`Result`] enum He pinepine ka maikaʻi pāʻoihana no ka hou ana mai ka hewa ma mua o ka hoʻohana 'ana i ka `panic!` nunui.
Pono e hoʻohana i kēia macro e hōʻole i ka hoʻohana ʻana i nā kumukūʻai kūpono ʻole, e like me nā kumuwaiwai kūwahi.
Piha 'ana i hewa pēpēʻana ua loaʻa i loko o ka [book].

E ʻike pū i ka macro [`compile_error!`], no ka hāpai ʻana i nā hewa i ka wā o ka hōʻuluʻulu.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Ke hoʻokō ʻia nei

Inā i ka papa kuhikuhiE pae panics ka mea, e 'ōlelo a pau i kou pae paha, a pau i kou polokalamu me kuhi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





