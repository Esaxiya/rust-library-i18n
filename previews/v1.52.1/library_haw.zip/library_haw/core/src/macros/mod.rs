#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Hoʻonui ʻia i `$crate::panic::panic_2015` a i ʻole `$crate::panic::panic_2021` e like me ka paʻi o ka mea e kāhea ana.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Hoʻike i mau, ka 'aoʻao e like i kekahi i kekahi, (me ka hoʻohana' [`PartialEq`]).
///
/// Ma panic, e paʻi kēia makona i nā waiwai o nā manaʻo me kā lākou hōʻike debug.
///
///
/// Like [`assert!`], ua nunui i ka lua o ka palapala, ma ka aoao panic memo hiki ke hoakaka ia.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Nā reborrows ma lalo nō intentional.
                    // Me ka ʻole o lākou, ua hoʻomaka mua ʻia ka māhu stack no ka hōʻaiʻē ma mua o ka hoʻohālikelike ʻia ʻana o nā waiwai, e alakaʻi ana i kahi lohi lohi i ʻike ʻia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Nā reborrows ma lalo nō intentional.
                    // Me ka ʻole o lākou, ua hoʻomaka mua ʻia ka māhu stack no ka hōʻaiʻē ma mua o ka hoʻohālikelike ʻia ʻana o nā waiwai, e alakaʻi ana i kahi lohi lohi i ʻike ʻia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Hoʻike i mau, ka 'aoʻao mea e like ai i kekahi i kekahi, (me ka hoʻohana' [`PartialEq`]).
///
/// Ma panic, e paʻi kēia makona i nā waiwai o nā manaʻo me kā lākou hōʻike debug.
///
///
/// Like [`assert!`], ua nunui i ka lua o ka palapala, ma ka aoao panic memo hiki ke hoakaka ia.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Nā reborrows ma lalo nō intentional.
                    // Me ka ʻole o lākou, ua hoʻomaka mua ʻia ka māhu stack no ka hōʻaiʻē ma mua o ka hoʻohālikelike ʻia ʻana o nā waiwai, e alakaʻi ana i kahi lohi lohi i ʻike ʻia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Nā reborrows ma lalo nō intentional.
                    // Me ka ʻole o lākou, ua hoʻomaka mua ʻia ka māhu stack no ka hōʻaiʻē ma mua o ka hoʻohālikelike ʻia ʻana o nā waiwai, e alakaʻi ana i kahi lohi lohi i ʻike ʻia.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Hoʻike i ka holomua Lālā paʻa 'aoʻao o `true` ma runtime.
///
/// Kēia, e hea aku i ka [`panic!`] nunui ina ka hoakaka olelo hiki ole ke ana kūpono i ka `true` i runtime.
///
/// Like [`assert!`], kekahi i keia nunui o ka lua o ka mana, ma ka aoao panic memo hiki ke hoakaka ia.
///
/// # Uses
///
/// Haʻalele [`assert!`], `debug_assert!` māmala'ōlelo e hōʻike ana i wale e 'ā ma' ole hoʻomākaukau leʻa kükulu ma ka paʻamau.
/// An hoʻomākaukau leʻa hana e e hoopai aku `debug_assert!` olelo ole `-C debug-assertions` ua hala aku i ka compiler.
/// Kēia i `debug_assert!` pono no ka loaʻa, e kaha i ka mea oi aku ka pipiʻi ia e noho i loko o ka hookuu wale nō akā, i e kōkua maikaʻi i? Acaeoey.
/// ʻO ka hopena o ka hoʻonui ʻana iā `debug_assert!` e nānā mau ʻia.
///
/// An unchecked assertion e leie aku kekahi polokalamu i loko o ka moku'āina e kue i ka malama e holo mai ana, a ke i unexpected hopena akā, 'aʻole e hoʻolauna unsafety like loa me kēia wale nō ka hana i ka palekana kivila.
///
/// Ka hana ana kāki o assertions, naʻe, mea i ke ana i loko o kekahi mau.
/// Hoʻomaopopo wale ʻia ka hoʻololi ʻana iā [`assert!`] me `debug_assert!` ma hope o ka hoʻopihapiha ʻana o ka profiling, a ʻo ka mea nui loa, aia wale nō i ke code palekana!
///
/// # Examples
///
/// ```
/// // ʻo ka leka panic no kēia mau manaʻo i ka waiwai stringified o ka ʻōlelo i hāʻawi ʻia.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // He nui loa na mea kuleana pili i
/// debug_assert!(some_expensive_computation());
///
/// // hoʻike me ka mea mau memo
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Hoʻike i mau, ka 'aoʻao e like i kekahi i kekahi.
///
/// Ma panic, e paʻi kēia makona i nā waiwai o nā manaʻo me kā lākou hōʻike debug.
///
/// ʻAʻole like me [`assert_eq!`], hoʻohana wale ʻia nā ʻōlelo `debug_assert_eq!` i nā kūkulu ʻole i hoʻomākaukau ʻia e ka paʻamau.
/// An hoʻomākaukau leʻa hana e e hoopai aku `debug_assert_eq!` olelo ole `-C debug-assertions` ua hala aku i ka compiler.
/// Kēia i `debug_assert_eq!` pono no ka loaʻa, e kaha i ka mea oi aku ka pipiʻi ia e noho i loko o ka hookuu wale nō akā, i e kōkua maikaʻi i? Acaeoey.
///
/// I ka hopena o ka hoʻonui `debug_assert_eq!` ua mauʻano kulana kupono.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Hoʻike i mau, ka 'aoʻao mea e like ai i kekahi i kekahi.
///
/// Ma panic, e paʻi kēia makona i nā waiwai o nā manaʻo me kā lākou hōʻike debug.
///
/// Haʻalele [`assert_ne!`], `debug_assert_ne!` māmala'ōlelo e hōʻike ana i wale e 'ā ma' ole hoʻomākaukau leʻa kükulu ma ka paʻamau.
/// ʻAʻole hoʻokō kahi kūkulu hoʻomākaukau leʻa i nā ʻōlelo `debug_assert_ne!` inā ʻaʻole i hāʻawi ʻia ʻo `-C debug-assertions` i ka mea hoʻopili.
/// Kēia i `debug_assert_ne!` pono no ka loaʻa, e kaha i ka mea oi aku ka pipiʻi ia e noho i loko o ka hookuu wale nō akā, i e kōkua maikaʻi i? Acaeoey.
///
/// I ka hopena o ka hoʻonui `debug_assert_ne!` ua mauʻano kulana kupono.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Hoike paha i ka haawiia hōʻike 'ākau a kekahi o ka haawi mai lauana.
///
/// Like me ka `match` olelo, i ke kumu hiki ke kohoʻia hahai ma `if`, a me ka poʻe kiaʻi 'aoʻao e loaʻa ke kōkua o ke inoa paa ia e ke kumu.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// E wehe i ka hopena paha hoʻopulapula kona hewa.
///
/// Ka `?` Aʻole i huiia e puku `try!` a me ka pono e hoʻohana hakahaka.
/// Eia kekahi, he ʻōlelo huna ʻia ka `try` ma Rust 2018, no laila inā ʻoe e hoʻohana ia, pono ʻoe e hoʻohana i ka [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` 'ākau a me ka haawi mai [`Result`].I ke ʻano o ka `Ok` ʻano ʻokoʻa, loaʻa ka manaʻo i ka waiwai o ka waiwai i wahī ʻia.
///
/// I ke ʻano o ka ʻokoʻa `Err`, kiʻi ia i ka hemahema o loko.A laila hana ʻo `try!` i ka hoʻololi ʻana me ka hoʻohana ʻana iā `From`.
/// Kēia i nā 'akomi huli ana ma waena o hana kūikawā hewa, a oi mau poʻe.
/// Ke kūpono ai hewa ua laila, hoi koke mai la.
///
/// No ka mea, o ka hoi koke ana mai, `try!` hiki wale ke hoʻohana i ka oihana i hoʻi [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ʻO ke ala i makemake ʻia e hoʻihoʻi i nā hemahema
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Ka mua hana ana o ka poe ola, hoi mai ka wahaheʻe
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ua like kēia me:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Kākau formattedʻikepili i loko o ka aooa.
///
/// Kēia nunui lawe maikai nei he 'writer', he waihona kui, a me ka papa inoa o nā manaʻo hoʻopiʻi kū'ē.
/// 'Oihana e e formatted e like me ka mea i hoakaka ia waihona kaula, a me ka hopena e e hele i ka mea kākau moʻolelo.
/// Ka mea kākau moʻolelo i e kekahi waiwai me ka `write_fmt` iaoia;nui keia hele mai ana, mai ka manaʻo o kekahi ka [`fmt::Write`] a me ka [`io::Write`] trait.
/// Ka nunui hoike mea a pau i ka `write_fmt` iaoiaeii hoike;maʻamau he [`fmt::Result`], a i ʻole [`io::Result`].
///
/// E ʻike iā [`std::fmt`] no ka ʻike hou aku e pili ana i ka syntax string format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A Module hiki Import nā `std::fmt::Write` a me `std::io::Write`, a kahea aku `write!` ma luna o nā mea i hoʻokō i kekahi, e like me ka mea mai,ʻaʻole nō kāu hoʻokō i nā.
///
/// Naʻe, i ka Module pono Import ka traits palapala hōʻoia no ole no laila lākou mau inoa hana e kue ana:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // ia mea fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // ia mea io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Hiki ke hoʻohana ʻia kēia macro i nā hoʻonohonoho `no_std` pū kekahi.
/// Ma ka `no_std` AUOO oe i kuleana no ka manaʻo lāliʻi o na eiiiiiaiou.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// E kakau iho i formattedʻikepili i loko o ka aooa, me ka newline huiia.
///
/// Ma nā paepae ai, ka newline o ka LINE Feed ano (`\n`/`U+000A`) wale (ʻaʻohe hou ukana i HOI ANA (`\r`/`U+000D`).
///
/// No ka ʻike hou aku, e ʻike iā [`write!`].No ka ʻike e pili ana i ka syntax string format, e nānā iā [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A Module hiki Import nā `std::fmt::Write` a me `std::io::Write`, a kahea aku `write!` ma luna o nā mea i hoʻokō i kekahi, e like me ka mea mai,ʻaʻole nō kāu hoʻokō i nā.
/// Naʻe, i ka Module pono Import ka traits palapala hōʻoia no ole no laila lākou mau inoa hana e kue ana:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // ia mea fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // ia mea io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Hōʻike unreachable kivila.
///
/// He mea pono i kekahi manawa i ka compiler hiki ole hooholo i kekahi karaima mea unreachable.O kahi laʻana:
///
/// * Like me na mea kaua me ka poʻe kiaʻi ana.
/// * Puka lou ka mea dynamically 'ōlelo.
/// * Iterators e hoʻopau hōʻino.
///
/// Inā hōʻoia ʻole ka hoʻoholo ʻana i ka hiki ʻole o ke code, hoʻopau koke ʻia ka papahana me [`panic!`].
///
/// Ke unsafe counterpart o keia nunui o ka [`unreachable_unchecked`] hana, a e i undefined hana ina ke kuhi ua hiki.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ua makemake mau [`panic!`].
///
/// # Examples
///
/// Hoʻokūkū i nā lima:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // i hoʻouluulu hewa inā ua'ōleloʻia mai
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // kekahi o nā hoʻokō ʻilihune o x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Hōʻike unimplemented kivila ma ka'ā'ā me ka memo o "not implemented".
///
/// Kēia e leie aku kou hoopai karaima, e 'ano-ponopono, i mea pono ina oe e prototyping a hoʻokō i kekahi trait e pono mau ano a au hana ole kumumanao o ka hoʻohana' ana i nā mea a pau o ka.
///
/// Ke hookaawale iwaena o `unimplemented!` a me [`todo!`] mea i ana `todo!` hoolilo aku hoi i ka manao o ka hoʻokō 'ia ka functionality hope, a me ka memo o "not yet implemented", `unimplemented!` i ole ia mau kuleana.
/// Kona memo o "not implemented".
/// E kaha kekahi mau IDE iā 'todo! `S.
///
/// # Panics
///
/// Ua makemake mau [`panic!`] no ka mea, `unimplemented!` mea pono ke shorthand no `panic!` me ka paa, kekahi memo.
///
/// Like `panic!`, ua nunui i ka lua o ka palapala no ka hōʻike hana mau loina.
///
/// # Examples
///
/// E olelo aku nei mākou i ka trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Mākou makemake i ka hoʻokō `Foo` no 'MyStruct', akā, no kekahi kumu ka mea i ano e? Ii i ke kuleana pili i `bar()` wale.
/// `baz()` a me `qux()` e noho pono e e ho'ākāka 'ia i loko o ka manaʻo o `Foo`, akā, ua hiki ke hana `unimplemented!` i loko o kā lākou mau wehewehe e ae mākou kuhi e i hoʻouluulu.
///
/// Mākou nō makemake e i ka papahana hooki holo ina e hiki i ka unimplemented ki ina hana like.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ua hana i hoohalike ia `baz` he `MyStruct`, no laila mākou i ole ke kūpiliʻaneʻi ma nā mea a pau.
/////
///         // Kēia e hōʻike "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Mākou i kekahi ke kūpiliʻaneʻi, mākou ke hui aku i ka memo i unimplemented!e hōʻike 'ia kāna mākou.
///         // E hōʻike kēia: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Hōʻike paʻa hapa kivila.
///
/// Kēia hiki e pono keia mau mea, ināʻoe e prototyping a e pono e nana i ka i kou kuhi typecheck.
///
/// Ke hookaawale iwaena o [`unimplemented!`] a me `todo!` mea i ana `todo!` hoolilo aku hoi i ka manao o ka hoʻokō 'ia ka functionality hope, a me ka memo o "not yet implemented", `unimplemented!` i ole ia mau kuleana.
/// Kona memo o "not implemented".
/// E kaha kekahi mau IDE iā 'todo! `S.
///
/// # Panics
///
/// Ua makemake mau [`panic!`].
///
/// # Examples
///
/// Eia kekahi laʻana o kekahi ma-holo kuhi.Mākou i ka trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Mākou makemake i ka hoʻokō `Foo` ma kekahi o ko mākou mau hoailona ia mea, akā, ua makemake no hoi i ka hana i pono `bar()` mua.I mea no mākou kivila mai i ka i hoʻouluulu, ua pono e hoʻokō `baz()`, no laila mākou e hana `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // manaʻo e hele ai 'aneʻi
///     }
///
///     fn baz(&self) {
///         // mai hopohopo e pili ana i ka hoʻokō ʻana iā baz() i kēia manawa
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // mākou ka mea,ʻaʻole i hoʻohana baz(), no laila, keia mea maikai.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Nā wehewehe ʻana o nā macros i kūkulu ʻia.
///
/// Ka hapa nui o ka nunui waiwai (kumupaʻa,ʻike pono, etc.) i lawe mai i ke kumu kivila mai iʻaneʻi, me ka a koe o? Anoe? Oihana hoano hou ana ia nunui nā manaʻo i loko o nā mea hōʻike aku, e hoomakaukau mau mana ma ke compiler.
///
///
pub(crate) mod builtin {

    /// Mea, lalau mai compilation e pau auaneʻi me ka mea i haawiia mai manaʻo ka wā pilikia.
    ///
    /// E e hoʻohana 'ia kēia nunui ka wā i crate hoʻohana he conditional compilation kou akamai, e hoomakaukau i maikaʻi hewa memo no erroneous ana.
    ///
    /// O ka compiler-nui ke ano o [`panic!`], akā, kī ana i ka hewa iloko o *compilation* e aho ia mamua ma *runtime*.
    ///
    /// # Examples
    ///
    /// Elua mau examples mau macros a me `#[cfg]` hana kūpono.
    ///
    /// Kī maikaʻi compiler hewa ina i nunui ua hala kūponoʻole nā loina.
    /// Me ka ʻole o ka branch hope loa, e hoʻokuʻu mau ka mea nāna i hoʻonohonoho i kahi hemahema, akā ʻaʻole ka ʻōlelo a ka hewa e haʻi i nā waiwai kūpono ʻelua.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Hewa i ka mea hōʻuluʻulu inā loaʻa ʻole kekahi o nā hiʻohiʻona.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Iino? Ieea kiko'î a no ka mea 'ē aʻe kaula-formatting macros.
    ///
    /// Kēia nunui oihana ma ka lawe ana i ka formatting kui literal i loaʻa ka `{}` no kēlā me nā loulou hala.
    /// `format_args!` prepares ka hou kiko'î e hōʻoia i ka auoiaea hiki ke hoohalike ana me he kaula, a canonicalizes i nā manaʻo hoʻopiʻi kū'ē i loko o ka hoʻokahiʻano.
    /// Kekahi waiwai i ka [`Display`] trait hiki ke hele i `format_args!` e kakau mai, e like me ka hiki i kekahi [`Debug`] manaʻo e hele i ka `{:?}` i loko o ka formatting kui.
    ///
    ///
    /// Kēia nunui produces i ka waiwai o keʻano [`fmt::Arguments`].Kēia waiwai hiki ke hele i na macros loko o [`std::fmt`] no ka hana maikaʻi kēia redirection.
    /// All 'ē aʻe formatting macros ([' waihona! '], [`write!`], [`println!`], a pela aku) i hope ma keia kekahi.
    /// `format_args!`, like kona loko macros, hōʻalo ai i ka hoiliili au i na allocations.
    ///
    /// Hiki nō ke hoʻohana i ka [`fmt::Arguments`] waiwai i `format_args!` hoʻi ma `Debug` a `Display` ma mua, e like me ka ike ma lalo nei.
    /// Ke kumu no hoi E hoike mai i `Debug` a me `Display` waihona i ka mea hookahi: ka interpolated waihona kaula ma `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// No ka 'ike hou aku, e nānā i ka moʻolelo ma [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// E like me `format_args`, akā hoʻohui i kahi laina hou i ka hopena.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ke nānā pono i OOAaAeU i i hoʻouluulu manawa.
    ///
    /// Kēia nunui, e hoʻonui i ka waiwai o ka mea i kapaʻia OOAaAeU i i hoʻouluulu manawa, haawi ana i ka olelo o ka type `&'static str`.
    ///
    ///
    /// Inā ʻaʻole i wehewehe ʻia ka hoʻololi o ke kaiapuni, a laila e hoʻokuʻu ʻia kahi hewa hōʻuluʻulu.
    /// Ia i hoʻokuʻu akula i ka i hoʻouluulu hewa, e hoʻohana i ka [`option_env!`] nunui kahi.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Oe ke hoʻopilikino i ka manaʻo ma ka hele ana i ke kaula me ka lua o ka aiao.
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Inā ka `documentation` OOAaAeU ua ole i ho'ākāka ', oe e kiʻi i nā kēia hewa.
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kohoʻia ke nānā pono i OOAaAeU i i hoʻouluulu manawa.
    ///
    /// Inā ka inoa OOAaAeU mea i hiki mai ma i hoʻouluulu manawa, i kēia e hoʻonui i loko o ka olelo o ke 'ano `Option<&'static str>` nona ka waiwai o `Some` o ka waiwai o ka OOAaAeU.
    /// Inā ʻaʻohe ke ʻano o ke kaiapuni, a laila e hoʻonui kēia i `None`.
    /// E ʻike iā [`Option<T>`][Option] no ka ʻike hou aku e pili ana i kēia ʻano.
    ///
    /// ia ka hoʻohana 'ana i kēia nunui nānā' ole no paha ka OOAaAeU mea noho paha,ʻaʻole A i hoʻouluulu manawa hewa ua loa kinoea.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates hōʻike no ke i loko o kekahi hōʻike no.
    ///
    /// Lawe kēia macro i kekahi o nā mea hoʻokaʻawale hoʻokaʻawale i ke koma, a hoʻohui iā lākou āpau i hoʻokahi, e hāʻawi ana i kahi manaʻo i kahi ʻike hou.
    /// E noke i kou niho hana ia ia i keia nunui hiki ole paʻa kūloko aiaiiuo.
    /// No hoi, me he mau rula, macros i wale ae ma ka'ikamu, hoike a hōʻike kūlana.
    /// E hoʻi ana au e hoʻohana i kēia nunui no ka haawi ia ana i na DEBFULLNAME, oihana paha modules a pela aku, e hiki ole hoakaka i ka hou kekahi me ia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (hou, leʻaleʻa, inoa) { }//ole usable ma keia ala!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals i loko o ka kūpaʻa kui māhele.
    ///
    /// Kēia nunui i kekahi helu o ka comma-hookaawaleia literals, haawi ana i ka olelo o ke 'ano `&'static str` i ho a pau o na literals concatenated haʻalele-i-pono.
    ///
    ///
    /// Helu a me ka lana wahi literals i stringified ma ka mea e e concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Hoʻonui i ka helu laina i kāhea ʻia ai.
    ///
    /// Me [`column!`] a me [`file!`], mau macros i debugging 'ikepili no ka haku polokalamu e pili ana i ka wahi i loko o ke kumu.
    ///
    /// Loaʻa ka manaʻo hoʻonui i ka type `u32` a me ka 1-based, no laila ʻo ka lālani mua i kēlā me kēia faila e loiloi i 1, ka lua a 2, etc.
    /// He mea ku i ka hewa memo ma na compilers a mahalo me ka luna hoʻoponopono.
    /// Ke hoi mai laina mea *e pono* i ka laina o ka `line!` invocation ia iho, akā, e aho ka mua nunui invocation e alakai mai i ka invocation o ka `line!` nunui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Hoʻonui i ka pono a hiki i ka kolamu helu ma i ka mea i lakou.
    ///
    /// Me [`line!`] a me [`file!`], hāʻawi kēia mau macros i ka ʻikepili debugging no nā mea hoʻomohala e pili ana i ka wahi i loko o ke kumu.
    ///
    /// Ka hoʻonui 'aoʻao o ka' ano `u32` a me ka mea 1-muli, no laila, i ke kolamu mua i loko o kēlā me kēia laina loiloi i 1, i ka lua i ka 2, etc.
    /// He mea ku i ka hewa memo ma na compilers a mahalo me ka luna hoʻoponopono.
    /// Ka hoi kolamu mea *e pono* i ka laina o ka `column!` invocation ia iho, akā, e aho ka mua nunui invocation e alakai mai i ka invocation o ka `column!` nunui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Hoʻonui i ka pono a hiki i ka waihona inoa i loko i ka mea i lakou.
    ///
    /// Me [`line!`] a me [`column!`], mau macros i debugging 'ikepili no ka haku polokalamu e pili ana i ka wahi i loko o ke kumu.
    ///
    /// Ka hoʻonui 'aoʻao o ua kikokiko i `&'static str`, a me ka hoi mai waihona mea ole ka invocation o ka `file!` nunui ia iho, akā, e aho ka mua nunui invocation e alakai mai i ka invocation o ka `file!` nunui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies kona manaʻo hoʻopiʻi kū'ē.
    ///
    /// Kēia nunui, e hookuu aku i ka olelo o ke 'ano `&'static str` i mea ka stringification o nā mea a pau i ka tokens hele ai i ka nunui.
    /// No kapu i kau ma luna o ka Mooolelo o ka nunui invocation iho.
    ///
    /// E noke i ke hoʻololi i ka hoomaka hopena o ka hoʻokomo o tokens i loko o ka future.Oe E e akahele ina ua ku paa ma ka auoiaea.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ka loaʻa o ke UTF-8 encoded waihona me ke kui.
    ///
    /// Aia ka faila e pili ana i ka faile o kēia manawa (e like me ka ʻike o nā modula).
    /// Ua hoakaka ia alanui ua hoohalike ana i loko o ka pola-i ho'ākāka 'ana ma i hoʻouluulu manawa.
    /// No laila, no ka laʻana, ʻaʻole kahi compocation me kahi ala Windows i loaʻa nā backslashes `\` e hōʻuluʻulu pono iā Unix.
    ///
    ///
    /// Kēia nunui, e hookuu aku i ka olelo o ke 'ano `&'static str` i mea kahi o ka waihona.
    ///
    /// # Examples
    ///
    /// Lawe ma laila nō nā AEIU i loko o ka hookahi papa kuhikuhi nui me ka mea kēia Contents:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// I hoʻouluulu 'main.rs' a holo i ke kūpono aeaie e kakau "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ka loaʻa o ka waihona e like me ka olua i kaʻai ke kaua.
    ///
    /// Aia ka faila e pili ana i ka faile o kēia manawa (e like me ka ʻike o nā modula).
    /// Ua hoakaka ia alanui ua hoohalike ana i loko o ka pola-i ho'ākāka 'ana ma i hoʻouluulu manawa.
    /// No laila, no ka laʻana, ʻaʻole kahi compocation me kahi ala Windows i loaʻa nā backslashes `\` e hōʻuluʻulu pono iā Unix.
    ///
    ///
    /// Kēia nunui, e hookuu aku i ka olelo o ke 'ano `&'static [u8; N]` i mea kahi o ka waihona.
    ///
    /// # Examples
    ///
    /// Lawe ma laila nō nā AEIU i loko o ka hookahi papa kuhikuhi nui me ka mea kēia Contents:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// I hoʻouluulu 'main.rs' a holo i ke kūpono aeaie e kakau "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Hoʻonui i ka pono a hiki i kekahi kaula i ho i kaʻikena Module alanui.
    ///
    /// Ka papa Module alanui hiki e manao ana e like me ka luna kiʻekiʻe o modules alakai hoʻi mai ai i ka crate root.
    /// Ka mua ke keʻena o ke ala hoi o ka inoa o ka crate a ianoiyuaa a ua 'ohi ai.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Loiloi holomua Lālā paʻa pu ana o ka hoʻonohonohoʻia lepa i i hoʻouluulu-manawa.
    ///
    /// Ma waho aʻeo i ka `#[cfg]` kaila, ua nunui ua hoakaka ia e ae Lālā paʻa 'aoʻao o ka loiloi' ana i hoʻonohonohoʻia nā hae.
    /// He pinepine hiki aku ai i ka emiʻia i kekahi kivila.
    ///
    /// Ka Mooolelo O hāʻawiʻia a hiki i kēia nunui o ka ia Ka Mooolelo O like me ka [`cfg`] kaila.
    ///
    /// `cfg!`, e like `#[cfg]`, 'aʻole e wehe i kekahi karaima, a wale loiloi i ka oiaio a me ka hoopunipuni.
    /// No ka laʻana, a pau ālai 'ia ma ka' aoʻao o if/else pono e lilo ia `cfg!` ua hoʻohana 'ia no keʻano, nānā' ole o ka mea `cfg!` ua loiloi '.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// AIAIEUEOO i ka waihona e like me ka olelo a me ka'ikamu, e like me ka pōʻaiapili.
    ///
    /// (Like me ke pehea modules i loaʻa) i ka waihona o Nyos i pili i kaʻikena waihona.Ua hoakaka ia alanui ua hoohalike ana i loko o ka pola-i ho'ākāka 'ana ma i hoʻouluulu manawa.
    /// No laila, no ka laʻana, ʻaʻole kahi compocation me kahi ala Windows i loaʻa nā backslashes `\` e hōʻuluʻulu pono iā Unix.
    ///
    /// ʻO ka hoʻohana pinepine ʻana i kēia macro he manaʻo maikaʻi ʻole ia, no ka mea inā parsed ka faila ma ke ʻano he expression, e hoʻokau ʻia ia i loko o nā code a puni me ka maikaʻi ʻole.
    /// He hiki ka hopena i aiaiiuo paha oihana i okoa mai mea o ka waihona i manaoia ina he mau aiaiiuo paha oihana i i ka ia inoa i loko o kaʻikena waihona.
    ///
    ///
    /// # Examples
    ///
    /// Lawe ma laila nō nā AEIU i loko o ka hookahi papa kuhikuhi nui me ka mea kēia Contents:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// I hoʻouluulu 'main.rs' a holo i ke kūpono aeaie e kakau "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Hoʻike i ka holomua Lālā paʻa 'aoʻao o `true` ma runtime.
    ///
    /// Kēia, e hea aku i ka [`panic!`] nunui ina ka hoakaka olelo hiki ole ke ana kūpono i ka `true` i runtime.
    ///
    /// # Uses
    ///
    /// Assertions i mau kulana kupono ma nā debug a me ka hoʻokuʻu kūkulu, aʻaʻole hiki ke polokalamu JavaScript.
    /// E ʻike iā [`debug_assert!`] no nā ʻōlelo i hiki ʻole i ka hoʻokuʻu kūkulu ʻana i paʻamau.
    ///
    /// Unsafe kivila e hilinai aku maluna o `assert!` e hooko holo-manawa invariants mea, ina hoohaumia i hiki alakai i ka unsafety.
    ///
    /// Other ana-hihia o `assert!` ka lolouila hoao a me ka pule holo-manawa invariants ma palekana code (kona 'aʻe' hiki ole ka hopena ma ka unsafety).
    ///
    ///
    /// # Mana Lima Nā memo ma
    ///
    /// He ʻano lua ko kēia macro, kahi e hiki ai ke hāʻawi ʻia i kahi leka panic maʻamau me ka ʻole o nā paio no ka hōʻano ʻana.
    /// E nānā i [`std::fmt`] no Ka Mooolelo no kēia palapala.
    /// E loiloi wale ʻia nā manaʻo i hoʻohana ʻia e like me nā hoʻopaʻapaʻa format inā holo ʻole ka ʻōlelo.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ʻo ka leka panic no kēia mau manaʻo i ka waiwai stringified o ka ʻōlelo i hāʻawi ʻia.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // He nui loa na mea kuleana pili i
    ///
    /// assert!(some_computation());
    ///
    /// // hoʻike me ka mea mau memo
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// LIKE LIKE i ua ahakanaka la.
    ///
    /// E heluhelu i ka [unstable book] no ka oAaEeIeIAaIAeO.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-mika LIKE LIKE i ua ahakanaka la.
    ///
    /// E heluhelu i ka [unstable book] no ka oAaEeIeIAaIAeO.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Module-ilikai LIKE LIKE i ua ahakanaka la.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Wahi hala tokens i loko o ka maʻamau ia auoiaea.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mau hiʻohiʻona nō a hoʻopio i nā Hahai I functionality hoʻohana no ka debugging'ē aʻe macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Kaila nunui hoʻohana i pili loko macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Hoʻohana ʻia ka macro ʻano i kahi hana e hoʻolilo iā ia i kahi hōʻike anakahi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Kaila nunui noi ai i ka papa, e huli ia i loko o ka benchmark hōʻike.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// An manaʻo au mamuli o ka `#[test]` a me `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Hoʻohana ʻia ka macro makamae i kahi kūpaʻa e hoʻopaʻa inoa iā ia ma ke ʻano he mea hoʻokaʻawale honua.
    ///
    /// E nānā pū [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mālama i ka mea i pili inā pili ke ala i hala, a wehe iā ia i kahi ʻē aʻe.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Hoʻonui i ka pono `#[cfg]` a me nā mea a pau `#[cfg_attr]` aʻe i loko o ka eiae apana nahaha he hana pili i ka.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// He hu wale manaʻo au mamuli o ka `rustc` compiler, mai hana.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// He hu wale manaʻo au mamuli o ka `rustc` compiler, mai hana.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}