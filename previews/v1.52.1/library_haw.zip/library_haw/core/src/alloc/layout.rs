use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ia keia kuleana pili i ka hoʻohana 'ia ma kekahi wahi, a kona manaʻo hiki ke inlined, ka mua a ho'āʻo paha e hana ai i rustc ke kua'āina o:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// ʻIa o ka hihia o ka iaiyoe.
///
/// Hōʻike kahi hanana o `Layout` i kahi hoʻonohonoho o ka hoʻomanaʻo.
/// E kūkulu i ka `Layout` i like ka hoʻokomo o, e haawi i ka allocator.
///
/// Loaʻa i nā ʻōnaehana āpau ka nui e pili ana a me ka hoʻopili ʻana o ka mana o ka ʻelua.
///
/// (Note i layouts i *i* koi i ka i 'ole-Aʻohe nui, a hiki nae `GlobalAlloc` pono i nā mea a pau iaiyoe noi e' ole-Aʻohe ma ka nui.
/// A Caller pono ka hōʻoia 'ia aku ana e like keia e halawai, hana i ho'ākāka' allocators me looser koi, a hoʻohana i ka oi lenient `Allocator` mau '.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ka nui o ka poloka noi o ka hoʻomanaʻo, ana ʻia i nā bytes.
    size_: usize,

    // kaulike o ka poloka noi o ka hoʻomanaʻo, ana ʻia i nā bytes.
    // ke hōʻoia i kēia mea mau i ka mana-o-elua, no ka mea, API ka e like `posix_memalign` e noi mai ka mea, a ia mea he kupono constraint e auhau ia maʻia constructors.
    //
    //
    // (Naʻe, mākou e ole analogously koi 'align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Kūkulu i kahi `Layout` mai kahi `size` a me `align` i hāʻawi ʻia, a i ʻole hoʻihoʻi iā `LayoutError` inā ʻaʻole e hoʻokō ʻia kekahi o nā ʻano aʻe:
    ///
    /// * `align` pono ʻole e zero,
    ///
    /// * `align` pono he mana o ʻelua,
    ///
    /// * `size`, ke hoʻopuni ʻia i kahi kokoke i `align`, pono ʻole e kahe (ie, ʻoi aku ka liʻiliʻi o ke kumukūʻai āpau a i ʻole like me `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Ka mana-o-elua hoʻohuʻu align!=0.)

        // Ua hoʻokōʻia i ka nui o:
        //   size_round_up=(size + align, 1)&! (kaulike, 1);
        //
        // ʻIke mākou mai luna aʻe e kaulike!=0.
        // Inā ohui (align, 1) 'aʻole i hoʻohālana, laila polopelema mai e e uku.
        //
        // Conversely, a-masking me! (Align, 1) e unuhi aku wale haʻahaʻa-mea-i nā kānaka.
        // Pēlā inā piʻi ka hoʻonui me ka huina, ʻaʻole hiki i ka&-mask ke unuhi i ka lawa e wehe ai i kēlā kahawai.
        //
        //
        // Ma luna e hōʻike nei he pono a lawa hoʻi ka nānā ʻana no ka hoʻoliʻiliʻi hōʻuluʻulu.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: nā kūlana no `from_size_align_unchecked` i
        // nānā ʻia ma luna.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Hoʻokumu i kahi hoʻonohonoho, e kāpae i nā kaha āpau.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana no ka mea ʻaʻole ia e hōʻoia i nā preconditions mai [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // Ka maluhia: o ka Caller pono hōʻoia i `align`, ua oi aku ma mua o 'Aʻohe.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ka liʻiliʻi loa o nā bytes no kahi paʻa hoʻomanaʻo o kēia hoʻonohonoho.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ʻO ka hoʻoliʻiliʻi byte palena iki no kahi poloka hoʻomanaʻo o kēia hoʻonohonoho.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Kūkulu i kahi `Layout` kūpono no ka hoʻopaʻa ʻana i kahi waiwai o ka ʻano `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // Ka maluhia: o ka align ua ua hoʻohiki e Rust e ia i ka mana o ka elua a me ka
        // ʻo ka nui + align combo e hōʻoiaʻiʻo ʻia e komo i kā mākou helu wahi.
        // E like me ka hopena e hoʻohana i ka mea kūkulu ʻole i nānā ʻole ʻia ma aneʻi e hōʻalo i ka hoʻokomo ʻana i ka pāʻālua panics inā ʻaʻole i hoʻomākaukau maikaʻi ʻia.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Hana i ka ʻōnaehana e wehewehe nei i kahi moʻolelo i hiki ke hoʻohana ʻia e hoʻokaʻawale i ke kūkulu ʻana no `T` (a he trait a i ʻole kekahi ʻano unsized e like me kahi ʻāpana).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Maluhia: ʻike rationale ma `new` no ke aha la keia ua hoʻohana 'ana i ka unsafe Lolina
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Hana i ka ʻōnaehana e wehewehe nei i kahi moʻolelo i hiki ke hoʻohana ʻia e hoʻokaʻawale i ke kūkulu ʻana no `T` (a he trait a i ʻole kekahi ʻano unsized e like me kahi ʻāpana).
    ///
    /// # Safety
    ///
    /// Palekana wale kēia hana e kāhea inā paʻa nā ʻano aʻe:
    ///
    /// - Inā `T` ka `Sized`, palekana kēia hana i ke kāhea mau ʻana.
    /// - Inā ka unsized huelo o `T` mea:
    ///     - he [slice], a laila pono ka lōʻihi o ka huelo ʻokiʻoki i integer intial, a me ka nui o ka *waiwai holoʻokoʻa*(hōʻeuʻeu ka huelo lōʻihi + kuhī nui statically) pono e komo i `isize`.
    ///     - a [trait object], a laila pono e kuhikuhi i ka ʻāpana vtable o ka pointer i kahi papa kūpono kūpono no ke ʻano `T` i loaʻa ʻia e kahi coizingion unsizing, a me ka nui o ka *waiwai holoʻokoʻa*(ka lōʻihi o ka huelo hōʻeuʻeu + kuhī nui statically) pono e komo i `isize`
    ///
    ///     - he (unstable) [extern type], a laila palekana kēia hana i ke kāhea ʻana, akā e panic a i ʻole hoʻi e hoʻoliʻiliʻi i ka waiwai hewa, no ka mea ʻaʻole ʻike ʻia ka ʻano o ka ʻano extern.
    ///     ʻO kēia ka hana e like me [`Layout::for_value`] ma ke kuhikuhi ʻana i kahi huelo o waho.
    ///     - i ole ia, ka mea, ua conservatively ole ae, e kapa aku i kēia kuleana pili i.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: hala mākou i nā pono o kēia mau hana i ka mea e kāhea ana
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Maluhia: ʻike rationale ma `new` no ke aha la keia ua hoʻohana 'ana i ka unsafe Lolina
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Hana he `NonNull` i ua dangling, akā, pono-ua kūponoʻia no kēiaʻia.
    ///
    /// E hoʻomaopopo he hiki ke kuhikuhi i ka helu kuhikuhi i kahi kuhikuhi kūpono, ʻo ia hoʻi ʻaʻole pono e hoʻohana ʻia kēia ma ke ʻano he "not yet initialized" sentinel waiwai.
    /// ʻO nā ʻano e hoʻokaʻawale palaualelo e nānā pono i ka hoʻomaka ʻana e kekahi ʻano ʻē aʻe.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: hoʻohiki ʻia i ka ʻole-ʻole
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Hoʻokumu i kahi hoʻonohonoho e wehewehe ana i ka moʻolelo i hiki ke hoʻopaʻa i kahi waiwai o ka hoʻonohonoho like me `self`, akā hoʻopili ʻia ia i ka hoʻopili `align` (ana ʻia i nā bytes).
    ///
    ///
    /// Inā ua hui ʻo `self` i ka hoʻopili i kuhikuhi ʻia, a laila hoʻihoʻi iā `self`.
    ///
    /// E hoʻomaopopo ʻaʻole hoʻohui kēia hana i kekahi padding i ka nui holoʻokoʻa, me ka nānā ʻole inā he ʻano ʻokoʻa ka hoʻonohonoho hoʻihoʻi.
    /// I nā huaʻōlelo ʻē aʻe, inā `K` ka nui 16, `K.align_to(32)` e *nō* loaʻa ka nui 16.
    ///
    /// Hoʻi ka hewa ina o ka hui malu pu ana o `self.size()`, a me ka haawi `align` aʻe i nā kūlana helu ma [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Hoʻihoʻi i ka nui o nā pale a pono mākou e hoʻokomo ma hope o `self` e hōʻoia i ka ʻōlelo aʻe e māʻona ai `align` (ana ʻia i nā bytes).
    ///
    /// e laʻa, inā ʻo `self.size()` ka 9, a laila `self.padding_needed_for(4)` hoʻihoʻi i 3, no ka mea ʻo ia ka helu liʻiliʻi o nā bytes o nā pale i koi ʻia e kiʻi i kahi kamaʻilio 4-kaulike (ke manaʻo nei e hoʻomaka ka poloka hoʻomanaʻo i kahi helu 4 i hoʻopili ʻia.
    ///
    ///
    /// ʻAʻohe kumu o ka waiwai hoʻihoʻi o kēia hana inā ʻaʻole `align` ka mana-o-ʻelua.
    ///
    /// Note i ka pili ana o ka hoi mai la waiwai koi `align` e e emi ma mua o paha i keia i ka hoʻopololei o ka hoʻomaka aae? No ka mea a pau anao? Aou aeie o ka iaiyoe.ʻO kahi ala e māʻona ai kēia kaohi mea e hōʻoia ai iā `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // ʻO ka waiwai i hoʻopili ʻia:
        //   len_rounded_up=(Len + align, 1)&(align, 1)!;
        // a laila hoʻi mākou i ka nenelu loa koena unuhi. `len_rounded_up - len`.
        //
        // Hoʻohana mākou i ka arithmetic māhele ma:
        //
        // 1. kaulike ʻia e> 0, no laila kaulike, 1 mau nō ke kūpono.
        //
        // 2.
        // `len + align - 1` hiki ke hoʻonui ʻia i ka `align - 1` nui loa, no laila e hōʻoia ka&-mask me `!(align - 1)` i ke ʻano o ka hoʻoheheʻe ʻana, ʻo `len_rounded_up` ponoʻī ke lilo i 0.
        //
        //    Pela ka hoi nenelu loa, ka wā i hoʻohuiʻia ia `len`, e haawi i ko 0, a trivially satisfies ka hoʻopololei `align`.
        //
        // (ʻOiaʻiʻo, hoʻāʻo e hoʻokaʻawale i nā palaka o ka hoʻomanaʻo nona ka nui a me ka padding e hoʻonui i ke ʻano i luna aʻe e hoʻohua i ka mea hoʻokaʻawale.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Hoʻokumu i kahi ʻōnaehana e ka hoʻopuni ʻana i ka nui o kēia hoʻonohonoho a i kahi mau o ke kau o ka hoʻonohonoho.
    ///
    ///
    /// Kūlike kēia i ka hoʻohui ʻana i ka hopena o `padding_needed_for` i ka nui o ka ʻōnaehana o kēia manawa.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ʻAʻole hiki i kēia ke hoʻonui.Kuhi ʻia mai ka invariant o Layout:
        // > `size`, wā ua hoʻokōʻia mai ai i ka hapa 'mau o `align`,
        // > pono ole hoʻohālana ('o ia hoʻi, pono e emi ma mua o ka mea ua hoʻokōʻia cia
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Hana i kahi hoʻonohonoho e wehewehe ana i ka moʻolelo no nā `n` hanana o `self`, me kahi nui kūpono o ka pale ma waena o kēlā me kēia e hōʻoia i ka hāʻawi ʻia ʻana o kēlā me kēia hanana i ka nui a me ka hoʻopili ʻana.
    /// Ma ka pomaikai, hoi mai `(k, offs)` kahi `k` o ke kūpono o ka hoʻouka, a `offs` o ka mamao ma waena o ka hoʻomaka 'ana o kēlā me kēia hehee ai i loko o ke kaua.
    ///
    /// Ma makemakika hoʻohālana, hoi mai `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ʻAʻole hiki i kēia ke hoʻonui.Kuhi ʻia mai ka invariant o Layout:
        // > `size`, wā ua hoʻokōʻia mai ai i ka hapa 'mau o `align`,
        // > pono ole hoʻohālana ('o ia hoʻi, pono e emi ma mua o ka mea ua hoʻokōʻia cia
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align ua ʻike ʻia ka pono a ua alakaʻi ʻia ka nui
        // padded ʻē.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Hoʻokumu i kahi hoʻonohonoho e wehewehe ana i ka moʻo no `self` i ukali ʻia e `next`, me nā pale pono e ʻike pono ai e hoʻopili pono ʻia ʻo `next`, akā *ʻaʻohe pale pale*.
    ///
    /// I mea e like me C e hoohalike aiʻia `repr(C)`, oe e kahea `pad_to_align` ma hope e holo ana i ke kūpono a me nā kula.
    /// (He mea i ala, e like loa me ka ka paʻamau Rust e hoohalike aiʻia `repr(Rust)`, as it is unspecified.)
    ///
    /// E hoʻomaopopo i ke kaulike ʻana o ka hoʻonohonoho hopena ka maximum o nā `self` a me `next`, i mea e hōʻoia ai i ke kaulike o nā ʻāpana ʻelua.
    ///
    /// Hoʻi iā `Ok((k, offset))`, kahi hoʻonohonoho `k` o ka moʻolelo concatenated a ʻo `offset` kahi wahi e pili ana, i nā bytes, o ka hoʻomaka ʻana o ka `next` i hoʻokomo ʻia i loko o ka concatenated record (ke manaʻo nei e hoʻomaka ka moʻolelo ma ka offset 0).
    ///
    ///
    /// Ma makemakika hoʻohālana, hoi mai `LayoutError`.
    ///
    /// # Examples
    ///
    /// E hoʻomaulia i ka hoʻonohonoho o kahi hanana `#[repr(C)]` a me nā offset o nā māla mai nā ʻōnaehana o kāna pā.
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // E hoomanao e finalize me `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // hoao aku i ka mea hana
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Hana heʻia hōʻike no ka mooolelo no ka `n` nui o `self`, me ka ole nenelu loa ma waena o kēlā me kēia manawa.
    ///
    /// Note e, e like `repeat`, `repeat_packed` aʻole i kumu hoʻomalu i ka hai nui o `self` e e pono ua kūponoʻia, a hiki ina he haawiia kekahi manawa o `self` ua pono ua kūponoʻia.
    /// Ma na olelo e ae, ina keʻia hoʻi ma ka `repeat_packed` ua hoʻohana 'ia e līkaia no ka hoʻouka, ka mea, ua i ua hoʻohiki i nā kumu i loko o ke kaua, e e pono ua kūponoʻia.
    ///
    /// Ma makemakika hoʻohālana, hoi mai `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Hana heʻia hōʻike no ka mooolelo no ka `self` hahai ma `next` me ole hou nenelu loa ma waena o nā elua.
    /// No ka mea,ʻaʻohe nenelu loa ua hookomoia, i ka hoʻopololei o `next` mea pili 'ole, a ua ole hoohui *ma nā mea a pau i loko o* ka kūponoʻia.
    ///
    ///
    /// Ma makemakika hoʻohālana, hoi mai `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Hana heʻia hōʻike no ka mooolelo no ka `[T; n]`.
    ///
    /// Ma makemakika hoʻohālana, hoi mai `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Nā mea kiko'î a haawiia mai ia `Layout::from_size_align` 'ole kekahi' ē aʻe `Layout` constructor eʻole nō paha kona hoʻopaʻa pepa paʻi kiʻi nā palena.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (pono mākou i kēia no ka implstream down o trait Kuʻia)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}