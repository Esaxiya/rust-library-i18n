use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Hiki i kahi mea hoʻokaʻawale hoʻomanaʻo ke hiki ke hoʻopaʻa inoa ma ke ʻano he paʻamau o ka hale waihona puke maʻamau ma o ka hiʻona `#[global_allocator]`.
///
/// Kekahi o nā kiʻina hana i kauoha mai i ka iaiyoe hihia e *a ianoiyuaa a anao? Aou* Via ka allocator.Keia ano e:
///
/// * ka hoʻomaka aae? no ka mea, ua nalowale hihia mua hoi ia ma ke kāhea mua a hiki i ka e auaaeaiea hana e like me `alloc`, a
///
/// * ʻaʻole i hoʻololi hou ʻia ka palaka hoʻomanaʻo, kahi e hoʻololi ʻia ai nā palaka ma o ka hoʻoili ʻia ʻana i kahi hana kuʻuna e like me `dealloc` a i ʻole ke hele ʻia i kahi ʻano reallocation e hoʻihoʻi i kahi kuhikuhi ʻole.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// ʻO `GlobalAlloc` trait kahi `unsafe` trait no nā kumu he nui, a pono nā mea hoʻokō e hōʻoia e pili pono lākou i kēia mau ʻaelike.
///
/// * ʻO undefined hana ina global allocators unwind.Hiki ke hāpai ʻia kēia kapu i ka future, akā i kēia manawa ʻo panic mai kekahi o kēia mau hana e alakaʻi i ka unsafety memo.
///
/// * `Layout` pono e pololei nā nīnau a me nā helu ʻana ma ka laulā.ʻAe ʻia nā mea kelepona i kēia trait e hilinaʻi i nā ʻaelike i wehewehe ʻia i kēlā me kēia hana, a pono nā mea hoʻokō e hōʻoia i ka ʻoiaʻiʻo o nā ʻaelike.
///
/// * ole oe e hilinai aku maluna o allocations maoli hana, a hiki ina he mea pelapela ahu allocations i loko o ke kumu.
/// Hiki i ka optimizer ke kuhikuhi i nā hoʻokaʻawale i hoʻohana ʻole ʻia e hiki ai iā ia ke hoʻopau holoʻokoʻa a neʻe paha i ka stack a no laila ʻaʻole e noi i ka mea hoʻokaʻawale.
/// Manaʻo hou paha ka optimizer he hewa ʻole ka hoʻokaʻawale ʻana, no laila e holo koke paha ke code i hoʻohana ʻole ʻia ma muli o ka hana ʻole o ka mea hāʻawi.
/// ʻOi aku ka concretely, he unsound kēia hiʻohiʻona laʻana, no ka mea e ʻae paha kāu mea hoʻokaʻawale e helu i ka nui o nā hoʻokaʻina i hana ʻia.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   E hoʻomaopopo ʻaʻole nā optimization i ʻōlelo ʻia ma luna wale nō i ka optimization e hiki ai ke noi.Oe i ke ano nui e hilinai aku maluna o ua ahu la allocations hanaia ina ka mea, hiki ke wehe 'ia me ka hoʻololi polokalamu hana.
///   Inā loaʻa ʻole ka hoʻokaʻawale ʻana ʻaʻole ia he ʻāpana o ka hana o ka papahana, ʻoiai inā hiki ke ʻike ʻia ma o ka mea hoʻokaʻawale e nānā i nā hoʻokaʻawale e ka paʻi ʻana a i ʻole nā hopena ʻē aʻe.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// E hoʻokaʻawale i ka hoʻomanaʻo e like me ka mea i wehewehe ʻia e ka `layout` i hāʻawi ʻia.
    ///
    /// Hoʻi i ka laʻau kuhikuhi no Puhi iho-anao? Aou iaiyoe, a Yard e ka hōʻike e auaaeaiea ole.
    ///
    /// # Safety
    ///
    /// Kēia kuleana pili i ka unsafe no ka mea, undefined hana hiki ia ho ina ka Caller aʻole e hōʻoia 'ia ai `layout` loaʻa' ole-Aʻohe nui.
    ///
    /// (Ka Manaÿo subtraits ke hoomakaukau hou kekahi i pale a ma ka hana, e like, ai ka 'kanaka kiaʻi wahi a ka Yard laʻau kuhikuhi ma muli o ka' Aʻohe-nui e auaaeaiea noi.)
    ///
    /// O anao? Aou aeie o ka iaiyoe e paha e ole e initialized.
    ///
    /// # Errors
    ///
    /// Ke hoʻihoʻi nei i kahi kiko kuhikuhi ʻole e hōʻike i ka pau ʻana o kahi hoʻomanaʻo a i ʻole ʻaʻole `layout` e kū i ka nui o kēia mea hāʻawi a i ʻole nā palena kaulike.
    ///
    /// Paipai ʻia nā hana e hoʻi i null i ka luhi o ka hoʻomanaʻo ma mua o ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate i ka aeie ana o iaiyoe ma ka hāʻawi `ptr` laʻau kuhikuhi me ka haawi mai `layout`.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana ma muli o ka hana undefined hiki ke hopena inā ʻaʻole e hōʻoia ka mea i kāhea i nā mea āpau:
    ///
    ///
    /// * `ptr` pono e hōʻike i kahi poloka o ka hoʻomanaʻo i hoʻokaʻawale ʻia ma o kēia mea hoʻokaʻawale,
    ///
    /// * `layout` pono ia i ka hoʻonohonoho like i hoʻohana ʻia e hoʻokaʻawale i kēlā palaka o ka hoʻomanaʻo.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// ʻO nā Behaves e like me `alloc`, akā hōʻoia pū nō hoʻi e hoʻonohonoho ʻia nā ʻike i ka ʻole ma mua o ka hoʻihoʻi ʻia.
    ///
    /// # Safety
    ///
    /// Kēia kuleana pili i ka unsafe no ka ia kumu i `alloc` mea.
    /// Eia naʻe ka mea i hāʻawi ʻia o ka hoʻomanaʻo e hōʻoia ʻia e hoʻomaka mua ʻia.
    ///
    /// # Errors
    ///
    /// Ke hoʻihoʻi nei i kahi kiko kuhikuhi ʻole e hōʻike i ka pau ʻana o ka hoʻomanaʻo a i ʻole ʻaʻole `layout` e kū i ka nui o ka mea hāʻawi a i ʻole nā palena kaulike, e like me `alloc`.
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: ʻo ka ʻaelike palekana no `alloc` pono e kākoʻo ʻia e ka mea e kāhea ana.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // Maluhia: like e auaaeaiea pomaikai ae la lakou, i ka māhele 'āina mai `ptr`
            // o ka nui `size` hōʻoia ʻia e kūpono no nā kākau.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// E hoʻoulu a ulu i kahi palaka o ka hoʻomanaʻo i ka `new_size` i hāʻawi ʻia.
    /// Ua wehewehe ʻia ka palaka e ka mea kuhikuhi `ptr` a me `layout` i hāʻawi ʻia.
    ///
    /// Inā hoʻihoʻi kēia i kahi kuhikuhi ʻole, a laila ʻo ka kuleana o ka poloka hoʻomanaʻo i kuhikuhi ʻia e `ptr` ua hoʻoili ʻia i kēia mea hoʻokaʻawale.
    /// Ua hoʻokau ʻia paha ka hoʻomanaʻo a ʻaʻole paha, a pono e noʻonoʻo ʻia ʻaʻole hiki ke hoʻohana ʻia (inā ʻaʻole ʻo ia e hoʻihoʻi hou ʻia i ka mea e kelepona ana ma o ka waiwai hoʻihoʻi o kēia hana).
    /// Hāʻawi ʻia ka poloka hoʻomanaʻo hou me `layout`, akā me ka `size` i hoʻohou ʻia i `new_size`.
    /// E e hoʻohana 'ia kēia houʻia ka wā deallocating ka hou iaiyoe hihia me `dealloc`.
    /// Loaʻa ka laulā `0..min(layout.size(), new_size) `o ka palaka hoʻomanaʻo hou i nā waiwai like me ka poloka kumu.
    ///
    /// Inā hoʻi ʻole kēia hana, a laila ʻaʻole i lawe ʻia ka kuleana o ka palaka hoʻomanaʻo i kēia mea hāʻawi, a ʻaʻole i loli nā ʻike o ka poloka hoʻomanaʻo.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana ma muli o ka hana undefined hiki ke hopena inā ʻaʻole e hōʻoia ka mea i kāhea i nā mea āpau:
    ///
    /// * `ptr` pono e hoʻokaʻawale ʻia i kēia manawa ma o kēia mea hoʻokaʻawale,
    ///
    /// * `layout` pono ia i ka hoʻonohonoho like i hoʻohana ʻia e hoʻokaʻawale i kēlā poloka o ka hoʻomanaʻo,
    ///
    /// * `new_size` pono kela aku kona nui ma mua o 'Aʻohe.
    ///
    /// * `new_size`, ke hoʻopuni ʻia i kahi kokoke i `layout.align()`, pono ʻole e kahe (ie, ʻoi aku ka liʻiliʻi o ka waiwai i hoʻopuni ʻia ma mua o `usize::MAX`).
    ///
    /// (Ka Manaÿo subtraits ke hoomakaukau hou kekahi i pale a ma ka hana, e like, ai ka 'kanaka kiaʻi wahi a ka Yard laʻau kuhikuhi ma muli o ka' Aʻohe-nui e auaaeaiea noi.)
    ///
    /// # Errors
    ///
    /// Hoʻihoʻi ʻole inā ʻaʻole hoʻokō ka hoʻonohonoho hou i ka nui a me nā palena kaulike o ka mea hoʻokaʻawale, a i ʻole inā ʻaʻole holomua ka reallocation.
    ///
    /// Implementations i hooluoluia mai ai e hoʻi Yard ma iaiyoe exhaustion, aole i ka'ā'ā a aborting, akā, i kēia mea,ʻaʻole he koi ikaika.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Makemake nā mea kūʻai aku e hōʻoki i ka helu i ka pane ʻana i kahi hemahema maoli e kāhea i ka hana [`handle_alloc_error`], ma mua o ke kāhea pololei ʻana iā `panic!` a i ʻole like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // Ka maluhia: o ka Caller pono hōʻoia 'ia ai ka `new_size` hana ole hoʻohālana.
        // `layout.align()` hele mai kahi `Layout` a no laila ua hōʻoia ʻia e kū pololei.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: pono e hōʻoia ka mea e kāhea ana he ʻoi aku ka nui o `new_layout` ma mua o ka ʻole.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: ʻaʻole hiki i ka palaka i hoʻokaʻawale ʻia i mua ke hoʻopili i ka palaka i hoʻokaʻawale hou ʻia.
            // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}