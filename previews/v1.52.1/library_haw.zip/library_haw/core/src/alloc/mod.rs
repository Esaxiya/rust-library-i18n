//! Nā API hoʻokaʻawale hoʻomanaʻo

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kuhi ka hemahema `AllocError` i kahi hoʻokaʻawale kālā i loaʻa ma muli o ka luhi o nā kumuwaiwai a i ʻole i kekahi mea hewa i ka hoʻohui ʻana i nā paio hoʻokomo i hāʻawi ʻia me kēia mea hoʻokaʻawale.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (pono mākou i kēia no ka implstream down o trait Kuʻia)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Hiki i kahi hoʻokō o `Allocator` ke hoʻokaʻawale, ulu, hoʻoliʻiliʻi, a hana i nā poloka kūlike ʻole o ka ʻikepili i wehewehe ʻia ma o [`Layout`][].
///
/// `Allocator` ua papahana e e hoʻokō ma ZSTs, kūmole, a akamai mea kuhikuhi no ka mea, ua i allocator e like `MyAlloc([u8; N])` hiki ole ke nee aku no ia, me ka hōʻano hou i nā mea kuhikuhi i ka anao? aou iaiyoe.
///
/// ʻAʻole like me [`GlobalAlloc`][], ʻae ʻia nā hoʻokaʻawale ʻole-nui i `Allocator`.
/// Inā ʻaʻole kākoʻo kahi mea hoʻokaʻawale ma lalo i kēia (e like me jemalloc) a i ʻole hoʻihoʻi i kahi kuhikuhi ʻole (e like me `libc::malloc`), pono e hopu ʻia kēia e ka hoʻokō.
///
/// ### Hoʻomanaʻo ʻānō
///
/// Kekahi o nā kiʻina hana i kauoha mai i ka iaiyoe hihia e *a ianoiyuaa a anao? Aou* Via ka allocator.Keia ano e:
///
/// * ka hoʻomaka aae? no ka mea, ua nalowale hihia mua hoi mai la ia e [`allocate`], [`grow`], a [`shrink`], a i
///
/// * ʻaʻole i hoʻololi hou ʻia ka palaka hoʻomanaʻo, kahi e hāʻawi pololei ʻia ai nā palaka e ka hāʻawi ʻia iā [`deallocate`] a i ʻole hoʻololi ʻia e ka hāʻawi ʻia iā [`grow`] a i ʻole [`shrink`] e hoʻihoʻi iā `Ok`.
///
/// Inā `grow` a `shrink` paha i hoʻihoʻi i `Err`, hoʻomau ka mana o ka kuhikuhi i hala.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Hoʻohui hoʻomanaʻo
///
/// Pono kekahi o nā kiʻina i kahi hoʻonohonoho *kūpono* i kahi palaka hoʻomanaʻo.
/// He aha ke ʻano o ka hoʻolālā i "fit" i kahi poloka hoʻomanaʻo i ke ʻano (a i ʻole ia, no ka palaka hoʻomanaʻo i "fit" i kahi hoʻonohonoho) ʻo ia nā ʻōlelo aʻe e paʻa:
///
/// * pono e anao? aou ia ka hihia a me ka mea ia hoʻopololei me [`layout.align()`], a
///
/// * Pono e hāʻule ka [`layout.size()`] i hāʻawi ʻia i ka pae `min ..= max`, kahi:
///   - `min` ʻo ka nui o ka hoʻonohonoho i hoʻohana ʻia e hoʻokaʻawale i ka palaka, a
///   - `max` o ka hope maoli nui hoʻi mai [`allocate`], [`grow`], a [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ua hoʻi mai nā poloka hoʻomanaʻo mai kahi mea hoʻokaʻawale e hoʻomanaʻo i ka hoʻomanaʻo pono a mālama i ko lākou pono a hiki i ka manawa i hāʻule ai nā clone āpau,
///
/// * cloning a neʻe maila i ke allocator pono ole invalidate hoomanao ālai 'hoi, mai keia allocator.A cloned allocator pono hele e like me ka ia allocator, a
///
/// * kekahi laʻau kuhikuhi i kekahi iaiyoe hihia i mea [*currently allocated*] i e hele i kekahi 'ē aʻe iaoia o ka allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Nā hoʻāʻo e hoʻokaʻawale i kahi poloka o ka hoʻomanaʻo.
    ///
    /// Ma ka kūleʻa, hoʻihoʻi i kahi [`NonNull<[u8]>`][NonNull] hālāwai i ka nui a me nā hoʻohiki kaulike o `layout`.
    ///
    /// Ka hoi aeie ke i he nui ka nui ma mua i hoakaka ia ma ka `layout.size()`, a hiki paha i ole i kona Contents initialized.
    ///
    /// # Errors
    ///
    /// Hōʻike i ka hoʻihoʻi `Err` hōʻike i ka pau ʻana o ka hoʻomanaʻo a i ʻole ʻaʻole `layout` e hālāwai i ka nui o ka mea hoʻokaʻawale a i ʻole nā palena kaulike.
    ///
    /// Paipai ʻia nā hana e hoʻihoʻi iā `Err` i ka luhi o ka hoʻomanaʻo ma mua o ka panicking a i ʻole ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Hoi e like `allocate`, akā, i hōʻoia 'ia ai i ka hoi iaiyoe mea Aʻohe-initialized.
    ///
    /// # Errors
    ///
    /// Hōʻike i ka hoʻihoʻi `Err` hōʻike i ka pau ʻana o ka hoʻomanaʻo a i ʻole ʻaʻole `layout` e hālāwai i ka nui o ka mea hoʻokaʻawale a i ʻole nā palena kaulike.
    ///
    /// Paipai ʻia nā hana e hoʻihoʻi iā `Err` i ka luhi o ka hoʻomanaʻo ma mua o ka panicking a i ʻole ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // Maluhia: `alloc`, e huli hou i ka henua pololei iaiyoe hihia
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Hāʻawi i kahi hoʻomanaʻo i kuhikuhi ʻia e `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` pono e hōʻike i kahi poloka o ka hoʻomanaʻo [*currently allocated*] ma o kēia mea hoʻokaʻawale, a
    /// * `layout` pono [*fit*] i kēlā palaka o ka hoʻomanaʻo.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Nā hoʻāʻo e hoʻolōʻihi i ka poloka hoʻomanaʻo.
    ///
    /// Hoʻihoʻi i kahi [`NonNull<[u8]>`][NonNull] hou i loaʻa kahi kuhikuhi a me ka nui maoli o ka hoʻomanaʻo i hoʻokaʻawale ʻia.Kūpono ka pointer no ka hoʻopaʻa ʻana i ka ʻikepili i wehewehe ʻia e `new_layout`.
    /// I mea e hoʻokō ai i kēia, hiki i ka mea hoʻokaʻawale ke hoʻolōʻihi i ka hoʻokaʻawale i kuhikuhi ʻia e `ptr` e kūpono i ka hoʻonohonoho hou.
    ///
    /// Inā hoʻihoʻi kēia iā `Ok`, a laila hoʻoili ʻia ka kuleana o ka palaka hoʻomanaʻo e `ptr` i kēia mea hāʻawi.
    /// Ua hoʻokuʻu ʻia a hoʻomanaʻo ʻole paha ka hoʻomanaʻo, a pono e noʻonoʻo ʻia ʻaʻole hiki ke hoʻohana ʻia inā ʻaʻole i hoʻihoʻi ʻia i ka mea e kelepona hou ana ma o ka waiwai hoʻihoʻi o kēia hana.
    ///
    /// Inā hoʻihoʻi kēia ala iā `Err`, a laila ʻaʻole i lawe ʻia ka kuleana o ka palaka hoʻomanaʻo i kēia mea hāʻawi, a ʻaʻole i loli nā ʻike o ka poloka hoʻomanaʻo.
    ///
    /// # Safety
    ///
    /// * `ptr` pono e hōʻike i kahi poloka o ka hoʻomanaʻo [*currently allocated*] ma o kēia mea hoʻokaʻawale.
    /// * `old_layout` pono [*fit*] i kēlā palaka o ka hoʻomanaʻo (ʻAʻole pono ka hoʻopaʻapaʻa `new_layout` iā ia.).
    /// * `new_layout.size()` pono e ʻoi aku ma mua o ka like o ka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hoʻi iā `Err` inā ʻaʻole hoʻokō ka ʻōnaehana hou i ka nui o ka mea hoʻokaʻawale a me nā palena kaulike o ka mea hoʻokaʻawale, a i ʻole inā ʻaʻole holomua ka ulu ʻana.
    ///
    /// Paipai ʻia nā hana e hoʻihoʻi iā `Err` i ka luhi o ka hoʻomanaʻo ma mua o ka panicking a i ʻole ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: no ka mea, ʻoi aku ka nui o `new_layout.size()` ma mua a i ʻole like paha
        // `old_layout.size()`, kūpono ka ʻelemakule a me ka hoʻokaʻawale hoʻomanaʻo hou no ka heluhelu a kākau ʻana no `old_layout.size()` bytes.
        // Eia kekahi, no ka mea, ʻaʻole i kaila ʻia ka hoʻokaʻawale kahiko, ʻaʻole hiki ke hoʻokau iā `new_ptr`.
        // No laila, palekana ke kāhea iā `copy_nonoverlapping`.
        // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ʻO nā Behaves e like me `grow`, akā hōʻoia pū nō hoʻi e hoʻonohonoho ʻia nā ʻike hou i ka ʻole ma mua o ka hoʻihoʻi ʻia.
    ///
    /// Aia i ka palaka hoʻomanaʻo kēia mau ʻike ma hope o ke kāhea maikaʻi ʻana iā
    /// `grow_zeroed`:
    ///   * Mālama ʻia nā bytes `0..old_layout.size()` mai ka hoʻokaʻawale kumu.
    ///   * Nāʻai `old_layout.size()..old_size` e kekahi e mālama 'ole' Aʻohe hualoaʻa, ke kaumaha ma muli o ka allocator manaʻo.
    ///   `old_size` pili i ka nui o ka poloka hoʻomanaʻo ma mua o ke kāhea ʻana o `grow_zeroed`, ʻoi aku paha ka nui ma mua o ka nui i noi mua ʻia i ka wā i hoʻokaʻawale ʻia ai.
    ///   * Hōʻalo ʻia nā Bytes `old_size..new_size`.`new_size` pili i ka nui o ka paʻa hoʻomanaʻo i hoʻihoʻi ʻia e ke kāhea `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` pono e hōʻike i kahi poloka o ka hoʻomanaʻo [*currently allocated*] ma o kēia mea hoʻokaʻawale.
    /// * `old_layout` pono [*fit*] i kēlā palaka o ka hoʻomanaʻo (ʻAʻole pono ka hoʻopaʻapaʻa `new_layout` iā ia.).
    /// * `new_layout.size()` pono e ʻoi aku ma mua o ka like o ka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hoʻi iā `Err` inā ʻaʻole hoʻokō ka ʻōnaehana hou i ka nui o ka mea hoʻokaʻawale a me nā palena kaulike o ka mea hoʻokaʻawale, a i ʻole inā ʻaʻole holomua ka ulu ʻana.
    ///
    /// Paipai ʻia nā hana e hoʻihoʻi iā `Err` i ka luhi o ka hoʻomanaʻo ma mua o ka panicking a i ʻole ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: no ka mea, ʻoi aku ka nui o `new_layout.size()` ma mua a i ʻole like paha
        // `old_layout.size()`, kūpono ka ʻelemakule a me ka hoʻokaʻawale hoʻomanaʻo hou no ka heluhelu a kākau ʻana no `old_layout.size()` bytes.
        // Eia kekahi, no ka mea, ʻaʻole i kaila ʻia ka hoʻokaʻawale kahiko, ʻaʻole hiki ke hoʻokau iā `new_ptr`.
        // No laila, palekana ke kāhea iā `copy_nonoverlapping`.
        // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Nā hoʻāʻo e hoʻoliʻiliʻi i ka palaka hoʻomanaʻo.
    ///
    /// Hoʻihoʻi i kahi [`NonNull<[u8]>`][NonNull] hou i loaʻa kahi kuhikuhi a me ka nui maoli o ka hoʻomanaʻo i hoʻokaʻawale ʻia.Kūpono ka pointer no ka hoʻopaʻa ʻana i ka ʻikepili i wehewehe ʻia e `new_layout`.
    /// E hoʻokō i kēia, hiki i ka mea hoʻokaʻawale ke hoʻoliʻiliʻi i ka hoʻokaʻawale i kuhikuhi ʻia e `ptr` e kūpono i ka ʻōnaehana hou.
    ///
    /// Inā hoʻihoʻi kēia iā `Ok`, a laila hoʻoili ʻia ka kuleana o ka palaka hoʻomanaʻo e `ptr` i kēia mea hāʻawi.
    /// Ua hoʻokuʻu ʻia a hoʻomanaʻo ʻole paha ka hoʻomanaʻo, a pono e noʻonoʻo ʻia ʻaʻole hiki ke hoʻohana ʻia inā ʻaʻole i hoʻihoʻi ʻia i ka mea e kelepona hou ana ma o ka waiwai hoʻihoʻi o kēia hana.
    ///
    /// Inā hoʻihoʻi kēia ala iā `Err`, a laila ʻaʻole i lawe ʻia ka kuleana o ka palaka hoʻomanaʻo i kēia mea hāʻawi, a ʻaʻole i loli nā ʻike o ka poloka hoʻomanaʻo.
    ///
    /// # Safety
    ///
    /// * `ptr` pono e hōʻike i kahi poloka o ka hoʻomanaʻo [*currently allocated*] ma o kēia mea hoʻokaʻawale.
    /// * `old_layout` pono [*fit*] i kēlā palaka o ka hoʻomanaʻo (ʻAʻole pono ka hoʻopaʻapaʻa `new_layout` iā ia.).
    /// * `new_layout.size()` pono e ʻoi aku ka liʻiliʻi ma mua o ka like o ka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Hoʻihoʻi iā `Err` inā ʻaʻole hoʻokō ka ʻōnaehana hou i ka nui o ka mea hoʻokaʻawale a me nā palena kaulike o ka mea hoʻokaʻawale, a i ʻole inā ʻaʻole e holomua.
    ///
    /// Paipai ʻia nā hana e hoʻihoʻi iā `Err` i ka luhi o ka hoʻomanaʻo ma mua o ka panicking a i ʻole ka haʻalele ʻana, akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// (Ua hōʻike hewa: ia mea *loio i* e? Ii keia trait luna i ka hp'pnphp maoli e auaaeaiea waihona i'ō'ū ma iaiyoe exhaustion.)
    ///
    /// Nā mea mālama mai no ko ianei manao i'ō'ū computation ma muli o ka auaaeaiea hewa i hooluoluia mai ai e kapa aku i ke kuleana pili i [`handle_alloc_error`], ma mua 'ana kahea `panic!` ole i 'ano like.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: no ka mea, pono ka `new_layout.size()` ma lalo o ka like a i ʻole
        // `old_layout.size()`, kūpono ka ʻelemakule a me ka hoʻokaʻawale hoʻomanaʻo hou no ka heluhelu a kākau ʻana no `new_layout.size()` bytes.
        // Eia kekahi, no ka mea, ʻaʻole i kaila ʻia ka hoʻokaʻawale kahiko, ʻaʻole hiki ke hoʻokau iā `new_ptr`.
        // No laila, palekana ke kāhea iā `copy_nonoverlapping`.
        // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Hana i kahi adapter "by reference" no kēia hanana o `Allocator`.
    ///
    /// Hoʻokomo pū ka mea hoʻopili hoʻihoʻi iā `Allocator` a hōʻaiʻē maʻalahi i kēia.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: pono e mālama ʻia ka ʻaelike palekana e ka mea e kelepona ana
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: pono e mālama ʻia ka ʻaelike palekana e ka mea e kelepona ana
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: pono e mālama ʻia ka ʻaelike palekana e ka mea e kelepona ana
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: pono e mālama ʻia ka ʻaelike palekana e ka mea e kelepona ana
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}