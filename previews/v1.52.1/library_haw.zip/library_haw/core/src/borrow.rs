//! Kahi modula no ka hana ʻana me ka ʻike hōʻaiʻē.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait no ka ʻikepili hōʻaiʻē.
///
/// Ma Rust, ia mea, he pono ole ia i kekahi mau mea ia e hoohalike o ka hoailona no kekahi hana hihia.
/// ʻO kahi laʻana, hiki ke koho kikoʻī i kahi e waiho ai a me ka hoʻokele no kahi waiwai e like me ke kūpono no kahi hoʻohana kikoʻī ma o nā ʻano kuhikuhi e like me [`Box<T>`] a i ʻole [`Rc<T>`].
/// Ma waho o kēia mau ʻōwili generic i hiki ke hoʻohana ʻia me kekahi ʻano, hāʻawi kekahi mau ʻano i nā helehelena koho e hāʻawi ana i nā hana kumu kūʻai.
/// An hana no e like me keʻano o [`String`] i kō ka hiki, e hohola aku i ke kaula i ke kumu o [`str`].
/// Pono kēia i ka mālama ʻana i ka ʻike hou aʻe ʻaʻole pono no kahi kaula maʻalahi a luli ʻole.
///
/// Hāʻawi kēia ʻano i ke komo ʻana i ka ʻikepili kumu ma o nā kuhikuhi i ka ʻano o kēlā ʻikepili.ʻ saidlelo ʻia lākou e 'ʻaiʻē ʻia e like me kēlā' ano.
/// No ka mea he nui, he [`Box<T>`] hiki ke aie me `T`, oiai he [`String`] hiki ke aie me `str`.
///
/// Hōʻike nā ʻano hiki ke hōʻaiʻē ʻia e like me kekahi ʻano `T` e ka hoʻokomo ʻana iā `Borrow<T>`, e hāʻawi ana i kahi kuhikuhi i kahi `T` ma ke ʻano trait's [`borrow`].ʻAʻohe manuahi kahi hōʻaiʻē e like me nā ʻano ʻokoʻa.
/// Inā makemake ia e hōʻaiʻē mutable e like me ke ʻano-e ʻae ana i nā ʻikepili i lalo e hoʻololi ʻia, hiki iā ia ke hoʻokō pū me [`BorrowMut<T>`].
///
/// Eia hou, ke hāʻawi nei i nā hoʻokō no traits hou aku, pono e noʻonoʻo inā lākou e hana like me nā ʻano o ke ʻano ma muli o ka hana ʻana ma ke ʻano he hiʻohiʻona o kēlā ʻano kumu.
/// Hoʻohana maʻamau ka code Generic iā `Borrow<T>` ke hilinaʻi ia i ka hana like o kēia mau trait hoʻokō.
/// E ʻike ʻia paha kēia traits ma ke ʻano he trait bounds hou aʻe.
///
/// Ma kekahi `Eq`, pono e like no ka aie a me ka waiwai nā loina `Ord` a me `Hash`: `x.borrow() == y.borrow()` e haawi aku i ka ia hopena like `x == y`.
///
/// Inā nōhie kivila wale no pono, e hana no nā mea a pau ano i hiki i ka olua i nāʻano `T`, ia mea pinepine maikaʻi, e hoʻohana [`AsRef<T>`] like hou ano hiki maluhia hoʻokō i ia.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ma ke ʻano he hōʻiliʻili ʻikepili, nona ka [`HashMap<K, V>`] i nā kī a me nā waiwai.Inā i ke ki i ka maoliʻikepili ua wahīʻia i loko o ka mālama 'ana i' ano o kekahi mau ano, ka mea e, nae, nō e hiki i ka huli 'ana i ka waiwai me ka hoʻohana i ka olua i ke ki o kaʻikepili.
/// ʻO kahi laʻana, inā he kaula ke kī, a laila mālama ʻia paha me ka palapala ʻāina hash ma ke ʻano he [`String`], ʻoiai e hiki ke ʻimi me ka [`&str`][`str`].
/// No laila, pono e hana ʻo `insert` ma kahi `String` ʻoiai e hiki i `get` ke hoʻohana i `&str`.
///
/// Kānaka Nohie, i ka pili mau māhele o `HashMap<K, V>` nana aku e like keia:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // waiho ʻia nā mahinaʻai
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// ʻO ka palapala ʻāina holoʻokoʻa holoʻokoʻa he generic ma luna o kahi kī nui `K`.Ma muli o ka mālama ʻia o kēia mau kī me ka palapala ʻāina hash, pono kēia ʻano e ʻikepili i ke kī.
/// Ke hoʻokomo nei i kahi pālua waiwai nui, hāʻawi ʻia ka palapala ʻāina i kahi `K` a pono e ʻike i ka bakeke hash pololei a nānā inā aia ke kī ma muli o kēlā `K`.no ia mea, he pono It `K: Hash + Eq`.
///
/// Ke ʻimi nei i kahi waiwai i ka palapala ʻāina, eia nō naʻe, e hāʻawi i kahi kuhikuhi i kahi `K` ma ke ʻano he ki e ʻimi ai e koi mau e hana i kahi waiwai i loaʻa.
/// No nā kī kī, ʻo ia hoʻi he `String` waiwai e pono e hana ʻia no ka ʻimi ʻana i nā hihia kahi `str` wale nō e loaʻa.
///
/// Akā, generic ka hana `get` ma luna o ke ʻano o ka ʻikepili kī paʻa, i kapa ʻia ʻo `Q` i ke ʻano hana ma luna.Ua hākālia nō i `K` noi wale aku me ka `Q` e noi ana e make `K: Borrow<Q>`.
/// Ma ke koi pono ʻana iā `Q: Hash + Eq`, hōʻailona ia i ke koi a `K` a me `Q` i nā hoʻokō o `Hash` a me `Eq` traits e hua like ana i nā hopena.
///
/// Ka manaʻo o `get` nui i loko o pau ma'ālike implementations o `Hash` ma ka hoomaopopo ana i ke ki i ka hasa bākeke ma kahea `Hash::hash` ma ka `Q` waiwai, a hiki nae ia hookomo i ke kī ma muli o ka hasa cia pōpilikia mai ka `K` waiwai.
///
///
/// A ʻo kahi hopena, haki ka palapala ʻāina hash inā hana ka `K` i ka wahī ʻana i kahi waiwai `Q` i kahi hash ʻokoʻa ma mua o `Q`.No ka mea he nui, i noonoo ai oe i ka hoailona e wahī mai i ke kaula akā, hoʻohālikeʻana ASCII palapala ignoring lākou hihia:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// No ka mea pono ʻelua mau waiwai like e pono e hana i ka waiwai hash like, pono e mālama ʻole ka hoʻokō ʻana o `Hash` i ka hihia ASCII.
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Hiki iā `CaseInsensitiveString` ke hoʻokomo iā `Borrow<str>`?Hiki iā ia ke hāʻawi i kahi kuhikuhi i kahi ʻāpana kaula ma o kāna kaula i loaʻa.
/// Akā, no ka mea, kona `Hash` manaʻo ka oko ao, ka mea, hoi okoa mai `str`, a nolaila, pono ole, ma ka mea, hoʻokō i `Borrow<str>`.
/// Inā makemake ia e ʻae i nā poʻe ʻē aʻe e komo i ka `str` kumu, hiki iā ia ke hana ma o `AsRef<str>` i lawe ʻole i nā koi keu.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Hoʻoiho ʻole ʻia mai kahi waiwai waiwai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait no ka mutably i lawekahikiʻiaʻikepili.
///
/// Ma ke ʻano he hoa i [`Borrow<T>`] ʻae kēia trait i kahi ʻano e hōʻaiʻē ma ke ʻano he kumu ma o ka hāʻawi ʻana i kahi kūmole hiki ke hoʻololi.
/// E nānā i [`Borrow<T>`] no ka 'ike hou aku i lawekahikiʻia me kekahiʻano.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably e noi mai i waiwai nui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}