use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ʻO kahi kikowaena no ka hana ʻana me nā iterator asynchronous.
///
/// ʻO kēia ke kahawai nui trait.
/// No ka mea hou aʻe e pili ana i ka manaʻo o nā kahawai ma ka maʻamau, e ʻoluʻolu e ʻike i ka [module-level documentation].
/// Ma kahi kikoʻī, makemake ʻoe e ʻike pehea e [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Ke ʻano o nā huahana i hāʻawi ʻia e ke kahawai.
    type Item;

    /// Hoao e huki mai i ka pili waiwai o keia kahawai, ke kau helu keleponaʻana i ka he hana no wakeup ina ka waiwai mea,ʻaʻole i loaʻa, a me ka hoi mai `None` ina ke kahawai mea hooweliweli.
    ///
    /// # Waiwai hoʻihoʻi
    ///
    /// Nui a hewahewa paha nā hoʻihoʻi e hiki ai, kēlā me kēia e hōʻike ana i kahi kūlana kahawai ʻokoʻa:
    ///
    /// - `Poll::Pending` ʻo ia hoʻi ʻaʻole mākaukau ka waiwai hou o kēia kahawai.E hōʻoia nā hoʻokō e hoʻomaopopo ʻia ka hana o kēia manawa ke mākaukau ka waiwai aʻe.
    ///
    /// - `Poll::Ready(Some(val))` ʻo ia hoʻi ua hana maikaʻi ke kahawai i kahi waiwai, `val`, a hana paha i nā waiwai hou aʻe ma nā kāhea `poll_next` ma hope.
    ///
    /// - `Poll::Ready(None)` ʻo ia hoʻi ua hoʻopau ʻia ke kahawai, a ʻaʻole pono e kāhea hou ʻia ʻo `poll_next`.
    ///
    /// # Panics
    ///
    /// Once ke kahawai i pau (hoi `Ready(None)` from `poll_next`), e kahea ana kona `poll_next` iaoia hou ke panic, aeie ka wa pau ole, a me ke kumu 'ē aʻe ano o ka pilikia; ka `Stream` trait wahi i koi ia ma ka hopena o ia i ke kahea.
    ///
    /// Eia naʻe, e like me ka `poll_next` iaoiaeii ua ole ia `unsafe`, Rust ka mau rula pili: kelepona 'pono loa i undefined hana (iaiyoe palaho, pololei ole ana o `unsafe` oihana, a me ka e like), nānā' ole o ke kahawai o ka moku'āina.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Hoʻihoʻi i nā palena i ke koena o ke kahawai.
    ///
    /// Ua hōʻike hewa, `size_hint()`, hoi mai i ka tuple kahi o ka mua hehee ai o ka lalo nakinaki aku la ia, a me ka lua o ka hehee ai o ka luna e paa ana.
    ///
    /// I ka lua o ka hapalua o ka tuple i ua hoʻi mea he ['Option`]' <'[' usize`] '>'.
    /// A [`None`] ʻaneʻi mea i kekahi ole ma laila ua ike keena e paa ana, a me na luna e paa ana ka nui ma mua o [`usize`].
    ///
    /// # Nā memo hoʻokō
    ///
    /// ʻAʻole ia e hoʻokō ʻia i ka hoʻokō ʻia ʻana o kahi kahawai e hōʻike i ka helu o nā kumu.Hiki i kahi kahawai buggy ke hāʻawi ma lalo o ka palena haʻahaʻa a ʻoi aku paha ma mua o ka palena o luna o nā mea.
    ///
    /// `size_hint()` ua kuhikuhi manaoia e e hoʻohana no ka optimizations e like me koe wa no na kumu o ke kahawai, akā, pono ole e hilinaʻi i IAOEIAaO, omit iho i pale a loaʻa, e kaha i ka unsafe kivila.
    /// An pololei ole manaʻo o `size_hint()` e ole e alakai i ka iaiyoe palekana 'aʻe'.
    ///
    /// ʻO kēlā i ʻōlelo ʻia, pono i ka hoʻokō ʻana e hāʻawi i kahi kuhi kūpono, no ka mea inā ʻaʻole ia he mea hōʻeha i ka protocol o trait.
    ///
    /// Ka paʻamau manaʻo hoike `(0,` ['None`]') 'i mea pololei no kekahi kahawai.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}