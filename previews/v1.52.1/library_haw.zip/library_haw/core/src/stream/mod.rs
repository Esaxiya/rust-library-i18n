//! ʻO ka hana hou asynchronous i haku ʻia.
//!
//! Inā futures he mau helu like ʻole, a laila ʻo nā kahawai he iterators asynchronous.
//! Inā ʻoe i ʻike iā ʻoe iho me kahi hōʻuluʻulu asynchronous o kekahi ʻano, a pono e hana i kahi hana ma nā mea o ka hōʻiliʻili i ʻōlelo ʻia, holo koke ʻoe i 'streams'.
//! Hoʻohana nui ʻia nā kahawai i ka code Rust idynomic asynchronous, no laila pono ke kamaʻāina me lākou.
//!
//! Mamua o ka weheweheʻana aku, e ka olelo e pili ana i keia Module ua mea kūkulu:
//!
//! # Organization
//!
//! Hoʻonohonoho nui ʻia kēia module e ka ʻano:
//!
//! * [Traits] ʻo ia ka mahele nui: wehewehe kēia traits i ke ʻano o nā kahawai e kū nei a me nā mea hiki iā ʻoe ke hana me lākou.Nā hakakā o kēia mau traits pono kau aku la i kekahi mau keu study manawa i loko o.
//! * Hāʻawi nā hana i kekahi mau ala kōkua e hana i kekahi mau kahawai kumu.
//! * ʻO ke ʻano pinepine nā ʻano hoʻihoʻi o nā kiʻina like ʻole ma kēia module traits.Makemake ʻoe e nānā i ke ʻano hana i hana i ka `struct`, ma mua o ka `struct` ponoʻī.
//! No nā kikoʻī e pili ana i ke kumu, e ʻike iā '[Kahe ʻana i ke Kahawai](#ke hoʻokō nei i ke kahawai)'.
//!
//! [Traits]: #traits
//!
//! O ia wale nō!E ʻeli kāua i nā kahawai.
//!
//! # Stream
//!
//! ʻO ka puʻuwai a me ka ʻuhane o kēia module ka [`Stream`] trait.ʻO ke kumu o [`Stream`] e like me kēia:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Haʻalele `Iterator`, `Stream` ʻo ia ke hoʻokaʻawale i waena o ka [`poll_next`] iaoiaeii i ka hoʻohana 'ia ka wā hoʻokō i ka `Stream`, a me ka (to-be-implemented) `next` iaoia ia e hoopau ana i ke kahawai i ua i hoʻohana.
//!
//! Pono nā mea kūʻai mai o `Stream` e noʻonoʻo iā `next`, ke hea ʻia, e hoʻihoʻi iā future e hāʻawi iā `Option<Stream::Item>`.
//!
//! Ka future hoi ma `next`, e hookuu aku `Some(Item)` like loa me he mau oihana mua, a koke ka mea, hulina a pau 'ana, e hoohua `None` i ka hōʻike' ana i iteration ua pau.
//! Inā mākou e kali ana i kahi mea asynchronous e hoʻonā, e kali ʻo future a mākaukau ke kahawai e hāʻawi hou.
//!
//! Kanaka kahawai e koho i ka hoʻomau 'iteration, a no laila, kahea `next` hou e paha e ole e ho'ōla hua `Some(Item)` hou ma kekahi mau wahi.
//!
//! [`Stream`] 's piha ka wehewehena ka loaʻa o ka helu ana o na ano like ola, akā, ka mea, i ka paʻamau ano, kūkuluʻia ma luna o [`poll_next`], a no laila, lawe oe ia no ka noa.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ke kahawai hoʻokō
//!
//! Ke hana nei i kahi kahawai o kāu pono e pili ana i ʻelua mau ʻanuʻu: e hana ana i `struct` e hoʻopaʻa i ka mokuʻāina o ke kahawai, a laila e hoʻokō nei iā [`Stream`] no kēlā `struct`.
//!
//! E ka e ke kahawai, o `Counter` i helu mai `1` a hiki i `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // ʻO ka mea mua,
//!
//! /// A kahawai i helu mai kekahi i ka elima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ua makemake mākou helu e hoʻomaka i kekahi, no laila, e ka hookui he new() papa hana no ke kōkua.
//! // Kēia mea,ʻaʻole pololei pono, akā, ua pono.
//! // E hoʻomaopopo e hoʻomaka mākou i `count` ma zero, e ʻike mākou i ke kumu ma ka `poll_next()`'s hoʻokō ʻana ma lalo.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // A laila, hoʻokō mākou iā `Stream` no kā mākou `Counter`:
//!
//! impl Stream for Counter {
//!     // mākou e e helu me ka usize
//!     type Item = usize;
//!
//!     // poll_next() ʻo ia wale nō ka hana i koi ʻia
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Xi mākou helu.ʻO kēia ke kumu a mākou i hoʻomaka ai ma ka ʻole.
//!         self.count += 1;
//!
//!         // E nānā inā ua pau kā mākou helu ʻana ʻaʻole paha.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! He palaualelo nā kahawai.ʻO kēia ka hana ʻana i kahi kahawai ʻaʻole _do_ i kahi nui āpau.ʻAʻohe mea maoli a hiki i kou kāhea ʻana iā `next`.
//! ʻO kēia kekahi kumu o ka huikau i ka hana ʻana i kahi kahawai no kāna hopena ʻaoʻao.
//! E aʻo mai ka mea nāna mākou e pili ana i kēia ʻano hana:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;