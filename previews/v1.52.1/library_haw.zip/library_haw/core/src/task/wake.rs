#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Hāʻawi kahi `RawWaker` i ka mea hoʻokō i kahi luna hoʻokō hana e hana i kahi [`Waker`] e hāʻawi nei i ka hana ʻala ala.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Aia ia i kahi ʻikepili kikoʻī a me ka [virtual function pointer table (vtable)][vtable] e hoʻomaʻamaʻa i ka hana o ka `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Kahi kuhikuhi ʻikepili, hiki ke hoʻohana ʻia e mālama i ka ʻikepili kūwaho e like me ke koi a ka luna hoʻokō.
    /// Hiki paha kēia
    /// kahi kuhikuhi kuhikuhi i holoi ʻia i `Arc` e pili ana i ka hana.
    /// Hoʻouna ʻia ka waiwai o kēia kahua i nā hana āpau i ʻāpana o ka vtable ma ke ʻano he pae mua.
    ///
    data: *const (),
    /// Pākaukau kuhikuhi kikohoʻe hana maʻamau i ka hana o kēia ala ala.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Hana i kahi `RawWaker` hou mai ka kuhikuhi `data` i hāʻawi ʻia a me `vtable`.
    ///
    /// Hiki ke hoʻohana ʻia ka mākuhi `data` e mālama i ka ʻikepili kaulike e like me ke koi a ka luna hoʻokō.Hiki paha kēia
    /// kahi kuhikuhi kuhikuhi i holoi ʻia i `Arc` e pili ana i ka hana.
    /// E lilo ka waiwai o kēia kuhikuhi i nā hana āpau i ʻāpana o ka `vtable` ma ke ʻano he palena mua.
    ///
    /// Na `vtable` hoʻopilikino i ka hana o ka `Waker` iʻia hana, mai ka `RawWaker`.
    /// No kēlā me kēia hana ma luna o ka `Waker`, ka mea pili i hana i loko o ka `vtable` o ka hp'pnphp `RawWaker` e e kapaʻia.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// ʻO kahi papa kuhikuhi poʻomanaʻo hana (vtable) e kuhikuhi ana i ke ʻano o [`RawWaker`].
///
/// Ua hala ka pointer i nā hana āpau i loko o ka vtable ʻo ka kuhikuhi `data` mai ka mea [`RawWaker`] e hoʻopili ana.
///
/// ʻO nā hana i loko o kēia mea i manaʻo wale ʻia e kāhea ʻia ma ka `data` kuhikuhi o kahi mea [`RawWaker`] i kūkulu pono ʻia mai loko mai o ka [`RawWaker`] hoʻokō.
/// Kahea ana i kekahi o na mana i kakauiaʻi maluna hoʻohana 'ana i kekahi' ē aʻe `data` laʻau kuhikuhi e i undefined kolohe.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// E e kapaʻia kēia papa, i ka wa o ka [`RawWaker`] ʻia cloned, IAOEIAaO ka wā o ka [`Waker`] ma i ka [`RawWaker`] ua waiho wahoʻia cloned.
    ///
    /// Pono e mālama i ka hana o kēia hana i nā kumuwaiwai āpau e koi ʻia no kēia hanana hou o kahi [`RawWaker`] a me ka hana i pili.
    /// Ke kāhea nei iā `wake` ma ka hopena [`RawWaker`] pono e hopena i kahi ala like o ka hana like e hoʻāla ʻia e ka [`RawWaker`] kumu.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// E kāhea ʻia kēia hana ke kāhea ʻia ʻo `wake` ma ka [`Waker`].
    /// Pono e ala i ka hana e pili ana i kēia [`RawWaker`].
    ///
    /// Pono e hoʻokō i ka hana o kēia hana e hoʻokuʻu i nā kumuwaiwai e pili ana i kēia hanana o [`RawWaker`] a me ka hana i pili.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// E kāhea ʻia kēia hana ke kāhea ʻia ʻo `wake_by_ref` ma ka [`Waker`].
    /// Pono e ala i ka hana e pili ana i kēia [`RawWaker`].
    ///
    /// Ua like kēia hana me `wake`, akā ʻaʻole pono e hoʻopau i ka kuhikuhi kuhikuhi i hāʻawi ʻia.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Kāhea ʻia kēia hana ke hāʻule kahi [`RawWaker`].
    ///
    /// Pono e hoʻokō i ka hana o kēia hana e hoʻokuʻu i nā kumuwaiwai e pili ana i kēia hanana o [`RawWaker`] a me ka hana i pili.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// I ka mea hou `RawWakerVTable` mai o ka hoakaka `clone`, `wake`, `wake_by_ref`, a me `drop` hana.
    ///
    /// # `clone`
    ///
    /// E e kapaʻia kēia papa, i ka wa o ka [`RawWaker`] ʻia cloned, IAOEIAaO ka wā o ka [`Waker`] ma i ka [`RawWaker`] ua waiho wahoʻia cloned.
    ///
    /// Pono e mālama i ka hana o kēia hana i nā kumuwaiwai āpau e koi ʻia no kēia hanana hou o kahi [`RawWaker`] a me ka hana i pili.
    /// Ke kāhea nei iā `wake` ma ka hopena [`RawWaker`] pono e hopena i kahi ala like o ka hana like e hoʻāla ʻia e ka [`RawWaker`] kumu.
    ///
    /// # `wake`
    ///
    /// E kāhea ʻia kēia hana ke kāhea ʻia ʻo `wake` ma ka [`Waker`].
    /// Pono e ala i ka hana e pili ana i kēia [`RawWaker`].
    ///
    /// Pono e hoʻokō i ka hana o kēia hana e hoʻokuʻu i nā kumuwaiwai e pili ana i kēia hanana o [`RawWaker`] a me ka hana i pili.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// E kāhea ʻia kēia hana ke kāhea ʻia ʻo `wake_by_ref` ma ka [`Waker`].
    /// Pono e ala i ka hana e pili ana i kēia [`RawWaker`].
    ///
    /// Ua like kēia hana me `wake`, akā ʻaʻole pono e hoʻopau i ka kuhikuhi kuhikuhi i hāʻawi ʻia.
    ///
    /// # `drop`
    ///
    /// Kāhea ʻia kēia hana ke hāʻule kahi [`RawWaker`].
    ///
    /// Pono e hoʻokō i ka hana o kēia hana e hoʻokuʻu i nā kumuwaiwai e pili ana i kēia hanana o [`RawWaker`] a me ka hana i pili.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ʻO ka `Context` o kahi hana asynchronous.
///
/// I kēia manawa, lawelawe wale ʻo `Context` i ke komo ʻana i kahi `&Waker` i hiki ke hoʻohana ʻia e hoʻāla i ka hana o kēia manawa.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // E hōʻoia iā mākou future-hōʻoia e kūʻē i nā loli o ka hoʻololi ʻana i ke ola āpau e lilo i invariant (hoʻopaʻapaʻa ke ʻano o nā manawa hoʻopaʻapaʻa ʻoiai nā covariant mau manawa hoʻihoʻi hoʻi).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Hana i kahi `Context` hou mai kahi `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Hoʻihoʻi i kahi kuhikuhi i ka `Waker` no ka hana o kēia manawa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// ʻO kahi `Waker` kahi lima no ke ala ʻana i kahi hana ma ka hoʻomaopopo ʻana i kāna mea hoʻokō ua mākaukau ia e holo.
///
/// Hoʻopili kēia lima i kahi hanana [`RawWaker`], kahi e wehewehe ai i ka hana ala ʻokoʻa e ka luna hoʻokō.
///
///
/// Hoʻokomo i ka [`Clone`], [`Send`], a me [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// E ala aʻe i ka hana e pili ana i kēia `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Hāʻawi ʻia ke kāhea ala maoli ma o kahi kāhea uila i ka hoʻokō i wehewehe ʻia e ka mea hoʻokō.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Mai kāhea iā `drop`-e hoʻopau ʻia ka mea ala e `wake`.
        crate::mem::forget(self);

        // SAFETY: Palekana kēia no ka mea ʻo `Waker::from_raw` wale nō ke ala
        // e hoʻomaka i ka `wake` a me `data` e koi ana i ka mea hoʻohana e ʻike i ka mālama ʻia o ka ʻaelike o `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// E ala aʻe i ka hana e pili ana i kēia `Waker` me ka hoʻopau ʻole ʻana i ka `Waker`.
    ///
    /// Ua like kēia me `wake`, akā emi iki paha ka maikaʻi i ka hihia i loaʻa kahi `Waker` nona.
    /// Kēia hana e e he makemake ko i kahea `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Hāʻawi ʻia ke kāhea ala maoli ma o kahi kāhea uila i ka hoʻokō i wehewehe ʻia e ka mea hoʻokō.
        //

        // SAFETY: ʻike iā `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Hoʻihoʻi iā `true` inā kēia `Waker` a me kekahi `Waker` i ala aʻe i ka hana like.
    ///
    /// Hana kēia hana ma ke kumu hoʻāʻo maikaʻi loa, a hoʻi paha i ka wahaheʻe a hiki i ka wā e ala ai ka 'Waker i ka hana like.
    /// Eia nō naʻe, inā hoʻihoʻi kēia hana i `true`, ua hoʻohiki ʻia e hoʻāla ka ʻo Waker i ka hana like.
    ///
    /// Hoʻohana nui ʻia kēia hana no nā kumu ʻoi loa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Hana i kahi `Waker` hou mai [`RawWaker`].
    ///
    /// Ua undefined ka hana ana o ka hoi mai `Waker` ina palapala kuhikuhi i ka aelike ho'ākāka 'ia i loko o [' RawWaker`] 's a [`RawWakerVTable`]' s ua i kokuaia oia.
    ///
    /// No laila ʻaʻole palekana kēia hana.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: Palekana kēia no ka mea ʻo `Waker::from_raw` wale nō ke ala
            // e hoʻomaka i ka `clone` a me `data` e koi ana i ka mea hoʻohana e ʻike i ka mālama ʻia o ka ʻaelike o [`RawWaker`].
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: Palekana kēia no ka mea ʻo `Waker::from_raw` wale nō ke ala
        // e hoʻomaka i ka `drop` a me `data` e koi ana i ka mea hoʻohana e ʻike i ka mālama ʻia o ka ʻaelike o `RawWaker`.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}