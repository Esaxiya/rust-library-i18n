#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Loaʻa nā wehewehe wehewehe no ka hoʻonohonoho ʻana o nā ʻano kūkulu i kūkulu ʻia i loko.
//!
//! Ka mea hiki ke hoʻohana i pale o transmutes ma unsafe code for Na manipulating ka maka e hoohalike ai ia 'ana.
//!
//!
//! Kūlike mau kā lākou wehewehe i ka ABI i ho'ākāka ʻia ma `rustc_middle::ty::layout`.
//!

/// ʻO ka hiʻohiʻona o kahi mea trait e like me `&dyn SomeTrait`.
///
/// Loaʻa ka hoʻonohonoho like o kēia struct me nā ʻano e like me `&dyn SomeTrait` a me `Box<dyn AnotherTrait>`.
///
/// `TraitObject` ua ua hoʻohiki e aʻohe layouts, akā, ia mea i ke ano o trait mea (e like, i nā mahinaʻai i ole pololei ole ma ka `&dyn SomeTrait`), aole hoi e hana ia ka pāʻana iʻia (hoʻololi i ka ho'ākāka 'ana e ole e hoʻololi i ke kūpono o ka `&dyn SomeTrait`).
///
/// Ua ua wale papahana e ke hoʻohana 'ia e unsafe kivila e pono e manipulate i ka haʻahaʻa-ʻilikai lāliʻi.
///
/// ʻAʻohe ala e kuhikuhi ai i nā mea trait āpau āpau, no laila ke ala hoʻokahi e hana i nā waiwai o kēia ʻano me nā hana e like me [`std::mem::transmute`][transmute].
/// Pēlā nō, ʻo ke ala hoʻokahi e hana ai i kahi trait ʻoiaʻiʻo mai kahi `TraitObject` waiwai me `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing he trait mea me mismatched ano-kekahi ma ka vtable hana i hoʻopili like i ke 'ano o ka waiwai i a kaʻikepili laʻau kuhikuhi nui-ka lahui paha, e alakai i ka undefined kolohe.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // kahi laʻana trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // e hana ka mea hoʻopili i kahi mea trait
/// let object: &dyn Foo = &value;
///
/// // e nānā i ka hōʻike maka
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ʻo ka helu kuhikuhi ʻikepili ka helu wahi o `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // kūkulu i kahi mea hou, e kuhikuhi ana i kahi `i32` ʻokoʻa, e akahele ana i ka hoʻohana ʻana i ka `i32` vtable mai `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // pono e hana e like me inā mākou i kūkulu i kahi trait mea mai `other_value` pololei
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}