//! Nā ala e hana ai i kahi `str` mai ka ʻāpana bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Hoʻohuli i kahi ʻāpana bytes i kahi ʻāpana string.
///
/// Hana ʻia kahi aho ([`&str`]) e nā bytes ([`u8`]), a hana ʻia kahi byte slice ([`&[u8]`][byteslice]) e nā bytes, no laila hoʻololi kēia hana ma waena o nā mea ʻelua.
/// ʻAʻole nā ʻāpana byte āpau i nā ʻāpana kaula pono, eia nō naʻe: koi ʻo [`&str`] e pololei UTF-8.
/// `from_utf8()` nā hōʻoia e hōʻoia i ka pololei o nā bytes UTF-8, a laila hana ka hoʻololi.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Inā ʻoe e maopopo he pololei UTF-8 i ka ʻāpana byte, a ʻaʻole ʻoe makemake e loaʻa i ka overhead o ka hōʻoia hōʻoia, aia kahi mana palekana ʻole o kēia hana, [`from_utf8_unchecked`], nona ka ʻano like akā haʻalele i ka hōʻoia.
///
///
/// Inā makemake ʻoe i `String` ma kahi o `&str`, e noʻonoʻo iā [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// No ka mea hiki iā ʻoe ke hoʻokau-hoʻokaʻawale i kahi `[u8; N]`, a hiki iā ʻoe ke lawe i kahi [`&[u8]`][byteslice] o ia, ʻo kēia hana kahi ala hoʻokahi e loaʻa ai kahi aho i hoʻokaʻawale ʻia.Aia kekahi laʻana o kēia ma nā ʻāpana hoʻohālikelike ma lalo.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Hoʻi iā `Err` inā ʻaʻole UTF-8 kahi ʻāpana me kahi wehewehe no ke aha ʻaʻole UTF-8 ka ʻāpana i hāʻawi ʻia.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::str;
///
/// // kekahi mau byte, i kahi vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mākou i kēia mau nāʻai mea i pololei ia, no laila, pono e hoʻohana `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Pololei ole nāʻai:
///
/// ```
/// use std::str;
///
/// // kekahi mau byte kūpono ʻole, ma kahi vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// E ʻike i nā docs no [`Utf8Error`] no nā kikoʻī hou aʻe e pili ana i nā ʻano hewa i hiki ke hoʻihoʻi ʻia.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // kekahi mau byte, i kahi hoʻonohonoho hoʻonohonoho
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Mākou i kēia mau nāʻai mea i pololei ia, no laila, pono e hoʻohana `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Ua holo wale ka hōʻoia.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Hoʻololi i kahi ʻāpana o nā bytes i hiki ke hoʻololi ʻia i kahi ʻāpana i hiki ke hoʻololi ʻia.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" me he vector hiki ke hoʻololi ʻia
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // E like me kā mākou ʻike he pololei kēia mau byte, hiki iā mākou ke hoʻohana iā `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Pololei ole nāʻai:
///
/// ```
/// use std::str;
///
/// // ʻO kekahi mau byte kūpono ʻole i kahi vector hiki ke hoʻololi ʻia
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// E ʻike i nā docs no [`Utf8Error`] no nā kikoʻī hou aʻe e pili ana i nā ʻano hewa i hiki ke hoʻihoʻi ʻia.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Ua holo wale ka hōʻoia.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Hoʻololi i kahi ʻāpana o nā bytes i kahi ʻāpana string me ka nānā ʻole ʻana inā loaʻa ka UTF-8 i ke aho.
///
/// E ʻike i ka mana palekana, [`from_utf8`], no ka ʻike hou aku.
///
/// # Safety
///
/// Palekana ʻole kēia hana no ka mea ʻaʻole ia e kaha i nā byte i hāʻawi ʻia iā ia he UTF-8 kūpono.
/// Inā hōʻeha ʻia kēia kāohi, hopena ʻole nā hopena i hoʻoholo ʻole ʻia, ʻoiai ke koena o Rust e manaʻo nei he UTF-8 ka pololei o ".
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::str;
///
/// // kekahi mau byte, i kahi vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: pono i ka mea kelepona e hōʻoia i ka pololei o nā bytes `v` ma UTF-8.
    // Hilinaʻi nō hoʻi iā `&str` a me `&[u8]` e loaʻa ana ka hoʻonohonoho like.
    unsafe { mem::transmute(v) }
}

/// Hoʻohuli i kahi ʻāpana o nā bytes i kahi ʻāpana string me ka nānā ʻole ʻana inā loaʻa ka UTF-8 i ke aho;mana hoʻololi.
///
///
/// E ʻike i ka mana hoʻololi ʻole, [`from_utf8_unchecked()`] no ka ʻike hou aku.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: pono i ka mea kelepona e hōʻoia i ka bytes `v`
    // kūpono UTF-8, no laila palekana ka hoʻolei iā `*mut str`.
    // Pēlā pū kekahi, palekana ka mea kuhikuhi poʻomanaʻo no ka mea mai kahi kuhikuhi i hōʻoia ʻia e kūpono no nā kākau.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}