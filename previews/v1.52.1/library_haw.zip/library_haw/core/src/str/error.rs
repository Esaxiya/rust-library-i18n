//! Wehewehe i ka utf8 ʻano hewa.

use crate::fmt;

/// Nā Hewa i hiki ke hana ʻia ke hoʻāʻo ʻana e unuhi i ke kaʻina o [`u8`] ma ke ʻano he aho.
///
/// E like me, ʻo ka ʻohana `from_utf8` o nā hana a me nā ʻano hana no nā ʻelua [`String`] a me [`&str`] e hoʻohana i kēia hemahema, no ka laʻana.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Hiki ke hoʻohana i nā ʻano hana o kēia ʻano hewa e hana i nā hana e like me `String::from_utf8_lossy` me ka hoʻokaʻawale ʻole i ka hoʻomanaʻo puʻupuʻu:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Hoʻihoʻi i ka papa kuhikuhi ma ke aho i hāʻawi ʻia a hiki i ka hōʻoia UTF-8 i hōʻoia ʻia.
    ///
    /// ʻO ia ka papa kuhikuhi kiʻekiʻe e like me ka hoʻi ʻana o `from_utf8(&input[..index])` iā `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::str;
    ///
    /// // kekahi mau byte kūpono ʻole, ma kahi vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 hoʻihoʻi i kahi Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // hewa ʻole ka byte ʻelua ma aneʻi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Hāʻawi i ka ʻike hou aku e pili ana i ka holomua.
    ///
    /// * `None`: ua hōʻea ka hopena o ke komo i kahi manaʻo ʻole.
    ///   `self.valid_up_to()` ʻo 1 a 3 mau bytes mai ka hopena o ke hoʻokomo.
    ///   Inā decode a hoʻonui ʻia kahi kahawai byte (e like me ka faile a i ʻole ke kumu pūnaewele), hiki paha i `char` kūpono nona ke kaʻina XteX byte e hoʻonui nei i nā ʻāpana he nui.
    ///
    ///
    /// * `Some(len)`: ua hālāwai kekahi byte i manaʻo ʻole ʻia.
    ///   ʻO ka lōʻihi i hāʻawi ʻia ʻo ia o ke kaʻina byte kūpono ʻole e hoʻomaka i ka papa kuhikuhi i hāʻawi ʻia e `valid_up_to()`.
    ///   Pono e hoʻomaka hou i ka decoding ma hope o kēlā kaʻina (ma hope o ka hoʻokomo ʻana i kahi [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) inā he decode lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Ua hoʻihoʻi ʻia kahi hemahema i ka wā e pio ai kahi `bool` me ka hoʻohana ʻole o [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}