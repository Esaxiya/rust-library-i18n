//! Hoʻolālā string.
//!
//! No nā kikoʻī hou aku, e ʻike i ka module [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ma waho o nā palena
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. hoʻomaka <=pau
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. palena ʻaʻano
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // e ʻike i ke ʻano
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` pono ma lalo o ka len a me ka palena char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Hoʻihoʻi i ka lōʻihi o `self`.
    ///
    /// Aia kēia lōʻihi i nā byte, ʻaʻole [`char`] a i ʻole nā graphemes.
    /// I nā huaʻōlelo ʻē, ʻaʻole paha ia ka mea a ke kanaka e noʻonoʻo ai i ka lōʻihi o ke aho.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // moemoeā f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Hoʻi iā `true` inā `self` kahi lōʻihi o zero bytes.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Nānā ʻia ʻo `index '-th byte ka byte mua ma ke kaʻina kiko helu UTF-8 a i ʻole ka hopena o ke aho.
    ///
    ///
    /// ʻO ka hoʻomaka a me ka hope o ke aho (ke manaʻo ʻia ʻo `index== self.len()`) he mau palena.
    ///
    /// Hoʻi iā `false` inā ʻo `index` ʻoi aku ma mua o `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // hoʻomaka o `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // lua byte o `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // kolu byte o `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 a len mau ka manawa ok.
        // E hoʻāʻo no ka 0 kikoʻī i hiki iā ia ke hoʻokau i ka nānā maʻalahi a lele i ka ʻikepili ʻana i ke aho no kēlā hihia.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ʻO kēia ka mea hoʻokalakupua e like me: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Hoʻohuli i kahi ʻāpana string i kahi byte slice.
    /// E hoʻolilo i ka ʻāpana byte i loko o kahi ʻāpana kaula, e hoʻohana i ka hana [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: kani Const no ka mea lawe mākou i ʻelua mau ʻano me ka hoʻonohonoho like
        unsafe { mem::transmute(self) }
    }

    /// Hoʻololi i kahi ʻāpana kaula i hiki ke hoʻololi ʻia i kahi ʻāpana byte i hoʻohuli ʻia.
    ///
    /// # Safety
    ///
    /// Pono e hōʻoia ka mea kelepona i ka ʻike o ka ʻāpana he UTF-8 ma mua o ka pau ʻana o ka hōʻaiʻē a hoʻohana ʻia ka `str` ma lalo.
    ///
    ///
    /// Hoʻohana o `str` nona nā ʻike kūpono ʻole UTF-8 i hana ʻole ʻia.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: palekana ka hoʻolei mai `&str` a i `&[u8]` mai ka `str`
        // Loaʻa iā ia ka hoʻonohonoho like me `&[u8]` (hiki i ka libstd wale nō ke hana i kēia hōʻoia).
        // Palekana ka mākaʻi kuhikuhi ma muli o ka hiki ʻana mai kahi kūmole hiki ke hoʻohuli ʻia i kūpono no nā kākau.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Hoʻololi i kahi ʻāpana kaula i kahi kuhikuhi kope.
    ///
    /// ʻOiai nā ʻāpana kaula he ʻāpana o nā bytes, kuhikuhi ka mākaʻi maka i [`u8`].
    /// E kuhikuhi ana kēia kuhikuhi i ka byte mua o ka ʻāpana o ke aho.
    ///
    /// Pono e hōʻoia ka mea e kelepona ana ʻaʻole kākau ʻia ka kuhikuhi kuhikuhi i hoʻihoʻi ʻia.
    /// Inā pono ʻoe e hoʻololi i nā ʻike o ka ʻāpana aho, e hoʻohana iā [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Hoʻololi i kahi ʻāpana kaula i hiki ke hoʻololi ʻia i kahi kuhikuhi maʻa.
    ///
    /// ʻOiai nā ʻāpana kaula he ʻāpana o nā bytes, kuhikuhi ka mākaʻi maka i [`u8`].
    /// E kuhikuhi ana kēia kuhikuhi i ka byte mua o ka ʻāpana o ke aho.
    ///
    /// ʻO kāu kuleana ia e hōʻoia i ka hoʻololi ʻana o kahi ʻāpana string i kahi ala e mau ai UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Hoʻihoʻi i kahi papa inoa o `str`.
    ///
    /// ʻO kēia kahi koho panic ʻole i ka helu ʻana i ka `str`.
    /// Hoʻihoʻi iā [`None`] i kēlā me kēia manawa ke ʻano o ka hana helu helu like panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ʻaʻohe hōʻike ma UTF-8 palena palena
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ma waho o nā palena
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Hoʻihoʻi i kahi leka uila hiki ke hoʻololi o `str`.
    ///
    /// ʻO kēia kahi koho panic ʻole i ka helu ʻana i ka `str`.
    /// Hoʻihoʻi iā [`None`] i kēlā me kēia manawa ke ʻano o ka hana helu helu like panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // pololei lōʻihi
    /// assert!(v.get_mut(0..5).is_some());
    /// // ma waho o nā palena
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Hoʻihoʻi i kahi leka uila i nānā ʻole ʻia o `str`.
    ///
    /// ʻO kēia kahi koho i nānā ʻole ʻia i ka helu ʻana i ka `str`.
    ///
    /// # Safety
    ///
    /// ʻO nā mea kelepona i kēia hana ke kuleana e māʻona kēia mau preconditions:
    ///
    /// * ʻAʻole pono ka papa kuhikuhi hoʻomaka ma mua o ka helu kuhikuhi;
    /// * Pono nā papa kuhikuhi ma loko o nā palena o ka ʻāpana kumu;
    /// * Pono nā papa kuhikuhi ma nā palena kau UTF-8.
    ///
    /// Ke hāʻule ʻole nei, hiki i ka ʻāpana kaula i hoʻihoʻi ʻia ke kuhikuhi i ka hoʻomanaʻo kūpono ʻole a haki paha i nā invariants i kamaʻilio ʻia e ka ʻano `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: pono ke kāhea ka mea e kāhea i ka ʻaelike palekana no `get_unchecked`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Hoʻihoʻi i kahi leka uila i hoʻololi ʻia, unchecked o `str`.
    ///
    /// ʻO kēia kahi koho i nānā ʻole ʻia i ka helu ʻana i ka `str`.
    ///
    /// # Safety
    ///
    /// ʻO nā mea kelepona i kēia hana ke kuleana e māʻona kēia mau preconditions:
    ///
    /// * ʻAʻole pono ka papa kuhikuhi hoʻomaka ma mua o ka helu kuhikuhi;
    /// * Pono nā papa kuhikuhi ma loko o nā palena o ka ʻāpana kumu;
    /// * Pono nā papa kuhikuhi ma nā palena kau UTF-8.
    ///
    /// Ke hāʻule ʻole nei, hiki i ka ʻāpana kaula i hoʻihoʻi ʻia ke kuhikuhi i ka hoʻomanaʻo kūpono ʻole a haki paha i nā invariants i kamaʻilio ʻia e ka ʻano `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: pono ke kāhea ka mea e kāhea i ka ʻaelike palekana no `get_unchecked_mut`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Hoʻokumu i kahi ʻāpana kaula mai kahi ʻāpana kaula ʻē aʻe, e kāpae nei i nā hōʻoia palekana.
    ///
    /// ʻAʻole kēia e paipai ʻia, hoʻohana me ka akahele.No kahi koho palekana e ʻike iā [`str`] a me [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Hele kēia ʻāpana hou mai `begin` a i `end`, me `begin` akā ke kāpae nei iā `end`.
    ///
    /// E kiʻi i kahi ʻāpana kaula hiki ke hoʻololi ʻia, e ʻike i ke ʻano [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// He kuleana nā mea e kelepona ana i kēia hana i ʻoluʻolu nā preconditions ʻekolu:
    ///
    /// * `begin` pono ʻole ma mua o `end`.
    /// * `begin` a ʻo `end` pono nā kūlana byte i loko o ka ʻāpana o ke aho.
    /// * `begin` a `end` pono e moe ma nā palena kaʻina UTF-8.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: pono ke kāhea ka mea e kāhea i ka ʻaelike palekana no `get_unchecked`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Hoʻokumu i kahi ʻāpana kaula mai kahi ʻāpana kaula ʻē aʻe, e kāpae nei i nā hōʻoia palekana.
    /// Kēia mea nui,ʻaʻole pono, hoʻohana me ka mālama nui!No kahi koho palekana e ʻike iā [`str`] a me [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Hele kēia ʻāpana hou mai `begin` a i `end`, me `begin` akā ke kāpae nei iā `end`.
    ///
    /// E kiʻi i kahi ʻāpana kaula hiki ʻole ke hoʻololi ʻia, e ʻike i ke ʻano [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// He kuleana nā mea e kelepona ana i kēia hana i ʻoluʻolu nā preconditions ʻekolu:
    ///
    /// * `begin` pono ʻole ma mua o `end`.
    /// * `begin` a ʻo `end` pono nā kūlana byte i loko o ka ʻāpana o ke aho.
    /// * `begin` a `end` pono e moe ma nā palena kaʻina UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: pono ke kāhea ka mea e kāhea i ka ʻaelike palekana no `get_unchecked_mut`;
        // hiki ke hoʻopau ʻia ka ʻāpana no ka mea he palekana ʻo `self`.
        // Palekana ka pointer i hoʻihoʻi ʻia no ka mea impls o `SliceIndex` pono e hōʻoia ʻo ia ia.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// E mahele i hoʻokahi ʻāpana kaula i ʻelua ma ka papa kuhikuhi.
    ///
    /// ʻO ka hoʻopaʻapaʻa, `mid`, he byte offset mai ka hoʻomaka o ke aho.
    /// Pono ia ma ka palena o kahi kuhi kiko UTF-8.
    ///
    /// Ua hoʻi mai nā ʻāpana ʻelua mai ka hoʻomaka o ka ʻāpana o ke aho a hiki i ka `mid`, a mai ka `mid` a i ka hopena o ka ʻāpana o ke aho.
    ///
    /// E kiʻi i nā ʻāpana kaula hiki ke hoʻololi ʻia, e ʻike i ke ʻano [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics inā ʻaʻohe `mid` ma ka palena kuhi helu UTF-8, a i ʻole ua hala ia i ka hopena o ka helu code hope o ka ʻāpana string.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary hōʻoia i ka helu kuhikuhi ma [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: nānā wale ʻia ʻo `mid` ma ka palena char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// E mahele i hoʻokahi ʻāpana kaula i hiki ke hoʻololi ʻia i ʻelua ma ka papa kuhikuhi.
    ///
    /// ʻO ka hoʻopaʻapaʻa, `mid`, he byte offset mai ka hoʻomaka o ke aho.
    /// Pono ia ma ka palena o kahi kuhi kiko UTF-8.
    ///
    /// Ua hoʻi mai nā ʻāpana ʻelua mai ka hoʻomaka o ka ʻāpana o ke aho a hiki i ka `mid`, a mai ka `mid` a i ka hopena o ka ʻāpana o ke aho.
    ///
    /// E kiʻi i nā ʻāpana kaula hiki ʻole ke hoʻololi ʻia, e ʻike i ke ʻano [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics inā ʻaʻohe `mid` ma ka palena kuhi helu UTF-8, a i ʻole ua hala ia i ka hopena o ka helu code hope o ka ʻāpana string.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary hōʻoia i ka helu kuhikuhi ma [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: nānā wale ʻia ʻo `mid` ma ka palena char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// E hoʻihoʻi i kahi iterator ma luna o nā [`char`] o kahi ʻāpana string.
    ///
    /// Ma ke ʻano he ʻāpana kaula o UTF-8 kūpono, hiki iā mākou ke hana ma o ka ʻāpana kaula e [`char`].
    /// Hoʻihoʻi kēia hana i kahi iterator.
    ///
    /// He mea nui e hoʻomanaʻo ʻo [`char`] kahi unicode Scalar Value, a ʻaʻole paha i kūlike i kou manaʻo o ka 'character'.
    ///
    /// ʻO ka Iteration ma luna o nā puʻupuʻu grapheme ka mea āu e makemake ai.
    /// ʻAʻole hāʻawi ʻia kēia hana e ka waihona waihona maʻamau o Rust, e nānā iā crates.io ma kahi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// E hoʻomanaʻo, ʻaʻole e like ʻo [char`] i kāu intuition e pili ana i nā huapalapala:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // aole 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// E hoʻihoʻi i kahi iterator ma luna o nā [`char`] o kahi ʻāpana kaula, a me ko lākou mau kūlana.
    ///
    /// Ma ke ʻano he ʻāpana kaula o UTF-8 kūpono, hiki iā mākou ke hana ma o ka ʻāpana kaula e [`char`].
    /// Hoʻihoʻi kēia hana i kahi iterator o kēia mau [char] ʻelua, a me ko lākou mau kūlana byte.
    ///
    /// Hāʻawi ka iterator i nā kūpuna.ʻO ke kūlana ka mua, ʻo ka [`char`] ka lua.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// E hoʻomanaʻo, ʻaʻole e like ʻo [char`] i kāu intuition e pili ana i nā huapalapala:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ʻaʻole (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // e hoʻomaopopo i ka 3 ma aneʻi, ʻo ka mea hope loa i lawe i ʻelua mau bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// He iterator ma luna o nā bytes o kahi ʻāpana kaula.
    ///
    /// Ma ke ʻano he ʻāpana byte kahi ʻāpana o nā aho, hiki iā mākou ke hana ma o ka ʻāpana kaula e ka byte.
    /// Hoʻihoʻi kēia hana i kahi iterator.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Māhele i kahi ʻāpana kaula e keʻokeʻo keʻokeʻo.
    ///
    /// Ke iterator hoʻi, e hoʻi kui slices i mea iiaciiie-slices o ka palapala kui māhele, hoʻokaʻawaleʻia ma kekahi dala o ke whitespace.
    ///
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    /// Inā makemake ʻoe e hoʻokaʻawale ma kahi keʻokeʻo ASCII ma kahi o, e hoʻohana iā [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Manaʻo ʻia nā ʻano keʻokeʻo āpau:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Māhele i kahi ʻāpana kaula e ka keʻokeʻo ASCII.
    ///
    /// Ua hoʻihoʻi ka iterator i nā ʻāpana kaula i ʻāpana o nā ʻāpana kaula kumu, hoʻokaʻawale ʻia e kekahi nui o ke keʻokeʻo ASCII.
    ///
    ///
    /// E hoʻokaʻawale iā Unicode `Whitespace` ma kahi, e hoʻohana iā [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Nānā ʻia nā ʻano keʻokeʻo ASCII āpau:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// He iterator ma luna o nā laina o ke aho, e like me nā ʻāpana kaula.
    ///
    /// Pau nā laina me kahi (`\n`) laina hou a i ʻole kahi hoʻi kaʻa me kahi hānai laina (`\r\n`).
    ///
    /// ʻO ka laina hope loa he koho.
    /// E hoʻihoʻi kahi kaula i ka hopena o ka laina hope i nā laina like me ke ʻano kaulike ʻole me ka ʻole o ka pau ʻana o ka laina hope.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ka hope loa laina pau ana ka i koi 'ia:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// He iterator ma luna o nā laina o ke aho.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Hoʻihoʻi i kahi iterator o `u16` ma luna o ke aho i hoʻopili ʻia e like me UTF-16.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Hoʻi iā `true` inā kūlike ke ʻano i hāʻawi ʻia i kahi ʻāpana sub-slice o kēia ʻāpana aho.
    ///
    /// Hoʻi iā `false` inā ʻaʻole.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// E hoʻihoʻi iā `true` inā kūlike ke ʻano i hāʻawi ʻia i mua o ka mua o kēia ʻāpana aho.
    ///
    /// Hoʻi iā `false` inā ʻaʻole.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Hoʻi iā `true` inā kūlike ke ʻano i hāʻawi ʻia i kahi hope o kēia ʻāpana aho.
    ///
    /// Hoʻi iā `false` inā ʻaʻole.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Hoʻihoʻi i ka papa kuhikuhi byte o ke ʻano mua o kēia ʻāpana kaula e kūlike i ke kumu.
    ///
    /// Hoʻi iā [`None`] inā kūlike ʻole ke kumu.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Nā lauana laulaha hou aʻe e hoʻohana ana i ka kaila kiko ʻole a me nā pani:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ʻAʻole loaʻa ke kumu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Hoʻihoʻi i ka papa kuhikuhi byte no ke ʻano mua o ka match pono loa o ke kumu ma kēia ʻāpana kaula.
    ///
    /// Hoʻi iā [`None`] inā kūlike ʻole ke kumu.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Nā lauana laulā hou aʻe me nā pani:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ʻAʻole loaʻa ke kumu:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// He iterator ma luna o nā substrings o kēia ʻāpana ʻāpana, hoʻokaʻawale ʻia e nā huapalapala i kūlike ʻia e kahi kumu.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// E lilo ka iterator i hoʻihoʻi ʻia i [`DoubleEndedIterator`] inā ʻae ʻia ke kumu i kahi huli huli a hāʻawi ka forward/reverse i nā like like.
    /// He ʻoiaʻiʻo kēia no, eg, [`char`], akā ʻaʻole no `&str`.
    ///
    /// Inā ʻae ʻia ke kumuhana i kahi hulina huli akā ʻokoʻa paha nā hopena mai kahi hulina i mua, hiki ke hoʻohana ʻia ke ʻano [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Inā ʻo ke kumu he ʻāpana o chars, e hoʻokaʻawale ma kēlā me kēia hanana o kekahi o nā huapalapala.
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Inā loaʻa i kahi kaula he mau mea hoʻokaʻawale contiguous, e hoʻopau ʻoe me nā kaula kau ʻole i ka hoʻopuka.
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Hoʻokaʻawale ʻia nā mea hoʻokaʻawale pili loa i ka aho hakahaka.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Hoʻohui ʻia nā mea hoʻokaʻawale i ka hoʻomaka a i ʻole ka hopena o kahi kaula e nā kaula kau ʻole.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Ke hoʻohana ʻia ke kaula hakahaka ma ke ʻano he mea hoʻokaʻawale, hoʻokaʻawale ia i kēlā me kēia ʻano i ke aho, me ka hoʻomaka a me ka hope o ke aho.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Hiki i nā mea hoʻokaʻawale pili ke alakaʻi i kahi hana kahaha paha ke hoʻohana ʻia ke keʻokeʻo i mea hoʻokaʻawale.Pololei kēia code:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Hāʻawi ʻo _not_ iā ʻoe:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// E hoʻohana iā [`split_whitespace`] no kēia hana.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// He iterator ma luna o nā substrings o kēia ʻāpana ʻāpana, hoʻokaʻawale ʻia e nā huapalapala i kūlike ʻia e kahi kumu.
    /// ʻOkoʻa ka iterator i hana ʻia e `split` i ka haʻalele ʻana o `split_inclusive` i ka ʻāpana like me ka terminator o ka substring.
    ///
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Inā kūlike ka mea hope loa o ke aho, e manaʻo ʻia kēlā mea i ka terminator o ka substring o mua.
    /// ʻO kēlā substring ka mea hope loa i hoʻihoʻi ʻia e ka iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// He iterator ma luna o nā substrings o ka ʻāpana kaula i hāʻawi ʻia, hoʻokaʻawale ʻia e nā huapalapala i kūlike ʻia e kahi kumu a hāʻawi ʻia i ke kaʻina huli.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// Pono ka iterator i hoʻihoʻi ʻia e kākoʻo i ke kumu hoʻohālikelike i kahi huli huli, a he [`DoubleEndedIterator`] ia inā loaʻa kahi hulina forward/reverse i nā mea like.
    ///
    ///
    /// No ka iterating mai mua, hiki ke hoʻohana i ka [`split`] hana.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ʻO kahi iterator ma luna o nā substrings o ka ʻāpana kaula i hāʻawi ʻia, hoʻokaʻawale ʻia e nā huapalapala i kūlike ʻia e kahi kumu.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Kūlike ʻia me [`split`], koe wale nō ke haʻalele ʻia ke substring trailing inā nele.
    ///
    /// [`split`]: str::split
    ///
    /// Hiki ke hoʻohana i kēia hana no ka ʻikepili string ʻo _terminated_, ma mua o _separated_ e kahi hiʻohiʻona.
    ///
    /// # Hana Iterator
    ///
    /// E lilo ka iterator i hoʻihoʻi ʻia i [`DoubleEndedIterator`] inā ʻae ʻia ke kumu i kahi huli huli a hāʻawi ka forward/reverse i nā like like.
    /// He ʻoiaʻiʻo kēia no, eg, [`char`], akā ʻaʻole no `&str`.
    ///
    /// Inā ʻae ʻia ke kumuhana i kahi hulina huli akā ʻokoʻa paha nā hopena mai kahi hulina i mua, hiki ke hoʻohana ʻia ka hana [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// ʻO kahi iterator ma luna o nā substrings o `self`, hoʻokaʻawale ʻia e nā huapalapala i kūlike ʻia e kahi kumu a hāʻawi ʻia i ke kaʻina huli.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Kūlike ʻia me [`split`], koe wale nō ke haʻalele ʻia ke substring trailing inā nele.
    ///
    /// [`split`]: str::split
    ///
    /// Hiki ke hoʻohana i kēia hana no ka ʻikepili string ʻo _terminated_, ma mua o _separated_ e kahi hiʻohiʻona.
    ///
    /// # Hana Iterator
    ///
    /// Pono ka iterator i hoʻihoʻi ʻia e kākoʻo i ke kumu hoʻohālikelike i kahi huli huli, a e pāpālua ʻia ia inā loaʻa i kahi hulina forward/reverse nā mea like.
    ///
    ///
    /// No ka iterating mai mua, hiki ke hoʻohana i ka [`split_terminator`] hana.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// He iterator ma luna o nā substrings o ka ʻāpana kaula i hāʻawi ʻia, hoʻokaʻawale ʻia e kahi kumu, i kapu ʻia i ka hoʻi ʻana ma nā mea `n` nui loa.
    ///
    /// Inā hoʻihoʻi ʻia nā XstrX substrings, aia i ka substring hope loa (ka substring `n`th) ke koena o ke aho.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// ʻAʻole e hoʻopau pālua ka iterator i hoʻihoʻi ʻia, no ka mea ʻaʻole maikaʻi e kākoʻo.
    ///
    /// Inā ʻae ʻia ke kumuhana i kahi huli huli, hiki ke hoʻohana i ke ʻano [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An iterator no substrings o keia kui māhele, hookaawale ae ma ke kumu, e hoʻomaka ana, mai ka pau ana o ke kaula, kapu ia hoi ma ka hapanui `n` mau.
    ///
    ///
    /// Inā hoʻihoʻi ʻia nā XstrX substrings, aia i ka substring hope loa (ka substring `n`th) ke koena o ke aho.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// ʻAʻole e hoʻopau pālua ka iterator i hoʻihoʻi ʻia, no ka mea ʻaʻole maikaʻi e kākoʻo.
    ///
    /// No ka hoʻokaʻawale ʻana mai mua, hiki ke hoʻohana i ke ʻano [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Māhele i ke aho ma ka hanana mua o ka palena palena palena a hoʻihoʻi i mua i mua o ka palena a me ka hope ma hope o ka palena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Māhele i ke aho i ka hopena hope loa o ka palena palena i kuhikuhi ʻia a hoʻi i mua i ka mua o ka palena a me ka hope ma hope o ka palena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// He iterator ma luna o nā hui hoʻokaʻawale o kahi kumu i loko o ka ʻāpana kaula i hāʻawi ʻia.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// E lilo ka iterator i hoʻihoʻi ʻia i [`DoubleEndedIterator`] inā ʻae ʻia ke kumu i kahi huli huli a hāʻawi ka forward/reverse i nā like like.
    /// He ʻoiaʻiʻo kēia no, eg, [`char`], akā ʻaʻole no `&str`.
    ///
    /// Inā ʻae ʻia ke kumuhana i kahi hulina huli akā ʻokoʻa paha nā hopena mai kahi hulina i mua, hiki ke hoʻohana ʻia ke ʻano [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// He iterator ma luna o nā hoʻokūkū hoʻokaʻawale o kahi kumu i loko o kēia ʻāpana kaula, i hāʻawi ʻia i ke kaʻina huli.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// Pono ka iterator i hoʻihoʻi ʻia e kākoʻo i ke kumu hoʻohālikelike i kahi huli huli, a he [`DoubleEndedIterator`] ia inā loaʻa kahi hulina forward/reverse i nā mea like.
    ///
    ///
    /// No ka iterating mai mua, hiki ke hoʻohana i ka [`matches`] hana.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// He iterator ma luna o nā hoʻokūkū hoʻokaʻawale o kahi kumu i loko o kēia ʻāpana kaula a me ka papa kuhikuhi e hoʻomaka ai ke pāʻani.
    ///
    /// No nā pāʻani o `pat` ma waena o `self` e hāhā ana, e hoʻihoʻi wale ʻia nā ʻikepili e pili ana i ka pāʻani mua.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// E lilo ka iterator i hoʻihoʻi ʻia i [`DoubleEndedIterator`] inā ʻae ʻia ke kumu i kahi huli huli a hāʻawi ka forward/reverse i nā like like.
    /// He ʻoiaʻiʻo kēia no, eg, [`char`], akā ʻaʻole no `&str`.
    ///
    /// Inā ke kumu e leie aku ka aʻe huli akā kona hualoaʻa paha oko mai kekahi aku huli, ka [`rmatch_indices`] ano hiki ke hoʻohana.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ʻo ka `aba` mua wale nō
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// He iterator ma luna o nā kuʻikahi disjoint o kahi kumu ma waena o `self`, i hāʻawi ʻia i ka ʻaoʻao huli a me ka papa kuhikuhi o ke kime.
    ///
    /// No nā pāʻani o `pat` ma waena o `self` e hāhā ana, e hoʻihoʻi wale ʻia nā ʻikepili i kūlike i ka pāʻani hope loa.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hana Iterator
    ///
    /// Pono ka iterator i hoʻihoʻi ʻia e kākoʻo i ke kumu hoʻohālikelike i kahi huli huli, a he [`DoubleEndedIterator`] ia inā loaʻa kahi hulina forward/reverse i nā mea like.
    ///
    ///
    /// No ka iterating mai mua, hiki ke hoʻohana i ka [`match_indices`] hana.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ʻo ka `aba` hope loa
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Hoʻihoʻi i kahi ʻāpana string me ke alakaʻi ʻana a me ke keʻokeʻo keʻokeʻo i wehe ʻia.
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me kahi keʻokeʻo alakaʻi i wehe ʻia.
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// `start` ma kēia pōʻaiapili o ia hoʻi, ka oihana mua o ka meaʻai kui;no kahi ʻōlelo hema a ʻākau e like me ʻEnelani a i ʻole Lūkia, e waiho ʻia kēia ma ka ʻaoʻao hema, a no nā ʻōlelo ʻākau a hema hema e like me ʻAlapia a me Hebera, ʻo kēia ka ʻaoʻao ʻākau.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me ke keʻokeʻo keʻokeʻo e hemo ana.
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// `end` i kēia pōʻaiapili ke ʻano o ke kūlana hope loa o kēlā aho byte;no ka i koe-i-pono 'ōlelo e like English a Russian, keia e e ponoʻaoʻao, a no ka pono-i-haʻalele' ōlelo e like Apapika a Hebera, i kēia e ia ma kaʻaoʻao hema.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me kahi keʻokeʻo alakaʻi i wehe ʻia.
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// 'Left' i kēia pōʻaiapili ke ʻano o ke kūlana mua o kēlā aho byte;no ka 'ōlelo e like Apapika a he Hebera ka olelo i mea' pono i ka haʻalele 'ana aku mamua o' haʻalele i ka pono ', keia, e ia i kaʻaoʻao _right_,ʻaʻole ma ka hema.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me ke keʻokeʻo keʻokeʻo e hemo ana.
    ///
    /// 'Whitespace' Wehewehe ʻia e like me nā ʻōlelo o ka Unicode Derished Core Property `White_Space`.
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// 'Right' i kēia pōʻaiapili ke ʻano o ke kūlana hope loa o kēlā aho byte;no ka 'ōlelo e like Apapika a he Hebera ka olelo i mea' pono i ka haʻalele 'ana aku mamua o' haʻalele i ka pono ', keia, e ia i kaʻaoʻao _left_,ʻaʻole i ka pono.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me nā paina kuhina a me nā ʻūkuʻi e kūlike i ke kumu i wehe pinepine ʻia.
    ///
    /// Ke [pattern] hiki e he [`char`], he māhele o ka ['char`] s, a me ka papa a me ka panina e hoʻoholo inā he ano ihoiho.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // E hoʻomanaʻo i ka pili mua i ʻike ʻia, e hoʻoponopono ma lalo inā
            // ʻokoʻa ka hoʻokūkū hope loa
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: ʻIke ʻia ʻo `Searcher` e hoʻihoʻi i nā ʻike kūpono.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me nā paina kuhina āpau e kūlike i kahi lau i wehe pinepine ʻia.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// `start` ma kēia pōʻaiapili o ia hoʻi, ka oihana mua o ka meaʻai kui;no kahi ʻōlelo hema a ʻākau e like me ʻEnelani a i ʻole Lūkia, e waiho ʻia kēia ma ka ʻaoʻao hema, a no nā ʻōlelo ʻākau a hema hema e like me ʻAlapia a me Hebera, ʻo kēia ka ʻaoʻao ʻākau.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: ʻIke ʻia ʻo `Searcher` e hoʻihoʻi i nā ʻike kūpono.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me ka unuhi mua.
    ///
    /// Inā hoʻomaka ke aho me ke kumu `prefix`, hoʻihoʻi i ka substring ma hope o ka pākuʻi mua, a ʻū ʻia i `Some`.
    /// ʻAʻole like me `trim_start_matches`, hoʻopau kēia hana i ka pīpī i hoʻokahi manawa.
    ///
    /// Inā ʻaʻole e hoʻomaka ke aho me `prefix`, hoʻihoʻi iā `None`.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me ka hope i lawe ʻia.
    ///
    /// Inā pau ke aho me ke kumu `suffix`, hoʻihoʻi i ka substring ma mua o ka hope, i wahī ʻia i `Some`.
    /// ʻAʻole like me `trim_end_matches`, hemo kēia hana i ka hope.
    ///
    /// Inā ʻaʻole e pau ke aho me `suffix`, hoʻihoʻi iā `None`.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Hoʻihoʻi mai i kahi ʻāpana kaula me nā ʻope āpau e kūlike i kahi lau i wehe pinepine ʻia.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// `end` i kēia pōʻaiapili ke ʻano o ke kūlana hope loa o kēlā aho byte;no ka i koe-i-pono 'ōlelo e like English a Russian, keia e e ponoʻaoʻao, a no ka pono-i-haʻalele' ōlelo e like Apapika a Hebera, i kēia e ia ma kaʻaoʻao hema.
    ///
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: ʻIke ʻia ʻo `Searcher` e hoʻihoʻi i nā ʻike kūpono.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Hoʻihoʻi i kahi ʻāpana kaula me nā paina kuhina āpau e kūlike i kahi lau i wehe pinepine ʻia.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// 'Left' i kēia pōʻaiapili ke ʻano o ke kūlana mua o kēlā aho byte;no ka 'ōlelo e like Apapika a he Hebera ka olelo i mea' pono i ka haʻalele 'ana aku mamua o' haʻalele i ka pono ', keia, e ia i kaʻaoʻao _right_,ʻaʻole ma ka hema.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Hoʻihoʻi mai i kahi ʻāpana kaula me nā ʻope āpau e kūlike i kahi lau i wehe pinepine ʻia.
    ///
    /// Hiki i ka [pattern] ke lilo i `&str`, [`char`], kahi ʻāpana o [`char`] s, a i ʻole kahi hana a pani paha e hoʻoholo inā kūlike kahi ʻano.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Papa kuhikuhi kuhikuhi huaʻōlelo
    ///
    /// ʻO ke aho ke kaʻina o nā byte.
    /// 'Right' i kēia pōʻaiapili ke ʻano o ke kūlana hope loa o kēlā aho byte;no ka 'ōlelo e like Apapika a he Hebera ka olelo i mea' pono i ka haʻalele 'ana aku mamua o' haʻalele i ka pono ', keia, e ia i kaʻaoʻao _left_,ʻaʻole i ka pono.
    ///
    ///
    /// # Examples
    ///
    /// Nā lauana maʻalahi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// ʻO kahi hiʻohiʻona paʻakikī, e hoʻohana nei i ka pani:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Hoʻohui i kēia kaula i kahi ʻano ʻē aʻe.
    ///
    /// Ma muli o ka nui o `parse`, hiki iā ia ke hoʻopilikia i nā pilikia me ka ʻano o ka manaʻo.
    /// E like me, `parse` kekahi o nā manawa liʻiliʻi āu e ʻike ai i ka syntax aloha e ʻike ʻia ʻo 'turbofish': `::<>`.
    ///
    /// Kōkua kēia i ka inferensi algorithm e hoʻomaopopo kikoʻī i ke ʻano āu e hoʻāʻo nei e ʻoki.
    ///
    /// `parse` hiki ke hoʻokaʻawale i kekahi ʻano e hoʻokomo i ka [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// E hoʻi [`Err`] ina ia ke ole e hiki i ka wae i kēia kaula māhele i loko o ka makemakeʻano.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Ke hoʻohana nei i ka 'turbofish' ma kahi o ka anotating `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// E hāʻule ʻole ana:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Nānā inā aia nā huapalapala āpau i kēia aho i loko o ka pae ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Hiki iā mākou ke mālama i kēlā me kēia byte ma ke ʻano he ʻano ma aneʻi: hoʻomaka nā huapalapala multibyte āpau me kahi byte ʻaʻole ma ka pae ʻo Alexa, no laila e kū ma laila i laila.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Nānā i nā kaula ʻelua he hoʻokūkū hihia hihia ʻole ʻo ASCII.
    ///
    /// E like me `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, akā me ka hoʻokaʻawale ʻole a me ke kope ʻana i nā manawa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Hoʻololi i kēia aho i kāna ASCII hihia kiʻekiʻe i kūlike i ka wahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'a' a i 'z' i 'A' a i 'Z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou aʻe me ka ʻole o ka hoʻololi ʻana i kahi e kū nei, e hoʻohana iā [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAFETY: palekana no ka mea lawe mākou i ʻelua mau ʻano me ka hoʻonohonoho like.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Hoʻololi i kēia aho i kāna ASCII hihia haʻahaʻa e kū like ana ma kahi.
    ///
    /// Kuhi ʻia nā leka ASCII 'A' a i 'Z' i 'a' a i 'z', akā hoʻololi ʻole nā leka ASCII ʻole.
    ///
    /// E hoʻihoʻi i kahi waiwai hou i hoʻemi ʻia me ka hoʻololi ʻole i kahi e kū nei, e hoʻohana iā [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAFETY: palekana no ka mea lawe mākou i ʻelua mau ʻano me ka hoʻonohonoho like.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// E hoʻihoʻi i kahi iterator i pakele i kēlā me kēia char i `self` me [`char::escape_debug`].
    ///
    ///
    /// Note: hoʻopakele wale nā grapheme codepoints e hoʻomaka i ke aho e pakele ai.
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// E hoʻihoʻi i kahi iterator i pakele i kēlā me kēia char i `self` me [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// E hoʻihoʻi i kahi iterator i pakele i kēlā me kēia char i `self` me [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ma ke ʻano he iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// E ho ohana i `println!` 'ana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Nā mea like i:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Ke hoʻohana nei iā `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Hana i kahi str hakahaka
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Hoʻokumu i kahi str mutable hakahaka
    #[inline]
    fn default() -> Self {
        // SAFETY: pololei ke aho hakahaka UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// He ʻano inoa cloneable fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: palekana ʻole
        unsafe { from_utf8_unchecked(bytes) }
    };
}