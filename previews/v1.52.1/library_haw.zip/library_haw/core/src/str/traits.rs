//! Trait implementations no `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Hoʻokomo i ke kauoha o nā aho.
///
/// Oi i kauoha [lexicographically](Ord#lexicographical-comparison) ma kā lākouʻai nā loina.
/// Keia kauoha Unicode karaima mea nui ka nānā 'ana ma luna o ko lakou wahi i loko o ke kuhi nńnń.
/// 'O kēia ka ia me "alphabetical" mea, i loli aʻe ma ka' ōlelo a me ka'ōlelo a aupuni i pono.
/// Ka hoʻomaopopoʻana kaula e like me ka nohona-maliu mau hae pono a aupuni-i ho'ākāka 'ikepili i mea ma waho o ka laulā o ka `str` ʻano.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Hoʻohana i nā hana hoʻohālikelike i nā aho.
///
/// Oi i hoʻohālike [lexicographically](Ord#lexicographical-comparison) ma kā lākouʻai nā loina.
/// Hoʻohālikelike kēia i nā helu code Unicode e pili ana i ko lākou mau kūlana i nā pakuhi code.
/// 'O kēia ka ia me "alphabetical" mea, i loli aʻe ma ka' ōlelo a me ka'ōlelo a aupuni i pono.
/// Ke kapakai a kaula e like me ka nohona-maliu mau hae pono a aupuni-i ho'ākāka 'ikepili i mea ma waho o ka laulā o ka `str` ʻano.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Hoʻokomo i ka ʻoki ʻana i ka substring me ka syntax `&self[..]` a i ʻole `&mut self[..]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho holoʻokoʻa, ʻo ia hoʻi, hoʻihoʻi iā `&self` a i ʻole `&mut self`.Kūlike ʻia i `&iho [0 ..
/// len] `a i ʻole ʻ&mut ponoʻī [0 ..
/// len]`.
/// ʻAʻole like me nā papa kuhikuhi helu ʻē aʻe, ʻaʻole hiki i kēia iā panic.
///
/// Kēia hana i *O*(1).
///
/// Ma mua o 1.20.0, ua kākoʻo ʻia kēia mau papa kuhikuhi helu e ka hoʻokō pololei ʻana o `Index` a me `IndexMut`.
///
/// Kūlike ʻia i `&self[0 .. len]` a i `&mut self[0 .. len]` paha.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Mea lapaʻau substring slicing me Ka Mooolelo O `&self[begin .. end]` a `&mut self[begin .. end]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho i hāʻawi ʻia mai ka pae byte [`hoʻomaka`, `end`).
///
/// Kēia hana i *O*(1).
///
/// Ma mua o 1.20.0, ua kākoʻo ʻia kēia mau papa kuhikuhi helu e ka hoʻokō pololei ʻana o `Index` a me `IndexMut`.
///
/// # Panics
///
/// Panics inā ʻaʻole kuhikuhi ʻo `begin` a i ʻole `end` i ka offset hoʻomaka o kahi ʻano (e like me ka wehewehe ʻana e `is_char_boundary`), inā `begin > end`, a i ʻole inā `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // kēia e panic:
/// // byte 2 moe i loko o `ö`:
/// // &Mau [2 ..3];
///
/// // ʻai 8 wahaheʻe i loko o `老`&mau [1 ..
/// // 8];
///
/// // byte 100 aia ma waho o ke aho&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: nānā wale ʻia ʻo `start` a me `end` ma ka palena char,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            // Mākou kekahi kulana kupono Mike Char palena, no laila, i kēia mea i pololei ia UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: nānā wale ʻia ʻo `start` a me `end` ma ka palena char.
            // ʻIke mākou he kū hoʻokahi ka pointer no ka mea loaʻa iā mākou mai `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: hōʻoia ka mea kāhea i ka `self` i nā palena o `slice`
        // ka mea e māʻona ai nā kūlana āpau no `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: e nānā i nā manaʻo no `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary loaʻa, e kaha i ka 'inideka mea i loko o [0, .len()] hiki ole hoʻohana hou `get` i luna, no ka mea, o NLL pilikia
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: nānā wale ʻia ʻo `start` a me `end` ma ka palena char,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Mea lapaʻau substring slicing me Ka Mooolelo O `&self[.. end]` a `&mut self[.. end]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho i hāʻawi ʻia mai ka pae byte [`0`, `end`).
/// Kūlike ʻia i `&self[0 .. end]` a i `&mut self[0 .. end]` paha.
///
/// Kēia hana i *O*(1).
///
/// Ma mua o 1.20.0, ua kākoʻo ʻia kēia mau papa kuhikuhi helu e ka hoʻokō pololei ʻana o `Index` a me `IndexMut`.
///
/// # Panics
///
/// Panics inā ʻaʻole kuhikuhi ʻo `end` i ka offset hoʻomaka o kahi ʻano (e like me ka wehewehe ʻana e `is_char_boundary`), a i ʻole inā `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // Maluhia: e kulana kupono ia `end` mea ma luna o ka Mike Char palena,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // Maluhia: e kulana kupono ia `end` mea ma luna o ka Mike Char palena,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // Maluhia: e kulana kupono ia `end` mea ma luna o ka Mike Char palena,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Hoʻokomo i ka ʻoki ʻana i ka substring me ka syntax `&self[begin ..]` a i ʻole `&mut self[begin ..]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho i hāʻawi ʻia mai ka pae byte [`hoʻomaka`, `len`).Kūlike ʻia i `&iho [hoʻomaka ..
/// len] `a i ʻole ʻ&mut iho [hoʻomaka ..
/// len]`.
///
/// Kēia hana i *O*(1).
///
/// Ma mua o 1.20.0, ua kākoʻo ʻia kēia mau papa kuhikuhi helu e ka hoʻokō pololei ʻana o `Index` a me `IndexMut`.
///
/// # Panics
///
/// Panics ina `begin` aole ia e kuhikuhi i ka hoʻomakaʻai offset o ke ano (e like me ka ho'ākāka 'ia ma ka `is_char_boundary`), a ina `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: nānā wale ʻia ʻo `start` ma ka palena char,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: nānā wale ʻia ʻo `start` ma ka palena char,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: hōʻoia ka mea kāhea i ka `self` i nā palena o `slice`
        // ka mea e māʻona ai nā kūlana āpau no `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: ʻokoʻa me `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: nānā wale ʻia ʻo `start` ma ka palena char,
            // a ke hele nei mākou i kahi kūmole palekana, no laila e lilo pū ka waiwai hoʻihoʻi i hoʻokahi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Mea lapaʻau substring slicing me Ka Mooolelo O `&self[begin ..= end]` a `&mut self[begin ..= end]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho i hāʻawi ʻia mai ka pae byte [`begin`, `end`].Like ia `&self [begin .. end + 1]` a `&mut self[begin .. end + 1]`, koe wale no ina `end` i ka i kā mākou waiwai no `usize`.
///
/// Kēia hana i *O*(1).
///
/// # Panics
///
/// Panics inā ʻaʻole kuhikuhi ʻo `begin` i ka offset hoʻomaka o kahi huapalapala (e like me ka wehewehe ʻana e `is_char_boundary`), inā ʻaʻole kuhikuhi ʻo `end` i ka hopena byte offset o kahi ʻano (`end + 1` kahi hoʻomaka byte offset a like paha me `len`), inā `begin > end`, a i ʻole inā `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Hoʻokomo i ka ʻoki ʻana i ka substring me ka syntax `&self[..= end]` a i ʻole `&mut self[..= end]`.
///
/// Hoʻihoʻi i kahi ʻāpana o ke aho i hāʻawi ʻia mai ka pae byte [0, `end`].
/// Like ia `&self [0 .. end + 1]`, koe nae ina `end` i ka i kā mākou waiwai no `usize`.
///
/// Kēia hana i *O*(1).
///
/// # Panics
///
/// Panics ina `end` aole ia e kuhikuhi i ka pauʻai offset o ke ano (`end + 1` mea kekahi i hoʻomakaʻai offset i ho'ākāka 'ia ma ka `is_char_boundary`, a i keia ia `len`), a ina `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: pono e mālama ka mea kelepona i ka ʻaelike palekana no `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Wae i ka waiwai mai kekahi kaula
///
/// Hoʻohana pinepine ʻia ka hana ʻo `FromStr`'s [`from_str`], ma o ka hana [`parse`] o [`str`].
/// E ʻike i nā palapala a [`parse`] no nā laʻana.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ʻaʻohe ona palena manawa ola, a no laila hiki iā ʻoe ke hoʻokaʻawale i nā ʻano i loaʻa ʻole kahi palena manawa ola iā lākou iho.
///
/// Ma na olelo e ae, e hiki ke wae i `i32` me `FromStr`, akā,ʻaʻole he `&i32`.
/// Hiki iā ʻoe ke kālailai i kahi mea i loaʻa iā `i32`, akā ʻaʻole hoʻokahi i loaʻa kahi `&i32`.
///
/// # Examples
///
/// Ka hoʻokumu maʻamau o `FromStr` ma kahi hiʻohiʻona `Point` ʻano:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ʻO ka hemahema e pili ana i hiki ke hoʻihoʻi ʻia mai ka parsing ʻana.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Pākuʻi i kahi string `s` e hoʻihoʻi i kahi waiwai o kēia ʻano.
    ///
    /// Inā parsing ka holomua 'ana, e hoʻi i ka waiwai i loko o [`Ok`], ai ole ia i ke kaula ka maʻi-formatted hoʻi ka hewa i ho'ākāka' ana i ka loko [`Err`].
    /// Ka hewaʻano mea i ho'ākāka 'ia manaʻo o ka trait.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau me [`i32`], kahi ʻano e hoʻopili iā `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Nānā i kahi `bool` mai kahi kaula.
    ///
    /// Hāʻawi i kahi `Result<bool, ParseBoolError>`, no ka mea Xa X01 a i ʻole hiki ʻole ke parseable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Hoʻomaopopo, i nā manawa he nui, ʻoi aku ka pono o ke ʻano `.parse()` ma `str`.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}