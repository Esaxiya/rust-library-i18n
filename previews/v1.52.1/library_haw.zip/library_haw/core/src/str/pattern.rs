//! ʻO ke string API API.
//!
//! Hāʻawi ka Pattern API i kahi ʻano hana no ka hoʻohana ʻana i nā ʻano mana ʻokoʻa ke ʻimi nei ma o kahi kaula.
//!
//! No nā kikoʻī hou aʻe, e ʻike i ka traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], a me [`DoubleEndedSearcher`].
//!
//! ʻOiai kūpaʻa ʻole kēia API, hōʻike ʻia ia ma o nā API paʻa i ka ʻano [`str`].
//!
//! # Examples
//!
//! [`Pattern`] o [implemented][pattern-impls] i loko o ka hale lio API no [`&str`][`str`], [`char`], slices o [`char`], a me ka oihana a me closures hoʻokō `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // kumu hoʻohālike char
//! assert_eq!(s.find('n'), Some(2));
//! // ʻāpana o ke kumu chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // kumu hoʻopau
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Kukana kaula.
///
/// Hōʻike kahi `Pattern<'a>` hiki ke hoʻohana ʻia ke ʻano o ka hoʻokomo e like me ke ʻano o ke aho no ka ʻimi ʻana i [`&'a str`][str].
///
/// ʻO kahi laʻana, ʻo `'a'` a me `"aa"` nā hiʻohiʻona e kūlike i ka index `1` i ke aho `"baaaab"`.
///
/// Hana ka trait ponoʻī ma ke ʻano he mea kūkulu hale no kahi ʻano [`Searcher`] e pili ana, kahi e hana nei i ka hana maoli o ka ʻike ʻana i nā hanana o ke kumu i kahi kaula.
///
///
/// Kaukaʻi ʻia i ke ʻano o ke kumu, hiki ke loli ke ʻano o nā hana e like me [`str::find`] a me [`str::contains`].
/// Hōʻike ka papa ma lalo i kekahi o ia mau ʻano.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Huli ʻimi no kēia kumu
    type Searcher: Searcher<'a>;

    /// Kūkulu i ka mea ʻimi pili e pili ana mai `self` a me ka `haystack` e ʻimi ai.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Nānā inā kūlike ke kumu ma nā wahi āpau i ka hale hānai
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Nānā inā hoʻohālikelike ke ʻano i ke alo o ka mauʻu
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Nānā inā pili ke kumu ma ka hope o ka mauʻu
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Wehe i ke kumu mai ke alo o ka mauʻu, inā kūlike ia.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SAFETY: ʻIke ʻia ʻo `Searcher` e hoʻihoʻi i nā ʻike kūpono.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Wehe i ke kumu mai ka hope o ka mauʻu, inā pili ia.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SAFETY: ʻIke ʻia ʻo `Searcher` e hoʻihoʻi i nā ʻike kūpono.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Ka hopena o ke kāhea ʻana iā [`Searcher::next()`] a i ʻole [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Hōʻike i ka loaʻa ʻana o kahi hoʻokūkū o ke kumu ma `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Hōʻike ua hōʻole ʻia ʻo `haystack[a..b]` ma ke ʻano he like kūpono o ke kumu.
    ///
    /// E hoʻomaopopo he nui aʻe paha ma mua o hoʻokahi `Reject` ma waena o ʻelua mau match, ʻaʻohe mea e pono ai e hoʻohui ʻia i hoʻokahi.
    ///
    ///
    Reject(usize, usize),
    /// Hōʻike i kipa ʻia kēlā me kēia byte o ka pāhiʻu, hoʻopau i ka hana hou.
    ///
    Done,
}

/// He mea ʻimi no kahi kumu aho.
///
/// Hāʻawi kēia trait i nā hana no ka ʻimi ʻana i nā match non-overlaping o kahi lauana e hoʻomaka ana mai ka mua (left) o kahi aho.
///
/// E hoʻokō ʻia e nā ʻano `Searcher` pili o ka [`Pattern`] trait.
///
/// Kaha inoa ʻole ʻia ka trait no ka mea ʻo nā ʻikepili i hoʻihoʻi ʻia e nā ʻano [`next()`][Searcher::next] e koi ʻia e moe ma nā palena utf8 kūpono i ka hale hau.
/// Hāʻawi kēia i nā mea kūʻai aku o kēia trait e ʻokiʻoki i ka mauʻu mauʻu me ka ʻole o nā kaha manawa hou.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter no ke kaula ma lalo e ʻimi ʻia
    ///
    /// E hoʻihoʻi mau i ka [`&str`][str] like.
    fn haystack(&self) -> &'a str;

    /// Hana i kahi ʻimi ʻimi aʻe e hoʻomaka ana mai mua.
    ///
    /// - Hoʻi iā [`Match(a, b)`][SearchStep::Match] inā pili ʻo `haystack[a..b]` i ke kumu.
    /// - Hoʻi iā [`Reject(a, b)`][SearchStep::Reject] inā ʻaʻole hiki i `haystack[a..b]` ke kūlike i ke kumu, a hapa ʻē aʻe.
    /// - Hoʻi iā [`Done`][SearchStep::Done] inā kipa ʻia kēlā me kēia byte o ka pāhiʻu.
    ///
    /// Ke kahawai o [`Match`][SearchStep::Match] a me [`Reject`][SearchStep::Reject] nā loina mai i ka [`Done`][SearchStep::Done], e komo 'inideka papa koa i ka mea e pili, ole-overlapping, e uhi ana i ka pau haystack, a kau ma luna o utf8 palena.
    ///
    ///
    /// A [`Match`][SearchStep::Match] hopena pono e komo i ka pau like kumu, nae i ke Wāwahi i [`Reject`][SearchStep::Reject] hualoaʻa i loko o ākeʻakeʻa kumu nui e pili koena ai.ʻElua paha ka lōʻihi o nā pae ʻelua.
    ///
    /// Ma kahi laʻana, ʻo ke kumu `"aaa"` a me ka haystack `"cbaaaaab"` e hana paha i ke kahawai
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Loaʻa i ka hopena [`Match`][SearchStep::Match] e hiki mai ana.E nānā iā [`next()`][Searcher::next].
    ///
    /// ʻAʻole like me [`next()`][Searcher::next], ʻaʻohe mea hōʻoia e hoʻopili ʻia nā pae hoʻihoʻi o kēia a me [`next_reject`][Searcher::next_reject].
    /// Kēia, e hoʻi `(start_match, end_match)`, kahi start_match o ka Papa kuhikuhi o kahi o ka ń hoʻomaka, a me end_match o ka 'inideka ma hope o ka pau ana o ka ÷ ń.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Loaʻa i ka hopena [`Reject`][SearchStep::Reject] e hiki mai ana.E nānā [`next()`][Searcher::next] a me [`next_match()`][Searcher::next_match].
    ///
    /// ʻAʻole like me [`next()`][Searcher::next], ʻaʻohe mea hōʻoia e hoʻopili ʻia nā pae hoʻihoʻi o kēia a me [`next_match`][Searcher::next_match].
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// He ʻimi huli no kahi kumu kaula.
///
/// Hāʻawi kēia trait i nā hana no ka ʻimi ʻana i nā match non-overlaping o kahi lauana e hoʻomaka ana mai ka X00 hope o kahi aho.
///
/// E hoʻokō ʻia e nā ʻano [`Searcher`] pili o ka [`Pattern`] trait inā kākoʻo ke kumu i ka ʻimi ʻana iā ia mai ka hope.
///
///
/// ʻAʻole koi ʻia nā pae kuhikuhi i hoʻihoʻi ʻia e kēia trait e kūlike i kēlā me ka huli o hope i hope.
///
/// No ke kumu no ka mika palekana ʻole o kēia trait, e ʻike iā lākou makua trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Hana i kahi ʻimi ʻimi aʻe e hoʻomaka ana mai ka hope.
    ///
    /// - Hoʻi iā [`Match(a, b)`][SearchStep::Match] inā pili ʻo `haystack[a..b]` i ke kumu.
    /// - Hoʻi iā [`Reject(a, b)`][SearchStep::Reject] inā ʻaʻole hiki i `haystack[a..b]` ke kūlike i ke kumu, a hapa ʻē aʻe.
    /// - Hoʻi iā [`Done`][SearchStep::Done] inā kipa ʻia kēlā me kēia byte o ka pāhiʻu
    ///
    /// Ke kahawai o [`Match`][SearchStep::Match] a me [`Reject`][SearchStep::Reject] nā loina mai i ka [`Done`][SearchStep::Done], e komo 'inideka papa koa i ka mea e pili, ole-overlapping, e uhi ana i ka pau haystack, a kau ma luna o utf8 palena.
    ///
    ///
    /// A [`Match`][SearchStep::Match] hopena pono e komo i ka pau like kumu, nae i ke Wāwahi i [`Reject`][SearchStep::Reject] hualoaʻa i loko o ākeʻakeʻa kumu nui e pili koena ai.ʻElua paha ka lōʻihi o nā pae ʻelua.
    ///
    /// Me lakou i mea hoike, i ke kumu hoʻohālike `"aaa"` a me ka haystack `"cbaaaaab"` paha paka i ke kahawai `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// E ʻike i ka hopena [`Match`][SearchStep::Match] e hiki mai ana.
    /// E nānā iā [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// E ʻike i ka hopena [`Reject`][SearchStep::Reject] e hiki mai ana.
    /// E nānā iā [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// A peni mäka trait i ka hoike i ke [`ReverseSearcher`] hiki ke hoʻohana 'ia no ka [`DoubleEndedIterator`] manaʻo.
///
/// No kēia, pono e pili ka impl o [`Searcher`] a me [`ReverseSearcher`] i kēia mau ʻano:
///
/// - Pono nā hualoaʻa a pau o `next()` i nā hopena o `next_back()` ma ke kaʻina huli hope.
/// - `next()` a me `next_back()` pono e hana e like me nā wēlau ʻelua o kahi pae o nā kumukūʻai, ʻo ia ka hiki ʻole iā "walk past each other".
///
/// # Examples
///
/// `char::Searcher` he `DoubleEndedSearcher` no ka mea ʻo ka ʻimi ʻana i [`char`] wale nō ke koi ʻana i kēlā me kēia manawa, kahi like me nā ʻaoʻao ʻelua.
///
/// `(&str)::Searcher` ʻaʻole ia he `DoubleEndedSearcher` no ka mea ʻo ke kumu `"aa"` i ka haystack `"aaa"` e like me `"[aa]a"` a i ʻole `"a[aa]"`, e hilinaʻi ana ma ka ʻaoʻao hea e ʻimi ai.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Pili no char
/////////////////////////////////////////////////////////////////////////////

/// Nā ʻano i pili ʻia no `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // palekana invariant: `finger`/`finger_back` pono kahi utf8 byte index pono o `haystack` Hiki ke haki *kēia invariant* ma waena o * next_match a me next_match_back, akā pono lākou e puka me nā manamana lima ma nā palena kiko kuhi kikoʻī.
    //
    //
    /// `finger` ʻo ia ka papa kuhikuhi byte o ka ʻimi i mua.
    /// E noʻonoʻo aia ma mua o ka byte ma kāna papa kuhikuhi, ie
    /// `haystack[finger]` ʻo ia ka byte mua o ka ʻāpana a mākou e nānā ai i ka wā e ʻimi nei i mua
    ///
    finger: usize,
    /// `finger_back` ʻo ka papa kuhikuhi byte o kēia manawa no ka huli huli.
    /// E noʻonoʻo aia aia ma hope o ka byte ma kāna papa kuhikuhi, ie
    /// ʻo ka haystack [finger_back, 1] ka byte hope loa o ka ʻāpana a mākou e nānā ai i ka wā e ʻimi mua ana (a no laila e nānā ʻia ka byte mua ke kāhea iā next_back()).
    ///
    finger_back: usize,
    /// Ke huli ʻia nei ke ʻano
    needle: char,

    // invariant palekana: `utf8_size` pono ma lalo o 5
    /// Lawe ka helu o nā bytes `needle` i ka encode i utf8.
    utf8_size: usize,
    /// Kope utf8 i hoʻopā encode o ka `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SAFETY: 1-4 hōʻoia i ka palekana o `get_unchecked`
        // 1. `self.finger` a `self.finger_back` mālama ʻia ma nā palena unicode (ʻo kēia invariant)
        // 2. `self.finger >= 0` mai ka hoʻomaka ʻana ma 0 a hoʻonui wale nō
        // 3. `self.finger < self.finger_back` no ka mea i ʻole e hoʻihoʻi ka char `iter` iā `SearchStep::Done`
        // 4.
        // `self.finger` hiki mai ma mua o ka hopena o ka haystack no ka mea hoʻomaka ʻo `self.finger_back` ma ka hopena a e emi wale ana
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // hoʻohui i ka offte byte o ke ʻano o kēia manawa me ka hoʻopili ʻole hou ʻana ma ke ʻano utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // e kiʻi i ka nāhelehele ma hope o ke ʻano hope loa i loaʻa
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ʻo ka byte hope loa o ka utf8 i hoʻopaʻa ʻia i ka nila kuʻina SAFETY: loaʻa iā mākou kahi invariant e `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ke hou manamana lima o ka Papa kuhikuhi o kaʻai, ua loaʻa, hoʻohui kekahi, mahope mai o mākou memchr'd no ka hopeʻai o keʻano.
                //
                // E hoʻomaopopo ʻaʻole hāʻawi mau kēia iā mākou i kahi manamana lima ma ka palena UTF8.
                // Inā mākou *i i loaʻa* mākou ano mākou i ua Papa kuhikuhi i ka ole-hopeʻai o ka 3-ʻai a 4-ʻai külana.
                // ʻAʻole hiki iā mākou ke lele wale i ka byte hoʻomaka hoʻomaka no ka mea e like me ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` e loaʻa mau iā mākou ka byte ʻelua ke ʻimi nei i ke kolu.
                //
                //
                // Eia naʻe, maikaʻi loa kēia.
                // Ia mākou i ka invariant i self.finger mea ma luna o ka UTF8 palena, keia invariant ua i hilinaʻi aku lākou iā loko o kēia iaoia (ka mea, ua hilinaʻi aku lākou iā ia ma CharSearcher::next()).
                //
                // Hoʻopuka wale mākou i kēia hana ke hiki mākou i ka hopena o ke aho, a i ʻole inā ʻike mākou i kekahi mea.Ke loaʻa iā mākou kahi mea e hoʻonoho ʻia ka `finger` i ka palena UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // loaʻa ʻole mea, puka
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // e hoʻohana aʻe_reject i ka hoʻokō paʻamau mai ka Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SAFETY: e nānā i ka manaʻo no next() ma luna
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // e unuhi i ka byte offset o ke ʻano o kēia manawa me ka ʻole o ka hoʻopiʻi ʻana ma ke ʻano utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // e kiʻi i ka huhū a hiki i ka hoʻohui ʻana i ke ʻano hope loa i ʻimi ʻia
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ʻo ka byte hope loa o ka utf8 i hoʻopaʻa ʻia i ka nila kuʻina SAFETY: loaʻa iā mākou kahi invariant e `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // ua ʻimi mākou i kahi ʻāpana i offset ʻia e self.finger, hoʻohui self.finger e kiʻi hou i ka papa kuhikuhi kumu
                //
                let index = self.finger + index;
                // memrchr e hoʻihoʻi i ka papa kuhikuhi o ka byte a mākou e makemake ai e loaʻa.
                // Inā kahi ʻano ASCII, makemake mākou i kēia manamana hou o mākou ("after" ke kiʻi i loaʻa i ke ʻano o ka hoʻohuli hoʻohuli).
                //
                // No nā chib multibyte pono mākou e lele i lalo i ka helu o nā byte i loaʻa iā lākou ma mua o ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // neʻe i ka manamana lima ma mua o ka loaʻa ʻana o ke ʻano (ie, ma ka papa kuhikuhi hoʻomaka)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ʻAʻole hiki iā mākou ke hoʻohana i ka finger_back=index, size + 1 ma aneʻi.
                // Inā mākou i loaʻa i ka char hope loa o kahi ʻano like ʻole (a i ʻole ka byte waena o kekahi ʻano ʻē aʻe) pono mākou e ʻōkuʻu i ka manamana lima i lalo i `index`.
                // Hoʻohālikelike kēia iā `finger_back` i ka hiki ke lilo hou i ka palena, akā maikaʻi kēia ʻoiai mākou e puka wale i kēia hana ma kahi palena a i ka wā i huli ʻia ai ka mauʻu mauʻu.
                //
                //
                // ʻAʻole like me kēia_match ʻaʻohe pilikia o nā bytes hou i utf-8 no ka mea ke ʻimi nei mākou i ka byte hope loa, a hiki iā mākou ke loaʻa i ka byte hope loa ke ʻimi nei i hope.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // loaʻa ʻole mea, puka
                return None;
            }
        }
    }

    // e hoʻohana i ka_una aʻe_reject_back i ka hoʻokō paʻamau mai ka Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Searches no ka Mike Char i mea like me ka haawi mai [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Hoʻopili no kahi wahī MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Hoʻohālikelike i nā lōʻihi o ka baila slice iterator e ʻike i ka lōʻihi o ka char o kēia manawa
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Hoʻohālikelike i nā lōʻihi o ka baila slice iterator e ʻike i ka lōʻihi o ka char o kēia manawa
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Pili no&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Hoʻololi/Wehe ma muli o ke kānalua i ka manaʻo.

/// Nā ʻano i pili ʻia no `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Nā ʻimi no nā chars i kūlike i kekahi o nā [`char`] i ka ʻāpana.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Hoʻokomo no F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Nā ʻano i pili ʻia no `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Huli no nā [`char`] e kūlike me ka predicate i hāʻawi ʻia.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Pili no&&str
/////////////////////////////////////////////////////////////////////////////

/// ʻElele i ka `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Hoʻopili no &str
/////////////////////////////////////////////////////////////////////////////

/// Huli hoʻokaʻawale hoʻokaʻawale.
///
/// E lawelawe i ke kumu `""` ma ke hoʻi ʻana i nā match hakahaka i kēlā me kēia palena o ke ʻano.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Nānā inā hoʻohālikelike ke ʻano i ke alo o ka mauʻu.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Wehe i ke kumu mai ke alo o ka mauʻu, inā kūlike ia.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SAFETY: ua hōʻoia wale ʻia ʻo mua
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Nānā inā pili ke kumu ma ka hope o ka mauʻu.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Wehe i ke kumu mai ka hope o ka mauʻu, inā pili ia.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SAFETY: ua hōʻoia wale ʻia ka hope.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ʻImi ʻimi substring ʻelua
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Nā ʻano i pili ʻia no `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // hōʻole nā nila nalo i kēlā me kēia char a kūlike i nā kaula nele ma waena o lākou
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produces henua pololei *aʻohe* indices e mahae ma Mike Char palena like loa me ka mea e hana pololei'ālike, a ua haystack a me ka puka o ua pololei ia UTF-8 *hoomalau mai lakou i* mai ka algorithm hiki haule ma kekahi indices, akā, e hele mākou i hana lima i ka mea e hiki mai ana ano palena, no laila palekana lākou iā utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // lele i ka palena char aʻe
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // e kākau i nā hihia `true` a me `false` e paipai i ka mea hoʻopili e hana kūikawā i nā hihia ʻelua i kaawale.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // lele i ka palena char aʻe
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // kākau `true` a me `false`, e like me `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Ke kūlana kūloko o ka ʻaoʻao ʻelua huli ʻana i ka algorithm.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// papa kuhikuhi helu koʻikoʻi koʻikoʻi
    crit_pos: usize,
    /// papa kuhikuhi helu koʻikoʻi no ka nila kuapo
    crit_pos_back: usize,
    period: usize,
    /// `byteset` he hoʻolōʻihi (ʻaʻole ʻāpana o ka ʻaoʻao ʻelua algorithm);
    /// he X-"fingerprint" 64-iki kahi e pili ai kēlā me kēia set bit `j` i kahi (byte&63)==j i kēia manawa ma ka nila.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// kuhikuhi i loko o ke kui kele ma mua a mākou i pili mua
    memory: usize,
    /// papa kuhikuhi i loko o ka nila kuhoho a ma hope ua like mākou
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ʻO kahi wehewehe e pili pono ana i ka mea e hana nei ma aneʻi hiki ke loaʻa ma kā Crochemore a me kā Rytter puke "Text Algorithms", ch 13.
        // ʻIke kikoʻī i ke code no "Algorithm CP" ma ka p.
        // 323.
        //
        // He aha Ka hele ana ma ka mākou i kekahi pilikia factorization (u, V) o ke kuikele, a ua makemake e ike ai i ko? U mea he kau hope o&v [.. manawa].
        // Ināʻo ia, hoʻohana mākou i "Algorithm CP1".
        // Inā mākou e hoʻohana "Algorithm CP2", i hoʻomākaukau leʻa ʻia no ka wā nui o ka nila.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // hihia wā pōkole-kikoʻī ka wā kikoʻī i kahi ʻāpana koʻikoʻi koʻikoʻi no ke kui kiki x=u 'v' kahi | v '|<period(x).
            //
            // Lawe ʻia kēia e ka manawa i ʻike ʻia.
            // Hoʻomaopopo i kahi hihia e like me x= "acba" e pili pono pono ʻia i mua (crit_pos=1, wā=3) ʻoiai e hoʻopili ʻia me kahi wā kokoke i hope (crit_pos=2, wā=2).
            // Hoʻohana mākou i ka mea i hoʻohuli ʻia i hoʻohuli ʻia akā mālama i ka manawa kikoʻī.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // hihia lōʻihi-loaʻa iā mākou kahi kokoke i ka wā maoli, a mai hoʻohana i ka hoʻopaʻanaʻau.
            //
            //
            // E hoʻokokoke i ka wā ma lalo o max(|u|, |v|) + 1.
            // Kūpono ka mea koʻikoʻi koʻikoʻi e hoʻohana no ka ʻaoʻao i mua a huli huli.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy waiwai e hōʻailona ai ua lōʻihi ka wā
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Kekahi o na kumu nui i ka manaʻo nui o Two-Way mea ia mākou factorize ke kui kele ma loko o nā halves, (u, V), a me ka hoʻomaka ho'āʻo ana e loaʻa V ma ka haystack ma kaʻimiʻana i haalele ai ia i ka akau.
    // Inā kūlike ʻo v, hoʻāʻo mākou e hoʻohālikelike iā ʻoe ma ka ʻimi ʻākau ʻana hema.
    // Pehea ka mamao i ka wa a makou i halawai me kekahi kanaka OOAaAeAa mea a pau ma muli o ka mea i (u, V) mea he pilikia factorization no ke kui kele ma mākou ke lele.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` hoʻohana `self.position` like kona kahaʻimo
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // E hōʻoia inā he lumi ko mākou e ʻimi ai i ke kūlana + ʻaʻole hiki i ka needle_last ke piʻi aʻe inā mākou e hoʻopili i nā ʻāpana e ka pae o isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Koke skip ma nui wale i kaʻai unrelated i ko kakou substring
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // E nānā i ina ka akau loa o ke kuikele ihoiho
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // E ʻike inā pili ka ʻaoʻao hema o ka nila
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Mākou i loaʻa i ka ń!
            let match_pos = self.position;

            // Note: hoʻohui i ka self.period ma kahi o needle.len() i loaʻa nā match like
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // hoʻonoho ʻia i needle.len(), self.period no nā match like
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Hahai i nā manaʻo ma `next()`.
    //
    // Ka wehewehena i symmetrical, me period(x) = period(reverse(x)) a me local_period(u, v) = local_period(reverse(v), reverse(u)), no laila, inā (u, V) ua he pilikia factorization, no laila, o (reverse(v), reverse(u)).
    //
    //
    // No ka hihia hope ua hōʻuluʻulu mākou i kahi helu koʻikoʻi x=u 'v' (kahua `crit_pos_back`).Mākou Pono | Liliʻu |<period(x) no ka mea mua, a me ka hihia pela | V '|<period(x) no ka hope.
    //
    // No ka huli 'ana i loko aʻe ma ka haystack, ua huli aku ma kekahi nana e hoole haystack me ka nana e hoole kuikele,'ālike mua Liliʻu' a laila, V '.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` hoʻohana iā `self.end` ma ke ʻano he kursor-no laila kūʻokoʻa ʻo `next()` a me `next_back()`.
        //
        let old_end = self.end;
        'search: loop {
            // Hōʻoia i ke loaa kahi akea e huli ma ka hopena, needle.len() e uhi puni ia mea,ʻaʻohe hou kaawale, akā, ma muli o ka māhele lōʻihi mokuna o ka mea hiki loa e uhi i ke ala hoʻi i loko o ka lōʻihi o ka haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Koke skip ma nui wale i kaʻai unrelated i ko kakou substring
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // E ʻike inā pili ka ʻaoʻao hema o ka nila
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // E nānā i ina ka akau loa o ke kuikele ihoiho
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Mākou i loaʻa i ka ń!
            let match_pos = self.end - needle.len();
            // Note: ma lalo o self.period ma kahi o needle.len() e loaʻa nā match like
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // E helu i ka hope nui o `arr`.
    //
    // ʻO ka hope loa ka mea nui i hiki ke hoʻoholo ʻia (u, v) o `arr`.
    //
    // Hoike ('i`, `p`) kahi `i` o ka hoʻomaka' inideka o ka V a me `p` mea i ka wā o ka v.
    //
    // `order_greater` hoʻoholo inā `<` a `>` paha ka lexical kauoha.
    // Pono e helu ʻia nā kauoha ʻelua-ʻo ka hoʻonohonoho ʻana me `i` nui loa e hāʻawi i kahi ʻano koʻikoʻi.
    //
    //
    // No ka lōʻihi wā hihia, ke kūpono manawa mea,ʻaʻole kiko'ī (ia mea, ua pōkole).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Kūlike me i i ka pepa
        let mut right = 1; // Hoʻopili like i ka hu ma ka pepa
        let mut offset = 0; // Pili i k i ka pepa, akā e hoʻomaka ana ma 0
        // e kūlike me ka helu ʻana ma muli o 0.
        let mut period = 1; // Pili i ka p i ka pepa

        while let Some(&a) = arr.get(right + offset) {
            // `left` e komo i loko ke `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Heʻuʻuku ʻo Suffix, ʻo ka manawa ka unuhi mua āpau i kēia manawa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Mua ma repetition o kaʻikena wā.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ʻOi aku ka nui o ka Suffix, hoʻomaka ma kahi o kēia manawa.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // E helu i ka hope loa o ka hope o `arr`.
    //
    // Ke maximal kau hope o ka hiki pilikia factorization (Liliʻu ', V') o `arr`.
    //
    // Hoʻi iā `i` kahi `i` i ka papa kuhikuhi hoʻomaka o v ', mai ka hope;
    // hoʻi koke ke hiki mai kahi manawa o `known_period`.
    //
    // `order_greater` hoʻoholo inā `<` a `>` paha ka lexical kauoha.
    // Pono e helu ʻia nā kauoha ʻelua-ʻo ka hoʻonohonoho ʻana me `i` nui loa e hāʻawi i kahi ʻano koʻikoʻi.
    //
    //
    // No ka lōʻihi wā hihia, ke kūpono manawa mea,ʻaʻole kiko'ī (ia mea, ua pōkole).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Kūlike me i i ka pepa
        let mut right = 1; // Hoʻopili like i ka hu ma ka pepa
        let mut offset = 0; // Pili i k i ka pepa, akā e hoʻomaka ana ma 0
        // e kūlike me ka helu ʻana ma muli o 0.
        let mut period = 1; // Pili i ka p i ka pepa
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Heʻuʻuku ʻo Suffix, ʻo ka manawa ka unuhi mua āpau i kēia manawa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Mua ma repetition o kaʻikena wā.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ʻOi aku ka nui o ka Suffix, hoʻomaka ma kahi o kēia manawa.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// Hāʻawi ʻo TwoWayStrategy i ka algorithm e lele i nā pāʻani ʻole i ka hikiwawe, a i ʻole e hana i kahi ʻano kahi e hoʻokuʻu ai i nā Rejects me ka wikiwiki.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// E lele e hoʻokūkū i nā wā i hikiwawe loa
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Hōʻole pinepine ʻo Emit
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}