use core::task::Poll;

#[test]
fn poll_const() {
    // e hoʻāʻo i nā ʻano o `Poll` i hiki ke hoʻohana ʻia i loko o ka pōʻaiapili paʻa

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}