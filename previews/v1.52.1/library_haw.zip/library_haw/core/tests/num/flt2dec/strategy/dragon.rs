use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Lohi loa ʻo Miri
fn exact_sanity_test() {
    // Pau kēia hōʻike i ka holo ʻana i ka mea e hiki ai iaʻu ke kuhi wale i kahi hihia kihi-ish o ka hana waihona `exp2`, i wehewehe ʻia i nā mea a pau C runtime a mākou e hoʻohana nei.
    // Ma makou 2013 kēia kuleana pili i apparently i ka pilikia e like me keia hoʻokolohua ke aloha ka wā ua hoʻopili, akā, me makou 2015 ka pilikia 'ōili mai paa e like me ka hoao ana holo pono ka hana.
    //
    // Me he mea lā he ʻokoʻa ka bug i ka waiwai hoʻihoʻi o `exp2(-1057)`, kahi ma VS 2013 hoʻihoʻi ia i pālua me ke ʻano iki 0x2 a i ka VS 2015 hoʻi ia 0x20000.
    //
    //
    // No ka manawa wale kāpae'ōlelo i kēia hōʻike loa ma MSVC like ia Ka ho'āʻo kakou Hehe, a ua huli ole iā Naha Pōhaku hoihoi i ka hoao kēlā pola ka exp2 manaʻo.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}