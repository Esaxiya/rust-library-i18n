use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ʻAʻole kūpaʻa kēia o ka ʻāpana, akā kōkua ia e mālama i ka `?` ma waena o lākou, ʻoiai inā ʻaʻole hiki i ka LLVM ke hoʻohana kūpono iā ia i kēia manawa.
    //
    // (Kūlike ʻole ka hopena a me ke koho kaumaha, no laila ʻaʻole hiki i ka ControlFlow ke kūlike i nā mea ʻelua.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}