//! A UTF-8 - encoded, growable string.
//!
//! Aia i loko o kēia module ke ʻano [`String`], ka [`ToString`] trait no ka hoʻololi ʻana i nā aho, a me kekahi mau ʻano kuhihewa i hopena ʻia ma ka hana ʻana me [`String`] s.
//!
//!
//! # Examples
//!
//! Nui a hewahewa nā ala e hana i kahi [`String`] hou mai kahi string literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Hiki iā ʻoe ke hana i kahi [`String`] hou mai kahi e kū nei ma ka concatenating ʻana me
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Inā loaʻa iā ʻoe kahi vector o nā bytes UTF-8 kūpono, hiki iā ʻoe ke hana i kahi [`String`] ma waho.Hiki iā ʻoe ke hana i ka hoʻi.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ʻIke mākou he pololei kēia mau byte, no laila e hoʻohana mākou i `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// A UTF-8 - encoded, growable string.
///
/// Ke `String` ʻano o ka loa, he pono ole kaula type e loaʻa ona ma luna o kahi o ke kaula.Ua loaʻa he kokoke pilina me kona aie counterpart, ka primitive [`str`].
///
/// # Examples
///
/// Oe ke hana i kekahi `String` mai [a literal string][`str`] me [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Hiki iā ʻoe ke hoʻopili i [`char`] i kahi `String` me ke ʻano [`push`], a hoʻopili i [`&str`] me ke ʻano [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Inā loaʻa iā vector o UTF-8 bytes, hiki iā ʻoe ke hana i `String` mai ia me ke ʻano [`from_utf8`].
///
/// ```
/// // kekahi mau byte, i kahi vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ʻIke mākou he pololei kēia mau byte, no laila e hoʻohana mākou i `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Kūpono mau nā aho UTF-8.He mau manaʻo paha kēia, ʻo ka mea mua inā pono ʻoe i kahi aho ʻole UTF-8, e noʻonoʻo iā [`OsString`].He like ia, akā me ka ʻole o ka UTF-8 kaohi.Ka lua o ka implication mea ia oe ke ole inideka i loko o ka `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Kuhi ʻia ka papa kuhikuhi ʻana i manawa no ka manawa mau, akā ʻaʻole ʻae ʻo UTF-8 encoding iā mākou e hana i kēia.Eia kekahi, ʻaʻole maopopo i ke ʻano o ka mea a ka index e hoʻi ai: he byte, a codepoint, a he grapheme cluster.
/// Hoʻihoʻi nā hana [`bytes`] a me [`chars`] i nā iterator ma luna o nā mea mua ʻelua.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Hoʻokomo ʻo String`s [`Deref`]`<Target=str>ʻ, a no laila hoʻoilina i nā hana a [[str`] āpau.Hoʻohui, pili kēia hiki iā ʻoe ke hoʻohele i kahi `String` i kahi hana e lawe ai i [`&str`] ma o ka hoʻohana ʻana i kahi ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Kēia, e hana i kekahi [`&str`] mai ka `String`, a hala ia i loko o. Keia huli ana ka loa inexpensive, a no laila, nui, oihana eʻae ['&str`] ke i kekahi manaʻo hoʻopiʻi kū'ē ole ka mea pono i ka `String` no kekahi kekahi kumu.
///
/// I kekahi mau hihia, ʻaʻole lawa ka ʻike o Rust e hoʻohuli ai i kēia hoʻololi, i ʻike ʻia ma ke ʻano he [`Deref`] coercion.I ka laʻana aʻe e hana ana kahi kaula ʻāpana [`&'a str`][`&str`] i ka trait `TraitExample`, a lawe ka hana `example_func` i kekahi mea e hoʻokō i ka trait.
/// I kēia hihia e pono iā Rust e hana i ʻelua hoʻololi hoʻololi ʻana, a ʻaʻohe kumu o Rust e hana ai.
/// No kēlā kumu, ʻaʻole e hoʻopili ʻia kēia laʻana.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// ʻElua mau koho e holo ma kahi.E hoʻololi ka mea mua i ka laina `example_func(&example_string);` a i `example_func(example_string.as_str());`, me ka hoʻohana ʻana i ke ʻano [`as_str()`] e unuhi pono i ka ʻāpana o ke aho i loaʻa i ke aho.
/// Hoʻololi ke ala ʻelua iā `example_func(&example_string);` i `example_func(&*example_string);`.
/// I kēia hihia ke nānā nei mākou i kahi `String` i kahi [`str`][`&str`], a laila e kuhikuhi nei i ka [`str`][`&str`] i [`&str`].
/// ʻO ka ʻaoʻao ʻelua ʻoi aku idiomatic, akā hana pū nā mea ʻelua e hana akāka ma mua o ka hilinaʻi ʻana i ka hoʻohuli implicit.
///
/// # Representation
///
/// Hana ʻia kahi `String` i ʻekolu mau ʻāpana: kahi kuhikuhi i kekahi mau byte, kahi lōʻihi, a me kahi hiki.Kuhi ka pointer i kahi buffer kūloko `String` e hoʻohana ai e mālama i kāna ʻikepili.ʻO ka lōʻihi ka helu o nā byte i mālama ʻia i kēia manawa i ka buffer, a ʻo ka nui o ka buffer i nā bytes.
///
/// E like me ia, e emi mau ana ka lōʻihi ma mua a i ʻole kūlike i ka hiki.
///
/// Kēia aooa? Ua mau waiho ma luna o ka puʻu.
///
/// Hiki iā ʻoe ke nānā i kēia me nā ʻano [`as_ptr`], [`len`], a me [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Hoʻohou i kēia ke kūpaʻa ka vector_into_raw_parts.
/// // Kāohi i ka waiho wale ʻana i ka ʻikepili a ka String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // he ʻumikūmāiwa mau bytes ka moʻolelo
/// assert_eq!(19, len);
///
/// // E hiki hou-kūkulu i kekahi kaula mai o ptr, Len, a me ka 'auhau.
/// // Palekana ʻole kēia a pau no ka mea ke kuleana nei mākou i ka ʻike pono ʻana i nā ʻāpana:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Inā lawa ka hiki i kahi `String`, ʻaʻole e hoʻokaʻawale hou nā mea hoʻohui iā ia.ʻO kahi laʻana, e noʻonoʻo i kēia papahana:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// E hoʻopuka kēia i kēia:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// I ka mua, ʻaʻohe o mākou hoʻomanaʻo i hoʻokaʻawale ʻia, akā ke hoʻopili mākou i ke aho, hoʻonui ia i kona hiki kūpono.Inā mākou e hoʻohana i ka hana [`with_capacity`] e hoʻokaʻawale i ka hiki kūpono i kinohi.
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Hoʻopau mākou me kahi huahana ʻokoʻa:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Maʻaneʻi, ʻaʻole pono e hoʻokaʻawale i kahi hoʻomanaʻo hou aʻe i loko o ka loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Kuhi kūpono kūpono i ka hoʻololi ʻana i `String` mai kahi UTF-8 byte vector.
///
/// ʻO kēia ʻano ke ʻano hemahema no ka hana [`from_utf8`] ma [`String`].
/// Hoʻolālā ʻia i kahi ala e pale pono ai i nā reallocations: e hoʻihoʻi ka hana [`into_bytes`] i ka byte vector i hoʻohana ʻia i ka hoʻāʻo hoʻohuli.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// ʻO ka ʻano [`Utf8Error`] i hāʻawi ʻia e [`std::str`] e hōʻike ana i kahi hemahema i hiki ke hoʻololi ʻia ke hoʻololi ʻana i kahi ʻāpana o [`u8`] i kahi [`&str`].
/// I kēia manaʻo, he analogue ia i `FromUtf8Error`, a hiki iā ʻoe ke kiʻi i hoʻokahi mai kahi `FromUtf8Error` ma o ka hana [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// // kekahi mau byte kūpono ʻole, ma kahi vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Kuhi kūpono kūpono i ka hoʻololi ʻana i `String` mai kahi ʻāpana byte UTF-16.
///
/// ʻO kēia ʻano ke ʻano hemahema no ka hana [`from_utf16`] ma [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Hana i kahi `String` hakahaka hou.
    ///
    /// Hāʻawi ʻia i ka `String` hakahaka, ʻaʻole kēia e hoʻokaʻawale i kahi pale pale mua.ʻOiai ke kumu o ke kumu kūʻai o kēia hana mua loa, he kumu ia o ka hoʻokaʻawale ʻana ma hope ke hoʻohui ʻoe i ka ʻikepili.
    ///
    /// Inā he manaʻo kou no ka nui o ka ʻikepili e paʻa ai ka `String`, e noʻonoʻo i ka hana [`with_capacity`] e pale ai i ka hoʻokaʻawale hou ʻana.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Hana i kahi `String` hakahaka hou me kahi mana kikoʻī.
    ///
    /// Loaʻa iā String` kahi pale pale i loko e hoʻopaʻa i kā lākou ʻikepili.
    /// ʻO ka hiki ke lōʻihi o kēlā buffer, a hiki ke nīnau ʻia me ka [`capacity`] hana.
    /// Hoʻokumu kēia ala i kahi `String` hakahaka, akā hoʻokahi me kahi pale mua i hiki ke hoʻopaʻa i nā bytes `capacity`.
    /// He mea pono ia oe e ke huiia me he pua kiele oʻikepili i ka `String`, hoemi i ka helu ana o reallocations ka mea pono e hana ai.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Inā `0` ka mana i hāʻawi ʻia, ʻaʻohe hoʻokaʻawale e loaʻa, a kūlike kēia ala me ka [`new`] hana.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // ʻAʻohe o ke kaula i nā chars, ʻoiai nona ka mana no nā mea hou aʻe
    /// assert_eq!(s.len(), 0);
    ///
    /// // Hana ʻia kēia mau mea me ka ʻole o ka hoʻoili hou ʻana ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... akā e hana paha kēia i ke aho
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): me cfg(test) ke ʻano `[T]::to_vec` kūmau, i koi ʻia no kēia wehewehe ʻana o kēia hana, ʻaʻole i loaʻa.
    // ʻOiai ʻaʻole mākou e koi i kēia hana no ka hoʻāʻo ʻana, e ʻōpala wale wau iā NB e ʻike i ka module slice::hack ma slice.rs no ka ʻike hou aku
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Hoʻololi i vector o nā bytes i `String`.
    ///
    /// A kaula ([`String`]) ua i mai o nāʻai ([`u8`]), a me he vector o nāʻai ([`Vec<u8>`]) ua i mai o nāʻai, no laila, i kēia papa pio ma waena o ka elua.
    /// ʻAʻole kūpono nā ʻāpana byte i nā 'String`s, eia naʻe: koi ʻo `String` i ka pololei UTF-8.
    /// `from_utf8()` nā hōʻoia e hōʻoia i ka pololei o nā bytes UTF-8, a laila hana ka hoʻololi.
    ///
    /// Inā ʻoe e maopopo he pololei UTF-8 i ka ʻāpana byte, a ʻaʻole ʻoe makemake e loaʻa i ka overhead o ka hōʻoia hōʻoia, aia kahi mana palekana ʻole o kēia hana, [`from_utf8_unchecked`], nona ka ʻano like akā haʻalele i ka hōʻoia.
    ///
    ///
    /// E mālama kēia hana i kope ʻole i ka vector, no ka pono o ka pono.
    ///
    /// Inā makemake ʻoe i [`&str`] ma kahi o `String`, e noʻonoʻo iā [`str::from_utf8`].
    ///
    /// ʻO ka inverse o kēia hana ʻo [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Hoʻi iā [`Err`] inā ʻaʻole UTF-8 kahi ʻāpana me kahi wehewehe no ke aha ʻaʻole i hāʻawi ʻia nā bytes i UTF-8.Hoʻokomo pū ʻia ka vector āu i neʻe ai.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte, i kahi vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ʻIke mākou he pololei kēia mau byte, no laila e hoʻohana mākou i `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Pololei ole nāʻai:
    ///
    /// ```
    /// // kekahi mau byte kūpono ʻole, ma kahi vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// E ʻike i nā docs no [`FromUtf8Error`] no nā kikoʻī hou aʻe e pili ana i nā mea e hiki ai iā ʻoe ke hana me kēia hemahema.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Pio i kekahi māhele o nāʻai a hiki i ke kaula, a me ka helu kuhi huapalapala.
    ///
    /// Hana ʻia nā aho e nā bytes ([`u8`]), a ʻo kahi ʻāpana o nā bytes ([`&[u8]`][byteslice]) e hana ʻia e nā bytes, no laila hoʻololi kēia hana ma waena o nā mea ʻelua.'Aʻole i pauʻai slices i i pololei ia kaula, nae: e koi kaula e e i pololei ia UTF-8.
    /// Ma keia huli ana, `from_utf8_lossy()` e puku i kekahi helu kuhi UTF-8 kaʻina me [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], a nana e like keia:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Inā ʻoe e ʻike pono he maikaʻi ka paukū byte UTF-8, a ʻaʻole ʻoe makemake e loaʻa i ka overhead o ka hoʻohuli, aia kahi mana palekana ʻole o kēia hana, [`from_utf8_unchecked`], nona ka ʻano like akā haʻalele i nā kaha.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Hoʻihoʻi kēia hana i [`Cow<'a, str>`].Inā pololei ʻole kā kā mākou ʻāpana byte UTF-8, a laila pono mākou e hoʻokomo i nā huapalapala pani, kahi e hoʻololi ai i ka nui o ke aho, a no laila, e noi iā `String`.
    /// Akā inā ua kūpono ʻo UTF-8, ʻaʻole pono mākou i kahi hoʻokaʻawale hou.
    /// ʻAe kēia ʻano hoʻihoʻi iā mākou e lawelawe i nā hihia ʻelua.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte, i kahi vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Pololei ole nāʻai:
    ///
    /// ```
    /// // kekahi mau byte pono ʻole
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// E hoʻopau i kahi UTF-16 - encode vector `v` i loko o kahi `String`, e hoʻihoʻi nei iā [`Err`] inā loaʻa nā ʻikepili kūpono ʻole i ka `v`.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ʻAʻole i hana ʻia kēia ma ohi: : <Result<_, _>> () No ka lawelawe kumu.
        // FIXME: hiki ke maʻalahi i ka hana ke pani ʻia ʻo #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Hoʻoholo i kahi ʻāpana UTF-16 - i hoʻopili ʻia i ka ʻāpana `v` i kahi `String`, e pani ana i ka ʻikepili kūpono ʻole me [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// ʻAʻole like me [`from_utf8_lossy`] e hoʻihoʻi nei i [`Cow<'a, str>`], hoʻihoʻi ʻo `from_utf16_lossy` i kahi `String` mai ka huli ʻana o UTF-16 a UTF-8 i kahi hoʻokaʻawale hoʻomanaʻo.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Hoʻopau i kahi `String` i loko o kāna mau mea hana.
    ///
    /// Hoike i ka maka laʻau kuhikuhi i ka hp'pnphp 'ikepili, ka lōʻihi o ke kaula (i loko o nāʻai), a me ka anao? Aou nona iho o kaʻikepili (i loko o nāʻai).
    /// ʻO kēia nā paio like i ke kaʻina like me nā hoʻopaʻapaʻa iā [`from_raw_parts`].
    ///
    /// Ma hope o ke kāhea ʻana i kēia kuleana, kuleana ke kāhea no ka hoʻomanaʻo i hoʻokele mua ʻia e ka `String`.
    /// ʻO ke ala wale nō e hana ai i kēia ke hoʻololi i ka pointer maka, ka lōʻihi, a me ka hiki i hoʻi i `String` me ka hana [`from_raw_parts`], e ʻae i ka mea hōʻino e hana i ka hoʻomaʻemaʻe.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Hana i kahi `String` hou mai kahi lōʻihi, hiki, a kuhikuhi.
    ///
    /// # Safety
    ///
    /// He nui unsafe, ma muli o ka helu ana o invariants i mea ole kulana kupono:
    ///
    /// * Pono e hoʻokaʻawale ʻia ka hoʻomanaʻo ma `buf` e ka mea hoʻokaʻawale like a ka waihona waihona maʻamau e hoʻohana ai, me kahi hoʻopili pono o 1 maoli.
    /// * `length` pono e emi ma lalo a i ʻole like paha me `capacity`.
    /// * `capacity` pono ka waiwai kūpono.
    /// * ʻO ka `length` bytes mua ma `buf` pono e kūpono UTF-8.
    ///
    /// ʻO ka hōʻino ʻana i kēia mau mea ke kumu o nā pilikia e like me ka hōʻino ʻana i nā ʻōnaehana ʻikepili o ka mea hoʻokaʻawale.
    ///
    /// I ka ona o `buf` ua kuleʻa hoololiia i ka `String` a i laila deallocate, reallocate 'ole hoʻololi i nā mea o ka iaiyoe kuhikuhi ia e ka laʻau kuhikuhi i makemake.
    /// E hōʻoia i ka hoʻohana ʻole ʻana o ka mea kuhikuhi ma hope o ke kāhea ʻana i kēia hana.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Hoʻohou i kēia ke kūpaʻa ka vector_into_raw_parts.
    ///     // Kāohi i ka waiho wale ʻana i ka ʻikepili a ka String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Hoʻololi i kahi vector o nā bytes i kahi `String` me ka nānā ʻole ʻana inā loaʻa ka UTF-8 i ke aho.
    ///
    /// E ʻike i ka mana palekana, [`from_utf8`], no nā kikoʻī hou aʻe.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana no ka mea ʻaʻole ia e kaha i nā byte i hāʻawi ʻia iā ia he UTF-8 kūpono.
    /// Inā hōʻeha ʻia kēia kaohi, hiki iā ia ke kumu i nā pilikia unsafety memo me nā mea hoʻohana future o ka `String`, ʻoiai ke koena o ka waihona waihona maʻamau e loaʻa ana nā "String`s UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte, i kahi vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Pio he `String` i loko o kaʻai vector.
    ///
    /// Pau kēia i ka `String`, no laila ʻaʻole pono mākou e kope i kāna ʻike.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Nā pōʻalo he kaula māhele i loaʻa i ka `String` holoʻokoʻa.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Hoʻohuli i `String` i kahi ʻāpana kaula hiki ke hoʻololi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Hoʻopili i kahi ʻāpana kaula i hāʻawi ʻia ma ka hopena o kēia `String`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Hoʻihoʻi i kā kēia 'String` hiki, i nā bytes.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Hōʻoia i ka hiki i kēia 'String` ma ka liʻiliʻi `additional` bytes nui aʻe ma mua o kona lōʻihi.
    ///
    /// E hoʻonui ʻia paha ka hiki ma mua o `additional` bytes inā koho ia, e pale aku i nā reallocations pinepine.
    ///
    ///
    /// Inā ʻaʻole ʻoe makemake i kēia hana "at least", e ʻike i ke ʻano [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ina ka hou nona iho e hālanaʻia [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ʻAʻole paha e hoʻonui maoli kēia i ka hiki:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s kahi lōʻihi o 2 a me kahi kaha o 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Oiai mākou i kāinoa mua he keu 8 nona iho, e kahea ana i kēia ...
    /// s.reserve(8);
    ///
    /// // ... ʻaʻole hoʻonui maoli.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Hōʻoia i ka hiki i kēia 'String` ke loaʻa iā `additional` bytes ʻoi aku ka nui ma mua o kona lōʻihi.
    ///
    /// E hoomanao i ka hoʻohana 'ana i ka [`reserve`] ano ole oe e pāpā ikaika ike maikaʻi ma mua o ka allocator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ʻAʻole paha e hoʻonui maoli kēia i ka hiki:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s kahi lōʻihi o 2 a me kahi kaha o 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Oiai mākou i kāinoa mua he keu 8 nona iho, e kahea ana i kēia ...
    /// s.reserve_exact(8);
    ///
    /// // ... ʻaʻole hoʻonui maoli.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// E hoʻāʻo e mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `String` i hāʻawi ʻia.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    /// Ma hope o ke kāhea ʻana iā `reserve`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// ʻAʻohe mea inā lawa ka hiki.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve(data.len())?;
    ///
    ///     // I kēia manawa maopopo iā mākou ʻaʻole hiki iā OOM i ka waena o kā mākou hana paʻakikī
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// E hoʻāʻo e mālama i ka hiki palena iki no `additional` kikoʻī hou aʻe e hoʻokomo ʻia i ka `String` i hāʻawi ʻia.
    ///
    /// Ma hope o ke kāhea ʻana iā `reserve_exact`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila, ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo `reserve` inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve(data.len())?;
    ///
    ///     // I kēia manawa maopopo iā mākou ʻaʻole hiki iā OOM i ka waena o kā mākou hana paʻakikī
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Kuhi i ka hiki o kēia `String` e kūlike i kona lōʻihi.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// E hōʻemi i ka hiki o kēia `String` me ka palena haʻahaʻa.
    ///
    /// E noho ka hiki ma ka liʻiliʻi e like me ka lōʻihi a me ka waiwai i hoʻolako ʻia.
    ///
    ///
    /// Inā ʻoi aku ka liʻiliʻi o kēia manawa ma mua o ka palena haʻahaʻa, he no-op kēia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Hoʻopili i ka [`char`] i hāʻawi ʻia i ka hopena o kēia `String`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Hoʻihoʻi i kahi ʻāpana byte o kēia 'String`.
    ///
    /// ʻO ka inverse o kēia hana ʻo [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Hoʻopōkole 'oe i keia `String` i ka hoakaka loa.
    ///
    /// Inā ʻoi aku ka nui o `new_len` ma mua o ka lōʻihi o ke aho, ʻaʻohe hopena o kēia.
    ///
    ///
    /// E hoʻomaopopo he hopena ʻole kēia hana ma ka mana i hoʻokaʻawale ʻia o ke aho
    ///
    /// # Panics
    ///
    /// Panics ina `new_len` 'aʻole e moe ma ka [`char`] palena.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Wehe i ka huapalapala hope loa mai ka buffer string a hoʻihoʻi iā ia.
    ///
    /// Hoʻi iā [`None`] inā hakahaka kēia `String`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Wehe i kahi [`char`] mai kēia `String` ma kahi kūlana byte a hoʻihoʻi iā ia.
    ///
    /// ʻO kēia kahi hana ʻo *O*(*n*), no ka mea koi ia i ke kope ʻana i kēlā me kēia meahana i loko o ka pale.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka nui o `idx` ma mua a i ʻole like paha me ka lōʻihi o `String`, a i ʻole moe ia ma ka palena [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Wehe i nā hoʻokūkū a pau o ke kumu `pat` ma ka `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// E ʻike a hoʻoneʻe ʻia nā hoʻokūkū, no laila i nā hihia kahi e hoʻopili ʻia ai nā lauana, ʻo ke kumu mua wale nō e hemo ʻia.
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: ka hoʻomaka a me ka hopena ma utf8 byte palena no
        // nā palapala Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Mālama wale i nā huapalapala i hōʻike ʻia e ka predicate.
    ///
    /// I nā huaʻōlelo ʻē aʻe, e hoʻoneʻe i nā huapalapala `c` āpau e hoʻihoʻi iā `f(c)` iā `false`.
    /// Ke hana nei kēia hana ma kahi, e kipa pololei ʻana i kēlā me kēia me kēia ma ke ʻano kumu, a mālama i ke kaʻina o nā mea i hoʻopaʻa ʻia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Pono paha ke kauoha kikoʻī no ka huli ʻana i ka moku kūwaho, e like me ka papa kuhikuhi.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Kuhi idx i ka char aʻe
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Hoʻokomo i kahi huapalapala i loko o kēia `String` ma kahi kūlana byte.
    ///
    /// ʻO kēia kahi hana ʻo *O*(*n*) no ka mea koi ia i ke kope ʻana i kēlā me kēia meahana i ka pale.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `idx` ʻoi aku ka nui ma mua o ka lōʻihi o ka 'String`, a i ʻole inā e moe ia ma ka palena [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Hoʻokomo i kahi ʻāpana kaula i loko o kēia `String` ma kahi kūlana byte.
    ///
    /// ʻO kēia kahi hana ʻo *O*(*n*) no ka mea koi ia i ke kope ʻana i kēlā me kēia meahana i ka pale.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `idx` ʻoi aku ka nui ma mua o ka lōʻihi o ka 'String`, a i ʻole inā e moe ia ma ka palena [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i nā ʻike o kēia `String`.
    ///
    /// # Safety
    ///
    /// Palekana ʻole kēia hana no ka mea ʻaʻole ia e kaha i nā byte i hāʻawi ʻia iā ia he UTF-8 kūpono.
    /// Inā hōʻeha ʻia kēia kaohi, hiki iā ia ke kumu i nā pilikia unsafety memo me nā mea hoʻohana future o ka `String`, ʻoiai ke koena o ka waihona waihona maʻamau e loaʻa ana nā "String`s UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Hoʻihoʻi i ka lōʻihi o kēia `String`, i nā bytes, ʻaʻole [`char`] s a i ʻole graphemes.
    /// I nā huaʻōlelo ʻē, ʻaʻole paha ia ka mea a ke kanaka e noʻonoʻo ai i ka lōʻihi o ke aho.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Hoʻihoʻi iā `true` inā lōʻihi ka lōʻihi o kēia `String`, a me `false` i kahi ʻē aʻe.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Māhele i ke aho i ʻelua ma ka papa kuhikuhi byte i hāʻawi ʻia.
    ///
    /// Hoʻihoʻi i kahi `String` hou i hoʻokaʻawale ʻia.
    /// `self` loaʻa nā bytes `[0, at)`, a me ka `String` i hoʻihoʻi i loaʻa nā bytes `[at, len)`.
    /// `at` pono ia ma ka palena o ka UTF-8 kuhi wahi.
    ///
    /// E hoʻomaopopo ʻaʻole e loli ka hiki o `self`.
    ///
    /// # Panics
    ///
    /// Panics inā ʻaʻohe `at` ma ka palena kuhi helu `UTF-8`, a i ʻole ma waho o ka helu code hope o ke aho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Hoʻokiʻoki i kēia `String`, e hemo nei i nā ʻike āpau.
    ///
    /// ʻOiai ke ʻano o kēia ka `String` he lōʻihi o ka ʻole, ʻaʻole ia e hoʻopā i kona hiki.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Hana i ka ninini iterator e lawe aku oe i ka ke koho 'ia huahelu i loko o ka `String`, a oukou e haawi i ka wehe `chars`.
    ///
    ///
    /// Note: Lawe ʻia ka pae o ke kumu inā ʻaʻole pau ka iterator a hiki i ka hopena.
    ///
    /// # Panics
    ///
    /// Panics inā ʻaʻole e moe ka pihi hoʻomaka a hopena paha ma ka palena [`char`], a inā ʻaʻole i waho o nā palena.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Wehe i ka pae a hiki i ka β mai ke aho
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Hoʻomaʻemaʻe kahi pae holoʻokoʻa i ke aho
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Palekana palekana
        //
        // ʻAʻohe o ka mana String o Drain nā pilikia palekana hoʻomanaʻo o ka mana vector.
        // Keʻikepili mea e akaka nāʻai.
        // No ka mea, o ka laulā wehe 'ia ka hana i loko o na kulu, ina ka Drain iterator ua pūnāwai, ka wehe' e e hiki mai ana.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Lawe i ʻelua mau hōʻaiʻe like.
        // ʻAʻole e kiʻi ʻia ka &mut String a hiki i ka pau ʻana o ka hana, ma Drop.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` a me `is_char_boundary` hana i nā kaha palena kūpono.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Wehe i ka laulā i kuhikuhi ʻia i ke aho, a hoʻololi iā ia me ke aho i hāʻawi ʻia.
    /// Ua haawi mai ke kaula, aole ia e pono i ka ia i ka like loa me ka laulā.
    ///
    /// # Panics
    ///
    /// Panics inā ʻaʻole e moe ka pihi hoʻomaka a hopena paha ma ka palena [`char`], a inā ʻaʻole i waho o nā palena.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // E kuapo i ka pae a hiki i ka β mai ke aho
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Palekana palekana
        //
        // ʻAʻole i loaʻa iā Change_range nā pilikia palekana hoʻomanaʻo o kahi vector Splice.
        // o ka mana vector.Mālama wale ʻia nā ʻikepili.

        // ʻARlelo Aʻo: Inlining o kēia loli e unsound (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ʻARlelo Aʻo: Inlining o kēia loli e unsound (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ʻO ka hoʻohana ʻana iā `range` e lilo hou ʻole (#81138) Manaʻo mākou i nā palena i hōʻike ʻia e `range` noho like, akā hiki ke loli kahi hoʻokō kūʻē ma waena o nā kāhea.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Hoʻohuli i kēia `String` i loko o kahi [`Box`]`<`[`str`] `>`.
    ///
    /// E hāʻule kēia i nā mana keu.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Hoʻihoʻi i kahi ʻāpana o nā byte [`u8`] i hoʻāʻo ʻia e hoʻohuli i `String`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte kūpono ʻole, ma kahi vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Hoʻihoʻi i nā byte i hoʻāʻo e hoʻohuli i `String`.
    ///
    /// Kūkulu pono ʻia kēia ala e hōʻalo ai i ka hoʻokaʻawale ʻana.
    /// E hoʻopau ia i ka hemahema, e neʻe ana i nā byte, no laila ʻaʻole pono e hana kope i nā bytes.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte kūpono ʻole, ma kahi vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Kiʻi i `Utf8Error` e kiʻi hou lāliʻi e pili ana i ka huli ana ole.
    ///
    /// ʻO ka ʻano [`Utf8Error`] i hāʻawi ʻia e [`std::str`] e hōʻike ana i kahi hemahema i hiki ke hoʻololi ʻia ke hoʻololi ʻana i kahi ʻāpana o [`u8`] i kahi [`&str`].
    /// I kēia manaʻo, hoʻohālikelike ʻia ia me `FromUtf8Error`.
    /// E nānā i kona palapala kuhikuhi no ka oi lāliʻi ma luna o ka hoʻohana 'ia.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// // kekahi mau byte kūpono ʻole, ma kahi vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // hewa ʻole ka byte mua ma aneʻi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // No ka mea ke kau nei mākou ma luna o nā 'String`s, hiki iā mākou ke pale i hoʻokahi mahele ma o ka loaʻa ʻana o ke aho mua mai ka iterator a hoʻopili iā ia i nā aho āpau.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // No ka mea ke hana maʻamau nei mākou ma luna o CoWs, hiki iā mākou (potentially) ke hōʻalo i hoʻokahi mahele ma o ka loaʻa ʻana o ka mea mua a hoʻopili ʻia iā ia i nā huahana aʻe.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Hāʻawi kahi ʻoluʻolu impl i nā impl no `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Hana i kahi `String` hakahaka.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Hoʻokomo i ka mea hoʻohana `+` no ka concatenating i ʻelua kaula.
///
/// Hoʻopau kēia i ka `String` ma ka ʻaoʻao hema a hoʻohana hou i kāna buffer (e ulu ana inā pono).
/// Hana ʻia kēia e hōʻalo i ka hoʻokaʻawale ʻana i `String` hou a kope i nā ʻike āpau i kēlā me kēia hana, kahi e alakaʻi ai i ka *O*(*n*^ 2) manawa holo ke kūkulu ʻana i kahi aho *n*-byte e ka concatenation pinepine.
///
///
/// ʻO ke aho ma ka ʻaoʻao ʻākau ua noi wale ʻia;kope ʻia kāna ʻike i ka `String` i hoʻihoʻi ʻia.
///
/// # Examples
///
/// Hoʻohui i nā ʻ String ʻelua i ka mea mua ma ka waiwai a hōʻaiʻē i ka lua.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` hoʻoneʻe ʻia a hiki ʻole ke hoʻohana hou ʻia ma aneʻi.
/// ```
///
/// Inā makemake ʻoe e hoʻomau i ka hoʻohana ʻana i ka `String` mua, hiki iā ʻoe ke kālani a hoʻopili ʻia i ka clone ma kahi.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` Aia nō ke paʻa ma aneʻi.
/// ```
///
/// Hiki ke hana i nā ʻāpana `&str` concatenating ma o ka hoʻohuli ʻana i ka mua i `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Hoʻohana i ka mea hoʻohana `+=` no ka hoʻopili ʻana i `String`.
///
/// Loaʻa kēia i ka hana e like me ka hana [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// ʻO kahi ʻano inoa no [`Infallible`].
///
/// Aia kēia inoa inoa no ka hoʻohālikelike i hope, a hoʻoliʻiliʻi hope ʻia.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait no ka hoʻololi 'ana i kekahi waiwai no ka `String`.
///
/// Hoʻokomo ʻia kēia trait no kekahi ʻano e hoʻokō ana i ka [`Display`] trait.
/// E like me, `ToString` ʻaʻole pono e hoʻokō pololei ʻia.
/// [`Display`] pono e hoʻokō ʻia ma kahi, a loaʻa iā ʻoe ka hoʻokō `ToString` no ka manuahi.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Hoʻololi i ka waiwai i hāʻawi ʻia i `String`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// I kēia hoʻokō, ka hana `to_string` panics inā hoʻihoʻi ka `Display` hoʻokō i kahi hemahema.
/// Kuhi kēia i kahi hoʻokō `Display` hewa ʻole ma muli o `fmt::Write for String` ʻaʻole i hoʻihoʻi i kahi hemahema iā ia iho.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // ʻO kahi kulekele maʻamau ʻaʻole e hoʻopili i nā hana maʻamau.
    // Eia naʻe, ʻo ka hemo ʻana iā `#[inline]` mai kēia hana ke kumu o ka hoʻihoʻi hou ʻole ʻia ʻana.
    // E ʻike iā <https://github.com/rust-lang/rust/pull/74852>, ʻo ka hoʻāʻo hope loa e hoʻāʻo e hemo iā ia.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Hoʻohuli i `&mut str` i `String`.
    ///
    /// Hoʻonohonoho ʻia ka hopena ma ka puʻu.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: huki huki i ka libstd, i kumu e hewa ai ma aneʻi
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Hoʻololi i ka pahu `str` i hāʻawi ʻia i kahi `String`.
    /// Hoʻomaopopo ʻia ka ʻona `str` kahi nona.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Hoʻololi i ka `String` i hāʻawi ʻia i kahi ʻāpana `str` pahu nona.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Hoʻololi i kahi ʻāpana kaula i kahi ʻano ʻaiʻē.
    /// ʻAʻole hana ʻia ka puʻu, ʻaʻole kope ʻia ke aho.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Hoʻohuli i kahi kaula i loko o kahi ʻano ponoʻī.
    /// ʻAʻole hana ʻia ka puʻu, ʻaʻole kope ʻia ke aho.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Hoʻohuli i kahi kuhikuhi String i kahi ʻano ʻaiʻē.
    /// ʻAʻole hana ʻia ka puʻu, ʻaʻole kope ʻia ke aho.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Hoʻololi i ka `String` i hāʻawi ʻia i vector `Vec` e paʻa ana i nā waiwai o ka ʻano `u8`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// ʻO kahi iterator hoʻokahe no `String`.
///
/// Hoʻokumu ʻia kēia estr e ka hana [`drain`] ma [`String`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// E hoʻohana ʻia ma ke ʻano he&'a mut String i ka mea hōʻino
    string: *mut String,
    /// Hoʻomaka kahi hapa e hemo
    start: usize,
    /// Hoʻopau o kahi ʻāpana e hemo
    end: usize,
    /// O kēia i koe huaheluʻana o ka holoi
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // E hoʻohana iā Vec::drain.
            // "Reaffirm" nā kaha nā palena e hōʻalo i ke kuhi panic i ka hoʻokomo hou ʻia.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Hoʻihoʻi i ke koena (sub) o kēia iterator ma ke ʻano he ʻāpana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: hōʻoluʻolu AsRef impls ma lalo ke hoʻokūpaʻa.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kūpono ʻole ke hoʻokūpaʻa iā `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>no Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> no Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}