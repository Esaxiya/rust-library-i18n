/// Hana i kahi [`Vec`] i loko o nā paio.
///
/// `vec!` ʻae ʻia e wehewehe ʻia ʻo `Vec`s me ka syntax like e like me nā ʻōlelo hoʻonohonoho.
/// ʻElua ʻano o kēia macro:
///
/// - Hana i kahi [`Vec`] i loko o kahi papa inoa o nā mea i hāʻawi ʻia:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Hana i kahi [`Vec`] mai kahi mea i hāʻawi ʻia a me ka nui:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// E hoʻomaopopo he ʻokoʻa ia o nā manaʻo huina e kākoʻo kēia syntax i nā mea āpau e hoʻokō i [`Clone`] a ʻaʻole pono ka helu o nā mea i kahi mau.
///
/// E hoʻohana kēia i `clone` e pālua i kahi manaʻo, no laila e makaʻala kekahi i ka hoʻohana ʻana i kēia me nā ʻano me ka hoʻokō ʻole `Clone` pono ʻole.
/// ʻO kahi laʻana, `vec![Rc::new(1);5] `e hana i vector o ʻelima mau kūmole i ka helu integer box i like, ʻaʻole ʻelima mau kūmole e kuhikuhi ana i nā integers pahu kūʻokoʻa.
///
///
/// Eia kekahi, e ʻae i ʻae ʻia `vec![expr; 0]`, a hana i kahi vector hakahaka.
/// E loiloi kēia iā `expr`, akā naʻe, a hāʻule koke ka hopena hopena, no laila e noʻonoʻo i nā hopena ʻaoʻao.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): me cfg(test) ke ʻano `[T]::into_vec` kūlohelohe, i koi ʻia no kēia wehewehe macro, ʻaʻole i loaʻa.
// E hoʻohana i ka hana `slice::into_vec` i loaʻa wale me cfg(test) NB e ʻike i ka module slice::hack ma slice.rs no ka ʻike hou aku.
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Hana i kahi `String` e hoʻohana ana i ka interpolation o nā manawa holo.
///
/// Loaʻa ka paio mua `format!` i kahi string format.Pono kēia e hana i kahi string literal.Aia ka mana o ke string formatting i loko o ka `{}` s i loaʻa.
///
/// Ua hāʻawi ʻia nā palena ʻē aʻe i `format!` e hoʻololi i nā "{} ʻi loko o ke kāʻei hoʻoliʻiliʻi i ke kaʻina i hāʻawi ʻia ke ʻole e hoʻohana ʻia nā inoa a i ʻole nā pae hoʻonohonoho hoʻonohonoho.ʻike iā [`std::fmt`] no ka ʻike hou aku.
///
///
/// ʻO ka hoʻohana maʻamau no `format!` ka concatenation a me ka interpolation o nā aho.
/// Hoʻohana ʻia ka ʻaha kūkā like me [`print!`] a me [`write!`] macros, kaukaʻi ʻia i ka hopena i manaʻo ʻia o ke aho.
///
/// E hoʻololi i hoʻokahi waiwai i ke aho, e hoʻohana i ke ʻano [`to_string`].E hoʻohana kēia i ka [`Display`] formatting trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics inā hōʻano kahi formatting trait i kahi hemahema.
/// Kuhi kēia i kahi hoʻokō pono ʻole ma muli o `fmt::Write for String` ʻaʻole i hoʻihoʻi ʻia i kahi hemahema.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// E hoʻokau i ka piko AST i kahi huaʻōlelo e hoʻomaikaʻi ai i nā diagnostics i ke kūlana kumu
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}