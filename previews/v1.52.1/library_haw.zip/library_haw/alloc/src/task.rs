#![stable(feature = "wake_trait", since = "1.51.0")]
//! Nā ʻano a me Traits no ka hana ʻana me nā hana asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ka hoʻokō ʻana o ke ala ʻana i kahi hana ma luna o ka mea hoʻokō.
///
/// Hiki ke hoʻohana ʻia kēia trait e hana i [`Waker`].
/// Hiki i ka mea hoʻokō ke wehewehe i ka hoʻokō ʻana o kēia trait, a hoʻohana i kēlā mea e kūkulu i kahi Waker e hāʻawi i nā hana i hoʻokō ʻia ma luna o kēlā luna hoʻokō.
///
/// Kēia trait He He iaiyoe-palekana a me ka ergonomic 'ano like i kūkulu i ka [`RawWaker`].
/// Kākoʻo ia i ka hoʻolālā luna maʻamau kahi i mālama ʻia ai ka ʻikepili e ala ai kahi hana i kahi [`Arc`].
/// ʻAʻole hiki i kekahi mau luna hoʻokō (keu hoʻi nā mea no nā ʻōnaehana i hoʻokomo ʻia) e hoʻohana i kēia API, ʻo ia ke kumu e kū nei ʻo [`RawWaker`] ma ke ʻano he koho no kēlā mau ʻōnaehana.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ʻO kahi hana `block_on` maʻamau e lawe iā future a holo iā ia a pau i ka pae o kēia manawa.
///
/// **Note:** Kūʻai kēia laʻana i ka pololei no ka maʻalahi.
/// I mea e pale aku ai i nā mea make, pono pono nā hoʻokō ʻana i ka papa hana e lawelawe i nā kāhea waena i `thread::unpark` a me nā noi nests.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// A waker e kāhea aku i ka mea he pae ka wā i kapaʻia.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Holo i kahi future e hoʻopau i ke pae o kēia manawa.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin i ka future i hiki ke koho ʻia.
///     let mut fut = Box::pin(fut);
///
///     // E hana i kekahi hou pōʻaiapili no e hele ai i ka future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Hoʻoholo i ka future i ka paʻaʻana.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// E hoʻāla i kēia hana.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// E hoʻāla i kēia hana me ka ʻai ʻole i ka mea ala.
    ///
    /// Inā kākoʻo kahi mea hoʻokō i kahi ala ʻoi aku ka maikaʻi e ala aʻe me ka ʻole e hoʻopau ʻana i ka waker, pono e hoʻokahuli i kēia hana.
    /// Ma ka paʻamau, kālani ʻia ka [`Arc`] a kāhea iā [`wake`] ma ka clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // Maluhia: kēia mea pakele no ka mea, raw_waker maluhia? Aiey iauaeoia
        // he RawWaker mai Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Hoʻohana ʻia kēia hana pilikino no ke kūkulu ʻana i kahi RawWaker ma mua o
// hoʻokomo i kēia i ka `From<Arc<W>> for RawWaker` impl, e hōʻoia i ka hilinaʻi ʻole o ka palekana o `From<Arc<W>> for Waker` i ka hoʻouna trait pololei, ma kahi o nā impls ʻelua e kāhea pololei i kēia hana.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // E hoʻonui i ka helu kuhikuhi o ka arc e kālona iā ia.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // E ala ma ka waiwai, neʻe i ka Arc i ka hana Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // E ala ʻoe ma ke kūmole, kāwili i ka mea ala ma ManallyDrop e pale i ka waiho ʻana iā ia
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // E hoʻemi i ka helu helu o ka Arc ma ke kulu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}