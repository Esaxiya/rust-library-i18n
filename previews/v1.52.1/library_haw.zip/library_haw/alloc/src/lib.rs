//! # ʻO ka Rust kumu nui a me ka waihona waihona hōʻiliʻili
//!
//! Hāʻawi kēia waihona i nā mea kuhikuhi akamai a me nā hōʻiliʻili no ka mālama ʻana i nā waiwai i hoʻokaʻawale ʻia.
//!
//! ʻO kēia hale waihona puke, e like me ka libcore, pono ʻole e hoʻohana pololei ʻia mai ka lawe hou ʻia ʻana o kāna ʻike i ka [`std` crate](../std/index.html).
//! Crates e hoʻohana nei i ka hiʻona `#![no_std]` akā ʻaʻole ia e hilinaʻi ʻia ma `std`, no laila e hoʻohana lākou i kēia crate ma kahi.
//!
//! ## Nā koina paʻa
//!
//! ʻO ka ʻano [`Box`] kahi ʻano pointer akamai.Hiki i hoʻokahi wale nō mea nona ka [`Box`], a hiki i ka mea nāna ke hoʻoholo e hoʻololi i nā ʻike, e noho ana ma ka puʻu.
//!
//! Hiki ke hoʻouna ʻia kēia ʻano i waena o nā pae me ka maikaʻi e like me ka nui o kahi `Box` waiwai e like me ka helu kuhikuhi.
//! Kūkulu pinepine ʻia nā hale ʻikepili e like me nā kumulāʻau me nā pahu no ka mea he hoʻokahi wale nō nona ka pākahi, ka makua.
//!
//! ## Kuhikuhi helu i kuhikuhi ʻia
//!
//! ʻO ka [`Rc`] kahi kikoʻī helu ʻole helu threadsafe i manaʻo ʻia no ka kaʻana like ʻana i ka hoʻomanaʻo i loko o kahi pae.
//! Hoʻopili kahi kuhi [`Rc`] i kahi ʻano, `T`, a ʻae wale i ke komo ʻana i `&T`, kahi kūmole i kaʻana like ʻia.
//!
//! He mea pono kēia ʻano ke hoʻoili ʻia ka hoʻoilina hoʻoilina (e like me ka hoʻohana ʻana i [`Box`]) ke kāohi nei no kahi noi, a ua hoʻopili pinepine ʻia me nā ʻano [`Cell`] a i ʻole [`RefCell`] i mea e ʻae ai i ka hoʻololi.
//!
//!
//! ## Atomically pili helu kuhikuhi
//!
//! ʻO ka [`Arc`] ʻano like ka threadsafe o ka [`Rc`] ʻano.Hāʻawi ia i nā hana like a pau o [`Rc`], koe wale no e koi i ka loaʻa ʻana o ka ʻano `T` i kaʻana like ʻia.
//! Hoʻohui ʻia, [`Arc<T>`][`Arc`] hiki iā ia ke hoʻouna ʻia ʻoiai ʻo [`Rc<T>`][`Rc`] ʻaʻole.
//!
//! ʻAe kēia ʻano no ke komo like ʻana i ka ʻikepili i hoʻopaʻa ʻia, a hoʻopili pinepine ʻia me nā primitives synchronization e like me nā mutexes e ʻae ai i ka hoʻololi ʻana o nā waiwai like.
//!
//! ## Collections
//!
//! Hoʻomaopopo ʻia nā hana o ka ʻike nui e pili ana i nā ʻike ʻike maʻamau i kēia waihona.Ka mea, i hou-hoʻolilo ma ka [standard collections library](../std/collections/index.html).
//!
//! ## Nā kuʻina puʻu
//!
//! Hoʻomaopopo ka module [`alloc`](alloc/index.html) i ka pae haʻahaʻa i ka mea hāʻawi honua paʻamau.ʻAʻole kūlike ia me ka libc mea hoʻokaʻawale API.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// ʻO ka ʻenehana, he lapalapa kēia ma rustdoc: ʻike ʻo rustdoc i nā palapala ma `#[lang = slice_alloc]` mau poloka no `&[T]`, a he palapala hoʻi e hoʻohana nei i kēia hiʻohiʻona i `core`, a huhū ʻo ia ʻaʻole i hiki i ka hiʻohiʻona hiʻohiʻona ke hoʻohana ʻia.
// Ma ke kūpono, ʻaʻole ia e nānā no ka puka hiʻohiʻona no nā docs mai crates ʻē aʻe, akā ʻoiai hiki ke hōʻike wale ʻia kēia no nā mea wale nō, ʻaʻole pono ia e hoʻoponopono.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ʻAe e hoʻāʻo i kēia waihona

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Module me nā macros kūloko i hoʻohana ʻia e nā modula ʻē aʻe (pono e hoʻopili ʻia ma mua o nā modula ʻē aʻe).
#[macro_use]
mod macros;

// Hāʻawi ʻia nā puʻu no nā hoʻolālā hoʻokaʻina pae haʻahaʻa

pub mod alloc;

// Nā ʻano primitive e hoʻohana ana i nā ahu ma luna

// Pono e ho'ākāka pono i ka mod mai `boxed.rs` e hōʻole i ka pālua ʻana i nā mea i ke kūkulu ʻana i ka hōʻike CFg;akā pono e ʻae i ka pāʻālua e loaʻa ai iā `use boxed::Box;` mau hoʻolaha.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}