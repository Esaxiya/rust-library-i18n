#![stable(feature = "rust1", since = "1.0.0")]

//! Ka pae-maluhia maopopo kahi-helu kuhikuhi.
//!
//! E nānā i ke [`Arc<T>`][Arc] nā moʻolelo no nā lāliʻi.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Ka palena palupalu ma ka nui o nā kūmole i hana ʻia i `Arc`.
///
/// ʻO ka hele ʻana ma luna o kēia palena e hoʻopau i kāu polokalamu (ʻoiai ʻaʻole pono) ma nā kūmole _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ʻAʻole kākoʻo ʻo ThreadSanitizer i nā pā hoʻomanaʻo.
// I mea e hōʻalo ai i nā hōʻike maikaʻi maikaʻi ʻole ma Arc/nāwaliwali ka hoʻohana ʻana i nā ukana ʻtoma no ka hoʻopili ʻana ma kahi.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ʻO kahi kuhikuhi kuhi helu-palekana helu.Kū ʻo 'Arc' no 'Atomically Reference Counted'.
///
/// Hāʻawi ka ʻano `Arc<T>` i ka ʻāpana like o kahi ʻano `T`, i hoʻokaʻawale ʻia i ka puʻu.Ke noi nei iā [`clone`][clone] ma `Arc` e hana i kahi hanana `Arc` hou, e kuhikuhi ana i ka hoʻokaʻawale like ma ka puʻu e like me ke kumu `Arc`, ʻoiai e hoʻonui ana i kahi helu kūmole.
/// Ke luku ʻia ka poʻomanaʻo `Arc` hope loa i kahi hoʻokaʻawale i hāʻawi ʻia, hāʻule pū ka waiwai i mālama ʻia i kēlā hoʻokaʻawale (i kapa pinepine ʻia ʻo "inner value").
///
/// Hōʻole nā kūmole i kaʻana ʻia ma Rust e ka paʻamau, a ʻaʻohe ʻokoʻa ʻo `Arc`: ʻaʻole hiki iā ʻoe ke kiʻi i kahi kūmole i kahi mea i loko o `Arc`.Inā pono ʻoe e hoʻololi ma o `Arc`, e hoʻohana i [`Mutex`][mutex], [`RwLock`][rwlock], a i ʻole kekahi o nā ʻano [`Atomic`][atomic].
///
/// ## Ka palekana o ka pae
///
/// ʻAʻole like me [`Rc<T>`], hoʻohana ʻo `Arc<T>` i nā hana atomic no kāna helu kūmole.Keia mea i ka mea, o ka pae-palekana.ʻO ka mea maikaʻi ʻole ʻoi aku ka pipiʻi o nā hana atika ma mua o ke kiʻi ʻana o ka hoʻomanaʻo maʻamau.Inā 'oe e ole kaʻana like i maopopo kahi-helu allocations ma waena o lopi, E noʻonoʻo i ka hoʻohana' ana [`Rc<T>`] no ka emi lolo.
/// [`Rc<T>`] he paʻamau palekana, no ka mea e hopu ka mea hoʻopili i nā hoʻāʻo e hoʻouna i [`Rc<T>`] ma waena o nā pae.
/// Eia nō naʻe, koho paha kahi waihona iā `Arc<T>` i mea e hāʻawi ai i nā mea kūʻai hale waihona i ka maʻalahi.
///
/// `Arc<T>` e hoʻokō iā [`Send`] a me [`Sync`] i ka lōʻihi o ka `T` e hoʻokō ai iā [`Send`] a me [`Sync`].
/// No ke aha e hiki ʻole ai iā ʻoe ke waiho i kahi ʻano palekana ʻole thread `T` i kahi `Arc<T>` e hana ai i ka wili-palekana?He counter-intuitive paha kēia i ka mua: ma hope o nā mea āpau, ʻaʻole anei ke kiko o ka `Arc<T>` wili palekana?ʻO ke kī kēia: hana ʻo `Arc<T>` i palekana i ka pae i loaʻa nona ka nui o ka ʻikepili like, akā ʻaʻole ia e hoʻohui i ka palekana o ka pae i kāna ʻikepili.
///
/// E noʻonoʻo iā `Arc <'[' RefCell<T>`]>>.
/// [`RefCell<T>`] ʻaʻole [`Sync`], a inā ʻo `Arc<T>` mau [`Send`], ʻ Arc <`[RefCell<T>`]>> e like pū kekahi.
/// Akā loaʻa iā mākou kahi pilikia:
/// [`RefCell<T>`] ʻaʻole palekana ke aho;mālama ʻo ia i ka helu o ka hōʻaiʻē me ka hoʻohana ʻana i nā hana ʻĀtoma.
///
/// Ma ka hopena, kēia mea i oe i pono, e mau `Arc<T>` me kekahi mauʻano o [`std::sync`] 'ano, IeAUPIIe, IAa IO [`Mutex<T>`][mutex].
///
/// ## Ka Pale Kauoha pōʻaiapuni me `Weak`
///
/// Hiki ke hoʻohana ʻia ka hana [`downgrade`][downgrade] e hana i kahi kuhikuhi ʻole [`Weak`] ʻona kuleana ʻole.A [`Weak`] laʻau kuhikuhi hiki e ['upgrade`][upgrade] b i ka `Arc`, akā, i kēia, e hoʻi [`None`] ina ka cia waiho i loko o ka auaaeaiea ua mua, ua haule iho la iluna.
/// I nā huaʻōlelo ʻē aʻe, ʻaʻole mālama nā pointers `Weak` i ka waiwai i loko o ka hoʻokaʻina ola ʻana;akā, mālama lākou * i ka hoʻokaʻawale (ka hale kūʻai hope no ka waiwai) ola.
///
/// ʻAʻole e hoʻokahuli ʻia kahi pōʻai ma waena o nā kuhi `Arc`.
/// No kēia kumu, hoʻohana ʻia ʻo [`Weak`] e haki i nā pōʻaiapuni.No ka laʻana, he laau hiki i ikaika `Arc` mea kuhikuhi mai makua aka wahi i na keiki, a me [`Weak`] mea kuhikuhi mai nā kamaliʻi hope i ko lakou mau makua.
///
/// # Nā kūmole kuhikuhi
///
/// Ke hana nei i kahi kuhikuhi hou mai kahi kuhikuhi kuhikuhi i helu ʻia e hana ʻia me ka hoʻohana ʻana i ka `Clone` trait i hoʻokō ʻia no [`Arc<T>`][Arc] a me [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Kūlike nā syntaxes ʻelua ma lalo.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // i kekahi, e, a me ka foo nō nā mea a pau Arcs ia wahi a hiki i ka ia iaiyoe wahi
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` koho kikoʻī iā `T` (ma o [`Deref`][deref] trait), no laila hiki iā ʻoe ke kāhea i nā kiʻina ʻo "T" ma kahi waiwai o ka type `Arc<T>`.I mea e hōʻalo ai i nā paio inoa me nā hana a `T`, pili nā hana o `Arc<T>` ponoʻī i nā hana, i kapa ʻia me [fully qualified syntax].
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// ʻO Arc<T>"ʻO nā hoʻokō ʻana o traits e like me `Clone` hiki ke kāhea ʻia me ka hoʻohana piha ʻana i ka syntax.
/// Makemake kekahi poʻe e hoʻohana i ka syntax palapala hōʻoia piha, ʻoiai makemake kekahi e hoʻohana i ka syntax kāhea-kahea.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax kāhea-kāhea
/// let arc2 = arc.clone();
/// // Syntax kūpono kūpono
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] hana ʻole auto-dereferensi iā `T`, no ka mea ua hāʻule paha ka waiwai o loko.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ke kaʻana like ʻana i kekahi ʻikepili i hoʻololi ʻole ʻia ma waena o nā pae:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// E hoʻomaopopo ʻaʻole mākou ** e holo i kēia mau hōʻike ma aneʻi.
// Loaʻa ka hauʻoli loa o nā mea hana windows inā ʻoi aku kahi pae i ka pae nui a laila puka i ka manawa like (kahi mea make make) no laila ke pale wale nei mākou i kēia ma ka holo ʻole ʻana i kēia mau hoʻokolohua.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ke hāʻawi nei i kahi [`AtomicUsize`] hiki ke hoʻololi:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// E ʻike i ka [`rc` documentation][rc_examples] no nā laʻana hou aʻe o ka helu helu ʻana ma ka laulā.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` kahi mana o [`Arc`] e paʻa ana i kahi kuhikuhi ʻona ʻole i ka hoʻokaʻawale hoʻokele.
/// ʻIke ʻia ka hoʻokaʻawale ʻana ma ke kāhea ʻana iā [`upgrade`] ma ka kuhikuhi `Weak`, e hoʻihoʻi nei i kahi [`ʻAno`]`<`[Arc`] ʻ<T>>.
///
/// Ma muli o ka helu ʻole ʻana o kahi kuhikuhi `Weak` i ka ona, ʻaʻole ia e pale i ka waiwai i mālama ʻia i ka hoʻokaʻawale ʻana mai ka hāʻule ʻana, a `Weak` pono ʻole e hōʻoia e pili ana i ka waiwai e noho nei.
///
/// Pēlā paha e hoʻihoʻi iā [`None`] ke [[hoʻomaikaʻi hou]] d.
/// 'Ōlelo Aʻo nae i ka `Weak` maopopo kahi *hana* pale aku i ka auaaeaiea ia iho (ka ke kākoʻoʻana kūʻai) mai ka deallocated.
///
/// Maikaʻi ka poʻomanaʻo `Weak` no ka mālama ʻana i kahi kuhikuhi manawa i ka hoʻokaʻawale i mālama ʻia e [`Arc`] me ka ʻole o ka pale ʻana i kāna waiwai o loko mai ka hāʻule ʻana.
/// Hoʻohana ʻia ia e pale i nā kuhikuhi pōʻai ma waena o nā kuhikuhi [`Arc`], ʻoiai ʻaʻole ʻae ʻia nā kūmole ʻelua e hoʻokau iā [`Arc`].
/// ʻO kahi laʻana, hiki i kahi kumulāʻau ke loaʻa nā kuhi [`Arc`] ikaika mai nā mākua i nā keiki, a me nā kuhikuhi `Weak` mai nā keiki i ko lākou mau mākua.
///
/// ʻO ke ala maʻamau e loaʻa ai kahi kuhikuhi `Weak` e kāhea iā [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // He `NonNull` kēia e ʻae i ka optimizing i ka nui o kēia ʻano i nā enums, akā ʻaʻole ia he kuhikuhi pono kūpono.
    //
    // `Weak::new` hoʻonohonoho i kēia i `usize::MAX` no laila ʻaʻole pono ia e hoʻokaʻawale i kahi ma ka puʻu.
    // ʻAʻole ia he waiwai e loaʻa i kahi kuhikuhi pono maoli no ka mea ua hoʻopili ʻo RcBox ma ka liʻiliʻi 2.
    // Hiki wale nō kēia ke `T: Sized`;ʻo `T` ʻole i kau ʻia.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ʻO repr(C) kēia iā future-hōʻoia e kūʻē i ka hoʻonohonoho hou ʻana o ka māla, kahi e hoʻopilikia ai i kahi [into|from]_raw() palekana o nā ʻano o loko transmutable.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // hana ka waiwai usize::MAX ma ke ʻano he sentinel no "locking" manawa pokole ka hiki ke hoʻonui i nā kuhikuhina nāwaliwali a hoʻoliʻiliʻi paha i nā mea ikaika;Hoʻohana ʻia kēia e hōʻalo i nā lāhui ma `make_mut` a me `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Kūkulu i kahi `Arc<T>` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Omaka i ka nawaliwali laʻau kuhikuhi helu like 1 a mea i ka nawaliwali laʻau kuhikuhi e Ka paa ana i na mea kuhikuhi ikaika (kinda), ike std/rc.rs no nāʻike'ē
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Iino? Ieea he hou `Arc<T>` hoʻohana i ka nawaliwali pili i kona wahi iho.
    /// Ke hoʻāʻo nei e hoʻomaikaʻi i ka kuhikuhina nāwaliwali ma mua o ka hoʻi ʻana o kēia hana e hopena i kahi waiwai `None`.
    /// Eia nō naʻe, e kālone manuahi ʻia ka nawaiwaliwali a mālama ʻia no ka hoʻohana ʻana ma kahi hope.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Kūkulu i ka loko i ka moku "uninitialized" me kahi kuhikuhi palupalu hoʻokahi.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // He mea nui ʻaʻole mākou e haʻalele i ka mea nona ka pointer nāwaliwali, a i ʻole e hoʻokuʻu ʻia ka hoʻomanaʻo i ka manawa a `data_fn` e hoʻi ai.
        // Inā mākou maoli makemake e hele kuleana, ua hiki ho okumu i ka hou nawaliwali laʻau kuhikuhi no ia makou iho, akā, i kēia makemake ka hopena i loko o nā IeAIIeXIAaIEE i ka nawaliwali i maopopo kahi helu a paha,ʻaʻole e pono ole.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ano, ua hiki pono initialize i ka lilo o ka waiwai a me ka huli mākou nāwaliwali olua i ka olua ikaika.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Kākau ka mea i luna i ka ʻikepili i nā pae i ʻike ʻia i ka helu ikaika ʻole ʻole.
            // No laila mākou e pono ai ma ka liʻiliʻi "Release" e kauoha ana i mea e hana pū ai me ka `compare_exchange_weak` ma `Weak::upgrade`.
            //
            // "Acquire" ʻaʻole koi ʻia ke kauoha ʻana.
            // Ke noʻonoʻo nei i nā ʻano kūpono o `data_fn` pono mākou e nānā i ka mea e hiki ke hana me kahi kuhikuhi i kahi `Weak` hōʻano hou ʻole ʻia.
            //
            // - Hiki iā ia ke *clone* ka `Weak`, e hoʻonui nei i ka helu kuhikuhi nāwaliwali.
            // - Hiki iā ia ke hoʻokuʻu i kēlā mau clone, e hoʻemi ana i ka helu kuhikuhi nāwaliwali (akā ʻaʻole loa i ka ʻole).
            //
            // ʻAʻole pili kēia mau hopena iā mākou i kekahi ʻano, a ʻaʻohe hopena ʻē aʻe i hiki ke loaʻa me ke code palekana wale nō.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Pono nā kūmole ikaika e ʻākoakoa pū i kahi kuhikuhina nāwaliwali, no laila mai holo i ka mea hōʻino no kā mākou kūwaliwali kahiko.
        //
        mem::forget(weak);
        strong
    }

    /// Kūkulu i kahi `Arc` hou me nā ʻike uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kūkulu i kahi `Arc` hou me nā ʻike uninitialized, me ka hoʻomanaʻo i piha i nā by by `0`.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kūkulu i kahi `Pin<Arc<T>>` hou.
    /// Inā ʻaʻole hoʻokomo ʻo `T` iā `Unpin`, a laila `data` e hoʻopili ʻia i ka hoʻomanaʻo a hiki ʻole ke hoʻoneʻe ʻia.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Kūkulu i kahi `Arc<T>` hou, hoʻihoʻi i kahi hemahema inā ʻaʻole holo ka hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Omaka i ka nawaliwali laʻau kuhikuhi helu like 1 a mea i ka nawaliwali laʻau kuhikuhi e Ka paa ana i na mea kuhikuhi ikaika (kinda), ike std/rc.rs no nāʻike'ē
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Kūkulu i kahi `Arc` hou me nā ʻike uninitialized, e hoʻihoʻi i kahi hemahema inā ʻaʻole i hoʻokaʻawale ka hoʻokaʻawale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Kūkulu i kahi `Arc` hou me nā ʻike uninitialized, me ka piha o ka hoʻomanaʻo me nā `0` bytes, e hoʻihoʻi nei i kahi hemahema inā ʻaʻole i hoʻokaʻawale ka hoʻokaʻawale.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Huli i ka pahale cia, ina ka `Arc` i pono i kekahi ikaika i maopopo nä haumäna.
    ///
    /// Inā ʻole, hoʻihoʻi ʻia kahi [`Err`] me ka `Arc` like i hala ʻia i loko.
    ///
    ///
    /// E kūleʻa kēia inā aia nā kūmole nāwaliwali koʻikoʻi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // E hana i kahi kuhikuhi nāwaliwali e hoʻomaʻemaʻe i ke kuhikuhi ikaika ikaika nāwaliwali
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Kūkulu i kahi ʻāpana atomika i helu hou ʻia me nā ʻike uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Kūkulu i kahi ʻāpana atomika helu-helu hou me nā ʻike uninitialized, me ka hoʻomanaʻo i piha me nā bytes `0`.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Hoʻololi i `Arc<T>`.
    ///
    /// # Safety
    ///
    /// E like me [`MaybeUninit::assume_init`], aia i ka mea kelepona e hōʻoia ai ka waiwai o loko i kahi kūlana mua.
    ///
    /// Ke kāhea ʻana i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i kumu ʻole ʻia ka hana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Hoʻololi i `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// E like me [`MaybeUninit::assume_init`], aia i ka mea kelepona e hōʻoia ai ka waiwai o loko i kahi kūlana mua.
    ///
    /// Ke kāhea ʻana i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i kumu ʻole ʻia ka hana.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Pau ka `Arc`, e hoʻihoʻi nei i ka kuhikuhi kuhikuhi.
    ///
    /// I mea e hōʻalo ai i kahi kulu hoʻomanaʻo e pono ke hoʻohuli i ka pointer i kahi `Arc` me ka hoʻohana ʻana iā [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Hāʻawi i kahi kuhikuhi maka i ka ʻikepili.
    ///
    /// ʻAʻole hoʻopili nā helu i kekahi ʻano a pau ʻole ka `Arc`.
    /// Kūpono ka pointer no ka mea aia nā helu ikaika i ka `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: ʻAʻole hiki i kēia ke hele ma o Deref::deref a i ʻole RcBoxPtr::inner no ka mea
        // koi ʻia kēia e mālama i ka raw/mut hōʻoia e like me kēlā
        // `get_mut` hiki iā ia ke kākau ma o ka pointer ma hope o ka loaʻa hou ʻana o ka Rc ma o `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Kūkulu i kahi `Arc<T>` mai kahi kuhikuhi maka.
    ///
    /// Ua hoʻihoʻi ʻia ke kuhikuhi maka maka e ke kāhea iā [`Arc<U>::into_raw`][into_raw] kahi e like ai ka nui a me ka hoʻopili ʻana o `U` me `T`.
    /// Heʻoiaʻiʻo maoli kēia inā `U` ka `T`.
    /// E hoʻomaopopo inā ʻaʻole ʻo `U` ka `T` akā like ka nui a me ke kaulike, like kēia me ka transmuting references o nā ʻano ʻokoʻa.
    /// E ʻike iā [`mem::transmute`][transmute] no ka ʻike hou aku e pili ana i nā mea e hoʻopili ai i kēia hihia.
    ///
    /// Pono ka mea hoʻohana o `from_raw` e hōʻoia i hoʻokahi wale nō waiwai o `T` i hāʻule wale ʻia.
    ///
    /// Palekana ʻole kēia hana ma muli o ka hoʻohana kūpono ʻole ʻana e alakaʻi ai i ka palekana ʻole, ʻoiai inā ʻaʻole i kiʻi ʻia ka `Arc<T>` i hoʻihoʻi ʻia.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Hoʻohuli i kahi `Arc` e pale ai i ka liu.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ʻO nā kāhea hou iā `Arc::from_raw(x_ptr)` e hoʻomanaʻo-palekana ʻole.
    /// }
    ///
    /// // Ua hoʻokuʻu ʻia ka hoʻomanaʻo i ka wā i hele aku ai ʻo `x` mai kahi ākea i luna, no laila ke kau nei ʻo `x_ptr` i kēia manawa.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // E hoʻohuli i ka offset e ʻike i ka ArcInner kumu.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Hoʻokumu i kahi kuhikuhi [`Weak`] hou i kēia hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Maikaʻi kēia hoʻomaha no ka mea ke nānā nei mākou i ka waiwai ma ka CAS ma lalo.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // e nānā inā ʻo "locked" ka mea nāwaliwali i kēia manawa;inā pēlā, wili.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: Kuhi kēia code i kēia manawa i ka hiki ke hālana
            // i loko o usize::MAX;ma ka laulā pono pono e hoʻoponopono i nā Rc a me Arc e hana me ka hoʻonui.
            //

            // ʻAʻole like me Clone(), pono mākou i kēia e loaʻa kahi heluhelu e hoʻopili pū me ka palapala e hele mai ana mai `is_unique`, i hiki ai nā hanana ma mua o kēlā kākau ma mua o kēia heluhelu.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // E hōʻoia ʻaʻole mākou e hana i kahi nawaliwali nāwaliwali
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Loaʻa i ka helu o [`Weak`] mea kuhikuhi i keia e auaaeaiea.
    ///
    /// # Safety
    ///
    /// Palekana kēia hana ma ona iho, akā pono ka mālama ʻana me ka hoʻohana pono.
    /// Hiki i kahi pae ʻē aʻe ke hoʻololi i ka helu nāwaliwali i kēlā me kēia manawa, me ke kūpono ma waena o ke kāhea ʻana i kēia hana a hana i ka hopena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Hoʻoholo kēia ʻōlelo no ka mea ʻaʻole mākou i kaʻana i ka `Arc` a i ʻole `Weak` ma waena o nā pae.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Inā laka ʻia ka helu nāwaliwali i kēia manawa, ʻo ka helu o ka helu ʻana he 0 ia ma mua o ka lawe ʻana i ka laka.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Loaʻa i ka helu o nā kuhikuhi (`Arc`) ikaika i kēia hoʻokaʻawale.
    ///
    /// # Safety
    ///
    /// Palekana kēia hana ma ona iho, akā pono ka mālama ʻana me ka hoʻohana pono.
    /// Hiki i kekahi pae ke hoʻololi i ka helu ikaika i kēlā me kēia manawa, e like me ka hiki ke kapa ʻia ma waena o ke kāhea ʻana i kēia hana a hana i ka hopena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ʻO kēia manaʻo he deterministic no ka mea ʻaʻole mākou i kaʻana i ka `Arc` ma waena o nā pae.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Hoʻonui i ka helu kuhikuhi ikaika ma ka `Arc<T>` e pili ana i ka kuhikuhi i hāʻawi ʻia e hoʻokahi.
    ///
    /// # Safety
    ///
    /// Ka laʻau kuhikuhi pono i ua loaa ma `Arc::into_raw`, a pono e lilo ka mea pili i `Arc` paha ('o ia hoʻi
    /// pono ka helu ikaika ma ka liʻiliʻi 1) no ka lōʻihi o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ʻO kēia manaʻo he deterministic no ka mea ʻaʻole mākou i kaʻana i ka `Arc` ma waena o nā pae.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Hoopaa i piʻo, akā, mai hoopa refcount ma ka hoʻi i wahīʻia i loko o ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // I kēia manawa e hoʻonui i ka refcount, akā mai haʻalele i kahi refcount hou kekahi
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Hoʻoholo i ka helu kuhikuhi ikaika ma ka `Arc<T>` e pili ana i ka kuhikuhi i hāʻawi ʻia e hoʻokahi.
    ///
    /// # Safety
    ///
    /// Ka laʻau kuhikuhi pono i ua loaa ma `Arc::into_raw`, a pono e lilo ka mea pili i `Arc` paha ('o ia hoʻi
    /// pono ka helu ikaika ma ka liʻiliʻi 1) ke noi nei i kēia hana.
    /// Hiki ke hoʻohana i kēia hana e hoʻokuʻu i ka `Arc` hope loa a me ke kākoʻo ʻana i ke kākoʻo ʻana, akā **ʻaʻole pono** e kāhea ʻia ma hope o ka hoʻokuʻu ʻia ʻana o ka `Arc` hope loa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Kēlā mau assertions i deterministic no ka mea,ʻaʻole mākou i pili ana i ka `Arc` ma waena o nā pae memo.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Kēia unsafety He OK no ka mea, oiai keia piʻo mea e ola ana, ua huli ua hoʻohiki i ka pahale laʻau kuhikuhi mea i pololei ia.
        // Eia kekahi, ʻike mākou i ka hanana `ArcInner` ponoʻī ʻo `Sync` no ka mea ʻo ka ʻikepili o loko ka `Sync` pū kekahi, no laila ke holo nei mākou i kahi kuhikuhi kūpono ʻole i kēia mau ʻike.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ole-inlined hapa o `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // E luku i ka ʻikepili i kēia manawa, ʻoiai ʻaʻole mākou e hoʻokuʻu i ka hoʻokaʻawale ʻana i ka pahu iā ia iho (aia paha he mau kuhi nāwaliwali e moe ana).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // E hoʻokuʻu i ka ref nāwaliwali i paʻa ʻia e nā kuhikuhi ikaika
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hoʻihoʻi iā `true` inā kuhikuhi nā ʻ Arc ʻelua i ka hoʻokaʻawale like (i kahi aa e like me [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Hoʻokaʻawale i kahi `ArcInner<T>` me ka lawa o ka hakahaka no kahi waiwai i loko ʻole i unsized i kahi o ka waiwai i hoʻonohonoho ʻia.
    ///
    /// Kāhea ʻia ka hana `mem_to_arcinner` me ka kuhikuhi kikoʻī a pono e hoʻihoʻi i kahi (momona momona)-pointer no ka `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // E helu i ka hoʻonohonoho ʻana me ka hoʻonohonoho waiwai i hāʻawi ʻia.
        // Ma mua, ua helu ʻia ka hoʻolālā ma ka huaʻōlelo `&*(ptr as* const ArcInner<T>)`, akā ua hana kēia i kahi kuhikuhi kuhi hewa (e nānā iā #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Hoʻokaʻawale i kahi `ArcInner<T>` me ka lawa o ka hakahaka no kahi waiwai o loko i unsized paha kahi o ka waiwai i hoʻonohonoho ʻia, e hoʻihoʻi i kahi hemahema inā ʻaʻole i hoʻokaʻawale ka hoʻokaʻawale.
    ///
    ///
    /// Kāhea ʻia ka hana `mem_to_arcinner` me ka kuhikuhi kikoʻī a pono e hoʻihoʻi i kahi (momona momona)-pointer no ka `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // E helu i ka hoʻonohonoho ʻana me ka hoʻonohonoho waiwai i hāʻawi ʻia.
        // Ma mua, ua helu ʻia ka hoʻolālā ma ka huaʻōlelo `&*(ptr as* const ArcInner<T>)`, akā ua hana kēia i kahi kuhikuhi kuhi hewa (e nānā iā #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Hoʻomaka i ka ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Allocates he `ArcInner<T>` me ka lawa kahua no ka unsized ma loko waiwai.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Hāʻawi i ka `ArcInner<T>` e hoʻohana ana i ka waiwai i hāʻawi ʻia.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kope waiwai i nā bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // E hoʻokuʻu i ka hoʻokaʻawale me ka waiho ʻole ʻana i kāna ʻike
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Hāʻawi i kahi `ArcInner<[T]>` me ka lōʻihi i hāʻawi ʻia.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// E kope i nā mea mai ka ʻāpana i loko o Arc <\[T\]> hou i hoʻokaʻawale ʻia
    ///
    /// Palekana ʻole no ka mea pono ka mea kāhea e lawe i ka ʻona a paʻa iā `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Kūkulu i kahi `Arc<[T]>` mai kahi iterator i ʻike ʻia i kahi nui.
    ///
    /// ʻAʻole maopopo ka lawena inā hewa ka nui.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Kiaʻi ʻo Panic ʻoiai ke klone ʻana i nā mea T.
        // Ma ka hanana o ke panic, hehee wale i ua ua kākau i loko o ka hou ArcInner e e haule iho, a laila, i ka hoomanao ana hookuuia oia.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer i ka mea mua
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Maopopo nā mea āpau.Poina i ke kiaʻi no laila ʻaʻole ia e hoʻokuʻu i ka ArcInner hou.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Hoʻohana trait i hoʻohana ʻia no `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Hana i ka clone o ka kuhikuhi `Arc`.
    ///
    /// Hoʻokumu kēia i kahi kuhikuhi ʻē aʻe i ka hoʻokaʻawale like, e hoʻonui ana i ka helu kūmole ikaika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Maikaʻi ka hoʻohana ʻana i kahi hoʻonohonoho hoʻonanea ma aneʻi, ʻoiai ka ʻike o ka ʻike kumu i pale i nā pae ʻē aʻe mai ka holoi hewa ʻana i ka mea.
        //
        // E like me ka wehewehe ʻana ma ka [Boost documentation][1], ʻo ka hoʻonui ʻana i ka helu kūmole hiki ke hana mau ʻia me memory_order_relaxed: Hiki ke hana ʻia nā kūmole hou i kahi mea mai kahi kūmole e kū nei, a me ka hala ʻana i kahi kūmole e kū nei mai kahi pae i kahi ʻē aʻe e pono e hāʻawi i kēlā me kēia koi.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Eia nō naʻe, pono mākou e kiaʻi i nā hoʻoiho nui inā loaʻa kekahi i kahi memo e hoʻopoina nei iā ʻArcs.
        // Inā ʻaʻole mākou e hana i kēia hiki i ka helu ke holo aʻe a hoʻohana nā mea hoʻohana ma hope o ka manuahi.
        // Mālama mākou i ka `isize::MAX` i ka manaʻo ʻaʻohe ~2 biliona wili e hoʻonui ana i ka helu kuhikuhi i ka manawa hoʻokahi.
        //
        // ʻAʻole e lawe ʻia kēia branch i kekahi papahana kūpono.
        //
        // Kūleʻa mākou no ka mea ʻo ia ʻano papahana he degenerate nui loa, a ʻaʻole mālama mākou e kākoʻo iā ia.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Hana i kahi kuhikuhi hiki ke hoʻololi i ka `Arc` i hāʻawi ʻia.
    ///
    /// Inā he `Arc` a [`Weak`] paha kuhi ʻē aʻe i ka hoʻokaʻawale like, a laila `make_mut` e hana i kahi hoʻokaʻawale hou a noi iā [`clone`][clone] ma ka waiwai o loko e hōʻoia i ka ʻona ʻokoʻa.
    /// Ua kapa ʻia kēia ma ke ʻano he clone-on-kākau.
    ///
    /// E hoʻomaopopo he ʻokoʻa kēia mai ka hana a [`Rc::make_mut`] e hoʻokaʻawale i nā kuhi `Weak` i koe.
    ///
    /// E ʻike pū iā [`get_mut`][get_mut], kahi e holomua ma mua o ka cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ʻAʻole e clone i kekahi mea
    /// let mut other_data = Arc::clone(&data); // ʻAʻole e clone i ka ʻikepili o loko
    /// *Arc::make_mut(&mut data) += 1;         // Clones loko ikepili
    /// *Arc::make_mut(&mut data) += 1;         // ʻAʻole e clone i kekahi mea
    /// *Arc::make_mut(&mut other_data) *= 2;   // ʻAʻole e clone i kekahi mea
    ///
    /// // I kēia manawa `data` a me `other_data` kuhikuhi i nā hoʻokaʻawale ʻokoʻa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Hoʻomaopopo e paʻa mākou i kahi kūmole ikaika a me kahi kuhikuhi nāwaliwali.
        // No laila, ke hoʻokuʻu nei i kā mākou kūmole ikaika wale nō, ʻaʻole iā ia iho, e hoʻolilo i ka hoʻomanaʻo.
        //
        // E ho ohana i loaʻa iā e hōʻoia 'ia mākou iʻike i kekahi E kakau iho i ka `weak` i hiki mai ma mua hoʻokuʻu kakau iho ai (' o ia hoʻi, decrements) i `strong`.
        // ʻOiai mākou e paʻa nei i kahi helu nāwaliwali, ʻaʻohe hiki i ka ArcInner iho ke hoʻokuʻu ʻia.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Aia kekahi māka kuhikuhi ikaika, no laila pono mākou e clone.
            // E hoʻokaʻawale mua i ka hoʻomanaʻo e ʻae i ke kākau pololei ʻana i ka waiwai cloned.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ua lawa ka maha i ka mea i luna aʻe no ka mea he optimization kēia i ke kumu: ke heihei mau nei mākou me nā kuhi nāwaliwali e hoʻokau ʻia ana.
            // ʻO ka hihia ʻoi loa, ua hāʻawi mākou i kahi Arc hou me ka ʻole.
            //

            // Ua wehe mākou i ka ref ikaika hope loa, akā aia kekahi mau ref nāwaliwali i koe.
            // E neʻe mākou i nā ʻike i kahi Arc hou, a hoʻopau ʻole i nā ref nāwaliwali ʻē aʻe.
            //

            // Note i ia mea i hiki ai ke heluhelu iho o `weak`, e hua mai usize::MAX ('o ia hoʻi, laka' ia), mahope mai o ka nawaliwali helu hiki wale ke laka 'ia ma ka pae me ka maopopo kahi ikaika.
            //
            //

            // Hana i kā mākou iho kuhikuhi ponowaliwali implicit, i hiki iā ia ke hoʻomaʻemaʻe i ka ArcInner e pono ai.
            //
            let _weak = Weak { ptr: this.ptr };

            // Hiki wale ʻaihue i ka ʻikepili, nā Weaks wale nō i koe
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ʻO mākou wale nō ke kuhikuhi o kēlā me kēia ʻano;kuʻi hou i ka helu ref ikaika.
            //
            this.inner().strong.store(1, Release);
        }

        // E like me `get_mut()`, maikaʻi ʻole ka unsafety no ka mea he kū hoʻokahi kā mākou kuhikuhi e hoʻomaka ai, a i lilo i hoʻokahi ma ke kala ʻana i ka ʻike ma loko.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// E hoʻihoʻi i kahi kuhikuhi i hiki ke hoʻololi ʻia i ka `Arc` i hāʻawi ʻia, inā ʻaʻohe `Arc` a i ʻole [`Weak`] kuhi ʻē aʻe i ka hoʻokaʻawale like.
    ///
    ///
    /// Hoʻi iā [`None`] i kahi ʻē aʻe, no ka mea, ʻaʻole palekana ia e hoʻololi i kahi waiwai like.
    ///
    /// E nānā i [`make_mut`][make_mut], a e [`clone`][clone] i ka pahale cia ka wā ma laila i nā mea kuhikuhi.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ua maikaʻi kēia unsafety no ka mea ua hoʻohiki mākou i ka kuhikuhi ʻana ʻo ia ka *kuhikuhi* wale nō e hoʻihoʻi ʻia iā T.
            // Mākou pili helu ua ua hoʻohiki ia e 1 ma keia wahi, a me ke koi 'ia i ka piʻo iho ia ia `mut`, no laila mākou e huli hoi mai i ka hiki wale pili ana i ka pā ikepili.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka `Arc` i hāʻawi ʻia, me ka ʻole o kahi kaha.
    ///
    /// E ʻike pū iā [`get_mut`], kahi palekana a hana i nā kaha kūpono.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Kekahi 'ē aʻe `Arc` a [`Weak`] mea kuhikuhi i ka ia e auaaeaiea pono ole e dereferenced no ka lōʻihi o ka hoʻi kēia.
    ///
    /// He trivally kēia hihia inā ʻaʻohe mea kuhikuhi e like me, ma hope koke o `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mālama mākou i ka *ʻaʻole* e hana i kahi kūmole e uhi ana i nā kahua "count", no ka mea he inoa ʻē kēia me ke komo pū ʻana i nā helu kūmole (eg
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// E hoʻoholo inā ʻo kēia kahi kuhikuhi kū hoʻokahi (me nā refs nāwaliwali) i ka ʻikepili ma lalo.
    ///
    ///
    /// E hoʻomaopopo he koi kēia i ka laka ʻana i ka helu ref nāwaliwali.
    fn is_unique(&mut self) -> bool {
        // laka i ka helu kuhikuhi nāwaliwali inā ʻike mākou ʻo mākou wale nō ka mea kuhikuhi nāwaliwali.
        //
        // Mālama ka lepili loaʻa i kahi pilina ma mua o ka pilina me nā mea i kākau iā `strong` (ma `Weak::upgrade`) ma mua o nā decrement o ka helu `weak` (ma o `Weak::drop`, e hoʻohana nei i ka hoʻokuʻu).
        // Inā ʻaʻole i hoʻokuʻu ʻia ka ref nawaliwali hou loa, e pau ʻole ka CAS ma ʻaneʻi no laila ʻaʻole mākou e noʻonoʻo e hoʻopili.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Pono kēia e lilo i `Acquire` e hoʻopili pū me ka hoʻohaʻahaʻa ʻana o ka counter `strong` ma `drop`-ke kiʻi wale nō e hiki ke hana ʻia ke hāʻule ʻia ke kuhikuhi hope loa.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Hoʻopau ka palapala hoʻokuʻu ma aneʻi me ka heluhelu ʻana ma `downgrade`, e pale pono ana i ka heluhelu ma luna o `strong` mai ka hana ʻana ma hope o ka kākau.
            //
            //
            self.inner().weak.store(1, Release); // hoʻokuʻu i ka laka
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Pākuʻi i ka `Arc`.
    ///
    /// E hoʻemi ana kēia i ka helu kuhikuhi ikaika.
    /// Inā piʻi ka helu kuhikuhi ikaika i ka ʻole a laila ʻo nā kuhikuhi ʻē aʻe wale nō (inā kekahi) he [`Weak`], no laila mākou `drop` i ka waiwai o loko.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ʻAʻole paʻi i kekahi mea
    /// drop(foo2);   // Nā paʻi "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ma muli o ka atomic o `fetch_sub`, ʻaʻole pono mākou e hoʻopili me nā pae ʻē aʻe ke ʻole mākou e kāpae i kēia mea.
        // Pili kēia kūlike i ka `fetch_sub` ma lalo a i ka helu `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Pono kēia pā i mea e pale aku ai i ka hoʻohana hou ʻana o ka ʻikepili a hoʻopau ʻia o ka ʻikepili.
        // Ma muli o ka māka `Release`, ʻo ka emi ʻana o ka helu helu e hoʻopili pū ʻia me kēia pā `Acquire`.
        // ʻO kēia ka hana o ka ʻikepili ma mua o ka hōʻemi ʻana i ka helu kuhikuhi, e hana ʻia ma mua o kēia pā, i hana ʻia ma mua o ka holoi ʻana o ka ʻikepili.
        //
        // E like me ia i wehewehe ʻia ma ka [Boost documentation][1],
        //
        // > He mea nui e hoʻokūpaʻa i kahi hiki ke komo i ka mea i hoʻokahi
        // > ka pae (ma kekahi olua) e *hiki mai mua* ka hiʻona
        // > ka mea i ka pae ʻokoʻa.Kēia Ua loaʻaʻia kekahi "release"
        // > hana ma hope o ka waiho ʻana i kahi kūmole (hiki i kahi mea
        // > ma o kēia kūmole e maopopo leʻa i hana ʻia ma mua), a me an
        // > "acquire" ana ma mua ka hiʻona o ka mea.
        //
        // ʻO ka mea kikoʻī, ʻoiai ʻaʻole hiki ke hoʻololi i nā ʻike o ka Arc, hiki ke kākau i loko i kahi mea e like me ka Mutex<T>.
        // Ma muli o ka loaʻa ʻole o kahi Mutex ke holoi ʻia, ʻaʻole hiki iā mākou ke kaukaʻi i kāna loiloi synchronization e hana i nā kākau i ka pae A ʻike ʻia i kahi mea luku e holo ana i ka pae B.
        //
        //
        // E hoʻomaopopo hoʻi e hiki ke pani ʻia ka pā Loaʻa iā ʻoe me kahi ukana Loaʻa, i hiki ai ke hoʻomaikaʻi i ka hana i nā kūlana hakakā nui.E nānā iā [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Hoao e hoʻoliʻiliʻi i ka `Arc<dyn Any + Send + Sync>` i kahi ʻano paʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Kūkulu i kahi `Weak<T>` hou, me ka hoʻokaʻawale ʻole i kahi hoʻomanaʻo.
    /// Ke kāhea nei iā [`upgrade`] ma ke kumu kūʻai hoʻihoʻi hāʻawi mau iā [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ʻAno kōkua e ʻae i ke kiʻi ʻana i nā helu kūmole me ka ʻole o kekahi manaʻo e pili ana i ka ʻikepili.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Hoʻihoʻi i kahi kuhikuhi maka i ka mea `T` i kuhikuhi ʻia e kēia `Weak<T>`.
    ///
    /// Ke laʻau kuhikuhi mea i pololei ia wale nō inā loaʻa nō kekahi mau kūmole ikaika.
    /// Ke kau nei paha ka pointer, kaulike ʻole ʻia a i ʻole [`null`] ʻole.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Kuhi nā mea ʻelua i ka mea like
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Mālama ka mea ikaika ma aneʻi i mea e ola ai, no laila hiki iā mākou ke komo i kēia mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Akā ʻaʻole hou.
    /// // Hiki iā mākou ke hana weak.as_ptr(), akā ke kiʻi nei i ka pointer e alakaʻi i ka lawena i hoʻoholo ʻole ʻia.
    /// // assert_eq! ("hello", palekana ʻole {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Inā ke kau nei ke kuhikuhi, hoʻi pololei mākou i ka mea kiaʻi.
            // ʻAʻole hiki i kēia ke lilo i kahi helu uku kūpono, ʻoiai ka liʻiliʻi o ka uku e like me ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: inā hoʻihoʻi ʻo_dangling i ka wahaheʻe, a laila hoʻopau ʻia ke kuhikuhi.
            // Hiki ke hoʻokuʻu ʻia ka ukana ma kēia wahi, a pono mākou e mālama i ka hōʻoia, no laila e hoʻohana i ka manipula kuhikuhi maka.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Pau ka `Weak<T>` a hoʻolilo ia i mea kuhikuhi maka.
    ///
    /// Hoʻololi kēia i ka pointer nāwaliwali i kahi kuhikuhi maka, ʻoiai e mālama nei i ka ʻona o kahi kuhikuhi nāwaliwali (ʻaʻole hoʻololi ʻia ka helu nāwaliwali e kēia hana).
    /// Hiki iā ia ke hoʻihoʻi i ka `Weak<T>` me [`from_raw`].
    ///
    /// Na ia mau kapu o ka loaʻa'an i ka pale o ka laʻau kuhikuhi like me [`as_ptr`] pili.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Hoʻololi i kahi kuhikuhi maka ma mua i hana ʻia e [`into_raw`] i `Weak<T>`.
    ///
    /// Hiki ke hoʻohana ʻia kēia e kiʻi palekana i kahi kūmole ikaika (ma ke kāhea ʻana iā [`upgrade`] ma hope) a i ʻole ke kuʻikahi i ka helu nāwaliwali ma ka waiho ʻana i ka `Weak<T>`.
    ///
    /// Mālama ʻia kahi ʻāpana palupalu (me ka ʻokoʻa o nā kuhikuhi i haku ʻia e [`new`], ʻoiai ʻaʻohe o lākou mau mea kēia; ke hana mau nei ke ʻano ma luna o lākou).
    ///
    /// # Safety
    ///
    /// Pono ka pointer e hoʻomaka mai ka [`into_raw`] a pono nō i kāna kahawai nāwaliwali.
    ///
    /// ʻAe ʻia no ka helu ikaika e 0 i ka manawa e kāhea ana i kēia.
    /// Eia nō naʻe, lilo kēia i kuleana i hoʻokahi kuhikuhi nāwaliwali e kū nei i kēia manawa ma ke ʻano he kuhikuhi maka (ʻaʻole hoʻololi ʻia ka helu nāwaliwali e kēia hana) a no laila pono e hoʻopili ʻia me kahi kāhea mua iā [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hoʻolaha i ka helu nāwaliwali hope loa.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // E ʻike iā Weak::as_ptr no ka pōʻaiapili pehea e loaʻa ai ka kuhikuhi kuhikuhi.

        let ptr = if is_dangling(ptr as *mut T) {
            // He Wīwī kau kēia.
            ptr as *mut ArcInner<T>
        } else {
            // Inā ʻole, ua hoʻohiki ʻia mākou no ka nāwaliwali kahi kuhikuhi.
            // SAFETY: palekana ka data_offset e kāhea aku ai, no ka mea, he ptr kūmole he maoli (hāʻule paha) ʻo T.
            let offset = unsafe { data_offset(ptr) };
            // No laila, huli mākou i ka offset e kiʻi i ka RcBox holoʻokoʻa.
            // SAFETY: mai kahi nāwaliwali ka pointer, no laila palekana kēia offset.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: ua loaʻa hou iā mākou ka pointer Weak maoli, no laila hiki ke hana i ka Nāwaliwali.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// ʻO nā hoʻāʻo e hoʻomaikaʻi i ka kuhikuhi `Weak` i kahi [`Arc`], e hoʻolohi ana i ka waiho ʻana o ka waiwai o loko inā kūleʻa.
    ///
    ///
    /// Hoʻi iā [`None`] inā ua haʻalele ʻia ka waiwai o loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Luku i nā kuhi ikaika a pau.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Hoʻohana mākou i kahi loop CAS e hoʻonui i ka helu ikaika ma kahi o kahi fetch_add ʻoiai ʻaʻole pono kēia hana e lawe i ka helu kuhikuhi mai ka ʻole a i ka hoʻokahi.
        //
        //
        let inner = self.inner()?;

        // ʻO ka ukana hoʻomaha no ka mea e kākau kekahi o 0 i hiki iā mākou ke nānā ke waiho i ka māla i kahi kūlana zero mau (no laila he "stale" heluhelu o 0 maikaʻi), a hōʻoia ʻia kekahi waiwai ʻē aʻe ma o ka CAS ma lalo.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // E ʻike i nā manaʻo ma `Arc::clone` no ke aha mākou e hana ai i kēia (no `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Maikaʻi ka hoʻomaha no ka hihia holomua no ka mea ʻaʻohe o mākou mea e manaʻo ai e pili ana i ka mokuʻāina hou.
            // Lilo iā ia mea e pono ai no ka pomaikai hihia e synchronize me `Arc::new_cyclic`, ka wā o ka pahale cia hiki ke initialized `Weak` kūmole i mua, ua hanaia ma hope.
            // I kēlā hihia, manaʻo mākou e nānā i ka waiwai i hoʻokumu mua ʻia.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null nānā ʻia ma luna
                Err(old) => n = old,
            }
        }
    }

    /// Loaʻa i ka helu o nā kuhi (`Arc`) ikaika e kuhikuhi ana i kēia hoʻokaʻawale.
    ///
    /// Inā `self` i hana ʻia me [`Weak::new`], e hoʻihoʻi kēia iā 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Loaʻa i kahi kokoke i ka helu o nā kuhikuhi `Weak` e kuhikuhi ana i kēia hoʻokaʻawale.
    ///
    /// Inā `self` i hana ʻia me ka hoʻohana ʻana iā [`Weak::new`], a i ʻole he koʻo ikaika i koe, e hoʻihoʻi kēia iā 0.
    ///
    /// # Accuracy
    ///
    /// Ma muli o nā kikoʻī hoʻokō, hiki ke hōʻemi ʻia ka waiwai i hoʻihoʻi ʻia e 1 i kēlā a me kēia ʻaoʻao ke hana ʻē ʻia nā pae ʻē aʻe i kekahi mau 'Arc`a i ʻole nā' Weak`s e kuhikuhi ana i ka hoʻokaʻawale like.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ma muli o ko mākou ʻike aia ma ka liʻiliʻi he hoʻokahi kuhikuhi ikaika ma hope o ka heluhelu ʻana i ka helu nāwaliwali, ʻike mākou ʻo ke kūmole palupalu implicit (i kēia manawa ke ola nei nā kūmole ikaika) aia a puni ke nānā mākou i ka helu nāwaliwali, a no laila hiki iā mākou ke unuhi maikaʻi.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Hoʻi iā `None` ke kau nei ka kuhikuhi a ʻaʻohe hāʻawi ʻia `ArcInner`, (ʻo ia hoʻi, i ka manawa i hoʻokumu ʻia ai kēia `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mālama mākou i ka *ʻaʻole* e hana i kahi kūmole e uhi ana i ka kahua "data", no ka mea hiki ke hoʻololi ʻia ke kahua i ka manawa like (e laʻa me ka hoʻohālikelike ʻana o ka `Arc` hope loa, e hāʻule ka ʻikepili ma kahi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Hoʻi iā `true` inā kuhikuhi nā ʻelua Weak i ka hoʻokaʻawale like (e like me [`ptr::eq`]), a i ʻole kuhikuhi ʻole nā mea ʻelua i kekahi hoʻokaʻawale (no ka mea ua hana ʻia me `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// ʻOiai hoʻohālikelike kēia i nā kuhi kuhi ʻo ia ka `Weak::new()` e kaulike kekahi me kekahi, ʻoiai ʻaʻole lākou e kuhikuhi i kekahi hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ke hoʻohālikelike nei iā `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Hana i ka clone o ka poʻomanaʻo `Weak` e kuhikuhi i ka hoʻokaʻawale like.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // E ʻike i nā manaʻo ma Arc::clone() no ke aha e hoʻomaha ai kēia.
        // Hiki i kēia ke hoʻohana i fetch_add (nānā ʻole i ka laka) no ka mea ua laka wale ʻia ka helu nāwaliwali ma hea kahi * ʻaʻohe ʻē ʻē nāwahiwahi ʻē aʻe i ke ola.
        //
        // (No laila ʻaʻole hiki iā mākou ke holo i kēia code i kēlā hihia).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // E nānā i pākuʻi ma Arc::clone() no ke kumu mākou hana i kēia (no ka mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Kūkulu i kahi `Weak<T>` hou, me ka hoʻokaʻawale ʻole i ka hoʻomanaʻo.
    /// Ke kāhea nei iā [`upgrade`] ma ke kumu kūʻai hoʻihoʻi hāʻawi mau iā [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Kulu ka kuhikuhi `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ʻAʻole paʻi i kekahi mea
    /// drop(foo);        // Nā paʻi "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Inā ua loaʻa mai ai aole o makou i ka hope nawaliwali laʻau kuhikuhi, a laila, kona manawa e deallocate i nā ikepili loa.E ʻike i ke kūkā kamaʻilio ma Arc::drop() e pili ana i nā hoʻonohonoho hoʻomanaʻo
        //
        // OʻAʻole e pono, e nānā i ka mea paʻa moku'āina 'aneʻi, no ka mea, hiki wale nō e laka i ka nawaliwali helu ina ua kaʻoi loa kekahi nawaliwali listen, me ka manao ua kulu ke wale a laila holo ON e noho nawaliwali listen, a hiki wale hiki mai ma hope o ka laka ua hookuu.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ke hana nei mākou i kēia loea ma aneʻi, ʻaʻole ma ke ʻano he optimization ʻoi aku ka nui ma `&T`, no ka mea e hoʻohui i kahi kumukūʻai i nā hōʻoia kaulike āpau ma nā ref.
/// Manaʻo mākou e hoʻohana ʻia ʻo Arcs e mālama i nā waiwai nui, lohi i ka clone, akā kaumaha hoʻi e nānā no ke kaulike, e uku maʻalahi ana kēia kumukūʻai.
///
/// Loaʻa paha iā ia nā klona `Arc` ʻelua, e kuhikuhi ana i ka waiwai like, ma mua o ʻ ʻelua&&T.
///
/// Hiki iā mākou ke hana i kēia inā `T: Eq` ma ke ʻano he `PartialEq` i hana maʻalahi ʻole ʻia.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Kaulike no ʻelua Arc.
    ///
    /// Kūlike ʻelua ʻ Arc`s inā kūlike kā lākou waiwai o loko, ʻoiai inā mālama ʻia lākou i nā hoʻokaʻawale ʻokoʻa.
    ///
    /// Inā hoʻokomo ʻo `T` iā `Eq` (e hōʻike nei i ka reflexivity o ke kaulike), ʻelua mau Arc e kuhikuhi ana i ka hoʻokaʻawale like like mau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Kūlike ʻole no ʻ Arc ʻelua.
    ///
    /// Mau `Arc`s i kaiʻewaʻewa ina ko lakou mau lilo o ka Hawaiʻi i kaiʻewaʻewa.
    ///
    /// Inā hoʻokomo ʻo `T` iā `Eq` (e hōʻike nei i ka reflexivity o ke kaulike), ʻelua mau Arc e kuhikuhi ana i ka waiwai like ʻaʻole i kaulike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Hoʻohālikelike hapa no nā ʻ Arc ʻelua.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `partial_cmp()` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Hoʻemi iki ʻia ma mua o ka hoʻohālikelike no ʻelua Arc.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `<` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Emi ma lalo a i ʻole kaulike' hoʻohālikelike no ʻelua Arc.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `<=` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Hoʻohālikelike ʻoi aku ka nui no ʻelua Arc.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `>` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Oi aku a i ʻole kaulike' hoʻohālikelike no ʻelua Arc.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `>=` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Hoʻohālikelike no ʻelua Arc.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `cmp()` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// I ka mea hou `Arc<T>`, a me ka `Default` waiwai no `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// E hoʻokaʻawale i kahi ʻāpana i helu ʻia a hoʻopiha iā ia e ke klona ʻana i nā mea a 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// E hoʻokaʻawale i kahi `str` i helu ʻia a helu kope iā `v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// E hoʻokaʻawale i kahi `str` i helu ʻia a helu kope iā `v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Hoʻoneʻe i ka 'ikepili mea i ka hou, i maopopo kahi-helu e auaaeaiea.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// E hoʻokaʻawale i kahi ʻāpana i helu ʻia a kuhikuhi i nā ʻāpana o 'v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // E ʻae i ka Vec e hoʻokuʻu i kāna hoʻomanaʻo, akā ʻaʻole e luku i kāna mau ʻike
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Lawe i kēlā me kēia meahana i ka `Iterator` a hōʻiliʻili iā ia i `Arc<[T]>`.
    ///
    /// # Nā ʻano hana
    ///
    /// ## ʻO ka hihia laulā
    ///
    /// Ma ka kekahi mau hihia, o kaʻohiʻana i loko o `Arc<[T]>` ua hana ma mua o kaʻohiʻana i loko o ka `Vec<T>`.ʻO ia, ke kākau nei i kēia:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// hana kēia me he mea lā ua kākau mākou:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ka mua kau o allocations ka hana i 'aneʻi.
    ///     .into(); // Loaʻa kahi ʻāpana ʻelua no `Arc<[T]>` ma aneʻi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// E hoʻokaʻawale kēia i nā manawa i makemake ʻia no ke kūkulu ʻana i ka `Vec<T>` a laila e hoʻokaʻawale ʻia hoʻokahi no ka hoʻolilo ʻana i ka `Vec<T>` i ka `Arc<[T]>`.
    ///
    ///
    /// ## ʻO Iterators o ka lōʻihi i ʻike ʻia
    ///
    /// Ke hoʻokō nei kāu `Iterator` iā `TrustedLen` a he kikoʻī kona nui, e hāʻawi ʻia kahi hoʻokaʻawale hoʻokahi no ka `Arc<[T]>`.O kahi laʻana:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hoʻokahi wale nō hoʻokaʻawale e hana ʻia ma aneʻi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Hoʻohana trait i hoʻohana ʻia no ka hōʻiliʻili ʻana i `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ʻO kēia ka hihia no ka `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Pono mākou e hōʻoia i ka lōʻihi o ka iterator a loaʻa iā mākou.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // E hoʻi i ka hoʻokō maʻamau.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// E kiʻi i ka offset ma waena o `ArcInner` no ka ukana ma hope o kahi kuhikuhi.
///
/// # Safety
///
/// Pono ke kuhikuhi i (a loaʻa i nā metadata kūpono no) kahi hanana T i kūpono ma mua, akā ʻae ʻia e haʻalele iā T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // E hoʻopili i ka waiwai i hoʻopaʻa ʻia i ka hopena o ArcInner.
    // Ma muli o RcBox ʻo repr(C), ʻo ia nō ka māla hope loa i ka hoʻomanaʻo.
    // SAFETY: ʻoiai ʻo nā ʻano unsized wale nō i hiki ke ʻoki, trait mau mea,
    // a me nā ʻano kūwaho, ua lawa ka pono palekana hoʻokomo i kēia manawa e māʻona i nā koina o align_of_val_raw;ʻO kēia kahi kikoʻī hoʻokō o ka ʻōlelo i hiki ʻole ke hilinaʻi ʻia ma waho o std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}