//! Hoʻokomo ʻia kahi lālani makakoho me kahi puʻu binary.
//!
//! Hoʻokomo a popping ka mea nui i loaʻa ka paʻakikī *O*(log(*n*)) manawa.
//! Ke nānā nei i ka mea nui ʻoi loa ʻo *O*(1).Hoʻololi i kahi vector i kahi puʻu binary hiki ke hana ʻia ma kahi, a loaʻa ka *O*(*n*) paʻakikī.
//! Hiki ke hoʻololi i kahi puʻupuʻu binary i kahi vector i hoʻokaʻina ʻia ma kahi, e ʻae iā ia e hoʻohana no kahi *O*(*n*\*log(* n*)) ma kahi wahi heapsort.
//!
//! # Examples
//!
//! ʻO kēia kahi laʻana nui aʻe e hoʻopili iā [Dijkstra's algorithm][dijkstra] e hoʻonā i ka [shortest path problem][sssp] ma kahi [directed graph][dir_graph].
//!
//! Hōʻike ia pehea e hoʻohana ai i [`BinaryHeap`] me nā ʻano pilikino.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Pili ka lālani mua i ka `Ord`.
//! // E hoʻokomo pono i ka trait no laila lilo ka lālani i puʻu min-kahi o kahi max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // E nānā i ka flip mākou i ke kauoha ʻana i nā koina.
//!         // Inā pili mākou i ka pili e hoʻohālikelike mākou i nā kūlana, pono kēia kaʻina e hana i nā hoʻokō o `PartialEq` a me `Ord` kūlike.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` pono e hoʻokō pū kekahi.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Hōʻike ʻia kēlā me kēia aka me he `usize`, no kahi hoʻokō pōkole.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ʻO Dijkstra ke ala pōkole loa algorithm.
//!
//! // E hoʻomaka ma `start` a hoʻohana iā `dist` e nānā i ka mamao loa o kēia manawa i kēlā me kēia pona.ʻAʻole mākaukau kēia hoʻokō ʻana ma muli o ka waiho ʻana i nā piko ʻelua i ka lālani.
//! //
//! // Hoʻohana pū ʻo ia iā `usize::MAX` ma ke ʻano he sentinel waiwai, no kahi maʻalahi maʻalahi.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=kēia manawa pōkole loa mai `start` a i `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Aia mākou ma `start`, me ke kumu kūʻai ʻole
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // E nānā i ka palena palena me nā helu kumu kūʻai haʻahaʻa (min-heap) mua
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // ʻOkoʻa hiki iā mākou ke hoʻomau e ʻike i nā ala pōkole loa
//!         if position == goal { return Some(cost); }
//!
//!         // Nui e like me kā mākou i loaʻa ai i kahi ala ʻoi aku ka maikaʻi
//!         if cost > dist[position] { continue; }
//!
//!         // No kēlā me kēia pona hiki iā mākou ke kiʻi, ʻike inā hiki iā mākou ke ʻike i kahi ala me ka uku haʻahaʻa e hele ana i kēia piko
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Inā pēlā, e hoʻohui i ka palena a hoʻomau
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Hoʻomaha, ua loaʻa iā mākou i kahi ala ʻoi aku ka maikaʻi
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ʻAʻole hiki ke kiʻi ʻia ke pahuhopu
//!     None
//! }
//!
//! fn main() {
//!     // ʻO kēia ka pakuhi kuhikuhi e hoʻohana mākou.
//!     // Kūlike nā helu node i nā mokuʻāina ʻokoʻa, a ʻo nā kaupaona edge e hōʻailona i ke kumukūʻai o ka neʻe ʻana mai kekahi piko i kekahi.
//!     //
//!     // E hoʻomaopopo he ʻaoʻao hoʻokahi nā kihi.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Hōʻike ʻia ka pakuhi ma ke ʻano he papa inoa pili i kēlā me kēia helu helu, e kūlike ana i kahi helu node, he papa inoa o nā ʻaoʻao i waho.
//!     // Koho ʻia no kona hoʻokō ʻana.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Hoʻokomo ʻia kahi lālani makakoho me kahi puʻu binary.
///
/// He puʻu kiʻekiʻe kēia.
///
/// He kuhi hewa ia no kahi mea e hoʻololi ʻia i ke ala e ʻoka ana ka mea e pili ana i nā huahana ʻē aʻe, e like me ka mea i hoʻoholo ʻia e `Ord` trait, e loli ana aia ia i ka puʻu.
///
/// Hiki wale nō kēia ma o `Cell`, `RefCell`, mokuʻāina holoʻokoʻa, I/O, a i ʻole pāʻālua palekana.
/// ʻAʻole i kuhikuhi ʻia ke ʻano o ke kuhi hewa ʻana, akā ʻaʻole ia e hopena i ka hana i hoʻoholo ʻole ʻia.
/// Hiki i kēia ke hoʻopili iā panics, nā hualoaʻa kūpono ʻole, nā hemo, nā laha hoʻomanaʻo, a me ka hoʻopau ʻole ʻana.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // E ʻae iā mākou e haʻalele i kahi pūlima ʻano kikoʻī (ʻo ia ka `BinaryHeap<i32>` i kēia hiʻohiʻona).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Hiki iā mākou ke hoʻohana i ka peek e nānā i ka mea hou aʻe i ka puʻu.
/// // I kēia hihia, ʻaʻohe mea i laila ma laila no laila ʻaʻole mākou e loaʻa.
/// assert_eq!(heap.peek(), None);
///
/// // E hoʻohui i kekahi mau helu ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Hōʻike ka peek i ka mea nui i ka puʻu.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Hiki iā mākou ke nānā i ka lōʻihi o kahi ahu.
/// assert_eq!(heap.len(), 3);
///
/// // Hiki iā mākou ke iterate ma luna o nā mea i ka puʻu, ʻoiai lākou i hoʻihoʻi ʻia mai i kahi hoʻonohonoho lōkō.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Inā pā mākou i kēia mau helu, hoʻi lākou i ke kauoha.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Hiki iā mākou ke hoʻomaʻemaʻe i ka ahu o nā mea i koe.
/// heap.clear();
///
/// // E hakahaka ka puʻu i kēia manawa.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Hiki ke hoʻohana ʻia i `std::cmp::Reverse` a i ʻole `Ord` hoʻohana pilikino e hana i `BinaryHeap` i kahi min-heap.
/// Hoʻihoʻi kēia iā `heap.pop()` i ka waiwai liʻiliʻi ma kahi o ka mea nui loa.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Hoʻopili i nā waiwai i `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Inā pop mākou i kēia mau helu i kēia manawa, hoʻi lākou i ke kaʻina huli.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Ka paʻakikī o ka manawa
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// ʻO ke kumukūʻai no `push` kahi kumukūʻai i manaʻo ʻia;hāʻawi ka palapala hana i kahi hōʻuluʻulu kikoʻī.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// ʻO ke kāwaha e hoʻopili nei i kahi kuhikuhi hiki ke hoʻololi i kahi mea nui loa ma `BinaryHeap`.
///
///
/// Hana ʻia kēia `struct` e ke ʻano [`peek_mut`] ma [`BinaryHeap`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: Hoʻohou wale ʻia ʻo PeekMut no nā ahu ʻōpala ʻole.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: Hoʻohuli wale ʻia ʻo PeekMut no nā ahu ʻōpala ʻole
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: Hoʻohuli wale ʻia ʻo PeekMut no nā ahu ʻōpala ʻole
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Wehe i ka waiwai peeked mai ka puʻu a hoʻihoʻi iā ia.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Hana i kahi `BinaryHeap<T>` hakahaka.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Hana i kahi `BinaryHeap` hakahaka ma ke ʻano he max-heap.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Hana i kahi `BinaryHeap` hakahaka me kahi mana kikoʻī.
    /// Hoʻopili kēia i ka hoʻomanaʻo i lawa no nā mea `capacity`, no laila ʻaʻole pono e hoʻoili ʻia ka `BinaryHeap` a hiki i ka loaʻa ʻana o ia mau waiwai ma ka liʻiliʻi.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Hoʻihoʻi i kahi kuhikuhi e hiki ai ke hoʻololi i ka mea nui i ka puʻu binary, a i ʻole `None` inā hakahaka.
    ///
    /// Note: Inā kulu ka waiwai `PeekMut`, aia paha ka puʻupuʻu i kahi kūlana kūlike ʻole.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Ka paʻakikī o ka manawa
    ///
    /// Inā hoʻololi ʻia ka mea a laila *O*(log(*n*)) ka paʻakikī manawa hihia ʻoi loa, a i ʻole ʻo *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Wehe i ka mea nui mai ka puʻu binary a hoʻihoʻi iā ia, a i ʻole `None` inā hakahaka.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Ka paʻakikī o ka manawa
    ///
    /// ʻO ke kumukūʻai hihia maikaʻi loa o `pop` ma kahi puʻu e paʻa ana nā *n* element ʻo *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() ke ʻano o self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Pākuʻi i kahi mea i ka puʻu binary.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Ka paʻakikī o ka manawa
    ///
    /// ʻO ke kumu kūʻai i manaʻo ʻia o `push`, averages ma luna o kēlā me kēia hoʻonohonoho pono ʻana o nā mea e hoʻokuʻi ʻia ana, a ma luna o ka nui o nā pahu kuʻi, ʻo ia ʻo *O*(1).
    ///
    /// ʻO kēia ka metric uku kumukūʻai ʻoi loa i ka pahu ʻana i nā ʻaoʻao i *ʻaʻole* i loko o kekahi ʻano hoʻonohonoho.
    ///
    /// E hoʻohaʻahaʻa ka paʻakikī manawa inā hoʻokuʻi ʻia nā mea i ka piʻi piʻi nui.
    /// I ka hihia maikaʻi loa, hoʻoneʻe ʻia nā mea i ka piʻi ʻana i hoʻonohonoho ʻia a ʻo *O*(log(*n*)) ke kumu kūʻai i hoʻolilo ʻia no ka puʻe e kūʻē i kahi puʻu e komo ana nā ʻaoʻao *n*.
    ///
    /// ʻO ke kumukūʻai hihia maikaʻi loa o ke kāhea *hoʻokahi* iā `push` ʻo *O*(*n*).Kū ka hihia ʻoi loa ke luhi ka hiki a pono i kahi resize.
    /// Ua amortized ke kumu kūʻai resize i nā kiʻi mua.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: ʻOiai ua pahu mākou i kahi mea hou he manaʻo ia
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Pau ka `BinaryHeap` a hoʻihoʻi i kahi vector i ka hoʻonohonoho (ascending) i hoʻonohonoho ʻia.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: Hele ʻo `end` mai `self.len() - 1` a 1 (hoʻopili pū ʻia),
            //  no laila he index pololei ia e komo ai.
            //  Palekana ia e kiʻi i ka papa kuhikuhi 0 (ie `ptr`), no ka mea
            //  1 <=hopena <self.len(), ʻo ia hoʻi self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` hele mai `self.len() - 1` a 1 (hoʻopili pū ʻia) no laila:
            //  0 <1 <=hopena <= self.len(), 1 <self.len() ʻO ka manaʻo 0 0 ka hopena a me ka hopena <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Hoʻohana nā hana o sift_up a me sift_down i nā poloka palekana ʻole e hoʻoneʻe i kahi mea mai vector (e waiho ana ma hope o kahi puka), e neʻe me nā mea ʻē aʻe a hoʻoneʻe i ka mea i hoʻoneʻe ʻia i vector ma kahi hope loa o ka lua.
    //
    // Hoʻohana ʻia ke ʻano `Hole` e hōʻike i kēia, a e ʻike pono i ka hoʻopiha ʻana o ka lua i ka hope o kāna kaha, ʻoiai ma panic.
    // Hoʻohana ka hoʻohana ʻana i kahi lua i ka mea mau i hoʻohālikelike ʻia i ka hoʻohana ʻana i nā swaps, e pili ana i ʻelua mau neʻe.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Pono ka mea kelepona e hōʻoia i ka `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // E lawe i ka waiwai ma `pos` a hana i kahi puka.
        // SAFETY: Hōʻoia ka mea kelepona i kēlā pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos()> hoʻomaka>=0, ʻo ia hoʻi hole.pos()> 0
            //  a no laila hole.pos(), ʻaʻole hiki i 1 ke kahe i lalo.
            //  Hōʻoia kēia i ka makua <hole.pos() no laila he helu helu kūpono ia a me!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: E like me ma luna
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Lawe i kahi mea ma `pos` a hoʻoneʻe iā ia i ka puʻu, ʻoiai ʻoi aku ka nui o kāna mau keiki.
    ///
    ///
    /// # Safety
    ///
    /// Pono ka mea kelepona e hōʻoia i ka `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETY: Hōʻoia ka mea kelepona i kēlā pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loari invariant: keiki==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // e hoʻohālikelike me nā mea nui o nā keiki ʻelua SAFETY: keiki <hopena, 1 <self.len() a me ke keiki + 1 <hopena <= self.len(), no laila ua pololei nā papa kuhikuhi.
            //
            //  keiki==2 *hole.pos() + 1!= hole.pos() a me ke keiki + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 a i ʻole 2* hole.pos() + 2 hiki ke hoʻonui ʻia inā ʻo T kahi ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // inā mākou i ke kauoha, kū.
            // SAFETY: ʻo ke keiki i kēia manawa ka ʻelemakule a i ʻole ke keiki ʻelemakule + 1
            //  Ua hōʻoia mākou he <self.len() a me!= hole.pos() nā mea ʻelua
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: like me ma luna.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: &&pōʻaiapuni, ʻo ia hoʻi i loko o ka
        //  lua o ke ano ia ka oiaio mua i keiki==hopena, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: ua hōʻoia ʻia ke keiki he helu helu kūpono a
            //  keiki==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Pono ka mea kelepona e hōʻoia i ka `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: hōʻoia ʻia ʻo pos <len e ka mea e kāhea ana a
        //  maopopo leʻa len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Lawe i kahi mea ma `pos` a neʻe i ke ala a pau i ka puʻu, a laila kānana iā ia i kona kūlana.
    ///
    ///
    /// Note: ʻOi aku ka wikiwiki o kēia ke ʻike ʻia ka mea he nui/pono kokoke i ka lalo.
    ///
    /// # Safety
    ///
    /// Pono ka mea kelepona e hōʻoia i ka `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: Hōʻoia ka mea kelepona i kēlā pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loari invariant: keiki==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETY: keiki <pau, 1 <self.len() a
            //  keiki + 1 <hopena <= self.len(), no laila kūpono lākou i nā papa kuhikuhi helu.
            //  keiki==2 *hole.pos() + 1!= hole.pos() a me ke keiki + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 a i ʻole 2* hole.pos() + 2 hiki ke hoʻonui ʻia inā ʻo T kahi ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: E like me ma luna
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: keiki==pau, 1 <self.len(), no laila he helu helu kūpono
            //  a keiki==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: ʻo pos ke kūlana i ka lua a ua hōʻoia ʻia
        //  he papa kuhikuhi kūpono.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n hoʻomaka mai self.len()/2 a iho i lalo i 0.
            //  ʻO ka hihia wale nō ke! (N <self.len()) inā ʻo self.len() ==0, akā hoʻoholo ʻia e ke ʻano loop.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// E hoʻoneʻe i nā mea āpau o `other` i `self`, e waiho hakahaka nei i `other`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` Lawe ʻo O(len1 + len2) mau hana a ma kahi o 2 *(len1 + len2) hoʻohālikelike i ka hihia ʻoi loa ʻoiai ʻo `extend` e hana i nā hana O(len2* log(len1)) a ma kahi o 1 *len2* log_2(len1) hoʻohālikelike i ka hihia maikaʻi loa, e manaʻo nei len1>= len2.
        // No nā puʻu nunui, ʻaʻole pili hou ke kiko crossover i kēia noʻonoʻo a hoʻoholo ʻia empirically.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Hoʻihoʻi i kahi iterator e kiʻi i nā mea i ka hoʻonohonoho heap.
    /// Lawe ʻia nā mea i kiʻi ʻia mai ka puʻu kumu.
    /// E hoʻoneʻe ʻia nā mea i koe ma ke kulu i ka hoʻonohonoho ahu.
    ///
    /// Note:
    /// * `.drain_sorted()` ʻo *O*(*n*\*log(* n*)); ʻoi aku ka lohi ma mua o `.drain()`.
    ///   Pono ʻoe e hoʻohana i ka hope no ka nui o nā hihia.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // hemo i nā mea āpau i ka hoʻonohonoho ahu
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Mālama wale i nā mea i kuhikuhi ʻia e ka predicate.
    ///
    /// I nā huaʻōlelo ʻē aʻe, wehe i nā mea āpau `e` e like me ka hoʻihoʻi ʻana o `f(&e)` iā `false`.
    /// Kipa ʻia nā mea i ke ʻano unsort (a ʻaʻole i kuhikuhi ʻia).
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // mālama wale nō i nā helu
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Hoʻihoʻi i kahi iterator e kipa ana i nā waiwai āpau i ka vector ma lalo, i ke kaʻina kaulike.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Pai i ka 1, 2, 3, 4 ma ke kauoha kuokoa
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Hoʻihoʻi i kahi iterator e kiʻi i nā mea i ka hoʻonohonoho heap.
    /// Pau kēia hana i ka puʻu kumu.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Hoʻihoʻi i ka mea nui i ka puʻu binary, a i ʻole `None` inā hakahaka.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Ka paʻakikī o ka manawa
    ///
    /// ʻO ke kumukūʻai ʻo *O*(1) ma ka hihia ʻoi loa.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Hoʻihoʻi i ka helu o nā mea i hiki i ka puʻu binary ke hoʻopaʻa me ka ʻole o ka reallocating.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Mālama i ka palena iki ka hiki no `additional` kikoʻī hou aʻe e hoʻokomo ʻia i ka `BinaryHeap` i hāʻawi ʻia.
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo [`reserve`] inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `BinaryHeap`.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Hōʻalo e like me ka hiki ke hiki.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Hoʻolei i ka hiki me ka palena lalo.
    ///
    /// E noho ka hiki ma ka liʻiliʻi e like me ka lōʻihi a me ka waiwai i hoʻolako ʻia.
    ///
    ///
    /// Inā ʻoi aku ka liʻiliʻi o kēia manawa ma mua o ka palena haʻahaʻa, he no-op kēia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Pau ka `BinaryHeap` a hoʻihoʻi i ka vector ma lalo i ke kaʻina kaulike.
    ///
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // E paʻi ma kekahi ʻoka
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Hoʻihoʻi i ka lōʻihi o ka puʻu binary.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Nānā inā hakahaka ka ahu ahu.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hoʻomaʻemaʻe i ka puʻu binary, hoʻihoʻi i kahi iterator ma luna o nā mea i hoʻoneʻe ʻia.
    ///
    /// Wehe ʻia nā mea i ke kaʻina kaulike.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Kulu i nā mea āpau mai ka puʻu binary.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hōʻike ʻo Hole i kahi puka i kahi ʻāpana, he papa kuhikuhi me ka ʻole o ke kumukūʻai kūpono (no ka mea ua hoʻoneʻe ʻia a i pālua ʻia paha).
///
/// I ke kulu, `Hole` e hoʻihoʻi i ka ʻāpana ma ka hoʻopiha ʻana i ke kūlana puka me ka waiwai i hemo mua ʻia.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Hana i kahi `Hole` hou ma ka helu `pos`.
    ///
    /// Palekana ʻole no ka mea aia ʻo pos i loko o ka ʻikepili.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pono ʻo pos i loko o ka ʻāpana
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Hoʻihoʻi i kahi kuhikuhi i ke kumumanaʻo i hoʻoneʻe ʻia.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Hoʻihoʻi i kahi kuhikuhi i ka mea ma `index`.
    ///
    /// Palekana ʻole no ka mea aia ka index ma loko o ka ʻikepili ʻikepili a kūlike ʻole i ka pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Neʻe puka i kahi hou
    ///
    /// Palekana ʻole no ka mea aia ka index ma loko o ka ʻikepili ʻikepili a kūlike ʻole i ka pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // hoʻopiha hou i ka lua
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// He iterator ma luna o nā kumu o ka `BinaryHeap`.
///
/// Hana ʻia kēia `struct` e [`BinaryHeap::iter()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Wehe i ka makemake o `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Loaʻa kahi iterator ma luna o nā mea o ka `BinaryHeap`.
///
/// Hana ʻia kēia `struct` e [`BinaryHeap::into_iter()`] (hāʻawi ʻia e `IntoIterator` trait).
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ʻO kahi iterator hoʻokahe ma luna o nā mea o `BinaryHeap`.
///
/// Hana ʻia kēia `struct` e [`BinaryHeap::drain()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ʻO kahi iterator hoʻokahe ma luna o nā mea o `BinaryHeap`.
///
/// Hana ʻia kēia `struct` e [`BinaryHeap::drain_sorted()`].
/// E ʻike i kāna palapala no nā mea hou aʻe.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Wehe i nā mea ahu i ka hoʻonohonoho ahu.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Hoʻohuli i `Vec<T>` i `BinaryHeap<T>`.
    ///
    /// Hana kēia hoʻololi i kahi, a loaʻa ka *O*(*n*) paʻakikī i ka manawa.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Hoʻohuli i `BinaryHeap<T>` i `Vec<T>`.
    ///
    /// ʻAʻole koi kēia hoʻololi i ka neʻe ʻana o ka ʻikepili a i ʻole ka hoʻokaʻawale ʻana, a he paʻakikī mau ka manawa.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Hoʻokumu i kahi iterator e ʻai ana, ʻo ia hoʻi, e hoʻoneʻe i kēlā me kēia waiwai mai ka puʻupuʻu binary i ke kaʻina kaulike.
    /// ʻAʻole hiki ke hoʻohana i ka puʻupuʻu binary ma hope o ke kāhea ʻana i kēia.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻamau:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Pai i ka 1, 2, 3, 4 ma ke kauoha kuokoa
    /// for x in heap.into_iter() {
    ///     // x he ʻano i32, ʻaʻole &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}