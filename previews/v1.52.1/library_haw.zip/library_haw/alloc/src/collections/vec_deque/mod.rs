//! Hoʻokomo ʻia kahi lālani pālua me kahi buffer ring growable.
//!
//! ʻO kēia kaʻina he *O*(1) nā insort amortized a hemo mai nā wēlau ʻelua o ka ipu.
//! Loaʻa iā ia he index *O*(1) e like me vector.
//! ʻAʻole koi ʻia nā mea i loko e hiki i kahi kope, a e hoʻouna ʻia ke kūloko inā e hoʻouna ʻia ke ʻano i loaʻa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Ka mana nui nui loa o nā mea ʻelua

/// Hoʻokomo ʻia kahi lālani pālua me kahi buffer ring growable.
///
/// ʻO ka hoʻohana "default" o kēia ʻano he lālani e hoʻohana iā [`push_back`] e hoʻohui i ka lālani, a me [`pop_front`] e hemo ai mai ka lālani.
///
/// [`extend`] a [`append`] kaomi i ka hope i kēia ʻano, a ʻo ka iterating ma luna o `VecDeque` e hele mua i hope.
///
/// No ka mea ʻo `VecDeque` kahi buffer apo, ʻaʻole pili pono kāna mau mea i ka hoʻomanaʻo.
/// Inā makemake ʻoe e kiʻi i nā kumumea ma ke ʻano o kahi ʻāpana hoʻokahi, e like me ka hoʻomaʻemaʻe kūpono ʻana, hiki iā ʻoe ke hoʻohana iā [`make_contiguous`].
/// Hoʻohuli ia i ka `VecDeque` i ʻole e wahī kāna mau mea, a hoʻihoʻi i kahi ʻāpana i hiki ke hoʻololi ʻia i ke kaʻina o nā mea e pili ana i kēia manawa.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ʻo ka huelo a me ke poʻo ke kuhi i loko o ka pale.
    // Kuhi mau ka huela i ka mea mua i hiki ke heluhelu ʻia, kuhikuhi mau ke poʻo i kahi e kākau ai i ka ʻikepili.
    //
    // Inā huelo==poʻo ke poʻo o ka pale pale.Hoʻomaopopo ʻia ka lōʻihi o ka ringbuffer e like me ka mamao ma waena o nā mea ʻelua.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Holo i ka mea hōʻino no nā mea āpau i ka ʻāpana ke iho ʻia i lalo (maʻa mau a i ʻole ka holoi ʻana.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // hoʻohana kulu no [T]
            ptr::drop_in_place(front);
        }
        // Mālama ʻo RawVec i ka translocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Hana i kahi `VecDeque<T>` hakahaka.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// ʻOi aku ka maʻalahi
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// ʻOi aku ka maʻalahi
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // No nā ʻano nui ʻole, aia mau mākou i ka nui o ka hiki
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// E hoʻolilo iā ptr i kahi ʻāpana
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// E hoʻolilo iā ptr i kahi ʻoki mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// E hoʻoneʻe i kahi mea mai ka pale pale
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Kākau i kahi mea i loko o ka pale, neʻe iā ia.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Hoʻi iā `true` inā loaʻa ka buffer i ka hiki piha.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Hoʻihoʻi i ka papa kuhikuhi ma ka buffer kumu no kahi papa kuhikuhi kumu kūlike i hāʻawi ʻia.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// E hoʻihoʻi i ka papa kuhikuhi ma ka buffer o lalo no kahi index index element + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// E hoʻihoʻi i ka papa kuhikuhi ma ka buffer kumu no kahi index element element logical, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// E kope i kahi poloka pili o ka hoʻomanaʻo len mai src a hiki i dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// E kope i kahi poloka pili o ka hoʻomanaʻo len mai src a hiki i dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kope i ka palena papaha, ai wahīʻia aeie o ka iaiyoe Len loa mai src i dest.
    /// (abs(dst - src) + len) ʻaʻole e ʻoi aku ka nui ma mua o cap() (Aia ma kahi o hoʻokahi mau wahi kaiapuni mau ma waena o src a me dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // ʻAʻole wahī ʻo src, ʻaʻole wahī ʻole
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst ma mua o src, src ʻaʻole wahī, wahī
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ma mua o dst, ʻaʻole wahī ʻo src, wahī
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ma mua o ka hoʻopili ʻana o src, src, ʻaʻole wahī ʻo Dst
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src ma mua o dst, src wahī, ʻaʻole wahī ʻo dst
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst ma mua o src, src wahī, dst wahī
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src ma mua o dst, src wahī, dst wahī
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs i nā poʻo a me nā ʻāpana huelo a puni e lawelawe i ka ʻoiaʻiʻo a mākou i hoʻonohonoho ai.
    /// Palekana ʻole no ka mea hilinaʻi ia i ka makahiki kahiko.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // E neʻe i ka ʻāpana pili loa o ke apo buff TH
        //
        //   [o o o o o o o . ]
        //    ʻO THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              Nokia [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ʻAʻole
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Hana i kahi `VecDeque` hakahaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Hana i kahi `VecDeque` hakahaka me kahi hakahaka no ka `capacity` mau mea ma ka liʻiliʻi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 no ka mea haʻalele ka Ringbuffer i kahi hakahaka mau
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Hāʻawi i kahi kuhikuhi i ke kumuhana ma ka papa kuhikuhi i hāʻawi ʻia.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Hāʻawi i kahi kuhikuhi e hiki ai ke hoʻololi i ka mea ma ka papa kuhikuhi i hāʻawi ʻia.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Kuapo i nā mea ma nā papa helu `i` a me `j`.
    ///
    /// `i` a e like paha `j`.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Panics
    ///
    /// Panics inā aia kekahi papa kuhikuhi ma waho o nā palena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Hoʻihoʻi i ka helu o nā mea i hiki i ka `VecDeque` ke hoʻopaʻa me ka ʻole o ka reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Mālama i ka palena iki ka hiki no `additional` kikoʻī hou aʻe e hoʻokomo ʻia i ka `VecDeque` i hāʻawi ʻia.
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo [`reserve`] inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `VecDeque` i hāʻawi ʻia.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// E hoʻāʻo e mālama i ka hiki palena iki no `additional` kikoʻī hou aʻe e hoʻokomo ʻia i ka `VecDeque<T>` i hāʻawi ʻia.
    ///
    /// Ma hope o ke kāhea ʻana iā `try_reserve_exact`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila, ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo `reserve` inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki iā `usize`, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // I kēia manawa ʻike mākou ʻaʻole hiki i OOM(Out-Of-Memory) kēia ma waena o kā mākou hana paʻakikī
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // paʻakikī loa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// E hoʻāʻo e mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `VecDeque<T>` i hāʻawi ʻia.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    /// Ma hope o ke kāhea ʻana iā `try_reserve`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// ʻAʻohe mea inā lawa ka hiki.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki iā `usize`, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve(data.len())?;
    ///
    ///     // I kēia manawa maopopo iā mākou ʻaʻole hiki iā OOM i ka waena o kā mākou hana paʻakikī
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // paʻakikī loa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// E hōʻemi i ka hiki o `VecDeque` i ka hiki.
    ///
    /// E hāloʻo ia i lalo kokoke i ka lōʻihi akā e hoʻomaopopo mau paha ka mea hoʻokaʻawale i ka `VecDeque` aia kahi hakahaka no kekahi mau mea hou aku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// E hōʻemi i ka hiki o ka `VecDeque` me ka palena haʻahaʻa.
    ///
    /// E noho ka hiki ma ka liʻiliʻi e like me ka lōʻihi a me ka waiwai i hoʻolako ʻia.
    ///
    ///
    /// Inā ʻoi aku ka liʻiliʻi o kēia manawa ma mua o ka palena haʻahaʻa, he no-op kēia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // ʻAʻole pono mākou e hopohopo e pili ana i ka hoʻoheheʻe ʻana ʻo `self.len()` a me `self.capacity()` ʻaʻole hiki ke lilo i `usize::MAX`.
        // +1 e waiho mau ana ka mea kani kani i kahi hakahaka.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // ʻEkolu mau hihia hoihoi:
            //   Kūpono nā mea a pau i nā palena i makemake ʻia E pili ana nā mea, a ʻo ke poʻo i waho o nā palena i makemake ʻia E hoʻokaʻawale nā mea, a ʻo ka huelo i waho o nā palena i makemake ʻia.
            //
            //
            // I nā manawa ʻē aʻe āpau, ʻaʻole e hoʻopili ʻia nā kūlana kumu.
            //
            // Hōʻike i ka neʻe ʻana o nā mea ma ke poʻo.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // E neʻe i nā mea mai nā palena i makemake ʻia (nā kūlana ma hope o target_cap)
            if self.tail >= target_cap && head_outside {
                // ʻO TH
                //   [. . . . . . . . o o o o o o o . ]
                //    ʻO TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ʻO TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Hoʻopōkole i ka `VecDeque`, e mālama nei i nā mea `len` mua a waiho i ke koena.
    ///
    ///
    /// Inā ʻoi aku ka nui o `len` ma mua o ka lōʻihi o VecDeque`, ʻaʻohe hopena o kēia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Holo i ka mea hōʻino no nā mea āpau i ka ʻāpana ke iho ʻia i lalo (maʻa mau a i ʻole ka holoi ʻana.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Palekana no ka mea:
        //
        // * Kuhi ʻia kekahi ʻāpana i `drop_in_place`;ʻo ka lua o ka hihia he `len <= front.len()` a hoʻi i `len > self.len()` e hōʻoia `begin <= back.len()` i ka hihia mua
        //
        // * Hoʻoneʻe ʻia ke poʻo o ka VecDeque ma mua o ke kāhea ʻana iā `drop_in_place`, no laila ʻaʻohe kumu i hāʻule ʻelua inā `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // E ʻike pono i ka hāʻule ʻana o ka hapalua o ka hapalua ʻoiai ʻo kahi destructor i ka mea mua panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Hoʻi i kahi iterator mua-i-hope.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Hoʻi i kahi iterator mua a i hope e hoʻi i nā kūmole hiki ke loli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: Hoʻokumu ʻia ka invariant palekana `IterMut` kūloko no ka mea
        // `ring` ke hana nei i ka dereferencable māhele no ka wa e ola ana '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Hoʻihoʻi i kahi mau ʻāpana i loaʻa, i ke kaʻina, nā ʻike o ka `VecDeque`.
    ///
    /// Inā i kāhea ʻia ʻo [`make_contiguous`], aia nā mea āpau o ka `VecDeque` i ka ʻāpana mua a hakahaka ka ʻāpana ʻelua.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Hoʻihoʻi i kahi mau ʻāpana i loaʻa, i ke kaʻina, nā ʻike o ka `VecDeque`.
    ///
    /// Inā i kāhea ʻia ʻo [`make_contiguous`], aia nā mea āpau o ka `VecDeque` i ka ʻāpana mua a hakahaka ka ʻāpana ʻelua.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Hoʻihoʻi i ka helu o nā mea i ka `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Hoʻi iā `true` inā hakahaka ka `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Hana i kahi iterator e uhi i ka laulā i kuhikuhi ʻia i ka `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka helu hoʻomaka ma mua o ka hopena a i ʻole inā ʻoi aku ka nui o ka hopena ma mua o ka lōʻihi o ka vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Uhi kahi laulā piha i nā ʻike āpau
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // ʻO kā mākou ʻāpana like a mākou i &self i mālama ʻia i ka '_ o Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Hoʻokumu i kahi iterator e uhi i ka laulā hiki ke hoʻololi i ka `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka helu hoʻomaka ma mua o ka hopena a i ʻole inā ʻoi aku ka nui o ka hopena ma mua o ka lōʻihi o ka vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Uhi kahi laulā piha i nā ʻike āpau
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: Hoʻokumu ʻia ka invariant palekana `IterMut` kūloko no ka mea
        // `ring` ke hana nei i ka dereferencable māhele no ka wa e ola ana '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Hoʻokumu i kahi iterator hoʻokahe e hoʻoneʻe i ka pae i kuhikuhi ʻia i ka `VecDeque` a hāʻawi i nā mea i lawe ʻia.
    ///
    /// Nānā 1: Wehe ʻia ka pae o ke kumu inā ʻaʻole pau ka iterator a hiki i ka hopena.
    ///
    /// Nānā 2: ʻAʻole kuhi ʻia i ka nui o nā mea i lawe ʻia mai ka deque, inā ʻaʻole e hoʻokuʻu ʻia ka waiwai `Drain`, akā pau ka hōʻaiʻē e paʻa ana (e like me `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka helu hoʻomaka ma mua o ka hopena a i ʻole inā ʻoi aku ka nui o ka hopena ma mua o ka lōʻihi o ka vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Holoi kahi laulā piha i nā ʻike āpau
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Palekana palekana
        //
        // Ke hana mua ʻia ka Drain, hoʻopōkole ʻia ke kumu waiwai i mea e ʻike ʻole ai nā uninitialized a i neʻe ʻia paha mai nā mea i loaʻa ʻole inā holo ʻole ka mea hōʻino a Drain.
        //
        //
        // Drain e ptr::read i nā waiwai e hemo.
        // Ke pau, e kope i ka ʻikepili i koe e uhi i ka lua, a hoʻihoʻi pololei ʻia nā waiwai head/tail.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Ua mahele ʻia nā ʻaoʻao o ka deque i ʻekolu mau ʻāpana:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Mālama mākou iā drain_tail ma ke ʻano self.head, a me drain_head a me self.head ma hope o hope a ma hope o ke poʻo ma ka Drain.
        // Hoʻopili pū kēia i ka hoʻonohonoho kūpono e like me ke kuhi ʻia o Drain, ua poina mākou e pili ana i nā waiwai i neʻe ʻia ma hope o ka hoʻomaka o ka drain.
        //
        //
        //        T H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" e pili ana i nā waiwai ma hope o ka hoʻomaka o ka drain a hiki i ka pau ʻana o ka drain a holo ka Zuctactor Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // ʻO ke koʻikoʻi, hana wale mākou i nā kūmole i kaʻana like ʻia mai `self` ma aneʻi a heluhelu mai ia.
                // ʻAʻole mākou e kākau iā `self` a i ʻole reb rebim i kahi kuhikuhi kūwaho.
                // No laila, ʻo ka pointer maka mākou i hana ai ma luna, no `deque`, e paʻa mau.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// E hoʻomaʻemaʻe i ka `VecDeque`, e hoʻoneʻe i nā waiwai āpau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Hoʻi iā `true` inā loaʻa i ka `VecDeque` kahi mea like i ka waiwai i hāʻawi ʻia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Hāʻawi i kahi kuhikuhi i ka mea mua, a i ʻole `None` inā nele ka `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Hāʻawi i kahi kuhikuhi hiki ke hoʻololi i ka mea mua, a i ʻole `None` inā nele ka `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Hāʻawi i kahi kuhikuhi i ka mea hope, a i ʻole `None` inā nele ka `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Hāʻawi i kahi kuhikuhi hiki ke hoʻololi i ka ʻaoʻao hope, a i ʻole `None` inā nele ka `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Wehe i ka mea mua a hoʻihoʻi iā ia, a i ʻole `None` inā nele ka `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Wehe i ka mea hope loa mai ka `VecDeque` a hoʻihoʻi iā ia, a i ʻole `None` inā hakahaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Hoʻomākaukau kahi mea i ka `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Pākuʻi i kahi mea i ka hope o ka `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: E noʻonoʻo paha iā `head == 0` i ka manaʻo
        // pili pili kēlā `self`?
        self.tail <= self.head
    }

    /// Wehe i kahi mea mai kēlā me kēia wahi o ka `VecDeque` a hoʻihoʻi iā ia, e hoʻololi iā ia me ka mea mua.
    ///
    ///
    /// ʻAʻole mālama kēia i ke kauoha ʻana, akā ʻo *O*(1).
    ///
    /// Hoʻi iā `None` inā `index` ma waho o nā palena.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Wehe i kahi mea mai kēlā me kēia wahi o ka `VecDeque` a hoʻihoʻi iā ia, e hoʻololi iā ia me ka mea hope loa.
    ///
    ///
    /// ʻAʻole mālama kēia i ke kauoha ʻana, akā ʻo *O*(1).
    ///
    /// Hoʻi iā `None` inā `index` ma waho o nā palena.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Hoʻokomo i kahi mea ma `index` ma loko o ka `VecDeque`, ke hoʻololi nei i nā mea āpau me nā helu kikoʻī i ʻoi aku a i ʻole ia me `index` i ka hope.
    ///
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `index` ʻoi aku ma mua o ka lōʻihi o VecDeque
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // E hoʻoneʻe i ka helu liʻiliʻi o nā mea i ka buffer ring a hoʻokomo i ka mea i hāʻawi ʻia
        //
        // Ma ka hapanui len/2, hoʻoneʻe ʻia nā mea 1. O(min(n, n-i))
        //
        // ʻEkolu mau hihia nui:
        //  Kūlike nā kūmole
        //      - hihia kūikawā inā he huelo ʻo 0 E hōʻole ana nā mea a ʻo ka mea hoʻokomo i loko o ka ʻāpana o ka huelo E hoʻokaʻawale nā mea a ʻo ka mea hoʻokomo i ka ʻāpana poʻo.
        //
        //
        // No kēlā me kēia mea he ʻelua mau hihia hou:
        //  Hoʻokomo kokoke i ka huelo Hoʻokomo ʻo Insert kokoke i ke poʻo
        //
        // Ki: H, self.head
        //      T, self.tail o, ʻae kūpono I, Hoʻokomo ʻaoʻao A, ke kinona e pono ai ma hope o ke kiko hoʻokomo M, e hōʻike i ka neʻe ʻana o ka mea
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // pili pili, e hoʻokokoke aku i ka huelo.
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ʻO TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // pili pono, hoʻokomo kokoke i ka hiʻu a me ka huelo ʻo 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Ua neʻe mua i ka huelo, no laila kope wale mākou i nā mea `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // kokoke, hookomo pili i ka poo:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ʻO TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, hoʻokomo kokoke i ka huelo, ʻāpana huelo:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, hoʻokomo kokoke i ke poʻo, ʻāpana huelo:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kope i nā mea a hiki i ke poʻo hou
                    self.copy(1, 0, self.head);

                    // kope i ka mea hope loa i kahi kiko ʻole ma lalo o ka pale
                    self.copy(0, self.cap() - 1, 1);

                    // neʻe i nā mea mai idx a hoʻopau i mua me ka ʻole o ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, hoʻokomo kokoke i ka huelo, poʻo ʻāpana, a aia ma ka helu helu ʻole i loko o ka pale kūloko.
                    //
                    //
                    //       ʻIHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kope i nā mea a hiki i ka huelo hou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kope i ka mea hope loa i kahi kiko ʻole ma lalo o ka pale
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, hoʻokomo kokoke i ka huelo, poʻo ʻāpana:
                    //
                    //             ʻIHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kope i nā mea a hiki i ka huelo hou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kope i ka mea hope loa i kahi kiko ʻole ma lalo o ka pale
                    self.copy(self.cap() - 1, 0, 1);

                    // neʻe i nā mea mai idx-1 a hoʻopau i mua me ka ʻole o ka…element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, hoʻokomo kokoke i ke poʻo, poʻo ʻāpana:
                    //
                    //               ʻIHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Ua loli paha ka huelo no laila pono mākou e helu hou
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Wehe a hoʻihoʻi i ka mea ma `index` mai ka `VecDeque`.
    /// ʻO kēlā a me kēia ʻaoʻao e pili kokoke ana i kahi e hemo ai e hoʻoneʻe ʻia i lumi, a hoʻoneʻe ʻia nā mea āpau āpau i nā kūlana hou.
    ///
    /// Hoʻi iā `None` inā `index` ma waho o nā palena.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // ʻEkolu mau hihia nui:
        //  Kūlike nā mea kūlike ʻaʻano ʻole nā kumumanaʻo a hemo ka mahele o ka huelo
        //
        //      - hihia kūikawā ke pili pono nā ʻenehana, akā self.head =0
        //
        // No kēlā me kēia mea he ʻelua mau hihia hou:
        //  Hoʻokomo kokoke i ka huelo Hoʻokomo ʻo Insert kokoke i ke poʻo
        //
        // Ki: H, self.head
        //      T, self.tail o, ʻāpono kūpono x, Kaha i kahakaha ʻia no ka hemo ʻana o R, e hōʻike ana i ka hoʻoneʻe ʻia ʻana o M, ua hoʻoneʻe ʻia nā mea hōʻike
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // pili pili, hemo kokoke i ka huelo.
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ʻO TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // pili pili, hoʻoneʻe kokoke i ke poʻo:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ʻO TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // hoʻokaʻawale, hemo i kahi kokoke i ka huelo, ʻāpana huelo:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // hoʻokaʻawale, hemo loa i ke poʻo, ʻāpana poʻo:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, hemo kokoke i ke poʻo, ʻāpana huelo:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // a i ʻole quasi-discontiguous, hemo aʻe ma hope o ke poʻo, ʻāpana huelo:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ʻO TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // huki i nā mea i ka ʻāpana o ka huelo
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Kāohi i ka wai kahe.
                    if self.head != 0 {
                        // kope i ka mea mua i kahi kiko
                        self.copy(self.cap() - 1, 0, 1);

                        // neʻe i nā mea i ka ʻāpana poʻo i hope
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // hoʻokaʻawale, hemo i kahi kokoke i ka huelo, ʻāpana poʻo:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // huki i nā mea i idx
                    self.copy(1, 0, idx);

                    // kope i ka mea hope loa i kahi kiko
                    self.copy(0, self.cap() - 1, 1);

                    // neʻe i nā mea mai ka huelo a i mua o ka waiho ʻana i ka mea hope loa
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Māhele i ka `VecDeque` i ʻelua ma ka papa kuhikuhi i hāʻawi ʻia.
    ///
    /// Hoʻihoʻi i kahi `VecDeque` hou i hoʻokaʻawale ʻia.
    /// `self` he mau kumuhana `[0, at)`, a he `[at, len)` ka i hoʻihoʻi ʻia.
    ///
    /// E hoʻomaopopo ʻaʻole e loli ka hiki o `self`.
    ///
    /// ʻO Element ma ka helu ʻo 0 ka mua o ka lālani.
    ///
    /// # Panics
    ///
    /// Panics inā `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` moe i ka hapa mua.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // e lawe wale i ka hapa lua.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` moe i ka hapa lua, pono e hoʻopili i nā mea a mākou i haʻalele ai i ka hapa mua.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Hoʻomaʻemaʻe kahi o nā wēlau o nā pale
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// E hoʻoneʻe i nā mea āpau o `other` i `self`, e waiho hakahaka nei i `other`.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka helu hou o nā mea i loko iā iā iho i `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// Mālama wale i nā mea i kuhikuhi ʻia e ka predicate.
    ///
    /// I nā huaʻōlelo ʻē aʻe, e hoʻoneʻe i nā mea āpau `e` e like me ka hoʻi ʻana o `f(&e)` i ka wahaheʻe.
    /// Ke hana nei kēia hana ma kahi, e kipa pololei ʻana i kēlā me kēia mea i ka hoʻonohonoho kumu, a mālama i ke kaʻina o nā mea i hoʻopaʻa ʻia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Pono paha ke kauoha kikoʻī no ka huli ʻana i ka moku kūwaho, e like me ka papa kuhikuhi.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Hiki iā panic a i ʻole kāpae ʻia
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // E pāpālua i ka nui o ka pale pale.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Hoʻololi i ka `VecDeque` ma kahi i like ai ka `len()` me `new_len`, ma ka hemo ʻana i nā mea keu mai ke kua a i ʻole ka hoʻopili ʻana i nā mea i hana ʻia e ke kāhea ʻana iā `generator` i ka hope.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Hoʻonohonoho hou i ka mālama kūloko o kēia deque no laila ʻo ia kahi ʻāpana pili loa, a hoʻihoʻi ʻia.
    ///
    /// ʻAʻole hoʻokaʻawale kēia hana a hoʻololi ʻole i ke kauoha o nā mea i hoʻokomo ʻia.Ke hoʻihoʻi nei i kahi ʻoki hiki ke hoʻololi, hiki ke hoʻohana ʻia kēia e hoʻokaʻawale i kahi deque.
    ///
    /// I ka manawa e pili pili ana ka waihona i loko, e hoʻihoʻi nā ʻano [`as_slices`] a me [`as_mut_slices`] i nā ʻike āpau o ka `VecDeque` i hoʻokahi ʻāpana.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ke hoʻokaʻina ʻana i ka ʻike o ka deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // hoʻokaʻina i ka deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // hoʻokaʻina ia i ka ʻaoʻao ʻaoʻao
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ke kiʻi ʻana i ke komo hiki ʻole i ka ʻāpana pili.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // hiki iā mākou ke maopopo i kēia manawa aia nā `slice` i nā mea āpau o ka deque, ʻoiai ke komo nei ʻole i `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // lawa lawa ka hakahaka e kope i ka huelo i ka manawa hoʻokahi, ʻo kēia ke hoʻololi mua i ke poʻo i hope, a laila kope i ka huelo i kahi kūpono.
            //
            //
            // mai: DEFGH .... ABC
            // i: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ʻAʻole mākou e noʻonoʻo i kēia manawa .... ABCDEFGH
            // e pili pili ana no ka mea ʻo `head` ka `0` i kēia hihia.
            // ʻOiai makemake mākou e hoʻololi i kēia ʻaʻole mea nui ia e like me kahi mau wahi e manaʻo ai ʻo `is_contiguous` e hiki iā mākou ke ʻokiʻoki i ka hoʻohana ʻana iā `buf[tail..head]`.
            //
            //

            // lawa lawa ka hakahaka e kope i ke poʻo i hoʻokahi manawa, ʻo kēia ke hoʻololi mua i ka huelo i mua, a laila kope i ke poʻo i kahi kūpono.
            //
            //
            // mai: FGH .... ABCDE
            // i: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // manuahi ka manuahi ma mua o ke poʻo a me ka hiʻu, ʻo kēia ka mea e lohi mākou i "swap" i ka huelo a me ke poʻo.
            //
            //
            // mai: EFGHI ... ABCD a i ʻole HIJK.ABCDEFG
            // i: ABCDEFGHI ... a i ʻole ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Ke nānā nei ka pilikia maʻamau e like me kēia GHIJKLM ... ABCDEF, ma mua o ka hoʻololi ʻana o ABCDEFM ... GHIJKL, ma hope o ka hala ʻana o 1 i nā swaps ABCDEFGHIJM ... KL, e kuapo a hiki i ka edge hema i ka hale kūʻai temp.
                //                  - a laila e hoʻomaka hou i ka algorithm me kahi hale kūʻai (smaller) hou i kekahi manawa e kiʻi ʻia ka hale kūʻai temp ke loaʻa ka edge pono i ka hope o ke buffer, ʻo ia hoʻi ua paʻi mākou i ke kauoha kūpono me nā swap liʻiliʻi!
                //
                // E.g
                // EF..ABCD ABCDEF .., ma hope o ʻehā mau swaps wale nō ua pau mākou
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Hoʻohuli i nā lālani `mid` kūlua i ka hema.
    ///
    /// Equivalently,
    /// - Hoʻohuli i ka mea `mid` i ke kūlana mua.
    /// - Pākuʻi i nā mea `mid` mua a pahu iā lākou a hiki i ka hopena.
    /// - Hoʻohuli i nā wahi `len() - mid` ma ka ʻākau.
    ///
    /// # Panics
    ///
    /// Inā ʻoi aku ka nui o `mid` ma mua o `len()`.
    /// E hoʻomaopopo he `mid == len()` ka _not_ panic a he hoʻohuli no-op.
    ///
    /// # Complexity
    ///
    /// Kiʻi `*O*(min(mid, len() - mid))` manawa, aʻaʻohe keu ka lewa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Hoʻohuli i nā lālani `k` kūlua i ka ʻākau.
    ///
    /// Equivalently,
    /// - Hoʻohuli i ka mea mua i ke kūlana `k`.
    /// - Pākuʻi i nā mea `k` hope loa a pahu aku iā lākou i mua.
    /// - Rotates `len() - k` mau wahi i ka hema.
    ///
    /// # Panics
    ///
    /// Inā ʻoi aku ka nui o `k` ma mua o `len()`.
    /// E hoʻomaopopo he `k == len()` ka _not_ panic a he hoʻohuli no-op.
    ///
    /// # Complexity
    ///
    /// Lawe ʻia ka manawa `*O*(min(k, len() - k))` a ʻaʻohe wahi keu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: ʻo nā ʻano ʻelua aʻe e koi i ka nui o ka hoʻohuli
    // e emi mai ma mua o ka hapalua o ka lōʻihi o ka deque.
    //
    // `wrap_copy` koi iā `min(x, cap() - x) + copy_len <= cap()`, akā ma mua o `min` ʻaʻole i ʻoi aku i ka hapalua o ka hiki, me ka nānā ʻole i ka x, no laila ke kani nei e kāhea ma aneʻi no ka mea ke kāhea nei mākou me kahi mea ma lalo o ka hapalua o ka lōʻihi, ʻaʻole ia ma luna o ka hapalua o ka hiki.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// ʻImi ʻo Binary i kēia `VecDeque` i hoʻokaʻina ʻia no kahi ʻenemi i hāʻawi ʻia.
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.
    /// Inā he mea mau ihoiho, a laila, hiki ke hoʻi kekahi i kekahi o na ihoiho.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā.
    /// Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Inā makemake ʻoe e hoʻokomo i kahi mea i `VecDeque` i hoʻokaʻawale ʻia, ʻoiai e mālama nei i ka ʻoka ʻoka:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ʻImi ʻo Binary i kēia `VecDeque` i hoʻokaʻawale ʻia me kahi hana hoʻohālikelike.
    ///
    /// Pono e hoʻokō i ka hana hoʻohālikelike i kahi kauoha kūlike me ke ʻano hoʻonohonoho o ka `VecDeque` ma lalo, e hoʻihoʻi nei i kahi code hoʻonohonoho e hōʻike ana inā `Less`, `Equal` a i ʻole `Greater` ka hoʻopaʻapaʻa ma mua o ka pahu hopu i makemake ʻia.
    ///
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.Inā he nui nā match, a laila hiki ke hoʻihoʻi ʻia kekahi o nā pāʻani.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā.Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ʻImi ʻo Binary i kēia `VecDeque` i hoʻokaʻawale ʻia me kahi hana hemo kī.
    ///
    /// Manaʻo ʻia ua hoʻokaʻawale ʻia ka `VecDeque` e ke kī, no ka laʻana me [`make_contiguous().sort_by_key()`](#method.make_contiguous) me ka hoʻohana ʻana i ka hana unuhi kī hoʻokahi.
    ///
    ///
    /// Inā loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Ok`], nona ka papa kuhikuhi o ka mea like.
    /// Inā he mea mau ihoiho, a laila, hiki ke hoʻi kekahi i kekahi o na ihoiho.
    /// Inā ʻaʻole i loaʻa ka waiwai a laila hoʻihoʻi ʻia ʻo [`Result::Err`], i loko o ka papa kuhikuhi kahi e hoʻokomo ʻia ai kahi mea like me ka mālama ʻana i ka hoʻonohonoho hoʻonohonoho.
    ///
    /// # Examples
    ///
    /// Nānā i kahi moʻo o nā mea ʻehā i kahi ʻāpana o nā hui i hoʻokaʻawale ʻia e ko lākou mau ʻaoʻao ʻelua.
    /// Loaʻa ka mea mua, me kahi kūlana kū hoʻokahi i hoʻoholo ʻia;ʻaʻole i loaʻa ka lua a me ke kolu;hiki i ka hā ke kūlike i kēlā me kēia kūlana ma `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Hoʻololi i ka `VecDeque` ma kahi i like ai ka `len()` me new_len, ma ka lawe ʻana paha i nā mea keu mai ka hope a i ʻole ka hoʻopili ʻana i nā clones o `value` i ka hope.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Hoʻihoʻi i ka papa kuhikuhi ma ka buffer kumu no kahi papa kuhikuhi kumu kūlike i hāʻawi ʻia.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // nui ka mana o 2 i ka nui
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// E helu i ka helu o nā mea i waiho ʻia e heluhelu ʻia i ka pale
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // nui ka mana o 2 i ka nui
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Maʻamau mau i nā ʻāpana ʻekolu, no ka laʻana: ʻo ʻoe iho: [a b c|d e f] ʻē aʻe: [0 1 2 3|4 5] mua=3, waena=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // ʻAʻole hiki ke hoʻohana i ka Hash::hash_slice ma nā ʻāpana i hoʻihoʻi ʻia e ka hana as_slices hiki ke loli ka lōʻihi i nā deque like ʻole.
        //
        //
        // Hāʻawi wale ʻo Hasher i ke kaulike no ke ʻano like o ke kāhea ʻana i kāna kiʻina hana.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Pau ka `VecDeque` i kahi iterator i mua a i hope e hāʻawi ana i nā mea e ka waiwai.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Kēia papa e ia i ka pono like o:
        //
        //      no ka mea i iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// E hoʻolilo i [`Vec<T>`] i [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Hōʻalo kēia i ka hoʻoili hou ʻana i kahi e hiki ai, akā ʻo nā kūlana no ka paʻakikī, a hiki ke loli, a no laila ʻaʻole pono e hilinaʻi ʻia inā ʻaʻole hele mai ka `Vec<T>` mai `From<VecDeque<T>>` a ʻaʻole i hāʻawi ʻia.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ʻAʻohe hoʻokaʻawale maoli no ZST e hopohopo e pili ana i ka hiki, akā ʻaʻole hiki iā `VecDeque` ke lawelawe i ka lōʻihi o `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Pono mākou e hoʻonui hou inā ʻaʻole ka mana o ka lua o ka mana, liʻiliʻi a ʻaʻohe paha ma kahi o hoʻokahi kahi manuahi.
            // Hana mākou i kēia ʻoiai ia i ka `Vec` no laila e hāʻule nā mea ma panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// E hoʻolilo i [`VecDeque<T>`] i [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ʻAʻole pono kēia e hoʻokaʻawale hou, akā pono e hana i ka neʻe ʻana o ka ʻikepili *O*(*n*) inā ʻaʻole ka buffer pōʻai i ka hoʻomaka o ka hoʻokaʻawale ʻana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // ʻO kēia ʻo *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Pono kēia i ka hoʻoponopono hou ʻana i ka ʻikepili.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}