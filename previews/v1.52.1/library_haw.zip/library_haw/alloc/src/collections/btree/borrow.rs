use core::marker::PhantomData;
use core::ptr::NonNull;

/// Hoʻohālikelike nā hiʻohiʻona i kahi kumuwaiwai kūʻokoʻa, ke ʻike ʻoe ʻaʻole e hoʻohana hou ʻia ka reb rebeta a me kāna mau keiki āpau (ʻo ia hoʻi, nā kuhi āpau a me nā kūmole mai ia mea) i kekahi manawa, a laila makemake ʻoe e hoʻohana hou i ke kūmole kū hoʻokahi. .
///
///
/// Mālama mau ka mea hōʻaiʻē i kēia kau ʻana o nā hōʻaiʻē nāu, akā ʻo kekahi mau kahe kaohi e hoʻokō i kēia kau ʻana he paʻakikī loa ia no ka mea hoʻopili e ukali ʻole ai.
/// Hāʻawi kahi `DormantMutRef` iā ʻoe e nānā i ka hōʻaiʻē iā ʻoe iho, ʻoiai e hōʻike mau nei i kāna ʻano stacked, a hoʻopili ʻia i ka helu kuhikuhi maka e pono ai e hana i kēia me ka lawehala ʻole.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Hopu i kahi hōʻaiʻē kū hoʻokahi, a reborrow koke ia.
    /// No ka mea hoʻouluulu, ʻo ke ola o ke kūmole hou ka mea like me ke ola o ke kūmole kumu, akā ʻo promise ʻoe e hoʻohana ia mea no kahi wā pōkole.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: paʻa mākou i ka hōʻaiʻē ma 'a ma o `_marker`, a hōʻike mākou
        // ʻo kēia kūmole wale nō, no laila kū hoʻokahi ia.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// E hoʻi i ka hōʻaiʻē ʻokoʻa i hopu mua ʻia.
    ///
    /// # Safety
    ///
    /// Pono e pau ka reborrow, ʻo ia hoʻi, ka hoʻihoʻi i hoʻihoʻi ʻia e `new` a me nā kuhikuhi a pau a me nā kūmole i loaʻa mai iā ia, pono ʻole e hoʻohana hou ʻia.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: ko mākou kūlana palekana ponoʻī e hōʻike ana he kū hoʻokahi kēia kūmole.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;