use core::intrinsics;
use core::mem;
use core::ptr;

/// Kēia replaces i ka waiwai ma ke kua o ka `v` hanana kūmole ma ka pili kuleana pili i kahea.
///
///
/// Inā kū panic i ka pani `change`, e hoʻopau ʻia ke kaʻina holoʻokoʻa.
#[allow(dead_code)] // mālama e like me ke kiʻi a no future hoʻohana
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Hoʻololi kēia i ka waiwai ma hope o ka `v` kūmole kūmole ma ke kāhea ʻana i ka hana kūpono, a hoʻihoʻi i kahi hopena i loaʻa ma ke ala.
///
///
/// Inā kū panic i ka pani `change`, e hoʻopau ʻia ke kaʻina holoʻokoʻa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}