use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Kora o kahi iterator e hoʻopili i ka hopena o nā iterator piʻi piʻi ʻelua, e like me kahi uniona a i ʻole ʻokoʻa symmetric.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// ʻOi aku ka wikiwiki o nā Benchmarks ma mua o ke ʻōwili ʻana i nā iterator ʻelua i kahi Peekable, no ka mea hiki iā mākou ke hoʻokau i kahi FusedIterator i hoʻopaʻa ʻia.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Hoʻokumu i kumu nui no ka iterator e hoʻohui nei i nā kumuwaiwai ʻelua.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Hoʻihoʻi mai i nā mea kūʻelua e kū mai ana ma ka hui pūʻana o nā kumuwaiwai.
    /// Inā loaʻa ka waiwai i nā koho ʻelua i hoʻihoʻi ʻia, like ia waiwai a loaʻa i nā kumuwaiwai ʻelua.
    /// Inā loaʻa kahi waiwai i kekahi o nā koho i hoʻihoʻi ʻia, ʻaʻole kū kēlā waiwai i kahi kumu ʻē aʻe (a i ʻole piʻi piʻi nā kumu.
    ///
    /// Inā ʻaʻole i loaʻa i kahi koho i hoʻihoʻi ʻia kahi waiwai, ua pau ka hana a me nā kāhea hou ʻana e hoʻihoʻi i ka lua hakahaka like.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Hoʻihoʻi i kahi mau palena o luna no ka `size_hint` o ka iterator hope.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}