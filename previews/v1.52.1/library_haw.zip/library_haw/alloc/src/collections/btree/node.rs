// He hoʻāʻo kēia i ka hoʻokō ma hope o ka pono
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Ma muli o ka loaʻa ʻole o Rust i nā ʻano hilinaʻi a me ka recursion polymorphic, hana mākou me ka palekana ʻole.
//

// ʻO ka pahuhopu nui o kēia module ka mea e hōʻalo ai i ka paʻakikī ma ka mālama ʻana i ka lāʻau ma ke ʻano he generic (inā ʻano ʻē) a me ka pale ʻana i ka hana me ka hapa nui o ka poʻe B-Tree invariants.
//
// E like me kēia, ʻaʻole mālama kēia module inā hoʻokaʻawale ʻia nā mea hoʻokomo, kahi o nā aka e hiki ai ke underfull, a i ʻole ke ʻano o ka manaʻo underfull.Eia nō naʻe, ke hilinaʻi nei mākou i kekahi mau invariants:
//
// - Pono nā kumulāʻau e like me depth/height.ʻO kēia ke kumu o kēlā me kēia ala i lalo i kahi lau mai kahi node i hāʻawi ʻia i like ka lōʻihi me ka lōʻihi.
// - ʻO kahi pona o ka lōʻihi `n` he mau kī `n`, nā waiwai `n`, a me nā kihi `n + 1`.
//   Hōʻike kēia i kahi node hakahaka ma kahi o hoʻokahi edge.
//   No kahi pihi lau, "having an edge" wale nō ke hiki iā mākou ke ʻike i kahi kūlana i ka piko, no ka mea hakahaka nā ʻaoʻao lau a ʻaʻohe pono e hōʻike i kahi ʻikepili.
// I loko o kahi piko kūloko, kahi edge e hōʻike nei i kahi kūlana a loaʻa kahi kuhikuhi i kahi pihi keiki.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ʻO ka hōʻike ma lalo o nā piko lau a me kahi ʻāpana o ka hōʻike i nā piko kūloko.
struct LeafNode<K, V> {
    /// Makemake mākou e lilo i covariant ma `K` a me `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Kuhi kēia helu i ka helu `edges` o ka pona makua.
    /// `*node.parent.edges[node.parent_idx]` pono like ia me `node`.
    /// Hōʻoia wale ʻia kēia e hoʻomaka mua ʻia inā `parent` ʻole ʻole.
    parent_idx: MaybeUninit<u16>,

    /// ʻO ka helu o nā kī a me nā waiwai i kēia hale kūʻai node.
    len: u16,

    /// Ke mālama nei nā hoʻonohonoho i ka ʻikepili maoli o ka piko.
    /// ʻO nā mea `len` mua wale nō o kēlā me kēia lālani e hoʻomaka a pololei.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Hoʻomaka i kahi `LeafNode` hou ma kahi.
    unsafe fn init(this: *mut Self) {
        // Ma ke ʻano he kulekele maʻamau, waiho mākou i nā kahua uninitialized inā hiki, no ka mea, ʻoi aku ka wikiwiki a me ka maʻalahi o ka hahai ʻana ma Valgrind.
        //
        unsafe {
            // makua_idx, nā kī, a me nā vals a pau paha ʻo MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Hana i kahi `LeafNode` pahu hou.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// ʻO ka hōʻike kumu o nā piko kūloko.E like me nā `LeafNode`, pono e hūnā ʻia kēia mau mea ma hope o 'BoxedNode` e pale ai i ka hoʻokuʻu ʻana i nā kī a me nā loina uninitialized.
/// Hiki ke hoʻolei pololei ʻia kekahi kuhikuhi i ka `InternalNode` i kahi kuhikuhi i ka mahele `LeafNode` o ka piko, e ʻae ana i ka pāʻālua e hana ma nā lau a me nā pona kūloko me ka ʻole e nānā pono i ka ʻelua o ke kuhikuhi a ke kuhikuhi.
///
/// Hiki i kēia waiwai ke hoʻohana ʻia e `repr(C)`.
///
#[repr(C)]
// gdb_providers.py hoʻohana i kēia inoa ʻano no ka nānā pono ʻana.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ʻO nā kuhikuhi i nā keiki o kēia piko.
    /// `len + 1` ʻo kēia mau mea i manaʻo ʻia ua hoʻomaka a kūpono, koe wale nō ma kahi kokoke i ka hopena, ʻoiai e paʻa ka lāʻau ma o ka loan type `Dying`, aia kekahi o kēia mau kuhikuhi.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Hana i kahi `InternalNode` pahu hou.
    ///
    /// # Safety
    /// ʻO kahi invariant o nā piko kūloko ka mea i loaʻa iā lākou ma kahi o hoʻokahi edge i hoʻokumu ʻia a kūpono.
    /// ʻAʻole hoʻonohonoho kēia hana i kahi edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Pono mākou e hoʻomaka mua i ka ʻikepili;ʻo nā kihi paha ʻoUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Kuhi kuhikuhi, kuhikuhi ʻole i ka piko.He kuhikuhi paha kēia iā `LeafNode<K, V>` a i ʻole kuhikuhi kuhikuhi iā `InternalNode<K, V>`.
///
/// Eia nō naʻe, ʻaʻohe ʻikepili ma `BoxedNode` no nā ʻano ʻelua o nā aka i loaʻa maoli iā ia, a, hapa ma muli o kēia nele o ka ʻike, ʻaʻole ia he ʻano kaʻawale a ʻaʻohe ona mea hōʻemi.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ʻO ke aʻa aʻa o kahi kumulāʻau ponoʻī.
///
/// E hoʻomaopopo ʻaʻohe ona mea hōʻemi kēia, a pono e hoʻomaʻemaʻe lima ʻia.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Hoʻihoʻi i kahi lāʻau hou, me kona aʻa ponoʻī i hakahaka mua.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` pono ʻole e nul.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Hoʻolālā ʻo Mutable i ke aʻa aʻa paʻa.
    /// ʻAʻole like me `reborrow_mut`, palekana kēia no ka mea ʻaʻole hiki ke hoʻohana i ka waiwai hoʻihoʻi e luku i ke aʻa, a ʻaʻohe hiki ke kuhikuhi ʻia i ka lāʻau.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hoʻololi iki i ka pihi aʻa paʻa.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hoʻololi hoʻololi i kahi kuhikuhi e ʻae ai i ke kaʻahele a hāʻawi i nā hana luku a me kahi mea ʻē aʻe.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Hoʻohui i kahi piko kūloko me kahi edge hoʻokahi e kuhikuhi ana i ke aʻa kumu mua, e hana i kēlā piko hou i ke aʻa aʻa, a hoʻihoʻi iā ia.
    /// Hoʻonui kēia i ke kiʻekiʻe e 1 a ʻo ka ʻaoʻao ʻē aʻe o `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, koe wale no ua poina iā mākou aia mākou i loko i kēia manawa:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Wehe i ke aʻa aʻa kūloko, me ka hoʻohana ʻana i kāna keiki mua ma ke ʻano he aʻa hou.
    /// E like me ka mea i manaʻo wale ʻia ai e kāhea ʻia ke ke aʻa aʻa hoʻokahi wale nō keiki, ʻaʻohe hoʻomaʻemaʻe e hana ʻia ma nā kī, nā waiwai a me nā keiki ʻē aʻe.
    ///
    /// Hoʻoiho kēia i ke kiʻekiʻe e 1 a ʻo ka ʻaoʻao ʻē aʻe o `push_internal_level`.
    ///
    /// Koi aku i ke komo ʻana i ka mea `Root` akā ʻaʻole i ke kumu kumu;
    /// ʻaʻole ia e hōʻoia i nā lima ʻē aʻe a i ʻole nā kuhikuhi i ke kō aʻa.
    ///
    /// Panics inā ʻaʻohe pae o loko, ʻo ia hoʻi, inā he lau ke kumu o ke aʻa.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: ua hōʻoia mākou i loko.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: ua hōʻaiʻē wale mākou iā `self` a kū hoʻokahi kāna ʻano ʻaiʻē.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAFETY: ka edge mua e hoʻomaka mua ʻia.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. ʻO `NodeRef` ka covariant mau ma `K` a me `V`, ʻoiai ʻo `BorrowType` `Mut`.
// He hewa ʻenehana kēia, akā ʻaʻole hiki ke hopena i kahi palekana ʻole ma muli o ka hoʻohana kūloko o `NodeRef` no ka mea noho paʻa mau mākou ma luna o `K` a me `V`.
//
// Eia nō naʻe, i kēlā me kēia manawa ke ʻūlū ʻia e kahi ʻano lehulehu `NodeRef`, e ʻike pono he ʻokoʻa pololei kāna.
//
/// ʻO kahi kuhikuhi i kahi piko.
///
/// Loaʻa i kēia ʻano nā helu o nā palena e kaohi ana pehea e hana ai:
/// - `BorrowType`: He ʻano dummy e wehewehe ana i ke ʻano o ka hōʻaiʻē a hāpai i ke ola holoʻokoʻa.
///    - Ke `Immut<'a>` kēia, hana ʻino ka `NodeRef` e like me `&'a Node`.
///    - Ke `ValMut<'a>` kēia, hana ʻino ka `NodeRef` e like me `&'a Node` e pili ana i nā kī a me ke kumu lāʻau, akā ʻae pū kekahi i nā kuhikuhi i hiki ke hoʻololi ʻia i nā waiwai āpau o ka lāʻau e noho pū.
///    - Ke `Mut<'a>` kēia, hana ʻino ka `NodeRef` e like me `&'a mut Node`, ʻoiai e hoʻokomo i nā ʻano hana i kahi kuhikuhi i hiki ke hoʻololi ʻia i kahi waiwai e noho pū.
///    - Ke `Owned` kēia, hana ʻino ka `NodeRef` e like me `Box<Node>`, akā ʻaʻohe ona mea hoʻopau, a pono e hoʻomaʻemaʻe lima ʻia.
///    - Ke `Dying` kēia, hana ʻino ka `NodeRef` e like me `Box<Node>`, akā he mau ʻano hana e luku iki i ka lāʻau, a me nā ʻano maʻamau, ʻoiai ʻaʻole māka ʻia e palekana ʻole e kāhea, hiki ke kāhea iā UB inā kāhea hewa ʻia.
///
///   ʻOiai ʻo `NodeRef` e ʻae i ka hoʻokele ma waena o ka lāʻau, pili pono ʻo `BorrowType` i ka lāʻau holoʻokoʻa, ʻaʻole wale i ka piko ponoʻī.
/// - `K` a me `V`: ʻO kēia ke ʻano o nā kī a me nā waiwai i mālama ʻia i nā piko.
/// - `Type`: Hiki iā `Leaf`, `Internal`, a i `LeafOrInternal` paha kēia.
/// Ke `Leaf` kēia, kuhikuhi ka `NodeRef` i kahi pihi lau, ke `Internal` kēia ka `NodeRef` kuhikuhi i kahi piko kūloko, a i kēia `LeafOrInternal` hiki i ka `NodeRef` ke kuhikuhi i kēlā me kēia ʻano node.
///   `Type` inoa ʻo `NodeType` ke hoʻohana ʻia ma waho o `NodeRef`.
///
/// Hoʻopaʻa nā `BorrowType` a me `NodeType` i nā ʻano hana a mākou e hoʻokō ai, e hoʻohana ai i ka palekana ʻano kūpaʻa.Aia nā palena i ke ala e hiki ai iā mākou ke noi i kēlā mau kapu:
/// - No kēlā me kēia ʻāpana, hiki iā mākou ke wehewehe i kahi hana i ka laulima a i ʻole no hoʻokahi ʻano kikoʻī.
/// ʻO kahi laʻana, ʻaʻole hiki iā mākou ke wehewehe i kahi hana e like me `into_kv` maʻamau no nā `BorrowType` āpau, a i hoʻokahi manawa paha no nā ʻano āpau e halihali i ke ola holoʻokoʻa, no ka mea makemake mākou e hoʻihoʻi i nā kuhikuhi `&'a`.
///   No laila, wehewehe mākou no ka `Immut<'a>` mana ikaika liʻiliʻi loa.
/// - ʻAʻole hiki iā mākou ke loaʻa ka hoʻokūkū implicit mai ka ʻōlelo `Mut<'a>` a i `Immut<'a>`.
///   No laila, pono mākou e kāhea akaka iā `reborrow` ma kahi `NodeRef` iʻoi aku ka ikaika i mea e hiki ai i kahi ala e like me `into_kv`.
///
/// Nā kiʻina hana āpau ma `NodeRef` e hoʻihoʻi i kekahi ʻano kuhikuhi, a i ʻole:
/// - Lawe iā `self` i ka waiwai, a hoʻihoʻi i ke ola i hāpai ʻia e `BorrowType`.
///   I kekahi manawa, e kāhea i kēlā ʻano hana, pono mākou e kāhea iā `reborrow_mut`.
/// - E lawe iā `self` ma ke kūmole, a (implicitly) e hoʻihoʻi i kēlā ola i kēlā kūmole, ma kahi o ke ola i hāpai ʻia e `BorrowType`.
/// ʻO kēlā ala, hōʻoia ka mea hōʻaiʻē i ka `NodeRef` i hōʻaiʻē ʻia inā hoʻohana ʻia ke kuhikuhi i hoʻihoʻi ʻia.
///   ʻO nā kiʻina e kākoʻo ana e hoʻopili i kēia lula ma ka hoʻihoʻi ʻana i kahi kuhikuhi maka, ʻo ia hoʻi, kahi kuhikuhi me ka ʻole o ke ola.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// I ka helu ana o ka 'ilikai ai i ka'āina, a me ka nui o ka lau i ke kaʻawale, he ikaika o ka'āina i hiki ole e ho'ākāka' ia ma loa e `Type`, a me ka mea o ka'āina iho, aole ia i hoahu.
    /// Pono mākou e mālama i ke kiʻekiʻe o ke aʻa aʻa, a loaʻa mai ke kiʻekiʻe o kēlā me kēia ʻē aʻe.
    /// Pono ʻole inā `Type` ka `Leaf` a me ka ʻole ʻole inā `Type` ʻo `Internal`.
    ///
    ///
    height: usize,
    /// ʻO ka pointer i ka lau a i ʻole node i loko.
    /// ʻO ka wehewehe ʻana o `InternalNode` e hōʻoia i ka pololei o ka kuhikuhi i kēlā me kēia ala.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Wehe i kahi kuhikuhi node i ʻūlū ʻia e like me `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Hōʻike i ka ʻikepili o kahi piko kūloko.
    ///
    /// Hoʻihoʻi i kahi ptr maka e pale i ka hōʻoia ʻole ʻana i nā kuhikuhi ʻē aʻe i kēia node.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: ʻo ka ʻano node kūpaʻa ʻo `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Loaʻa iā ia ke komo ʻana i ka ʻikepili o kahi piko kūloko.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ʻImi i ka lōʻihi o ka piko.ʻO kēia ka helu o nā kī a i ʻole nā waiwai.
    /// ʻO `len() + 1` ka helu o nā kihi.
    /// E hoʻomaopopo, ʻoiai ʻo ka palekana, ke kāhea ʻana i kēia hana hiki ke loaʻa i ka hopena o ka invalidating mutable kūmole a unsafe code i hana ai.
    ///
    pub fn len(&self) -> usize {
        // ʻO ke koʻikoʻi, komo wale mākou i ka māla `len` ma aneʻi.
        // Inā marker::ValMut ka BorrowType, aia paha he mau kuhikuhi kūwaliwali koʻikoʻi i nā waiwai e pono ʻole ai mākou e hōʻoia.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Hoʻihoʻi i ka helu o nā pae i kaʻawale ka piko a me nā lau.
    /// ʻO ke kiʻekiʻe o Zero ʻo ia hoʻi ka piko he lau ponoʻī.
    /// Inā kiʻi ʻoe i nā lāʻau me ke aʻa ma luna, e ʻōlelo ka helu ma kahi e ʻike ʻia ai ke piko.
    /// Inā kiʻi ʻoe i nā lāʻau me nā lau ma luna, ʻōlelo ka helu i ke kiʻekiʻe o ka lāʻau ma luna o ka piko.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Lawe ka manawa i kahi ʻē aʻe, kuhikuhi ʻole i ka piko like.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hōʻike i ka ʻāpana lau o kekahi lau a i ʻole piko kūloko.
    ///
    /// Hoʻihoʻi i kahi ptr maka e pale i ka hōʻoia ʻole ʻana i nā kuhikuhi ʻē aʻe i kēia node.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Pono pono ke pona no ka liʻiliʻi o ka mahele LeafNode.
        // ʻAʻole kēia he kuhikuhi ma ka ʻano NodeRef no ka mea ʻaʻole mākou ʻike inā he kū hoʻokahi a i ʻole kaʻana like ʻia.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// E ʻike i ka makua o ka piko o kēia manawa.
    /// Hoʻi iā `Ok(handle)` inā he makua maoli ka piko o kēia manawa, kahi `handle` e kuhikuhi ai i ka edge o ka makua e kuhikuhi ana i ka piko o kēia manawa.
    ///
    /// Hoʻi iā `Err(self)` inā ʻaʻohe makua o ka piko o kēia manawa, e hoʻihoʻi i ka `NodeRef` kumu.
    ///
    /// Hāʻawi ka inoa hana iā ʻoe i nā lāʻau kiʻi me ke aʻa aʻa ma luna.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` pono lāua ʻelua, ke kūleʻa, hana ʻole i kekahi mea.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Pono mākou e hoʻohana i nā kuhikuhi maka i nā aka no ka mea, inā he marker::ValMut ka BorrowType, aia paha he mau kuhikuhi kūwaho kūwaho i nā waiwai e pono ʻole ai mākou e holoi.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// E hoʻomaopopo he pono ʻole ka `self`.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// E hoʻomaopopo he pono ʻole ka `self`.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Hōʻike i ka ʻāpana lau o nā lau a i ʻole i loko i loko o kahi kumulāʻau hoʻololi ʻole.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: ʻaʻole hiki ke hoʻololi i nā kumulāʻau i loko o kēia lāʻau i hōʻaiʻē ʻia e like me `Immut`.
        unsafe { &*ptr }
    }

    /// Hōʻike hōʻaiʻē i nā kī i mālama ʻia i ka piko.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// E like me `ascend`, loaʻa kahi kuhikuhi i ka piko o ka piko o ka piko, akā hana pū kekahi i ka piko o kēia manawa i ke kaʻina.
    /// Palekana kēia no ka mea e hiki ke kiʻi ʻia i kēia pona me ka lawe ʻia ʻana o kahi wahi.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Hōʻoia ʻiʻo ʻole i ka mea nāna e hōʻuluʻulu i ka ʻike kūpaʻa o kēia node he `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hōʻoia ʻiʻo ʻole i ka mea nāna e hōʻuluʻulu i ka ʻike kūpaʻa o kēia node he `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Lawe ka manawa i kahi ʻē aʻe, hiki ke hoʻololi i ka piko like.E makaʻala, no ka mea weliweli loa kēia hana, pālua pēlā no ka mea ʻaʻole ʻike ʻia ka weliweli.
    ///
    /// Ma muli o ka hiki ke holoholo ma nā wahi āpau a puni ka lāʻau, hiki ke hoʻohana maʻalahi ʻia ka pointer e hoʻoliʻiliʻi ai i ka kuhikuhi kuhikuhi, ma waho o nā palena, a i ʻole kūpono ʻole paha ma lalo o nā lula hōʻaiʻe.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) e noʻonoʻo e hoʻohui i kahi ʻano ʻē aʻe i `NodeRef` e kaohi ana i ka hoʻohana ʻana o nā ʻano hoʻokele i nā kuhikuhi kope ʻia, e pale ana i kēia palekana.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hōʻike noi komo i ka ʻāpana lau o kēlā me kēia lau a i ʻole pona kūloko.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: hiki iā mākou ke komo i ka piko holoʻokoʻa.
        unsafe { &mut *ptr }
    }

    /// Hāʻawi i kahi komo kūikawā i ka ʻāpana lau o kekahi lau a i ʻole piko kūloko.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: hiki iā mākou ke komo i ka piko holoʻokoʻa.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nonoi i ke komo ʻana i kahi ʻāpana o ka wahi mālama nui.
    ///
    /// # Safety
    /// `index` aia ma nā palena o 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAFETY: ʻaʻole hiki i ka mea kelepona ke kāhea i nā ʻano hana hou iā ʻoe iho
        // a hiki i ka hāʻule ʻana o ka ʻāpana ʻāpana kī, no ka mea hiki iā mākou ke komo ʻokoʻa no ke ola o ka hōʻaiʻē.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Nonoi i ke komo ʻana i kahi ʻāpana a i ʻole kahi ʻāpana o ka wahi mālama waiwai o ka pona.
    ///
    /// # Safety
    /// `index` aia ma nā palena o 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAFETY: ʻaʻole hiki i ka mea kelepona ke kāhea i nā ʻano hana hou iā ʻoe iho
        // a hiki i ka hāʻule ʻana o ka ʻāpana o ka ʻāpana waiwai, ʻoiai hiki iā mākou ke komo ʻokoʻa no ke ola āpau o ka hōʻaiʻē.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Loaʻa iā ia ke komo ʻana i kahi ʻāpana a i ʻole ka ʻāpana o ka wahi mālama o ka piko no edge ʻike.
    ///
    /// # Safety
    /// `index` aia ma nā palena o 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAFETY: ʻaʻole hiki i ka mea kelepona ke kāhea i nā ʻano hana hou iā ʻoe iho
        // a hiki i ka hāʻule ʻana o ka ʻāpana slam edge, no ka mea he hiki ʻokoʻa kā mākou i ke ola o ka hōʻaiʻē.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - ʻOi aku ka nui o ka node ma mua o `idx` mau mea i hoʻomaka mua ʻia.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Hoʻokumu wale mākou i kahi kuhikuhi i kahi mea hoʻokahi a mākou e makemake ai, e hōʻalo i ka alahaka ʻana me nā kuhikuhi koʻikoʻi i nā kumu ʻē aʻe, i ka mea hoʻi, i hoʻihoʻi ʻia i ka mea kāhea i nā ʻōlelo i hōʻike mua ʻia.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Pono mākou e koi aku i nā helu kuhikuhi i hoʻonohonoho ʻole ʻia no Rust puka #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Hōʻike noi komo i ka loa o ka piko.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Hoʻonohonoho i ka loulou o ka piko i kona makua edge, me ka ʻole o ka hōʻoia ʻole ʻana i nā kuhikuhi ʻē aʻe i ka piko.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Holoi i ka loulou o ke aʻa i kāna makua edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Hoʻohui i kahi pālua waiwai i ka hope o ka piko.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// ʻO kēlā me kēia mea i hoʻihoʻi ʻia e `range` kahi helu edge kūpono no ka piko.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Hoʻohui i kahi pālua waiwai nui, a me edge e hele i ka ʻākau o kēlā paʻa, i ka hope o ka piko.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Nānā inā he node he `Internal` piko a i ʻole he `Leaf` piko.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Kahi kuhikuhi i kahi kikoʻī kī-kikoʻī kikoʻī a i ʻole edge i loko o kahi kōpili.
/// Pono ka `Node` parameter i `NodeRef`, ʻoiai ʻo `Type` hiki ke lilo i `KV` (e kuhikuhi ana i kahi lima ma kahi pālua-kī nui) a i ʻole `Edge` (e kuhikuhi ana i kahi lima ma edge).
///
/// E hoʻomaopopo he hiki i nā kikowaena `Leaf` ke loaʻa i nā lima `Edge`.
/// Ma kahi o ke koho ʻana i kahi kuhikuhi i kahi node keiki, hōʻike kēia i nā hakahaka e hele ai nā mea kuhikuhi keiki ma waena o nā paʻa waiwai nui.
/// ʻO kahi laʻana, i kahi piko me ka lōʻihi 2, aia he 3 hiki i nā wahi edge, hoʻokahi ma ka hema o ka piko, hoʻokahi ma waena o nā pālua, a hoʻokahi ma ka ʻākau o ka piko.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ʻAʻole mākou e pono i ka laulā holoʻokoʻa o `#[derive(Clone)]`, ʻoiai ʻo `Node` wale nō ka manawa e lilo ʻo "Clone`able i ka manawa he kuhikuhi hiki ʻole ke hoʻololi a no laila `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Hōʻawi i ka piko i loaʻa ka edge a i ʻole paʻa waiwai nui i kuhikuhi ʻia e kēia lima.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Hoʻihoʻi i ke kūlana o kēia ʻau i ka piko.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Hana i kahi lima hou i kahi paʻa waiwai nui ma `node`.
    /// Palekana ʻole no ka mea pono e hōʻoia ka mea e kāhea iā `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Hiki i kahi hoʻokō ākea o PartialEq, akā hoʻohana wale ʻia i kēia module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Lawe ka manawa i kahi ʻau lawelawe ʻole e hiki ke hoʻololi ʻia ma ka wahi like.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ʻAʻole hiki iā mākou ke hoʻohana iā Handle::new_kv a i ʻole Handle::new_edge no ka mea ʻaʻole maopopo iā mākou ko mākou ʻano
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Hōʻoia ʻiʻo ʻole i ka mea hōʻuluʻulu i ka ʻike kūpaʻa o ka piko o ka lima he `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Lawe kuikawa i kahi lima ʻē aʻe hiki ke hoʻololi ʻia ma ka wahi like.
    /// E makaʻala, no ka mea weliweli loa kēia hana, pālua pēlā no ka mea ʻaʻole ʻike ʻia ka weliweli.
    ///
    ///
    /// No nā kikoʻī, e ʻike iā `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ʻAʻole hiki iā mākou ke hoʻohana iā Handle::new_kv a i ʻole Handle::new_edge no ka mea ʻaʻole maopopo iā mākou ko mākou ʻano
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Hana i kahi lima hou i kahi edge ma `node`.
    /// Palekana ʻole no ka mea pono e hōʻoia ka mea e kāhea iā `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Hāʻawi ʻia i kahi helu edge kahi e makemake ai mākou e hoʻokomo i kahi piko i piha i ka hiki, helu i kahi helu KV kūpono o kahi kiko hoʻokaʻawale a me kahi e hana ai i ka hoʻokomo.
///
/// ʻO ka pahuhopu o ka māhele hoʻokaʻawale no kāna kī a me kona waiwai e hoʻopau i kahi pona makua;
/// nā kī, nā waiwai a me nā kihi i ka hema o ke kiko hoʻokaʻawale i lilo i keiki hema;
/// nā kī, nā waiwai a me nā kihi i ka ʻākau o ka māhele hoʻokaʻawale e lilo i keiki kūpono.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust hoʻopuka #74834 e hoʻāʻo e wehewehe i kēia mau rula symmetric.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Hoʻokomo i kahi pālua-helu waiwai hou ma waena o nā paʻa hua nui i ka ʻākau a me ka hema o kēia edge.
    /// Kuhi kēia hana aia lawa ka hakahaka i ka piko no ke komo o ka lua hou.
    ///
    /// Kuhi ka mea kuhikuhi i ka waiwai i hoʻokomo ʻia.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Hoʻokomo i kahi pālua-helu waiwai hou ma waena o nā paʻa hua nui i ka ʻākau a me ka hema o kēia edge.
    /// Māhele kēia hana i ka piko inā ʻaʻole lawa kahi lumi.
    ///
    /// Kuhi ka mea kuhikuhi i ka waiwai i hoʻokomo ʻia.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixes ka makua laʻau kuhikuhi a me ka 'inideka i loko o ke keiki wahi i keia edge e loulou iho ai i.
    /// He mea maikaʻi kēia ke hoʻololi ʻia ke kauoha o nā lihi,
    fn correct_parent_link(self) {
        // E hana i backpointer me ka ʻole o ka hōʻoia ʻole i nā kuhikuhi ʻē aʻe i ka piko.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Hoʻokomo i kahi pālua-kī hou a me edge e hele i ka ʻākau o kēlā pālua hou ma waena o kēia edge a me ka paʻa waiwai nui i ka ʻākau o kēia edge.
    /// Kuhi kēia hana aia lawa ka hakahaka i ka piko no ke komo o ka lua hou.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Hoʻokomo i kahi pālua-kī hou a me edge e hele i ka ʻākau o kēlā pālua hou ma waena o kēia edge a me ka paʻa waiwai nui i ka ʻākau o kēia edge.
    /// Māhele kēia hana i ka piko inā ʻaʻole lawa kahi lumi.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Hoʻokomo i kahi pālua-helu waiwai hou ma waena o nā paʻa hua nui i ka ʻākau a me ka hema o kēia edge.
    /// Hoʻokaʻawale kēia hana i ka piko inā ʻaʻole lawa ka lumi, a hoʻāʻo e hoʻokomo i ka ʻāpana hoʻokaʻawale i ka piko makua me ka hoʻihoʻi ʻana, a hiki i ka loaʻa ʻana o ke aʻa.
    ///
    ///
    /// Inā he `Fit` ka hopena i hoʻihoʻi ʻia, hiki i ka piko o kona lima ke kōnane o edge a i kūpuna paha.
    /// Inā he `Split` ka hopena i hoʻihoʻi ʻia, ʻo ka māla `left` ke kumu kumu.
    /// Kuhi ka mea kuhikuhi i ka waiwai i hoʻokomo ʻia.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ʻIke i ka piko i kuhikuhi ʻia e kēia edge.
    ///
    /// Hāʻawi ka inoa hana iā ʻoe i nā lāʻau kiʻi me ke aʻa aʻa ma luna.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` pono lāua ʻelua, ke kūleʻa, hana ʻole i kekahi mea.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Pono mākou e hoʻohana i nā kuhikuhi maka i nā aka no ka mea, inā he marker::ValMut ka BorrowType, aia paha he mau kuhikuhi kūwaho kūwaho i nā waiwai e pono ʻole ai mākou e holoi.
        // ʻAʻohe hopohopo i ke kiʻi ʻana i ke kahua kiʻekiʻe no ka mea ua kope ʻia kēlā waiwai.
        // E makaʻala, i ka manawa e hoʻopau ʻole ʻia ai ka helu kuhikuhi node, hiki iā mākou ke komo i nā lālani palena me kahi kuhikuhi (Rust hoʻopuka #73987) a hōʻole ʻole i nā kuhikuhi ʻē aʻe i a i ʻole i loko o ka lālani, aia a puni paha.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ʻAʻole hiki iā mākou ke kāhea i nā kī hoʻokaʻawale a me nā ʻano waiwai, no ka mea, ʻo ke kāhea ʻana i ka lua e hōʻoia ʻole i ke kūmole i hoʻihoʻi ʻia e ka mea mua.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// E kuapo i ke kī a me ka waiwai a ka KV lima e kuhikuhi ai.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Kōkua i ka hoʻokō ʻana o `split` no kahi `NodeType` kikoʻī, ma ka mālama ʻana i ka ʻikepili lau.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Māhele i ka piko i lalo i ʻekolu mau ʻāpana:
    ///
    /// - Hoʻokiʻoki ʻia ka piko e loaʻa wale nā paʻa kī-nui i ka hema o kēia ʻau.
    /// - Lawe ʻia ke kī a me ka waiwai i kuhikuhi ʻia e kēia lima.
    /// - Hoʻokomo ʻia nā pālua-waiwai āpau i ka ʻākau o kēia ʻau i loko o kahi kōpana hou.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Wehe i ka pālua-waiwai i kuhikuhi ʻia e kēia lima a hoʻihoʻi iā ia, me edge i hāneʻe ʻia e ka lua waiwai nui.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Māhele i ka piko i lalo i ʻekolu mau ʻāpana:
    ///
    /// - Hoʻokiʻoki ʻia ka piko e loaʻa wale nā kihi a me nā paʻa waiwai-nui i ka hema o kēia ʻau.
    /// - Lawe ʻia ke kī a me ka waiwai i kuhikuhi ʻia e kēia lima.
    /// - Hoʻokomo ʻia nā kihi a pau a me nā paʻa waiwai-nui i ka ʻaoʻao ʻākau o kēia ʻau i loko o kahi piko i hāʻawi ʻia.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ke pani nei i kahi kau no ka loiloi a me ka hana ʻana i kahi hana ke kaulike ma kahi o nā paʻa waiwai nui kūloko.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Koho i ka pōʻaiapili e pili ana i ka piko ma ke ʻano he keiki, no laila ma waena o ka KV koke i ka hema a i ka ʻākau paha i ka piko makua.
    /// Hoʻihoʻi i kahi `Err` inā ʻaʻohe makua.
    /// Panics inā hakahaka ka makua.
    ///
    /// Makemake i ka ʻaoʻao hema, e ʻoi aku ka maikaʻi inā hāʻawi ʻia ka piko i lalo o kahi ʻano, ʻo ia hoʻi ma aneʻi he hapa kona mau mea ma mua o kona kaikaina hema a ma mua o kona kaikaina ʻākau, inā aia lākou.
    /// I kēlā hihia, ʻoi aku ka wikiwiki o ka hui ʻana me ke kaikaina hema, ʻoiai mākou e neʻe wale i nā ʻaoʻao N o ka piko, ma kahi o ka hoʻohuli ʻana iā lākou i ka ʻākau a neʻe i mua o nā mea N i mua.
    /// ʻO ka ʻaihue ʻana mai ke kaikaina hema ka ʻoi aku ka wikiwiki, ʻoiai mākou wale nō e neʻe i nā ʻaoʻao N o ka piko i ka ʻākau, ma kahi o ka neʻe ʻana ma ka liʻiliʻi N o nā ʻaoʻao o ke kaikaina i ka hema.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Hoʻihoʻi inā hiki ke kāwili ʻia, ʻo ia hoʻi, inā lawa paha ka lumi i kahi piko e hoʻohui i ke kikowaena KV me nā piko keiki ʻelua e pili ana.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Hana i kahi merge a hāʻawi i kahi pani pani e hoʻoholo i ka mea e hoʻi.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: ke kiʻekiʻe o nā aka i hoʻohui ʻia ma lalo o ke kiʻekiʻe
                // o ka pona o kēia edge, no laila ma luna o ka ʻole, no laila aia lākou i loko.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Hoʻohui i nā mākua waiwai nui a ka makua a me nā piko keiki ʻelua e pili ana i ka piko o ke keiki hema a hoʻihoʻi i ka piko makua liʻiliʻi.
    ///
    ///
    /// Panics ke ʻole a mākou `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Hoʻohui i nā mākua waiwai nui o ka makua a me nā piko keiki ʻelua e pili ana i ka piko o ke keiki hema a hoʻihoʻi i kēlā pihi keiki.
    ///
    ///
    /// Panics ke ʻole a mākou `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Hoʻohui i nā mākua waiwai nui a nā mākua a me nā piko keiki ʻelua e pili ana i ka piko o ke keiki hema a hoʻihoʻi i ka lima edge i kēlā pona keiki kahi i hoʻopau ai ke keiki edge i alualu ʻia,
    ///
    ///
    /// Panics ke ʻole a mākou `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Wehe i kahi paʻa waiwai nui mai ke keiki hema a waiho iā ia i ka waihona waiwai nui o ka makua, ʻoiai e hoʻokuʻikuʻi nei i ka paʻa waiwai nui o nā mākua i ke keiki kūpono.
    ///
    /// Hoʻihoʻi i kahi lima i ka edge i ke keiki kūpono e pili ana i kahi i hoʻopau ʻia ai ka edge i kuhikuhi ʻia e `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Wehe i kahi paʻa waiwai nui mai ke keiki kūpono a waiho iā ia i ka waihona waiwai nui o ka makua, ʻoiai e hoʻokuʻi ana i nā mākua waiwai nui makua i ke keiki hema.
    ///
    /// Hoʻihoʻi i kahi lima i ka edge i ke keiki hema i kuhikuhi ʻia e `track_left_edge_idx`, ʻaʻole i neʻe.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ʻAihue kēia e like me `steal_left` akā ʻaihue i nā mea he nui i ka manawa hoʻokahi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // E ʻaihue e ʻaihue mākou.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Neʻe i ka ʻikepili lau.
            {
                // Hana i kahi no nā mea ʻaihue i ke keiki kūpono.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // E neʻe i nā mea mai ke keiki hema i ka ʻākau.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // E neʻe i ka lua i ʻaihue ʻia i ka makua.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // E hoʻoneʻe i ka lua waiwai nui a ka makua i ke keiki kūpono.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Hana i kahi no nā kihi i ʻaihue ʻia.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Nā kihi ʻaihue.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// ʻO ka clone symmetric o `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // E ʻaihue e ʻaihue mākou.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Neʻe i ka ʻikepili lau.
            {
                // E neʻe i ka lua i ʻaihue ʻia i ka makua.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // E hoʻoneʻe i ka lua waiwai nui a ka makua i ke keiki hema.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // E neʻe i nā mea mai ke keiki kūpono a ka hema.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // E hoopiha ae nahā i kahi hoʻohana aihue hehee wale, e e.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nā kihi ʻaihue.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Hoʻopiha i ka hakahaka kahi i ʻaihue ʻia ai nā kihi.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Wehe i kekahi ʻike kūpaʻa e hōʻoia nei he pona `Leaf` kēia piko.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Wehe i kekahi ʻike kūpaʻa e hōʻoia nei he pona `Internal` kēia piko.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Nānā inā he nū `Internal` a i ʻole he `Leaf` node ke kumu paʻa.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// E hoʻoneʻe i ka hope ma hope o `self` mai kahi piko i kekahi.`right` pono e hakahaka.
    /// ʻO edge mua o `right` mau ka loli.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Ka hopena o ka hoʻokomo ʻana, ke pono kahi node e hoʻonui ma waho o kona hiki.
pub struct SplitResult<'a, K, V, NodeType> {
    // ʻO ka pona i hoʻololi ʻia i nā kumulāʻau e kū nei me nā mea a me nā kihi e pili ana i ka hema o `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Hoʻokaʻawale ʻia kekahi kī a me ka waiwai, e hoʻokomo ʻia ma kahi ʻē.
    pub kv: (K, V),
    // Loaʻa iā ia, ʻaʻohe pili, node hou me nā mea a me nā kihi e pili ana i ka pono o `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Inā ʻae nā node o kēia ʻano ʻaiʻē e ʻae i ka hele ʻana i nā piko ʻē aʻe i ka lāʻau.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ʻAʻole pono ka Traversal, hana ia i ka hopena o `borrow_mut`.
        // Ma ka hoʻopau ʻole ʻana i ka traversal, a me ka hana ʻana i nā kuhikuhi hou i nā aʻa, ʻike mākou ʻo kēlā me kēia kuhikuhi o ka `Owned` ʻano aia i kahi āpau aʻa.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Hoʻokomo i kahi waiwai i loko o kahi ʻāpana o nā mea hoʻomaka i ukali ʻia e kekahi mea uninitialized.
///
/// # Safety
/// ʻOi aku ka nui o nā ʻāpana i ka `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Wehe a hoʻihoʻi i kahi waiwai mai kahi ʻāpana o nā mea i hoʻomaka mua ʻia, e waiho ana ma hope o kahi mea uninitialized.
///
///
/// # Safety
/// ʻOi aku ka nui o nā ʻāpana i ka `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Hoʻololi i nā mea i kahi ʻāpana `distance` ʻāpana i ka hema.
///
/// # Safety
/// Loaʻa ma ka ʻāpana nā ʻāpana `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Hoʻololi i nā mea i kahi ʻāpana `distance` ʻāpana i ka ʻākau.
///
/// # Safety
/// Loaʻa ma ka ʻāpana nā ʻāpana `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// E hoʻoneʻe i nā waiwai āpau mai kahi ʻāpana o nā mea hoʻomaka i kahi ʻāpana o nā mea uninitialized, e waiho ana ma hope o `src` e like me ka uninitialized āpau.
///
/// Hana e like me `dst.copy_from_slice(src)` akā ʻaʻole koi iā `T` e lilo i `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;