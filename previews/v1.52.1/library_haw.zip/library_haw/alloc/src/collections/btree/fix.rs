use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Mālama nā waihona i kahi node underfull paha e ka hui ʻana me a ʻaihue paha o kahi kaikaina.
    /// Inā kūleʻa akā ma ke kumu kūʻai o ke kuʻi ʻana i ka piko o ka makua, hoʻihoʻi i kēlā piko makua.
    /// Hoʻihoʻi i kahi `Err` inā he aʻa hakahaka ka piko.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Mālama nā waihona i kahi node underfull paha, a inā ʻo ia ke kumu e emi ai ka piko o kona makua, waihona i ka makua, recursively.
    /// Hoʻi iā `true` inā ua hoʻoponopono ʻo ia i ka lāʻau, `false` inā ʻaʻole hiki iā ia no ka mea ua hakahaka ke aʻa aʻa.
    ///
    /// ʻAʻole manaʻo kēia hana i nā kūpuna e lilo i lalo o ke kumu i ke komo ʻana a me panics inā e hālāwai me kahi kūpuna nele.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Wehe i nā pae hakahaka ma luna, akā mālama i kahi lau hakahaka inā hakahaka ka lāʻau holoʻokoʻa.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Hoʻopili a hoʻopili paha i nā aka underfull ma ka palena ʻākau o ka lāʻau.
    /// ʻO nā pūnana ʻē aʻe, nā mea ʻaʻole ke aʻa a i ʻole ka edge pono loa, pono e loaʻa he mau minuke MIN_LEN ma ka liʻiliʻi.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// ʻO ka clone symmetric o `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// E hoʻopaʻa i nā aka underfull ma ka palena ʻākau o ka lāʻau.
    /// ʻO nā aka ʻē aʻe, nā mea ʻaʻole ke aʻa a i ʻole ka edge pono loa, pono e mākaukau e ʻaihue ʻia nā mea MIN_LEN.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Hōʻoia inā pono-loa keiki mea underfull.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Pono mākou e ʻaihue.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // E hele i lalo i lalo.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Hoʻopili i ke keiki hema, ke manaʻo nei ʻaʻole kūpono ke keiki pono, a hāʻawi i kahi mea keu e ʻae i ka hoʻohui ʻana i kāna mau keiki me ka lilo ʻole i underfull.
    ///
    /// Hoʻi i ke keiki hema.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` e hōʻalo ai i ka hoʻoponopono hou inā hoʻopili ʻia ma ka pae aʻe.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Hoʻopili i ke keiki kūpono, ke manaʻo nei ʻaʻole i underfull ke keiki hema, a hoʻolako i kahi mea keu e ʻae i ka hoʻohui ʻana i kāna mau keiki me ka lilo ʻole i underfull.
    ///
    /// Hoʻi i kahi a ke keiki kūpono i pau ai.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` e hōʻalo ai i ka hoʻoponopono hou inā hoʻopili ʻia ma ka pae aʻe.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}