use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// A blueprint for crash test dummy instances e nānā i kekahi mau hanana.
/// E hoʻonohonoho ʻia paha kekahi mau hanana iā panic i kekahi manawa.
/// ʻO `clone`, `drop` a i ʻole `query` inoa inoa ʻole nā hanana.
///
/// Hoʻomaopopo a kauoha ʻia nā dummies hoʻāʻo e ka id, no laila hiki iā lākou ke lilo i mau kī i kahi BTreeMap.
/// Hoʻohana ka hoʻohana me ka manaʻo ʻole i ka mea i wehewehe ʻia ma crate, ma kahi o `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Hoʻokumu i kahi hoʻolālā dummy test crash.Hoʻoholo ka `id` i ke kaʻina a me ke kaulike o nā hanana.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Hoʻokumu i kahi laʻana o kahi dummy test crash e hoʻopaʻa i nā hanana i ʻike ʻia a me panics i koho ʻia.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// E hoʻihoʻi ehia mau manawa o ka dummy i kālani ʻia.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Hoʻihoʻi ehia mau manawa o ka dummy i hāʻule.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// E hoʻihoʻi ehia mau manawa o ka dummy i kāhea ʻia kā lākou lālā `query`.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Kekahi nīnau inoa inoa ʻole, ua hāʻawi ʻia ka hopena.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}