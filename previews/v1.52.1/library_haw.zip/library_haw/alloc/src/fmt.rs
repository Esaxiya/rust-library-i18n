//! Nā pono hana no ka formatting a me ka paʻi ʻana ʻo `String`s.
//!
//! Aia i loko o kēia module ke kākoʻo holo moho no ka hoʻonui XtaX syntax.
//! Hoʻohana ʻia kēia macro i ka mea hoʻopili e hoʻokuʻu i nā kāhea i kēia module i mea e hōʻano ai i nā paio i ka holo ʻana i nā aho.
//!
//! # Usage
//!
//! Makemake ka [`format!`] macro e kamaʻāina i nā mea e hele mai ana mai nā hana a C's `printf`/`fprintf` a i ʻole Python's `str.format` hana.
//!
//! ʻO kekahi mau laʻana o ka hoʻonui [`format!`]:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" me nā zeros alakaʻi
//! ```
//!
//! Mai kēia mau mea, hiki iā ʻoe ke ʻike i ka hoʻopaʻapaʻa mua he string format.Koi ʻia e ka mea hoʻopili no kēia mea he aho maoli;ʻaʻole hiki ke loli i hāʻawi ʻia i (i mea e hana ai i ka nānā pono ʻana).
//! A laila e kaha ka mea hoʻopili i ka string format a hoʻoholo inā he kūpono ka papa inoa o nā paio i hāʻawi ʻia i kēia aho format.
//!
//! E hoʻololi i hoʻokahi waiwai i ke aho, e hoʻohana i ke ʻano [`to_string`].E hoʻohana kēia i ka [`Display`] formatting trait.
//!
//! ## Nā palena pae
//!
//! ʻAe ʻia kēlā me kēia hoʻopaʻapaʻa hoʻākāka e kuhikuhi i ka manaʻo hoʻopaʻapaʻa e kuhikuhi ana, a inā haʻalele ʻia ua manaʻo ʻia ʻo "the next argument".
//! ʻO kahi laʻana, e lawe ke aho format `{} {} {}` i ʻekolu mau palena, a e hōʻano ʻia lākou i ke kaʻina like e like me ka hāʻawi ʻia ʻana.
//! ʻO ke aho hōʻano `{2} {1} {0}`, eia naʻe, e hōʻano i nā paio ma ka ʻaoʻao huli.
//!
//! Hiki i nā mea ke maʻalahi iki ke hoʻomaka ʻoe e hoʻopili i nā ʻano ʻelua o nā kikoʻī kūlana.Hiki i ka "next argument" kikoʻī ke manaʻo ʻia he iterator ma luna o ka hoʻopaʻapaʻa.
//! I kēlā me kēia manawa ke ʻike ʻia kahi kikoʻī "next argument", holomua ka iterator.Alakaʻi kēia i ka lawena e like me kēia:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! ʻAʻole i holomua ka iterator kūloko ma luna o ka paio e ka manawa i ʻike ʻia ai ka `{}` mua, no laila paʻi ia i ka paio mua.A laila i ka hōʻea ʻana i ka lua `{}`, ua holomua ka iterator i ka paio ʻelua.
//! ʻO ka mea nui, ʻo nā palena i hōʻike maopopo i ka inoa o kā lākou hoʻopaʻapaʻa ʻaʻole pili i nā palena i kapa ʻole i ka inoa o kahi paio e pili ana i nā kikoʻī kūlana.
//!
//! A waihona kui Ua koi 'ia e hana a pau o kona manaʻo hoʻopiʻi kū'ē, ole ia mea he i hoʻouluulu-manawa hewa.Hiki iā ʻoe ke kuhikuhi i ka hoʻopaʻapaʻa like ma mua o hoʻokahi manawa i ke aho format.
//!
//! ## Nā palena i kapa ʻia
//!
//! ʻAʻole loaʻa iā Rust kahi Python e like me nā palena i kapa ʻia i kahi hana, akā ʻo ka [`format!`] macro kahi extension syntax e ʻae iā ia e leverage i nā palena i kapa ʻia.
//! Ua helu ʻia nā palena i kapa ʻia ma ka hope o ka papa inoa hoʻopaʻapaʻa a loaʻa ka syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! ʻO kahi laʻana, nā ʻōlelo aʻe [`format!`] e hoʻohana āpau i ka inoa paio:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! ʻAʻole kūpono e kau i nā palena hoʻonohonoho (nā mea me ka ʻole o nā inoa) ma hope o nā paio i loaʻa nā inoa.E like me nā palena hoʻonohonoho, ʻaʻole kūpono e hāʻawi i nā palena i kapa ʻia i hoʻohana ʻole ʻia e ke aho format.
//!
//! # Nā Palapala Hoʻonohonoho
//!
//! Hiki ke hoʻololi ʻia kēlā me kēia hoʻopaʻapaʻa e ka helu o nā palena hoʻonohonoho hōkū (e like me `format_spec` ma [the syntax](#syntax)). Hoʻopili kēia mau palena i ka hōʻike string o ka mea i hōʻano ʻia.
//!
//! ## Width
//!
//! ```
//! // A pau o kēia mau paʻi "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! He parameter kēia no ka "minimum width" e lawe ai i ka hōʻano.
//! Inā i ka waiwai o ka kaula, aole ia e hoopiha i keia na huapalapala, alaila, i ka nenelu loa i hoakaka ia ma ka fill/alignment e e hoʻohana i ka lawe i na koi makahiki (e nānā ma lalo nei).
//!
//! Hiki ke hāʻawi ʻia i ka waiwai no ka laulā ma ke ʻano he [`usize`] i ka papa inoa o nā palena ma ka hoʻohui ʻana i ka postcode `$`, e hōʻike ana he [`usize`] ka lua o nā manaʻo e hōʻike ana i ka laulā.
//!
//! ʻO ke kuhikuhi ʻana i kahi hoʻopaʻapaʻa me ka syntax kālā ʻaʻole ia e hoʻopili i ka counter "next argument", no laila he mea maikaʻi ke nānā i nā paio ma ke kūlana, a i ʻole e hoʻohana i nā paio i kapa ʻia.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Hāʻawi ʻia ke ʻano koho hoʻopiha a koho i ka maʻamau me ka parameter [`width`](#width).Pono e wehewehe ma mua o `width`, ma hope pono o ka `:`.
//! Hōʻike kēia inā inā ʻoi aku ka liʻiliʻi o ka hōʻano ʻana ma mua o `width` e paʻi ʻia nā kaha keu a puni ia.
//! Hele mai ka hoʻopihapiha i nā ʻano aʻe aʻe no nā ʻano like ʻole:
//!
//! * `[fill]<` - waiho ʻia ka paio i nā kolamu `width`
//! * `[fill]^` - kaulike ke kūʻē i ke kikowaena `width`
//! * `[fill]>` - i ka manaʻo hoʻopiʻi kū'ē ua pono-ua kūponoʻia ma `width` kolamu
//!
//! ʻO ka [fill/alignment](#fillalignment) paʻamau no nā helu helu ʻole kahi ākea a kaulike ʻia.ʻO ka paʻamau no nā mea helu helu he ʻano hakahaka hoʻi me ka hoʻopili pono ʻana.
//! Inā ka `0` ia? Aiina (e nānā ma lalo nei) ua i hoakaka ia no ka laulā, a laila, i ka implicit māʻona ano o `0`.
//!
//! E hoʻomaopopo ʻaʻole paha e hoʻokō ʻia ke kau ʻana e kekahi ʻano.Ma ke kikoʻī, ʻaʻole hoʻokō ʻia ia no `Debug` trait.
//! ʻO kahi ala maikaʻi e hōʻoia ai i ka hoʻopili ʻana e hoʻopili i ka hoʻopili ʻana i kāu hoʻokomo, a laila pale i kēia kaula hopena e loaʻa ai kāu hopena:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Aloha Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! ʻO kēia nā lepa āpau e hoʻololi ana i ka lawena o ka mea hōʻano.
//!
//! * `+` - Hoʻonohonoho ʻia kēia no nā ʻano helu a hōʻike e paʻi mau ka hōʻailona.ʻAʻole paʻi ʻia nā hōʻailona maikaʻi e ka paʻamau, a ʻo ka hōʻailona maikaʻi ʻole e paʻi wale ʻia e ka paʻamau no ka `Signed` trait.
//! Hōʻike kēia hae i ka hōʻailona pololei (`+` a i ʻole `-`) e paʻi mau.
//! * `-` - ʻAʻole hoʻohana ʻia i kēia manawa
//! * `#` - Kuhi kēia hae i ka pono o ka paʻi "alternate" e hoʻohana ai.Ka 'ē aʻe' ano apau loa i:
//!     * `#?` - paʻi nani i ka hōʻano [`Debug`]
//!     * `#x` - ma mua o ka paio me `0x`
//!     * `#X` - ma mua o ka paio me `0x`
//!     * `#b` - ma mua o ka paio me `0b`
//!     * `#o` - ma mua o ka paio me `0o`
//! * `0` - Hoʻohana ʻia kēia e hōʻike no nā ʻōkuhi integer e pono ke hana ʻia ka padding i `width` me kahi `0` a me ka hōʻailona hōʻailona.
//! E hāʻawi kahi hōʻano e like me `{:08}` i `00000001` no ka integer `1`, ʻoiai e like ka mana like me `-0000001` no ka helu helu `-1`.
//! Ka leka hoʻomaopopo i ka io kēia i kekahi poʻeʻuʻuku Aʻohe ma mua o ka maikaʻi mana.
//!         E hoʻomaopopo i ka waiho mau ʻia ʻana o nā zeros padding ma hope o ka hōʻailona (inā loaʻa) a ma mua o nā helu.Ke hoʻohana pū ʻia me ka Hae `#`, pili kekahi rula like: hoʻokomo ʻia nā zeros padding ma hope o ka pīpī akā ma mua o nā helu.
//!         Hoʻokomo ʻia ka pīpī i ka laulā ākea.
//!
//! ## Precision
//!
//! No nā ʻano helu ʻole, hiki i kēia ke manaʻo ʻia he "maximum width".
//! Inā ʻoi aku ka lōʻihi o ke aho ma mua o kēia ākea, a laila truncated ia i lalo i kēia mau huapalapala a hoʻokuʻu ʻia ka waiwai truncated me `fill`, `alignment` a me `width` pono inā hoʻonohonoho ʻia kēlā mau palena.
//!
//! No nāʻano integral, nānā ʻole ʻia kēia.
//!
//! No nā ʻano kiko lana, hōʻike kēia i ka nui o nā helu ma hope o ka kiko decimal e paʻi ʻia.
//!
//! ʻEkolu ala e hiki ai ke kikoʻī i ka `precision` i makemake ʻia:
//!
//! 1. Kahi huina `.N`:
//!
//!    ʻo ka integer `N` ponoʻī ka kikoʻī.
//!
//! 2. ʻO kahi helu helu a inoa paha e ukali ʻia e ka inoa inoa `.N$`:
//!
//!    hoʻohana i ka hōʻano *paio*`N` (a he `usize` paha) e like me ke kikoʻī.
//!
//! 3. ʻO kahi asterisk `.*`:
//!
//!    `.*` ke ʻano o ka pili ʻana o kēia `{...}` me nā manaʻo hoʻokomo ʻelua * ma mua o hoʻokahi: ʻo ka hoʻokomo mua i paʻa i ka `usize` kikoʻī, a ʻo ka lua i ka waiwai e paʻi.
//!    E hoʻomaopopo ma kēia hihia, inā hoʻohana kekahi i ke aho format `{<arg>:<spec>.*}`, a laila ʻo ka ʻaoʻao `<arg>` e pili ana i ka* waiwai * e paʻi, a ʻo `precision` e pono e hele mai i ka hoʻokomo ma mua o `<arg>`.
//!
//! ʻO kahi laʻana, kāhea ka mea aʻe i nā paʻi āpau i ka mea like `Hello x is 0.01000`:
//!
//! ```
//! // Aloha {arg 0 ("x")} ʻo {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Aloha {arg 1 ("x")} ʻo {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Aloha {arg 0 ("x")} ʻo {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Aloha {next arg ("x")} ʻo {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Aloha {next arg ("x")} ʻo {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Aloha {next arg ("x")} ʻo {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! ʻOiai kēia:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! paʻi i ʻekolu mau mea ʻokoʻa loa:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! I kekahi mau ʻōlelo hoʻolālā, pili ka hana o ka hoʻonohonoho ʻana i ke aho i ka hoʻonohonoho kūloko o ka ʻōnaehana.
//! ʻAʻohe manaʻo o ka wahi o ka waihona waihona maʻamau o Rust o nā wahi a e hoʻopuka i nā hopena like ma nā ʻōnaehana āpau me ka nānā ʻole i ka hoʻonohonoho ʻana o nā mea hoʻohana.
//!
//! ʻO kahi laʻana, e paʻi mau ka code aʻe i ka `1.5` inā hoʻohana ka ʻōnaehana kikowaena i kahi hoʻokaʻawale decimal aʻe ma mua o kahi kiko.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Hoʻokomo ʻia paha nā huapalapala huapalapala `{` a me `}` i kahi kaula ma mua o lākou me ke ʻano like.ʻO kahi laʻana, ua pakele ke ʻano `{` me `{{` a ua pakele ke ʻano `}` me `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! E hōʻuluʻulu manaʻo, 'aneʻi oe hiki ke' imi i ka piha grammar o ka waihona kaula.
//! Ua unuhi ʻia ka syntax no ka ʻōnaehana hoʻonohonoho ʻana mai nā ʻōlelo ʻē aʻe, no laila ʻaʻole ia he malihini loa.Hōʻike ʻia nā hoʻopaʻapaʻa me Python-like syntax, ʻo ia hoʻi ua hoʻopuni ʻia nā hoʻopaʻapaʻa e `{}` ma kahi o ka C-like `%`.
//! ʻO ka grammar maoli no ka syntax hōʻano ʻo:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! I ka grammar ma luna, ʻaʻole paha i loko o `text` nā huapalapala `'{'` a i ʻole `'}'`.
//!
//! # Hoʻonohonoho traits
//!
//! Ke noi nei ʻoe e hōʻano ʻia kahi paio me kahi ʻano, ke noi nei ʻoe e hāʻawi ʻia kahi paio i kahi trait kikoʻī.
//! ʻAe kēia i nā ʻano maoli e hoʻopili ʻia ma o `{:x}` (e like me [`i8`] a me [`isize`]).ʻO ka palapala kiʻi o kēia manawa i traits ʻo ia:
//!
//! * *ʻaʻohe mea* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] me nā helu hexadecimal hihia haʻahaʻa
//! * `X?` ⇒ [`Debug`] me nā helu hexadecimal hihia kiʻekiʻe
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! He aha kēia mea mea i kekahiʻano o ka loulou i mea lapaʻau i ka [`fmt::Binary`][`Binary`] trait hiki laila e formatted me `{:b}`.Hāʻawi ʻia nā hana no kēia traits no kekahi mau ʻano primitive e ka waihona puke maʻamau.
//!
//! Inā ʻaʻohe kikoʻī i kuhikuhi ʻia (e like me `{}` a i ʻole `{:6}`), a laila ʻo ka hōʻano trait i hoʻohana ʻia ʻo [`Display`] trait.
//!
//! Ke hoʻokomo nei i kahi mana trait no kāu ʻano ponoʻī, pono ʻoe e hoʻokō i kahi hana o ka pūlima:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mākou ʻano maʻamau
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! E kāpae ʻia kāu ʻano ma ke ʻano he `self`, a laila e hoʻokuʻu i ka hana i ka puka i loko o ke kahawai `f.buf`.Aia ia i kēlā me kēia palapala trait hoʻokō e hoʻopili pololei i nā ʻōnaehana hoʻonohonoho i noi ʻia.
//! Nā aiee o kēia mau mea kiko'î e e heluʻia i loko o ka mahinaʻai o ke [`Formatter`] struct.I mea e kōkua ana me keia, no ka [`Formatter`] struct kekahi hoakaka i kekahi mea nana e kokua ki ina hana like.
//!
//! Eia kekahi, i ka hoʻi waiwai io o keia kuleana pili i ka [`fmt::Result`] i mea heʻano Alia o ['Result`]' <(),`['std: : fmt::Error`]`>'.
//! Pono e hōʻoia i ka hoʻokō ʻana i nā hoʻokō e hoʻolaha lākou i nā hewa mai ka [`Formatter`] (e like me ke kāhea ʻana iā [`write!`]).
//! Eia naʻe, ʻaʻole lākou e hoʻihoʻi pinepine i nā hewa.
//! ʻO ia, pono ka hoʻokō ʻana i kahi hōʻano a hoʻi paha i kahi hemahema inā hoʻi e hala ka [`Formatter`] i hala i hewa.
//! ʻO kēia no ka mea, i kūʻē i ka mea i manaʻo ʻia e ka pūlima inoa, he hana hewa ʻole ka hana ʻana i ke aho.
//! Hoʻihoʻi wale kēia hana i kahi hopena no ka mea e holo paha ke kākau ʻana i ke kahawai kumu a pono ia e hāʻawi i kahi ala e hoʻolaha ai i ka ʻoiaʻiʻo ua kū hou kahi hemahema i ka paila.
//!
//! ʻO kahi laʻana o ka hoʻokō ʻana i ka hōpili traits e like me:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Hoʻokomo ka waiwai `f` i ka `Write` trait, ʻo ia ka mea e kākau ai!ke kali nei ʻo makona.
//!         // E hoʻomaopopo i ka nānā ʻole ʻana o kēia ʻōpala i nā hae like ʻole i hāʻawi ʻia i nā aho format.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // ʻAe ka traits ʻokoʻa i nā ʻano puka like ʻole o kahi ʻano.
//! // ʻO ka manaʻo o kēia palapala e paʻi i ka nui o vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // E mahalo i nā lepa hoʻoliʻiliʻi ma o ka hoʻohana ʻana i ke ʻano kōkua he `pad_integral` ma ka mea Formatter.
//!         // E ʻike i nā palapala hana no nā kikoʻī, a hiki ke hoʻohana i ka hana `pad` e pale i nā aho.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! He mau kumu kuhi ko kēia mau ʻano traits.
//!
//! - [`fmt::Display`][`Display`] ke hōʻoia nei i nā hoʻokō hiki ke hōʻike pono ʻia ke ʻano ma ke ʻano he kaula UTF-8 i nā manawa āpau.ʻAʻole ** i manaʻo ʻia e hoʻopili nā ʻano āpau i ka [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] pono e hoʻokō i nā hoʻokō no **a pau** nā ʻano lehulehu.
//!   ʻO ka huahana e hōʻike maʻamau i ka moku kūloko i ka hiki ke hiki.
//!   ʻO ke kumu o ka [`Debug`] trait mea e kōkua ai i ka debugging Rust code.I ka hapanui o nā hihia, ua lawa a paipai ʻia ka hoʻohana ʻana i `#[derive(Debug)]`.
//!
//! ʻO kekahi mau laʻana o ka hoʻopuka mai traits ʻelua:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Nā macros e pili pū ana
//!
//! Aia kekahi mau helu o nā macros pili i ka ʻohana [`format!`].ʻO nā mea i hoʻokō ʻia i kēia manawa ʻo:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! ʻO kēia a me [`writeln!`] ʻelua macros i hoʻohana ʻia e emit i ke aho format i kahi kahawai i kuhikuhi ʻia.Hoʻohana ʻia kēia e pale i nā hoʻokaʻawale waena o nā aho format a ma kahi e kākau pololei i ka hopena.
//! Ma lalo o ka pāpale, ke noi nei kēia hana i ka hana [`write_fmt`] i wehewehe ʻia ma ka [`std::io::Write`] trait.
//! ʻO kahi laʻana hoʻohana:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Kuhi kēia a me [`println!`] i kā lākou puka iā stdout.Like i ka [`write!`] nunui, ka pahu hopu o kēia mau macros mea e pale aku waena allocations ka wā pai ana i auaiaea.ʻO kahi laʻana hoʻohana:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Kūlike like nā macros [`eprint!`] a me [`eprintln!`] i [`print!`] a me [`println!`], koe wale nō lākou e hoʻokuʻu i kā lākou puka iā stderr.
//!
//! ### `format_args!`
//!
//! ʻO kēia kahi macro makamae i hoʻohana ʻia e hele a hoʻopuni i kahi mea opaque e wehewehe ana i ke aho format.ʻAʻole koi kēia mea i kekahi hoʻokaʻina puʻu e hana, a kuhikuhi wale ia i ka ʻikepili ma ka puʻu.
//! Ma lalo o ka pāpale, ua hoʻokō ʻia nā macros āpau e pili ana i kēia.
//! ʻO ka mua, ʻo kahi laʻana o ka hoʻohana ʻana:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! ʻO ka hopena o ka [`format_args!`] macro kahi waiwai o ka ʻano [`fmt::Arguments`].
//! Hiki ke hoʻolilo ʻia kēia ʻōnaehana i nā hana [`write`] a me [`format`] i loko o kēia kōmike i mea e hana ai i ke aho format.
//! ʻO ka pahuhopu o kēia macro e pale hou aku i nā hoʻokaʻawale waena i ka wā e hana ana i nā aho hoʻonohonoho.
//!
//! ʻO kahi laʻana, hiki i kahi waihona logging ke hoʻohana i ka syntax hōʻano maʻamau, akā e hele a puni ia i kēia ʻano a hiki i ka hoʻoholo ʻia ʻana i kahi e hele ai ka hopena.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Lawe ka hana `format` i kahi hanana [`Arguments`] a hoʻihoʻi i ke aho hoʻonohonoho i hopena ʻia.
///
///
/// Hiki ke hana ʻia ka hanana [`Arguments`] me ka [`format_args!`] macro.
///
/// # Examples
///
/// Hoʻohana maʻamau:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Eʻoluʻolu, e hoailona oukou i ka hoʻohana 'ana [`format!`] paha e e ahoʻia.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}