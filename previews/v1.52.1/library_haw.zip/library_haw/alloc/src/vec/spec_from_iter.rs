use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Hoʻohana trait i hoʻohana ʻia no Vec::from_iter
///
/// ## ʻO ka pakuhi ʻelele:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ke hele nei kahi hihia maʻamau i vector i kahi hana e ʻohiʻohi hou ai i vector.
        // Hiki iā mākou ke kaapuni pōkole i kēia inā ʻaʻole holomua iki ka IntoIter.
        // Ke holomua Ua hiki iā mākou ke hoʻohana hou i ka hoʻomanaʻo a neʻe i ka ʻikepili i mua.
        // Akā hana wale mākou pēlā inā ʻaʻole loaʻa i ka hopena ʻo Vec ka nui i hoʻohana ʻole ʻia ma mua o ka hoʻokumu ʻana iā ia ma o ka generic FromIterator hoʻokō.
        //
        // ʻAʻole pono ka palena e like me ka hana a ka Vec hoʻokaʻawale.
        // Akā he koho conservative ia.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // pono elele 'o ia spec_extend() mai extend() ihoʻelele e spec_from no ka nele Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Hoʻohana kēia i `iterator.as_slice().to_vec()` mai ka pono o ka spec_extend e hana i nā ʻanuʻu hou aʻe e noʻonoʻo e pili ana i ka mana hope + ka lōʻihi a pēlā e hana hou ai i ka hana.
// `to_vec()` hoʻokaʻawale pololei i ka nui kūpono a hoʻopiha pololei iā ia.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): me cfg(test) ke ʻano `[T]::to_vec` kūmau, i koi ʻia no kēia wehewehe ʻana o kēia hana, ʻaʻole i loaʻa.
    // E hoʻohana i ka hana `slice::to_vec` i loaʻa wale me cfg(test) NB e ʻike i ka module slice::hack ma slice.rs no ka ʻike hou aku.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}