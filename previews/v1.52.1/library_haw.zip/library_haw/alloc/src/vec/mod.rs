//! A kokoke growable kū'ē 'ano me ka ahu-anao? Aou Contents, palapala `Vec<T>`.
//!
//! Loaʻa iā Vectors ka helu helu `O(1)`, kaomi `O(1)` amortized (i ka hopena) a me `O(1)` pop (mai ka hopena).
//!
//!
//! Vectors hōʻoia 'ka mea, aole līkaia oi ma mua o `isize::MAX` nāʻai.
//!
//! # Examples
//!
//! Hiki iā ʻoe ke hana kikoʻī i kahi [`Vec`] me [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... a ma ka hoʻohana 'ana i ka [`vec!`] nunui:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // he ʻumi mau zero
//! ```
//!
//! Hiki iā ʻoe ke [`push`] mau helu ma ka hopena o vector (kahi e ulu ai ka vector e pono ai):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Hana like ke kuhi ʻana i nā waiwai ma ke ʻano like:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Kākoʻo pū ʻo Vectors i ka loiloi ʻana (ma o [`Index`] a me [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// A contiguous growable array type, kākau ʻia e `Vec<T>` a ʻōlelo ʻia 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Hāʻawi ʻia ka [`vec!`] macro e ʻoi aku ka maʻalahi o ka hoʻomaka ʻana.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Hiki iā ia ke hoʻomaka mua i kēlā me kēia mehana o `Vec<T>` me kahi waiwai i hāʻawi ʻia.
/// ʻOi aku paha ka maikaʻi o kēia ma mua o ka hana ʻana i ka hoʻokaʻawale a me ka hoʻomaka ʻana i nā kaʻina kaʻawale, keu hoʻi i ka hoʻomaka ʻana i kahi vector o zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Kūlike ka mea aʻe, akā lohi paha:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// No ka ʻike hou aku, e ʻike iā [Capacity and Reallocation](#capacity-and-reallocation).
///
/// E hoʻohana i kahi `Vec<T>` ma ke ʻano he stack pono:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Wahi 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Ka `Vec` ʻano e leie aku i ka hoʻohana aiee ma ka 'inideka, no ka mea, e kakau mai i ka [`Index`] trait.E ʻike maopopo ʻia kahi laʻana:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // e hōʻike iā '2'
/// ```
///
/// Eia naʻe e akahele: inā hoʻāʻo ʻoe e kiʻi i kahi papa kuhikuhi ʻaʻole i ka `Vec`, panic kāu polokalamu!ʻAʻole hiki iā ʻoe ke hana i kēia:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// E hoʻohana i [`get`] a me [`get_mut`] inā makemake ʻoe e nānā inā paha ka helu kuhikuhi ma `Vec`.
///
/// # Slicing
///
/// Hiki i kahi `Vec` ke hoʻololi.Ma ka kekahi lima, e heluhelu-wale slices mea.
/// E kiʻi i [slice][prim@slice], e hoʻohana iā [`&`].Laʻana:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... a ʻo ia wale nō!
/// // hiki iā ʻoe ke hana e like me kēia:
/// let u: &[usize] = &v;
/// // a i ʻole e like me kēia:
/// let u: &[_] = &v;
/// ```
///
/// I Rust, ʻoi aku ka maʻamau o ka paʻi ʻana i nā ʻāpana ma ke ʻano he hoʻopaʻapaʻa ma mua o vectors ke makemake ʻoe e hāʻawi i ka loaʻa heluhelu.Pēlā nō ia no [`String`] a me [`&str`].
///
/// # Nona iho a me ka reallocation
///
/// ʻO ka hiki o kahi vector ka nui o kahi i hoʻokaʻawale ʻia no kēlā me kēia future mau mea e hoʻohui ʻia i ka vector.ʻAʻole e huikau kēia me ka *lōʻihi* o kahi vector, e hōʻike ana i ka helu o nā mea maoli i loko o ka vector.
/// Inā ʻoi aku ka lōʻihi o vector i kona hiki, e hoʻonui aunoa ʻia kona hiki, akā pono e hoʻonohonoho hou ʻia kāna mau mea.
///
/// ʻO kahi laʻana, ʻo vector me ka hiki iā 10 a me ka lōʻihi 0 kahi vector hakahaka me kahi no 10 mau mea hou aku.Ke hoʻololi nei i nā mea he 10 a ʻoi aku paha ma ka vector ʻaʻole e loli i kona hiki a i ʻole e hoʻokumu i ka reallocation.
/// Eia naʻe, inā hoʻonui ʻia ka lōʻihi o vector i 11, pono ia e hoʻohele hou, a hiki ke lohi.No kēia kumu, noi ʻia e hoʻohana i ka [`Vec::with_capacity`] i nā manawa āpau e hōʻike pono i ka nui o ka vector e manaʻo ʻia e loaʻa.
///
/// # Guarantees
///
/// Ma muli o kona ʻano kumu koʻikoʻi, `Vec` hana i nā hōʻoia he nui e pili ana i kāna hoʻolālā.Mālama kēia i ka haʻahaʻa o ke poʻo i hiki i ka hihia maʻamau, a hiki ke hoʻohana pono ʻia i nā ala kahiko e ka code unsafe.E hoʻomaopopo i kēia mau hoʻohiki e kuhikuhi i kahi `Vec<T>` kūpono ʻole.
/// Inā hoʻohui ʻia nā palena ʻāpana ʻokoʻa (e laʻa me ke kākoʻo ʻana i nā mea hoʻokaʻawale pilikino), ʻo ka hoʻokahuli ʻana i kā lākou hana maʻamau hiki ke hoʻololi i ka hana.
///
/// ʻO ke kumu nui, ʻo `Vec` a maʻa mau ia i kahi kuhi (kuhikuhi, hiki, lōʻihi) ʻekolu.ʻAʻole hou, ʻaʻole emi.I ka mea o kēia mau mahinaʻai nō hoʻi ia moʻolelo unspecified, a me oe e hoʻohana i ka kūpono ki ina hana, e hoʻololi i kēia mau.
/// ʻAʻole loa e kuhi ka pointer, no laila hoʻopau maikaʻi ʻole ʻia kēia ʻano.
///
/// Eia naʻe, ʻaʻole paha e kuhikuhi ka kuhikuhi i ka hoʻomanaʻo i hoʻokaʻawale ʻia.
/// I ke kikoʻī, inā kūkulu ʻoe i `Vec` me ka hiki 0 ma o [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], a i ʻole ke kāhea ʻana iā [`shrink_to_fit`] ma kahi Vec nele, ʻaʻole ia e hoʻokaʻawale i ka hoʻomanaʻo.Like, ina e hoahu Aʻohe-pepa paia ano i loko o ka `Vec`, ka mea e ole līkaia no ka lewa no ia.
/// *E hoʻomaopopo ma kēia hihia ʻaʻole e hōʻike ka `Vec` i kahi [`capacity`] o 0*.
/// `Vec` e hoʻokaʻawale inā a inā wale nō inā [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ma ka laulaha, ʻoluʻolu loa nā kikoʻī o ka hoʻokaʻawale ʻana o Vec-inā makemake ʻoe e hoʻokaʻawale i ka hoʻomanaʻo me ka hoʻohana ʻana i `Vec` a hoʻohana ia mea no kekahi mea ʻē aʻe (e hele i kahi pāʻālua palekana, a i ʻole e kūkulu i kāu hōʻiliʻili i kākoʻo ʻia e ʻoe iho), e ʻike pono e hoʻololi i kēia hoʻomanaʻo ma o ka hoʻohana ʻana iā `from_raw_parts` e hoʻihoʻi i ka `Vec` a laila e hoʻokuʻu iā ia.
///
/// Inā he `Vec`*i* hoʻokaʻawale i ka hoʻomanaʻo, a laila ka hoʻomanaʻo i kuhikuhi ʻia ma ka puʻu (e like me ka wehewehe ʻana a ka mea hoʻokaʻawale Rust i hoʻonohonoho ʻia e hoʻohana ma ke ʻano paʻamau), a kuhikuhi ʻia kona kiko kuhikuhi i [`len`] i hoʻokumu ʻia, nā mea pili i ka hoʻonohonoho (he aha kāu e makemake ai ʻike inā ʻoe e koi iā ia i kahi ʻāpana), a ukali ʻia e [`capac`]`,`[`len`] unicitialized, contiguous element.
///
///
/// A vector i loaʻa nā kumuhana `'a'` a me `'b'` me ka hiki 4 hiki ke ʻike ʻia ma lalo.ʻO ka ʻāpana luna ka `Vec` struct, loaʻa kahi kuhikuhi i ke poʻo o ka hoʻokaʻawale ʻana i ka puʻu, ka lōʻihi a me ka hiki.
/// ʻO ka ʻaoʻao lalo ka hoʻokaʻawale ʻana ma ka puʻu, kahi palapu hoʻomanaʻo pili.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** kū i ka hoʻomanaʻo i hoʻomaka ʻole ʻia, e ʻike iā [`MaybeUninit`].
/// - Note: ʻaʻole kūpaʻa ka ABI a ʻaʻohe `Vec` e hoʻohiki e pili ana i kāna hoʻonohonoho hoʻomanaʻo (me ke ʻano o nā māla).
///
/// `Vec` e loa hana i kekahi "small optimization" kahi oihana mua i maoli waiho ma luna o ka noae i mau kumu:
///
/// * E lilo ia i mea paʻakikī no ka code unsafe e hoʻoponopono pono i kahi `Vec`.ʻAʻole i loaʻa kahi ʻike paʻa o ka `Vec` i kahi helu paʻa inā hoʻoneʻe wale ʻia ia, a ʻoi aku ka paʻakikī e hoʻoholo inā ua hāʻawi ʻo `Vec` i kahi hoʻomanaʻo.
///
/// * E hoʻopaʻi ʻia ka hihia maʻamau, e hoʻonui ana i kahi branch hou aʻe ma ke komo ʻana.
///
/// `Vec` ʻaʻole loa e hōʻemi iā ia iho, ʻoiai inā nele loa.Kēia e hōʻoiaʻiʻo i hoʻokali kūpono 'allocations a me deallocations ana.Emptying he `Vec`, a laila, hoʻopiha ia hope mai a hiki i ka hookahi [`len`] e incur i kāhea aku a ke i ka allocator.Inā makemake ʻoe e hoʻokuʻu i ka hoʻomanaʻo i hoʻohana ʻole ʻia, e hoʻohana iā [`shrink_to_fit`] a i ʻole [`shrink_to`].
///
/// [`push`] a [`insert`] ʻaʻole loa (re) e hoʻokaʻawale inā lawa ka hōʻike i hōʻike ʻia.Hoʻokaʻawale ʻo [`push`] a me [`insert`] * (re) inā [`len`]`==`[`hiki`].ʻO ia, ʻo ke kūpono i hōʻike ʻia he pololei loa ia, a hiki ke hilinaʻi ʻia.Hiki ke hoʻohana ʻia no ka hoʻokuʻu manuahi ʻana i ka hoʻomanaʻo i hāʻawi ʻia e `Vec` inā makemake ʻia.
/// ʻO nā hana hoʻokomo i ka nui *hiki ke* hoʻoili hou, ʻoiai ʻaʻole pono.
///
/// `Vec` 'Aʻole i kumu hoʻomalu i kekahi mau ulu kou akamai ka wā reallocating ka wā piha, aole hoi i ka wā [`reserve`] ua kapaia.Kaʻikena kou akamai ka walaʻauʻana a me ka mea e ho'āʻo pono e hoʻohana i ka pili-a eia i ulu ololi.ʻO nā hoʻolālā a pau e hoʻohana ʻia e hōʻoiaʻiʻo nō ia *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, a me [`Vec::with_capacity(n)`][`Vec::with_capacity`], e hoʻopuka i kahi `Vec` me ka mana i noi ʻia.
/// Inā [`len`] '==' ['capacity`], (e like me ka ka ina no ka [`vec!`] nunui), a laila, he `Vec<T>` hiki ke huli ia, a mai ka [`Box<[T]>`][owned slice] me reallocating ole neʻe maila i nā kumu mua.
///
/// `Vec` ʻaʻole e hoʻokau kikoʻī i kekahi ʻikepili i lawe ʻia aku mai ona aku, akā ʻaʻole ia e mālama pono iā ia.ʻO kāna memo uninitialized kahi wili e hoʻohana ai ia akā makemake ia.E hana wale ia i nā mea ʻoi aku ka maikaʻi a maʻalahi ʻole e hoʻokō.Mai hilinai aku maluna o ka weheʻana ikepili e e holoiia no ka maluhia hana.
/// ʻO ina e haule kekahi `Vec`, kona aooa? I wale e hoʻohana hou 'ia ma kekahi `Vec`.
/// ʻOiai ʻaʻole ʻoe e hoʻomanaʻo i kahi hoʻomanaʻo o 'Vec` ma mua, ʻaʻole paha ia e kū ʻole ma muli o ka noʻonoʻo ʻole o ka optimizer he hopena ʻaoʻao kēia e mālama pono ʻia.
/// Aia o kekahi hihia a mākou e ole e uhai, nae: ka hoʻohana 'ana `unsafe` karaima i kahakaha iho ai i ka oi nona iho, a laila, mahuahua ka lōʻihi, e like me, ka manawa i pololei ia.
///
/// Currently, `Vec` 'aʻole i kumu hoʻomalu i ka mea i loko o a hehee wale i haule.
/// Ua loli ke kauoha i ka wā ma mua a ua loli hou paha.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// hoʻomaopop 'ana i kāu kiʻina hana
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Kūkulu i kahi `Vec<T>` hou, hakahaka.
    ///
    /// Ke vector e ole līkaia a hehee wale e pahu ma luna o ia.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Kūkulu i kahi `Vec<T>` hakahaka hou me ka mana i kuhikuhi ʻia.
    ///
    /// Na vector e e hiki ke paa pono `capacity` nā kumumea me reallocating.
    /// Inā ʻo `capacity` ka 0, ʻaʻole hoʻokaʻawale ka vector.
    ///
    /// He mea nui e hoʻomaopopo ʻoiai ʻo vector i hoʻihoʻi ʻia he *kaha* i kuhikuhi ʻia, e loaʻa i ka vector kahi lōʻihi *ʻole*.
    ///
    /// No ka wehewehe ʻana i ka ʻokoʻa ma waena o ka loa a me ka hiki, e ʻike i *[Ka hiki a me ka hoʻonohonoho hou ʻana]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // ʻAʻohe o ka vector i nā huahana, ʻoiai nona ka mana no nā mea hou aʻe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Hana ʻia kēia mau mea me ka ʻole o ka hoʻoili hou ʻana ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... akā, i kēia e hana i ka vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Hana i kahi `Vec<T>` pololei mai nā mea maka o kekahi vector.
    ///
    /// # Safety
    ///
    /// He nui unsafe, ma muli o ka helu ana o invariants i mea ole kulana kupono:
    ///
    /// * `ptr` pono e hoʻokaʻawale ʻia ma o [String`]/ʻVec<T>((ma ka liʻiliʻi, pololei ʻole paha inā ʻaʻole ia).
    /// * `T` pono e loaʻa ka nui a me ke kaulike e like me ka `ptr` i hoʻokaʻawale ʻia me.
    ///   (`T` me ka hoʻoliʻiliʻi koʻikoʻi ʻaʻole lawa, pono pono ke kaulike e māʻona i ka [`dealloc`] koi e pono e hoʻokaʻawale a hoʻomanaʻo ʻia me ka hoʻonohonoho like.)
    ///
    /// * `length` pono e emi ma lalo a i ʻole like paha me `capacity`.
    /// * `capacity` pono e hiki i ka mākia i hāʻawi ʻia me ka kuhikuhi.
    ///
    /// ʻO ka hōʻino ʻana i kēia mau mea ke kumu o nā pilikia e like me ka hōʻino ʻana i nā ʻikepili o loko o ka mea hoʻokaʻawale.Eia kahi laʻana **ʻaʻole** palekana e kūkulu i kahi `Vec<u8>` mai kahi kuhikuhi a i kahi hoʻonohonoho C `char` me ka lōʻihi `size_t`.
    /// ʻAʻole palekana ia e kūkulu i hoʻokahi mai kahi `Vec<u16>` a me kona lōʻihi, no ka mea mālama ka mea hoʻokaʻawale i ke kaulike, a he ʻokoʻa nā ʻano ʻelua o kēia mau ʻano.
    /// Ua hoʻokaʻawale ʻia ka buffer me ke kaulike 2 (no `u16`), akā ma hope o ka hoʻohuli ʻana iā ia i `Vec<u8>` e hoʻopili ʻia me ke kaulike 1.
    ///
    /// I ka ona o `ptr` ua kuleʻa hoololiia i ka `Vec<T>` a i laila deallocate, reallocate 'ole hoʻololi i nā mea o ka iaiyoe kuhikuhi ia e ka laʻau kuhikuhi i makemake.
    /// E hōʻoia i ka hoʻohana ʻole ʻana o ka mea kuhikuhi ma hope o ke kāhea ʻana i kēia hana.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Hoʻohou i kēia ke kūpaʻa ka vector_into_raw_parts.
    ///     // Kāohi i ka holo ʻana o ka mea hōʻino a mākou e kaohi piha nei i ka hoʻokaʻawale.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // E huki i nā ʻikepili nui like ʻole e pili ana i `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // E hoʻokahuli i ka hoʻomanaʻo me 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // E hoʻihoʻi i nā mea āpau i kahi Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Kūkulu i kahi `Vec<T, A>` hou, hakahaka.
    ///
    /// Ke vector e ole līkaia a hehee wale e pahu ma luna o ia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Kūkulu i kahi `Vec<T, A>` hakahaka hou me ka mana i kuhikuhi ʻia me ka mea hāʻawi i hāʻawi ʻia.
    ///
    /// Na vector e e hiki ke paa pono `capacity` nā kumumea me reallocating.
    /// Inā ʻo `capacity` ka 0, ʻaʻole hoʻokaʻawale ka vector.
    ///
    /// He mea nui e hoʻomaopopo ʻoiai ʻo vector i hoʻihoʻi ʻia he *kaha* i kuhikuhi ʻia, e loaʻa i ka vector kahi lōʻihi *ʻole*.
    ///
    /// No ka wehewehe ʻana i ka ʻokoʻa ma waena o ka loa a me ka hiki, e ʻike i *[Ka hiki a me ka hoʻonohonoho hou ʻana]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // ʻAʻohe o ka vector i nā huahana, ʻoiai nona ka mana no nā mea hou aʻe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Hana ʻia kēia mau mea me ka ʻole o ka hoʻoili hou ʻana ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... akā, i kēia e hana i ka vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Hana i kahi `Vec<T, A>` pololei mai nā mea maka o kekahi vector.
    ///
    /// # Safety
    ///
    /// He nui unsafe, ma muli o ka helu ana o invariants i mea ole kulana kupono:
    ///
    /// * `ptr` pono e hoʻokaʻawale ʻia ma o [String`]/ʻVec<T>((ma ka liʻiliʻi, pololei ʻole paha inā ʻaʻole ia).
    /// * `T` pono e loaʻa ka nui a me ke kaulike e like me ka `ptr` i hoʻokaʻawale ʻia me.
    ///   (`T` me ka hoʻoliʻiliʻi koʻikoʻi ʻaʻole lawa, pono pono ke kaulike e māʻona i ka [`dealloc`] koi e pono e hoʻokaʻawale a hoʻomanaʻo ʻia me ka hoʻonohonoho like.)
    ///
    /// * `length` pono e emi ma lalo a i ʻole like paha me `capacity`.
    /// * `capacity` pono e hiki i ka mākia i hāʻawi ʻia me ka kuhikuhi.
    ///
    /// ʻO ka hōʻino ʻana i kēia mau mea ke kumu o nā pilikia e like me ka hōʻino ʻana i nā ʻikepili o loko o ka mea hoʻokaʻawale.Eia kahi laʻana **ʻaʻole** palekana e kūkulu i kahi `Vec<u8>` mai kahi kuhikuhi a i kahi hoʻonohonoho C `char` me ka lōʻihi `size_t`.
    /// ʻAʻole palekana ia e kūkulu i hoʻokahi mai kahi `Vec<u16>` a me kona lōʻihi, no ka mea mālama ka mea hoʻokaʻawale i ke kaulike, a he ʻokoʻa nā ʻano ʻelua o kēia mau ʻano.
    /// Ua hoʻokaʻawale ʻia ka buffer me ke kaulike 2 (no `u16`), akā ma hope o ka hoʻohuli ʻana iā ia i `Vec<u8>` e hoʻopili ʻia me ke kaulike 1.
    ///
    /// I ka ona o `ptr` ua kuleʻa hoololiia i ka `Vec<T>` a i laila deallocate, reallocate 'ole hoʻololi i nā mea o ka iaiyoe kuhikuhi ia e ka laʻau kuhikuhi i makemake.
    /// E hōʻoia i ka hoʻohana ʻole ʻana o ka mea kuhikuhi ma hope o ke kāhea ʻana i kēia hana.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Hoʻohou i kēia ke kūpaʻa ka vector_into_raw_parts.
    ///     // Kāohi i ka holo ʻana o ka mea hōʻino a mākou e kaohi piha nei i ka hoʻokaʻawale.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // E huki i nā ʻikepili nui like ʻole e pili ana i `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // E hoʻokahuli i ka hoʻomanaʻo me 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // E hoʻihoʻi i nā mea āpau i kahi Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Hoʻopau i kahi `Vec<T>` i loko o kāna mau mea hana.
    ///
    /// E hoʻihoʻi i ka kuhikuhi kiko i ka ʻikepili i lalo, ka lōʻihi o ka vector (i nā mea), a me ka hiki i hoʻokaʻawale ʻia o ka ʻikepili (i nā mea.
    /// ʻO kēia nā paio like i ke kaʻina like me nā hoʻopaʻapaʻa iā [`from_raw_parts`].
    ///
    /// Ma hope o ke kāhea ʻana i kēia kuleana, kuleana ke kāhea no ka hoʻomanaʻo i hoʻokele mua ʻia e ka `Vec`.
    /// ʻO ke ala wale nō e hana ai i kēia ke hoʻololi i ka pointer maka, ka lōʻihi, a me ka hiki i hoʻi i `Vec` me ka hana [`from_raw_parts`], e ʻae i ka mea hōʻino e hana i ka hoʻomaʻemaʻe.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Hiki iā mākou ke hana i nā hoʻololi i nā ʻāpana, e like me ka lawe ʻana i ka pointer maka i kahi ʻano maʻalahi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Hoʻopau i kahi `Vec<T>` i loko o kāna mau mea hana.
    ///
    /// Hoʻihoʻi i ka kuhikuhi maka i ka ʻike ma lalo, ka lōʻihi o ka vector (i nā mea), ka mana i hāʻawi ʻia o ka ʻikepili (i nā mea), a me ka mea hoʻokaʻawale.
    /// ʻO kēia nā paio like i ke kaʻina like me nā hoʻopaʻapaʻa iā [`from_raw_parts_in`].
    ///
    /// Ma hope o ke kāhea ʻana i kēia kuleana, kuleana ke kāhea no ka hoʻomanaʻo i hoʻokele mua ʻia e ka `Vec`.
    /// ʻO ke ala wale nō e hana ai i kēia ke hoʻololi i ka pointer maka, ka lōʻihi, a me ka hiki i hoʻi i `Vec` me ka hana [`from_raw_parts_in`], e ʻae i ka mea hōʻino e hana i ka hoʻomaʻemaʻe.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Hiki iā mākou ke hana i nā hoʻololi i nā ʻāpana, e like me ka lawe ʻana i ka pointer maka i kahi ʻano maʻalahi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Hoʻihoʻi i ka helu o nā mea i hiki i ka vector ke hoʻopaʻa me ka ʻole o ka reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `Vec<T>` i hāʻawi ʻia.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    /// Ma hope o ke kāhea ʻana iā `reserve`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// ʻAʻohe mea inā lawa ka hiki.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka mana hou ma mua o `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Mālama i ka palena iki ka hiki no `additional` kikoʻī hou aʻe e hoʻokomo ʻia i ka `Vec<T>` i hāʻawi ʻia.
    ///
    /// Ma hope o ke kāhea ʻana iā `reserve_exact`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila, ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo `reserve` inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka mana hou iā `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// E hoʻāʻo e mālama i ka hiki no `additional` mau mea hou aku e hoʻokomo ʻia i ka `Vec<T>` i hāʻawi ʻia.
    /// Mālama paha ka hōʻiliʻili i kahi ākea e pale ai i nā reallocations pinepine.
    /// Ma hope o ke kāhea ʻana iā `try_reserve`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional`.
    /// ʻAʻohe mea inā lawa ka hiki.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve(data.len())?;
    ///
    ///     // I kēia manawa maopopo iā mākou ʻaʻole hiki iā OOM i ka waena o kā mākou hana paʻakikī
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // paʻakikī loa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// E hoʻāʻo e mālama i ka palena iki no nā pono `additional` kikoʻī e hoʻokomo ʻia i ka `Vec<T>` i hāʻawi ʻia.
    /// Ma hope o ke kāhea ʻana iā `try_reserve_exact`, ʻoi aku ka nui ma mua o a i ʻole like paha iā `self.len() + additional` inā hoʻi iā `Ok(())`.
    ///
    /// Hana ʻole i kekahi mea inā lawa ka hiki.
    ///
    /// E hoʻomaopopo e hāʻawi paha ka mea hoʻokaʻawale i ka hōʻiliʻili i kahi ākea ma mua o kāna noi.
    /// No laila, ʻaʻole hiki ke hilinaʻi ʻia ka hiki ke liʻiliʻi.
    /// Makemake ʻo `reserve` inā manaʻo ʻia nā hoʻokomo future.
    ///
    /// # Errors
    ///
    /// Inā hoʻonui ka hiki, a hōʻike paha ka mea hoʻokaʻawale i kahi hemahema, a laila hoʻihoʻi ʻia kahi hemahema.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Mālama ʻia ka hoʻomanaʻo, puka inā ʻaʻole hiki iā mākou
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // I kēia manawa maopopo iā mākou ʻaʻole hiki iā OOM i ka waena o kā mākou hana paʻakikī
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // paʻakikī loa
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Emi aku ana lakou i ka 'auhau o ka vector like ka nui me hiki.
    ///
    /// E hāʻule ʻo ia i lalo a kokoke i ka lōʻihi akā e hoʻomaopopo mau paha ka mea hoʻokaʻawale i ka vector e loaʻa kahi manawa no kekahi mau mea hou aku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ʻAʻole emi ka hiki ma mua o ka lōʻihi, a ʻaʻohe mea e hana ai ke like lākou, no laila hiki iā mākou ke pale i ka hihia panic ma `RawVec::shrink_to_fit` ma ke kāhea wale ʻana iā ia me kahi ʻoi aku ka nui.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Hoʻopiʻi i ka hiki o vector me kahi palena haʻahaʻa.
    ///
    /// E noho ka hiki ma ka liʻiliʻi e like me ka lōʻihi a me ka waiwai i hoʻolako ʻia.
    ///
    ///
    /// Inā ʻoi aku ka liʻiliʻi o kēia manawa ma mua o ka palena haʻahaʻa, he no-op kēia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Pio ka vector i [`Box<[T]>`][owned slice].
    ///
    /// E hoʻomaopopo e hāʻule ana kēia i kekahi mana keu.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Wehe ʻia kekahi mea nui aʻe:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Hoʻopōkole 'oe i ka vector, ka malama ana i ka mua `len` hehee wale, a hooki i ke koena.
    ///
    /// Inā ʻoi aku ka nui o `len` ma mua o ka lōʻihi o vector i kēia manawa, ʻaʻohe hopena o kēia.
    ///
    /// Ke [`drain`] papa hana hiki holoʻokoʻaai `truncate`, akā, ke kumu o ka oi hehee wale, e e hoi kahi o ka haule iho la iluna.
    ///
    ///
    /// E noke i keia iaoia i ole ia ma ka anao? Aou nona iho o ka vector.
    ///
    /// # Examples
    ///
    /// Ke kuhi nei i kahi ʻelima vector i ʻelua mau mea:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// ʻAʻole loaʻa kahi truncation ke ʻoi aku ka nui o `len` ma mua o ka lōʻihi o vector i kēia manawa:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Hoʻokiʻoki ke like ʻo `len == 0` me ke kāhea ʻana i ke ʻano [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Palekana kēia no ka mea:
        //
        // * ʻo ka ʻāpana i hāʻawi ʻia iā `drop_in_place` he kūpono;pale ka hihia `len > self.len` i ka hana ʻana i kahi ʻāpono kūpono ʻole, a
        // * ua haki ka `len` o ka vector ma mua o ke kāhea ʻana iā `drop_in_place`, no laila ʻaʻole e hoʻokuʻu ʻia ka waiwai i ka manawa ʻo `drop_in_place` iā panic i hoʻokahi manawa (inā ʻo panics i ʻelua manawa, hoʻopau ʻia ka papahana).
        //
        //
        //
        unsafe {
            // Note: Kuhi ʻia ʻo `>` kēia a ʻaʻole `>=`.
            //       Ke hoʻololi nei iā `>=` he hopena maikaʻi ʻole ka hopena ma kekahi mau hihia.
            //       E ʻike iā #78884 no ka mea hou aku.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Nā pōʻalo i kekahi māhele i loaʻa i ka vector holoʻokoʻa.
    ///
    /// Like ia `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Hoʻopili i kahi ʻāpana mutable o ka vector holoʻokoʻa.
    ///
    /// Kūlike ʻia me `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Hoʻihoʻi i kahi kuhikuhi maka i ka buffer o vector.
    ///
    /// Pono ka mea e kelepona ana e hōʻoia i ka vector e ola i ka kuhikuhi i kēia hoʻihoʻi i hoʻihoʻi, a i ʻole a e hoʻopau paha i ke kuhikuhi ʻana i nā ʻōpala.
    /// Ke hoʻololi nei i ka vector hiki ke hoʻoneʻe i kāna buffer, a he mea ʻole ia e kuhikuhi ʻia kekahi mau kuhikuhi iā ia.
    ///
    /// Pono e hōʻoia ka mea e kelepona ana ʻaʻole e kākau ʻia ka hoʻomanaʻo o ka poʻomanaʻo (non-transitively) (koe wale nō i loko o `UnsafeCell`) me ka hoʻohana ʻana i kēia kuhikuhi a i ʻole nā kuhikuhi i loaʻa iā ia.
    /// Inā pono ʻoe e hoʻololi i nā ʻike o ka ʻāpana, e hoʻohana iā [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ke aka nei mākou i ke ʻano slice o ka inoa like e hōʻalo i ka hele ʻana ma o `deref`, kahi e hoʻokumu ai i kahi kūmole waena.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Hoʻoiho i kahi kuhikuhi kuhi palekana palekana ʻole i ka buffer o vector.
    ///
    /// Pono ka mea e kelepona ana e hōʻoia i ka vector e ola i ka kuhikuhi i kēia hoʻihoʻi i hoʻihoʻi, a i ʻole a e hoʻopau paha i ke kuhikuhi ʻana i nā ʻōpala.
    ///
    /// Ke hoʻololi nei i ka vector hiki ke hoʻoneʻe i kāna buffer, a he mea ʻole ia e kuhikuhi ʻia kekahi mau kuhikuhi iā ia.
    ///
    /// # Examples
    ///
    /// ```
    /// // Hāʻawi i vector nui lawa no nā mea 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialize nā mea ma o ka pointer maka kākau, a laila hoʻonohonoho i ka lōʻihi.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Ke aka nei mākou i ke ʻano slice o ka inoa like e hōʻalo i ka hele ʻana ma o `deref_mut`, kahi e hoʻokumu ai i kahi kūmole waena.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Hoʻihoʻi i kahi kuhikuhi i ka mea hoʻokaʻawale ma lalo.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Koa i ka lōʻihi o ka vector i `new_len`.
    ///
    /// He hana pae haʻahaʻa kēia e mālama ʻole i kekahi o nā invariants maʻamau o ke ʻano.
    /// Hoʻololi maʻamau ka lōʻihi o vector hana ʻia me ka hoʻohana ʻana i kekahi o nā hana palekana ma kahi o, e like me [`truncate`], [`resize`], [`extend`], a i ʻole [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` pono ma lalo a i ʻole like paha me [`capacity()`].
    /// - ʻO nā kumumea ma `old_len..new_len` pono e initialized.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Hiki ke hoʻohana ʻia kēia hana no nā hanana a vector e lawelawe nei ma ke ʻano he buffer no nā pāʻālua ʻē aʻe, ʻoi aku ma luna o FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // He iwi iwi liʻiliʻi wale kēia no ka laʻana o ka doc;
    /// # // mai e hana i kēia me ka hoʻomaka wahi no kekahi maoli hale waihona puke.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Ma nā palapala a ka hana FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: Ke hoʻihoʻi ʻo `deflateGetDictionary` iā `Z_OK`, paʻa ia i:
    ///     // 1. `dict_length` ua hoʻokumu ʻia nā kumu mua.
    ///     // 2.
    ///     // `dict_length` <=ka hiki (32_768) i palekana iā `set_len` e kāhea.
    ///     unsafe {
    ///         // E kāhea iā FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... a update i ka lōʻihi i mea i initialized.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Oiai ka kēia laʻana mea kani, aia no he iaiyoe liu hope i ole hookuu mamua i ka `set_len` kahea i ka pā vectors:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` mea hakahaka no laila,ʻaʻohe kumu pono e e initialized.
    /// // 2. `0 <= capacity` paʻa mau i nā `capacity` āpau.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// ʻO ka maʻamau, ma aneʻi, e hoʻohana kekahi i [`clear`] ma kahi e kulu pololei i nā ʻike a no laila ʻaʻole e hoʻokahe i ka hoʻomanaʻo.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Wehe i kahi mea mai ka vector a hoʻihoʻi iā ia.
    ///
    /// Ke wehe i nā hehee ai UAIAaIN ~ ma ka hope hehee ai o ka vector.
    ///
    /// 'Aʻole i kēia mālama' ana i hoonoho papa, akā, o O(1).
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `index` ma waho o nā palena.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Hoʻololi mākou iā mākou iho [index] me ka mea hope loa.
            // E hoʻomaopopo inā inā kūleʻa nā palena ma luna pono e loaʻa kahi mea hope loa (hiki iā ia iho [index] ponoʻī.
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Hoʻokomo i kahi mea ma ke kūlana `index` ma waena o ka vector, e hoʻololi nei i nā mea āpau ma hope o ka ʻākau.
    ///
    ///
    /// # Panics
    ///
    /// Panics ina `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // hakahaka no ka mea hou
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible ka wahi e waiho ai i ka hou cia
            //
            {
                let p = self.as_mut_ptr().add(index);
                // E hoʻohuli i nā mea āpau e hana i kahi.
                // (Pālua i ka ʻenekumu ʻ ʻelua ma nā wahi ʻelua.)
                ptr::copy(p, p.offset(1), len - index);
                // Kākau iā ia i loko, e kāpae nei i ke kope mua o ka 'index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Wehe a hoʻihoʻi i ka mea ma ke kūlana `index` ma waena o vector, e hoʻololi nei i nā mea āpau ma hope o ka hema.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā ʻo `index` ma waho o nā palena.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // kahi a mākou e lawe nei.
                let ptr = self.as_mut_ptr().add(index);
                // kope iā ia, me ka makaʻu ʻole i kahi kope o ka waiwai ma ka stack a ma ka vector i ka manawa like.
                //
                ret = ptr::read(ptr);

                // E hoʻohuli i nā mea āpau e hoʻopiha i kēlā wahi.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Mālama wale i nā mea i kuhikuhi ʻia e ka predicate.
    ///
    /// I nā huaʻōlelo ʻē aʻe, wehe i nā mea āpau `e` e like me ka hoʻihoʻi ʻana o `f(&e)` iā `false`.
    /// Ke hana nei kēia hana ma kahi, e kipa pololei ʻana i kēlā me kēia mea i ka hoʻonohonoho kumu, a mālama i ke kaʻina o nā mea i hoʻopaʻa ʻia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// No ka mea, e kipa pono hookahi no nā kumu i loko o ka palapala kauoha, mawaho moku'āina hiki ke hoʻohana i ka olelo a hehee wale, e mālama.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Hōʻalo i ke kulu lua inā ʻaʻole hoʻokō ʻia ke kiaʻi kulu, ʻoiai hiki iā mākou ke hana i kekahi mau lua i ke kaʻina hana.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-hana ʻia ʻo len-> |^-aʻe e nānā
        //                  | <-holoi ʻia cnt-> |
        //      | <-original_len-> |Mālama ʻia: Nā mea i predicate e hoʻi maoli ai.
        //
        // Hole: Kamehameha e paha, Nākulukulu nō hehee ai kau.
        // Unchecked: Unchecked i pololei ia oihana mua.
        //
        // E kāhea ʻia kēia kiaʻi hāʻule i ka wā e panic a i ʻole `drop` o ka mea.
        // Hoʻololi ia i nā mea i nānā ʻole ʻia e uhi i nā lua a me `set_len` i ka lōʻihi pololei.
        // I nā hihia ke predick a `drop` ʻaʻole panick, e hoʻonui ʻia ia i waho.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SAFETY: Pono e hōʻoia i nā huahana i nānā ʻole ʻia no ka mea ʻaʻole mākou e hoʻopā iā lākou.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // Maluhia: Ma hope o hoopiha mai ana i lua, a pau 'ikamu i loko o kokoke iaiyoe.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Pono e he pono ka mea i nānā ʻole ʻia.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // E neʻe i mua e hōʻalo i ka hāʻule pālua inā makaʻu ʻo `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // Maluhia: kakou i hoopa aku i kēia hehee ai hou ma hope, Nakulukulu no.
                unsafe { ptr::drop_in_place(cur) };
                // Ua hele mua mākou i ka pākaukau.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, no laila ʻaʻole pono e kau ka lua puka me nā mea o kēia manawa.
                // He hana kope no ka neʻe aku, aʻaʻole loa e hoopa hou i kēia hehee ai.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Hoʻopili ʻia nā mea āpau.Hiki ke hoʻonui ʻia kēia i `set_len` e LLVM.
        drop(g);
    }

    /// Wehe i nā mea āpau akā nā mea mua o nā mea pili ma vector e hoʻoholo i ke kī like.
    ///
    ///
    /// Inā hoʻokaʻawale ʻia ka vector, hemo kēia i nā mea i kope ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Wehe i nā mea āpau akā nā mea mua o nā mea pili i ka vector e hōʻoluʻolu nei i kahi pili like i hāʻawi ʻia.
    ///
    /// Hoʻouna ʻia ka hana `same_bucket` i nā kūmole i ʻelua mau mana mai ka vector a pono e hoʻoholo inā hoʻohālikelike nā mea like.
    /// Hoʻoholo ʻia nā mea i ka ʻaoʻao ʻē aʻe mai kā lākou ʻoka i ka ʻāpana, no laila inā hoʻihoʻi ʻo `same_bucket(a, b)` iā `true`, hoʻoneʻe ʻia ʻo `a`.
    ///
    ///
    /// Inā hoʻokaʻawale ʻia ka vector, hemo kēia i nā mea i kope ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Pākuʻi i kahi mea ma hope o kahi hōʻiliʻili.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka mana hou ma mua o `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Kēia e panic a i ʻole kāpae inā mākou e hoʻokaʻawale> isize::MAX bytes a i ʻole inā piʻi ka lōʻihi o ka lōʻihi no nā ʻano ʻaʻohe-nui.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// E lawe aku oe i ka hope hehee ai, mai ka vector, a hoike ia, a [`None`] ina ia mea nele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// E hoʻoneʻe i nā mea āpau o `other` i `Self`, e waiho hakahaka nei i `other`.
    ///
    /// # Panics
    ///
    /// Panics inā hoʻonui ka helu o nā mea i ka vector i kahi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Hoʻopili i nā mea i `Self` mai kahi pale ʻē aʻe.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Hoʻokumu i kahi iterator hoʻokahe e hoʻoneʻe i ka pae i kuhikuhi ʻia ma vector a hāʻawi i nā mea i lawe ʻia.
    ///
    /// Ke hāʻule ka iterator **, hoʻoneʻe ʻia nā mea āpau o ka pae mai vector, ʻoiai inā ʻaʻole i hoʻopau pono ʻia ka iterator.
    /// Inā ʻaʻole **hāʻule ka iterator**(me [`mem::forget`] ʻo kahi laʻana), ʻike ʻole ʻia ehia mau mea i lawe ʻia.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka helu hoʻomaka ma mua o ka hopena a i ʻole inā ʻoi aku ka nui o ka hopena ma mua o ka lōʻihi o ka vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Hoʻomaʻemaʻe kahi pae piha i ka vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Palekana palekana
        //
        // Ke hana mua ʻia ka Drain, hoʻopōkole ia i ka lōʻihi o ke kumu vector e hōʻoia i ka loaʻa ʻole o nā mea uninitialized a i neʻe ʻia-mai nā mea āpau inā ʻaʻole holo ka Zachtor's destructor.
        //
        //
        // Drain e ptr::read i nā waiwai e hemo.
        // Ke pau, kope i koe o nā vector e kope i hope e uhi i ka lua, a hoʻihoʻi ʻia ka lōʻihi vector i ka lōʻihi hou.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // huapalapala self.vec lōʻihi A e hoʻomaka, e noho maluhia ma ka hihia Drain ua pūnāwai
            self.set_len(start);
            // E hoʻohana i ke kēia i loko o ka IterMut, e hōʻike i lawekahikiʻia hana o ka pau Drain iterator (e like &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Holoi i ka vector, e hemo nei i nā waiwai āpau.
    ///
    /// E noke i keia iaoia i ole ia ma ka anao? Aou nona iho o ka vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Hoike i ka helu ana o hehee wale i loko o ka vector, i haawi ia ia e like me kona 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Hoʻi iā `true` inā ʻaʻohe o ka vector i kahi o nā mea.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Māhele i ka hōʻiliʻili i ʻelua ma ka papa kuhikuhi i hāʻawi ʻia.
    ///
    /// Hoʻihoʻi i kahi vector i hoʻokaʻawale hou ʻia i loaʻa nā mea i ka pae `[at, len)`.
    /// Ma hope o ke kāhea ʻana, e waiho ʻia ka vector kumu me ka loaʻa ʻana o nā mea `[0, at)` me kona hiki ʻole i hoʻololi ʻia.
    ///
    ///
    /// # Panics
    ///
    /// Panics inā `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // hiki i ka vector hou ke lawe i ka buffer kumu a pale i ke kope
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsafely `set_len` a kope i nā mea i `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Hoʻonohonoho hou i ka `Vec` ma kahi i like ai ka `len` me `new_len`.
    ///
    /// Inā `new_len`, ua oi aku ma mua o `len`, ka `Vec` ua kīkoʻo ma ka like, a me kela mea keia mea hou kau piha i ka hopena o ke kahea ana i ka panina `f`.
    ///
    /// ʻO nā waiwai hoʻihoʻi mai `f` e pau i ka `Vec` i ke kauoha a lākou i hana ai.
    ///
    /// Inā ʻo `new_len` ma lalo o `len`, truncated maʻalahi ka `Vec`.
    ///
    /// Hoʻohana kēia hana i ka pani ʻana e hana i nā waiwai hou i kēlā me kēia kaomi.Inā makemake ʻoe iā [`Clone`] i kahi waiwai i hāʻawi ʻia, e hoʻohana iā [`Vec::resize`].
    /// Inā makemake ʻoe e hoʻohana i ka [`Default`] trait e hoʻonui ai i nā waiwai, hiki iā ʻoe ke hala i [`Default::default`] ma ke ʻano he hoʻopaʻapaʻa lua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Hoʻopau a hoʻokahe i ka `Vec`, e hoʻihoʻi nei i kahi kuhikuhi hiki ke hoʻololi i nā ʻike. `&'a mut [T]`.
    /// E hoʻomaopopo he pono ke ola `T` i ke ola `'a` i wae ʻia.
    /// Inā he kūmole kūmau wale ke ʻano, a ʻaʻohe paha, a laila hiki ke koho ʻia i `'static`.
    ///
    /// Kēia kuleana pili i ka i 'ano like me ke kuleana pili i [`leak`][Box::leak] ma [`Box`] wale i ka mea, aohe ala, e loaa i ka pūnāwai iaiyoe.
    ///
    ///
    /// He mea nui kēia hana no ka ʻikepili e ola nei no ke koena o ke ola o ka papahana.
    /// ʻO ka waiho ʻana i kahi kūmole i hoʻihoʻi ʻia e hana i kahi pūpū hoʻomanaʻo.
    ///
    /// # Examples
    ///
    /// Hoʻohana maʻalahi:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Hoʻihoʻi i ke koena i koe o ka vector ma ke ʻāpana o `MaybeUninit<T>`.
    ///
    /// Hiki ke hoʻohana ʻia ka ʻāpana i hoʻi ʻia e hoʻopihapiha i ka vector me ka ʻikepili (e laʻa
    /// ma ka heluhelu ʻana mai kahi faila) ma mua o ka māka ʻana i ka ʻikepili e like me ka hoʻomaka ʻana me ka hoʻohana [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Hoʻokaʻawale iā vector nui lawa no nā mea he 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // E hoopiha i loko o ka mua 3 hehee wale.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // E kaha i nā mea mua 3 o ka vector e like me ka mea i hoʻomaka mua ʻia.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Kēia papa hana, 'aʻole hoʻokō i ka hua'ōlelo o `split_at_spare_mut`, e pale aku invalidation o ka mea kuhikuhi i ka aooa.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Hoʻihoʻi i ka ʻike vector ma ke ʻano he ʻāpana o `T`, me ke koena o ka vector i ʻāpana o `MaybeUninit<T>`.
    ///
    /// Hiki ke hoʻohana ʻia ka ʻāpana manawaleʻa hoʻihoʻi e hoʻopiha i ka vector me ka ʻikepili (e laʻa me ka heluhelu ʻana mai kahi faila) ma mua o ka māka ʻana i ka ʻikepili e like me ka hoʻomaka ʻana me ka hoʻohana [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// E hoʻomaopopo he API pae haʻahaʻa kēia, a pono e hoʻohana ʻia me ka mālama no nā kumu ʻoi loa.
    /// Inā pono ʻoe e hoʻopili i ka ʻikepili i kahi `Vec` hiki iā ʻoe ke hoʻohana i [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] a i ʻole [`resize_with`], ke kaukaʻi ʻia i kāu mau pono kikoʻī.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserve hou makahiki nui kupono no ka 10 hehee wale.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Hoʻopiha i nā mea ʻē aʻe e hiki mai ana.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // E kaha i nā mea 4 o ka vector e like me ka mea i hoʻomaka mua ʻia.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - nānā ʻole ʻia ʻo len a no laila ʻaʻole i loli
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Palekana: ʻo ka hoʻololi ʻana i hoʻi .2 (&mut usize) i manaʻo ʻia he like ia me ke kāhea ʻana iā `.set_len(_)`.
    ///
    /// Hoʻohana ʻia kēia hana i ke komo ʻokoʻa ʻana i nā ʻāpana vektor a pau i ka manawa hoʻokahi ma `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` hōʻoia ʻia e kūpono no nā mea `len`
        // - `spare_ptr` ke kuhikuhi nei i hoʻokahi mea ma mua o ka pale pale, no laila ʻaʻole ia e hoʻopili ʻia me `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Hoʻonohonoho hou i ka `Vec` ma kahi i like ai ka `len` me `new_len`.
    ///
    /// Inā `new_len`, ua oi aku ma mua o `len`, ka `Vec` ua kīkoʻo ma ka like, a me kela mea keia mea hou kau piha me `value`.
    ///
    /// Inā ʻo `new_len` ma lalo o `len`, truncated maʻalahi ka `Vec`.
    ///
    /// Kēia papa hana pono `T` e hoʻokō [`Clone`], ma ka mea e e hiki ke clone i ka hooholoia waiwai.
    /// Inā makemake ʻoe i kahi maʻalahi hou aʻe (a i ʻole makemake e hilinaʻi iā [`Default`] ma kahi o [`Clone`]), e hoʻohana iā [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Pālolo a hoʻopili ʻia i nā mea āpau i kahi ʻāpana i ka `Vec`.
    ///
    /// Iterates ma luna o ka ʻāpana `other`, kālani ʻia i kēlā me kēia mea, a laila hoʻopili ʻia i kēia `Vec`.
    /// Lawe ʻia ka `other` vector ma ka papa kauoha.
    ///
    /// E hoʻomaopopo he like kēia hana me [`extend`] koe wale nō he loea e hana me nā ʻāpana ma kahi.
    ///
    /// Inā a me ka wā Rust loaʻa specialization keia papa, e paha e kaila (akā nō i loaʻa).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// E kope i nā mea mai ka `src` pae i ka hopena o vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` hōʻoia i ka pololei o ka pae i hāʻawi ʻia no ka helu ʻana iā ʻoe iho
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Kuhi kēia code i ka `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Hohola aku i ka vector ma `n` waiwai, ka hoʻohana 'ana i ka haawiia mai mīkini hana wāwahie.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // E hoʻohana iā SetLenOnDrop e hana a puni kahi huna kahi e ʻike ʻole ai ka mea hoʻopili i ka hale kūʻai ma o `ptr` ma o self.set_len() mai alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Kākau i nā mea āpau a koe ka mea hope loa
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // E hoʻonui i ka lōʻihi i kēlā me kēia ʻanuʻu i ka hihia next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Hiki iā mākou ke kākau pololei i ka mea hope loa me ka pono ʻole o ka cloning
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len hoʻonoho ʻia e ke kahu kiaʻi
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Wehe i nā mea hou aʻe i ka vector e like me ka [`PartialEq`] trait hoʻokō.
    ///
    ///
    /// Inā hoʻokaʻawale ʻia ka vector, hemo kēia i nā mea i kope ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Nā hana a me nā hana kūloko
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` pono i ka index pono
    /// - `self.capacity() - self.len()` pono e `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - Hoʻonui ʻia ʻo len ma hope wale nō o nā kumu hoʻomaka ʻana
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - hōʻoia ka mea kelepona ʻO src kahi helu kuhikuhi kūpono
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Hoʻomaka mua ʻia ʻo Element me `MaybeUninit::write`, no laila maikaʻi ke hoʻonui iā len
            // - hoʻonui ʻia ʻo len ma hope o kēlā me kēia mehana e pale i nā kahe (e nānā i ka #82533 helu)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - hōʻoia ka mea kelepona ʻo `src` kahi helu kuhikuhi kūpono
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Hana ʻia nā kuhi ʻelua mai nā kūmole ʻāpana kūpanaha (`&mut [_]`) no laila kūpono lākou a ʻaʻole e hoʻopili.
            //
            // - Nā mea i: Kope no laila maikaʻi ke kope iā lākou, me ka hana ʻole ʻana i kekahi mea me nā kumu kumu
            // - `count` kūlike ia me ka len o `source`, no laila kūpono ke kumu no `count` heluhelu
            // - `.reserve(count)` hoʻohiki i ka `spare.len() >= count` no laila ua kūpono ia no `count` kākau
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Hoʻomaka mua ʻia nā mea e `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Nā hoʻokō trait maʻamau no Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): me cfg(test) ke ʻano `[T]::to_vec` kūmau, i koi ʻia no kēia wehewehe ʻana o kēia hana, ʻaʻole i loaʻa.
    // E hoʻohana i ka hana `slice::to_vec` i loaʻa wale me cfg(test) NB e ʻike i ka module slice::hack ma slice.rs no ka ʻike hou aku.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // papa i nā mea ʻaʻole e hoʻokahuli ʻia
        self.truncate(other.len());

        // self.len <= other.len ma muli o ka truncate ma luna, no laila nā ʻoki ma aneʻi i loko o nā palena.
        //
        let (init, tail) = other.split_at(self.len());

        // hoʻohana hou i nā waiwai i loaʻa allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Hoʻokumu i kahi iterator e ʻai ana, ʻo ia hoʻi, e neʻe i kēlā me kēia waiwai mai ka vector (mai ka hoʻomaka a i ka hopena).
    /// Ke vector hiki ole e hoʻohana 'ma hope o ke kahea keia.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // He ʻano String ko kā, ʻaʻole &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // lau hana ia a likeʻole SpecFrom/SpecExtend implementations elele 'o ia ka mea, i ole hou optimizations e pili
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // ʻO kēia ka hihia no ka iterator ākea.
        //
        // Kēia papa e ia i ka pono like o:
        //
        //      no ka mea i ka iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // ʻAʻole hiki i ka NB ke hoʻonui aʻe no ka mea pono mākou e hoʻokaʻawale i ka wahi helu
                self.set_len(len + 1);
            }
        }
    }

    /// Hoʻokumu i kahi iterator splicing e pani i ka laulā i kuhikuhi ʻia i ka vector me ka hāʻawi `replace_with` i hāʻawi ʻia a hāʻawi i nā mea i lawe ʻia.
    ///
    /// `replace_with` ʻaʻole pono e like ka lōʻihi me `range`.
    ///
    /// `range` ua hoʻoneʻe ʻia inā ʻaʻole pau ka iterator a hiki i ka hopena.
    ///
    /// Kuhi ʻole ʻia i ka nui o nā mea i lawe ʻia mai ka vector inā kulu ka waiwai `Splice`.
    ///
    /// Pau ka mea hoʻokomo iterator `replace_with` ke hāʻule ka waiwai `Splice`.
    ///
    /// ʻOi aku ka maikaʻi inā:
    ///
    /// * ʻO ka huelo (nā mea i ka vector ma hope o `range`) hakahaka,
    /// * aiʻole `replace_with` e hāʻawi i nā mea liʻiliʻi a i ʻole like o nā mea ma mua o ka lōʻihi o "range"
    /// * aiʻole ka palena lalo o kāna `size_hint()` pololei.
    ///
    /// Inā ʻole, hoʻokaʻawale ʻia kahi vector manawa kūlohelohe a hoʻoneʻe ʻelua i ka huelo.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka helu hoʻomaka ma mua o ka hopena a i ʻole inā ʻoi aku ka nui o ka hopena ma mua o ka lōʻihi o ka vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Hoʻokumu i kahi iterator e hoʻohana i ka pani e hoʻoholo inā hemo kahi mea.
    ///
    /// Inā hoʻi maoli ka pani, a laila lawe ʻia ke kumu a hāʻawi ʻia.
    /// Inā hoʻi hewa ka pani ʻana, e hoʻomau ka mea i ka vector a ʻaʻole e hāʻawi ʻia e ka iterator.
    ///
    /// Hoʻohana ka hoʻohana ʻana i kēia hana i kēia code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kou kuhi 'aneʻi
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Akā ʻoi aku ka maʻalahi o ka `drain_filter` e hoʻohana.
    /// `drain_filter` ʻoi aku ka maikaʻi, no ka mea hiki iā ia ke hoʻihoʻi i nā ʻaoʻao o ka hoʻonohonoho i ka nui.
    ///
    /// Note i `drain_filter` kekahi ke hoike nei oe mutate kela hehee ai i loko o ka Kānana panina, nānā 'ole o ka ina paha e koho i ka malama a me ka wehe ia.
    ///
    ///
    /// # Examples
    ///
    /// Splitting ka kaua i loko o evens a me paʻewa, reusing ka mua e auaaeaiea:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Kiaʻi mai iā mākou e kiʻi ʻia (ka hoʻonui ʻana i ka leak)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Hoʻonui i ka hoʻokō kope ʻana i nā mea ma mua o ka hoʻokuʻi ʻana iā lākou i ka Vec.
///
/// Hana kūikawā ʻia kēia hoʻokō no nā iterator slice, kahi e hoʻohana ai iā [`copy_from_slice`] e hoʻopili i ka ʻāpana holoʻokoʻa i ka manawa hoʻokahi.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Hoʻohana i ka hoʻohālikelike o vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// E kakau mai ka hoʻouka i o vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // hoʻohana i ke kulu no [T] e hoʻohana i kahi ʻoki maka e kuhikuhi i nā mea o ka vector ma ke ʻano he nāwaliwali e pono ai;
            //
            // hiki ke pale i nā nīnau o ke kūpono i kekahi mau hihia
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Mālama ʻo RawVec i ka translocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Hana i mea nele `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: huki huki i ka libstd, i kumu e hewa ai ma aneʻi
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: huki huki i ka libstd, i kumu e hewa ai ma aneʻi
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Loaʻa i nā ʻike āpau o ka `Vec<T>` ma ke ʻano he hoʻonohonoho, inā kūlike ka nui me ia o ka lālani i noi ʻia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Inā ka lōʻihi 'aʻole' aʻohe, o ka hoʻokomo o ke hele mai hoʻi i loko o `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Inā 'oe makemake e me ka pololei noho i ka pākuʻina kau o ka `Vec<T>` uku, oe ke kahea aku [`.truncate(N)`](Vec::truncate) mua.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // Maluhia: `.set_len(0)` mea mau kani.
        unsafe { vec.set_len(0) };

        // SAFETY: Hoʻonohonoho pono ʻia kahi kuhikuhi a Vec`, a
        // ka hoʻopololei i ke ku pono o ka ia me ka mea mau.
        // Ua nānā mākou ma mua ua lawa kā mākou mau mea.
        // ʻAʻole e kulu pālua nā mea i ka `set_len` ʻōlelo i ka `Vec` ʻaʻole e hoʻokuʻu pū iā lākou.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}