use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ʻO trait hana kūikawā hou aʻe no Vec::from_iter pono e hana mua i ka hana i ka hana maʻamau i mua o [`SpecFromIter`](super::SpecFromIter) no nā kikoʻī.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Wehe i ka iteration mua, no ka mea e hoʻonui ʻia ka vector i kēia iteration i kēlā me kēia hihia ke ʻole ka hakahaka o ka iterable, akā ʻaʻole ʻike ka loop i extend_desugared() i ka piha ʻana o vector i nā hōʻike loop i hope.
        //
        // No laila e loaʻa iā mākou ka wānana branch ʻoi aku ka maikaʻi.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // pono elele 'o ia spec_extend() mai extend() ihoʻelele e spec_from no ka nele Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // pono elele 'o ia spec_extend() mai extend() ihoʻelele e spec_from no ka nele Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}