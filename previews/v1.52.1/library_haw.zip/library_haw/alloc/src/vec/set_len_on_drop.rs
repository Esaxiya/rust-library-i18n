// E hoʻonoho i ka lōʻihi o nā vector ke hele aku ka waiwai `SetLenOnDrop` ma waho o ka laulā.
//
// Ka manaʻo o: ka lōʻihi kahua ma SetLenOnDrop mea he kūloko ee iaaanu aey i ka optimizer e ike i ole Alia i kekahi hale kūʻai ma ka Vec kaʻikepili laʻau kuhikuhi.
// He He workaround no ka Alia Ka Ikepili pukana #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}