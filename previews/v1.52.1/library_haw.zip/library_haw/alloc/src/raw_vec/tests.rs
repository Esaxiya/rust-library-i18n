use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ʻO ke kākau ʻana i kahi hoʻāʻo o ka hoʻopili ʻana ma waena o ka poʻe ʻāpana ʻekolu a me `RawVec` he mea maʻalahi ʻole ia no ka mea ʻaʻole hōʻike ʻo `RawVec` API i nā ʻano hana hiki ke hoʻokaʻawale ʻia, no laila ʻaʻole hiki iā mākou ke nānā i ka mea e hana ana ke pau ka mea hoʻokaʻawale (ma waho o ka ʻike ʻana iā panic).
    //
    //
    // Ma kahi o, nānā wale kēia i nā hana `RawVec` ma ka liʻiliʻi e hele ma waena o ka Allocator API ke mālama ia i kahi waiho.
    //
    //
    //
    //
    //

    // ʻO kahi mea hoʻokaʻina kolohe nāna e hoʻopau i kahi nui o ka wahie ma mua o ka hoʻāʻo ʻana e hoʻomaka i ka hāʻule.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ke kumu o kahi realloc, no laila e hoʻohana ana i 50 + 150=200 ʻāpana o ka wahie)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Mua, `reserve` allocates e like `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // ʻOi aku ka 97 ma mua o ka pālua o 7, no laila e hana ʻo `reserve` e like me `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // ʻOi aku ka 3 ma mua o ka hapalua o 12, no laila e ulu nui ʻo `reserve`.
        // I ka manawa o ke kākau ʻana, he 2 kēia mea hoʻāʻo, no laila he 24 hou ka mana, eia nō naʻe, maikaʻi ka mea ulu o 1.5.
        //
        // No laila `>= 18` i ka ʻōlelo.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}