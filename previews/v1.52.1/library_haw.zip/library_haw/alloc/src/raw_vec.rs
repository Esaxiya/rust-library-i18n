#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Uninitialized nā mea o ka hoʻomanaʻo hou.
    Uninitialized,
    /// Hoʻopaʻa ʻia ka hoʻomanaʻo hou e lilo i zero.
    Zeroed,
}

/// ʻO kahi pono haʻahaʻa no ka hoʻokaʻawale ergonomically, hoʻoili, a me ka hāʻawi ʻana i kahi buffer o ka hoʻomanaʻo ma ka puʻu me ka hopohopo ʻole e pili ana i nā hihia kihi a pau i pili.
///
/// Maikaʻi loa kēia ʻano no ke kūkulu ʻana i kāu ʻikepili ponoʻī e like me Vec a me VecDeque.
/// I ke 'ano wae:
///
/// * Hana i ka `Unique::dangling()` ma nā ʻano zero.
/// * Hana iā `Unique::dangling()` ma nā hoʻokaʻawale palena lōʻihi.
/// * Hōʻalo iā `Unique::dangling()`.
/// * Hopu i nā kahawai āpau i nā helu helu ʻana (paipai iā lākou i "capacity overflow" panics).
/// * Nā kiaʻi e kūʻē ana i nā ʻōnaehana 32-bit e hoʻokaʻawale ana ma mua o nā isize::MAX bytes.
/// * Kū kiaʻi i ka hoʻonui ʻana i kou lōʻihi.
/// * Kāhea iā `handle_alloc_error` no nā hoʻokaʻina fallible.
/// * Loaʻa i kahi `ptr::Unique` a pēlā e hāʻawi ai i ka mea hoʻohana me nā keu pono e pili ana.
/// * Hoʻohana i ka mea i hoʻihoʻi ʻia mai ka mea hoʻokaʻawale e hoʻohana i ka hiki i loaʻa ka nui loa.
///
/// ʻAʻole nānā kēia ʻano i ka hoʻomanaʻo i hoʻokele ʻia.Ke waiho ʻia ia * e hoʻokuʻu i kona hoʻomanaʻo, akā ʻaʻole ia e hoʻāʻo e haʻalele i kāna ʻike.
/// Aia i ka mea hoʻohana o `RawVec` ke lawelawe i nā mea maoli * mālama ʻia i loko o kahi `RawVec`.
///
/// E hoʻomaopopo he mau mau ka nui o nā ʻano zero-nui, no laila `capacity()` hoʻi mau i `usize::MAX`.
/// Kēia mea pono ʻoe e akahele i ka hoʻopuni ʻana i kēia ʻano me `Box<[T]>`, ʻoiai ʻaʻole `capacity()` e hāʻawi i ka lōʻihi.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Aia kēia ma muli o ka pono ʻole o `#[unstable]` `const fn` i `min_const_fn` a no laila ʻaʻole hiki ke kāhea ʻia lākou i loko o`min_const_fn`s kekahi.
    ///
    /// Inā hoʻololi ʻoe i `RawVec<T>::new` a i ʻole nā mea i hilinaʻi ʻia, e ʻoluʻolu e lawe i kahi mea e hōʻino maoli iā `min_const_fn`.
    ///
    /// NOTE: Hiki iā mākou ke pale i kēia hack a nānā i ka hoʻohālikelike me kekahi ʻano `#[rustc_force_min_const_fn]` e koi ai i ka hoʻopili ʻana me `min_const_fn` akā ʻaʻole ia e ʻae i ke kāhea ʻana iā ia i `stable(...) const fn`/code hoʻohana ʻaʻole hiki iā `foo` ke loaʻa ʻo `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Hoʻokumu i ka `RawVec` nui loa (ma ka puʻu ʻōnaehana) me ka hoʻokaʻawale ʻole.
    /// Inā he nui maikaʻi ka `T`, a laila hana kēia i `RawVec` me ka hiki `0`.
    /// Inā `T` ka ʻole o ka nui, a laila hana ia i `RawVec` me ka hiki `usize::MAX`.
    /// Hoʻohana no ka hoʻokō ʻana i ka hoʻokaʻawale lohi.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Hana i kahi `RawVec` (ma ka puʻu ʻōnaehana) me ka pololei a me nā pono e pono ai no kahi `[T; capacity]`.
    /// Hoʻohālikelike kēia i ke kāhea ʻana iā `RawVec::new` ke `capacity` ʻo `0` a i ʻole `T` i ka nui ʻole.
    /// E hoʻomaopopo inā inā zero-nui ka `T` ʻo ia hoʻi ʻaʻole ʻoe * e kiʻi i kahi `RawVec` me ka mana i noi ʻia.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka nui i noi ʻia ma o `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Nā ʻoki ma OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// E like me `with_capacity`, akā e hōʻoiaʻiʻo i ka ʻaʻa ʻia ʻana o ka buffer.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitutes he `RawVec` mai ka laʻau kuhikuhi a me ka 'auhau.
    ///
    /// # Safety
    ///
    /// Pono e hoʻokaʻawale ʻia ka `ptr` (ma ka puʻu ʻōnaehana), a me ka `capacity` i hāʻawi ʻia.
    /// ʻAʻole hiki i ka `capacity` ke ʻoi aku i ka `isize::MAX` no nā ʻano nui.(kahi hopohopo wale nō ma nā ʻōnaehana 32-bit).
    /// Loaʻa iā ZST vectors ka hiki a hiki i `usize::MAX`.
    /// Inā hele mai ka `ptr` a me `capacity` mai kahi `RawVec`, a laila hōʻoia ʻia kēia.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ʻAmū nā Tec Vecs.E lele i:
    // - 8 inā he 1 ka nui o ka mea, no ka mea, e hoʻopuni paha kekahi mea hoʻokaʻawale i kahi noi ma lalo o 8 mau bytes a i ʻole 8 bytes.
    //
    // - 4 inā he kaulike ka nui o nā mea (<=1 KiB).
    // - 1 i ʻole, e hōʻalo i ka hoʻonele ʻana i nā wahi no nā Vecs pōkole loa.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// E like me `new`, akā parameter ʻia ma luna o ke koho a ka mea hoʻokaʻawale no ka `RawVec` i hoʻihoʻi ʻia.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` ʻo ia hoʻi "unallocated".Nānā ʻole ʻia nā ʻano nui ʻole.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// E like me `with_capacity`, akā parameter ʻia ma luna o ke koho a ka mea hoʻokaʻawale no ka `RawVec` i hoʻihoʻi ʻia.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// E like me `with_capacity_zeroed`, akā parameter ʻia ma luna o ke koho a ka mea hoʻokaʻawale no ka `RawVec` i hoʻihoʻi ʻia.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Hoʻohuli i `Box<[T]>` i `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Hoʻohuli i ka pale āpau i `Box<[MaybeUninit<T>]>` me ka `len` i kuhikuhi ʻia.
    ///
    /// E hoʻomaopopo e hana hou kēia i nā hoʻololi `cap` i hana ʻia paha.(E hōʻikeʻano o ke 'ano no ka lāliʻi.)
    ///
    /// # Safety
    ///
    /// * `len` pono e ʻoi aku ma mua a i ʻole kūlike i ka hiki ke noi ʻia, a
    /// * `len` pono ma lalo a i ʻole like paha me `self.capacity()`.
    ///
    /// E hoʻomaopopo, hiki i ka mana i noi ʻia a me `self.capacity()` ke ʻokoʻa, no ka mea hiki i kahi mea hoʻokaʻawale ke hoʻonui a hoʻihoʻi i kahi papa hoʻomanaʻo nui aʻe ma mua o ke noi.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-hōʻoia i hoʻokahi hapalua o ke koi palekana (ʻaʻole hiki iā mākou ke nānā i ka hapalua ʻē aʻe).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Hōʻalo mākou iā `unwrap_or_else` ma aneʻi no ka mea hoʻonui ia i ka nui o LLVM IR i hana ʻia.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Hoʻonohonoho hou i `RawVec` mai kahi kuhikuhi, hiki, a me ka mea hāʻawi.
    ///
    /// # Safety
    ///
    /// Pono e hoʻokaʻawale ʻia ka `ptr` (ma o ka mea hāʻawi `alloc` i hāʻawi ʻia), a me `capacity` i hāʻawi ʻia.
    /// ʻAʻole hiki i ka `capacity` ke ʻoi aku i ka `isize::MAX` no nā ʻano nui.
    /// (kahi hopohopo wale nō ma nā ʻōnaehana 32-bit).
    /// Loaʻa iā ZST vectors ka hiki a hiki i `usize::MAX`.
    /// Inā hele mai ka `ptr` a me `capacity` mai kahi `RawVec` i hana ʻia ma o `alloc`, a laila hōʻoia ʻia kēia.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Loaʻa i kahi kuhikuhi maka i ka hoʻomaka o ka hoʻokaʻawale.
    /// E hoʻomaopopo he `Unique::dangling()` kēia inā ʻo `capacity == 0` a i ʻole `T` ka nui ʻole.
    /// I ka hihia ma mua, pono ʻoe e akahele.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Loaʻa ka mana o ka hoʻokaʻawale.
    ///
    /// E `usize::MAX` mau kēia inā he zero-nui ka `T`.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// E hoʻihoʻi i kahi kuhikuhi pili i ka mea hoʻokaʻawale e kākoʻo nei i kēia `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Loaʻa iā mākou kahi ʻāpana o ka hoʻomanaʻo, no laila hiki iā mākou ke pale i nā hōʻoia holo manawa e kiʻi i kā mākou hoʻonohonoho o kēia manawa.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Hōʻoiaʻiʻo i loko o ka pale pale ma kahi o ka manawa kūpono e paʻa ai nā mea `len + additional`.
    /// Inā ʻaʻohe ona lawa ka hiki, e hoʻolālā hou i kahi ākea a me kahi e hōʻoluʻolu ai e hoʻolili ʻia *O*(1) hana.
    ///
    /// E kaupalena i kēia ʻano hana inā pono ia e hoʻoiho iā panic.
    ///
    /// Inā ʻoi aku ʻo `len` ma mua o `self.capacity()`, hiki ʻole i kēia ke hoʻokaʻawale maoli i kahi i noi ʻia.
    /// ʻAʻole palekana maoli kēia, akā ʻo ke code unsafe *āu* kākau e hilinaʻi nei i ka hana o kēia hana e haki paha.
    ///
    /// Kūpono kēia no ka hoʻokomo ʻana i kahi hana kaomi-nui e like me `extend`.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka mana hou ma mua o `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Nā ʻoki ma OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // E hoʻopau a pale paha ʻia ka mālama ʻana inā ʻoi aku ka len ma mua o `isize::MAX` no laila palekana kēia e hana ʻole ʻia i kēia manawa.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// ʻO ka like me `reserve`, akā hoʻi i nā hewa ma kahi o ka panicking a i ʻole ka haʻalele ʻana.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Hōʻoiaʻiʻo i loko o ka pale pale ma kahi o ka manawa kūpono e paʻa ai nā mea `len + additional`.
    /// Inā ʻaʻole ia, e hoʻonoho hou i ka palena iki o ka hoʻomanaʻo e pono ai.
    /// ʻO ka maʻamau ʻo kēia ka nui o ka hoʻomanaʻo e pono ai, akā ma ke ʻano he manuahi ka mea hoʻokaʻawale e hāʻawi i nā mea hou aʻe ma mua o kā mākou i noi ai.
    ///
    ///
    /// Inā ʻoi aku ʻo `len` ma mua o `self.capacity()`, hiki ʻole i kēia ke hoʻokaʻawale maoli i kahi i noi ʻia.
    /// ʻAʻole palekana maoli kēia, akā ʻo ke code unsafe *āu* kākau e hilinaʻi nei i ka hana o kēia hana e haki paha.
    ///
    /// # Panics
    ///
    /// Panics inā ʻoi aku ka mana hou ma mua o `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Nā ʻoki ma OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// ʻO ka like me `reserve_exact`, akā hoʻi i nā hewa ma kahi o ka panicking a i ʻole ka haʻalele ʻana.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Kuhi i ka hoʻokaʻawale ʻana i lalo i ka nui i kuhikuhi ʻia.
    /// Inā ʻo 0 ka nui i hāʻawi ʻia, hana maoli i nā translocates.
    ///
    /// # Panics
    ///
    /// Panics inā ʻo ka nui i hāʻawi ʻia * ʻoi aku ka nui ma mua o ka hiki i kēia manawa.
    ///
    /// # Aborts
    ///
    /// Nā ʻoki ma OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Hoʻi inā pono ka buffer e ulu e hoʻokō i ka pono keu e pono ai.
    /// Hoʻohana nui ʻia e hana i nā inlining Reserve-call hiki ʻole me ka hoʻopili ʻole ʻana iā `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Hoʻohana pinepine ʻia kēia ala i nā manawa he nui.No laila makemake mākou e liʻiliʻi ia e hiki ai, e hoʻomaikaʻi i nā manawa hōʻuluʻulu.
    // Akā makemake mākou i nā mea o loko e compatically computable ke hiki, i mea e holo wikiwiki ai ke code i hana ʻia.
    // No laila, kākau maikaʻi ʻia kēia ʻano a laila aia nā code āpau e pili ana iā `T` i loko o ia, ʻoiai ka nui o nā code i hilinaʻi ʻole iā `T` e like me ka hiki ke loaʻa i nā hana non-generic ma luna o `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Hōʻoia ʻia kēia e nā ʻano kāhea.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // ʻOiai mākou e hoʻihoʻi i ka hiki i `usize::MAX` ke `elem_size`
            // 0, ke hele nei i aneʻi no ia mea ʻo `RawVec` ka overfull.
            return Err(CapacityOverflow);
        }

        // ʻAʻohe mea hiki iā mākou ke hana maoli e pili ana i kēia mau loiloi, kaumaha.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Hōʻoia kēia i ka ulu exponential.
        // ʻAʻole hiki i ka pālua ke hoʻonui aʻe no ka mea ʻo `cap <= isize::MAX` a me ke ʻano o `cap` ʻo `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-generic ma luna o `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ʻO nā mea keakea ma kēia hana he like ia me nā mea ma `grow_amortized`, akā hana pinepine ʻia kēia ala ma muli o ka liʻiliʻi pinepine ʻole.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // ʻOiai mākou e hoʻihoʻi i ka hiki i `usize::MAX` ke ʻano ka nui
            // 0, ke hele nei i aneʻi no ia mea ʻo `RawVec` ka overfull.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-generic ma luna o `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Kēia kuleana pili i ka waho `RawVec` i ka i hoʻouluulu manawa kń.E ʻike i ka manaʻo ma luna o `RawVec::grow_amortized` no nā kikoʻī.
// (ʻAʻole koʻikoʻi ka parameter `A`, no ka mea, ʻoi aku ka liʻiliʻi o ka helu o nā ʻano `A` ʻokoʻa i ka hana ma mua o ka helu o nā ʻano `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // E hōʻoia no ka hemahema ma aneʻi e hoʻoliʻiliʻi i ka nui o `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Nānā ka mea hoʻokaʻawale no ke kaulike kaulike
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Hoʻokuʻu i ka hoʻomanaʻo i mālama ʻia e ka `RawVec`*me ka ʻole* e hoʻāʻo ana e hoʻokuʻu i kāna ʻike.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Hana kikowaena no ka mālama ʻana i nā hemahema.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Pono mākou e hōʻoia i kēia mau mea:
// * ʻAʻole mākou e hoʻokaʻawale iā `> isize::MAX` byte-size mea.
// * ʻAʻole mākou e hoʻonui iā `usize::MAX` a hoʻokaʻawale maoli.
//
// Ma 64-bit pono mākou e nānā no ka hoʻoulu ʻana mai ka hoʻāʻo ʻana e hoʻokaʻawale i nā `> isize::MAX` bytes e holo pono ʻole.
// Ma ka 32-bit a me ka 16-bit pono mākou e hoʻohui i kahi kiaʻi keu no kēia inā ke holo nei mākou ma kahi paepae i hiki ke hoʻohana i nā 4GB āpau i ka wahi hoʻohana, e laʻa, PAE a i ʻole x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ʻO kahi kuleana nui e pili ana i ka hōʻike ʻana i nā kahe o ka wai.
// E hōʻoia kēia i ka liʻiliʻi o ka hanauna code e pili ana i kēia panics no ka mea aia hoʻokahi wale nō wahi a panics ma mua o kahi pūpū ma loko o ka module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}