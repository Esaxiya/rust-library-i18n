//! Nā kuhikuhi kuhikuhi helu helu helu hoʻokahi.Kū ʻo 'Rc' i ka 'Reference
//! Counted'.
//!
//! Hāʻawi ka ʻano [`Rc<T>`][`Rc`] i ka ʻāpana like o kahi ʻano `T`, i hoʻokaʻawale ʻia i ka puʻu.
//! Ke noi nei iā [`clone`][clone] ma [`Rc`] e hana i kahi kuhikuhi hou i ka hoʻokaʻawale like i ka puʻu.
//! Ke luku ʻia ka poʻomanaʻo [`Rc`] hope loa i kahi hoʻokaʻawale i hāʻawi ʻia, hāʻule pū ka waiwai i mālama ʻia i kēlā hoʻokaʻawale (i kapa pinepine ʻia ʻo "inner value").
//!
//! Hōʻole nā kūmole i kaʻana ʻia ma Rust e ka paʻamau, a ʻaʻohe ʻokoʻa ʻo [`Rc`]: ʻaʻole hiki iā ʻoe ke kiʻi maʻamau i kahi mea i loko o [`Rc`].
//! Inā 'oe e pono ai mutability, kau i ka [`Cell`] a [`RefCell`] ma loko o ka [`Rc`];ʻike iā [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] hoʻohana i ka helu ʻana i nā ʻikepili ʻĀtoma.
//! ʻO ka manaʻo o kēia he haʻahaʻa loa ka overhead, akā ʻaʻole hiki ke hoʻouna ʻia kahi [`Rc`] ma waena o nā pae, a no laila ʻaʻole hoʻokomo ʻo [`Rc`] iā [`Send`][send].
//! ʻO ka hopena, e nānā ka mea hoʻopili Rust *i ka manawa hōʻuluʻulu* ʻaʻole ʻoe e hoʻouna iā [Rc` s ma waena o nā pae.
//! Inā 'oe e pono nunui-wili,'ātoma maopopo kahi helu, e hoʻohana [`sync::Arc`][arc].
//!
//! Hiki ke hoʻohana ʻia ka hana [`downgrade`][downgrade] e hana i kahi kuhikuhi [`Weak`] ʻona ʻole nona.
//! A [`Weak`] laʻau kuhikuhi hiki e ['upgrade`][upgrade] b i ka [`Rc`], akā, i kēia, e hoʻi [`None`] ina ka cia waiho i loko o ka auaaeaiea ua mua, ua haule iho la iluna.
//! I nā huaʻōlelo ʻē aʻe, ʻaʻole mālama nā pointers `Weak` i ka waiwai i loko o ka hoʻokaʻina ola ʻana;nae, ka mea,*e* malama i ka auaaeaiea (i ka ke kākoʻoʻana kūʻai no ka mea pā cia) e ola ana.
//!
//! ʻAʻole e hoʻokahuli ʻia kahi pōʻai ma waena o nā kuhi [`Rc`].
//! No kēia kumu, hoʻohana ʻia ʻo [`Weak`] e haki i nā pōʻaiapuni.
//! ʻO kahi laʻana, hiki i kahi kumulāʻau ke loaʻa nā kuhi [`Rc`] ikaika mai nā mākua i nā keiki, a me nā kuhikuhi [`Weak`] mai nā keiki i ko lākou mau mākua.
//!
//! `Rc<T>` koho kikoʻī iā `T` (ma o ka [`Deref`] trait), no laila hiki iā ʻoe ke kāhea i nā kiʻina ʻo "T" ma kahi waiwai o ka ʻano [`Rc<T>`][`Rc`].
//! I mea e hōʻalo ai i nā paio inoa me nā hana a 'T`, pili nā hana o [`Rc<T>`][`Rc`] ponoʻī i nā hana, i kapa ʻia me [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! ʻO Rc<T>"ʻO nā hoʻokō ʻana o traits e like me `Clone` hiki ke kāhea ʻia me ka hoʻohana ʻana i ka syntax kūpono.
//! Makemake kekahi poʻe e hoʻohana i ka syntax palapala hōʻoia piha, ʻoiai makemake kekahi e hoʻohana i ka syntax kāhea-kahea.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax kāhea-kāhea
//! let rc2 = rc.clone();
//! // Syntax kūpono kūpono
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] hana ʻole auto-dereferensi iā `T`, no ka mea ua hāʻule paha ka waiwai o loko.
//!
//! # Nā kūmole kuhikuhi
//!
//! Ke hana nei i kahi kūmole hou i ka hoʻokaʻawale like e like me kahi kuhikuhi kūhelu i helu ʻia e hana ʻia me ka `Clone` trait i hoʻokō ʻia no [`Rc<T>`][`Rc`] a me [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Kūlike nā syntaxes ʻelua ma lalo.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // kuhikuhi nā a lāua i ka helu hoʻomanaʻo i like me ka foo.
//! ```
//!
//! ʻO ka syntax `Rc::clone(&from)` ka idiomatic ʻoi loa no ka mea ke hōʻike nei ia i ka manaʻo o ke code.
//! I ke laʻana ma luna, ua maʻalahi kēia syntax e ʻike i ka hana ʻana o kēia code i kahi kūmole hou ma mua o ke kope ʻana i ka ʻike holoʻokoʻa o foo.
//!
//! # Examples
//!
//! E noʻonoʻo i kahi hanana i kahi o `Owner` i hāʻawi ʻia i kahi papa.
//! Makemake mākou e kuhikuhi i kā mākou 'Gadget` i kā lākou `Owner`.ʻAʻole hiki iā mākou ke hana i kēia me ke kuleana kūʻokoʻa, no ka mea ʻoi aku ma mua o hoʻokahi gadget i ka `Owner` like.
//! [`Rc`] ʻae iā mākou e kaʻana like i kahi `Owner` ma waena o nā 'Gadget` he nui, a e hoʻokaʻawale ʻia ka `Owner` i ka lōʻihi o nā kiko `Gadget` ma ia.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... kahua ʻē aʻe
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... kahua ʻē aʻe
//! }
//!
//! fn main() {
//!     // Hana i kahi `Owner` i helu ʻia.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // E hana i nā 'Gadget`s na `gadget_owner`.
//!     // Hāʻawi ka cloning i ka `Rc<Owner>` iā mākou i kahi kuhikuhi hou i ka hoʻokaʻawale `Owner` like, e hoʻonui ana i ka helu kuhikuhi i ke kaʻina.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // E hoʻolei i kā mākou kūloko `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Me ka waiho ʻana iā `gadget_owner`, hiki nō iā mākou ke paʻi i ka inoa o ka `Owner` o nā 'Gadget`s.
//!     // Keia mea no ka hulina wale, Nākulukulu nō mākou i ka hookahi `Rc<Owner>`, i ka `Owner` ia wahi no.
//!     // ʻOiai aia kekahi `Rc<Owner>` e kuhikuhi ana i ka hoʻokaʻawale `Owner` like, e ola ia.
//!     // Hana ka māla māla `gadget1.owner.name` ma muli o ka hoʻopau ʻole ʻana o `Rc<Owner>` iā `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // I ka hopena o ka hana, hoʻopau ʻia ʻo `gadget1` a me `gadget2`, a me lākou nā helu kuhikuhi hope loa i kā mākou `Owner`.
//!     // Ua luku ʻia ka Gadget Man i kēia manawa.
//!     //
//! }
//! ```
//!
//! Inā loli kā mākou mau koi, a pono mākou e hele i `Owner` a i `Gadget`, e loaʻa mākou i nā pilikia.
//! Hōʻike kahi poʻomanaʻo [`Rc`] mai `Owner` a i `Gadget` i kahi pōʻaiapuni.
//! ʻO kēia ka hiki ʻole i kā lākou helu helu ke helu iā 0, a ʻaʻole e luku ʻia ka hoʻokaʻawale ʻana.
//! he kulu hoʻomanaʻo.I mea e kiʻi a puni keia, ua hiki ke hoʻohana [`Weak`] mea kuhikuhi.
//!
//! Hana ʻo Rust i mea paʻakikī e hana i kēia loop i ka mua.I mea e hoʻopau ai i nā kumukūʻai ʻelua e kuhikuhi ana kekahi i kekahi, pono e hoʻololi i kekahi o lākou.
//! He mea paʻakikī kēia no ka mea [`Rc`] e hoʻokūpaʻa nei i ka palekana o ka hoʻomanaʻo ma o ka hāʻawi ʻana i nā kūmole like i ka waiwai e hoʻopili ai, a ʻaʻole ʻae kēia i ka hoʻololi pololei.
//! Pono mākou e wahī i ka ʻāpana o ka waiwai a mākou e makemake ai e mutate i kahi [`RefCell`], e hāʻawi ai i ka *mutability o loko*: kahi hana e hiki ai ke hoʻololi ma o kahi kūkaʻi like.
//! [`RefCell`] hoʻokō i kā Rust mau rula ʻaiʻē ma ka holo holo.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... kahua ʻē aʻe
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... kahua ʻē aʻe
//! }
//!
//! fn main() {
//!     // Hana i kahi `Owner` i helu ʻia.
//!     // E hoʻomaopopo ua kau mākou i kā vector o `ʻĀmona '' i loko o kahi `RefCell` i hiki ai iā mākou ke hoʻololi iā ia ma o kahi kuhikuhi like.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // E hana i nā 'Gadget` no `gadget_owner`, e like me ma mua.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Hoʻohui i nā `Gadget`s i kā lākou `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` pau nā aie hōʻeuʻeu ma aneʻi.
//!     }
//!
//!     // ʻIke ma luna o kā mākou 'Gadget`s, ke paʻi nei i kā lākou kikoʻī.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` he `Weak<Gadget>`.
//!         // ʻOiai ʻaʻole hiki i nā kuhi `Weak` ke hōʻoia i ka loaʻa o ka hoʻokaʻawale, pono mākou e kāhea iā `upgrade`, a hoʻihoʻi iā `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // I kēia hihia ʻike mākou i ka hoʻokaʻawale e waiho nei, no laila mākou wale `unwrap` ka `Option`.
//!         // I loko o kahi papahana ʻoi aku ka paʻakikī, pono ʻoe i ka lawelawe hewa ʻana no kahi hopena `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // I ka hopena o ka hana, luku ʻia ʻo `gadget_owner`, `gadget1`, a me `gadget2`.
//!     // ʻAʻohe kaha kuhikuhi (`Rc`) ikaika i nā hāmeʻa, no laila ua luku ʻia lākou.
//!     // Kuhi kēia i ka helu kuhikuhi ma kā Gadget Man, no laila e luku pū ʻia ʻo ia.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ʻO repr(C) kēia iā future-hōʻoia e kūʻē i ka hoʻonohonoho hou ʻana o ka māla, kahi e hoʻopilikia ai i kahi [into|from]_raw() palekana o nā ʻano o loko transmutable.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Kahi kiko kuhikuhi kūhelu helu hoʻokahi.Kū ʻo 'Rc' i ka 'Reference
/// Counted'.
///
/// E ʻike i ka [module-level documentation](./index.html) no nā kikoʻī hou aʻe.
///
/// ʻO nā ʻōnaehana kūlohelohe o `Rc` nā hana āpau e pili ana, ʻo ia hoʻi e kāhea ʻoe iā lākou e laʻa me [`Rc::get_mut(&mut value)`][get_mut] ma kahi o `value.get_mut()`.
/// Hōʻalo kēia i nā hakakā me nā ʻano o ka ʻano `T` o loko.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ua maikaʻi kēia unsafety no ka mea ʻoiai ke ola nei kēia Rc ua hoʻohiki mākou i ka pololei o ka pointer o loko.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Kūkulu i kahi `Rc<T>` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Aia kekahi kuhikuhi hemahema nāwaliwali nā nā mea kuhikuhi ikaika a pau, kahi e hōʻoia ai ʻaʻole e hoʻokuʻu ka mea hoʻowahāwahā nāwaliwali i ka hoʻokaʻawale i ka wā e holo ana ka mea hōʻino ikaika, ʻoiai inā mālama ʻia ka mea kuhikuhi nāwaliwali i loko o ka mea ikaika.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Kūkulu i kahi `Rc<T>` hou e hoʻohana ana i kahi kuhikuhi nāwaliwali iā ia iho.
    /// Ke hoʻāʻo nei e hoʻomaikaʻi i ka kuhikuhina nāwaliwali ma mua o ka hoʻi ʻana o kēia hana e hopena i kahi waiwai `None`.
    ///
    /// Eia nō naʻe, e kālone manuahi ʻia ka nawaiwaliwali a mālama ʻia no ka hoʻohana ʻana ma kahi hope.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... nā māla hou aʻe
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Kūkulu i ka loko i ka moku "uninitialized" me kahi kuhikuhi palupalu hoʻokahi.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // He mea nui ʻaʻole mākou e haʻalele i ka mea nona ka pointer nāwaliwali, a i ʻole e hoʻokuʻu ʻia ka hoʻomanaʻo i ka manawa a `data_fn` e hoʻi ai.
        // Inā mākou maoli makemake e hele kuleana, ua hiki ho okumu i ka hou nawaliwali laʻau kuhikuhi no ia makou iho, akā, i kēia makemake ka hopena i loko o nā IeAIIeXIAaIEE i ka nawaliwali i maopopo kahi helu a paha,ʻaʻole e pono ole.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Pono nā kūmole ikaika e ʻākoakoa pū i kahi kuhikuhina nāwaliwali, no laila mai holo i ka mea hōʻino no kā mākou kūwaliwali kahiko.
        //
        mem::forget(weak);
        strong
    }

    /// Kūkulu i kahi `Rc` hou me nā ʻike uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kūkulu i kahi `Rc` hou me nā ʻike uninitialized, me ka hoʻomanaʻo i piha i nā by by `0`.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kūkulu i kahi `Rc<T>` hou, hoʻihoʻi i kahi hemahema inā ʻaʻole holo ka hoʻokaʻawale
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Aia kekahi kuhikuhi hemahema nāwaliwali nā nā mea kuhikuhi ikaika a pau, kahi e hōʻoia ai ʻaʻole e hoʻokuʻu ka mea hoʻowahāwahā nāwaliwali i ka hoʻokaʻawale i ka wā e holo ana ka mea hōʻino ikaika, ʻoiai inā mālama ʻia ka mea kuhikuhi nāwaliwali i loko o ka mea ikaika.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Kūkulu i kahi `Rc` hou me nā ʻike uninitialized, e hoʻihoʻi i kahi hemahema inā ʻaʻole holo ka hoʻokaʻawale
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Kūkulu i kahi `Rc` hou me nā ʻike uninitialized, me ka piha o ka hoʻomanaʻo me nā `0` bytes, e hoʻihoʻi nei i kahi hemahema inā ʻaʻole e pau ka hāʻawi.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Kūkulu i kahi `Pin<Rc<T>>` hou.
    /// Inā ʻaʻole hoʻokomo ʻo `T` iā `Unpin`, a laila `value` e hoʻopili ʻia i ka hoʻomanaʻo a hiki ʻole ke hoʻoneʻe ʻia.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Hoʻihoʻi i ka waiwai o loko, inā he kikoʻī hoʻokahi kikoʻī ka `Rc`.
    ///
    /// Inā ʻole, hoʻihoʻi ʻia kahi [`Err`] me ka `Rc` like i hala ʻia i loko.
    ///
    ///
    /// E kūleʻa kēia inā aia nā kūmole nāwaliwali koʻikoʻi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kope i ka mea i loaʻa i loko

                // Hōʻike i nā Weaks ʻaʻole hiki iā lākou ke hoʻonui ʻia e ka hōʻemi ʻana i ka helu ikaika, a laila e hemo i ka helu kuhi henua "strong weak" ʻoiai e lawelawe ana i ka loiloi drop ma ka hana ʻana i kahi nāwaliwali hoʻopunipuni.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Kūkulu i kahi ʻāpana helu hou i helu ʻia me nā ʻike uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Kūkulu i kahi ʻāpana helu hou i helu ʻia me nā ʻike uninitialized, me ka hoʻomanaʻo i piha me nā bytes `0`.
    ///
    ///
    /// E ʻike iā [`MaybeUninit::zeroed`][zeroed] no nā laʻana o ka hoʻohana pololei a pololei ʻole o kēia hana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Hoʻololi i `Rc<T>`.
    ///
    /// # Safety
    ///
    /// E like me [`MaybeUninit::assume_init`], aia i ka mea kelepona e hōʻoia ai ka waiwai o loko i kahi kūlana mua.
    ///
    /// Ke kāhea ʻana i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i kumu ʻole ʻia ka hana.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Hoʻololi i `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// E like me [`MaybeUninit::assume_init`], aia i ka mea kelepona e hōʻoia ai ka waiwai o loko i kahi kūlana mua.
    ///
    /// Ke kāhea ʻana i kēia inā ʻaʻole i hoʻokumu ʻia ka ʻike i nā kumu i kumu ʻole ʻia ka hana.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hoʻoneʻe ʻia ka hoʻomaka ʻana:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Pau ka `Rc`, e hoʻihoʻi nei i ka kuhikuhi kuhikuhi.
    ///
    /// I mea e hōʻalo ai i kahi kulu hoʻomanaʻo e pono ke hoʻohuli i ka pointer i kahi `Rc` me ka hoʻohana ʻana iā [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Hāʻawi i kahi kuhikuhi maka i ka ʻikepili.
    ///
    /// ʻAʻole hoʻopili nā helu i kekahi ʻano a pau ʻole ka `Rc`.
    /// Kūpono ka pointer no ka mea aia nā helu ikaika ma ka `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: ʻAʻole hiki i kēia ke hele ma o Deref::deref a i ʻole Rc::inner no ka mea
        // koi ʻia kēia e mālama i ka raw/mut hōʻoia e like me kēlā
        // `get_mut` hiki iā ia ke kākau ma o ka pointer ma hope o ka loaʻa hou ʻana o ka Rc ma o `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Kūkulu i kahi `Rc<T>` mai kahi kuhikuhi maka.
    ///
    /// Ua hoʻihoʻi ʻia ke kuhikuhi maka maka e ke kāhea iā [`Rc<U>::into_raw`][into_raw] kahi e like ai ka nui a me ka hoʻopili ʻana o `U` me `T`.
    /// Heʻoiaʻiʻo maoli kēia inā `U` ka `T`.
    /// E hoʻomaopopo inā ʻaʻole ʻo `U` ka `T` akā like ka nui a me ke kaulike, like kēia me ka transmuting references o nā ʻano ʻokoʻa.
    /// E ʻike iā [`mem::transmute`][transmute] no ka ʻike hou aku e pili ana i nā mea e hoʻopili ai i kēia hihia.
    ///
    /// Pono ka mea hoʻohana o `from_raw` e hōʻoia i hoʻokahi wale nō waiwai o `T` i hāʻule wale ʻia.
    ///
    /// Palekana ʻole kēia hana ma muli o ka hoʻohana kūpono ʻole ʻana e alakaʻi ai i ka palekana ʻole, ʻoiai inā ʻaʻole i kiʻi ʻia ka `Rc<T>` i hoʻihoʻi ʻia.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Hoʻohuli i kahi `Rc` e pale ai i ka liu.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ʻO nā kāhea hou iā `Rc::from_raw(x_ptr)` e hoʻomanaʻo-palekana ʻole.
    /// }
    ///
    /// // Ua hoʻokuʻu ʻia ka hoʻomanaʻo i ka wā i hele aku ai ʻo `x` mai kahi ākea i luna, no laila ke kau nei ʻo `x_ptr` i kēia manawa.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // E hoʻohuli i ka offset e ʻike i ka RcBox kumu.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Hoʻokumu i kahi kuhikuhi [`Weak`] hou i kēia hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // E hōʻoia ʻaʻole mākou e hana i kahi nawaliwali nāwaliwali
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Loaʻa i ka helu o [`Weak`] mea kuhikuhi i keia e auaaeaiea.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Loaʻa i ka helu o nā kuhikuhi (`Rc`) ikaika i kēia hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Hoʻi iā `true` inā ʻaʻohe mea kuhikuhi `Rc` a i ʻole [`Weak`] ʻē aʻe i kēia hoʻokaʻawale.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// E hoʻihoʻi i kahi kuhikuhi i hiki ke hoʻololi ʻia i ka `Rc` i hāʻawi ʻia, inā ʻaʻohe `Rc` a i ʻole [`Weak`] kuhi ʻē aʻe i ka hoʻokaʻawale like.
    ///
    ///
    /// Hoʻi iā [`None`] i kahi ʻē aʻe, no ka mea, ʻaʻole palekana ia e hoʻololi i kahi waiwai like.
    ///
    /// E nānā i [`make_mut`][make_mut], a e [`clone`][clone] i ka pahale cia ka wā ma laila i nā mea kuhikuhi.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi i ka `Rc` i hāʻawi ʻia, me ka ʻole o kahi kaha.
    ///
    /// E ʻike pū iā [`get_mut`], kahi palekana a hana i nā kaha kūpono.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ʻO nā kuhi `Rc` a i ʻole [`Weak`] ʻē aʻe i ka hoʻokaʻawale like pono ʻole e hoʻopau ʻia no ka lōʻihi o ka hōʻaiʻē i hoʻihoʻi ʻia.
    ///
    /// He trivally kēia hihia inā ʻaʻohe mea kuhikuhi e like me, ma hope koke o `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mālama mākou i ka *ʻaʻole* e hana i kahi kūmole e uhi ana i nā kahua "count", no ka mea e hakakā kēia me nā kiʻi i nā helu kūmole (eg
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hoʻi iā `true` inā kuhikuhi nā ʻelua ʻ Rc` i ka hoʻokaʻawale like (i kahi aa e like me [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Hana i kahi kuhikuhi hiki ke hoʻololi i ka `Rc` i hāʻawi ʻia.
    ///
    /// Inā he `Rc` kikoʻī ʻē aʻe i ka hoʻokaʻawale like, a laila `make_mut` e [`clone`] i ka waiwai o loko i kahi hoʻokaʻawale hou e hōʻoia i ka ʻona ʻokoʻa.
    /// Ua kapa ʻia kēia ma ke ʻano he clone-on-kākau.
    ///
    /// Inā ʻaʻohe mea kuhikuhi `Rc` ʻē aʻe i kēia hoʻokaʻawale, a laila e hoʻokaʻawale ʻia nā kuhi [`Weak`] i kēia hoʻokaʻawale.
    ///
    /// E ʻike pū iā [`get_mut`], kahi e holomua ma mua o ka cloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // ʻAʻole e clone i kekahi mea
    /// let mut other_data = Rc::clone(&data);    // ʻAʻole e clone i ka ʻikepili o loko
    /// *Rc::make_mut(&mut data) += 1;        // Clones loko ikepili
    /// *Rc::make_mut(&mut data) += 1;        // ʻAʻole e clone i kekahi mea
    /// *Rc::make_mut(&mut other_data) *= 2;  // ʻAʻole e clone i kekahi mea
    ///
    /// // I kēia manawa `data` a me `other_data` kuhikuhi i nā hoʻokaʻawale ʻokoʻa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] e kāpae ʻia nā kuhikuhi
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Pono e clone i ka ʻikepili, aia kekahi Rcs ʻē aʻe.
            // E hoʻokaʻawale mua i ka hoʻomanaʻo e ʻae i ke kākau pololei ʻana i ka waiwai cloned.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Hiki wale ʻaihue i ka ʻikepili, nā Weaks wale nō i koe
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Wehe i ka ref-nawaliwali ref (ʻaʻole pono e hana i kahi Waliwali nāwaliwali ma aneʻi-ʻike mākou hiki i nā Weaks ke hoʻomaʻemaʻe no mākou)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ua maikaʻi kēia unsafety no ka mea ua hoʻohiki mākou i ka kuhikuhi ʻana ʻo ia ka *kuhikuhi* wale nō e hoʻihoʻi ʻia iā T.
        // Hōʻoiaʻiʻo ʻia kā mākou helu helu e 1 ma kēia wahi, a koi mākou i ka `Rc<T>` pono iā `mut`, no laila ke hoʻihoʻi nei mākou i kahi hiki wale nō ke kuhikuhi i ka hoʻokaʻawale.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Hoao e hoʻoliʻiliʻi i ka `Rc<dyn Any>` i kahi ʻano paʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Allocates he `RcBox<T>` me ka lawa kahua no ka malama o hiki mai-unsized pahale cia kahi o ka waiwai i ke kūpono i hoakaka ia.
    ///
    /// Kāhea ʻia ka hana `mem_to_rcbox` me ka kuhikuhi kikoʻī a pono e hoʻihoʻi i kahi (momona momona)-pointer no ka `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // E helu i ka hoʻonohonoho ʻana me ka hoʻonohonoho waiwai i hāʻawi ʻia.
        // Ma mua, ua helu ʻia ka hoʻolālā ma ka huaʻōlelo `&*(ptr as* const RcBox<T>)`, akā ua hana kēia i kahi kuhikuhi kuhi hewa (e nānā iā #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Hoʻokaʻawale i kahi `RcBox<T>` me ka lawa o ka hakahaka no kahi waiwai o loko i unsized paha kahi o ka waiwai i hoʻonohonoho ʻia, e hoʻihoʻi i kahi hemahema inā ʻaʻole i hoʻokaʻawale ka hoʻokaʻawale.
    ///
    ///
    /// Kāhea ʻia ka hana `mem_to_rcbox` me ka kuhikuhi kikoʻī a pono e hoʻihoʻi i kahi (momona momona)-pointer no ka `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // E helu i ka hoʻonohonoho ʻana me ka hoʻonohonoho waiwai i hāʻawi ʻia.
        // Ma mua, ua helu ʻia ka hoʻolālā ma ka huaʻōlelo `&*(ptr as* const RcBox<T>)`, akā ua hana kēia i kahi kuhikuhi kuhi hewa (e nānā iā #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Hāʻawi i ka hoʻonohonoho.
        let ptr = allocate(layout)?;

        // Initialize i ka RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Hāʻawi i kahi `RcBox<T>` me ka lawa o ka hakahaka no kahi waiwai i loko o unsized
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Hāʻawi i ka `RcBox<T>` e hoʻohana ana i ka waiwai i hāʻawi ʻia.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kope waiwai i nā bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // E hoʻokuʻu i ka hoʻokaʻawale me ka waiho ʻole ʻana i kāna ʻike
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Hāʻawi i kahi `RcBox<[T]>` me ka lōʻihi i hāʻawi ʻia.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// E kope i nā mea mai ka ʻāpana i Rc <\[T\]> i hāʻawi ʻia
    ///
    /// Palekana ʻole no ka mea pono ka mea kāhea e lawe i ka ʻona a paʻa iā `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Kūkulu i kahi `Rc<[T]>` mai kahi iterator i ʻike ʻia i kahi nui.
    ///
    /// ʻAʻole maopopo ka lawena inā hewa ka nui.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Kiaʻi ʻo Panic ʻoiai ke klone ʻana i nā mea T.
        // I ka hanana o panic, e hāʻule nā mea i kākau ʻia i loko o ka RcBox hou, a laila hoʻokuʻu ʻia ka hoʻomanaʻo.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer i ka mea mua
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Maopopo nā mea āpau.Poina i ke kiaʻi no laila ʻaʻole ia e hoʻokuʻu i ka RcBox hou.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Hoʻohana trait i hoʻohana ʻia no `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Pākuʻi i ka `Rc`.
    ///
    /// E hoʻemi ana kēia i ka helu kuhikuhi ikaika.
    /// Inā piʻi ka helu kuhikuhi ikaika i ka ʻole a laila ʻo nā kuhikuhi ʻē aʻe wale nō (inā kekahi) he [`Weak`], no laila mākou `drop` i ka waiwai o loko.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ʻAʻole paʻi i kekahi mea
    /// drop(foo2);   // Nā paʻi "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // luku i ka mea i loaʻa i loko
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // Wehe i ka mea kuhikuhi "strong weak" kuhikuhi i kēia manawa ua luku mākou i nā ʻike.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Hana i ka clone o ka kuhikuhi `Rc`.
    ///
    /// Hoʻokumu kēia i kahi kuhikuhi ʻē aʻe i ka hoʻokaʻawale like, e hoʻonui ana i ka helu kūmole ikaika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Hana i kahi `Rc<T>` hou, me ka waiwai `Default` no `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack e ʻae i ka loea ma `Eq` ʻoiai ʻo `Eq` kahi hana.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ke hana nei mākou i kēia loea ma aneʻi, ʻaʻole ma ke ʻano he optimization ʻoi aku ka nui ma `&T`, no ka mea e hoʻohui i kahi kumukūʻai i nā hōʻoia kaulike āpau ma nā ref.
/// Manaʻo mākou e hoʻohana ʻia ʻo `Rc`s e mālama i nā waiwai nui, lohi i ka clone, akā kaumaha hoʻi e nānā no ke kaulike, e uku maʻalahi ana i kēia kumukūʻai.
///
/// Loaʻa paha iā ia nā klona `Rc` ʻelua, e kuhikuhi ana i ka waiwai like, ma mua o ʻ ʻelua&&T.
///
/// Hiki iā mākou ke hana i kēia inā `T: Eq` ma ke ʻano he `PartialEq` i hana maʻalahi ʻole ʻia.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kaulike no ʻelua Rc`s.
    ///
    /// Kūlike ʻelua mau Rc ʻelua inā kūlike ka waiwai o loko, ʻoiai inā mālama ʻia i nā hoʻokaʻawale like ʻole.
    ///
    /// Inā hoʻokomo ʻo `T` iā `Eq` (e hōʻike nei i ka reflexivity o ke kaulike), ʻelua mau Rc`s e kuhikuhi ana i ka hoʻokaʻawale like like mau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Kūlike ʻole no ʻelua Rc`s.
    ///
    /// Kūlike ʻole ʻelua mau Rc` inā kūlike ʻole ko lākou waiwai o loko.
    ///
    /// Inā hoʻokomo ʻo `T` iā `Eq` (e hōʻike nei i ka reflexivity o ke kaulike), ʻelua mau "Rc" e kuhikuhi ana i ka hoʻokaʻawale like ʻaʻole i kaulike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Hoʻohālikelike hapa no nā ʻRc ʻelua.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `partial_cmp()` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Hoʻohālikelike ka liʻiliʻi ma mua o nā ʻRc ʻelua.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `<` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Emi ma lalo a i ʻole kaulike' hoʻohālikelike no ʻelua Rc`s.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `<=` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Hoʻohālikelike ʻoi aku ka nui no ʻelua Rc`s.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `>` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Oi aku a i ʻole kaulike' hoʻohālikelike no ʻelua Rc`s.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `>=` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Hoʻohālikelike no ʻelua Rc`s.
    ///
    /// Hoʻohālikelike ʻia nā mea ʻelua e ke kāhea ʻana iā `cmp()` i kā lākou waiwai i loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// E hoʻokaʻawale i kahi ʻāpana i helu ʻia a hoʻopiha iā ia e ke klona ʻana i nā mea a 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// E hoʻokaʻawale i kahi ʻāpana kaula helu ʻia a helu kope `v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// E hoʻokaʻawale i kahi ʻāpana kaula helu ʻia a helu kope `v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// E hoʻoneʻe i kahi mea pahu i kahi mea hou, helu i helu ʻia, hoʻokaʻawale.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// E hoʻokaʻawale i kahi ʻāpana i helu ʻia a kuhikuhi i nā ʻāpana o 'v` i loko.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // E ʻae i ka Vec e hoʻokuʻu i kāna hoʻomanaʻo, akā ʻaʻole e luku i kāna mau ʻike
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Lawe i kēlā me kēia meahana i ka `Iterator` a hōʻiliʻili iā ia i `Rc<[T]>`.
    ///
    /// # Nā ʻano hana
    ///
    /// ## ʻO ka hihia laulā
    ///
    /// I ka hihia maʻamau, ʻo ka hōʻiliʻili ʻana i `Rc<[T]>` e hana ʻia e ka hōʻiliʻili mua ʻana i `Vec<T>`.ʻO ia, ke kākau nei i kēia:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// hana kēia me he mea lā ua kākau mākou:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ka mua kau o allocations ka hana i 'aneʻi.
    ///     .into(); // Loaʻa kahi ʻāpana ʻelua no `Rc<[T]>` ma aneʻi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// E hoʻokaʻawale kēia i nā manawa i makemake ʻia no ke kūkulu ʻana i ka `Vec<T>` a laila e hoʻokaʻawale ʻia hoʻokahi no ka hoʻolilo ʻana i ka `Vec<T>` i ka `Rc<[T]>`.
    ///
    ///
    /// ## ʻO Iterators o ka lōʻihi i ʻike ʻia
    ///
    /// Ke hoʻokō nei kāu `Iterator` iā `TrustedLen` a he kikoʻī kona nui, e hāʻawi ʻia kahi hoʻokaʻawale hoʻokahi no ka `Rc<[T]>`.O kahi laʻana:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hoʻokahi wale nō hoʻokaʻawale e hana ʻia ma aneʻi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Hoʻohana trait i hoʻohana ʻia no ka hōʻiliʻili ʻana i `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // ʻO kēia ka hihia no ka `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Pono mākou e hōʻoia i ka lōʻihi o ka iterator a loaʻa iā mākou.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // E hoʻi i ka hoʻokō maʻamau.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` kahi mana o [`Rc`] e paʻa ana i kahi kuhikuhi ʻona ʻole i ka hoʻokaʻawale hoʻokele.ʻIke ʻia ka hoʻokaʻawale ʻana e ke kāhea ʻana iā [`upgrade`] ma ka kuhikuhi `Weak`, a e hoʻihoʻi nei i kahi [`ʻAno`]`<`['Rc`]'<T>>.
///
/// Ma muli o ka helu ʻole ʻana o kahi kuhikuhi `Weak` i ka ona, ʻaʻole ia e pale i ka waiwai i mālama ʻia i ka hoʻokaʻawale ʻana mai ka hāʻule ʻana, a `Weak` pono ʻole e hōʻoia e pili ana i ka waiwai e noho nei.
/// Pēlā paha e hoʻihoʻi iā [`None`] ke [[hoʻomaikaʻi hou]] d.
/// 'Ōlelo Aʻo nae i ka `Weak` maopopo kahi *hana* pale aku i ka auaaeaiea ia iho (ka ke kākoʻoʻana kūʻai) mai ka deallocated.
///
/// Maikaʻi ka poʻomanaʻo `Weak` no ka mālama ʻana i kahi kuhikuhi manawa i ka hoʻokaʻawale i mālama ʻia e [`Rc`] me ka ʻole o ka pale ʻana i kāna waiwai o loko mai ka hāʻule ʻana.
/// Hoʻohana ʻia ia e pale i nā kuhikuhi pōʻai ma waena o nā kuhikuhi [`Rc`], ʻoiai ʻaʻole ʻae ʻia nā kūmole ʻelua e hoʻokau iā [`Rc`].
/// ʻO kahi laʻana, hiki i kahi kumulāʻau ke loaʻa nā kuhi [`Rc`] ikaika mai nā mākua i nā keiki, a me nā kuhikuhi `Weak` mai nā keiki i ko lākou mau mākua.
///
/// ʻO ke ala maʻamau e loaʻa ai kahi kuhikuhi `Weak` e kāhea iā [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // He `NonNull` kēia e ʻae i ka optimizing i ka nui o kēia ʻano i nā enums, akā ʻaʻole ia he kuhikuhi pono kūpono.
    //
    // `Weak::new` hoʻonohonoho i kēia i `usize::MAX` no laila ʻaʻole pono ia e hoʻokaʻawale i kahi ma ka puʻu.
    // ʻAʻole ia he waiwai e loaʻa i kahi kuhikuhi pono maoli no ka mea ua hoʻopili ʻo RcBox ma ka liʻiliʻi 2.
    // Hiki wale nō kēia ke `T: Sized`;ʻo `T` ʻole i kau ʻia.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Kūkulu i kahi `Weak<T>` hou, me ka hoʻokaʻawale ʻole i kahi hoʻomanaʻo.
    /// Ke kāhea nei iā [`upgrade`] ma ke kumu kūʻai hoʻihoʻi hāʻawi mau iā [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ʻAno kōkua e ʻae i ke kiʻi ʻana i nā helu kūmole me ka ʻole o kekahi manaʻo e pili ana i ka ʻikepili.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Hoʻihoʻi i kahi kuhikuhi maka i ka mea `T` i kuhikuhi ʻia e kēia `Weak<T>`.
    ///
    /// Ke laʻau kuhikuhi mea i pololei ia wale nō inā loaʻa nō kekahi mau kūmole ikaika.
    /// Ke kau nei paha ka pointer, kaulike ʻole ʻia a i ʻole [`null`] ʻole.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Kuhi nā mea ʻelua i ka mea like
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Mālama ka mea ikaika ma aneʻi i mea e ola ai, no laila hiki iā mākou ke komo i kēia mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Akā ʻaʻole hou.
    /// // Hiki iā mākou ke hana weak.as_ptr(), akā ke kiʻi nei i ka pointer e alakaʻi i ka lawena i hoʻoholo ʻole ʻia.
    /// // assert_eq! ("hello", palekana ʻole {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Inā ke kau nei ke kuhikuhi, hoʻi pololei mākou i ka mea kiaʻi.
            // ʻAʻole hiki i kēia ke lilo i kahi helu uku kūpono, ʻoiai ka liʻiliʻi o ka uku e like me RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: inā hoʻihoʻi ʻo_dangling i ka wahaheʻe, a laila hoʻopau ʻia ke kuhikuhi.
            // Hiki ke hoʻokuʻu ʻia ka ukana ma kēia wahi, a pono mākou e mālama i ka hōʻoia, no laila e hoʻohana i ka manipula kuhikuhi maka.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Pau ka `Weak<T>` a hoʻolilo ia i mea kuhikuhi maka.
    ///
    /// Hoʻololi kēia i ka pointer nāwaliwali i kahi kuhikuhi maka, ʻoiai e mālama nei i ka ʻona o kahi kuhikuhi nāwaliwali (ʻaʻole hoʻololi ʻia ka helu nāwaliwali e kēia hana).
    /// Hiki iā ia ke hoʻihoʻi i ka `Weak<T>` me [`from_raw`].
    ///
    /// Na ia mau kapu o ka loaʻa'an i ka pale o ka laʻau kuhikuhi like me [`as_ptr`] pili.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Hoʻololi i kahi kuhikuhi maka ma mua i hana ʻia e [`into_raw`] i `Weak<T>`.
    ///
    /// Hiki ke hoʻohana ʻia kēia e kiʻi palekana i kahi kūmole ikaika (ma ke kāhea ʻana iā [`upgrade`] ma hope) a i ʻole ke kuʻikahi i ka helu nāwaliwali ma ka waiho ʻana i ka `Weak<T>`.
    ///
    /// Mālama ʻia kahi ʻāpana palupalu (me ka ʻokoʻa o nā kuhikuhi i haku ʻia e [`new`], ʻoiai ʻaʻohe o lākou mau mea kēia; ke hana mau nei ke ʻano ma luna o lākou).
    ///
    /// # Safety
    ///
    /// Pono ka pointer e hoʻomaka mai ka [`into_raw`] a pono nō i kāna kahawai nāwaliwali.
    ///
    /// ʻAe ʻia no ka helu ikaika e 0 i ka manawa e kāhea ana i kēia.
    /// Eia nō naʻe, lilo kēia i kuleana i hoʻokahi kuhikuhi nāwaliwali e kū nei i kēia manawa ma ke ʻano he kuhikuhi maka (ʻaʻole hoʻololi ʻia ka helu nāwaliwali e kēia hana) a no laila pono e hoʻopili ʻia me kahi kāhea mua iā [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hoʻolaha i ka helu nāwaliwali hope loa.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // E ʻike iā Weak::as_ptr no ka pōʻaiapili pehea e loaʻa ai ka kuhikuhi kuhikuhi.

        let ptr = if is_dangling(ptr as *mut T) {
            // He Wīwī kau kēia.
            ptr as *mut RcBox<T>
        } else {
            // Inā ʻole, ua hoʻohiki ʻia mākou no ka nāwaliwali kahi kuhikuhi.
            // SAFETY: palekana ka data_offset e kāhea aku ai, no ka mea, he ptr kūmole he maoli (hāʻule paha) ʻo T.
            let offset = unsafe { data_offset(ptr) };
            // No laila, huli mākou i ka offset e kiʻi i ka RcBox holoʻokoʻa.
            // SAFETY: mai kahi nāwaliwali ka pointer, no laila palekana kēia offset.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: ua loaʻa hou iā mākou ka pointer Weak maoli, no laila hiki ke hana i ka Nāwaliwali.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// ʻO nā hoʻāʻo e hoʻomaikaʻi i ka kuhikuhi `Weak` i kahi [`Rc`], e hoʻolohi ana i ka waiho ʻana o ka waiwai o loko inā kūleʻa.
    ///
    ///
    /// Hoʻi iā [`None`] inā ua haʻalele ʻia ka waiwai o loko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Luku i nā kuhi ikaika a pau.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Loaʻa i ka helu o nā kuhi (`Rc`) ikaika e kuhikuhi ana i kēia hoʻokaʻawale.
    ///
    /// Inā `self` i hana ʻia me [`Weak::new`], e hoʻihoʻi kēia iā 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Loaʻa i ka helu o nā kuhikuhi `Weak` e kuhikuhi ana i kēia hoʻokaʻawale.
    ///
    /// Inā ʻaʻohe mau kuhikuhi ikaika e hoʻi, e hoʻi kēia i ka ʻole.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // e unuhi i ka ptr nawaliwali implicit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Hoʻi iā `None` ke kau nei ka kuhikuhi a ʻaʻohe hāʻawi ʻia `RcBox`, (ʻo ia hoʻi, i ka manawa i hoʻokumu ʻia ai kēia `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mālama mākou i ka *ʻaʻole* e hana i kahi kūmole e uhi ana i ka kahua "data", no ka mea hiki ke hoʻololi ʻia ke kahua i ka manawa like (e laʻa me ka hoʻohālikelike ʻana o ka `Rc` hope loa, e hāʻule ka ʻikepili ma kahi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Hoʻi iā `true` inā kuhikuhi nā ʻelua Weak i ka hoʻokaʻawale like (e like me [`ptr::eq`]), a i ʻole kuhikuhi ʻole nā mea ʻelua i kekahi hoʻokaʻawale (no ka mea ua hana ʻia me `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// ʻOiai hoʻohālikelike kēia i nā kuhi kuhi ʻo ia ka `Weak::new()` e kaulike kekahi me kekahi, ʻoiai ʻaʻole lākou e kuhikuhi i kekahi hoʻokaʻawale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ke hoʻohālikelike nei iā `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Kulu ka kuhikuhi `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ʻAʻole paʻi i kekahi mea
    /// drop(foo);        // Nā paʻi "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // hoʻomaka ka helu nāwaliwali ma 1, a hele wale i ka ʻole inā ua nalowale nā kuhikuhi ikaika āpau.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Hana i ka clone o ka poʻomanaʻo `Weak` e kuhikuhi i ka hoʻokaʻawale like.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Kūkulu i kahi `Weak<T>` hou, hoʻokaʻawale i ka hoʻomanaʻo no `T` me ka ʻole o ka hoʻomaka ʻana.
    /// Ke kāhea nei iā [`upgrade`] ma ke kumu kūʻai hoʻihoʻi hāʻawi mau iā [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Ua hōʻoia_add mākou ma aneʻi e hana palekana iā mem::forget.I ke 'ano wae
// inā ʻoe e mem::forget Rcs (a i ʻole nāwaliwali), hiki ke hoʻonui i ka helu ref, a laila hiki iā ʻoe ke hoʻokuʻu i ka hoʻokaʻawale ʻoiai ʻo Rcs poʻokela (a i ʻole nāwaliwali) e noho nei.
//
// Kūleʻa mākou no ka mea he hanana hoʻohaʻahaʻa kēia e mālama ʻole ai mākou i ka mea e hana ʻia-ʻaʻohe polokalamu maoli e ʻike i kēia.
//
// Pono kēia e hoʻowahāwahā ʻia ma luna ʻoiai ʻaʻole ʻoe e pono e kāloli i kēia mau mea ma Rust mahalo i ka ʻona a me nā neʻe-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Makemake mākou e kāpae i ka kahe ma kahi o ka waiho ʻana i ka waiwai.
        // Ke pili helu e loa e Aʻohe keia ua kapaia ka wā;
        // Eia nō naʻe, hoʻokomo mākou i kahi abort ma aneʻi e kuhikuhi iā LLVM ma kahi optimization i hala ʻole ʻole.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Makemake mākou e kāpae i ka kahe ma kahi o ka waiho ʻana i ka waiwai.
        // Ke pili helu e loa e Aʻohe keia ua kapaia ka wā;
        // Eia nō naʻe, hoʻokomo mākou i kahi abort ma aneʻi e kuhikuhi iā LLVM ma kahi optimization i hala ʻole ʻole.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// E kiʻi i ka offset ma waena o `RcBox` no ka ukana ma hope o kahi kuhikuhi.
///
/// # Safety
///
/// Pono ke kuhikuhi i (a loaʻa i nā metadata kūpono no) kahi hanana T i kūpono ma mua, akā ʻae ʻia e haʻalele iā T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Align ka unsized cia hiki i ka pau ana o ka RcBox.
    // Ma muli o RcBox ʻo repr(C), ʻo ia nō ka māla hope loa i ka hoʻomanaʻo.
    // SAFETY: ʻoiai ʻo nā ʻano unsized wale nō i hiki ke ʻoki, trait mau mea,
    // a me nā ʻano kūwaho, ua lawa ka pono palekana hoʻokomo i kēia manawa e māʻona i nā koina o align_of_val_raw;ʻO kēia kahi kikoʻī hoʻokō o ka ʻōlelo i hiki ʻole ke hilinaʻi ʻia ma waho o std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}