//! ʻO ka hoʻokaʻawale Prelude
//!
//! ʻO ke kumu o kēia modula e hoʻoliʻiliʻi i nā lawe mai o nā mea i hoʻohana pinepine ʻia o ka `alloc` crate ma ka hoʻohui ʻana i kahi ʻaukā glob i ka piko o nā modula:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;