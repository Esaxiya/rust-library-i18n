//! Nā API hoʻokaʻawale hoʻomanaʻo

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ʻO kēia nā hōʻailona hoʻokalakupua e kāhea i ka mea hoʻokaʻawale honua.Hoʻokumu ʻo rustc iā lākou e kāhea iā `__rg_alloc` etc.
    // inā aia kahi `#[global_allocator]` ʻano (ke hoʻonui ka pāʻālua e hōʻike i ka macro i kēlā mau hana), a i ʻole e kāhea i nā hoʻokō paʻamau ma libstd (`__rdl_alloc` etc.
    //
    // i `library/std/src/alloc.rs`) ʻē aʻe.
    // ʻO ka rustc fork o LLVM kekahi mau hihia kūikawā i hiki i nā inoa hana ke hoʻonui iā lākou e like me `malloc`, `realloc`, a me `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ʻO ka mea hoʻokaʻawale hoʻomanaʻo honua.
///
/// Hoʻokomo kēia ʻano i ka [`Allocator`] trait ma o ka hoʻouna ʻana i nā kelepona i ka mea hoʻokaʻawale i hoʻopaʻa inoa ʻia me ka hiʻona `#[global_allocator]` inā aia hoʻokahi, a i ʻole ka `std` crate paʻamau.
///
///
/// Note: ʻoiai ʻaʻano paʻa ʻole kēia ʻano, hiki ke kiʻi ʻia i nā hana i hāʻawi ʻia ma o ka [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// E hoʻokaʻawale i ka hoʻomanaʻo me ka mea hoʻokaʻawale honua.
///
/// Kāhea kēia hana i mua i ke ʻano [`GlobalAlloc::alloc`] o ka mea hoʻokaʻawale i hoʻopaʻa inoa ʻia me ka hiʻona `#[global_allocator]` inā aia hoʻokahi, a i ʻole ka `std` crate paʻamau.
///
///
/// Pono e hoʻonele ʻia kēia hana ma ke ʻano o ke ʻano `alloc` o ke ʻano [`Global`] ke kūpaʻa a me ka [`Allocator`] trait.
///
/// # Safety
///
/// E nānā iā [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Hoʻololi i ka hoʻomanaʻo me ka mea hoʻokaʻawale honua.
///
/// Kāhea kēia hana i mua i ke ʻano [`GlobalAlloc::dealloc`] o ka mea hoʻokaʻawale i hoʻopaʻa inoa ʻia me ka hiʻona `#[global_allocator]` inā aia hoʻokahi, a i ʻole ka `std` crate paʻamau.
///
///
/// Pono e hoʻonele ʻia kēia hana ma ke ʻano o ke ʻano `dealloc` o ke ʻano [`Global`] ke kūpaʻa a me ka [`Allocator`] trait.
///
/// # Safety
///
/// E nānā iā [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Hoʻonohonoho hou i ka hoʻomanaʻo me ka mea hoʻokaʻawale honua.
///
/// Kāhea kēia hana i mua i ke ʻano [`GlobalAlloc::realloc`] o ka mea hoʻokaʻawale i hoʻopaʻa inoa ʻia me ka hiʻona `#[global_allocator]` inā aia hoʻokahi, a i ʻole ka `std` crate paʻamau.
///
///
/// Pono e hoʻonele ʻia kēia hana ma ke ʻano o ke ʻano `realloc` o ke ʻano [`Global`] ke kūpaʻa a me ka [`Allocator`] trait.
///
/// # Safety
///
/// E nānā iā [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// E hoʻokaʻawale i ka hoʻomanaʻo zero-hoʻomaka me ka mea hoʻokaʻawale honua.
///
/// Kāhea kēia hana i mua i ke ʻano [`GlobalAlloc::alloc_zeroed`] o ka mea hoʻokaʻawale i hoʻopaʻa inoa ʻia me ka hiʻona `#[global_allocator]` inā aia hoʻokahi, a i ʻole ka `std` crate paʻamau.
///
///
/// Pono e hoʻonele ʻia kēia hana ma ke ʻano o ke ʻano `alloc_zeroed` o ke ʻano [`Global`] ke kūpaʻa a me ka [`Allocator`] trait.
///
/// # Safety
///
/// E nānā iā [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SAFETY: X-`layout`-ʻole i ka nui,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SAFETY: Like me `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SAFETY: `new_size` non-zero ʻoiai ʻo `old_size` ʻoi aku ma mua a i ʻole like me `new_size`
            // e like me ke koi e nā kūlana palekana.Pono e mālama i nā kūlana ʻē aʻe e ka mea kāhea
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` hōʻoia paha no `new_size >= old_layout.size()` a mea like paha.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: no ka mea, pono ʻoi aku ka nui o `new_layout.size()` ma mua a i ʻole like me `old_size`,
            // kūpono ka ʻelemakule a me ka hoʻokaʻawale hoʻomanaʻo hou no ka heluhelu a kākau ʻana no `old_size` bytes.
            // Eia kekahi, no ka mea, ʻaʻole i kaila ʻia ka hoʻokaʻawale kahiko, ʻaʻole hiki ke hoʻokau iā `new_ptr`.
            // No laila, palekana ke kāhea iā `copy_nonoverlapping`.
            // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SAFETY: X-`layout`-ʻole i ka nui,
            // pono e mālama ʻia nā kūlana ʻē aʻe e ka mea kelepona
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: pono e mālama i nā ʻōlelo āpau e ka mea e kāhea ana
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: pono e mālama i nā ʻōlelo āpau e ka mea e kāhea ana
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SAFETY: pono e mālama ʻia nā kūlana e ka mea e kelepona ana
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SAFETY: `new_size` ʻaʻohe-ʻole.Pono e mālama i nā kūlana ʻē aʻe e ka mea kāhea
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` hōʻoia paha no `new_size <= old_layout.size()` a mea like paha.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: no ka mea, pono ka liʻiliʻi o `new_size` ma mua a i ʻole like me `old_layout.size()`,
            // kūpono ka ʻelemakule a me ka hoʻokaʻawale hoʻomanaʻo hou no ka heluhelu a kākau ʻana no `new_size` bytes.
            // Eia kekahi, no ka mea, ʻaʻole i kaila ʻia ka hoʻokaʻawale kahiko, ʻaʻole hiki ke hoʻokau iā `new_ptr`.
            // No laila, palekana ke kāhea iā `copy_nonoverlapping`.
            // Pono e mālama ʻia ka ʻaelike palekana no `dealloc` e ka mea kelepona.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ʻO ka mea hoʻokaʻawale no nā kuhikuhi kikoʻī.
// ʻAʻole pono e hoʻopau i kēia hana.Inā hana ia, e pau ʻole ka MIR codegen.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Pono like kēia pūlima me `Box`, a i ʻole e kū ʻia kahi ICE.
// Ke hoʻohui ʻia kahi pākuʻi hou i `Box` (e like me `A: Allocator`), pono e hoʻohui ʻia kēia ma aneʻi.
// ʻO kahi laʻana inā hoʻololi ʻia ʻo `Box` i `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, pono e hoʻololi i kēia hana i `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` pū kekahi.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Mea lawe hewa lalau

extern "Rust" {
    // ʻO kēia ka hōʻailona hoʻokalakupua e kāhea i ka mea lawe hewa o ka honua.
    // Hoʻokumu ʻo rustc iā ia e kāhea iā `__rg_oom` inā aia he `#[alloc_error_handler]`, a i ʻole e kāhea i nā hoʻokō paʻamau ma lalo o (`__rdl_oom`) i kahi ʻē aʻe.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Hoʻomaha ma ka hewa hoʻokaʻawale hoʻomanaʻo a i ʻole kūleʻa.
///
/// ʻO nā mea e kāhea ana i nā API hoʻomanaʻo e makemake ana e hōʻoki i ka helu ʻana i ka pane ʻana i kahi hemahema hoʻokaʻawale e paipai ʻia e kāhea i kēia hana, ma mua o ke kāhea pololei ʻana iā `panic!` a like paha.
///
///
/// ʻO ka hana maʻamau o kēia hana ʻo ka paʻi i kahi leka i ka hewa maʻamau a hoʻopau i ke kaʻina hana.
/// Hiki ke hoʻololi iā [`set_alloc_error_hook`] a me [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// No ka hoʻāʻo hoʻokolohua hiki iā `std::alloc::handle_alloc_error` ke hoʻohana pololei.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // i kāhea ʻia ma o `__rust_alloc_error_handler` i hana ʻia

    // inā ʻaʻohe `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // inā he `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Hoʻohālikelike i nā clone i hāʻawi mua ʻia, hoʻomanaʻo hoʻomanaʻo ʻole ʻia.
/// Hoʻohana ʻia e `Box::clone` a me `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ma ka hoʻokaʻawale ʻana * ʻae ʻia e ʻae i ka optimizer e hana i ka waiwai cloned ma kahi, e haʻalele ana i ka wahi a neʻe.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Hiki iā mākou ke kope i kahi, me ka pili ʻole i kahi waiwai kūloko.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}