#![feature(no_core)]
#![no_core]

// E nānā i rustc-std-workspace-kāna mau 'ōlelo no ke kumu keia crate ua pono.

// Kapa hou i ka crate e hōʻalo i ka hakakā me ka module kōpana ma liballoc.
extern crate alloc as foo;

pub use foo::*;