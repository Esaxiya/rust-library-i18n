# backtrace-rs

[Documentation](https://docs.rs/backtrace)

He hale waihona puke no ka loaʻa ʻana o nā kua kua i ka wā holo no Rust.
Hoʻolako kēia waihona e hoʻonui i ke kākoʻo o ka waihona waihona maʻamau ma o ka hāʻawi ʻana i kahi ʻōnaehana papahana e hana pū, akā kākoʻo pū ia me ka maʻalahi o ka paʻi maʻalahi ʻana i ka backtrace o kēia manawa e like me ka libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

E hopu wale i kahi backtrace a hoʻolōʻihi i ka hana ʻana me ia a hiki i kahi manawa hope, hiki iā ʻoe ke hoʻohana i ka ʻano `Backtrace` pae kiʻekiʻe.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Inā, nae, āu e makemake ana hou maka komo i ka maoli Hahai I functionality, e hiki ke hoʻohana i ka `trace` a me `resolve` hana pololei.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Hoʻonā i kēia aʻo laʻau kuhikuhi i ka hōʻailona inoa
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // e hoʻomau i ka hele i ke kaha aʻe
    });
}
```

# License

Ua laikini ʻia kēia papahana ma lalo o kekahi o

 * Laikini Apache, Mana 2.0, ([LICENSE-APACHE](LICENSE-APACHE) a i ʻole http://www.apache.org/licenses/LICENSE-2.0)
 * ʻO ka laikini MIT ([LICENSE-MIT](LICENSE-MIT) a i ʻole http://opensource.org/licenses/MIT)

i kāu koho.

### Contribution

Inā ʻaʻole ʻoe e haʻi akāka, inā ʻaʻole i hāʻawi ʻia i nā kuleana i hāʻawi ʻia no ka hoʻokomo ʻana i backtrace-rs e ʻoe, e like me ia i ho'ākāka ʻia ma ka laikini Apache-2.0, ʻelua laikini e like me ma luna, me ka ʻole o nā ʻōlelo a me nā kumu.







