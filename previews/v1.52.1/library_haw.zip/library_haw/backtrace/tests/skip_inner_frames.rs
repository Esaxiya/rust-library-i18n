use backtrace::Backtrace;

// Hana wale kēia ho'āʻo ma nā papaha i loaʻa kahi hana `symbol_address` hana no nā papa e hōʻike i ka helu hoʻomaka o kahi hōʻailona.
// A ʻo kahi hopena ua hoʻohana wale ʻia ia ma kekahi mau anuu.
//
const ENABLED: bool = cfg!(all(
    // Windows ʻaʻole i hoʻāʻo maoli ʻia, a ʻaʻole kākoʻo ʻo OSX i ka loaʻa maoli ʻana o kahi kiʻomo paʻa, no laila hoʻopau ʻole i kēia
    //
    target_os = "linux",
    // Ma lima i loaa i ka i nahae ka hana ua wale hoi i ka ip iho.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}