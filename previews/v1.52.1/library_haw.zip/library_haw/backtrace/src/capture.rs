use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// He hōʻike i kahi backtrace nona ponoʻī.
///
/// Hiki ke hoʻohana ʻia kēia ʻōnaehana e hoʻopaʻa i kahi kua i hope i nā helu like ʻole i kahi papahana a ma hope e nānā ai i ke ʻano o ke kua i ia manawa.
///
///
/// `Backtrace` Kākoʻo i ka paʻi paʻi nani o nā kua i hope ma o kāna hoʻokō `Debug`.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Helu ʻia nā kiʻina ma luna a lalo o ka ahu
    frames: Vec<BacktraceFrame>,
    // Ka 'inideka mākou manaoio o ka maoli hoʻomaka' ana o ka backtrace, hōʻike pū 'ana nā mōlina e like `Backtrace::new` a me `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Hopena i hopu ʻia o kahi haka ma kahi backtrace.
///
/// Ua hoʻihoʻi ʻia kēia ʻano ma ke ʻano he papa inoa mai `Backtrace::frames` a hōʻike i hoʻokahi haka stack i kahi backtrace i hopu ʻia.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Hopena i hopu ʻia o kahi hōʻailona ma ke kua kua.
///
/// Ua hoʻihoʻi ʻia kēia ʻano ma ke ʻano he papa inoa mai `BacktraceFrame::symbols` a hōʻike i ka metadata no kahi hōʻailona ma kahi backtrace.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Hopu i kahi backtrace ma ke kahua kāhea o kēia hana, e hoʻihoʻi nei i kahi ʻona ponoʻī.
    ///
    /// Kēia kuleana pili i ka pono no ka ia ho i ka backtrace me ka mea i loko o Rust.Kēia hoʻi waiwai hiki ke hoouna ma pae paha, a pai kahi'ē, a me ka hana ana o keia waiwai mea e e loa naʻu kakauiaʻi maluna.
    ///
    /// E hoʻomaopopo ma kekahi o nā paepae e kiʻi nei i kahi backtrace piha a hoʻonā iā ia he kumu kūʻai nui loa.
    /// Inā nui ke kumukūʻai no kāu noi noi ʻia e hoʻohana ma kahi o `Backtrace::new_unresolved()` e hōʻalo i ke kaʻina hoʻonā hoʻonā (kahi e ʻoi loa ka lōʻihi) a ʻae i ka hoʻopaneʻe ʻana i kēlā i kekahi lā ma hope.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // makemake e hōʻoia aia aia kahi kiʻi ma aneʻi e hemo
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// E like me `new` koe wale nō ʻaʻole hoʻoholo kēia i nā hōʻailona, kiʻi wale kēia i ka backtrace ma ke ʻano he papa inoa o nā helu kuhi.
    ///
    /// Ma kahi manawa aʻe hiki ke kāhea ʻia ka hana `resolve` e hoʻonā i nā hōʻailona o kēia backtrace i nā inoa heluhelu.
    /// Aia kēia hana ma muli o ke kaʻina hoʻonā e hiki ai i kekahi manawa ke lawe i kahi nui o ka manawa ma kahi o kahi backtrace e paʻi liʻiliʻi wale ʻia ana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ʻaʻohe inoa hōʻailona
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // inoa inoa i kēia manawa
    /// ```
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    ///
    #[inline(never)] // makemake e hōʻoia aia aia kahi kiʻi ma aneʻi e hemo
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Hoʻihoʻi i nā mōlina mai ka wā i hopu ʻia ai kēia backtrace.
    ///
    /// ʻO ka hoʻokomo mua o kēia ʻāpana paha ka hana `Backtrace::new`, a ʻo ke kiʻi hope loa he mea paha e pili ana i ka hoʻomaka ʻana o kēia pae a i ʻole ka hana nui.
    ///
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Inā keia backtrace i hanaia mai `new_unresolved` laila, i kēia papa, e hoʻonā i helu kuhi henua i loko o ka backtrace i kā lākou symbolic inoa.
    ///
    ///
    /// Inā ua hoʻoholo mua ʻia kēia backtrace a i ʻole hana ʻia ma o `new`, ʻaʻohe mea a kēia hana.
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Pēlā nō me `Frame::ip`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Ia me `Frame::symbol_address`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Ia me `Frame::module_base_address`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Hoʻihoʻi i ka papa inoa o nā hōʻailona i kūlike i kēia haka.
    ///
    /// Maʻamau ka mea, hoʻokahi wale nō hōʻailona no wahi ponoi, akā, i kekahi manawa, ina e inlined i ka helu o ka oihana i loko o kekahi wahi ponoi laila mau hōʻailona e e hoi aku.
    /// ʻO ka hōʻailona mua i helu ʻia ʻo "innermost function", akā ʻo ka hōʻailona hope loa ʻo ia ka waho loa (ka mea kelepona hope).
    ///
    /// E hoʻomaopopo inā inā mai kēia papa mai kahi backtrace i hoʻoholo ʻole ʻia a laila e hoʻihoʻi kēia i kahi papa inoa hakahaka.
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Ia me `Symbol::name`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Pēlā nō me `Symbol::addr`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Ia me `Symbol::filename`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Pēlā nō me `Symbol::lineno`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Pēlā nō me `Symbol::colno`
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ke paʻi ʻana i nā ala mākou e hoʻāʻo e wehe i ka cwd inā aia, inā ʻaʻole mākou e paʻi i ke ala e like me-is.
        // Note ana mākou i wale nō hana i kēia no ka pōkole waihona, no ka mea, ina ka mea, ka piha mākou presumably makemake e kakau a pau.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}