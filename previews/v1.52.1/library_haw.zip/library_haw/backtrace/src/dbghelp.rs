//! Kahi module e kōkua ai i ka mālama ʻana i nā paʻa dbghelp ma Windows
//!
//! Hana hope ʻia nā backtraces ma Windows (ma ka liʻiliʻi loa no MSVC) ma o `dbghelp.dll` a me nā hana like ʻole i loaʻa iā ia.
//! Hoʻoili ʻia kēia mau hana ma kēia manawa *dynamically* ma mua o ka hoʻopili ʻana iā `dbghelp.dll` statically.
//! Hana ʻia kēia i kēia manawa e ka waihona puke maʻamau (a aia i ke kumumanaʻo e koi ʻia ma laila), akā he hoʻāʻo e kōkua i ka hōʻemi ʻana i nā hilinaʻi static dll o kahi waihona no ka mea he koho maʻamau nā backtraces.
//!
//! ʻO ka ʻōlelo ʻia, `dbghelp.dll` ʻaneʻane nā manawa e hoʻouka kūleʻa ma Windows.
//!
//! E hoʻomaopopo naʻe ʻoiai mākou e hoʻouka nei i kēia kākoʻo āpau ʻaʻole hiki iā mākou ke hoʻohana maoli i nā wehewehe maka ma `winapi`, akā pono mākou e wehewehe i nā ʻano kuhikuhi kuhikuhi iā mākou iho a hoʻohana i kēlā.
//! ʻAʻole mākou makemake e pili i ka hana o ka pālua ʻia ʻana o ka winapi, no laila he Cargo hiʻohiʻona `verify-winapi` i manaʻo ʻia e hoʻopili like nā paʻa āpau i nā winapi a hiki i kēia hiʻohiʻona ke hōʻike ʻia ma CI.
//!
//! ʻO ka mea hope loa, e kahakaha ʻoe ma aneʻi ʻaʻole e lawe ʻia ka dll no `dbghelp.dll`, a makemake ʻia ia i kēia manawa.
//! ʻO ka noʻonoʻo hiki iā mākou ke cache āpau a hoʻohana iā ia ma waena o nā kāhea i ka API, e hōʻalo nei i ka loads/unloads nui.
//! Inā he pilikia kēia no nā mea kulu leak a mea like paha e hiki ai iā mākou keʻaʻa i ke alahaka ke hiki mākou i laila.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Hana ma kahi o `SymGetOptions` a me `SymSetOptions` i ʻole ma winapi iho.
// Inā ʻaʻole e hoʻohana wale ʻia kēia ke huli mākou i nā ʻano papalua e kūʻē i ka winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ʻAʻole i wehewehe ʻia ma winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ua wehewehe ʻia kēia i ka winapi, akā pololei ʻole ia (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ʻAʻole i wehewehe ʻia ma winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Hoʻohana ʻia kēia macro e wehewehe i kahi hanana `Dbghelp` i loko e paʻa ana i nā kuhikuhi kuhikuhi āpau a mākou e hoʻouka ai.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// ʻO DLL i hoʻouka ʻia no `dbghelp.dll`
            dll: HMODULE,

            // Kēlā me kēia papa laʻau kuhikuhi no kēlā me kēia papa mākou e hana
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // I ka manawa mua ʻaʻole mākou i hoʻouka i ka DLL
            dll: 0 as *mut _,
            // Hoʻonohonoho ʻia nā hana āpau i ka ʻole e ʻōlelo he pono e hoʻouka ikaika ʻia.
            //
            $($name: 0,)*
        };

        // ʻO ka typedef pono no kēlā me kēia ʻano hana.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Nā hoʻāʻo e wehe iā `dbghelp.dll`.
            /// Hoʻihoʻi i ka kūleʻa inā holo a holo hewa paha inā ʻaʻole `LoadLibraryW` i holo.
            ///
            /// Panics inā hoʻoili ʻia ka waihona.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Hana no kēlā me kēia hana mākou makemake e hoʻohana.
            // I ka wā i kapaʻia ka mea e heluhelu kekahi i ka ahu papa laʻau kuhikuhi a kiʻi ia, a hoʻi i ka hoʻoukaʻia nei cia.
            // Hōʻoia ʻia nā haawe e kūleʻa.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Pono hope, e hoʻohana i ka Cleanup wili lauoho i maopopo kahi dbghelp oihana.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize a pau kākoʻo pono e hoʻohana `dbghelp` API oihana mai keia crate.
///
///
/// Note i keia kuleana pili i ka **pakele**, ka mea i loko o ua kona iho hoʻononiakahi.
/// E hoʻomaopopo hoʻi he palekana ke kāhea ʻana i kēia hana i nā manawa hou he recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ʻO ka mea mua a mākou e pono ai e hoʻopili i kēia hana.Hiki ke kāhea like ʻia kēia mai nā pae ʻē aʻe a i ʻole recursively ma waena o hoʻokahi pae.
        // E hoʻomaopopo he maʻalahi ia ma mua o kēlā akā no ka mea a mākou e hoʻohana nei ma aneʻi, `dbghelp`,*no hoʻi* pono e hoʻopili pū ʻia me nā mea kelepona ʻē aʻe a pau i `dbghelp` i kēia kaʻina hana.
        //
        // Nō kāu loaʻa nō ole maoli ia he nui kāhea aku a ke i `dbghelp` i loko o ka hookahi kaʻina, a ua hiki paha paa kuhi i ka wale kamalii ka loaʻa'an ia mākou 'oe.
        // Eia nō naʻe, hoʻokahi mea hoʻohana ʻē aʻe a mākou e hopohopo ai no ka mea ironically iā mākou iho, akā i ka waihona puke maʻamau.
        // Aia ka Rust hale waihona puke maʻamau i kēia crate no ke kākoʻo kua kua, a aia nō kēia crate ma crates.io.
        // ʻO ke kumu kēia inā paʻi ka waihona puke maʻamau i Ztrpanic0Z backtrace e heihei paha me kēia crate e hele mai crates.io, e hoʻoiho ana i nā segfaults.
        //
        // I mea e kōkua ai i ka hoʻoponopono ʻana i kēia pilikia lōkahi hoʻohana mākou i kahi maʻalea ʻo Windows kikoʻī ma aneʻi (ʻo ia, ma hope o nā mea āpau, kahi palena palena palena ʻo Windows e pili ana i ka hoʻopili ʻana).
        // Mākou e hana i ka *Ahaolelo-kūloko* inoa mutex, e hoomalu mai i keia leo kahea.
        // ʻO ka manaʻo ma ʻaneʻi ʻaʻole pono ka waihona hale waihona puke maʻamau a me kēia crate e kaʻana like iā Rust-ʻanuʻu API e hoʻopili like ma aneʻi akā hiki iā ia ke hana ma hope o nā pale e hōʻoia i ka lōkahi ʻana o kekahi i kekahi.
        //
        // ʻO kēlā ala ke kāhea ʻia kēia hana ma o ka hale waihona puke maʻamau a i ʻole ma crates.io hiki iā mākou ke maopopo e loaʻa ana ka mutex like.
        //
        // No laila ʻo ia mau mea āpau e ʻōlelo i ka mea mua a mākou e hana ai ma aneʻi e hana atomic mākou i `HANDLE` kahi mutex inoa ma Windows.
        // Hoʻopili mākou i kahi liʻiliʻi me nā pae ʻē aʻe e kaʻana like ana i kēia ʻoihana kikoʻī a hōʻoia e hana ʻia hoʻokahi ʻau i kēlā me kēia hanana o kēia hana.
        // E hoʻomaopopo ʻaʻole paʻa ʻia ka lima i ka manawa e mālama ʻia i ka honua.
        //
        // Ma hope o kā mākou hele maoli ʻana i ka laka loaʻa wale iā mākou, a ʻo kā mākou lima `Init` a mākou e hāʻawi aku ai ke kuleana no ka haʻalele ʻana iā ia i ka hopena.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ʻ, ʻē!I kēia manawa ua palekana mākou a pau, e hoʻomaka maoli i ka hana ʻana i nā mea āpau.
        // Pono mākou e ʻike i ka hoʻouka maoli ʻia o `dbghelp.dll` i kēia kaʻina hana.
        // Hana mākou i kēia i ka dynamically e pale i ka hilinaʻi kūpaʻa.
        // Kēia i Hawaiʻi nei, ua hana i ka hana a puni weird e kuhikuhi ana nīnūnē, a ua manao ia ma ka hana ana i binaries he iki oi lawe mai i kēia mea pili pono i ka debugging pili i ka hoʻoponopono.
        //
        //
        // Ke wehe mākou iā `dbghelp.dll` pono mākou e kāhea i kahi hana hoʻomaka i loko o ia mea, a ʻo ia ka kikoʻī ma lalo.
        // Mākou wale nō e hana i kēia manawa hookahi, nae, no laila mākou hulina loaa he global Lālā paʻa e hoike ana, ina paha ua huli hana aole paha,ʻaʻole.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // E hōʻoia e hoʻonohonoho ʻia ka hae `SYMOPT_DEFERRED_LOADS`, no ka mea e like me nā palapala a MSVC ponoʻī e pili ana i kēia: "This is the fastest, most efficient way to use the symbol handler.", no laila e hana i kēlā.
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Hoʻomaka maoli i nā hōʻailona me MSVC.E hoʻomaopopo he hiki ʻole i kēia, akā nānā ʻole mākou iā ia.
        // ʻAʻohe tona o nā kiʻi ma mua no kēia mea, akā ʻaʻole e nānā ʻo LLVM i loko i ka waiwai hoʻihoʻi ma aneʻi a paʻi kekahi o nā hale waihona puke hoʻomaʻemaʻe ma LLVM i kahi ʻōlelo aʻoaʻo weliweli inā ʻaʻole holo pono kēia akā nānā ʻole ʻia ia i ka holo lōʻihi.
        //
        //
        // ʻO kekahi hihia e piʻi nui kēia no Rust ʻo ia ka waihona waihona maʻamau a me kēia crate ma crates.io makemake ʻelua e hoʻokūkū no `SymInitializeW`.
        // Ua makemake ka hale waihona puke maʻamau e hoʻomaka mua a hoʻomaʻemaʻe i ka hapanui o ka manawa, akā i kēia manawa ke hoʻohana nei ia i kēia crate ʻo ia hoʻi e kiʻi mua kekahi i kahi a ʻo ka mea ʻē aʻe e kiʻi i kēlā hoʻomaka.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}