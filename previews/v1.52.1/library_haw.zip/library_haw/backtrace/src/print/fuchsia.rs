use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr i ka callback mea e loaa i ka dl_phdr_info laʻau kuhikuhi no na DSO i ua ua ua hoʻopili i loko o ke kaʻina.
    // Mālama pū ka dl_iterate_phdr i ka laka ʻia o ka linker hōʻeuʻeu mai ka hoʻomaka a i ka pau ʻana o ka hana.
    // Inā hoʻihoʻi ka callback i kahi waiwai ʻole-ʻole e hoʻopau koke ʻia ka iteration.
    // 'data' e hoʻolilo ʻia ma ke ʻano he kolu o ka paio i ke kelepona ʻana i kēlā me kēia kāhea.
    // 'size' hāʻawi i ka nui o ka dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// E Pono e wae mai i ka hana ID a me kekahi mau kumu o polokalamu: , EeIeOIeOIeAaʻikepili i mea e ana mākou pono i ka wahi o ka ukana mai like hoʻi me ka Elf spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// I kēia manawa pono mākou e hoʻopili hou, iki no ka bit, ke ʻano o ke ʻano dl_phdr_info i hoʻohana ʻia e fuchsia's linker ikaika i kēia manawa.
// Loaʻa iā Chromium kēia palena ABI a me crashpad.
// Makemake mākou e neʻe i kēia mau hihia e hoʻohana i ka huli elf akā pono mākou e hoʻolako i kēlā ma ka SDK a ʻaʻole i pau.
//
// Pela mākou (a me ka mea,) ua apo la me ka hoʻohana 'ana i kēia hana a incurs he pilipaa huiiaʻi me ka fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // ʻAʻohe ala o mākou e ʻike ai i ka nānā ʻana inā pololei ka e_phoff a me e_phnum.
    // Pono ʻo libc e hōʻoia i kēia no mākou akā palekana no ka hana ʻana i kahi ʻāpana ma aneʻi.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Hōʻike ʻo Elf_Phdr i kahi poʻo poʻomanaʻo ʻo ELF 64-bit ma ka hopena o ka hoʻolālā pahuhopu.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Hōʻike ʻo Phdr i kahi poʻo poʻomanaʻo ELF pono a me nā ʻike o loko.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Mākou i ole ala o kéu ina p_addr a p_memsz mea i pololei ia.
    // ʻO ka libc libs a Fuchsia i haʻi mua i nā memo akā no laila ma muli o ke kū ʻana ma aneʻi e kūpono kēia mau poʻo.
    //
    // NoteIter 'aʻole i koi i ka hp'pnphp' ikepili e lilo akā, ka mea, aole ia kauoha i ka palena e e i pololei ia.
    // Hilinaʻi mākou i ka libc i hōʻoia ʻo kēia ka hihia no mākou ma aneʻi.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ʻO ka ʻano memo no nā ID kūkulu.
const NT_GNU_BUILD_ID: u32 = 3;

// Hōʻike ʻo Elf_Nhdr i kahi poʻo poʻo ELF ma ka hopena o ka pahuhopu.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Hoʻomaopopo ʻo Note i kahi memo ELF (pane poʻo + ʻike).
// Waiho ʻia ka inoa ma ke ʻano he ʻāpana u8 no ka mea ʻaʻole ia e hoʻopau ʻole ʻia a rust maʻalahi maʻalahi e nānā i ke kūlike o nā byte.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Mālama ʻo NoteIter iā ʻoe e mālama pono ma luna o kahi mahele memo.
// Hoʻopau ʻia ke loaʻa koke kahi hemahema a i ʻole ʻaʻohe memo hou aʻe.
// Inā ʻoe e iterate ma luna o ka ʻikepili kūpono ʻole e holo ia me he mea lā ʻaʻole i loaʻa nā memo.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // He invariant ia o ka hana a ka kuhikuhi a me ka nui i hāʻawi ʻia e hōʻike i kahi pae o nā byte i hiki ke heluhelu ʻia.
    // Hiki i nā ʻike o kēia mau byte i kekahi mea akā pono ka laulā e palekana no kēia.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// kaulike ʻo 'x' i ka 'to'-byte kaulike me ka manaʻo 'to' he mana o 2.
// Hāpai kēia i kahi hiʻohiʻona maʻamau i ka C/C ++ ELF helu pāʻālua kahi (x + a, 1)&-to e hoʻohana ai.
// ʻAʻole ʻo Rust e hoʻokuʻu iā ʻoe e hōʻole iā mākou no laila hoʻohana wau
// 2's-hoʻokō huli ana i ka recreate ia.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 hoʻopau i nā bytes mai ka ʻāpana (inā loaʻa) a hōʻoia pū kekahi e hoʻopili pololei ʻia ka ʻāpana hope.
// Inā nui ka helu o nā byte i noi ʻia a i ʻole hiki i ka ʻāpana ke hoʻonohonoho hou ʻia ma hope ma muli o ka lawa ʻole o nā byte e waiho nei, ʻaʻohe mea i hoʻihoʻi ʻia a ʻaʻole hoʻololi ʻia ka ʻāpana.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Kēia kuleana pili i ka mea ole maoli invariants ka Caller pono kokua 'ē ma mua paha i 'bytes' e e ua kūponoʻia no ka hana ana (a ma luna o kekahi architectures pono).
// He mea lapuwale paha nā kumukūʻai ma nā kahua ʻo Elf_Nhdr akā ʻaʻole hōʻoia kēia hana i kēlā mea.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // He maluhia like loa me he mea lawa wa, a ua pono hoʻopaʻa i loko o ka ina hoakaka ma luna o laila, i kēia,ʻaʻole e unsafe e.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Note i sice_of: :<Elf_Nhdr>() He mau 4-ʻai ua kūponoʻia.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Hōʻoia inā he paena i hiki aku ai mākou i ka hopena.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Hoʻouna mākou i kahi nhdr akā noʻonoʻo pono mākou i ka hopena hopena.
        // ʻAʻole mākou hilinaʻi i ka namesz a i ʻole ka descsz a ʻaʻole mākou e hoʻoholo i kahi palekana e pili ana i ke ʻano.
        //
        // No laila, a hiki ina kiʻi mai mākou piha ioni? Mākou e nō e palekana.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Hōʻike i ka hiki ke hoʻokō ʻia kahi ʻāpana.
const PERM_X: u32 = 0b00000001;
/// Hōʻike i ka Hoʻohana mea writable.
const PERM_W: u32 = 0b00000010;
/// Hōʻike i ka hiki ke heluhelu ʻia i kahi ʻāpana.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Hōʻike i kahi ʻāpana ELF i ka manawa holo.
struct Segment {
    /// I haawi mai i ka runtimeʻike kamepiula aae? O keia Hoʻohana ka Contents.
    addr: usize,
    /// Hāʻawi i ka nui hoʻomanaʻo o nā ʻike o kēia ʻāpana.
    size: usize,
    /// Hāʻawi i ka leka uila o kēia māhele me ka faila ELF.
    mod_rel_addr: usize,
    /// Hāʻawi i nā ʻae i loaʻa i ka faila ELF.
    /// ʻAʻole ʻae ʻia kēia mau ʻae i nā ʻae i kēia manawa ma runtime.
    flags: Perm,
}

/// Ke hoike nei kekahi iterate no Hoʻohana mai o ka DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Ke pani nei i kahi ELF DSO (Objective Shared Object).
/// Kēiaʻano i maopopo nä haumäna i ka 'ikepili waiho i loko o ka maoli DSO makemake ma mua o ka hana ana i kona mau kope.
struct Dso<'a> {
    /// Hāʻawi mau ka mea hoʻopili ikaika iā mākou i kahi inoa, ʻoiai inā hakahaka ka inoa.
    /// Ma ka hihia o ka papa kuhikuhiE executable keia inoa, e e kaawale.
    /// I ka hihia o kahi mea i kaʻana like ia ia i soname (ʻike iā DT_SONAME).
    name: &'a str,
    /// Ma Fuchsia ʻaneʻane loaʻa nā ID i nā binaries āpau akā ʻaʻole kēia kahi koi koʻikoʻi.
    /// ʻAʻohe ala e hoʻohālikelike ai i ka ʻike DSO me kahi faila ELF maoli ma hope inā ʻaʻohe build_id no laila koi mākou i kēlā me kēia DSO ma aneʻi.
    ///
    /// ʻAʻole nānā ʻia ʻo DSO me ka ʻole o kahi build_id.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Hoʻihoʻi i kahi iterator ma luna o nā ʻāpana i kēia DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Hoʻopili kēia mau hewa i nā pilikia e kū aʻe i ka wā e ʻae nei i ka ʻike e pili ana i kēlā me kēia DSO.
///
enum Error {
    /// Kuhi ʻia ʻo NameError i kahi hewa i ka hoʻololi ʻana i kahi aho kaila C i ke aho rust.
    ///
    NameError(core::str::Utf8Error),
    /// Kuhi ʻo BuildIDError ʻaʻole i loaʻa iā mākou kahi ID kūkulu.
    /// Ma muli paha o ka loaʻa ʻole o ka ID ID o ka DSO a no ka hana hewa ʻana paha o ka ʻāpana i loaʻa ka ID kūkulu.
    ///
    BuildIDError,
}

/// Kāhea iā 'dso' a i ʻole 'error' no kēlā me kēia DSO i hoʻopili ʻia i ke kaʻina e ka mea hoʻopili ikaika.
///
///
/// # Arguments
///
/// * `visitor` - A DsoPrinter mea e i kekahi o Maiʻai i kāu kiʻina hana kapa foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr e hōʻoia i ka info.name e kuhikuhi i kahi wahi kūpono.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Paʻi kēia hana i ka markup hōʻailona Fuchsia no nā ʻike āpau i loaʻa i kahi DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}