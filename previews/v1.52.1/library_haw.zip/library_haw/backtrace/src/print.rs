#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Kahi hōʻano no nā kua kua.
///
/// Hiki ke hoʻohana ʻia i kēia ʻano e paʻi i ke kua kua nānā ʻole ʻia ma hea kahi o ka backtrace iho.
/// Inā loaʻa iā ʻoe kahi `Backtrace` a laila hoʻohana kāna `Debug` hoʻohana i kēia palapala paʻi.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Nā styles o ka paʻi palapala ana, ua hiki e kakau
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Pai i kahi backtrace terser i kūpono e loaʻa ai ka ʻike pili
    Short,
    /// Wahi he backtrace e he hiki a pau 'ike
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// E hana i kekahi hou `BacktraceFmt` a e kākau auoiaea i ka i hoakaka `fmt`.
    ///
    /// E kāohi ka `format` hoʻopaʻapaʻa i ke kaila i paʻi ʻia ka backtrace, a e hoʻohana ʻia ka hoʻopaʻapaʻa `print_path` e paʻi i nā hanana `BytesOrWideString` o nā inoa inoa.
    /// ʻAʻole hana kēia ʻano i ka paʻi ʻana o nā inoa inoa, akā koi ʻia kēia callback e hana pēlā.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Wahi he hoʻolauna no ka backtrace e pili ana i ke pai ia.
    ///
    /// Koi ʻia kēia ma nā paepae no nā backtraces e hōʻailona piha ʻia ma hope, a i ʻole ʻo ia wale nō ke ala mua āu e kāhea ai ma hope o ka hoʻokumu ʻana i `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Hoʻohui i kahi papa i ka hopena backtrace.
    ///
    /// Keia hana i hoike i RAII kekahi manawa o ka `BacktraceFrameFmt` i hiki ke hoʻohana 'ia nae e kakau i kekahi wahi ponoi, a ma luna o ka make ia e xi i ke kino loan.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Ke hoʻoholo 'ia i ka backtrace ia auoiaea.
    ///
    /// He no-op kēia i kēia manawa akā ua hoʻohui ʻia no ka hoʻokaulike future me nā ʻano backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Currently he ole-op-- me keia hook e ae no ka future lewa.
        Ok(())
    }
}

/// Kahi hōʻano no hoʻokahi wale nō kiʻi o ka kua kua.
///
/// Kēiaʻano ua hana ia e ke kuleana pili i `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Pai i kahi `BacktraceFrame` me kēia mea hoʻopili mana.
    ///
    /// E paʻi hou kēia i nā hanana `BacktraceSymbol` āpau ma loko o ka `BacktraceFrame`.
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Pai i kahi `BacktraceSymbol` ma loko o `BacktraceFrame`.
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ʻAʻole maikaʻi kēia ʻaʻole e pau ka paʻi ʻana i kekahi mea
            // me ka 'ole-utf8 filenames.
            // Mea hoʻomaikaʻi aneane na mea a pau o utf8 ai keia e ole eʻoi aku ka 'ino.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Pai i kahi `Frame` a me `Symbol` i huli maka ʻia, ma waena o nā callbacks maka o kēia crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Hoʻohui i kahi papa maka i ka hopena backtrace.
    ///
    /// ʻO kēia ʻano hana, ʻokoʻa ka mea ma mua, lawe i nā paio maka inā loaʻa lākou mai nā wahi like ʻole.
    /// E noke i keia i ke kapa mau manawa no kekahi wahi ponoi.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Hoʻohui i kahi maka maka i ka hopena backtrace, me ka ʻike kolamu.
    ///
    /// Kēia hana, e like me ka mua, i ka maka manaʻo hoʻopiʻi kū'ē ma ka hihia e huli i kumu, mai kekahi mau wahi.
    /// E noke i keia i ke kapa mau manawa no kekahi wahi ponoi.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ʻAʻole hiki iā Fuchsia ke hōʻailona i loko o kahi kaʻina no laila he ʻano kūikawā kona i hiki ke hoʻohana ʻia e hōʻailona ma hope.
        // E paʻi ma kahi o ka paʻi ʻana i nā helu kuhi i kā mākou ʻano ponoʻī ma aneʻi.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // No pono e kakau "null" mōlina, ia holo nōhie pono 'o ia hoʻi i ka'ōnaehana backtrace ua he iki eager e kumumea hoʻi iā Naha Pōhaku mamao.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // E hoʻemi i ka nui TCB ma Sgx enclave, ʻaʻole makemake mākou e hoʻokō i ka hana hoʻonā o ka hōʻailona.
        // Akā, hiki iā mākou ke paʻi i ka offset o ka helu wahi ma aneʻi, i hiki ke palapala ʻia ma hope e hoʻoponopono i ka hana.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // E kakau i ka Papa kuhikuhi o na wahi ponoi, a me ke koho aʻo laʻau kuhikuhi ana o ke kino.
        // Inā mākou ma ʻō o ka hōʻailona mua o kēia kiʻina ʻoiai mākou e paʻi i ke keʻokeʻo kūpono.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ma hope aʻe e kākau i ka inoa hōʻailona, e hoʻohana ana i ka hoʻololi ʻē aʻe no ka ʻike hou aku inā he backtrace piha mākou.
        // Maanei mākou e lawelawe ai i nā hōʻailona ʻaʻohe inoa,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // A ʻo ka hope loa, paʻi i ka helu filename/line inā loaʻa lākou.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line paʻi ʻia ma nā laina ma lalo o ka inoa hōʻailona, no laila paʻi i kekahi keʻokeʻo kūpono e ʻano pono e hoʻopili pono iā mākou iho.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Elele 'o ia kā mākou maloko callback e kakau i ka filename, a laila, e kakau mai i ka laina helu.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Hoʻohui i kolamu helu, inā loaʻa.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Mālama wale mākou i ka hōʻailona mua o kahi haka
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}