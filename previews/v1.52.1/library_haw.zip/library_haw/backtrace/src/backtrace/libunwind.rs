//! Kākoʻo Backtrace me ka hoʻohana ʻana iā libunwind/gcc_s/etc API.
//!
//! Aia i loko o kēia module ka hiki ke wehe i ka ahu ma ka hoʻohana ʻana i nā API ʻano libunwind.
//! E hoʻomaopopo aia aia kekahi pūpū o nā hoʻokō o ka libunwind-like API, a ke hoʻāʻo nei kēia e launa me ka hapa nui o lākou āpau ma kahi o ka picky.
//!
//!
//! Hoʻohana ʻia ka libunwind API e `_Unwind_Backtrace` a ke hoʻohana pono nei ia i ka hana ʻana i kahi backtrace.
//! ʻAʻole maopopo loa pehea e hana ai (kuhi kuhi? Eh_frame info? ʻElua?) Akā ke hana nei paha!
//!
//! ʻO ka hapa nui o ka paʻakikī o kēia kōnae ke lawelawe nei i nā ʻokoʻa anuu like ʻole ma waena o nā hoʻokō libunwind.
//! A i ʻole ʻo Rust pololei pololei kēia e hoʻopaʻa nei i nā API libunwind.
//!
//! ʻO kēia ka wili API paʻamau no nā paepae Windows ʻole i kēia manawa.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Me ka maka libunwind laʻau kuhikuhi ia e wale loa e komo i loko o ka readonly threadsafe ano, no laila ka mea, ke `Sync`.
// Ke hoʻouna nei mākou i nā pae ʻē aʻe ma o `Clone` hoʻololi mau mākou i kahi mana i mālama ʻole i nā kuhikuhina o loko, no laila e `Send` pū kekahi mākou.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Pēlā ka manaʻo i ka OSX `_Unwind_FindEnclosingFunction` hoʻi i ka laʻau kuhikuhi i ... i kekahi mea i ka unclear.
        // ʻAʻole mau ia i ka hana hoʻopili no nā kumu āpau.
        // It OʻAʻole loa i ike ia mai iaʻu he aha ana lāʻaneʻi, no laila, pessimize keia no ka manawa a me ka pono mau hoʻi i ka ip.
        //
        // Hoʻomaopopo ua kāpae ʻia ka hōʻike `skip_inner_frames.rs` ma OSX ma muli o kēia paukū, a inā paʻa kēia hiki ke holo i ka hoʻāʻo ma ka loiloi ma OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Hoʻohālike i ka waihona waihona i hoʻohana ʻia no nā kua kua
///
/// Hoʻomaopopo e ʻae ʻia ka code make ma aneʻi he mea paʻa wale nō ʻaʻole hoʻohana ʻo iOS iā lākou āpau akā ʻo ka hoʻohui ʻana i nā config kikoʻī kikoʻī e hoʻohaumia loa i ka pāʻālua.
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // hoʻohana ʻia e ARM EABI wale nō
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // ʻAʻohe ʻōiwi_Unwind_Backtrace ma IOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // loaʻa mai GCC 4.2.0, pono maikaʻi no kā mākou kumu
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Kuhi hewa kēia hana: ma mua o ka loaʻa ʻana o kēia frame's Canonical Frame Address (aka ka mea i kapa ʻia ʻo SP) hoʻihoʻi ia i kēia SP's frame.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x hoʻohana i kahi waiwai CFA bias, no laila pono mākou e hoʻohana_Unwind_GetGR e kiʻi i ka papa kuhikuhi poʻomanaʻo (%r15) ma kahi o ka hilinaʻi ʻana iā _Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Ma android a me ka lima, ʻo ka hana `_Unwind_GetIP` a me kahi pūpū o nā mea ʻē aʻe he mau macros, no laila mākou e wehewehe nei i nā hana i loaʻa ka hoʻonui ʻana o nā macros.
    //
    //
    // TODO: loulou i ka faile poʻomanaʻo e wehewehe ai i kēia mau macros, inā hiki iā ʻoe ke loaʻa.
    // (ʻO wau, fitzgen, ʻaʻole hiki ke ʻike i ka faile poʻomanaʻo i hōʻaiʻē ʻia kekahi o kēia mau hoʻonui hoʻonui.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 ʻo ia ka pointer stack ma ka lima.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ʻAʻohe o kēia hana ma Android a i ʻole ARM/Linux, no laila e hoʻolilo iā ia i kahi no-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}