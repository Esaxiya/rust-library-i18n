use core::ffi::c_void;
use core::fmt;

/// Nānā i kēia kāhea kāhea, e hele ana i nā mōlina hana i loko o ka pani i hāʻawi ʻia e helu i kahi kuhi stack.
///
/// ʻO kēia hana ka hana o kēia waihona ma ka helu ʻana i nā koina no ka papahana.Hāʻawi ʻia ka panina `cb` mau hanana o kahi `Frame` e hōʻike ana i ka ʻike e pili ana i kēlā kāhea kelepona i ka stack.
/// Hāʻawi ʻia ka pani i nā papa i kahi ʻano luna i lalo (i kapa ʻia ʻo nā hana ma mua).
///
/// I ka panina o ka hoʻi waiwai mea he PAaIEN no paha ka backtrace e hoʻomau.E hoʻopau kahi waiwai hoʻihoʻi o `false` i ka backtrace a hoʻi koke.
///
/// I ka manawa e loaʻa ai kahi `Frame` makemake paha ʻoe e kāhea iā `backtrace::resolve` e hoʻololi i ka `ip` (kuhikuhi kuhikuhi) a i ʻole ka helu wahi hōʻailona i kahi `Symbol` e hiki ai ke aʻo ʻia ka inoa a me/a i ʻole filename/helu laina.
///
///
/// E hoʻomaopopo he hana haʻahaʻa haʻahaʻa kēia a inā makemake ʻoe e, e laʻa, hopu i kahi backtrace e nānā ʻia ma hope, a laila ʻoi aku ke kūpono o ka `Backtrace` ʻano.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
/// # Panics
///
/// Hoʻoikaika kēia hana ʻaʻole loa iā panic, akā inā hāʻawi ka `cb` iā panics a laila e hoʻokau kekahi mau paepae i kahi panic pālua e hoʻopau i ke kaʻina hana.
/// Hoʻohana kekahi paepae i kahi waihona C e hoʻohana i loko i nā callbacks i hiki ʻole ke hemo ʻole ʻia, no laila ʻo ka panic ʻana mai `cb` hiki ke hoʻomaka i kahi kaʻina hana i hoʻopau ʻia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // hoʻomau i ka backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// E like me `trace`, palekana ʻole ʻoiai hoʻohui ʻole ʻia.
///
/// ʻAʻohe o kēia hana i nā hoʻohiki syncingization akā loaʻa ke loaʻa ʻole ka hiʻohiʻona `std` o kēia crate i loko.
/// E ʻike i ka hana `trace` no nā palapala hou aʻe a me nā laʻana.
///
/// # Panics
///
/// E ʻike i ka ʻike ma `trace` no nā ana ma `cb` panicking.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// ʻO trait e hōʻike ana i hoʻokahi haka o kahi backtrace, hāʻawi ʻia i ka hana `trace` o kēia crate.
///
/// Na Hahai I kuleana pili i ka panina e e hooliloia mōlina, a me ke kino uaʻaneʻane hoolale ae like me ka nń ku manaʻo ua iʻike mauʻia a runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Hoʻihoʻi i ka kuhikuhi kuhikuhi o kēia papa.
    ///
    /// ʻO kēia ke kuhikuhi maʻamau e hoʻokō ai i ke kiʻina, akā ʻaʻole nā papa hana āpau e papa inoa i kēia me 100% pololei (akā pili pinepine ia).
    ///
    ///
    /// ? Aeiiaiaiaaia e hele i kēia kumukuai i `backtrace::resolve` e huli ia i loko o ka hōʻailona inoa.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// E hoʻihoʻi i ka kuhikuhi kuhikuhi o kēia papa.
    ///
    /// I ka hihia ʻaʻole hiki i kahi backend ke kiʻi hou i ka pointer stack for this frame, hoʻihoʻi ʻia kahi kuhikuhi ʻole.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Hoʻihoʻi i ka helu wahi hoʻomaka o ke kiʻina o kēia hana.
    ///
    /// E hoʻāʻo kēia e hoʻi i ka kuhikuhi kuhikuhi i hoʻihoʻi ʻia e `ip` i ka hoʻomaka o ka hana, e hoʻihoʻi i kēlā waiwai.
    ///
    /// I kekahi mau hihia, akā hoʻi, hoʻi wale nā backends iā `ip` mai kēia hana.
    ///
    /// Hiki ke hoʻohana ʻia ka waiwai i hoʻihoʻi ʻia i kekahi manawa inā holo hewa ʻo `backtrace::resolve` ma ka `ip` i hāʻawi ʻia ma luna.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// E hoʻihoʻi i ka helu wahi o ka mole i pili ai ke kiʻi.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Pono kēia e hele mua, e hōʻoia i ka lawe o Miri i ka mea nui ma mua o ka paepae hoʻokipa
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // hoʻohana wale ʻia i dbghelp hōʻailona
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}