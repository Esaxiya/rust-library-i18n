use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Hoʻoholo i kahi kamaʻilio i kahi hōʻailona, e hele ana i ka hōʻailona i ka pani pani ʻia.
///
/// Kēia papa, e nana i ka haawiia aae? I mau wahi, e like me ka kūloko hōʻailonaʻaina, hōʻeuʻeu hōʻailona papa, a me DWARF debug ikepili kemu (ke kaumaha ma muli o ka ho'ā 'ia paha manaʻo) e imi hōʻailona, e hookuu aku.
///
///
/// hiki ole ke kapaia ka panina ina olelo hooholo hiki ole ke hana, a me ka mea i kapaʻia e oi ma mua o koke i loko o ka hihia o inlined hana no hoi.
///
/// Hōʻailona alaila kuu aku la ho i ka hooko i ka mea i hoakaka ia `addr`, hoi file/line hui no ka mea helu wahi (ina i loaʻa).
///
/// E hoʻomaopopo inā he `Frame` kāu a laila makemake ʻia e hoʻohana i ka hana `resolve_frame` ma kahi o kēia.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
/// # Panics
///
/// Hoʻoikaika kēia hana ʻaʻole loa iā panic, akā inā hāʻawi ka `cb` iā panics a laila e hoʻokau kekahi mau paepae i kahi panic pālua e hoʻopau i ke kaʻina hana.
/// Hoʻohana kekahi paepae i kahi waihona C e hoʻohana i loko i nā callbacks i hiki ʻole ke hemo ʻole ʻia, no laila ʻo ka panic ʻana mai `cb` hiki ke hoʻomaka i kahi kaʻina hana i hoʻopau ʻia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // wale nana i ka luna maoli
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Hoʻoholo i kahi paʻa mua i kahi hōʻailona, e hāʻawi i ka hōʻailona i ka pani pani ʻia.
///
/// Kēia functin hanaʻia i ka ia hana me `resolve` ole i ka mea lawe i ke `Frame` me ka manaʻo hoʻopiʻi kahi o ka helu wahi.
/// Ua hiki ae kekahi anuu implementations o backtracing e hoolako hou pololei hōʻailona 'ike a me ka' ike e pili ana i LIKE LIKE nā mōlina no ka laʻana.
///
/// He hana aeiiaiaiaaia e hoʻohana i kēia inā 'oe e hiki.
///
/// # Nā hiʻohiʻona i makemake ʻia
///
/// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
///
/// # Panics
///
/// Hoʻoikaika kēia hana ʻaʻole loa iā panic, akā inā hāʻawi ka `cb` iā panics a laila e hoʻokau kekahi mau paepae i kahi panic pālua e hoʻopau i ke kaʻina hana.
/// Hoʻohana kekahi paepae i kahi waihona C e hoʻohana i loko i nā callbacks i hiki ʻole ke hemo ʻole ʻia, no laila ʻo ka panic ʻana mai `cb` hiki ke hoʻomaka i kahi kaʻina hana i hoʻopau ʻia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // wale nana i ka luna maoli
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP aiee mai noae mōlina i kāu (always?) ke aʻo *hope* ka hea i ka ka maoli noae kumumea.
// Ke hōʻailona nei i kēia ma ke kumu o ka helu filename/line ma mua a i loko paha o ka ʻole inā kokoke i ka hopena o ka hana.
//
// ʻIke pinepine kēia i ka hihia ma nā paepae āpau, no laila e unuhi pinepine mākou i kekahi mai ka ip i hoʻonā ʻia e hoʻonā iā ia i ke aʻo ʻana o ke kāhea ma mua o ka hoʻihoʻi ʻia ʻana o ke aʻo.
//
//
// Maikaʻi loa mākou makemake e hana i kēia.
// Maikaʻi loa mākou e noi aku callers o ka `resolve` APIsʻaneʻi i ka hana lima hana i ka -1 a me ka mooolelo i ka mea, makemake wahi 'ikepili no ka *mua* aʻoʻia,ʻaʻole i kaʻikena.
// Kūpono mākou e hōʻike iā `Frame` inā ʻo mākou ka helu o ke aʻo aʻe a i ʻole ke au o kēia manawa.
//
// No ka manawa, ina keia mea he nani niche e hopohopo nei no laila mākou wale i loko o mau unuhi i kekahi.
// Pono nā mea kūʻai aku e hana mau a loaʻa i nā hopena maikaʻi maikaʻi, no laila e lawa pono mākou.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// E like me `resolve`, palekana ʻole ʻoiai hoʻohui ʻole ʻia.
///
/// ʻAʻohe o kēia hana i nā hoʻohiki syncingization akā loaʻa ke loaʻa ʻole ka hiʻohiʻona `std` o kēia crate i loko.
/// E ʻike i ka hana `resolve` no nā palapala hou aʻe a me nā laʻana.
///
/// # Panics
///
/// E nānā i ka 'ikepili ma `resolve` no caveats ma `cb` ā'ā.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// E like me `resolve_frame`, palekana ʻole ʻoiai hoʻohui ʻole ʻia.
///
/// ʻAʻohe o kēia hana i nā hoʻohiki syncingization akā loaʻa ke loaʻa ʻole ka hiʻohiʻona `std` o kēia crate i loko.
/// E nānā i ke `resolve_frame` hana no ka nui nā moʻolelo a me nā examples.
///
/// # Panics
///
/// E ʻike i ka ʻike ma `resolve_frame` no nā ana ma `cb` panicking.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ʻO trait e hōʻike nei i ka hoʻonā ʻana o kahi hōʻailona ma kahi faila.
///
/// Hāʻawi ʻia kēia trait ma ke ʻano he trait mea i ka pani pani i hāʻawi ʻia i ka hana `backtrace::resolve`, a ua hoʻouna ʻaneʻane ʻia no ka mea ʻaʻole ʻike ʻia ka hana ma hope ona.
///
///
/// Hiki i kahi hōʻailona ke hāʻawi i ka ʻike pili e pili ana i kahi hana, e laʻa me ka inoa, filename, helu laina, kahi kikoʻī, a pēlā aku.
/// ʻAʻole loaʻa mau nā ʻike āpau i kahi hōʻailona, akā naʻe, no laila hoʻihoʻi ʻia nā ʻano hana āpau i `Option`.
///
///
pub struct Symbol {
    // TODO: keia wa e ola ana e paa ana pono ai ia e hoopaakiki mau iho la e ho'ōla i `Symbol`,
    // akā, e O a ianoiyuaa a he lumai loli.
    // No kēia manawa palekana kēia ʻoiai hāʻawi wale ʻia ʻo `Symbol` e ke kuhikuhi a hiki ʻole ke kālona ʻia.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Hoʻi i ka inoa o keia kuleana pili i.
    ///
    /// Hiki ke hoʻohana ʻia ka hanana i hoʻihoʻi ʻia e nīnau i nā ʻano waiwai like ʻole e pili ana i ka inoa hōʻailona:
    ///
    ///
    /// * E paʻi ka hoʻokō `Display` i ka hōʻailona hōʻailona.
    /// * Ka maka `str` waiwai o ka hōʻailona hiki ke lolouila (ina mea ka i pololei ia utf-8).
    /// * Ka maka nāʻai no ka hōʻailona inoa hiki ke lolouila.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Hoʻihoʻi i ka helu hoʻomaka o kēia hana.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Hoʻihoʻi i ka inoa filename ma ke ʻano he ʻāpana.
    /// Heʻano nui pono no `no_std` hana kūpono.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Hoʻihoʻi i ka helu kolamu no kahi e hoʻokō nei kēia hōʻailona.
    ///
    /// Hāʻawi wale ka gimli i kahi waiwai ma aneʻi a laila inā wale nō `filename` hoʻihoʻi iā `Some`, a no laila ke kumu ia i nā ana like.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Huli i ka laina helu no kahi kēia hōʻailona ua a ianoiyuaa a hana.
    ///
    /// Kēia hoʻi waiwai He nō kāu `Some` ina `filename` hoi mai `Some`, a me ka mea nolaila paha i like caveats.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Hoʻihoʻi i ka inoa o kahi faila kahi i wehewehe ʻia ai kēia hana.
    ///
    /// Loaʻa kēia manawa wale nō ke hoʻohana ʻia ʻo libbacktrace a i ʻole gimli (e laʻa
    /// unix nā paepae ʻē aʻe) a ke hōʻuluʻulu ʻia kahi binary me debuginfo.
    /// Ināʻaʻole hoʻi o kēia kūlana ua halawai laila, i kēia, e paha hoʻi `None`.
    ///
    /// # Nā hiʻohiʻona i makemake ʻia
    ///
    /// Pono kēia hana i ka hiʻohiʻona `std` o ka `backtrace` crate e hiki ai, a ʻo ka hiʻohiʻona `std` e hiki ai i ka paʻamau.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Maliʻa paha he par Ced C++ i hoʻohālikelike ʻia, inā ua pio ka hōʻailona mangled e like me Rust i holomua.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // E mālama pono i kēia ʻole o ka nui, no laila ʻaʻohe kumu kūʻai o ka hiʻohiʻona `cpp_demangle` ke kīnā ʻole.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ʻO kahi wahī e hoʻopuni ana i kahi inoa hōʻailona e hāʻawi i nā mea kōkua ergonomic i ka inoa i hoʻopau ʻia, nā byte maka, ke aho maka, a pēlā aku.
///
// E ʻae i ka code make no ka hiki ʻole o ka hiʻohiʻona `cpp_demangle`.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// I ka mea hou hōʻailona inoa, mai ka maka nń ku nāʻai.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Hoʻihoʻi i ka inoa (mangled) maka ma ke ʻano he `str` inā he utf-8 ka hōʻailona.
    ///
    /// E hoʻohana i ka `Display` manaʻo ina oe makemake i ka demangled mana.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Hoʻihoʻi i ka inoa hōʻailona maka ma ke ʻano he papa inoa o nā bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Hiki paha i kēia ke paʻi inā ʻaʻole kūpono ka hōʻailona demangled, no laila e lawelawe lokomaikaʻi i ka hemahema ma o ka hoʻolaha ʻole ʻana i waho.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Hoao e kiʻi hou i ua paʻa hoʻomanaʻo i hoʻohana ʻia e hōʻailona i nā helu wahi.
///
/// e hoao i kēia papa hana, e hookuu i kekahi global ikepili nā hale i i ole ia ua ahu puni ke ao a ma ka pae i kāu ho i wae DWARF 'ike' ole i 'ano like.
///
///
/// # Caveats
///
/// Ia keia kuleana pili i ka manawa i loaʻa ka mea, aole i maoli hana i kekahi mea ma luna o ka hapanui implementations.
/// County e like dbghelp paha libbacktrace e ole i iauaeoia i deallocate moku'āina a me ka hooponopono i ka anao? Aou iaiyoe.
/// No ka manawa o ka `gimli-symbolize` hiʻona o keia crate o ka wale hiʻona ma keia kuleana pili i kekahi kanawai.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}