// hoʻohana wale ʻia ma Linux i kēia manawa, no laila e ʻae i nā code make ma kahi ʻē
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ʻO kahi mea hāʻawi ʻona maʻalahi no nā buffer byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Hāʻawi i kahi pale o ka nui i kuhikuhi ʻia a hoʻihoʻi i kahi kuhikuhi hiki ke hoʻololi iā ia.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: ʻo kēia wale nō ka hana e kūkulu i kahi hoʻololi
        // kuhikuhi i `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // Maluhia: mākou ole wehe i nā kumumea mai `self.buffers`, no laila, i ka olua
        // i ka ʻikepili i loko o kahi buffer e ola inā `self` ka lōʻihi.
        &mut buffers[i]
    }
}