//! Hoʻolālā hōʻailona e hoʻohana ana i ka code DWARF-parsing i libbacktrace.
//!
//! Ke libbacktrace C waihona, nō kāu haawi me gcc, kūkulu pū hoʻomakaʻia,ʻaʻole wale kekahi backtrace (a mākou e ole nae hoʻohana) akā, i symbolicating ka backtrace a me ka lawelawe ana dwarf debug 'ike e pili ana i na mea e like inlined mōlina a whatnot.
//!
//!
//! He paʻakikī kēia ma muli o nā hopohopo like ʻole ma aneʻi, akā ʻo ka manaʻo maʻamau:
//!
//! * Kāhea mua mākou iā `backtrace_syminfo`.Kēia loaʻa hōʻailona ike, mai ka hōʻeuʻeu hōʻailonaʻaina ina ua hiki.
//! * Next mākou kahea `backtrace_pcinfo`.Kēia e wae debuginfo papa ina ka mea, 'oe i loaʻa, a ae mai, e loaa' ike e pili ana LIKE LIKE mōlina, filenames, laina helu, etc.
//!
//! Nui nā hana hoʻopunipuni e pili ana i ka lawe ʻana i nā papa dwarf i loko o ka hoʻi ʻana, akā lana ka manaʻo ʻaʻole ia ka hopena o ka honua a maopopo leʻa ke heluhelu i lalo.
//!
//! ʻO kēia ka ʻōnaehana hōʻailona hōʻailona no non-MSVC a me nā paepae OSX ʻole.I ka libstd ʻoiai kēia ka ʻōnaehana paʻamau no OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Inā hiki ke makemake i ka inoa `function` e hele mai ana mai debuginfo a hiki ke ʻoi aku ka pololei no nā papa laina laina.
                // Inā ʻaʻole ia ma laila akā hoʻi i ka inoa o ka papa ʻaina hōʻailona i kuhikuhi ʻia ma `symname`.
                //
                // Note i kekahi manawa, `function` ke haha aku i kekahi mau mea emi pololei, no ka laʻana i heluʻia me `try<i32,closure>` isntead o `std::panicking::try::do_call`.
                //
                // Ua KaʻAʻole anei loa ke kumu, akā, nohona ma ke `function` inoa manao hou pololei.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // mai hana iki i kēia manawa
}

/// ʻO ke ʻano o ka māka `data` i hala i `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ke kāhea ʻia kēia callback mai `backtrace_syminfo` ke hoʻomaka mākou e hoʻoholo a hele hou aku e kāhea iā `backtrace_pcinfo`.
    // E kūkākūkā ka hana `backtrace_pcinfo` i ka ʻike debug a hoʻāʻo e hana i nā mea e like me ka hoʻōla ʻana i ka ʻike file/line a me nā mōlina inline.
    // Note nae i `backtrace_pcinfo` hiki ole paha i hana nui ina aole ka ole debug ikepili kemu, no laila, inā e hana kākouʻoiaʻiʻo, e hea aku i ka callback me ma ka liʻiliʻi loa kekahi hōʻailona mai ka `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// ʻO ke ʻano o ka māka `data` i hala i `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Kākoʻo ka libbacktrace API i ka hoʻokumu ʻana i kahi mokuʻāina, akā ʻaʻole ia i kākoʻo i ka luku ʻana i kahi mokuʻāina.
// I kino lawe keia i ka olelo i ka moku'āina mea i manaoia e e hana, a laila, ola mau loa.
//
// I makemake aloha e? Aaeno ka at_exit() handler a lākou ma ka hoʻomaʻemaʻe i kēia moku'āina, akā, libbacktrace hoʻolako i wahi e hana ai.
//
// Me kēia mau kaohi, loaʻa kahi hana cached statically i kēia hana i helu ʻia i ka manawa mua e noi ʻia ai kēia.
//
// E hoʻomanaʻo i ka hoʻihoʻi ʻana i nā mea āpau i kahi serally (hoʻokahi laka honua).
//
// E hoʻomaopopo i ka hemahema o ka hoʻopili ʻana ma muli o ke koi e `resolve` e hoʻopili like ʻia me waho.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Mai hana i ka hiki ke hoʻohana i nā threadsafe o ka libbacktrace ʻoiai mākou e kāhea mau nei iā ia i kahi ʻano lōkahi.
        //
        0,
        error_cb,
        ptr::null_mut(), // ʻaʻohe ʻikepili keu
    );

    return STATE;

    // E noke ana no ka libbacktrace e hana i nā mea a pau e pono e 'imi i ka DWARF debug ikepili kemu no kaʻikena executable.Hana maʻamau ia ma o nā ʻano hana me, akā ʻaʻole i kaupalena ʻia i:
    //
    // * /proc/self/exe ma nā anuu kākoʻo
    // * Ua hala maopopo ka inoa filename ke hana nei i ka mokuʻāina
    //
    // Ke libbacktrace waihona mea he nui hoʻopöpö o C kuhi.Keia maoli 'o ia hoʻi ka mea, i ka loaa iaiyoe maluhia vulnerabilities, o ka oi aku ka wā lawelawe ana PilikiaʻAʻole i hoʻonohonoho pono debuginfo.
    // Ua holo nui ʻo Libstd i kēia mau mōʻaukala.
    //
    // Inā /proc/self/exe ua hoʻohana 'laila, ua hiki nō kāu kāpae'ōlelo i kēia mau me ke kuhi ana libbacktrace o "mostly correct", a ano e ae paha, aole e hana weird mea me "attempted to be correct" dwarf debug ikepili kemu.
    //
    //
    // Inā mākou e hele i kahi filename, akā, a laila hiki i kekahi mau paepae (e like me BSDs) kahi e hana ai kahi mea hana ʻino i kahi faila kūlike i kēlā wahi.
    // ʻO kēia ke kumu inā mākou e haʻi i ka libbacktrace e pili ana i kahi filename e hoʻohana ana paha i kahi faile arbitrary, e hoʻokau paha i nā ʻāpana ʻaoʻao.
    // Inā ʻaʻole mākou e haʻi i ka libbacktrace i kekahi mea akā ʻaʻole ia e hana i kekahi mea ma nā paepae i kākoʻo ʻole i nā ala e like me /proc/self/exe!
    //
    // Hāʻawi ʻia i nā mea āpau a mākou e hoʻāʻo ai e *ʻaʻole* hala i kahi filename, akā pono mākou ma nā paepae i kākoʻo ʻole iā /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Note i maikaʻi loa mākou Kuahiwi O hoʻohana `std::env::current_exe`, akā, ua hiki ole koi `std` ʻaneʻi.
            //
            // E ho ohana i `_NSGetExecutablePath` e kiʻi i kaʻikena executable ala i loko o ke kūpaʻa wahi (a ina e Aloha 'uuku e haawi mai).
            //
            //
            // Note e mākou huli seriously hilinai libbacktraceʻaneʻi i ka i make ma ino executables, akā, eʻoiaʻiʻo nō, e hana ana ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows i keʻano o ka weheʻana o AEIU kahi ma hope o ka mea Ka wehe ia hiki ole ke holoiʻia.
            // I ka i mau mea ke makemake nei no ka mea, ua makemake e hōʻoia 'ia mākou executable ua i hoʻololi mai, mai lalo mai ma hope o mākou i haawi ia aku i ka libbacktrace, hopefully mitigating i ka hiki i kekahi, ma ākeʻakeʻa kumuʻikepili i loko o libbacktrace (i hiki e mishandled).
            //
            //
            // Ua haawiia i ke hana i kekahi wahi o ka hula 'aneʻi, e hoao mai e kiʻi i kekahiʻano o ka laka ma luna o mākou iho kiʻi:
            //
            // * E kiʻi i kahi lima i ke kaʻina o kēia manawa, e hoʻouka i kona inoa filename.
            // * E wehe i kahi faila i kēlā inoa filename me nā lepa kūpono.
            // * Hoʻouka i ka inoa filename o ka hana i kēia manawa, e hōʻoia ana he like ia
            //
            // Inā hala kēlā āpau a mākou i ke kumumanaʻo ua wehe mākou i kā mākou faila a hōʻoia mākou ʻaʻole ia e loli.ʻO FWIW kope o kēia mea i kope ʻia mai libstd mōʻaukala, no laila ʻo kēia kaʻu wehewehe maikaʻi loa o nā mea e hana nei.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Noho kēia i ka hoʻomanaʻo paʻa i hiki ai iā mākou ke hoʻihoʻi iā ia ..
                static mut BUF: [i8; N] = [0; N];
                // ... a ke ola nei kēia ma ka puʻupuʻu no ka mea he manawa pōkole ia
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // intentionally liu `handle` ʻaneʻi no ka mea, ka mea e wehe ae e malama mākou laka ma keia waihona inoa.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Mākou makemake e hoʻi i māhele i ka nul-'ōlelo, no laila, inā i piha nā mea a pau i loko o lākou, a me ka ia i ka huina lōʻihi laila equate ia i ka ole.
                //
                //
                // I ole ia, i ka wa hoi i ka pomaikai hana i paa, ua hui pū ka nulʻai i loko o ka māhele.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace hewa Ke kahili ae ma lalo o ka rug
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Kāhea i ka `backtrace_syminfo` API (mai ka heluhelu ʻana i ke code) e kāhea pono iā `syminfo_cb` i hoʻokahi manawa (a i ʻole e holo hewa paha.
    // A laila mālama mākou i nā mea hou aʻe i loko o ka `syminfo_cb`.
    //
    // E hoʻomaopopo e hana mākou i kēia mai `syminfo` e nīnau i ka papa ʻaina, e loaʻa ana nā inoa hōʻailona inā ʻaʻohe ʻike debug i ka binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}