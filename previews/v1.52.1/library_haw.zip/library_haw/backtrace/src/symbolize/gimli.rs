//! Kākoʻo no ka hōʻailona me ka hoʻohana ʻana i ka `gimli` crate ma crates.io
//!
//! 'O kēia ka paʻamau symbolication manaʻo no Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'kūpaʻa ke ola a pau i ka wahaheʻe e hack a puni ka nele o ke kākoʻo no ka iho-referential hana.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Hoʻololi i nā 'static lifetime mai ka manawa e hōʻaiʻe wale nā hōʻailona iā `map` a me `stash` a ke mālama nei mākou iā lākou ma lalo.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // No ka hoʻouka ʻana i nā hale waihona puke ʻōiwi ma Windows, e ʻike i kahi kūkā ʻana ma rust-lang/rust#71060 no nā ʻōkuhi like ʻole ma aneʻi.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW County a ianoiyuaa a mai kākoʻo ASLR (rust-lang/rust#16514), akā, DLLs hiki nō ke relocated a puni i loko o ka helu makahiki.
            // ʻIke ʻia nā kamaʻilio ma ka ʻikepili debug āpau āpau-inā hoʻoili ʻia kēia waihona ma kāna "image base", kahi māla i kāna mau poʻo poʻo COFF.
            // ʻOiai ʻo kēia ka mea a debuginfo e helu ai mākou i ka papa inoa hōʻailona a mālama i nā helu wahi me he mea lā ua hoʻouka ʻia ka waihona ma "image base".
            //
            // ʻAʻole paha e hoʻouka ʻia ka waihona ma "image base".
            // (Presumably kekahi mea'ē aʻe i ke Hoʻoili aʻela ma laila?) Kēia mea ma ka `bias` ke kahua mai i loko o play, a ua pono, e pohihihi mai i ka waiwai o `bias` ʻaneʻi.Minamina naʻe ʻaʻole maopopo pehea e loaʻa ai kēia mai kahi module i kau ʻia.
            // Akā, ʻo ka mea i loaʻa iā mākou, ʻo ia ka helu wahi hoʻouka maoli (`modBaseAddr`).
            //
            // Ma ke ʻano he cop-out no kēia manawa mmap mākou i ka faila, heluhelu i ka ʻike poʻo i ka poʻo o ka faila, a laila hāʻule ka mmap.He wasteful no mākou e paha reopen i ka mmap hope, akā, i kēia, e hana maikaʻi lawa no ka manawa.
            //
            // Once mākou i ka `image_base` (makemake e haawe wahi) a me ka `base_addr` (maoli haawe wahi) mākou ke hoʻopiha i loko o ka `bias` (likeʻole ma waena o ka maoli a me ka makemake), a laila, i ka Kūla Ao aae? O kēlā me kēia Hoʻohana o ka `image_base`, mai ia mau mea i ka waihona i olelo mai.
            //
            //
            // No ka manawa eia kahi mea akaka i like ELF/MachO mākou hiki e hana i kekahi Hoʻohana no waihona, hoʻohana `modBaseSize` like me ka a pau nui.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS hoʻohana i ka faila faila Mach-O a hoʻohana i nā API kikoʻī ʻo DYLD e hoʻouka i kahi papa inoa o nā hale waihona puke ʻōiwi i ʻāpana o ka noi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // E kiʻi i ka inoa o keia waihona i hoʻopili like ai i ke ala o kahi e kiʻi ia i pono.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // E hoʻouka i ke poʻo kiʻi o kēia waihona a me ka ʻelele iā `object` e ʻoki i nā kauoha ukana a pau i hiki ai iā mākou ke ʻike i nā ʻāpana āpau e pili ana ma aneʻi.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // E hoʻopili i nā ʻāpana a hoʻopaʻa inoa i nā wahi i ʻike ʻia no nā ʻāpana a mākou e loaʻa ai.
            // Hoʻopili i nā ʻikepili e pili ana i nā ʻatikala no ka hana ʻana ma hope, e ʻike i nā manaʻo ma lalo.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // E hoʻoholo i ka "slide" no kēia waihona i pau i ke ʻano bias a mākou e hoʻohana ai e ʻike i kahi e hoʻouka ʻia ai nā mea hoʻomanaʻo.
            // ʻO kēia kahi mea helu ʻē aʻe akā ʻo ia ka hopena o ka hoʻāʻo ʻana i kekahi mau mea i ka nāhelehele a me ka ʻike ʻana i nā lāʻau.
            //
            // ʻO ka manaʻo nui ʻo ka `bias` a me kahi `stated_virtual_memory_address` o kahi ʻāpana e noho ana ma kahi o kahi kikoʻī maoli e noho ai ka ʻāpana.
            // ʻO ka mea ʻē aʻe a mākou e hilinaʻi nei ʻoiai kahi helu maoli i lawe ʻia i ka `bias` ka papa kuhikuhi e nānā i ka papa hōʻailona a me ka debuginfo.
            //
            // Akā naʻe, no ka waihona puke i hoʻoili ʻia i ka pūnaewele i hewa ʻole kēia mau helu.No nā ʻōiwi hoʻokō, eia naʻe, ʻike pololei ʻia.
            // Ke hāpai nei i kahi loiloi mai kā LLDB kumuwaiwai he loaʻa kūikawā kūikawā ia no ka ʻāpana `__TEXT` mua i hoʻouka ʻia mai ka faila offset 0 me ka nui nonzero.
            // No kēlā me kēia kumu ke loaʻa kēia e ʻike ʻia ka pili o ka papa ʻaina i ka paheʻe vmaddr wale nō no ka waihona.
            // Inā ʻaʻole *loaʻa* a laila pili ka pākaukau hōʻailona i ka slide vmaddr a me ka ʻōlelo a ka ʻāpana i ʻōlelo ʻia.
            //
            // E mālama i kēia kūlana inā ʻaʻole mākou * e ʻike i kahi ʻatikala ma ka faila offset zero a laila hoʻonui mākou i ka bias e nā ʻāpana o nā ʻāpana ʻōlelo mua a hoʻoliʻiliʻi hoʻi i nā helu i haʻi ʻia e kēlā nui.
            //
            // Pēlā e hōʻike mau ʻia ai ka papa ʻaina e pili ana i ka nui o ka bias o ka waihona.
            // ʻIke ʻia kēia i nā hopena kūpono no ka hōʻailona ma o ka pākaukau hōʻailona.
            //
            // ʻOiaʻiʻo ʻaʻole wau i maopopo piha inā pololei kēia a inā aia kekahi mea ʻē aʻe e hōʻike pehea e hana ai i kēia.
            // I kēia manawa ʻoiai e holo pono kēia me (?) a hiki mau iā mākou ke hoʻololi i kēia i ka manawa ke pono.
            //
            // No kekahi ʻike hou aku e ʻike iā #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Other Unix (e like
        // Linux) hoʻohana nā paepae iā ELF ma ke ʻano he faila faila a hoʻokō pinepine i kahi API i kapa ʻia ʻo `dl_iterate_phdr` e hoʻouka i nā waihona puke ʻōiwi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` pono he kuhi kūpono.
        // `vec` E e ka henua pololei laʻau kuhikuhi i ka `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ʻaʻole kākoʻo maoli i ka info debug, akā e hoʻokau ka ʻōnaehana kūkulu i ka ʻike debug ma ke ala `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Pono nā mea āpau āpau e hoʻohana iā ELF, akā ʻaʻole ʻike pehea e hoʻouka ai i nā waihona puke ʻōiwi.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Ua hoʻoili ʻia nā hale waihona puke i ʻike ʻia.
    libraries: Vec<Library>,

    /// Hoʻopili nā palapala kiʻi kahi mākou e mālama ai i ka ʻike dwarf i pāleo ʻia.
    ///
    /// He paʻa paʻa ko kēia papa inoa no kāna hāpai hāpai holoʻokoʻa i hoʻonui ʻole.
    /// ʻO ka mea `usize` o kēlā me kēia pālua he papa kuhikuhi i `libraries` ma luna kahi e hōʻike ai ʻo `usize::max_value()` i ka luna o kēia manawa.
    ///
    /// Pili ka `Mapping` i ka ʻikepili dwarf like.
    ///
    /// E hoʻomaopopo he kuhi LRU kēia a e hoʻololi mākou i nā mea ma aneʻi e pili ana i nā helu kuhi.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Ua hoʻouka ʻia nā ʻāpana o kēia waihona i loko o ka hoʻomanaʻo, a ma hea lākou e hoʻouka ai.
    segments: Vec<LibrarySegment>,
    /// ʻO ka "bias" o kēia waihona, ma kahi maʻamau e hoʻouka ʻia i ka hoʻomanaʻo.
    /// Hoʻohui ʻia kēia waiwai i kēlā me kēia ʻāpana i ʻōlelo ʻia e kiʻi i ka leka uila hoʻomanaʻo maoli i hoʻouka ʻia ka ʻāpana i loko.
    /// Eia keia pāʻewaʻewa ua unuhi mai maoliʻike kamepiula iaiyoe helu kuhi henua i ka 'inideka i loko o debuginfo a me ka hōʻailona papa.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Ka olelo helu wahi o keia Hoʻohana i ka mea waihona.
    /// Kēia mea,ʻaʻole maoli kahi i ka Hoʻohana ua ukana, akā, e aho e keia helu wahi hua hoʻohui ka i loaʻa ka hale waihona puke i ka `bias` mea kahi e loaʻa ia.
    ///
    stated_virtual_memory_address: usize,
    /// Ka nui o ths Hoʻohana i ka iaiyoe.
    len: usize,
}

// palekana ʻole no ka mea koi ʻia kēia e kaho waho waho
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // palekana ʻole no ka mea koi ʻia kēia e kaho waho waho
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Kahi liʻiliʻi loa, maʻalahi ʻo LRU cache no debug info mappings.
        //
        // Pono ke kiʻekiʻe hit e kiʻekiʻe loa, ʻoiai ʻaʻole hele ka stack maʻamau ma waena o nā waihona puke like.
        //
        // ʻOi aku ka pipiʻi o nā hale `addr2line::Context` e hana.
        // Kuhi ʻia kāna kumukūʻai e nā nīnau `locate` e hiki mai ana, e leverage i nā hale i kūkulu ʻia i ke kūkulu ʻana i `addr2line: : Context`s e kiʻi i nā wikiwiki wikiwiki.
        //
        // Inā i ole i mākou i kēia ahu, e amortization makemake loa e hiki mai, a me ka symbolicating backtraces makemake e ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ʻO ka mea mua, e hoʻāʻo inā loaʻa kēia `lib` i kahi ʻāpana i loaʻa ka `addr` (lawelawe ʻana i ka neʻe ʻana).Inā hala kēia hōʻoia a laila hiki iā mākou ke hoʻomau ma lalo a unuhi maoli i ka helu wahi.
                //
                // E hoʻomaopopo e hoʻohana nei mākou iā `wrapping_add` ma aneʻi e hōʻalo i nā loiloi laha.ʻIke ʻia i ka nāhelehele e hāhā ana ka SVMA + bias computation.
                // Me he mea lā ʻano ʻē paha ia e hiki mai ana akā ʻaʻohe nui nui a hiki iā mākou ke hana e pili ana i ia mea ʻē aʻe ma mua o ka nānā ʻole ʻana i kēlā mau ʻāpana ʻoiai ke kuhikuhi nei lākou i kahi ākea.
                //
                // Ua hele mai kēia i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // I kēia manawa ua ʻike mākou he `addr` ka `addr`, hiki iā mākou ke offset me ka bias e ʻike i ka helu hoʻomanaʻo hoʻomanaʻo virutal i ʻōlelo ʻia.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: ma hope o kēia conditional ke hoʻoholo 'ia me ka wanaʻao hoi
        // mai kahi kuhi hewa, ke komo cache no kēia ala aia ma ka helu 0.

        if let Some(idx) = idx {
            // Ke paʻa nei ka palapala kiʻi i ka cache, neʻe i mua.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // I ka wā o ka kŰia ha mea,ʻaʻole i loko o ke ahu hoʻokoe, e ho okumu i ka hou kŰia ha, hookomo ia i loko o ke alo o ke ahu hoʻokoe, a hoʻokuke ka mea kahiko ahu hoʻokoe komo inā e pono ai.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // mai kulu i ke ola `'static`, e nānā pono ia iā mākou iho
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Hoʻonui i ke ola o `sym` a `'static` ʻoiai koi koi ʻia mākou ma aneʻi, akā ke hele nei i waho ma ke ʻano he kuhikuhi no laila ʻaʻole e hoʻomau ʻia kahi kūmole ma waho o kēia kiʻi.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Eia hoi, kiʻi i ka ahu kŰia ha a hana i kekahi hou kŰia ha no keia waihona, a loiloi i ka DWARF 'Ikepili, e imi i ka file/line/name no keia helu wahi.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Ua hiki iā mākou ke ʻimi i ka ʻike kino no kēia hōʻailona, a ʻo kā frame ʻo addr2line` i loko āpau nā kikoʻī nitty gritty āpau.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ʻAʻole hiki ke ʻike i ka ʻike debug, akā ua ʻike mākou ia i loko o ka pākaukau hōʻailona o ka elf i hiki ke hoʻokō ʻia.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}