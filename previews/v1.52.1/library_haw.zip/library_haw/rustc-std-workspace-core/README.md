# Ka `rustc-std-workspace-core` crate

Kēia crate He He no ie o Sima, a kaawale ko crate i wale hilinaʻi nui ma `libcore` a reexports a pau o kona Contents.
Ke crate o ka crux o Kuhina ka maʻamau hale waihona puke, e hilinai ma crates mai crates.io

Crates ma crates.io ka hale waihona puke maʻamau e pili i ka pono e hilinaʻi i ka `rustc-std-workspace-core` crate mai crates.io, kahi hakahaka.

Hoʻohana mākou i `[patch]` e hoʻokahuli iā ia i kēia crate i kēia waihona.
E like me ka hopena, crates ma crates.io, e kikoo aku i kekahi dependency edge i `libcore`, i ka mana ho'ākāka 'ia i loko o kēia waihona.
Pono kēlā e huki i nā kihi hilinaʻi āpau e hōʻoia Cargo kūkulu crates maikaʻi!

Note e crates ma crates.io Pono e hilinai ma keia crate me ka inoa `core` no na mea a pau i ka hana pono.Hiki iā lākou ke hoʻohana:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ma ka hoʻohana o ka `package` kī ka crate ua Kapa hou i ke ia `core`, ke ano, ka mea e nana e like

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ka wā Cargo ke pule aku nei i ka compiler, satisfying ka implicit `extern crate core` kauoha injected ma ka compiler.




