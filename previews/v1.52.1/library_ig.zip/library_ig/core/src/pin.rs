//! Tydị nke na-etinye data na ọnọdụ ya na ebe nchekwa.
//!
//! Ọ bara uru mgbe ụfọdụ ịnwe ihe ndị ejiri n'aka na ha agaghị agagharị, n'echiche na ntinye ha na ebe nchekwa anaghị agbanwe agbanwe, ma nwee ike ịdabere na ya.
//! Otu ihe atụ kachasị mma nke ọnọdụ dị otú ahụ ga-abụ iji aka gị na-ekwu okwu, dịka ị na-ebugharị ihe na ntụpọ n'onwe ya ga-emebi ha, nke nwere ike ibute omume a na-akọwaghị.
//!
//! Na ọkwa dị elu, [`Pin<P>`] na-eme ka o doo anya na onye na-akọwa ụdị ụdị `P` ọ bụla nwere ebe nchekwa na ebe nchekwa, nke pụtara na enweghị ike ịkwaga ya ebe ọzọ na enweghị ike ịhazi ebe nchekwa ya ruo mgbe ọ ga-adaba.Anyị na-ekwu na pointee bụ "pinned".Ihe na-adị aghụghọ karị mgbe a na-atụle ụdị nke jikọtara pinned na data na-abụghị pinned;[see below](#projections-and-structural-pinning) maka nkọwa ndị ọzọ.
//!
//! Site na ndabara, ụdị niile dị na Rust nwere ike ibugharị.
//! Rust na-enye ohere ịgafe ụdị niile na-abaghị uru, yana ụdị smart-pointer dịka [`Box<T>`] na `&mut T` na-enye ohere iji dochie ma na-ebugharị ụkpụrụ ha nwere: ị nwere ike ịpụ na [`Box<T>`], ma ọ bụ ịnwere ike iji [`mem::swap`].
//! [`Pin<P>`] eyiri a pointer ụdị `P`, otú [``Pin`] '' <`['' Box`] ''<T>> arụ ọrụ dị ka mgbe niile
//!
//! [`Box<T>`]: when a (``Pin`] '' ``('' Box`]]<T>> na-adaba, ya mere ime ọdịnaya ya, na ebe nchekwa na-enweta
//!
//! gbasaa.N'otu aka ahụ, [`Pin`]`<&mut T>`` dị ka `&mut T`.Otú ọ dị, [`Pin<P>`] anaghị ka ahịa n'ezie nweta a [`Box<T>`] ma ọ bụ `&mut T` na pinned data, nke na-egosi na i nwere ike iji arụmọrụ dị ka [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` chọrọ `&mut T`, mana anyị enweghị ike inweta ya.
//!     // Anọgidere anyị, anyị enweghị ike ịgbanwe ọdịnaya nke amaokwu ndị a.
//!     // Anyị nwere ike iji `Pin::get_unchecked_mut`, mana nke ahụ enweghị nchedo maka ihe kpatara ya:
//!     // anyi anaghi anabata ya iji ya wepu ihe na `Pin`.
//! }
//! ```
//!
//! Ọ bara uru ikwughachi na [`Pin<P>`]*anaghị* agbanwe eziokwu ahụ bụ na onye na-achịkọta Rust na-elele ụdị ụdị niile anya.[`mem::swap`] na-anọgide na-adaba maka `T` ọ bụla.Kama nke ahụ, [`Pin<P>`] na-egbochi ụfọdụ ụkpụrụ * (nke a tụrụ atụ na [`Pin<P>`]) site na ịme ka ọ ghara ịkpọ usoro chọrọ `&mut T` na ha (dị ka [`mem::swap`]).
//!
//! [`Pin<P>`] enwere ike iji kechie ụdị pointer `P` ọ bụla, yana ka ọ na-emekọrịta [`Deref`] na [`DerefMut`].A [`Pin<P>`] ebe `P: Deref` ga-atụle ka a "`P`-style pointer" ka a pinned `P::Target`-ya mere, a ['Pin`]' <'[' Box`] '<T>> bụ ihe nwere pointer nwere na pinne `T`, yana [`Pin`]``<` ['' Rc`] ''<T>> bụ ihe ntụgharị-agụpụtara maka akara aka na `T` a tụkọtara.
//! Maka imezi, [`Pin<P>`] na-adabere na ntinye nke [`Deref`] na [`DerefMut`] ka ọ ghara ịpụ na ihe ha `self`, ma ọ bụ naanị mgbe ịlaghachi akara aka na pinned data mgbe akpọrọ ha na poin pointer.
//!
//! # `Unpin`
//!
//! Ọtụtụ ụdị dị mgbe niile na-ebugharị n'efu, ọbụlagodi mgbe a tụgidere, n'ihi na ha anaghị adabere na ịnweta adreesị dị mma.Nke a gụnyere ụdị niile (dị ka [`bool`], [`i32`], na ntụaka) yana ụdị nwere naanị ụdị ndị a.Dị ndị na-adịghị eche banyere pinning mejuputa [`Unpin`] auto-trait, nke na-akagbu mmetụta nke [`Pin<P>`].
//! Maka `T: Unpin`, [``Pin`] '' ``('' Box`]<T>> 'Na [`Box<T>`] ọrụ identically, dị ka ime [' Pin`] '<&mut T>' na `&mut T`.
//!
//! Rịba ama na pinning na [`Unpin`] na-emetụta `P::Target` a kapịrị ọnụ, ọ bụghị ụdị ntinye aka `P` n'onwe ya nke etinyere na [`Pin<P>`].Dịka ọmụmaatụ, ma [`Box<T>`] bụ [`Unpin`] ma ọ bụ na ọ nweghị [`Unpin`] enweghị mmetụta na omume nke [``Pin`] '' <`[` `Box`] ''<T>> `` (Ebe a, `T` bụ pịnyere aka iji pịnye).
//!
//! # Ihe Nlereanya: ntinye aka nke onwe
//!
//! Tupu anyị abanye na nkọwa ndị ọzọ iji kọwaa nkwa na nhọrọ ndị metụtara `Pin<T>`, anyị na-atụle ụfọdụ ihe atụ maka otu esi eji ya.
//! Enwere onwe gị na [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Nke a bụ usoro nhazi onwe onye n'ihi na mpaghara iberi na-arụtụ aka na mpaghara data.
//! // Anyị enweghị ike ịgwa onye nchịkọta ihe banyere nke ahụ site na iji ntụpọ nkịtị, ebe ọ bụ na enweghị ike ịkọwa ụkpụrụ a na iwu ịgbaziri ego na mbụ.
//! //
//! // Kama nke ahụ, anyị na-eji pointer raw, ọ bụ ezie na nke a maara na ọ bụghị ihe efu, dịka anyị maara na ọ na-atụ aka na eriri.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Iji hụ na data ahụ anaghị agagharị mgbe ọrụ ahụ laghachiri, anyị na-etinye ya na ikpo ebe ọ ga-anọru oge ndụ nke ihe ahụ, naanị otu ụzọ isi nweta ya ga-abụ site na ntụnyere ya.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // anyị na-eke pointer naanị mgbe data ahụ dị ma ọ bụghị ya ọ ga-agalarịrị tupu anyị ebido
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // anyị maara na nke a dị mma n'ihi na ịmegharị mpaghara anaghị ebugharị ihe niile
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ntuziaka kwesịrị igosi ebe ziri ezi, ọ bụrụhaala na nhazi ahụ emegharịghị.
//! //
//! // Ka ọ dị ugbu a, anyị nweere onwe anyị ịkwaga pointer gburugburu.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ebe ụdị anyị anaghị etinye Unpin, nke a agaghị achịkọta:
//! // ka mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Ihe Nlereanya: intrusive doubly-linked list
//!
//! Ke intrusive doubly-jikọrọ ndepụta, collection anaghị n'ezie igbunye ebe nchekwa maka ọcha onwe ya.
//! Ndị ahịa na-achịkwa oke ahụ, yana ihe nwere ike ibi na okpokoro na-adị mkpụmkpụ karịa nchịkọta ahụ.
//!
//! Iji rụọ ọrụ a, ihe ọ bụla nwere akara nke onye bu ya ụzọ na onye nọchiri ya na ndepụta ahụ.Enwere ike ịgbakwunye ihe naanị mgbe a tụdoro ha, n'ihi na ịgagharị ihe ndị dị na ya ga-eme ka akara ngosi ghara ịdị ire.Ọzọkwa, [`Drop`] mmejuputa nke ihe jikọtara ndepụta ga-amachi akara nke onye bu ya ụzọ na onye nọchiri ya iji wepu onwe ya na listi ahụ.
//!
//! N'ụzọ dị oke mkpa, anyị ga-enwe ike ịdabere na akpọrọ [`drop`].Ọ bụrụ na enwere ike ịmegharị ihe ma ọ bụ mebie ya na-akpọghị [`drop`], ndị na-atụnye ya n'ime ihe ndị gbara ya gburugburu ga-abụ ihe na-adịghị mma, nke ga-agbaji usoro data.
//!
//! Ya mere, pinning na-abia na nkwa [``drop`].
//!
//! # `Drop` guarantee
//!
//! Ebumnuche nke pinning bụ inwe ike ịdabere na ntinye nke ụfọdụ data na ebe nchekwa.
//! Iji mee ọrụ a, ọ bụghị naanị ịmegharị data ahụ ka amachibidoro;a na-egbochi imegharị, imegharị, ma ọ bụ na-enweghị ike imebi ihe nchekwa echekwara iji chekwaa data ahụ.
//! N'ikpeazụ, maka data ezubere ịchebe gị na * ebe nchekwa ya agaghị emebi ma ọ bụ weghachi ya site na mgbe a tụdoro ya ruo mgbe akpọrọ [`drop`].Naanị mgbe [`drop`] laghachiri ma ọ bụ panics, enwere ike iweghachi ebe nchekwa ahụ.
//!
//! Ebe nchekwa nwere ike ịbụ "invalidated" site na nkesa azụmahịa, kamakwa site na dochie [`Some(v)`] site na [`None`], ma ọ bụ ịkpọ [`Vec::set_len`] ka "kill" ụfọdụ ihe si na vector.Enwere ike iweghachi ya site na iji [`ptr::write`] iji degharịa ya na-akpọghị onye mbibi ahụ na mbụ.Enweghị nke a na-ekwe ka data ezukọ na-akpọghị [`drop`].
//!
//! Nke a bụ kpọmkwem ụdị nkwa na ndepụta njikọ jikọtara ọnụ site na ngalaba gara aga kwesịrị ịrụ ọrụ nke ọma.
//!
//! Rịba ama na nke a nkwa na-eme *bụghị* pụtara na ebe nchekwa na-adịghị ihihi!Ọ bụ ka kpamkpam na na agaghị na-akpọ [`drop`] na a pinned mmewere (eg, ị ka nwere ike ịkpọ [`mem::forget`] on a ['Pin`]' <'[' Box`] '<T>>)).N'ihe atụ nke ndepụta ejikọtara nke abụọ, mmewere ahụ ga-anọ na ndepụta ahụ.Otú ọ dị unu wee ghara free ma ọ bụ iwerekwa nchekwa *enweghị akpọ ['drop`]*.
//!
//! # `Drop` implementation
//!
//! Ọ bụrụ na ụdị gị na-eji ntụtụ (dịka ihe atụ abụọ dị n'elu), ị ga-akpachara anya mgbe ị na-emejuputa [`Drop`].Ọrụ [`drop`] na-ewere `&mut self`, mana a na-akpọ ya *ọbụlagodi ma ọ bụrụ na ụdị gị agbago na mbụ*!Ọ dịka a ga-asị na onye na-akpakọ akpaghị aka [`Pin::get_unchecked_mut`].
//!
//! Nke a enweghị ike ibute nsogbu na koodu nchekwa n'ihi na ịmejuputa ụdị nke na-adabere na pinning chọrọ koodu na-enweghị nchebe, mana mara na ị na-ekpebi iji pinning na ụdị gị (dịka ọmụmaatụ site na itinye ụfọdụ ọrụ na [`Pin`]`<&Self>`` ma ọ bụ [``Pin`] ''&&Onwe gị> ``) nwere nsonaazụ maka mmejuputa [`Drop`] gị: ọ bụrụ na a ga-atụnye ụdị ụdị gị, ị ga-emeso [`Drop`] ka ọ na-ewere [`Pin`]` <&mut Onwe> ``.
//!
//!
//! Iji maa atụ, ịnwere ike itinye `Drop` dị ka ndị a:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ọ dị mma maka na anyị ma na anaghị eji uru a aba ọzọ mgbe etufuru ya.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ojiji dobe koodu na-aga ebe a.
//!         }
//!     }
//! }
//! ```
//!
//! Ọrụ `inner_drop` nwere ụdị nke [`drop`]*kwesịrị* ịnwe, yabụ nke a na-ejide n'aka na ị gaghị eji `self`/`this` mee ihe ọghọm n'ụzọ na-adabaghị na pinning.
//!
//! Ọzọkwa, ọ bụrụ na gị na ụdị bụ `#[repr(packed)]`, na compiler ga-akpaghị aka-akpali ubi gburugburu na-enwe ike idebe ha.Ọ pụrụ ọbụna ime na n'ihi na ubi na-eme ka a zuru ezu kwekọọ.Dị ka a na ya pụta, i nwere ike iji pinning na a `#[repr(packed)]` ụdị.
//!
//! # Ntughari na pinning Structural
//!
//! Mgbe ị na-arụ ọrụ ejiri akara eserese, ajụjụ na-ebilite etu mmadụ ga-esi nweta ngalaba nke ihe owuwu ahụ na usoro nke na-ewere naanị [``Pin`] '' <&mut Struct> ``.
//! Approachzọ a na-emebu bụ ide ụzọ inyeaka (nke a na-akpọ *projections*) nke na-atụgharị (``Pin`] ''&&Ihe nrụpụta> ``gaa na ntụ aka maka ubi ahụ, mana ụdị ụdị ntụaka ahụ kwesịrị inwe?Ọ bụ [`Pin`]` `<&mut Ubi>` `ma ọ bụ `&mut Field`?
//! Otu ajụjụ na-ebilite na ubi nke ihe `enum`, ya na mgbe atụle container/wrapper ụdị dị ka [`Vec<T>`], [`Box<T>`], ma ọ bụ [`RefCell<T>`].
//! (Ajuju a metutara ma ihe edere ederede na ederede ederede, anyi na-eji okwu ndi mmadu na-eme karie ebe a maka ihe omuma.)
//!
//! Ọ na-apụta na ọ bụ onye edemede nke usoro data ka ọ ga-ekpebi ma atụmatụ a na-atụ atụ maka otu mpaghara na-atụgharị [``Pin`] ''&&Ihe nchekwa> ``n'ime '' Pin`] `` `&mut Field`.Enwere ụfọdụ ihe mgbochi, ma ihe mgbochi kachasị mkpa bụ *nkwekọrịta*:
//! a pụrụ ịkọwa *ihe ọ bụla na ntinye aka,* ma ọ bụ * wepụ pinning dị ka akụkụ nke ntule.
//! Ọ bụrụ na ma na-eme n'ihi na otu ubi, na ga-abụ na amamihe na-adịghị!
//!
//! Dị ka onye edemede nke usoro data ị ga-ekpebi maka mpaghara ọ bụla ma ọ na-agbanye "propagates" na mpaghara a ma ọ bụ na ọ bụghị.
//! Pinning na propagates a na-akpọ "structural", n'ihi na ọ na-agbaso usoro nke ụdị.
//! Na ngalaba ndị a, anyị na-akọwa ntụle ndị a ga-eme maka nhọrọ ọ bụla.
//!
//! ## Pinning *abụghị* nhazi maka `field`
//!
//! O nwere ike iyi ihe na-emeghị eme nwere ike ghara ịkọ mpaghara nke ihe eji arụ ọrụ, mana nke ahụ bụ nhọrọ kachasị mfe: ọ bụrụ na emebeghị [``Pin`] `<&mut Field> '', ọ nweghị ihe ga-emehie!Yabụ, ọ bụrụ na ị kpebie na ụfọdụ ubi enweghị usoro iwu eji arụ ọrụ, ihe niile ị ga-ahụ bụ na ị naghị ekepụta akara aka na mpaghara ahụ.
//!
//! Ubi na-enweghị usoro ntanye nwere ike ịnwe usoro ntụgharị nke na-atụgharị [``Pin`] '' <&mut Struct> `` n'ime `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Nke a dị mma maka na anaghị ewere `field` ntụtụ.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Ị nwere ike na-`impl Unpin for Struct`*ọ bụrụgodị* ụdị `field` bụghị [`Unpin`].Ihe ụdị ahụ chere maka pinning adịghị mkpa mgbe onweghị ['Pin`]`<&mut Field>' '.
//!
//! ## Pinning *bụ* nhazi maka `field`
//!
//! Nhọrọ ọzọ bụ ikpebi na pinning bụ "structural" maka `field`, nke pụtara na ọ bụrụ na etinyere ihe owuwu ahụ otu ahụ ka ubi ahụ dị.
//!
//! Nke a na-enye ohere ide ederede amụma nke na-emepụta [``Pin`] '' <&mut Field> ``, si otú a na-agba ama na a tụụrụ ubi ahụ:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Nke a dị mma maka na etinyere `field` mgbe `self` dị.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Agbanyeghị, pinning usoro na-abịa na ihe ole na ole achọrọ:
//!
//! 1. Ihe owuwu ahụ ga-abụ [`Unpin`] naanị ma ọ bụrụ na ngalaba nhazi niile bụ [`Unpin`].Nke a bụ ndabara, mana [`Unpin`] bụ nchekwa trait, yabụ dị ka onye edemede nke nhazi ọ bụ ọrụ gị *ọ bụghị* ịgbakwunye ihe dị ka `impl<T> Unpin for Struct<T>`.
//! (Rịba ama na ịtinye ọrụ nyocha na-achọ koodu na-enweghị nchebe, yabụ eziokwu ahụ bụ na [`Unpin`] bụ trait dị mma anaghị emebi ụkpụrụ na naanị ị ga-echegbu onwe gị gbasara nke a ma ọ bụrụ na ị jiri `` enweghị nchekwa ''.
//! 2. The destructor nke struct ga adịghị akpali bughi ubi nke ya okwu.Nke a bụ ihe ziri ezi nke etolitere na [previous section][drop-impl]: `drop` na-ewere `&mut self`, mana a ga-atụnye usoro (yabụ mpaghara ya).
//!     Ga-ekwe nkwa na ị gaghị agagharị n'ọhịa n'ime mmejuputa [`Drop`] gị.
//!     Karịsịa, dịka akọwara na mbụ, nke a pụtara na nhazi gị ga-abụrịrị * ọ bụghị `#[repr(packed)]`.
//!     Hụ ngalaba ahụ maka otu esi ede [`drop`] n'ụzọ onye nchịkọta nwere ike inyere gị aka ka ị ghara ịgbaji pinning na mberede.
//! 3. Ghaghi ijide n'aka na ị kwadoro [`Drop` guarantee][drop-guarantee]:
//!     ozigbo, etinyere ihe ederede gị, ebe nchekwa nwere ọdịnaya anaghị edegharị ma ọ bụ weghachite ya na-akpọghị ndị na-emebi ọdịnaya.
//!     Nke a pụrụ ịbụ tricky, dika a site [`VecDeque<T>`]: na destructor nke [`VecDeque<T>`] nwere ike na-akpọ [`drop`] na niile ọcha ma ọ bụrụ na otu n'ime destructors panics.Nke a megidere nkwa [`Drop`], n'ihi na ọ nwere ike ibute ihe ndị ọzọ na-ebugharị na-akpọghị onye nbibi ha.([`VecDeque<T>`] enweghị atụ pinning, n'ihi ya, nke a anaghị akpata unsoundness.)
//! 4. Ikwesighi ịnye ọrụ ọ bụla ọzọ nke nwere ike iduga na iwepụ data n'ọhịa ebe a na-atụ ụdị gị.Ka ihe atụ, ọ bụrụ na ndị struct nwere ihe [`Option<T>`] na e nwere a 'take`-dị ka ọrụ na ụdị `fn(Pin<&mut Struct<T>>) -> Option<T>`, na ime ihe ike ga-eji na-akpali a `T` nke a pinned `Struct<T>`-nke pụtara pinning nwere ike ịbụ bughi maka ubi-ejide a data.
//!
//!     Maka ihe atụ dị mgbagwoju anya nke na-ebugharị data site na ụdị pinned, chee echiche ma ọ bụrụ na [`RefCell<T>`] nwere usoro `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Anyị nwere ike ime ihe ndị a:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Nke a bụ ọdachi, ọ pụtara na anyị nwere ike ibu ụzọ tụlee ọdịnaya nke [`RefCell<T>`] (iji `RefCell::get_pin_mut`) wee megharia ọdịnaya ahụ site na iji ntụgharị ntụgharị anyị nwetara mgbe e mesịrị.
//!
//! ## Examples
//!
//! Maka ụdị dịka [`Vec<T>`], ohere abụọ (nhazi usoro ma ọ bụ na ọ bụghị) nwere uche.
//! A [`Vec<T>`] na bughi pinning nwere ike `get_pin`/`get_pin_mut` ụzọ ina pinned zoro aka ọcha.Agbanyeghị, ọ nweghị ike * ịhapụ ịkpọ [`pop`][Vec::pop] na [`Vec<T>`] a tụkọtara n'ihi na nke ahụ ga-ebugharị ọdịnaya (agbatị) O nweghi ike ikwe [`push`][Vec::push], nke nwere ike ịhazigharị ya ma mekwaa ọdịnaya ahụ.
//!
//! [`Vec<T>`] na-enweghị pinning ụdị nwere ike `impl<T> Unpin for Vec<T>`, n'ihi na anaghị atụnye ọdịnaya ahụ na [`Vec<T>`] n'onwe ya dị mma na a na-akwagharị ya.
//! N'oge ahụ pinning enweghị mmetụta ọ bụla na vector ma ọlị.
//!
//! Na ọkọlọtọ Ọbá akwụkwọ, pointer ụdị n'ozuzu enweghị bughi pinning, ma si otú ha na-adịghị na-enye pinning projections.Nke a bụ ihe kpatara `Box<T>: Unpin` ji jide `T` niile.
//! Ọ bụ ihe ezi uche dị na ịme nke a maka ụdị pointer, n'ihi na ịgagharị `Box<T>` anaghị emegharị `T` ahụ: [`Box<T>`] nwere ike ibugharị kpamkpam (aka `Unpin`) ọbụlagodi na `T` abụghị.N'ezie, ọbụna ['Pin`]' <'[' Box`] '<T>> ``na ['' Pin`] `<&mut T>` bụ mgbe niile [`Unpin`] onwe ha, maka otu ihe kpatara ya: a na-atụnye ọdịnaya ha (`T`), mana ha nwere ike ịmegharị onwe ha na-enweghị ebugharị data ahụ ezubere.
//! N'ihi na ma [`Box<T>`] na ['Pin`]' <'[' Box`] '<T>>,, ma etinyere ọdịnaya ahụ kpamkpam ma ọ bụrụ na atụdoro pointer ahụ, nke pụtara na pinning abụghị * nhazi.
//!
//! Mgbe mejuputa atumatu a [`Future`] combinator, ị ga na-emekarị mkpa bughi pinning maka kpara akwụ futures, dị ka ị dị mkpa ka a pinned zoro aka ha na-akpọ [`poll`].
//! Mana ọ bụrụ na onye na-emekọ ihe gị nwere data ọ bụla ọzọ ekwesighi ịpinye, ị nwere ike ime ka mpaghara ndị ahụ ghara ịhazi ma si otú a jiri ha nweta ihe ederede na-agbanwe agbanwe ọbụlagodi mgbe ị nwere [`Pin`]`<&mut Self>`` dị ka gị onwe gị na [`poll`] mmejuputa).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// A pinned pointer.
///
/// Nke a bụ ihe mkpuchi gburugburu ụdị pointer nke na-eme pointer "pin" ahụ uru ọ bara, na-egbochi uru akpọtụrụ pointer a na-ebugharị ọ gwụla ma ọ na-etinye [`Unpin`] n'ọrụ.
///
///
/// *Hụ akwụkwọ [`pin` module] maka nkọwa nke pinning.*
///
/// [`pin` module]: self
///
// Note: `Clone` enwetara n'okpuru na-akpata unsoundness dị ka ọ bụ omume na-emejuputa
// `Clone` maka ederede mgbanwe.
// Hụ <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> maka nkọwa ndị ọzọ.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Emeghị mmejuputa iwu ndị a iji zere nsogbu dị mma.
// `&self.pointer` ekwesịghị inweta untrusted trait implementations.
//
// Hụ <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> maka nkọwa ndị ọzọ.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Rụọ `Pin<P>` ọhụrụ gburugburu pointer na ụfọdụ data nke ụdị nke na-eme [`Unpin`].
    ///
    /// N'adịghị ka `Pin::new_unchecked`, usoro a dị mma n'ihi na ihe ngosi `P` dere banyere ụdị [`Unpin`], nke na-akagbu ntụtụ nkwa.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // NCHEKWA: uru kwuru bụ `Unpin`, na ọ dịghị ihe a chọrọ
        // gburugburu pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps a `Pin<P>` alọta isi pointer.
    ///
    /// Nke a chọrọ ka data dị n`ime `Pin` a bụ [`Unpin`] ka anyị nwee ike ileghara ndị na-atụdo pinning anya mgbe anyị na-ewepụ ya.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Rụọ `Pin<P>` ọhụrụ maka ntụaka ụfọdụ data nke ụdị nke nwere ike ma ọ bụ enweghị ike mejuputa `Unpin`.
    ///
    /// Ọ bụrụ na `pointer` dere na ụdị `Unpin`, a ga-eji `Pin::new` mee ihe.
    ///
    /// # Safety
    ///
    /// Onye na-ewu ihe a enweghị nchekwa n'ihi na anyị enweghị ike ịkwado na data ejiri `pointer` rụtụ aka, nke pụtara na data agaghị ebugharị ma ọ bụ na echekwaghị nchekwa ya ruo mgbe ọ ga-adaba.
    /// Ọ bụrụ na ndị wuru `Pin<P>` anaghị ekwe nkwa ido na data `P` isi ka na-pinned, nke ahụ bụ a mebiri nke API nkwekọrịta na pụrụ iduga undefined agwa na mgbe e mesịrị (safe) arụmọrụ.
    ///
    /// Site n'iji usoro a, ị na-eme promise banyere mmejuputa `P::Deref` na `P::DerefMut`, ọ bụrụ na ha dị.
    /// Ọtụtụ ihe, ha ga-adịghị akpali ha `self` arụmụka: `Pin::as_mut` na `Pin::as_ref` ga-akpọ `DerefMut::deref_mut` na `Deref::deref`*na pinned pointer* na-atụ anya na ndị a ụzọ na-akwalite pinning invariants.
    /// Ọzọkwa, site na-akpọ usoro a ị promise na akwụkwọ `P` dereferences ka gaghị kwapụrụ ọzọ;Karịsịa, ọ gaghị ekwe omume ịnweta `&mut P::Target` wee pụọ na ntụaka ahụ (iji, dịka ọmụmaatụ [`mem::swap`]).
    ///
    ///
    /// Dịka ọmụmaatụ, ịkpọ `Pin::new_unchecked` na `&'a mut T` enweghị mmerụ ahụ n'ihi na ebe ị nwere ike ịpịnye ya maka oge ndụ `'a` niile, ị nweghị ikike ijikwa ma edobere ya ozugbo `'a` kwụsịrị:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Nke a kwesiri ịpụta `a` pointee enweghị ike imegharị ọzọ.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adreesị nke `a` gbanwere na oghere nchịkọta b, yabụ `a` kpaliri n'agbanyeghị na anyị etinyego ya na mbụ!Anyị emebila nkwekọrịta pinning API.
    /////
    /// }
    /// ```
    ///
    /// A uru, ozugbo pinned, ga-anọgide na-pinned ruo mgbe ebighị ebi (ma ụdị ya na-emejuputa `Unpin`).
    ///
    /// N'otu aka ahụ, ịkpọ `Pin::new_unchecked` na `Rc<T>` enweghị mmerụ ahụ n'ihi na enwere ike ịnwe aha ọzọ na otu data ahụ na-agbasaghị na mgbochi mgbochi.
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Nke a ga-apụta na pointee nwere ike mgbe akpali ọzọ.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ugbu a, ọ bụrụ na `x` bụ naanị ntụnye, anyị nwere ntụgharị ntụgharị maka data anyị tụbara n'elu, nke anyị nwere ike iji mee ka ọ dị ka anyị hụla na ihe atụ gara aga.
    ///     // Anyị emebila nkwekọrịta pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Alụta a pinned akọrọ akwụkwọ a pinned pointer.
    ///
    /// Nke a bụ a ọnyà usoro aga site `&Pin<Pointer<T>>` ka `Pin<&T>`.
    /// Ọ dị mma n'ihi na, dịka akụkụ nke nkwekọrịta nke `Pin::new_unchecked`, onye ọrụ pointee enweghị ike ịkwaga mgbe emechara `Pin<Pointer<T>>`.
    ///
    /// "Malicious" mmejuputa iwu nke `Pointer::Deref` bu ihe ndi mmadu chụpụrụ site na nkwekọrịta nke `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: lee akwukwo na oru a
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps a `Pin<P>` alọta isi pointer.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo.Ị ga-ekwe nkwa na ị ga-anọgide na-emeso pointer `P` ka pinned mgbe ị na-akpọ ọrụ a, nke mere na invariants na `Pin` ụdị nwere ike kwadoro.
    /// Ọ bụrụ na koodu iji dapụtara `P` anaghị anọgide na-enwe na pinning invariants na bụ a mebiri nke API nkwekọrịta na pụrụ iduga undefined agwa na mgbe e mesịrị (safe) arụmọrụ.
    ///
    ///
    /// Ọ bụrụ na data dị n'okpuru bụ [`Unpin`], a ga-eji [`Pin::into_inner`] mee ihe.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Na-enweta akara aka na-atụgharị atụ.
    ///
    /// Nke a bụ usoro ọnụọgụ iji si `&mut Pin<Pointer<T>>` gaa `Pin<&mut T>`.
    /// Ọ dị mma n'ihi na, dịka akụkụ nke nkwekọrịta nke `Pin::new_unchecked`, onye ọrụ pointee enweghị ike ịkwaga mgbe emechara `Pin<Pointer<T>>`.
    ///
    /// "Malicious" mmejuputa iwu nke `Pointer::DerefMut` bu ihe ndi mmadu chụpụrụ site na nkwekọrịta nke `Pin::new_unchecked`.
    ///
    /// Usoro a bụ uru mgbe eme multiple oku na ọrụ na-eri ihe na pinned ụdị.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // mee ihe
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` na-erepịa `self`, yabụ weghachite `Pin<&mut Self>` site na `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: lee akwukwo na oru a
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Edebe a ọhụrụ uru na ebe nchekwa n'azụ pinned akwụkwọ.
    ///
    /// Nke a overwrites na-edekọ data, mana nke ahụ dị mma: onye na-ebibi ya na-agba ọsọ tupu edegharị ya, yabụ na-agbanyeghị nkwa pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Chepụtara a ọhụrụ pin site nkewa ime uru.
    ///
    /// Ka ihe atụ, ọ bụrụ na ị chọrọ a `Pin` nke a ubi nke ihe, ị pụrụ iji nke a ka ịnweta na ubi na otu akara nke koodu.
    /// Agbanyeghị, enwere ọtụtụ gotchas na "pinning projections" ndị a;
    /// lee akwukwo [`pin` module] maka inweta ihe ndi ozo n`isiokwu a.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo.
    /// Must gha ekwenye na data ị weghachiri agaghị agagharị ma ọ bụrụhaala na arụmụka anaghị arụ ọrụ (dịka ọmụmaatụ, n'ihi na ọ bụ otu mpaghara nke uru ahụ), yana ị gaghị apụ na esemokwu ị nwetara ọrụ dị n'ime.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: nkwekọrịta nchekwa maka `new_unchecked` ga-abụrịrị
        // kwadoro site na nke bere.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Nweta otu ntụpọ site na ntụtụ.
    ///
    /// Nke a dị mma n'ihi na ọ gaghị ekwe omume ị wepu aka na ederede aha.
    /// Ọ nwere ike ịdị ka enwere esemokwu ebe a na ngbanwe dị n'ime: n'eziokwu, ọ * ga-ekwe omume ịmegharị `T` na `&RefCell<T>`.
    /// Otú ọ dị, nke a abụghị nsogbu dị ebe ọ na-adịghị na-adị a `Pin<&T>` arutu aka na otu data, na `RefCell<T>` anaghị ekwe ka ị na-ike a pinned banyere n'ime ya.
    ///
    /// Lee mkparịta ụka na ["pinning projections"] maka nkọwa ndị ọzọ.
    ///
    /// Note: `Pin` na-etinye `Deref` n'ọrụ na ebumnuche, enwere ike iji ya nweta uru dị n'ime.
    /// Agbanyeghị, `Deref` na-enye naanị ntụaka nke na-adị ndụ ogologo oge mgbazinye ego nke `Pin`, ọ bụghị ndụ nke `Pin` n'onwe ya.
    /// Usoro a na-enye ohere ịtụgharị `Pin` ka ọ bụrụ nrụtụ aka n'otu ndụ dịka nke mbụ `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Atọgharị `Pin<&mut T>` a n'ime `Pin<&T>` na ndụ niile.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Akawanye a mutable akwụkwọ na data n'ime nke a `Pin`.
    ///
    /// Nke a chọrọ ka data dị n`ime `Pin` a bụ `Unpin`.
    ///
    /// Note: `Pin` nwekwara implements `DerefMut` na data, nke nwere ike iji ohere n'ime uru.
    /// Agbanyeghị, `DerefMut` na-enye naanị ntụaka nke na-adị ndụ ogologo oge mgbazinye ego nke `Pin`, ọ bụghị ndụ nke `Pin` n'onwe ya.
    ///
    /// Usoro a na-enye ohere ịtụgharị `Pin` ka ọ bụrụ nrụtụ aka n'otu ndụ dịka nke mbụ `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Akawanye a mutable akwụkwọ na data n'ime nke a `Pin`.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo.
    /// Must gha ekwenye na ị gaghị ebugharị data ahụ site na ntụgharị ntụgharị ị na-enweta mgbe ị kpọrọ ọrụ a, ka enwere ike ịkwado ndị na-adịghị agbanwe agbanwe na ụdị `Pin`.
    ///
    ///
    /// Ọ bụrụ na data dị n'okpuru bụ `Unpin`, a ga-eji `Pin::get_mut` mee ihe.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Rụọ ntụtụ ọhụrụ site na ịdepụta uru dị n'ime.
    ///
    /// Ka ihe atụ, ọ bụrụ na ị chọrọ a `Pin` nke a ubi nke ihe, ị pụrụ iji nke a ka ịnweta na ubi na otu akara nke koodu.
    /// Agbanyeghị, enwere ọtụtụ gotchas na "pinning projections" ndị a;
    /// lee akwukwo [`pin` module] maka inweta ihe ndi ozo n`isiokwu a.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo.
    /// Must gha ekwenye na data ị weghachiri agaghị agagharị ma ọ bụrụhaala na arụmụka anaghị arụ ọrụ (dịka ọmụmaatụ, n'ihi na ọ bụ otu mpaghara nke uru ahụ), yana ị gaghị apụ na esemokwu ị nwetara ọrụ dị n'ime.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: onye na-akpọ oku nwere ọrụ maka ịghara imegharị ya
        // uru nke ederede a.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: dika uru nke `this` ka ekweghi nkwa inwe
        // ebupụla, oku a na `new_unchecked` dị nchebe.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Nweta akara ntụtụ site na ntụgharị ederede.
    ///
    /// Nke a bụ nchebe, n'ihi na `T` na-biiri maka `'static` ndụ, nke mgbe mechie.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: The 'static gbaziri na-emesi data agaghị adị
        // moved/invalidated ruo mgbe ọ na-ada (nke bụ mgbe).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Nweta ntụgharị mkpụrụ edemede na-atụgharị atụ.
    ///
    /// Nke a bụ nchebe, n'ihi na `T` na-biiri maka `'static` ndụ, nke mgbe mechie.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: The 'static gbaziri na-emesi data agaghị adị
        // moved/invalidated ruo mgbe ọ na-ada (nke bụ mgbe).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: nke a pụtara na ihe ọ bụla nke `CoerceUnsized` nke na-enye ohere ịmanye site
// ụdị nke na-akpali `Deref<Target=impl !Unpin>` n'ụdị na-akpali `Deref<Target=Unpin>` adịghị ama ụda.
// Ọ bụla dị otú impl ga-eleghị anya amamihe na-adịghị n'ihi ihe ndị ọzọ, ha na ya na anyị dị nnọọ mkpa na-elekọta ọ ghara ikwe ka ndị dị otú ahụ impls ka ala std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}