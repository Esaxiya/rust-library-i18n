//! The `Default` trait maka ụdị nke nwere ike bara uru ndabere ụkpụrụ.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait maka inye a ụdị a bara uru ndabere uru.
///
/// Mgbe ụfọdụ, ị chọrọ onye ga-azụ na ụdị ụfọdụ nke ndabere uru, na adịghị karịsịa ịma ihe ọ bụ.
/// Nke a na-abịa elu mgbe mgbe na 'struct`s na kọwaa a set of nhọrọ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Olee otú anyị pụrụ isi kọwaa ụfọdụ ndabere ụkpụrụ?Nwere ike iji `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Ugbu a, ị na-niile nke ndabara ụkpụrụ.Rust implements `Default` maka iche iche primitives ụdị.
///
/// Y`oburu n`ichoo igbari otu nhọrọ, mana ka ijide udiri iwu ndị ọzọ:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Nke a trait ike ga-eji na `#[derive]` ma ọ bụrụ na niile nke ụdị ubi mejuputa `Default`.
/// Mgbe 'derive`d, ọ ga-eji ndabara uru maka onye ọ bụla ubi si ụdị.
///
/// ## Kedụ ka m ga-esi mejuputa `Default`?
///
/// Nye usoro maka usoro `default()` nke na-eweghachi uru nke ụdị gị kwesịrị ịbụ ndabara:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// - Alaghachi na "default value" maka a ụdị.
    ///
    /// Kpụrụ ndabara na-abụkarị ụdị nke uru mbụ, uru njirimara, ma ọ bụ ihe ọ bụla ọzọ nwere ike ịme ka ọ bụrụ ndabara.
    ///
    ///
    /// # Examples
    ///
    /// Iji wuru na-ndabere ụkpụrụ:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Na-eme nke gị:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Weghachite uru ndabara nke ụdị dịka `Default` trait.
///
/// The ụdị na nloghachi na-inferred si gburugburu ya;a bụ Ẹkot `Default::default()` ma mkpumkpu na ụdị.
///
/// Ọmụmaatụ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Nweta macro na-ewepụta ihe nke trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }