// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Agbagharị nso `[mid-left, mid+right)` dị otú ahụ na mmewere na `mid` aghọ mbụ mmewere.Equivalently, agbagharị nso `left` ọcha na-ekpe ma ọ bụ `right` ọcha nri.
///
/// # Safety
///
/// Oke a kapịrị ọnụ ga-adị ire maka ịgụ na ide.
///
/// # Algorithm
///
/// A na-eji algorithm 1 eme ihe maka obere ụkpụrụ nke `left + right` ma ọ bụ maka nnukwu `T`.
/// The ọcha na-kwagara n'ime ha ikpeazụ ọnọdụ otu otu amalite na `mid - left` na-aga n'ihu site `right` nzọụkwụ modulo `left + right`, dị otú ahụ na onye na-adịru nwa oge na-mkpa.
/// N'ikpeazụ, anyị na-abata azụ na `mid - left`.
/// Otú ọ dị, ọ bụrụ na `gcd(left + right, right)` bụghị 1, n'elu nzọụkwụ ọsọsọp n'elu ọcha.
/// Ọmụmaatụ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ọ dabara nke ọma, ọnụọgụ nke ihe ndị mejupụtara n'etiti ihe ndị emechara emecha na-abụkarị nha, yabụ na anyị nwere ike iwepụ ọnọdụ mmalite anyị ma mee ọtụtụ gburugburu (ọnụ ọgụgụ nke gburugburu bụ `gcd(left + right, right)` value).
///
/// Nsonaazụ nsonaazụ bụ na emechara ihe niile otu ugboro.
///
/// A na-eji algorithm 2 eme ihe ma ọ bụrụ na `left + right` buru ibu mana `min(left, right)` pere mpe iji dabaa ebe nchekwa.
/// Ejiri ihe `min(left, right)` depụtaghachi na nchekwa ahụ, a na-etinye `memmove` n'ọrụ na ndị ọzọ, a na-akpọghachi ndị na nchekwa ahụ n'ime oghere dị n'akụkụ ọzọ nke ebe ha si malite.
///
/// Algọridim na ike ga-vectorized outperform n'elu ozugbo `left + right`-aghọ nnukwu ezuru.
/// Enwere ike iwepụta algorithm 1 site na ịpị na ịme ọtụtụ agba n'otu oge, mana enwere agba ole na ole na nkezi ruo mgbe `left + right` dị oke, yana okwu kachasị njọ nke otu gburugburu dị mgbe niile.
/// Kama nke ahụ, algorithm 3 jiri swapping ugboro ugboro nke ihe `min(left, right)` ruo mgbe nsogbu obere ntụgharị ga-ahapụ.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// mgbe `left < right` na swapping na-eme site n'aka ekpe kama.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algorithms dị n'okpuru nwere ike ịda ma ọ bụrụ na anaghị enyocha okwu ndị a
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algọridim 1 Microbenchmarks na-egosi na nkezi arụmọrụ maka usoro mgbanwe na-akawanye mma ruo mgbe ihe dị ka `left + right == 32`, mana ọrụ kachasị njọ na-agbaji ọbụlagodi 16.
            // Họọrọ 24 ka ọ bụrụ etiti.
            // Ọ bụrụ nha `T` buru ibu karịa 4 ``usize`s, algorithm a na-akarịkwa algorithms ndị ọzọ.
            //
            //
            let x = unsafe { mid.sub(left) };
            // mbido nke mbụ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` Enwere ike ịchọta tupu aka site na ịgbakọ `gcd(left + right, right)`, mana ọ bụ ngwa ngwa ịme otu akaghị nke na-agbakọ gcd dị ka mmetụta dị n'akụkụ, wee mee ihe ndị ọzọ
            //
            //
            let mut gcd = right;
            // benchmarks na-ekpughe na ọ bụ ngwa ngwa gbanwee temporaries ụzọ niile site kama na-agụ otu nwa oge otu ugboro, na-edegharị azu azu, na mgbe ahụ na-ede na-adịru nwa oge na nnọọ ọgwụgwụ.
            // Nke a bụ ikekwe n'ihi na eziokwu na swapping ma ọ bụ dochie temporaries eji naanị otu ebe nchekwa address na akaghị kama mkpa jikwaa abụọ.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // kama ịbawanye `i` wee chọpụta ma ọ bụrụ na ọ dị n'èzí, anyị na-elele ma ọ bụrụ na `i` ga-aga na mpụga oke na mgbakwunye na-esote.
                // Nke a na-egbochi ntinye akwụkwọ ma ọ bụ `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // njedebe nke agba nke mbụ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ọnọdụ a ga-adị ebe a ma ọ bụrụ `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // mechaa chunk ahụ na ihe ndị ọzọ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` abụghị ụdị nke ụdị efu, yabụ ọ dị mma ịkekọrịta site nha ya.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algọridim 2 The `[T; 0]` ebe a bụ iji hụ na nke a kwesịrị ekwesị kwekọọ maka T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algọridim 3 E nwere ụzọ ọzọ nke swapping na-agụnye achọta ebe ikpeazụ gbanwee nke a algọridim ga-abụ, na swapping iji nke ikpeazụ mmaji kama swapping n'akụkụ chunks dị ka nke a algọridim na-eme, ma a ụzọ ka ngwa ngwa.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algọridim 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}