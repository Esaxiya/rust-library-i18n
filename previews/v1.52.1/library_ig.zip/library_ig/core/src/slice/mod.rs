// ignore-tidy-filelength

//! Ibe iberibe na njikwa.
//!
//! Maka nkọwa ndị ọzọ lee [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Dị ọcha rust memchr mmejuputa, weputara na rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ọrụ a bụ nke ọha naanị n'ihi na ọ nweghị ụzọ ọzọ ị ga-esi tulee ebe obibi.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Weghachite ọnụ ọgụgụ nke ndị ọcha na iberi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: const ụda n'ihi na anyị na-transmute si ogologo ubi ka a were (nke ọ ga-abụ)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // NCHEKWA: a bụ nchebe n'ihi na `&[T]` na `FatPtr<T>` nwere otu nhọrọ.
            // Naanị `std` nwere ike ime nkwa a.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Dochie anya na `crate::ptr::metadata(self)` mgbe nke ahụ guzosiri ike.
            // Dịka ederede a, nke a na-akpata njehie "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Accessnweta uru site na njikọ `PtrRepr` dị mma ebe ọ bụ na * const T
            // na PtrComponents<T>nwee nhazi nchekwa otu ihe ahụ.
            // Naanị std nwere ike ime nkwa a.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Weghachi `true` ma ọ bụrụ na iberi nwere ogologo nke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Weghachite ihe mbu nke iberi, ma ọ bụ `None` ma ọ bụrụ na ọ tọgbọ chakoo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Weghachite pointer na-agbanwe agbanwe na ihe izizi nke iberi ahụ, ma ọ bụ `None` ma ọ bụrụ na ọ tọgbọ chakoo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Alaghachi ndị mbụ na ndị ọzọ nile dị n'eluigwe na ụwa nke iberi, ma ọ bụ `None` ọ bụrụ na ọ bụ ihe efu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Alaghachi ndị mbụ na ndị ọzọ nile dị n'eluigwe na ụwa nke iberi, ma ọ bụ `None` ọ bụrụ na ọ bụ ihe efu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Alaghachi ikpeazụ na ndị niile ọzọ nke ndị ọcha nke iberi, ma ọ bụ `None` ọ bụrụ na ọ bụ ihe efu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Alaghachi ikpeazụ na ndị niile ọzọ nke ndị ọcha nke iberi, ma ọ bụ `None` ọ bụrụ na ọ bụ ihe efu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Alaghachi ikpeazụ mmewere nke iberi, ma ọ bụ `None` ma ọ bụrụ na ọ bụ ihe efu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Alaghachi a mutable pointer ikpeazụ ihe na iberi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Alaghachi a banyere ihe mmewere ma ọ bụ subslice dabere na ụdị nke index.
    ///
    /// - Ọ bụrụ na e nyere a ọnọdụ, laghachi a banyere mmewere na na ọnọdụ ma ọ bụ `None` ma ọ bụrụ na nke ókè.
    ///
    /// - Ọ bụrụ na-enye a nso, laghachi subslice kwekọrọ na nso, ma ọ bụ `None` ma ọ bụrụ na nke ókè.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Alaghachi a mutable banyere ihe mmewere ma ọ bụ subslice dabere na ụdị nke index (lee [`get`]) ma ọ bụ `None` ma ọ bụrụ na index bụ nke ókè.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Weghachite nrụtụ aka maka mmewere ma ọ bụ ntinye, na-enweghị nyocha oke.
    ///
    /// Maka nchekwa ọzọ lee [`get`].
    ///
    /// # Safety
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke bụ *[omume a na-akọwaghị agwa]* ọbụlagodi na ejighị ntụzị aka rụpụtara.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // MGBE: onye na-akpọ oku ga-agbachitere ọtụtụ ihe nchekwa maka `get_unchecked`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Laghachi a mutable akwụkwọ na ihe mmewere ma ọ bụ subslice, na-enweghị na-eme ókè ịlele.
    ///
    /// N'ihi na a mma ọzọ ahụ [`get_mut`].
    ///
    /// # Safety
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke bụ *[omume a na-akọwaghị agwa]* ọbụlagodi na ejighị ntụzị aka rụpụtara.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // MGBE: onye na-akpọ oku ga-akwado ihe nchekwa maka `get_unchecked_mut`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Weghachite pointer raw na mpempe akwụkwọ.
    ///
    /// Onye na-akpọ oku ga-agba mbọ hụ na mpempe akwụkwọ ahụ gafere ihe nrụrụ ọrụ a laghachiri, ma ọ bụghị ya, ọ ga-ejedebe na-arụtụ aka na mkpofu.
    ///
    /// Onye na-akpọ oku ga-ekwenyekwa na ncheta ihe (non-transitively) pointer na-atụtụghị ede (ma e wezụga n'ime `UnsafeCell`) na-eji pointer a ma ọ bụ ihe ọ bụla na-esite na ya.
    /// Ọ bụrụ n`ịchọrọ ịtụgharị ọdịnaya nke iberi ahụ, jiri [`as_mut_ptr`].
    ///
    /// Imezigharị akpa ahụ nke iberi a zoro aka na ya nwere ike ime ka emegharị ya, nke ga-emekwa ka akara ngosi ọ bụla ghara ịdị irè.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Weghachite pointer na-adịghị ize ndụ na-echekwa na mpempe akwụkwọ.
    ///
    /// Onye na-akpọ oku ga-agba mbọ hụ na mpempe akwụkwọ ahụ gafere ihe nrụrụ ọrụ a laghachiri, ma ọ bụghị ya, ọ ga-ejedebe na-arụtụ aka na mkpofu.
    ///
    /// Imezigharị akpa ahụ nke iberi a zoro aka na ya nwere ike ime ka emegharị ya, nke ga-emekwa ka akara ngosi ọ bụla ghara ịdị irè.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Alaghachi abụọ raw pointers onwere iberi.
    ///
    /// The laghachi nso bụ ọkara oghe, nke pụtara na ọgwụgwụ pointer ihe otu gara aga * ikpeazụ mmewere nke iberi.
    /// Thiszọ a, ihe iberibe ihe efu na-anọchi anya ntụpọ abụọ, ihe dị iche na etiti abụọ na-anọchi anya nha iberi ahụ.
    ///
    /// Hụ [`as_ptr`] maka ịdọ aka na ntị n'iji ntụpọ ndị a.Ọgwụgwụ pointer achọ mmezi ịkpachara anya, dị ka ọ na-adịghị na-ezo aka a nti mmewere na iberi.
    ///
    /// Nke a ọrụ bụ bara uru n'ihi na mmekọrịta na mba ọzọ ihu nke na-eji abụọ pointers na-ezo aka a nso nke ọcha na ebe nchekwa, dị ka a na-efekarị C++ .
    ///
    ///
    /// Ọ nwekwara ike ịbụ bara uru iji lelee ma ọ bụrụ na a pointer ka ihe mmewere na-ezo aka ihe mmewere nke a iberi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // NCHEKWA: The `add` ebe a bụ nchebe, n'ihi na:
        //
        //   - Ihe abuo abuo bu otu ihe, dika na-egosi ihe kariri ihe a.
        //
        //   - Ogo nke iberi ahụ ebughi ibu karịa isize::MAX bytes, dịka e kwuru ebe a:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Enweghị ihe ọ bụla na-emetụta ya, dịka mpekere anaghị agabiga na njedebe nke oghere adreesị.
        //
        // Hụ akwụkwọ nke pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Alaghachi abụọ nwedịrị ike ịta mutable pointers onwere iberi.
    ///
    /// The laghachi nso bụ ọkara oghe, nke pụtara na ọgwụgwụ pointer ihe otu gara aga * ikpeazụ mmewere nke iberi.
    /// Thiszọ a, ihe iberibe ihe efu na-anọchi anya ntụpọ abụọ, ihe dị iche na etiti abụọ na-anọchi anya nha iberi ahụ.
    ///
    /// Hụ [`as_mut_ptr`] maka ịdọ aka na ntị n'iji ntụpọ ndị a.
    /// Ọgwụgwụ pointer achọ mmezi ịkpachara anya, dị ka ọ na-adịghị na-ezo aka a nti mmewere na iberi.
    ///
    /// Nke a ọrụ bụ bara uru n'ihi na mmekọrịta na mba ọzọ ihu nke na-eji abụọ pointers na-ezo aka a nso nke ọcha na ebe nchekwa, dị ka a na-efekarị C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // NCHEKWA: Lee as_ptr_range() n'elu maka mere `add` ebe a bụ nchebe.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Gbanwee ihe abuo na iberi.
    ///
    /// # Arguments
    ///
    /// * a, The index nke mbụ mmewere
    /// * b, ndeksi nke abuo
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `a` ma ọ bụ `b` bụ nke ókè.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Enweghi ike iwere mgbazinye ego abụọ sitere na vector, yabụ jiri akara ntụ were.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // NCHEKWA: `pa` na `pb` na e kere si mma mutable zoro na-ezo
        // ka ọcha na iberi na Ya mere na-ekwe nkwa ga-nti na kwekọọ.
        // Rịba ama na ịnweta ihe ndị dị n'azụ `a` na `b` na-enyocha ma ga-panic mgbe enweghị oke.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Na-agbanwe usoro nke ihe dị na iberi ahụ, n'ọnọdụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // N'ihi na dị nnọọ obere ụdị, ihe niile na onye na-agụ, na nkịtị ụzọ ịrụ-agụghị oké.
        // Anyị nwere ike ịme nke ọma, nyere load/store adabaghị nke ọma, site na itinye nnukwu ibu ma weghachite ndekọ.
        //

        // O doro anya na LLVM ga-eme nke a maka anyị, ebe ọ maara nke ọma karịa ka anyị na-eme ma ndị na-agụghị akwụkwọ na-arụ ọrụ nke ọma (ebe ọ bụ na mgbanwe ahụ dị n'etiti ụdị ARM dị iche iche, dịka ọmụmaatụ) na ihe nha kacha mma ga-abụ.
        // N'ụzọ dị mwute, nke LLVM 4.0 (2017-05) ya naanị unrolls akaghị, otú ahụ ka anyị kwesịrị ime nke a anyị onwe anyị.
        // (Amụma: reverse bụ na-eweta nsogbu n'ihi n'akụkụ nwere ike kwekọọ dị iche iche-ga-abụ, mgbe ogologo bụ onye iberibe-ya mere e nweghị ụzọ nke emitting pre-na postludes iji n'ụzọ zuru ezu-kwekọọ SIMD n'etiti.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Jiri llvm.bswap intrinsic weghachite u8s na usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Enwere ọtụtụ ihe ịlele ebe a:
                //
                // - Rịba ama na `chunk` bụ 4 ma ọ bụ 8 n'ihi cfg ego dị n'elu.Yabụ `chunk - 1` dị mma.
                // - Indexing na index `i` dị mma dị ka akaghị ego di
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexing na ndeksi `ln - i - chunk = ln - (i + chunk)` di nma:
                //   - `i + chunk > 0` bụ eziokwu n'ụzọ efu.
                //   - Mkpịsị aka aka na-emesi obi ike:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, si otú mwepu adịghị underflow.
                // - Oku `read_unaligned` na `write_unaligned` di nma:
                //   - `pa` na-ezo aka na `i` ebe `i < ln / 2 - (chunk - 1)` (lee n'elu) na `pb` na-ezo aka na `ln - i - chunk`, yabụ ha abụọ dịkarịa ala `chunk` ọtụtụ bytes pụọ na njedebe nke `self`.
                //
                //   - Ihe ncheta obula bu `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Jiri ntụgharị site-16 tụgharịa u16s na u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: u32 a na-ahaghị aka nwere ike ịgụ site na `i` ma ọ bụrụ na `i + 1 < ln`
                // (na o doro anya na `i < ln`), n'ihi na ihe ọ bụla bụ 2 bytes na anyị na-agụ 4.
                //
                // `i + chunk - 1 < ln / 2` # mgbe ọnọdụ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ebe ọ bụ na o pere mpe karịa ogologo nke 2 kewara, mgbe ahụ ọ ga-agarịrị.
                //
                // Nke a pụtakwara na a na-akwanyere ọnọdụ `0 < i + chunk <= ln` ugwu mgbe niile, na-ahụ na enwere ike iji pointer `pb` mee ihe n'enweghị nsogbu.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` dị ala karịa ọkara ogologo ogologo nke iberi ahụ
            // ịnweta `i` na `ln - i - 1` dị mma (`i` na-amalite na 0 ma ọ gaghị aga karịa `ln / 2 - 1`).
            // Ihe nchoputa nke `pa` na `pb` rụpụtara dabara adaba ma kwekọọ, enwere ike ịgụ ya ma degara ya ya.
            //
            //
            unsafe {
                // Nwedịrị ike ịta gbanwee izere ókè elele ke mma gbanwee.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Weghachite onye na-ede akwụkwọ ihe maka iberi ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Weghachite ite ite na-enye ohere imezigharị uru ọ bụla.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Weghachite onye na-ede akwụkwọ ihe niile gbasara windows nke ogologo `size`.
    /// windows gbanwere.
    /// Ọ bụrụ na iberi bụ mkpumkpu karịa `size`, na iterator laghachi dịghị ụkpụrụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ọ bụrụ na iberi bụ mkpumkpu karịa `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// Ihe chunks bụ mpekere ma anaghị ekpuchi.Ọ bụrụ na `chunk_size` anaghị kee ogologo nke iberi, mgbe ikpeazụ mmaji ga-enweghị ogologo `chunk_size`.
    ///
    /// Lee [`chunks_exact`] maka a variant nke a iterator na-alaghachi chunks nke mgbe kpọmkwem `chunk_size` ọcha, na [`rchunks`] maka otu iterator ma malite na njedebe nke iberi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// Akụkụ ndị ahụ bụ mpekere na-agbanwe agbanwe, ha anaghị adịkwa.Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ ngwugwu ikpeazụ agaghị enwe `chunk_size` ogologo.
    ///
    /// Lee [`chunks_exact_mut`] maka a variant nke a iterator na-alaghachi chunks nke mgbe kpọmkwem `chunk_size` ọcha, na [`rchunks_mut`] maka otu iterator ma malite na njedebe nke iberi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// Ihe chunks bụ mpekere ma anaghị ekpuchi.
    /// Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `chunk_size-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `remainder` nke iterator.
    ///
    ///
    /// N'ihi nchịkọta ọ bụla nwere ihe `chunk_size` ziri ezi, onye na-achịkọta nwere ike ịkwalite koodu na-eweta nke ọma karịa nke [`chunks`].
    ///
    /// Lee [`chunks`] maka a variant nke a iterator na na-na-alaghachikwuru fọdụrụnụ ka a nta mmaji, na [`rchunks_exact`] maka otu iterator ma malite na njedebe nke iberi.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// Akụkụ ndị ahụ bụ mpekere na-agbanwe agbanwe, ha anaghị adịkwa.
    /// Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `chunk_size-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `into_remainder` nke iterator.
    ///
    ///
    /// N'ihi nchịkọta ọ bụla nwere ihe `chunk_size` ziri ezi, onye na-achịkọta nwere ike ịkwalite koodu na-eweta nke ọma karịa nke [`chunks_mut`].
    ///
    /// Lee [`chunks_mut`] maka a variant nke a iterator na na-na-alaghachikwuru fọdụrụnụ ka a nta mmaji, na [`rchunks_exact_mut`] maka otu iterator ma malite na njedebe nke iberi.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Na-ekewa iberi ahụ n'ime iberibe nke 'N`-element arrays, na-eche na ọ nweghị nke fọdụrụnụ.
    ///
    ///
    /// # Safety
    ///
    /// Enwere ike ịkpọ ya naanị mgbe
    /// - The iberi gbawara kpọmkwem n'ime 'N`-mmewere chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: 1 element element chunks never have fọdụrụ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // Nchekwa: ogologo iberi (6) bụ otutu nke 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ndị a ga-abụ amamihe na-adịghị:
    /// // ka chunks: &[[_;5]]= slice.as_chunks_unchecked()//The iberi ogologo bụ bụghị a multiple of 5 Ka chunks:&[[_;0]]= slice.as_chunks_unchecked()//A naghị ekwe ka okpueze ogologo ogologo
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ihe anyi choro bu ihe anyi choro iji kpo oku
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Anyị tụbara iberibe ihe `new_len * N`
        // iberi nke `new_len` otutu `N` element chunks.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Gbawara iberi n'ime a iberi nke 'N`-mmewere arrays, malite ná mmalite nke iberi, na a fọdụrụnụ iberi na ogologo nditịm erughị `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // NCHEKWA: Anyị na-ama mara jijiji maka efu, na mbo ihu site ewu
        // na ogologo nke subslice bu otutu nke N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Gbawara iberi n'ime a iberi nke 'N`-mmewere arrays, malite na ọgwụgwụ nke iberi, na a fọdụrụnụ iberi na ogologo nditịm erughị `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // NCHEKWA: Anyị na-ama mara jijiji maka efu, na mbo ihu site ewu
        // na ogologo nke subslice bu otutu nke N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `N` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// Ihe ndi ozo bu ederede ndi edere ma ha adighi adi.
    /// Ọ bụrụ na `N` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `N-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `remainder` nke iterator.
    ///
    ///
    /// Usoro a bụ ihe jikọtara ọnụ nke [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Na-ekewa iberi ahụ n'ime iberibe nke 'N`-element arrays, na-eche na ọ nweghị nke fọdụrụnụ.
    ///
    ///
    /// # Safety
    ///
    /// Enwere ike ịkpọ ya naanị mgbe
    /// - The iberi gbawara kpọmkwem n'ime 'N`-mmewere chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: 1 element element chunks never have fọdụrụ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // Nchekwa: ogologo iberi (6) bụ otutu nke 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ndị a ga-abụ amamihe na-adịghị:
    /// // ka chunks: &[[_;5]]= slice.as_chunks_unchecked_mut()//Mpekere ogologo bụghị a otutu nke 5 ka chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//A naghị ekwe ka okpueze ogologo ogologo
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ihe anyi choro bu ihe anyi choro iji kpo oku
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Anyị tụbara iberibe ihe `new_len * N`
        // iberi nke `new_len` otutu `N` element chunks.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Gbawara iberi n'ime a iberi nke 'N`-mmewere arrays, malite ná mmalite nke iberi, na a fọdụrụnụ iberi na ogologo nditịm erughị `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // NCHEKWA: Anyị na-ama mara jijiji maka efu, na mbo ihu site ewu
        // na ogologo nke subslice bu otutu nke N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Gbawara iberi n'ime a iberi nke 'N`-mmewere arrays, malite na ọgwụgwụ nke iberi, na a fọdụrụnụ iberi na ogologo nditịm erughị `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // NCHEKWA: Anyị na-ama mara jijiji maka efu, na mbo ihu site ewu
        // na ogologo nke subslice bu otutu nke N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `N` nke iberi ahụ n'otu oge, malite na mbido nke iberi ahụ.
    ///
    /// The chunks bụ mutable n'usoro zoro na-eme adịghị yitewere.
    /// Ọ bụrụ na `N` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `N-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `into_remainder` nke iterator.
    ///
    ///
    /// Usoro a bụ ihe jikọtara ọnụ nke [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0. Ọ ga-abụrịrị na a ga-agbanwe elele a ka ọ chịkọta njehie oge tupu usoro a emee ka ọ kwụsie ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Weghachite onye na-edegharị ihe n`elu windows nke ihe `N` nke iberi, na-amalite na mbido iberi ahụ.
    ///
    ///
    /// Nke a bụ njikọ ọnụ ọnụ nke [`windows`].
    ///
    /// Ọ bụrụ na `N` dị ukwuu karịa size nke iberi, ọ ga-alọta windows.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `N` bụ 0.
    /// A na ego ga-kasị eleghị anya na-gbanwere a ide oge njehie n'ihu usoro a ego n'anya Nọsi'ike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na ngwụcha nke iberi ahụ.
    ///
    /// Ihe chunks bụ mpekere ma anaghị ekpuchi.Ọ bụrụ na `chunk_size` anaghị kee ogologo nke iberi, mgbe ikpeazụ mmaji ga-enweghị ogologo `chunk_size`.
    ///
    /// Lee [`rchunks_exact`] maka a variant nke a iterator na-alaghachi chunks nke mgbe kpọmkwem `chunk_size` ọcha, na [`chunks`] maka otu iterator ma malite ná mmalite nke iberi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na ngwụcha nke iberi ahụ.
    ///
    /// Akụkụ ndị ahụ bụ mpekere na-agbanwe agbanwe, ha anaghị adịkwa.Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ ngwugwu ikpeazụ agaghị enwe `chunk_size` ogologo.
    ///
    /// Hụ [`rchunks_exact_mut`] maka ụdị dị iche iche nke ite ite a na-eweghachi obere nke ihe `chunk_size` oge niile, yana [`chunks_mut`] maka otu iterator mana ịmalite na mbido nke iberi ahụ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na ngwụcha nke iberi ahụ.
    ///
    /// Ihe chunks bụ mpekere ma anaghị ekpuchi.
    /// Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `chunk_size-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `remainder` nke iterator.
    ///
    /// N'ihi nchịkọta ọ bụla nwere ihe `chunk_size` ziri ezi, onye na-achịkọta nwere ike ịkwalite koodu na-eweta nke ọma karịa nke [`chunks`].
    ///
    /// Hụ [`rchunks`] maka ụdị dị iche iche nke onye na-ekwu okwu a na-eweghachi ihe fọdụrụnụ dị ka obere akụkụ, yana [`chunks_exact`] maka otu iterator mana ịmalite na mbido nke iberi ahụ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Weghachite onye na-ede akwụkwọ maka ihe `chunk_size` nke iberi ahụ n'otu oge, malite na ngwụcha nke iberi ahụ.
    ///
    /// Akụkụ ndị ahụ bụ mpekere na-agbanwe agbanwe, ha anaghị adịkwa.
    /// Ọ bụrụ na `chunk_size` anaghị ekewa ogologo nke iberi ahụ, mgbe ahụ, ihe ikpeazụ ruo ihe `chunk_size-1` ga-ewepụ ma nwee ike weghachite site na ọrụ `into_remainder` nke iterator.
    ///
    /// N'ihi nchịkọta ọ bụla nwere ihe `chunk_size` ziri ezi, onye na-achịkọta nwere ike ịkwalite koodu na-eweta nke ọma karịa nke [`chunks_mut`].
    ///
    /// Lee [`rchunks_mut`] maka a variant nke a iterator na na-na-alaghachikwuru fọdụrụnụ ka a nta mmaji, na [`chunks_exact_mut`] maka otu iterator ma malite ná mmalite nke iberi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `chunk_size` bụ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// O weghachitere onye na-ekwu okwu banyere iberi ahụ na-ewepụta ihe ndị na-abụghị nke overlapping site na iji amụma iji kewaa ha.
    ///
    /// The predicate a na-akpọ on ihe abụọ na-esonụ onwe ha, ọ pụtara na predicate a na-akpọ on `slice[0]` na `slice[1]` mgbe on `slice[1]` na `slice[2]` na na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Enwere ike iji usoro a wepu ahihia ahihia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Alaghachi ihe iterator n'elu iberi amị ndị na-abụghị overlapping mutable agbaba nke ọcha na-eji predicate-ekewa ha.
    ///
    /// The predicate a na-akpọ on ihe abụọ na-esonụ onwe ha, ọ pụtara na predicate a na-akpọ on `slice[0]` na `slice[1]` mgbe on `slice[1]` na `slice[2]` na na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Enwere ike iji usoro a wepu ahihia ahihia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// E kee otu iberi abụọ ụzọ abụọ.
    ///
    /// The mbụ ga-ebu niile indices si `[0, mid)` (ewepu na index `mid` n'onwe ya) na nke abụọ ga-ebu niile indices si `[mid, len)` (ewepu na index `len` onwe ya).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // NCHEKWA: `[ptr; mid]` na `[mid; len]` bụ n'ime, `self`, nke
        // mezuo ihe `from_raw_parts_mut` chọrọ.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Ekesa otu mutable ibe ya abuo na ndeksi.
    ///
    /// The mbụ ga-ebu niile indices si `[0, mid)` (ewepu na index `mid` n'onwe ya) na nke abụọ ga-ebu niile indices si `[mid, len)` (ewepu na index `len` onwe ya).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // NCHEKWA: `[ptr; mid]` na `[mid; len]` bụ n'ime, `self`, nke
        // mezuo ihe `from_raw_parts_mut` chọrọ.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Na-ekewa otu iberi abụọ na ndeksi, na-emeghị nyocha ọ bụla.
    ///
    /// The mbụ ga-ebu niile indices si `[0, mid)` (ewepu na index `mid` n'onwe ya) na nke abụọ ga-ebu niile indices si `[mid, len)` (ewepu na index `len` onwe ya).
    ///
    ///
    /// N'ihi na a mma ọzọ ahụ [`split_at`].
    ///
    /// # Safety
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke bụ *[omume a na-akọwaghị agwa]* ọbụlagodi na ejighị ntụzị aka rụpụtara.Onye na-akpọ oku kwesiri ijide n'aka na `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // NCHEKWA: bere nwere elele na `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Ekesa otu mutable iberi abụọ na ndeksi, na-enweghị na-eme ókè achọpụta.
    ///
    /// The mbụ ga-ebu niile indices si `[0, mid)` (ewepu na index `mid` n'onwe ya) na nke abụọ ga-ebu niile indices si `[mid, len)` (ewepu na index `len` onwe ya).
    ///
    ///
    /// Maka nchekwa ọzọ lee [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke bụ *[omume a na-akọwaghị agwa]* ọbụlagodi na ejighị ntụzị aka rụpụtara.Onye na-akpọ oku kwesiri ijide n'aka na `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: Onye na-akpọ oku ga-eleba anya na `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` na `[mid; len]` na-adịghị overlapping, otú na-alọta a mutable akwụkwọ dị mma.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Na-alaghachi onye na-eme itele na mkpụrụedemede ndị ekewapụrụ site na ihe ndị metụtara `pred`.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ọ bụrụ na ejiri ihe mbido kwekọrọ, iberi iberi ga-abụ ihe izizi nke iterator na-eweghachi.
    /// N'otu aka ahụ, ọ bụrụ na e mejupụtara akụkụ ikpeazụ na iberi ahụ, iberi ihe na-enweghị ihe ga-abụ ihe ikpeazụ nke onye na-agbapụta ya weghachiri:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ọ bụrụ na ihe abụọ ejikọtara dị n'akụkụ, a ga-enwe iberibe nzuzu n'etiti ha:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Alaghachi ihe iterator n'elu mutable subslices iche site na ihe na-dakọtara `pred`.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Na-alaghachi onye na-eme itele na mkpụrụedemede ndị ekewapụrụ site na ihe ndị metụtara `pred`.
    /// Ihe kwekọrọ ekwekọ dị na njedebe nke ntinye gara aga dị ka onye na-agwụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ọ bụrụ na akụkụ ikpeazụ nke iberi ahụ adakọ, a ga-atụle ihe ahụ ka ọ na-ewepu ibe ahụ.
    ///
    /// Mpekere ahụ ga-abụ ihe ikpeazụ onye edemede ahụ weghachiri.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Alaghachi ihe iterator n'elu mutable subslices iche site na ihe na-dakọtara `pred`.
    /// The ekwekọghị mmewere na ẹdude ke gara aga subslice ka a terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Alaghachi ihe iterator n'elu subslices iche site na ihe na-dakọtara `pred`, malite na ọgwụgwụ nke iberi na-arụ ọrụ azụ.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dị ka ọ dị na `split()`, ọ bụrụ na ihe mbụ ma ọ bụ nke ikpeazụ ga-ekwekọ, iberibe ihe efu ga-abụ ihe mbụ (ma ọ bụ nke ikpeazụ) nke onye nyocha ahụ weghachitere.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// O weghachitere onye na-ekwu okwu banyere ihe odide a na-agbanwe agbanwe site na ihe ndi dakọtara na `pred`, bido na ngwụcha nke iberi ahụ ma na-arụ ọrụ azụ.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// O weghachitere onye nkowa n`elu ihe odide nkewaputara site na ihe ndi metutara `pred`, gbachiri ighachi na ihe otutu `n`.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// Ikpeazụ mmewere laghachiri, ma ọ bụrụ na ọ bụla, ga-ebu nke fọdụrụnụ nke iberi.
    ///
    /// # Examples
    ///
    /// Bipụta iberi nkewa otu ugboro site na ọnụọgụ nke atọ (ntụgharị, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// O weghachitere onye nkowa n`elu ihe odide nkewaputara site na ihe ndi metutara `pred`, gbachiri ighachi na ihe otutu `n`.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// Ikpeazụ mmewere laghachiri, ma ọ bụrụ na ọ bụla, ga-ebu nke fọdụrụnụ nke iberi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// O weghachitere onye nkowa n`elu ihe odide nkewaputara site na ihe ndi metutara `pred` na alaghachi na otutu ihe `n`.
    /// Nke a na-amalite na ngwụcha nke iberi ahụ wee na-arụ ọrụ azụ.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// Ikpeazụ mmewere laghachiri, ma ọ bụrụ na ọ bụla, ga-ebu nke fọdụrụnụ nke iberi.
    ///
    /// # Examples
    ///
    /// Bipute iberi gbawara n'etiti ozugbo, malite na ọgwụgwụ, site nọmba divisible site 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// O weghachitere onye nkowa n`elu ihe odide nkewaputara site na ihe ndi metutara `pred` na alaghachi na otutu ihe `n`.
    /// Nke a na-amalite na ngwụcha nke iberi ahụ wee na-arụ ọrụ azụ.
    /// Ejikọtara mmewere adịghị na subslices.
    ///
    /// Ikpeazụ mmewere laghachiri, ma ọ bụrụ na ọ bụla, ga-ebu nke fọdụrụnụ nke iberi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Weghachi `true` ma ọ bụrụ na iberi nwere ihe mmewere na nyere uru.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ọ bụrụ na ịnweghị `&T`, mana naanị `&U` dị ka `T: Borrow<U>` (dịka
    /// 'Eriri: Borrow<str>``,, can nwere ike iji `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // iberi nke `String`
    /// assert!(v.iter().any(|e| e == "hello")); // chọọ `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Laghachi `true` ma ọ bụrụ na `needle` bụ nganiihu nke iberi ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Na-alaghachi `true` mgbe niile ma ọ bụrụ na `needle` bụ ihe efu:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Weghachi `true` ma ọ bụrụ na `needle` bụ suffix nke iberi ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Na-alaghachi `true` mgbe niile ma ọ bụrụ na `needle` bụ ihe efu:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Alaghachi a subslice na nganiihu wepụrụ.
    ///
    /// Ọ bụrụ na iberi amalite na `prefix`, laghachi na subslice mgbe nganiihu, ọbọp ke `Some`.
    /// Ọ bụrụ na `prefix` bụ ihe efu, nanị na-alaghachikwuru mbụ iberi.
    ///
    /// Ọ bụrụ na iberi amalite na `prefix`, laghachi `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ọrụ a ga-achọ idegharị ma ọ bụrụ na mgbe SlicePattern na-adịwanye nkọ.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Alaghachi a subslice na suffix wepụrụ.
    ///
    /// Ọ bụrụ na iberi ejedebe na `suffix`, laghachi subslice tupu suffix, ọbọp ke `Some`.
    /// Ọ bụrụ na `suffix` bụ efu, nanị laghachi mbụ iberi.
    ///
    /// Ọ bụrụ na iberi anaghị akwụsị na `suffix`, laghachi `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ọrụ a ga-achọ idegharị ma ọ bụrụ na mgbe SlicePattern na-adịwanye nkọ.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Ọnụọgụ abụọ na-enyocha a ota iberi n'ihi na a nyere mmewere.
    ///
    /// Ọ bụrụ na achọtara uru ahụ wee laghachi [`Result::Ok`], nwere ndeksi nke ihe ndabara.
    /// Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    ///
    /// Hụkwa [`binary_search_by`], [`binary_search_by_key`], na [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Na-achọ ihe anọ.
    /// A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ọ bụrụ na ị chọrọ itinye otu ihe ka a ota vector, mgbe nọgide na-enwe ụdị iji:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Ọnụọgụ abụọ searches a ota iberi na a comparator ọrụ.
    ///
    /// Ọrụ comparator kwesịrị imejuputa usoro iji usoro ụdị nke ihe a na-akpata, weghachite koodu na-egosi ma arụmụka ya bụ `Less`, `Equal` ma ọ bụ `Greater` ihe achọrọ.
    ///
    ///
    /// Ọ bụrụ na uru a na-hụrụ mgbe [`Result::Ok`] na-laghachi, nke nwere index nke kenha mmewere.Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    /// Hụkwa [`binary_search`], [`binary_search_by_key`], na [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Na-achọ ihe anọ.A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // OZI: a na-akpọ oku ndị a ka ha ghara ịda mbà:
            // - `mid >= 0`
            // - `mid < size`: `mid` a na-ejedebeghị `[left; right)` agbụ.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Ihe mere anyị ji jiri if/else akara eruba kama egwuregwu bụ n'ihi na egwuregwu reorders tụnyere arụmọrụ, nke bụ perf mmetụta ọsọ ọsọ.
            //
            // Nke a bụ x86 asm maka u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Ọnụọgụ abụọ searches a ota iberi na a isi mmịpụta ọrụ.
    ///
    /// Echere na igodo na-edozi isi site na igodo, dịka ọmụmaatụ na [`sort_by_key`] na-eji otu igodo ntinye ọrụ.
    ///
    /// Ọ bụrụ na achọtara uru ahụ wee laghachi [`Result::Ok`], nwere ndeksi nke ihe ndabara.
    /// Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    ///
    /// Hụkwa [`binary_search`], [`binary_search_by`], na [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Na-ele anya na usoro ihe anọ dị na mpempe abụọ nke abụọ.
    /// A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // A na-ahapụ Lint rustdoc::broken_intra_doc_links ka `slice::sort_by_key` dị na crate `alloc`, yana dịka nke a adịghị adị ma mgbe ị na-ewu `core`.
    //
    // njikọ na mgbada crate: #74481.Ebe ọ bụ na ederede naanị ihe ochie na libstd (#73423), nke a anaghị ebute njikọ ndị agbajiri agbaji na omume.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Na-ahọrọ iberi, ma ọ nwere ike ọ gaghị echekwa usoro nke ihe nhata.
    ///
    /// Ụdị a bụ ejighị n'aka (ie, nwere ike reorder hà ọcha), na-ebe (ie, anaghị igbunye), na *O*(*n*\*log(* n*)) kasị njọ-ikpe.
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na [pattern-defeating quicksort][pdqsort] site n'aka Orson Peters, nke na-agwakọta ngwa ngwa ngwa ngwa nke usoro ihe omuma na usoro kachasị ngwa ngwa, ebe ị na-enweta oge usoro na mpekere na ụfọdụ usoro.
    /// Ọ na-eji ụfọdụ aghara iji zere ikpe na-adịghị njọ, mana ya na seed edozi iji nye omume mgbe niile.
    ///
    /// Ọ na-adịkarị ngwa ngwa karịa nhazi dị iche iche, belụsọ na ole na ole pụrụ iche, dịka, mgbe iberi ahụ nwere ọtụtụ usoro ahaziri iche.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Dichaa iberi na arụ ọrụ comparator, mana nwere ike ọ gaghị echekwa usoro nke ihe nhata.
    ///
    /// Ụdị a bụ ejighị n'aka (ie, nwere ike reorder hà ọcha), na-ebe (ie, anaghị igbunye), na *O*(*n*\*log(* n*)) kasị njọ-ikpe.
    ///
    /// Ọrụ nchịkọta ga-akọwapụta usoro iwu maka ihe ndị dị na iberi ahụ.Ọ bụrụ na ịtụghị ya bụ mkpokọta, usoro nke ihe ndị ahụ bụ kọwaghị.Usoro bụ usoro zuru ezu ma ọ bụrụ (ọ bụ maka `a`, `b` na `c`):
    ///
    /// * ngụkọta na antisymmetric: kpọmkwem otu nke `a < b`, `a == b` ma ọ bụ `a > b` bụ eziokwu, na
    /// * transitive, `a < b` na `b < c` pụtara `a < c`.Otu ga-ejide maka `==` na `>`.
    ///
    /// Iji maa atụ, ebe [`f64`] anaghị etinye [`Ord`] maka `NaN != NaN`, anyị nwere ike iji `partial_cmp` dịka ụdị ọrụ anyị mgbe anyị matara na iberi ahụ enweghị `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na [pattern-defeating quicksort][pdqsort] site n'aka Orson Peters, nke na-agwakọta ngwa ngwa ngwa ngwa nke usoro ihe omuma na usoro kachasị ngwa ngwa, ebe ị na-enweta oge usoro na mpekere na ụfọdụ usoro.
    /// Ọ na-eji ụfọdụ aghara iji zere ikpe na-adịghị njọ, mana ya na seed edozi iji nye omume mgbe niile.
    ///
    /// Ọ na-adịkarị ngwa ngwa karịa nhazi dị iche iche, belụsọ na ole na ole pụrụ iche, dịka, mgbe iberi ahụ nwere ọtụtụ usoro ahaziri iche.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // agbara sorting
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Dichapu iberi na arụ ọrụ isi, ma ọ nwere ike ọ gaghị echekwa usoro nke ihe nhata.
    ///
    /// Sortdị a ejighị n'aka (yabụ, enwere ike ịhazigharị ihe ndị ọzọ), na-ebe (ya bụ, anaghị ekenye), yana *O*(m\* * n *\* log(*n*)) kasị njọ, ebe isi ọrụ bụ *O*(*m*).
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na [pattern-defeating quicksort][pdqsort] site n'aka Orson Peters, nke na-agwakọta ngwa ngwa ngwa ngwa nke usoro ihe omuma na usoro kachasị ngwa ngwa, ebe ị na-enweta oge usoro na mpekere na ụfọdụ usoro.
    /// Ọ na-eji ụfọdụ aghara iji zere ikpe na-adịghị njọ, mana ya na seed edozi iji nye omume mgbe niile.
    ///
    /// N'ihi usoro ịkpọ oku ya, [`sort_unstable_by_key`](#method.sort_unstable_by_key) nwere ike ịdị nwayọ karịa [`sort_by_cached_key`](#method.sort_by_cached_key) n'ọnọdụ ebe ọrụ igodo dị oke ọnụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reorder iberi ahụ ka ihe mmewere na `index` dị na nhazi ikpeazụ ya.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reorder iberi na a comparator arụ ọrụ dị otú ahụ na mmewere na `index` bụ na nke ikpeazụ ya ota ọnọdụ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Hazigharị iberi ahụ na ọrụ mwepụ igodo dị ka ihe dị na `index` dị na nhazi ikpeazụ ya.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reorder iberi ahụ ka ihe mmewere na `index` dị na nhazi ikpeazụ ya.
    ///
    /// Reordering a nwere ihe mgbakwunye ndị ọzọ na uru ọ bụla na ọnọdụ `i < index` ga-erughị ma ọ bụ hara nha ọ bụla na ọnọdụ `j > index`.
    /// Ọzọkwa, a reordering bụ ejighị n'aka (ie
    /// nọmba ọ bụla nke hà nhata nwere ike ịkwụsị na ọnọdụ `index`), na-ebe (ntụgharị
    /// anaghị ekenye), yana *O*(*n*) nke kachasị njọ.
    /// Ọrụ a bụkwa/mara dị ka "kth element" na ọba akwụkwọ ndị ọzọ.
    /// Ọ laghachi a triplet nke ndị na-esonụ ụkpụrụ: niile ọcha na-erughị otu na nyere index, uru na nyere index, na ihe nile dị n'eluigwe na ụwa ukwuu karịa onye na nyere index.
    ///
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na mpaghara nhọrọ ngwa ngwa nke otu ngwa ngwa algorithm nke eji [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics mgbe `index >= len()`, nke pụtara mgbe ọ panics na efu Mpekere.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Chọta etiti
    /// v.select_nth_unstable(2);
    ///
    /// // Anyị na-na na na-ekwe nkwa iberi ga-abụ otu nke na-esonụ, nke dabeere na ụzọ anyị ụdị banyere kpọmkwem index.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorder iberi na a comparator arụ ọrụ dị otú ahụ na mmewere na `index` bụ na nke ikpeazụ ya ota ọnọdụ.
    ///
    /// Reordering a nwere ihe mgbakwunye ndị ọzọ na uru ọ bụla na ọnọdụ `i < index` ga-erughị ma ọ bụ hara nha ọ bụla na ọnọdụ `j > index` site na iji ọrụ nchịkọta.
    /// Ọzọkwa, usoro a anaghị agbanwe agbanwe (ntụgharị nọmba ọ bụla hà nhata nwere ike ịkwụsị na ọnọdụ `index`), ebe (ya bụ, anaghị ekenye ya), yana *O*(*n*) nke kachasị njọ.
    /// Ọrụ a na-mara dị "kth element" na ndị ọzọ ọba akwụkwọ.
    /// Ọ na-eweghachi okpukpu atọ nke ụkpụrụ ndị a: ihe niile dị obere karịa nke dị na ndepụta ahụ enyere, uru dị na ndepụta ahụ enyere ya, yana ihe niile dị ukwuu karịa nke edere na ntanetị, jiri ọrụ atụnyere enyere.
    ///
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na mpaghara nhọrọ ngwa ngwa nke otu ngwa ngwa algorithm nke eji [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics mgbe `index >= len()`, nke pụtara mgbe ọ panics na efu Mpekere.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Chọta etiti dị ka a ga-asị na iberi iberi na-agbadata.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Anyị na-na na na-ekwe nkwa iberi ga-abụ otu nke na-esonụ, nke dabeere na ụzọ anyị ụdị banyere kpọmkwem index.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Hazigharị iberi ahụ na ọrụ mwepụ igodo dị ka ihe dị na `index` dị na nhazi ikpeazụ ya.
    ///
    /// Nke a reordering nwere ndị ọzọ na ihe onwunwe na uru ọ bụla na ọnọdụ `i < index` ga-erughị ma ọ bụ tụnyere ọ bụla uru a ọnọdụ `j > index` eji isi mmịpụta ọrụ.
    /// Ọzọkwa, usoro a anaghị agbanwe agbanwe (ntụgharị nọmba ọ bụla hà nhata nwere ike ịkwụsị na ọnọdụ `index`), ebe (ya bụ, anaghị ekenye ya), yana *O*(*n*) nke kachasị njọ.
    /// Ọrụ a na-mara dị "kth element" na ndị ọzọ ọba akwụkwọ.
    /// Ọ laghachi a triplet nke ndị na-esonụ ụkpụrụ: niile ọcha na-erughị otu na nyere index, uru na nyere index, na ihe nile dị n'eluigwe na ụwa ukwuu karịa onye na nyere index, na iji nyere isi mmịpụta ọrụ.
    ///
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na mpaghara nhọrọ ngwa ngwa nke otu ngwa ngwa algorithm nke eji [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics mgbe `index >= len()`, nke pụtara mgbe ọ panics na efu Mpekere.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Weghachite etiti dị ka a ga-ahazi usoro ahụ dịka uru zuru oke.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Anyị na-na na na-ekwe nkwa iberi ga-abụ otu nke na-esonụ, nke dabeere na ụzọ anyị ụdị banyere kpọmkwem index.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Na-ebugharị ihe niile emere ugboro ugboro na njedebe nke iberi ahụ dịka ntinye [`PartialEq`] trait.
    ///
    ///
    /// Alaghachikwa Mpekere abụọ.Nke mbụ enweghị ihe na-eme ugboro ugboro.
    /// Nke abụọ nwere ihe niile ederede na usoro a kapịrị ọnụ.
    ///
    /// Ọ bụrụ na edozi iberi ahụ, mpempe akwụkwọ izizi izizi enweghị akwụkwọ abụọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Nkea niile ma nke mbụ nke consecutive ọcha na njedebe nke iberi na-eju afọ a nyere hara nhata mmekọrita.
    ///
    /// Alaghachikwa Mpekere abụọ.Nke mbụ enweghị ihe na-eme ugboro ugboro.
    /// Nke abụọ nwere ihe niile ederede na usoro a kapịrị ọnụ.
    ///
    /// Ejiri `same_bucket` rụọ ọrụ zoro aka na ihe abụọ site na iberibe ma ga-ekpebi ma ihe ndị ahụ tụnyere nha.
    /// A na-agafe ihe ndị ahụ na usoro ha site na usoro ha na iberi ahụ, yabụ ọ bụrụ na `same_bucket(a, b)` laghachiri `true`, `a` na-akwagharị na njedebe nke iberi ahụ.
    ///
    ///
    /// Ọ bụrụ na edozi iberi ahụ, mpempe akwụkwọ izizi izizi enweghị akwụkwọ abụọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Ọ bụ ezie na anyị nwere a mutable banyere `self`, anyị nwere ike ime *aka ike* mgbanwe.The `same_bucket` oku nwere ike panic, otú ahụ ka anyị ga-hụ na iberi bụ na a nti na steeti mgbe niile.
        //
        // The ụzọ anyị aka na nke a bụ site na iji swaps;anyị iterate n'elu niile ọcha, swapping dị ka anyị na-aga ya mere na, na njedebe ndị ọcha na anyị chọrọ ịnọgide na-na-na n'ihu, na ndị anyị na-achọ na-ajụ ndị na azụ.
        // Anyị nwere ike kewaa iberi.
        // Ọrụ a ka bụ `O(n)`.
        //
        // Ihe Nlereanya: Anyị na-amalite na steeti a, ebe `r` na-anọchite "na-esote
        // gụọ "na `w` na-anọchite" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // N'iji self[r] tụnyere onwe [w-1], nke a abụghị oyiri, yabụ anyị gbanwere self[r] na self[w] (enweghị mmetụta dị ka r==w) wee gbakwunye ma r na w, na-ahapụ anyị:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // N'iji self[r] tụnyere onwe [w-1], uru a bụ oyiri, yabụ anyị na-agbakwunye `r` mana hapụ ihe ọ bụla na-agbanweghi agbanwe:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Atụnyere self[r] megide onwe [w-1], nke a abụghị a oyiri, otú gbanwee self[r] na self[w] na tupu r na w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ọ bụghị oyiri, megharịa:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Oyiri, advance r. End nke iberi.Kewaa na w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // NCHEKWA: na `while` ọnọdụ emesi `next_read` na `next_write`
        // bụ ihe na-erughị `len`, yabụ dị n'ime `self`.
        // `prev_ptr_write` isi ka otu mmewere tupu `ptr_write`, ma `next_write` amalite na 1, otú `prev_ptr_write` bụ mgbe ihe na-erughị 0 na dị n'ime iberi.
        // Nke a na-emezu ihe ndị a chọrọ maka dereferencing `ptr_read`, `prev_ptr_write` na `ptr_write`, na maka iji `ptr.add(next_read)`, `ptr.add(next_write - 1)` na `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` na-incremented ọtụtụ mgbe kwa akaghị na kasị pụtara ọ dịghị mmewere na-awụgharị mgbe ọ pụrụ mkpa ka a swapped.
        //
        // `ptr_read` na `prev_ptr_write` ekwetaghi otu mmewere.Achọrọ nke a maka `&mut *ptr_read`, `&mut* prev_ptr_write` ka ọ dị mma.
        // Nkọwa ahụ bụ na `next_read >= next_write` bụ eziokwu mgbe niile, yabụ `next_read > next_write - 1` kwa.
        //
        //
        //
        //
        //
        unsafe {
            // Zere ókè-achọpụtazi site na iji ndu pointers.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Nkea niile ma nke mbụ nke consecutive ọcha na njedebe nke iberi na mkpebi na otu isi.
    ///
    ///
    /// Alaghachikwa Mpekere abụọ.Nke mbụ enweghị ihe na-eme ugboro ugboro.
    /// Nke abụọ nwere ihe niile ederede na usoro a kapịrị ọnụ.
    ///
    /// Ọ bụrụ na edozi iberi ahụ, mpempe akwụkwọ izizi izizi enweghị akwụkwọ abụọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Na-atụgharị iberi ahụ ebe nke ihe mbụ `mid` nke iberi ahụ na-aga na njedebe mgbe ihe ikpeazụ `self.len() - mid` na-aga n'ihu.
    /// Mgbe akpọchara `rotate_left`, mmewere nke mbụ na ndeksi `mid` ga-abụ ihe mbụ na mpempe ahụ.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na `mid` karịrị ogologo nke iberi ahụ.Rịba ama na `mid == self.len()` na-eme _not_ panic na ọ bụ ntụgharị na-enweghị opi.
    ///
    /// # Complexity
    ///
    /// Were linear (na oge `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// N'usoro subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: Usoro `[p.add(mid) - mid, p.add(mid) + k)` dị obere
        // ziri ezi maka ịgụ na ide, dịka `ptr_rotate` chọrọ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Agbagharị iberi na-ebe dị otú ahụ na nke mbụ `self.len() - k` ọcha nke iberi aga na njedebe mgbe ikpeazụ `k` ọcha gaa n'ihu.
    /// Mgbe akpọchara `rotate_right`, mmewere nke mbụ na ndeksi `self.len() - k` ga-abụ ihe mbụ na mpempe ahụ.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na `k` karịrị ogologo nke iberi ahụ.Cheta na `k == self.len()` ka _not_ panic na bụ a dịghị-op adiana.
    ///
    /// # Complexity
    ///
    /// Were linear (na oge `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Bugharia a subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: Usoro `[p.add(mid) - mid, p.add(mid) + k)` dị obere
        // ziri ezi maka ịgụ na ide, dịka `ptr_rotate` chọrọ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Jupụta `self` na ihe site na cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Ejuputa `self` na ihe laghachiri site na ịkpọ mmechi ugboro ugboro.
    ///
    /// Usoro a na-eji mmechi mepụta ụkpụrụ ọhụrụ.Ọ bụrụ na ịchọrọ [`Clone`] bara uru, jiri [`fill`].
    /// Ọ bụrụ n`ịchọrọ iji [`Default`] trait kenye ụkpụrụ, ịnwere ike ịgafe [`Default::default`] dị ka esemokwu.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Mbipụta ndị ọcha si `src` n'ime `self`.
    ///
    /// Ogologo `src` ga-abụ otu ihe ahụ dị ka `self`.
    ///
    /// Ọ bụrụ na `T` na-etinye `Copy` n'ọrụ, ọ nwere ike ịrụ ọrụ karịa iji [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na abụọ Mpekere nwere dị iche iche ogologo.
    ///
    /// # Examples
    ///
    /// Cloning abụọ ọcha si a iberi n'ime ọzọ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // N'ihi na mpekere ga-abụ otu ogologo, anyị na-ebipụ isi iyi si na ihe anọ ruo abụọ.
    /// // Ọ ga panic ma ọ bụrụ na anyị emeghị nke a.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust na-akwado na enwere ike ịbụ naanị otu mkpụrụedemede a na-agbanwe agbanwe na-enweghị ntụnye a na-apụghị ịgbanwe agbanwe na otu mpempe data n'otu akụkụ.
    /// Maka nke a, ịnwa iji `clone_from_slice` na otu iberi ga-ebute mkpokọta ọdịda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Iji ọrụ gburugburu a, anyị nwere ike iji [`split_at_mut`] ike abụọ dị iche sub-Mpekere si a iberi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Detuo ihe niile sitere na `src` n'ime `self`, jiri memcpy.
    ///
    /// Ogologo `src` ga-abụ otu ihe ahụ dị ka `self`.
    ///
    /// Ọ bụrụ na `T` anaghị etinye `Copy` n'ọrụ, jiri [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na abụọ Mpekere nwere dị iche iche ogologo.
    ///
    /// # Examples
    ///
    /// Iomi ihe abuo site na iberi na ozo:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // N'ihi na mpekere ga-abụ otu ogologo, anyị na-ebipụ isi iyi si na ihe anọ ruo abụọ.
    /// // Ọ ga panic ma ọ bụrụ na anyị emeghị nke a.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust na-akwado na enwere ike ịbụ naanị otu mkpụrụedemede a na-agbanwe agbanwe na-enweghị ntụnye a na-apụghị ịgbanwe agbanwe na otu mpempe data n'otu akụkụ.
    /// N'ihi nke a, na-agbalị iji `copy_from_slice` na a otu iberi ga-eme a ikpokọta ọdịda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Iji ọrụ gburugburu a, anyị nwere ike iji [`split_at_mut`] ike abụọ dị iche sub-Mpekere si a iberi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Etinyere ụzọ koodu panic n'ime ọrụ oyi iji ghara iwechi saịtị oku.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` dị mma maka ihe `self.len()` site na nkọwa, `src` dịkwa
        // enyocha nwere otu ogologo.
        // Mpekere ndị a enweghị ike ịbịakọta n'ihi na ederede ntụgharị pụrụ iche.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Detuo ihe site n'otu akụkụ nke iberi ahụ n'akụkụ ọzọ nke onwe ya, na-eji memmove.
    ///
    /// `src` bụ nso n'ime `self` i toomi si.
    /// `dest` bụ ndetu mmalite nke nso n'ime `self` iji depụta ya, nke ga-enwe otu ogologo dịka `src`.
    /// Ọnọdụ abụọ ahụ nwere ike ịdọrọ.
    /// Na nsọtụ abụọ àmà ga-erughị ma ọ bụ hà `self.len()`.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na nso nso karịa njedebe nke iberi ahụ, ma ọ bụ ọ bụrụ na njedebe nke `src` dị tupu mmalite.
    ///
    ///
    /// # Examples
    ///
    /// Iṅomi anọ bytes n'ime a iberi:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: Ọnọdụ nke `ptr::copy` niile enyochala n'elu,
        // dị ka ndị ahụ maka `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Gbanwee ihe niile dị na `self` na ndị nọ na `other`.
    ///
    /// Ogologo `other` ga-abụ otu ihe ahụ dị ka `self`.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na abụọ Mpekere nwere dị iche iche ogologo.
    ///
    /// # Example
    ///
    /// Wagbanye ihe abụọ gafere mpekere:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust na-akwado na enwere ike ịbụ naanị otu mkpụrụedemede na-atụgharị aka na otu mpempe data n'otu akụkụ.
    ///
    /// N'ihi nke a, na-agbalị iji `swap_with_slice` na a otu iberi ga-eme a ikpokọta ọdịda:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Iji ọrụ gburugburu a, anyị nwere ike iji [`split_at_mut`] ike abụọ dị iche mutable sub-Mpekere si a iberi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` dị mma maka ihe `self.len()` site na nkọwa, `src` dịkwa
        // enyocha nwere otu ogologo.
        // Mpekere ndị a enweghị ike ịbịakọta n'ihi na ederede ntụgharị pụrụ iche.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Function gbakọọ ogologo n'etiti na trailing iberi maka `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ihe anyi gha eme banyere `rest` bu ichoputa otutu otutu ``U '' anyi nwere ike itinye na onu ogugu kachasi nke T`s.
        //
        // Na otú ọtụtụ 'T`s anyị mkpa ka onye ọ bụla dị otú ahụ "multiple".
        //
        // Tụlee ihe atụ T=u8 U=u16.Mgbe ahụ, anyị nwere ike na-etinye 1 U na 2 TS.Dị Mfe.
        // Ugbu a, tụlee ihe atụ a ikpe ebe size_of: :<T>=16, size_of::<U>=24.</u>
        // Anyị nwere ike na-etinye 2 Anyị na ebe nke ọ bụla 3 TS na `rest` iberi.
        // Obere ihe mgbagwoju anya.
        //
        // Formula gbakọọ nke a bụ:
        //
        // Anyị= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>TS= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Gbasaa ma dị mfe:
        //
        // Anyị=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Luckily kemgbe ihe niile a na mgbe nile na-inyocha ... arụmọrụ ebe a mkpa abụghị!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorithm stein's algorithm Anyị ka ga-eme `const fn` a (ma laghachị na algorithm na-echegharị ma ọ bụrụ na anyị emee) n'ihi na ịdabere na llvm iji bụrụ ihe niile a bụ…nke ọma, ọ na-eme m obi erughị ala.
            //
            //

            // NCHEKWA: `a` na `b` na-enyocha na-abụghị-zero ụkpụrụ.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // wepu ihe niile nke 2 na b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // NCHEKWA: `b` na-enyocha na-na-abụghị efu.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ejiri ihe omuma a, anyi nwere ike ichota otutu `` U '' anyi puru itinye!
        let us_len = self.len() / ts * us;
        // Ma ole ole T`s ga-abụ na trailing iberi!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Gbanwee iberi ahụ na mpekere nke ụdị ọzọ, na-eme ka nhazi nke ụdị ndị ahụ dịgide.
    ///
    /// Usoro a na-ekewa iberipe na mpekere atọ dị iche iche: prefix, nke kwekọrọ n'ụdị etiti nke ụdị ọhụrụ, na mpempe suffix.
    /// Usoro a nwere ike ime ka mpempe dị n'etiti dị ogologo karịa maka ụdị enyere na ntinye ntinye, mana naanị arụmọrụ algorithm gị kwesịrị ịdabere na nke ahụ, ọ bụghị nke ziri ezi.
    ///
    /// Okwesiri ka eweghachite data ntinye niile dika prefix ma obu prefix.
    ///
    /// Nke a na usoro nwere dịghị nzube mgbe ma input mmewere `T` ma ọ bụ mmepụta mmewere `U` bụ efu-sized na ga-alaghachi mbụ iberi enweghị gbawara ihe ọ bụla.
    ///
    /// # Safety
    ///
    /// Usoro a bụ `transmute` n'ihe gbasara ihe ndị dị na nloghachi etiti ahụ, yabụ usoro ọgba aghara niile metụtara `transmute::<T, U>` na-etinye ebe a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Rịba ama na a ga-enyocha ọrụ a ọtụtụ oge,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // mee ZST n'ụzọ pụrụ iche, nke bụ-anaghị edozi ha ma ọlị.
            return (self, &[], &[]);
        }

        // Akpa, chọta na ihe na-ezo anyị na kewaa n'etiti ndị mbụ na 2nd iberi.
        // Mfe na ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Hụ usoro `align_to_mut` maka nkọwa gbasara nchekwa zuru ezu.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: ugbu a, `rest` kwụ ọtọ, ya mere `from_raw_parts` dị n'okpuru, dịkwa mma,
            // ebe ọ bụ na bere jide n'aka na anyị nwere ike transmute `T` ka `U` n'enweghị nsogbu.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Gbanwee iberi ahụ na mpekere nke ụdị ọzọ, na-eme ka nhazi nke ụdị ndị ahụ dịgide.
    ///
    /// Usoro a na-ekewa iberipe na mpekere atọ dị iche iche: prefix, nke kwekọrọ n'ụdị etiti nke ụdị ọhụrụ, na mpempe suffix.
    /// Usoro a nwere ike ime ka mpempe dị n'etiti dị ogologo karịa maka ụdị enyere na ntinye ntinye, mana naanị arụmọrụ algorithm gị kwesịrị ịdabere na nke ahụ, ọ bụghị nke ziri ezi.
    ///
    /// Okwesiri ka eweghachite data ntinye niile dika prefix ma obu prefix.
    ///
    /// Nke a na usoro nwere dịghị nzube mgbe ma input mmewere `T` ma ọ bụ mmepụta mmewere `U` bụ efu-sized na ga-alaghachi mbụ iberi enweghị gbawara ihe ọ bụla.
    ///
    /// # Safety
    ///
    /// Usoro a bụ `transmute` n'ihe gbasara ihe ndị dị na nloghachi etiti ahụ, yabụ usoro ọgba aghara niile metụtara `transmute::<T, U>` na-etinye ebe a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Rịba ama na a ga-enyocha ọrụ a ọtụtụ oge,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // mee ZST n'ụzọ pụrụ iche, nke bụ-anaghị edozi ha ma ọlị.
            return (self, &mut [], &mut []);
        }

        // Akpa, chọta na ihe na-ezo anyị na kewaa n'etiti ndị mbụ na 2nd iberi.
        // Mfe na ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: N'ebe a, anyị na-ahụ na anyị ga-eji akara ngosi echekwara maka U maka
        // ezumike nke usoro.Nke a na-eme site na-agafe a pointer ka&[T] na itinye n'ọnọdụ ezubere iche maka US Geological
        // `crate::ptr::align_offset` A na-akpọ ya na pointer `ptr` ziri ezi na nke ziri ezi (ọ na-abịa site na ntinye aka na `self`) yana nha nke nwere ike nke abụọ (ebe ọ na-esite na ntinye maka U), na-emeju afọ ojuju nchekwa ya.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Anyị enweghị ike iji `rest` ọzọ mgbe nke a gasịrị, nke ahụ ga-eme ka aha ya bụ `mut_ptr` gharazie ịdị irè!NCHEKWA: ahụ ihe n'ihi na `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Nyochaa ma ọ bụrụ na edozi ihe ndị dị na iberibe a.
    ///
    /// Nke ahụ bụ, maka ihe ọ bụla `a` na ihe na-eso ya `b`, `a <= b` ga-ejide.Ọ bụrụ na iberi amịrị kpọmkwem efu ma ọ bụ onye na mmewere, `true` na-laghachi.
    ///
    /// Cheta na ọ bụrụ na `Self::Item` bụ naanị `PartialOrd`, ma ọ bụghị `Ord`, n'elu definition na-egosi na ọrụ a na-alaghachikwuru `false` ma ọ bụrụ na abụọ ọ bụla consecutive ihe ndị tụnyere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Achọpụta ego ma ọ bụrụ na edozi ihe ndị dị na iberibe a site na iji ọrụ comparator nyere.
    ///
    /// Kama iji `PartialOrd::partial_cmp`, ọrụ a na-eji nyere `compare` ọrụ ikpebi ịtụ nke abụọ ọcha.
    /// E wezụga na, ọ bụ Ẹkot [`is_sorted`];-ahụ ya akwụkwọ maka ozi ndị ọzọ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Nyochaa ma ọ bụrụ na ejiri ihe dị na mpempe akwụkwọ a rụọ ọrụ site na iji ọrụ mwepu isi.
    ///
    /// Kama nke atụnyere iberi si ọcha ozugbo, ọrụ a na-eji tụnyere mkpịsị ugodi nke ọcha, dị ka akọwapụtara site `f`.
    /// E wezụga na, ọ bụ Ẹkot [`is_sorted`];-ahụ ya akwụkwọ maka ozi ndị ọzọ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// - Alaghachi na index nke nkebi ebe dị ka nyere predicate (na index nke mbụ mmewere nke abụọ nkebi).
    ///
    /// A na-eche na iberi ahụ ga-ekewa dịka usoro enyere enyere.
    /// Nke a pụtara na ihe niile dị n'eluigwe na ụwa n'ihi na nke predicate alaghachi eziokwu na mmalite nke iberi na niile ọcha n'ihi na nke predicate alaghachi ụgha bụ na njedebe.
    ///
    /// Iji maa atụ, [7, 15, 3, 5, 4, 12, 6] bụ nkewapụrụ n'okpuru amụma x% 2!=0 (ọnụọgụ niile dị njọ na mbido, ọbụlagodi na njedebe).
    ///
    /// Ọ bụrụ na ejighi nkebi a, nke a laghachiri bụ nke akọwaghị na enweghị isi, ebe usoro a na-eme ụdị nyocha ọnụọgụ abụọ.
    ///
    /// Hụkwa [`binary_search`], [`binary_search_by`], na [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Mgbe `left < right`, `left <= mid < right`.
            // Ya mere `left` mgbe enwekwu na `right` mgbe mbelata, ma ma nke ha na-ahọrọ.N'okwu abụọ `left <= right` nwere afọ ojuju.Ya mere ọ bụrụ na `left < right` na a nzọụkwụ, `left <= right` bụ na afọ ojuju na nzọụkwụ ọzọ.
            //
            // Yabụ ọ bụrụhaala na `left != right`, `0 <= left < right <= len` nwere afọ ojuju ma ọ bụrụ na ikpe a `0 <= mid < len` nwekwara afọ ojuju.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Anyị kwesịrị ịkọwapụ ha n'ụzọ doro anya n'otu ogologo
        // iji mee ka ọ dịkwuo mfe maka ihe kachasị mma iji kwado oke nyocha.
        // Mana ebe ọ bụ na enweghị ike ịdabere na ya, anyị nwekwara ọkachamara ọhụụ maka T: Detuo.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Emepụta ihe efu iberi.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Na-emepụta ihe efu efu.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Kpụrụ na Mpekere, ugbu a, naanị `strip_prefix` na `strip_suffix` na-eji ya.
/// N'ebe future, anyị nwere olile anya ịchịkọta `core::str::Pattern` (nke n'oge ederede naanị `str`) na mpekere, emesịa trait a ga-anọchi ma ọ bụ kpochapụ ya.
///
pub trait SlicePattern {
    /// Mmewere ụdị nke iberi na-ekwekọ na.
    type Item;

    /// Ugbu a, ndị na-eji ọkụ nke `SlicePattern` mkpa a iberi.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}