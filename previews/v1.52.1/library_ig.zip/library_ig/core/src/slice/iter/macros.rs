//! Macros ji ndị ọrụ ya nke iberi.

// Iniling is_empty na len na-eme nnukwu arụmọrụ dị iche
macro_rules! is_empty {
    // Wayzọ anyị si edochi ogologo nke onye ọrụ ZST, nke a na-arụ ọrụ maka ZST na ndị na-abụghị ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Iji kpochapụ ụfọdụ akwụkwọ ndenye ego (lee `position`), anyị na-agbakọ ogologo n'ogologo atụghị anya.
// (Nwara site 'codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // anyị na-mgbe ụfọdụ na-eji n'ime ihe-eche ọnweghị nchedo ngọngọ

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Nke a _cannot_ iji `unchecked_sub` n'ihi na anyị adabere na wrapping na-anọchite anya na ogologo nke ogologo ZST iberi iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Anyị maara na `start <= end`, otú ahụ pụrụ ime nke ọma karịa `offset_from`, nke kwesịrị obibi na bịanyere aka.
            // Site na ịtọlite ọkọlọtọ kwesịrị ekwesị ebe a anyị nwere ike ịgwa LLVM nke a, nke na-enyere ya aka wepu nyocha ego.
            // SAFETY: Site na ụdị na-agbanwe agbanwe, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Site na ịgwa LLVM na ntụpọ ahụ dị iche site na ọtụtụ otutu ụdị ụdị, ọ nwere ike ịkwalite `len() == 0` ruo `start == end` kama `(end - start) < size`.
            //
            // SAFETY: Site na udi na-agbanwe agbanwe, ihe nchoputa na-ahazi ya
            //         ohere dị n'etiti ha ga-abụrịrị ọtụtụ nha pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// The na-akọrọ definition nke `Iter` na `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // O weghachitere ihe mbu ma weghachite mmalite nke ite ite na 1.
        // Jiri arụmọrụ ka mma na arụ ọrụ ejiri arụ ọrụ.
        // The iterator ga-abụ ihe efu.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // O weghachitere ihe ikpeazụ wee mechaa njedebe nke ite ite 1.
        // Jiri arụmọrụ ka mma na arụ ọrụ ejiri arụ ọrụ.
        // The iterator ga-abụ ihe efu.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Ibelata iterator mgbe T bụ ZST, site na ịmegharị njedebe nke iterator na `n`.
        // `n` gafere `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Onye Inyeaka na-arụ ọrụ na-eke a iberi si iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // NCHEKWA: na iterator e kere si a iberi na pointer
                // `self.ptr` na ogologo `len!(self)`.
                // Nke a na-ekwe nkwa na ihe niile dị mkpa maka `from_raw_parts` mezuru.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ọrụ enyemaka maka ịmegharị mmalite nke iterator n'ihu site na `offset` ọcha, weghachite mmalite ochie.
            //
            // Onweghị nchedo n'ihi na mmebi agaghị agabiga `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // NCHEKWA: nke bere di na `offset` adịghị gafere `self.len()`,
                    // otú a ọhụrụ pointer bụ n'ime `self` ma si otú na-ekwe nkwa na-na-abụghị null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ọrụ enyemaka iji na-ebugharị njedebe nke iterator azụ site na `offset` ọcha, weghachite njedebe ọhụrụ.
            //
            // Onweghị nchedo n'ihi na mmebi agaghị agabiga `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // NCHEKWA: nke bere di na `offset` adịghị gafere `self.len()`,
                    // nke emere nkwa na ịghara ị gafere `isize`.
                    // Ọzọkwa, pointer rụpụtara nwere oke nke `slice`, nke na-emezu ihe ndị ọzọ achọrọ maka `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // enwere ike itinye ya na mpekere, mana nke a na-egbochi nyocha

                // SAFETY: Oku `assume` dị mma kemgbe mbido pointer amalite
                // ga-abụrịrị ihe efu, na mpekere ndị na-abụghị ZST ga-enwerịrị akara ngosi na-enweghị isi.
                // Oku a na-akpọ `next_unchecked!` adịghị mma ebe ọ bụ na anyị na-enyocha ma ọ bụrụ na onye na-egbu ite ahụ adịghịzi ihe mbụ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ihe omuma a adighizi.
                    if mem::size_of::<T>() == 0 {
                        // Anyị ga-eme ya n'ụzọ a dịka `ptr` nwere ike ọ gaghị abụ 0, mana `end` nwere ike ịbụ (n'ihi ikechi).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // MGBE: njedebe enweghị ike ịbụ 0 ma ọ bụrụ na T abụghị ZST n'ihi na ptr abụghị 0 na njedebe>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: Anyị eruola oke.`post_inc_start` eme ihe ziri ezi ọbụna n'ihi ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            // Ọzọkwa, `assume` na-ezere nyocha oke.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // NCHEKWA: anyị na-ekwe nkwa na-na ókè site akaghị invariant:
                        // mgbe `i >= n`, `self.next()` laghachiri `None` na akaghị agbaji.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Anyị akpagbu ndabara mmejuputa iwu, nke na-eji `try_fold`, n'ihi na nke a dị mfe, mmejuputa iwu site na obere LLVM Iye na bụ kpu ikpokọta.
            // Ọzọkwa, `assume` na-ezere nyocha oke.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` ga-adị ala karịa `n` ebe ọ malitere na `n`
                        // ma na-agbadata.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // MGBE: onye na-akpọ oku ga-ekwenye na `i` dị na njedebe
                // isi iberi, otú `i` ike erubiga ihe `isize`, na laghachi zoro na-ekwe nkwa na-ezo aka ihe mmewere nke iberi ma si otú na-ekwe nkwa na-nti.
                //
                // Marakwa na onye na-akpọ oku ahụ na-ekwekwa nkwa na a naghị akpọ anyị otu ndekpọ ahụ ọzọ, na ọ nweghịkwa ụzọ ndị ọzọ ga-esi nweta subslice a, a na-akpọ ya, yabụ ọ dị mma maka ntụghachị azụ a ga-atụgharị n'ọnọdụ nke
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // enwere ike itinye ya na mpekere, mana nke a na-egbochi nyocha

                // SAFETY: Oku `assume` adịghị mma ebe ọ bụ na mbido ibido ihe ga-abaghị uru,
                // na Mpekere ndị na-abụghị ZST ga-enwerịrị akara ngosi na-enweghị isi.
                // Oku a na-akpọ `next_back_unchecked!` adịghị mma ebe ọ bụ na anyị na-enyocha ma ọ bụrụ na onye na-egbu ite ahụ adịghịzi ihe mbụ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ihe omuma a adighizi.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: Anyị eruola oke.`pre_dec_end` na-eme ihe ziri ezi ọbụlagodi maka ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}