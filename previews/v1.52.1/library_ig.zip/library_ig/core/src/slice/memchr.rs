// Emere ihe izizi sitere na rust-memchr.
// Copyright 2015 Andrew Gallant, bluss na Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Jiri truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Laghachi `true` ma oburu na `x` nwere eli ozo obula.
///
/// Site na *Okwu Mgbakọ*, J. Arndt:
///
/// "The echiche bụ iwepu onye ọ bụla na nke bytes na mgbe ahụ na-achọ bytes ebe mgbazinye propagated n'ụzọ nile nke kasị dị ịrịba ama
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Weghachite ndeksi izizi dabara na byte `x` na `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Pathzọ ngwangwa maka obere mpekere
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Nyochaa otu uru byte site na ịgụ okwu `usize` abụọ n'otu oge.
    //
    // Kewaa `text` n'akụkụ atọ
    // - ahaghị mbụ, tupu okwu izizi ahaziri edezi na ederede
    // - ahu, scan site okwu abuo na oge
    // - nke fọdụrụ akụkụ, <2 okwu size

    // chọọ na-kwekọọ ókè
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // chọọ ahu ederede
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: oge na-ekwu maka ọdịnihu nke opekata mpe 2 * usize_bytes
        // n'etiti nchacha na njedebe nke iberi.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // agbaji ma ọ bụrụ na e nwere kenha byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Choo uzo mgbe isi akwara ahu kwusiri.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Weghachite ndekota nke dabara na baiti `x` na `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Nyochaa otu uru byte site na ịgụ okwu `usize` abụọ n'otu oge.
    //
    // Kewaa `text` n'akụkụ atọ:
    // - eriri adabaghị, mgbe okwu ikpeazụ jikọtara adreesị na ederede,
    // - ahụ, na-enyocha okwu abụọ n'otu oge,
    // - akpa fọdụrụ bytes, <2 okwu size.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Anyị na-akpọ nke a ka ị nweta ogologo nganiihu na suffix ahụ.
        // N'etiti anyị mgbe niile na-edozi chunks abụọ n'otu oge.
        // NCHEKWA: transmuting `[u8]` ka `[usize]` bụ nchebe ma e wezụga n'ihi size iche nke na-edozi site `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Chọọ na ederede ahụ, gbaa mbọ hụ na anyị agaghị agafe min_aligned_offset.
    // dechapụ na-mgbe kwekọọ, otú dị nnọọ anwale `>` bụ zuru ezu ma na-ezere omume nile.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: dechapụ amalite na len, suffix.len(), ọ bụrụhaala na ọ karịrị
        // min_aligned_offset (prefix.len()) nkwụsị fọdụrụ dịkarịa ala 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Agbaji ma ọ bụrụ na e nwere kenha byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Choo uzo tupu isi akuko ahu kwusiri.
    text[..offset].iter().rposition(|elt| *elt == x)
}