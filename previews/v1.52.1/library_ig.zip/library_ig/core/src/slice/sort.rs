//! Iberi nhazi
//!
//! Modul a nwere nhazi algorithm dabere na ngwa Orson Peters na-emeri ngwa ngwa, nke e bipụtara na: <https://github.com/orlp/pdqsort>
//!
//!
//! Ngwunye na-adịghị agbanwe agbanwe kwekọrọ na libcore n'ihi na ọ naghị ekenye ebe nchekwa, n'adịghị ka mmezi usoro nhazi anyị.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Mgbe a dara ya, mbipụta sitere na `src` n'ime `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // NCHEKWA: Nke a bụ onye na-enyere na klas.
        //          Biko rụtụ aka na ojiji ya maka imezi ihe.
        //          Ya bụ, mmadụ aghaghị ijide n'aka na `src` na `dst` anaghị ekpuchi dịka `ptr::copy_nonoverlapping` chọrọ.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Na-agbanwe ihe izizi gaa n'aka nri ruo mgbe ọ ga-ezute ihe ka ukwuu ma ọ bụ nha anya.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // NCHEKWA: The nwedịrị ike ịta arụmọrụ n'okpuru agụnye indexing enweghị a afụ opi ego (`get_unchecked` na `get_unchecked_mut`)
    // na i copomi ebe nchekwa (`ptr::copy_nonoverlapping`).
    //
    // a.Ndepụta:
    //  1. Anyị enyochaara nha nke usoro ahụ>=2.
    //  2. Nkọwa niile anyị ga-eme bụ oge niile n'etiti {0 <= index < len}.
    //
    // b.Idozi ebe nchekwa
    //  1. Anyị na-enweta ntụaka maka ntụnye aka nke enyere gị aka ịdị mma.
    //  2. Ha enweghị ike ịbịakọta n'ihi na anyị na-enweta akara ngosi dị iche iche.
    //     Ya bụ, `i` na `i-1`.
    //  3. Ọ bụrụ na iberi n'ụzọ ziri ezi kwekọọ, ndị ọcha na-ekwesị kwekọọ.
    //     Ọ bụ ọrụ nke onye na-akpọ oku ka o jide n'aka na iberi ahụ dabara nke ọma.
    //
    // Lee kwuru n'okpuru maka N'ịkọwakwu.
    unsafe {
        // Ọ bụrụ na ihe abụọ mbụ ahụ abụghị nke iwu ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Guo ihe mbu n`ime uzo towaputara.
            // Ọ bụrụ n `ọrụ ndị na-eso ụzọ panics, `hole` ga-adaba ma degharịa ihe ndozi na-akpaghị aka.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Bugharịa ``i`-th element otu ebe n'aka ekpe, si otú a na-agbanwe oghere gaa n'aka nri.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` na-adaba ma si otú a depụta `tmp` n'ime oghere fọdụrụ na `v`.
        }
    }
}

/// Na-agbanwe ihe ikpeazụ na aka ekpe ruo mgbe ọ ga-ezute ihe pere mpe ma ọ bụ nha anya.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // NCHEKWA: The nwedịrị ike ịta arụmọrụ n'okpuru agụnye indexing enweghị a afụ opi ego (`get_unchecked` na `get_unchecked_mut`)
    // na i copomi ebe nchekwa (`ptr::copy_nonoverlapping`).
    //
    // a.Ndepụta:
    //  1. Anyị enyochaara nha nke usoro ahụ>=2.
    //  2. Nkọwa niile anyị ga-eme bụ oge niile n'etiti `0 <= index < len-1`.
    //
    // b.Idozi ebe nchekwa
    //  1. Anyị na-enweta ntụaka maka ntụnye aka nke enyere gị aka ịdị mma.
    //  2. Ha enweghị ike ịbịakọta n'ihi na anyị na-enweta akara ngosi dị iche iche.
    //     Ya bụ, `i` na `i+1`.
    //  3. Ọ bụrụ na iberi n'ụzọ ziri ezi kwekọọ, ndị ọcha na-ekwesị kwekọọ.
    //     Ọ bụ ọrụ nke onye na-akpọ oku ka o jide n'aka na iberi ahụ dabara nke ọma.
    //
    // Lee kwuru n'okpuru maka N'ịkọwakwu.
    unsafe {
        // Ọ bụrụ na abụọ ikpeazụ ọcha bụ nke na-iji ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Guo nke ikpeazu n'ime uzo towaputara.
            // Ọ bụrụ n `ọrụ ndị na-eso ụzọ panics, `hole` ga-adaba ma degharịa ihe ndozi na-akpaghị aka.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Bugharịa `` ihe '' otu ebe aka nri, si otú a na-agbanwe oghere gaa n'aka ekpe.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` na-adaba ma si otú a depụta `tmp` n'ime oghere fọdụrụ na `v`.
        }
    }
}

/// Ikpe ụdị a iberi site shifting ọtụtụ nke na-iji ọcha gburugburu.
///
/// Weghachite `true` ma ọ bụrụ na a na-ahazi iberi na njedebe.Ọrụ a bụ *O*(*n*) kachasị njọ.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ọnụ ọgụgụ kachasị elu nke ụzọ abụọ na-agaghị adị n'usoro ga-agbanwe.
    const MAX_STEPS: usize = 5;
    // Ọ bụrụ na iberi ahụ dị mkpumkpu karịa nke a, agbanwela ihe ọ bụla.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Anyị emeworị n'ụzọ doro anya ka ejiri akara na `i < len`.
        // Nkọwa anyị niile sochirinụ bụ naanị na `0 <= index < len` nso
        unsafe {
            // Chọta ọzọ ụzọ nke n'akụkụ nke na-iji ọcha.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Anyi emeela?
        if i == len {
            return true;
        }

        // Agbanyela ihe na obere usoro, nke nwere ọnụ ahịa arụmọrụ.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Gbanwee ihe abụọ ahụ achọtara.Nke a na-etinye ha n'usoro ziri ezi.
        v.swap(i - 1, i);

        // Gbanwee obere ihe ahụ n'aka ekpe.
        shift_tail(&mut v[..i], is_less);
        // Gbanwee ihe ka ukwuu na nri.
        shift_head(&mut v[i..], is_less);
    }

    // Adịghị jikwaa ịhazi iberi na ọnụọgụ ole na ole.
    false
}

/// Dichaa otu iberi site na iji ụdị ntinye, nke bụ *O*(*n*^ 2) nke kachasị njọ.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sort `v` na-eji heapsort, nke na-ekwe nkwa *O*(*n*\*log(* n*)) kasị njọ-ikpe.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Hedị ọnụọgụ abụọ a na-asọpụrụ `parent >= child` na-enweghị atụ.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Ofmụ nke `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Họrọ nwa ka ukwuu.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Kwụsị ma ọ bụrụ na onye na-enweghị ike ijide `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Gbanwee `node` na nwatakịrị ka ukwuu, bulie otu nzọụkwụ ala, ma gaa n'ihu na-enyocha.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Mee ikpo ahụ na oge akara.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximal ọcha si kpokọtara.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Nkebi `v` n'ime ihe pere mpe `pivot`, ihe na-esote ya karịa ma ọ bụ hara ka `pivot`.
///
///
/// Weghachite onu ogugu nke obere karia `pivot`.
///
/// Nkewa na-rụrụ ngọngọ-site-gbochie iji belata na-eri nke branching arụmọrụ.
/// E gosipụtara echiche a na akwụkwọ [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Number nke ọcha ke ahụkarị ngọngọ.
    const BLOCK: usize = 128;

    // Nkewa algọridim na-ekwughachi usoro ndị a ruo mgbe emechara:
    //
    // 1. Chọpụta otu ngọngọ site n`akụkụ aka ekpe iji chọpụta ihe ndị dị ukwuu ma ọ bụ hara n`isi.
    // 2. Chọpụta otu ngọngọ site n'akụkụ aka nri iji chọpụta ihe ndị pere mpe.
    // 3. Exchange na kwuru ọcha n'etiti n'aka ekpe na n'akụkụ aka nri.
    //
    // Anyị na-edebe mgbanwe ndị a maka ngọngọ nke ihe:
    //
    // 1. `block` - Ọnụ ọgụgụ nke ihe ndị dị na ngọngọ ahụ.
    // 2. `start` - Bido pointer n'ime usoro `offsets`.
    // 3. `end` - Njedebe pointer n'ime usoro `offsets`.
    // 4. mmebi, Ndepụta nke ihe na-adịghị na iwu n'ime ogige ahụ.

    // The ugbu a ngọngọ na n'aka ekpe (site `l` ka `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ihe mgbochi dị ugbu a n'akụkụ aka nri (site na `r.sub(block_r)` to `r`).
    // NCHEKWA: The akwụkwọ maka .add() kpọmkwem banyere na `vec.as_ptr().add(vec.len())` bụ mgbe safe`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Mgbe anyị na-enweta VLAs, na-agbalị na-eke onye n'usoro nke ogologo `min(v.len(), 2 * ngọngọ) 'kama
    // karịa abụọ ofu-size arrays nke ogologo `BLOCK`.VLAs pụrụ ịbụ ihe cache-oru oma.

    // Weghachite ọnụ ọgụgụ nke ihe dị n'etiti ihe atụ `l` (inclusive) na `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Emechaala m na nkewa-nkewa mgbochi mgbe `l` na `r` rutere nso.
        // Mgbe ahụ, anyị na-arụ ụfọdụ ọrụ ịmachi iji kesaa ihe ndị ọzọ fọdụrụ n'etiti.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Number nke fọdụrụ ọcha (ka na-adịghị tụnyere pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Gbanwee nha nha ka ogwe aka ekpe na aka nri wee ghara ịbịakọta, mana ị ga-ahazi nke ọma iji kpuchie oghere niile fọdụrụ.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Chọpụta ihe `block_l` site n'akụkụ aka ekpe.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // NCHEKWA: The unsafety arụmọrụ n'okpuru agụnye ojiji nke `offset`.
                //         Dị ka ọnọdụ chọrọ site ọrụ, anyị na-egbo ha n'ihi na:
                //         1. `offsets_l` na-tojupụtara-ekenyela, ma si otú ahụ iche iche ekenyela ihe.
                //         2. Ndị ọrụ `is_less` laghachi a `bool`.
                //            Nkedo `bool` agaghị awaba karịa `isize`.
                //         3. Anyị ekwela nkwa na `block_l` ga-abụ `<= BLOCK`.
                //            Na mgbakwunye, ebido `end_l` na mmalite pointer nke `offsets_` nke ekwuputara na nchịkọta.
                //            Ya mere, anyị maara na ọbụlagodi n'ọnọdụ kachasị njọ (ịrịọ arịrịọ niile nke `is_less` na-alaghachi ụgha) anyị ga-anọ naanị na 1 kachasị byte gafere njedebe.
                //        Ọrụ ọzọ enweghị nchekwa ebe a bụ dereferencing `elem`.
                //        Agbanyeghị, `elem` bụ mmalite mmalite pointer na iberi nke na-adị ire mgbe niile.
                unsafe {
                    // Nkọwa na-enweghị atụ.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Chọpụta ihe `block_r` sitere n'akụkụ aka nri.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // NCHEKWA: The unsafety arụmọrụ n'okpuru agụnye ojiji nke `offset`.
                //         Dị ka ọnọdụ chọrọ site ọrụ, anyị na-egbo ha n'ihi na:
                //         1. `offsets_r` na-tojupụtara-ekenyela, ma si otú ahụ iche iche ekenyela ihe.
                //         2. Ndị ọrụ `is_less` laghachi a `bool`.
                //            Nkedo `bool` agaghị awaba karịa `isize`.
                //         3. Anyị ekwela nkwa na `block_r` ga-abụ `<= BLOCK`.
                //            Na mgbakwunye, ebido `end_r` na mmalite pointer nke `offsets_` nke ekwuputara na nchịkọta.
                //            Ya mere, anyị maara na ọbụlagodi n'ọnọdụ kachasị njọ (ịrịọ arịrịọ niile nke `is_less` na-alaghachi n'eziokwu) anyị ga-anọ na nke kachasị 1 byte gafere njedebe.
                //        Ọrụ ọzọ enweghị nchekwa ebe a bụ dereferencing `elem`.
                //        Agbanyeghị, `elem` bụ mmalite `1 *sizeof(T)` gafere njedebe ma anyị belata ya site na `1* sizeof(T)` tupu ịnweta ya.
                //        Na mgbakwunye, ekwenyesiri ike na `block_r` ga-erughị `BLOCK` na `elem` ga-atụtụ aka na mbido iberi ahụ.
                unsafe {
                    // Nkọwa na-enweghị atụ.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Onuogugu ihe nke iwu na-agbanwe n'etiti aka ekpe na aka nri.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Kama swapping otu ụzọ n'oge ahụ, ọ bụ ndị ọzọ ịrụ ọrụ nke ọma na-arụ a cyclic permutation.
            // Nke a abụghị nnọọ Ẹkot swapping, ma na-arụpụta a yiri N'ihi eji ole na ole ebe nchekwa arụmọrụ.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // A kpaliri ihe niile na-adịghị na iwu na mgbochi aka ekpe.Gaa na ngọngọ ọzọ.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // A kpaliri ihe niile na-adịghị na iwu na ngọngọ aka nri.Gaa na ngọngọ gara aga.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Naanị ihe fọdụrụ ugbu a bụ n'ọtụtụ ngọngọ (ma ọ bụ aka ekpe ma ọ bụ aka nri) ya na ihe ndị na-enweghị iwu chọrọ ịkwaga.
    // Enwere ike ịgbanwe ihe ndị ọzọ fọdụrụnụ na njedebe n'ime ngọngọ ha.
    //

    if start_l < end_l {
        // Ogwe aka ekpe na-anọgide.
        // Bugharịa ihe ndị ọzọ fọdụrụ na ya iji gaa n'aka nri.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Nri ngọngọ na-anọgide.
        // Bugharịa ya fọdụrụ nke na-iji ọcha na nnọọ aka ekpe.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ọ dịghị ihe ọzọ ị ga-eme, anyị agwụla.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` n'ime ọcha nta karịa `v[pivot]`, sochiri ọcha ukwuu karịa ma ọ bụ hà `v[pivot]`.
///
///
/// Alaghachi a tuple nke:
///
/// 1. Ọnụ ọgụgụ nke ihe ndị pekarịrị `v[pivot]`.
/// 2. Ezi ma ọ bụrụ na `v` ama partitioned.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Debe pivot na mbido iberi.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Gụọ ihe ndị na pivot n'ime a tojupụtara-ekenyela agbanwe maka arụmọrụ.
        // Ọ bụrụ na a na-esonụ tụnyere ọrụ panics, na pivot ga-akpaghị aka dere azụ n'ime iberi.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Chọta ụzọ mbu nke ihe na-adị n`usoro.
        let mut l = 0;
        let mut r = v.len();

        // Nchedo: Nchekwa dị n'okpuru ebe a gụnyere ịkọwa ọtụtụ usoro.
        // N'ihi na nke mbụ otu: Anyị na-ama-eme ókè achọpụta ebe a na `l < r`.
        // N'ihi na nke abụọ otu: Anyị ibido nwere `l == 0` na `r == v.len()` na anyị hụ na `l < r` na bụla indexing ọrụ.
        //                     Site n'ebe a na anyị maara na `r` ga-dịkarịa ala `r == l` nke e gosiri-nti si onye mbụ.
        unsafe {
            // Chọta mbụ mmewere ukwuu karịa ma ọ bụ hà pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Chọta ihe ikpeazụ ga-adị obere karịa.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` na-aga nke akporo na-ede pivot (nke bụ a tojupụtara-ekenyela agbanwe) azụ n'ime iberi ebe ọ mbụ bụ.
        // Nzọụkwụ a dị oke mkpa n'ịhụ nchekwa!
        //
    };

    // Debe pivot n`etiti nkewa abuo.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Nkebi `v` n'ime ihe hà nhata `v[pivot]` na-esote ihe ndị karịrị `v[pivot]`.
///
/// Weghachite onu ogugu nke ihe ndi ozo hapuru.
/// Ọ na-chere na `v` anaghị nwere ọcha nta karịa pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Debe pivot na mbido iberi.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Gụọ ihe ndị na pivot n'ime a tojupụtara-ekenyela agbanwe maka arụmọrụ.
    // Ọ bụrụ na a na-esonụ tụnyere ọrụ panics, na pivot ga-akpaghị aka dere azụ n'ime iberi.
    // NCHEKWA: The pointer ebe a bụ nti n'ihi na ọ bụ nke enwetara site n'izo aka a iberi.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ugbu a, nkebi nke iberi.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // Nchedo: Nchekwa dị n'okpuru ebe a gụnyere ịkọwa ọtụtụ usoro.
        // N'ihi na nke mbụ otu: Anyị na-ama-eme ókè achọpụta ebe a na `l < r`.
        // N'ihi na nke abụọ otu: Anyị ibido nwere `l == 0` na `r == v.len()` na anyị hụ na `l < r` na bụla indexing ọrụ.
        //                     Site n'ebe a na anyị maara na `r` ga-dịkarịa ala `r == l` nke e gosiri-nti si onye mbụ.
        unsafe {
            // Chọta ihe izizi buru ibu karịa isi.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Chọta ihe ikpeazụ ga-enyere aka.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Anyi emeela?
            if l >= r {
                break;
            }

            // Gbanye ihe achọtara nke ihe na-adị n'usoro.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Anyị hụrụ `l` ọcha hà pivot.Tinye 1 na akaụntụ maka pivot n'onwe ya.
    l + 1

    // `_pivot_guard` na-aga nke akporo na-ede pivot (nke bụ a tojupụtara-ekenyela agbanwe) azụ n'ime iberi ebe ọ mbụ bụ.
    // Nzọụkwụ a dị oke mkpa n'ịhụ nchekwa!
}

/// Na-agbasasị ụfọdụ ihe dị iche iche na mbọ iji mebie usoro nke nwere ike ibute nkebi na-ezighi ezi na ngwa ngwa.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nọmba jenerato sitere na akwụkwọ "Xorshift RNGs" nke George Marsaglia dere.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Were random nọmba modulo a nọmba.
        // Nọmba ahụ dabara na `usize` n'ihi na `len` adịghị karịa `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Fọdụ ndị na-azọ ndụ dị mkpa ga-anọ nso na ndepụta a.Ka anyi hapu ha.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // N'ịwa nọmba modulo `len`.
            // Otú ọ dị, iji zere oké ọnụ arụmọrụ mbụ anyị were ya modulo a ike nke abụọ, na mgbe ahụ ibelata site `len` ruo mgbe ọ na-adaba n'ime nso `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` na-ekwe nkwa na-erughị `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Ahọrọ a pivot na `v` na-alaghachi na index na `true` ma ọ bụrụ na iberi yiri ama ota.
///
/// Element na `v` enwere ike ịhazigharị usoro ahụ.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ogologo kachasị ịhọrọ usoro etiti na etiti.
    // Mpekere dị mkpụmkpụ na-eji usoro dị n'etiti na nke atọ.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Ọnụ ọgụgụ kachasị swaps nwere ike ịrụ na ọrụ a.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Atọ atọ dị nso nke anyị ga-ahọrọ pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Adabere ngụkọta ọnụ ọgụgụ nke swaps anyị banyere ịrụ mgbe sorting indices.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps indices ka `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps indices ka `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Chọta etiti nke `v[a - 1], v[a], v[a + 1]` ma chekwaa ndeksi na `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Chọta ndị agbata obi na agbata obi `a`, `b`, na `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Chọta etiti n'etiti `a`, `b`, na `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Emere ọnụ ọgụgụ kacha elu nke swaps.
        // Ohere inweta bụ iberi na-agbadata ma ọ bụ na-agbadata, yabụ iweghachite ga-enyere aka idozi ya ngwa ngwa.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Na-ahọrọ `v` recursively.
///
/// Ọ bụrụ na iberi nwere a ụzọ na mbụ n'usoro, ọ na-kpọmkwem dị ka `pred`.
///
/// `limit` bụ ọnụ ọgụgụ nke ndị kwere imbalanced partitions tupu ịmafe `heapsort`.
/// Ọ bụrụ n `efu, ọrụ a ga-agbanwe ozugbo.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mpekere nke ruo a n'ogologo esi ota iji ntinye ụdị.
    const MAX_INSERTION: usize = 20;

    // Ọ bụ eziokwu ma ọ bụrụ na njedebe nke ikpeazụ agakọghị nke ọma.
    let mut was_balanced = true;
    // Ezi ma ọ bụrụ na ndị ikpeazụ partitioning emeghị ịkpọgharịa ọcha (iberi ama partitioned).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Enwere mkpụmkpụ mkpụmkpụ dị mkpụmkpụ site na iji ụdị ntinye.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Y`oburu na eme otutu ihe di nkpa, gha la azu la ala iji kwado ihe kachasi njo nke `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ọ bụrụ na nkewa ikpeazụ enweghị aha abụọ, gbalịa imebi usoro na iberi ahụ site na ị gbanye ụfọdụ ihe gburugburu.
        // Enwere olile anya na anyi ga ahọrọ akara di nma n`oge a.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Họrọ pivot ma nwaa ịkọwa ma e meziela iberi ahụ.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ọ bụrụ na nkebi ikpeazụ ahụ gbasiri ike nke ọma ma ghara ịmegharị ihe, ọ bụrụ na nhọrọ dị oke mkpa buru amụma na iberi a nwere ike ịhazi ya ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Gbalịa ịmata ọtụtụ usoro na-adịghị n'usoro ma gbanwee ha iji dozie ọnọdụ.
            // Ọ bụrụ na iberi agwụ elu ịbụ kpamkpam ota, anyị na-mere.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ọ bụrụ na a họọrọ pivot bụ hà ụzọ, mgbe ọ bụ ndị kasị nta na mmewere na iberi.
        // Nkebi iberi n'ime ọcha hà na ọcha ukwuu karịa pivot.
        // A na-akụkarị ikpe a mgbe iberi ahụ nwere ọtụtụ ihe abụọ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nọgide na-eme ka ihe dị iche iche karịa isi ya.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Nkebi nke iberi.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Kewaa iberi ahụ na `left`, `pivot`, na `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse n'ime mkpumkpu n'akụkụ naanị iji belata ọnụ ọgụgụ nke recursive oku na-ewe obere tojupụtara ohere.
        // Mgbe ahụ dị nnọọ anọgide na-eji ogologo n'akụkụ (na nke a bụ akin ka ọdụ recursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sort `v` na-eji ngwa-mmeri ngwa ngwa, nke bụ *O*(*n*\*log(* n*)) kasị njọ.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sorting enweghị omume bara uru na ụdị nha efu.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Debe ọnụọgụ nke nkewa ahaghị na `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // N'ihi na Mpekere nke ruo a ogologo na ọ bụ eleghị anya, ngwa ngwa nanị ụdị ha.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Họrọ pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Ọ bụrụ na a họọrọ pivot bụ hà ụzọ, mgbe ọ bụ ndị kasị nta na mmewere na iberi.
        // Nkebi iberi n'ime ọcha hà na ọcha ukwuu karịa pivot.
        // A na-akụkarị ikpe a mgbe iberi ahụ nwere ọtụtụ ihe abụọ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ọ bụrụ na anyị agafeela ndepụta anyị, mgbe ahụ anyị dị mma.
                if mid > index {
                    return;
                }

                // Ma ọ bụghị ya, na-sorting ọcha ukwuu karịa pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Kewaa iberi ahụ na `left`, `pivot`, na `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ọ bụrụ na afọ==index, mgbe ahụ anyị na-mere, ebe ọ bụ na partition() na-ekwe nkwa na ndị niile ọcha mgbe afọ karịrị ma ọ bụ tụnyere ka ufọt.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sorting enweghị omume bara uru na ụdị nha efu.Emela ihe ọ bụla.
    } else if index == v.len() - 1 {
        // Chọta ihe kachasị ma tinye ya n'ọnọdụ ikpeazụ nke usoro ahụ.
        // Anyị enwere ike iji `unwrap()` ebe a n'ihi na anyị maara na v agaghị abụ ihe efu.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Chọta ihe mmewere ma debe ya n'ọnọdụ mbụ nke usoro ahụ.
        // Anyị enwere ike iji `unwrap()` ebe a n'ihi na anyị maara na v agaghị abụ ihe efu.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}