//! Ọrụ na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Nyochaa ọ bụrụ na bytes niile na mpempe akwụkwọ a dị na ọkwa ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Nyochaa na mpekere abụọ bụ egwuregwu ASCII na-enweghị isi.
    ///
    /// Otu dị ka `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mana na-enweghị ekenye na ịdegharị oge.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Atọghata a iberi ya ASCII elu ikpe Ẹkot na-ebe.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'a' na 'z' na 'A' na 'Z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji weghachite akara ọhụrụ akụrụngwa na-enweghị ịgbanwe nke dị ugbu a, jiri [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Atọghata a iberi ya ASCII obere okwu Ẹkot na-ebe.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'A' na 'Z' na 'a' na 'z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji weghachi uru dị ala ọzọ na-enweghị imezi nke dị ugbu a, jiri [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Laghachi `true` ma ọ bụrụ na byte na okwu `v` bụ nonascii (>=128).
/// Snarfed si `../str/mod.rs`, nke na-eme ihe yiri nke ahụ maka nkwado utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Kachasị ascii ule ga-eji usize-na-a-oge arụmọrụ kama byte-na-a-oge arụmọrụ (mgbe o kwere omume).
///
/// Algọridim anyị na-eji ebe a dị mfe.Ọ bụrụ na `s` bụ mkpụmkpụ, anyị dị nnọọ elele bụla byte na-eme na ya.Ma ọ bụghị:
///
/// - Jiri okwu a na-akwadoghị gụọ okwu mbụ.
/// - Mmezi nke pointer, na-agụ ụdi okwu ruo mgbe ọgwụgwụ na kwekọọ ibu.
/// - Gụọ `usize` nke ikpeazụ site na `s` nwere ibu a na-ahaghị.
///
/// Ọ bụrụ na nke ọ bụla n'ime ibu ndị a na-emepụta ihe nke `contains_nonascii` (above) laghachiri n'eziokwu, mgbe ahụ anyị maara azịza ya bụ ụgha.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ọ bụrụ na anyị agaghị enweta ihe ọ bụla site na ntinye-na-a-oge mmejuputa, dahachi azụ azụ.
    //
    // Anyị na-emekwa nke a maka ụlọ ebe `size_of::<usize>()` na-ezighi ezi maka `usize`, n'ihi na ọ bụ okwu edge dị egwu.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Anyị na-agụ okwu mbu unaligned, nke pụtara `align_offset` bụ
    // 0, anyị ga-agụ otu uru ọzọ maka kwekọọ agụ.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: Anyị nyochaa `len < USIZE_SIZE` n'elu.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Anyị enyochare nke a n'elu, n'ụzọ doro anya.
    // Mara na `offset_to_aligned` bụ `align_offset` ma ọ bụ `USIZE_SIZE`, a na-enyocha ha abụọ n'ụzọ doro anya n'elu.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr bu (ejizi kwesiri) adabara ptr anyi ji agu ya
    // nkebi nke iberi.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` bụ byte ndeksi nke `word_ptr`, eji maka akaghị ọgwụgwụ ndenye ego.
    let mut byte_pos = offset_to_aligned;

    // Paranoia ịlele banyere itinye n'ọnọdụ, ebe anyị na-achọ ime ụyọkọ nke ibu ndị a na-ahaghị.
    // Na omume a kwesịrị-agaghị ekwe omume barring a ahụhụ `align_offset` ezie na.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Gụọ ụdi okwu ruo mgbe ikpeazụ kwekọọ okwu, ewepu ikpeazụ kwekọọ okwu site n'onwe ya ka a mere na ọdụ ego mgbe e mesịrị, iji hụ na ọdụ bụ mgbe otu `usize` na kacha extra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity ego na-agụ bụ ókè
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Na na echiche anyị banyere `byte_pos` jidere.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: Anyị maara na `word_ptr` dabara nke ọma (n'ihi
        // ``align_offset`), ma anyị maara na anyị nwere oke bytes n'etiti `word_ptr` na njedebe
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Anyị maara na `byte_pos <= len - USIZE_SIZE`, nke pụtara na
        // mgbe `add` a gasịrị, `word_ptr` ga-anọ na otu njedebe gafere.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity ego iji hụ na ọ bụ naanị otu `usize` fọdụrụ.
    // Nke a kwesiri ikwe nkwa site na akuku anyi.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: Nke a dabere na `len >= USIZE_SIZE`, nke anyị na-enyocha na mbido.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}