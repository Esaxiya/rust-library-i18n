//! Ọrụ n'efu iji mepụta `&[T]` na `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Msdi a iberi si pointer na ogologo.
///
/// Mkparịta ụka `len` bụ ọnụọgụ nke **ihe**, ọ bụghị ọnụọgụ nke bytes.
///
/// # Safety
///
/// A na-akọwaghị omume ma ọ bụrụ na e mebie nke ọ bụla n'ime ọnọdụ ndị a:
///
/// * `data` ga-abụ [valid] maka agụ maka `len * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
///
///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.Hụ [below](#incorrect-usage) maka ọmụmaatụ atụghị nke a na-etinyeghị na akaụntụ.
///     * `data` ga-abụrịrị ihe efu ma kwekọọ ọbụlagodi iberibe ogologo-efu.
///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
///
/// * `data` ga-arụtụ aka na `len` usoro ejizi mmalite nke ụdị `T`.
///
/// * The ebe nchekwa referenced site laghachi iberi gaghị mutated maka oge nke ndụ `'a`, ma e wezụga n'ime otu `UnsafeCell`.
///
/// * Mkpokọta `len * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
///
/// # Caveat
///
/// Oge ndụ maka iberi iberi inferred si ojiji.
/// Iji gbochie iji ihe ọghọm eme ihe na mberede, a na-atụ aro ka ijikọ ndụ gị na ebe ndụ ọ bụla nwere nchekwa na ọnọdụ, dịka site n'inye ọrụ inyeaka na-eji ndụ nke onye ọbịa bara uru maka iberi ahụ, ma ọ bụ site na nkọwa doro anya.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // gosipụta iberi maka otu mmewere
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Ezighi ezi ojiji
///
/// Ọrụ `join_slices` na-esonụ bụ **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Nkwupụta ahụ dị n'elu na-eme ka o doo anya na `fst` na `snd` dị iche iche, mana ha ka nwere ike ịdị n'ime _different allocated objects_, ebe ọ bụ na imepụta mpempe a bụ agwa enweghị nkọwa.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` na `b` dị iche iche ekenyela ihe ...
///     let a = 42;
///     let b = 27;
///     // ... nke nwere ike-o ga-ẹkenịm contiguously na ebe nchekwa: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Na-arụ otu ọrụ ahụ dị ka [`from_raw_parts`], belụsọ na eweghachitere iberi ntụgharị.
///
/// # Safety
///
/// A na-akọwaghị omume ma ọ bụrụ na e mebie nke ọ bụla n'ime ọnọdụ ndị a:
///
/// * `data` ga-abụ [valid] maka ịgụ ma na-ede maka `len * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
///
///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.
///     * `data` ga-abụrịrị ihe efu ma kwekọọ ọbụlagodi iberibe ogologo-efu.
///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
///
///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
///
/// * `data` ga-arụtụ aka na `len` usoro ejizi mmalite nke ụdị `T`.
///
/// * Enweghi ike inweta ebe nchekwa a nke ederede a laghachiri site na pointer ozo obula (nke enwetaghi site na nloghachi) rue oge nke ndu `'a`.
///   Amachibidoro ma ịgụ ma banye ide.
///
/// * Mkpokọta `len * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Na-atụgharị aka na T n'ime iberi nke ogologo 1 (na-enweghị i copomi).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Na-atụgharị aka na T n'ime iberi nke ogologo 1 (na-enweghị i copomi).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}