//! Traits maka tọghatara n'etiti ụdị.
//!
//! traits na modul a na-enye ụzọ iji gbanwee site na otu ụdị gaa na ụdị ọzọ.
//! Onye ọ bụla trait na-eje ozi a dị iche iche na nzube:
//!
//! - Mejuputa [`AsRef`] trait maka ọnụ ala akwụkwọ-to-akwụkwọ tọghatara
//! - Mejuputa [`AsMut`] trait maka ọnụ ala mutable-to-mutable tọghatara
//! - Mejuputa [`From`] trait maka iwere ntughari bara uru
//! - Mejuputa [`Into`] trait maka ewe uru-na-uru tọghatara gaa ụdị n'èzí na nke ugbu a crate
//! - [`TryFrom`] na [`TryInto`] traits na-akpa agwa dị ka [`From`] na [`Into`], mana ekwesịrị itinye ya n'ọrụ mgbe ntụgharị nwere ike ịda.
//!
//! The traits a modul na-eji dị ka trait bounds maka ọnyà ọrụ ndị dị otú ahụ na arụmụka nke multiple ụdị na-akwado.Hụ ndetu nke ọ bụla trait maka ihe atụ.
//!
//! Dị ka onye na-ede akwụkwọ ọbá akwụkwọ, ị ga-ahọrọ mgbe niile imejuputa [`From<T>`][`From`] ma ọ bụ [`TryFrom<T>`][`TryFrom`] karịa [`Into<U>`][`Into`] ma ọ bụ [`TryInto<U>`][`TryInto`], dị ka [`From`] na [`TryFrom`] na-enye mgbanwe dị ukwuu ma na-enye mmeju mmekorita [`Into`] ma ọ bụ [`TryInto`] n'efu, na-ekele otu ihe mkpuchi blanket na ọbá akwụkwọ ọkọlọtọ.
//! Mgbe ezubere iche a version tupu Rust 1.41, ọ pụrụ ịbụ na ọ dị mkpa iji mejuputa [`Into`] ma ọ bụ [`TryInto`] ozugbo mgbe n'ịtụgharị ka a ụdị n'èzí na nke ugbu a crate.
//!
//! # ọnyà Implementations
//!
//! - [`AsRef`] na [`AsMut`] auto-dereference ma ọ bụrụ na ime ụdị bụ a akwụkwọ
//! - ['' Site`]`` <U>n'ihi na T 'pụtara [' 'n'ime'] '</u><T><U>maka U`</u>
//! - (``TryFrom`] '' <U>n'ihi na T`pụtara [`` TryInto`] ''</u><T><U>maka U`</u>
//! - [`From`] na [`Into`] bụ amara, nke pụtara na ihe nile ụdị nwere ike `into` onwe ha na `from` onwe ha
//!
//! Lee onye ọ bụla trait maka ojiji ihe atụ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// The njirimara ọrụ.
///
/// Ihe abụọ dị mkpa ka dee banyere ọrụ a:
///
/// - Ọ na-abụkarị ihe mmechi dịka `|x| x`, ebe ọ bụ na mmechi ahụ nwere ike ịmanye `x` n'ụdị dị iche.
///
/// - Ọ na-akpali ndị input `x` ebe ọrụ.
///
/// Mgbe ọ pụrụ iyi iju nwere a ọrụ na dị nnọọ alaghachi azụ ndenye, e nwere ụfọdụ na-akpali ojiji.
///
///
/// # Examples
///
/// Iji `identity` ime ihe ọ bụla na a usoro nke ndị ọzọ, na-akpali, ọrụ:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ka anyị hà na-agbakwunye na otu onye bụ ihe na-akpali ọrụ.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Iji `identity` ka a "do nothing" isi bụrụ na a nhazi:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ime ihe na-akpali stof ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Iji `identity` na-`Some` variants nke ihe iterator nke `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Na-eme a ọnụ ala akwụkwọ-to-akwụkwọ akakabarede.
///
/// Nke a trait yiri [`AsMut`] nke na-eji maka n'ịtụgharị n'etiti mutable zoro.
/// Ọ bụrụ na ịchọrọ ịme mgbanwe dị oke ọnụ ọ ka mma iji mejuputa [`From`] na ụdị `&T` ma ọ bụ dee ọrụ omenala.
///
/// `AsRef` nwere otu mbinye aka dị ka [`Borrow`], mana [`Borrow`] dị iche n'akụkụ ole na ole:
///
/// - N'adịghị ka `AsRef`, [`Borrow`] nwere blanket impl maka `T` ọ bụla, enwere ike iji ya nabata ma ọ bụ ntụnye ma ọ bụ uru.
/// - [`Borrow`] na-achọkwa na [`Hash`], [`Eq`] na [`Ord`] maka ego agbaziri ego bụ nke ndị nwere uru.
/// N'ihi nke a, ma ọ bụrụ na ị chọrọ gbaziri naanị otu ubi nke a struct i nwere ike ime eme `AsRef`, ma ọ bụghị [`Borrow`].
///
/// **Note: trait a agaghị ada ada **.Ọ bụrụ na ntughari nwere ike ida, na-eji a raara onwe ya nye usoro nke na-alaghachi ihe [`Option<T>`] ma ọ bụ a [`Result<T, E>`].
///
/// # ọnyà Implementations
///
/// - `AsRef` auto-dereferences ma ọ bụrụ na ime ụdị bụ a akwụkwọ ma ọ bụ a mutable akwụkwọ (eg: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Site na iji trait bounds anyị pụrụ ịnakwere arụmụka nke dị iche iche dị ka ogologo oge ka ha nwere ike ghọrọ ka kpọmkwem ụdị `T`.
///
/// Dị ka ihe atụ: Site eke a ọnyà ọrụ na-ewe ihe `AsRef<str>` anyị na-egosipụta na anyị na-chọrọ ịnabata niile zoro na pụrụ ghọrọ ka [`&str`] ka esemokwu.
/// Ebe ọ bụ na [`String`] na [`&str`] na-emejuputa `AsRef<str>` anyị nwere ike ịnabata ha dị ka esemokwu ndenye.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Anamde akakabarede.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Na-eme a ọnụ ala mutable-to-mutable akwụkwọ akakabarede.
///
/// Nke a trait yiri [`AsRef`] ma na-eji maka n'ịtụgharị n'etiti mutable zoro.
/// Ọ bụrụ na ị chọrọ ime na a oké ọnụ akakabarede na ọ bụ mma iji mejuputa [`From`] na ụdị `&mut T` ma ọ bụ dee a omenala ọrụ.
///
/// **Note: trait a agaghị ada ada **.Ọ bụrụ na ntughari nwere ike ida, na-eji a raara onwe ya nye usoro nke na-alaghachi ihe [`Option<T>`] ma ọ bụ a [`Result<T, E>`].
///
/// # ọnyà Implementations
///
/// - `AsMut` auto-dereferences ma ọ bụrụ na ime ụdị bụ a mutable akwụkwọ (eg: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Iji `AsMut` ka trait bound maka a ọnyà ọrụ anyị pụrụ ịnakwere niile mutable zoro na pụrụ ghọrọ ka pịnye `&mut T`.
/// Maka [`Box<T>`] na-eme `AsMut<T>` anyị nwere ike ide `add_one` ọrụ nke na-ewe arụmụka niile enwere ike ịgbanwe na `&mut u64`.
/// N'ihi [`Box<T>`] implements `AsMut<T>`, `add_one` anabata arụmụka nke ụdị `&mut Box<u64>` nakwa:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Anamde akakabarede.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// A uru-na-uru akakabarede na-erepịakwa ndị input uru.Ndị na-abụghị nke [`From`].
///
/// Otu kwesịrị izere mmejuputa [`Into`] ma mejuputa [`From`] kama.
/// Mmejuputa [`From`] na-akpaghị aka na-enye onye na-mmejuputa [`Into`] ekele na blanket, mmejuputa iwu-na ọkọlọtọ n'ọbá akwụkwọ.
///
/// Na-ahọrọ iji [`Into`] karịa [`From`] mgbe ị na-akọwa trait bounds na ọrụ ọnụọgụ iji hụ na a ga-ejikwa ụdị ndị na-emejuputa [`Into`] naanị.
///
/// **Note: Nke a trait ghaghị **.Ọ bụrụ na ntughari nwere ike ada, iji [`TryInto`].
///
/// # ọnyà Implementations
///
/// - ['From`]'<T>maka U` pụtara `Into<U> for T`
/// - [`Into`] dị nkọ, nke pụtara na etinyere `Into<T> for T`
///
/// # Imejuputa [`Into`] maka ntughari gaa na ụdị di na mpụga na ụdị ochie nke Rust
///
/// Tupu Rust 1.41, ma ọ bụrụ na ebe ụdị bụ akụkụ nke ugbu a crate mgbe ị na-apụghị ime eme [`From`] ozugbo.
/// Dịka ọmụmaatụ, were koodu a:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Nke a ga-ada ka ide na okenye na nsụgharị nke asụsụ n'ihi Rust si orphaning iwu na-eji na-a ntakịrị ihe ike.
/// Iji gafere nke a, ịnwere ike itinye [`Into`] ozugbo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ekwesiri ighota na [`Into`] enyeghi ntinye [`From`] (dika [`From`] na [`Into`]).
/// Yabụ, ị ga-anwa ime ihe [`From`] mgbe niile wee laghachi na [`Into`] ma ọ bụrụ na enweghị ike itinye [`From`] n'ọrụ.
///
/// # Examples
///
/// [`String`] mejuputa [``Into`] `<` [``Vec`] `<` [``u8`] '' >>: :
///
/// Iji gosipụta na anyị chọrọ ọrụ ọnyà iji were arụmụka niile enwere ike ịgbanwe gaa na ụdị `T` akọwapụtara, anyị nwere ike iji trait bound nke [``Into`] ''<T>``.
///
/// Dị ka ihe atụ: Ndị ọrụ `is_hello` ewe niile arụmụka na ike ga-converted n'ime a ['Vec`]' <'[' u8`] '>'.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Anamde akakabarede.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Na-eme uru-na-uru tọghatara mgbe irepịa input uru.Ọ bụ mmegwara nke [`Into`].
///
/// Mmadu kwesiri igbalite mmejuputa `From` karia [`Into`] n'ihi na imejuputa `From` na-enye mmadu ihe mmezi nke [`Into`] site na ntinye blanket na oba akwukwo.
///
///
/// Naanị mejuputa [`Into`] mgbe ị na-eche ụdị nke tupu Rust 1.41 ma gbanwee n'ụdị dị na mpụga crate ugbu a.
/// `From` enweghị ike ịme ụdị mgbanwe ndị a na nsụgharị ndị mbụ n'ihi iwu ụmụ mgbei Rust.
/// Hụ [`Into`] maka nkọwa ndị ọzọ.
///
/// Na-ahọrọ iji [`Into`] karịa iji `From` mgbe ị na-akọwa trait bounds na ọrụ ọrụ.
/// Nke a ụzọ, na ụdị na ozugbo mejuputa [`Into`] ike ga-eji dị ka arụmụka dị ka mma.
///
/// The `From` bụkwa nnọọ uru mgbe n'ịrụ njehie njikwa.Mgbe iwu a ọrụ na bụ ike nke na-adịkwaghị, nloghachi ụdị ga n'ozuzu-nke n'ụdị `Result<T, E>`.
/// The `From` trait simplifies njehie ejizi site n'ikwe a ọrụ laghachi otu njehie ụdị na encapsulate multiple njehie ụdị.Lee "Examples" ngalaba na [the book][book] maka nkọwa ndị ọzọ.
///
/// **Note: trait a agaghị ada ada **.Ọ bụrụ na ntughari nwere ike ịda, jiri [`TryFrom`].
///
/// # ọnyà Implementations
///
/// - `From<T> for U` pụtara [``o]] <U>maka T`</u>
/// - `From` bụ amara, nke pụtara na `From<T> for T` na-emejuputa atumatu
///
/// # Examples
///
/// [`String`] mejuputa `From<&str>`:
///
/// An doro akakabarede si a `&str` ka a eriri na-eme ka ndị a:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Mgbe na-eme na njehie-ejizi ọ bụ mgbe ọ bara uru iji mejuputa `From` maka gị onwe gị njehie ụdị.
/// Site na ịtụgharị ụdị njehie na-ezighị ezi na ụdị njehie nke anyị nke na-ekpuchi ụdị njehie na-akpata, anyị nwere ike weghachite otu ụdị njehie na-enweghị tufuo ozi na ihe kpatara kpatara.
/// Onye ọrụ '?' na-atụgharị ụdị ụdị njehie na-akpaghị aka na ụdị njehie omenala anyị site na ịkpọ `Into<CliError>::into` nke a na-enye na-akpaghị aka mgbe ị na-emejuputa `From`.
/// The compiler mgbe infers nke mmejuputa `Into` ga-eji.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Anamde akakabarede.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Mgbalị a nwara nke na-erepịa `self`, nke nwere ike ọ gaghị adị oke ọnụ.
///
/// Ndị na-ede akwụkwọ na-agụkarị anaghị emezigharị trait a, mana ha ga-ahọrọ itinye [`TryFrom`] trait n'ọrụ, nke na-enye mgbanwe ka ukwuu ma na-enye ihe ntinye `TryInto` nha n'efu, n'ihi ntinye blanket na ọbá akwụkwọ ọkọlọtọ.
/// Maka ozi ọzọ banyere nke a, na-ahụ akwụkwọ maka [`Into`].
///
/// # Mmejuputa `TryInto`
///
/// Nke a nwere otu mgbochi na ntụgharị uche dịka mmejuputa [`Into`], lee ebe ahụ maka nkọwa.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// The ụdị laghachi na ihe omume nke a akakabarede njehie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Anamde akakabarede.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple na mma ụdị tọghatara na pụrụ ịla a na-achịkwa ụzọ n'ọnọdụ ụfọdụ.Ọ bụ mmegwara nke [`TryInto`].
///
/// Nke a bụ bara uru mgbe ị na-eme a ụdị akakabarede na ike trivially ọma ma nwekwara ike mkpa pụrụ iche njikwa.
/// Ka ihe atụ, ọ dịghị ụzọ iji tọghata otu [`i64`] n'ime ihe [`i32`] iji [`From`] trait, n'ihi na ihe [`i64`] nwere ike ịnwe a uru na ihe [`i32`] ike na-anọchi anya na otú ahụ ka akakabarede ga-ejighi data.
///
/// Enwere ike idozi nke a site na ịpị [`i64`] na [`i32`] (nke na-enye uru modulo [`i32::MAX`]) ma ọ bụ naanị laghachite [`i32::MAX`], ma ọ bụ site na usoro ọzọ.
/// Ejiri [`From`] trait maka ntughari zuru oke, ya mere `TryFrom` trait na-agwa onye na-eme ihe omume ahụ mgbe ụdị ntụgharị nwere ike ịba uru ma hapụ ha ka ha kpebie otu esi edozi ya.
///
/// # ọnyà Implementations
///
/// - `TryFrom<T> for U` na-egosi ['TryInto`]' <U>maka T`</u>
/// - [`try_from`] bụ amara, nke pụtara na `TryFrom<T> for T` na-emejuputa atumatu na-apụghị ịda ada-metụtara `Error` ụdị maka akpọ `T::try_from()` on a uru nke ụdị `T` bụ [`Infallible`].
/// Mgbe [`!`] ụdị na-Nọsi'ike [`Infallible`] na [`!`] ga-Ẹkot.
///
/// `TryFrom<T>` nwere ike mejuputa atumatu dika ndi a:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Dị ka akọwara, [`i32`] na-etinye ``TryFrom <'' (`` 64 '')>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Na-eji nwayọ truncates `big_number`, chọrọ ịchọpụta na ijikwa truncation ahụ mgbe emechara ihe ahụ.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Alaghachi njehie n'ihi `big_number` bụ oke ibu dabara na `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Alaghachi `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// The ụdị laghachi na ihe omume nke a akakabarede njehie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Anamde akakabarede.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ọnyà IMPLS
////////////////////////////////////////////////////////////////////////////////

// Dị ka lifts n'elu&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Dị ka na-ebuli n'elu &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): dochie n'elu impls maka&/&mut na ndị na-esonụ ọzọ n'ozuzu otu:
// // Dị ka ọ na-ebuli n'elu Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>maka D {FN as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut buliri ihe karịrị &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): dochie n'elu impl maka &mut na ndị na-esonụ ọzọ n'ozuzu otu:
// // AsMut lifts n'elu DerefMut
// pụtara <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>maka D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Site na-egosi Na
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Site (ma si otú n'ime) bụ amara
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Kwụsie dee:** a impl anaghị ma adị, ma anyị bụ ndị "reserving space" ịgbakwunye ya na future.
/// Lee [rust-lang/rust#64715][#64715] maka nkọwa.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ime a ụkpụrụ na-eduzi fix kama.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom na-egosi TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// - Adịghị agha agha tọghatara ndị semantically Ẹkot ikom na-ezughị tọghatara na ihe n'enweghị onye bi na njehie ụdị.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ihe IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// IHE NO-njehie njehie Ụdị
////////////////////////////////////////////////////////////////////////////////

/// Errordị njehie maka njehie nke na-enweghị ike ime.
///
/// Ebe ọ bụ na a enum nwere dịghị variant, a bara uru nke ụdị ike mgbe n'ezie adị.
/// Nke a nwere ike ịba uru maka API niile na-eji [`Result`] ma dozie ụdị njehie ahụ, iji gosi na nsonaazụ ya bụ [`Ok`] mgbe niile.
///
/// Ka ihe atụ, [`TryFrom`] trait (akakabarede na-alaghachi a [`Result`]) nwere a blanket, mmejuputa iwu niile ụdị ebe a reverse [`Into`] mmejuputa iwu dị.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ndakọrịta Future
///
/// Nke a enum nwere otu ọrụ dị ka [the `!`“never”type][never], nke bụ ejighị n'aka na nke a version of Rust.
/// Mgbe `!` na-Nọsi'ike, anyị na-eme atụmatụ iji mee ka `Infallible` a ụdị utu aha ya:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ma mechaa depulata `Infallible`.
///
/// Otú ọ dị, e nwere otu ikpe ebe `!` syntax ike ga-eji tupu `!` na-Nọsi'ike dị ka a na-fledged ụdị: na ọnọdụ nke a ọrụ nloghachi ụdị.
/// Kpọmkwem, ọ ga-ekwe omume mmejuputa iwu maka ọrụ abụọ dị iche iche dị iche iche:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Na `Infallible` ịbụ onye enum, a koodu bụ nti.
/// Agbanyeghị mgbe `Infallible` ghọrọ aha utu aha maka never type, ihe abụọ ahụ a ga-amalite ga-amalite ịbịakọta ma ya mere iwu nkwekọrịta nke trait ga-ajụ ya.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}