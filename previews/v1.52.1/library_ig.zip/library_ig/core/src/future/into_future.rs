use crate::future::Future;

/// Ntughari n'ime `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// The mmepụta na future ga-emepụta na ẹkụre.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Nke ụdị future na-anyị na-atụgharị nke a n'ime?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Mepụta future site na uru.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}