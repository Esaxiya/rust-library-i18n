#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future na-anọchi anya ihe asynchronous mgbakọ.
///
/// future bụ uru nke nwere ike ọ gwụbeghị kọmpụta ma.
/// Nke a na ụdị "asynchronous value" eme ka o kwe a na eri na-anọgide na-eme bara uru ọrụ mgbe ọ na-echere maka uru adị dị.
///
///
/// # The `poll` usoro
///
/// Corezọ bụ isi nke future, `poll`,*na-anwa* iji dozie future ka ọ bụrụ uru ikpeazụ.
/// Usoro a anaghị egbochi ma ọ bụrụ na uru adịghị njikere.
/// Kama nke ahụ, a na-ahazi ọrụ dị ugbu a na-eteta mgbe ọ ga-ekwe omume inwekwu ọganihu site na `` ntuli aka ọzọ ''.
/// `context` gafere na usoro `poll` nwere ike inye [`Waker`], nke bụ njikwa maka ịkpọte ọrụ dị ugbu a.
///
/// Mgbe na-eji a future, ị n'ozuzu ga-akpọ `poll` ozugbo, ma kama `.await` uru.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Ofdị uru a rụpụtara na mmecha.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Agbali iji dozie future ka a ikpeazụ uru, ịdenye ugbu a ọrụ wakeup ma ọ bụrụ na uru bụ ma dị.
    ///
    /// # Laghachi uru
    ///
    /// Nke a ọrụ alaghachi:
    ///
    /// - [`Poll::Pending`] ma ọ bụrụ na future adịghị njikere ma
    /// - [`Poll::Ready(val)`] site na nsonaazụ `val` nke future a ma ọ bụrụ na ọ gwụchara nke ọma.
    ///
    /// Ozugbo future kwusịrị, ndị ahịa ekwesịghị `poll` ya ọzọ.
    ///
    /// Mgbe future adịghị njikere, `poll` laghachiri `Poll::Pending` ma chekwaa mmepụta oyiri nke [`Waker`] depụtaghachiri site na [`Context`] dị ugbu a.
    /// [`Waker`] a bụzị woken ozugbo future nwere ike inwe ọganiihu.
    /// Dịka ọmụmaatụ, future na-eche ka oghere dị ka ogugu ga-akpọ `.clone()` na [`Waker`] ma chekwaa ya.
    /// Mgbe a mgbaàmà abịarute n'ebe ọzọ na-egosi na anya bụ nke ogugu, [`Waker::wake`] a na-akpọ na anya future si ọrụ na-awoken.
    /// Ozugbo a ọrụ e woken elu, ọ ga-agbali iji `poll` na future ọzọ, nke nwere ike ma ọ na-emepụta a ikpeazụ uru.
    ///
    /// Cheta na na otutu oku `poll`, naanị [`Waker`] si [`Context`] ebe na-adịbeghị anya oku a ga-ndokwa na-enweta a wakeup.
    ///
    /// # Ihe omuma oge
    ///
    /// Futures naanị ya bụ *inert*;ha ga-abụrịrị 'ifịk ifịk' ``nghoputa '' iji nwee ọganiihu, nke pụtara na oge ọ bụla etinyere ọrụ dị ugbu a, ọ kwesịrị ịmaliteghachi`` mpịakọta '' na-echere futures na ọ ka nwere mmasị.
    ///
    /// A naghị akpọ ọrụ `poll` ugboro ugboro na akaghị aka-kama, ekwesịrị ịkpọ ya naanị mgbe future na-egosi na ọ dị njikere inwe ọganihu (site na ịkpọ `wake()`).
    /// Ọ bụrụ na ị na-emehe ye `poll(2)` ma ọ bụ `select(2)` syscalls on Unix ya si uru arịba ama na futures a-eme *bụghị* na-ata ahụhụ otu nsogbu nke "all wakeups must poll all events";ha dị ka `epoll(4)`.
    ///
    /// An mmejuputa `poll` kwesịrị ịgbalịsi laghachi ngwa ngwa, na-ekwesịghị igbochi.Laghachi ngwa ngwa na-egbochi igbochi eri na-enweghị isi ma ọ bụ ihe omume loops.
    /// Ọ bụrụ na ọ mara tupu oge na a oku ka `poll` ike ejedebe na-ewere awhile, ọrụ a ga-offloaded ka a na eri ọdọ mmiri (ma ọ bụ ihe yiri nke ahụ) iji hụ na `poll` ike ịlaghachi ngwa ngwa.
    ///
    /// # Panics
    ///
    /// Ozugbo future dechara (laghachiri `Ready` site na `poll`), na-akpọ usoro `poll` ya ọzọ nwere ike panic, gbochie ruo mgbe ebighi ebi, ma ọ bụ kpatara ụdị nsogbu ndị ọzọ;na `Future` trait nsị dịghị chọrọ na mmetụta nke ndị dị otú ahụ a na oku.
    /// Agbanyeghị, dịka usoro `poll` adịghị akara `unsafe`, iwu Rust na-adịkarị: oku ekwesịghị ime ka omume a na-akọwaghị (nrụrụ ncheta, iji ọrụ `unsafe` ezighi ezi, ma ọ bụ ihe ndị yiri ya), agbanyeghị steeti future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}