#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchronous ụkpụrụ.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Neededdị a chọrọ n'ihi na:
///
/// a) Generators enweghi ike ime ihe `for<'a, 'b> Generator<&'a mut Context<'b>>`, yabụ anyi kwesiri igafe pointer (lee <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw pointers na `NonNull` adịghị `Send` ma ọ bụ `Sync`, otú ga-eme ka ọ bụla otu future non-Send/Sync ka nke ọma, na anyị achọghị na.
///
/// Ọ na-simplifies HIR ẹsụhọde nke `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Kechie a generator na a future.
///
/// Ọrụ a na-alaghachikwuru a `GenFuture` n'okpuru, ma akpụkpọ ya na `impl Trait` inye mma njehie ozi (`impl Future` kama `GenFuture<[closure.....]>`).
///
// Nke a bụ `const` iji zere njehie ọzọ mgbe anyị gbakechara na `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Anyị na-adabere eziokwu na async/await futures bụ bụrụnụ ndị kwụ chịm iji ike onwe-referential agbaziri na kpatara generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // NCHEKWA: Safe n'ihi na anyị na !Unpin + !Drop, na nke a bụ nnọọ a ubi ntule.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Gbanyụọ generator, gbanwee `&mut Context` ka ọ bụrụ ihe pointer `NonNull`.
            // The `.await` ẹsụhọde ga n'enweghị igba na azụ a `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // NCHEKWA: nke bere kwesịrị nkwa na `cx.0` a bụ ezigbo pointer
    // na-emezu ihe niile ndị a chọrọ maka a mutable akwụkwọ.
    unsafe { &mut *cx.0.as_ptr().cast() }
}