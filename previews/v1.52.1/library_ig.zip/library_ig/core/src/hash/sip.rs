//! An mmejuputa SipHash.

#![allow(deprecated)] // ụdị ndị dị na modulu a adịghịzi mma

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// An mmejuputa SipHash 1-3.
///
/// Nke a bụ ugbu a na ndabere hashing ọrụ eji ọkọlọtọ n'ọbá akwụkwọ (eg, `collections::HashMap`-eji ya na ndabara).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// An mmejuputa SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// An mmejuputa SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash bụ a n'ozuzu-nzube hashing ọrụ: ọ na-agba na a ọma ọsọ (asọmpi na Spooky na City) na kwe ike _keyed_ hashing.
///
/// Nke a na-ahapụ gị igodo tebụl gị site na RNG siri ike, dị ka [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Ọ bụ ezie na SipHash algọridim-atụle ga-n'ozuzu ike, ọ na-abụghị maka ọgbàràùhie nzube.
/// Dị ka ndị dị otú ahụ, ihe niile ọgbàràùhie ojiji nke a, mmejuputa iwu-bụ _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // ole ogbe anyi jiri hazie
    state: State,  // hash State
    tail: u64,     // unprocessed bytes nwere ike
    ntail: usize,  // otele onodu n'ime odu di ire
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 na v1, v3-egosi na ụzọ abụọ na algọridim, na simd implementations nke SipHash ga-eji vectors nke v02 na v13.
    //
    // Site ịtụkwasị ha n'usoro a na struct, na compiler ike bulie na nanị ole na ole simd optimizations site n'onwe ya.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Ibu ihe integer nke chọrọ ụdị si a byte iyi, na LE iji.
/// Eji `copy_nonoverlapping` ka compiler n'ịwa kasị oru oma ụzọ iji mara ya site na a ikekwe unaligned address.
///
///
/// Nwedịrị ike ịta n'ihi: kpacharaghị indexing na i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Ibu a u64 iji ruo 7 bytes nke a byte iberi.
/// Ọ dị ka ntanye anya mana oku `copy_nonoverlapping` na-eme (site na `load_int_le!`) ha niile nwere nha edozi ma zere ịkpọ `memcpy`, nke dị mma maka ọsọ.
///
///
/// Enweghi nchebe n'ihi na: nyochaa ederede na mmalite..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // ugbu a byte index (site LSB) na mmepụta u64
    let mut out = 0;
    if i + 3 < len {
        // NCHEKWA: `i` ike-adị ukwuu karịa `len`, na nke bere kwesịrị nkwa
        // na ndeksi bidoro..start + len dị na oke.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // SAFETY: same as above.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // SAFETY: same as above.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Emepụta ọhụrụ `SipHasher` na abụọ mbụ igodo setịpụrụ na-0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Emepụta a `SipHasher` na-keyed kwụsịrị nyere igodo.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Emepụta ọhụrụ `SipHasher13` na abụọ mbụ igodo setịpụrụ na-0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Mepụta `SipHasher13` nke gbanyere igodo ya.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: dịghị integer hashing ụzọ ('write_u *', `write_i*`) na-kọwaa
    // maka ụdị a.
    // Anyị nwere ike tinye ha, detuo `short_write` mmejuputa na librustc_data_structures/sip128.rs, na tinye `write_u *`/`write_i*` ụzọ `SipHasher`, `SipHasher13`, na `DefaultHasher`.
    //
    // Nke a ga-ukwuu ọsọ integer hashing site ndị hashers, na-eri nke ubé selata ide gbapụrụ ọsọ na ụfọdụ benchmarks.
    // Hụ #69152 maka nkọwa.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // NCHEKWA: `cmp::min(length, needed)` na-ekwe nkwa na-adịghị na-elekọta `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Buffered odu ugbua flushed, hazie ihe ntinye ohuru.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // NCHEKWA: n'ihi `len - left` bụ nnukwu multiple nke 8 n'okpuru
            // `len`, na n'ihi na `i` malitere na `needed` ebe `len` bụ `length - needed`, `i + 8` na-ekwe nkwa ịdị obere ma ọ bụ hara ka `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // SAFETY: `i` bụ `needed + len.div_euclid(8) * 8`,
        // otú `i + left` = `needed + len` = `length`, nke bụ na definition hà `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Emepụta a `Hasher<S>` na abụọ mbụ igodo setịpụrụ na-0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}