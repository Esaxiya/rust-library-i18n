//! Oge niile doro anya na ụdị isi ihe na-ese n'elu mmiri `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! A na-enye ọnụọgụ mgbakọ na mwepụ na `consts` sub-modul.
//!
//! Maka ndị na-agbanwe agbanwe akọwapụtara na modulu a (dị iche na ndị akọwapụtara na `consts` sub-modul), koodu ọhụụ kwesịrị iji akara ndị metụtara ya akọwapụtara na ụdị `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radiks ma ọ bụ isi nke nnọchi anya nke `f32`.
/// Jiri [`f32::RADIX`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ezubere ụzọ
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Number nke dị ịrịba ama digits na isi 2.
/// Jiri [`f32::MANTISSA_DIGITS`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ezubere ụzọ
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Odika nọmba dị ịrịba ama dị na isi 10.
/// Jiri [`f32::DIGITS`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ezubere ụzọ
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] uru maka `f32`.
/// Jiri [`f32::EPSILON`] kama.
///
/// Nke a bụ ihe dị iche na `1.0` na ọnụọgụ nke ọzọ na-anọchite anya ya.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ezubere ụzọ
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Uru `f32` kacha nta.
/// Jiri [`f32::MIN`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ezubere ụzọ
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Xdị `f32` kacha mma dị mma.
/// Jiri [`f32::MIN_POSITIVE`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ezubere ụzọ
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Uru `f32` kachasị oke.
/// Jiri [`f32::MAX`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ezubere ụzọ
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Otu karịrị nke kacha nta ga-ekwe omume nkịtị ike nke 2 exporter.
/// Jiri [`f32::MIN_EXP`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ezubere ụzọ
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Ike kachasị ekwe omume nke ihe ngosi 2.
/// Jiri [`f32::MAX_EXP`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ezubere ụzọ
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Opekempe kwere omume nkịtị ike nke 10 exporter.
/// Jiri [`f32::MIN_10_EXP`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ezubere ụzọ
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Ike kachasị ekwe omume nke ihe ngosi 10.
/// Jiri [`f32::MAX_10_EXP`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ezubere ụzọ
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ọ bụghị Nọmba (NaN).
/// Jiri [`f32::NAN`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ezubere ụzọ
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Ebighebi (∞).
/// Jiri [`f32::INFINITY`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ezubere ụzọ
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Enweghị njedebe ebighi ebi (−∞).
/// Jiri [`f32::NEG_INFINITY`] kama.
///
/// # Examples
///
/// ```rust
/// // ụzọ rụrụ arụ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ezubere ụzọ
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Ntọala nke mgbakọ na mwepụ.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: dochie ya na mgbakọ na mwepụ na-agbanwe agbanwe site na cmath.

    /// Archimedes na-adịgide adịgide (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Gburugburu zuru (τ) mgbe niile
    ///
    /// Oyiri na 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Nọmba Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radiks ma ọ bụ isi nke nnọchi anya nke `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Number nke dị ịrịba ama digits na isi 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Odika nọmba dị ịrịba ama dị na isi 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] uru maka `f32`.
    ///
    /// Nke a bụ ihe dị iche na `1.0` na ọnụọgụ nke ọzọ na-anọchite anya ya.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Uru `f32` kacha nta.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Xdị `f32` kacha mma dị mma.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Uru `f32` kachasị oke.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Otu karịrị nke kacha nta ga-ekwe omume nkịtị ike nke 2 exporter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Ike kachasị ekwe omume nke ihe ngosi 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Opekempe kwere omume nkịtị ike nke 10 exporter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Ike kachasị ekwe omume nke ihe ngosi 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ọ bụghị Nọmba (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Ebighebi (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Enweghị njedebe ebighi ebi (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Laghachi `true` ma ọ bụrụ na uru a bụ `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` adịghị n'ihu ọha na libcore n'ihi nchegbu gbasara mbugharị, yabụ mmejuputa a bụ maka ojiji nkeonwe.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Laghachi `true` ma ọ bụrụ na uru a bara ọgaranya ma ọ bụ enweghị njedebe, na `false` ma ọ bụghị.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Laghachi `true` ma ọ bụrụ na ọnụ ọgụgụ a enweghị njedebe ma ọ bụ `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ọ dịghị mkpa ijikwa NaN iche iche: ọ bụrụ na onwe gị bụ Na, ntụle ahụ abụghị eziokwu, dịka ịchọrọ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Laghachi `true` ma ọ bụrụ na ọnụ ọgụgụ ahụ bụ [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Kpụrụ dị n'etiti `0` na `min` bụ Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Alaghachi `true` ma ọ bụrụ na ọnụ ọgụgụ bụ ma efu, enweghi ngwụcha, [subnormal], ma ọ bụ `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Kpụrụ dị n'etiti `0` na `min` bụ Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Laghachi azụ na-ese n'elu mmiri ebe udi nke nọmba.
    /// Ọ bụrụ na naanị otu ihe onwunwe ka a ga-anwale, ọ na-adịkarị ngwa ngwa iji amụma ahụ akọwapụtara kama.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Laghachi `true` ma ọ bụrụ na `self` nwere akara ngosi dị mma, gụnyere `+0.0`, ``NaN`s nwere akara ngosi dị mma na njedebe na-adịghị mma.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Laghachi `true` ma ọ bụrụ na `self` nwere akara na-adịghị mma, gụnyere `-0.0`, ``NaN`s na akara adịghị mma na njedebe na-adịghị mma.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 kwuru: isSignMinus(x) bụ eziokwu ma ọ bụrụ naanị na x nwere akara ngosi adịghị mma.
        // isSignMinus metụtara zeros na NaNs.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Were (inverse) nke nọmba, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Atọghata radians na ogo.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Jiri mgbe niile ka mma ka mma.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Atọghata degrees ka radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Weghachite kachasị nke nọmba abụọ ahụ.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ọ bụrụ na otu n`ime esemokwu bụ NA, mgbe ahụ esemokwu nke ọzọ eweghachitere.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Laghachi nke kacha nta nke nọmba abụọ.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ọ bụrụ na otu n`ime esemokwu bụ NA, mgbe ahụ esemokwu nke ọzọ eweghachitere.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Na-agagharị na efu ma gbanwee n'ụdị ụdị ọnụọgụ oge ochie ọ bụla, na-eche na uru ahụ nwere oke ma dabara na ụdị ahụ.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Uru ga:
    ///
    /// * Agaghị abụ `NaN`
    /// * Ghara enweghi ngwụcha
    /// * Bụrụ onye na-anọchi anya ya na ụdị nloghachi `Int`, mgbe ị gbusịrị akụkụ nke ya
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Ntughari Raw na `u32`.
    ///
    /// Nke a dị ugbu a na `transmute::<f32, u32>(self)` na nyiwe niile.
    ///
    /// Hụ `from_bits` maka ụfọdụ mkparịta ụka nke obere ọrụ a (ọ fọrọ nke nta ka ọ bụrụ okwu ọ bụla).
    ///
    /// Rịba ama na ọrụ a dị iche na nkedo `as`, nke na-anwa ichebe ọnụọgụ *ọnụọgụ*, ọ bụghị uru ntakịrị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() anaghị ajụ!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // OBI SAFETY: `u32` bu datatype ochie karie ka anyi gha apughari ya na ya
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutation si `u32`.
    ///
    /// Nke a dị ugbu a na `transmute::<u32, f32>(v)` na nyiwe niile.
    /// Ọ na-enyo na nke a bụ obere obere, n'ihi ihe abụọ:
    ///
    /// * Osimiri na Ints nwere otu endianness ahụ na nyiwe niile akwadoro.
    /// * IEEE-754 na-eziputa otutu ihe eji eme mmiri.
    ///
    /// Otú ọ dị, e nwere otu caveat: tupu 2008 version of IEEE-754, otú e si akọwa Nan na-agba ama bit adịghị n'ezie kpọmkwem.
    /// Imirikiti nyiwe (ọkachasị x86 na ARM) họpụtara nkọwa e mechara hazie na 2008, mana ụfọdụ emeghị (ọkachasị MIPS).
    /// N'ihi nke a, NaN niile na-egosi na MIPS bụ ndị NaNs dị jụụ na x86, na nke ọzọ.
    ///
    /// Kama ịnwa ịchekwa ihe ngosi-ness cross-platform, mmejuputa iwu a na-echekwa kpọmkwem ibe n'ibe.
    /// Nke a pụtara na akwụ ụgwọ ọ bụla etinyere na NaN ga-echekwa ọbụlagodi na esi na usoro a zipụ netwọkụ site na igwe x86 gaa na MIPS.
    ///
    ///
    /// Ọ bụrụ na nsonaazụ nke usoro a bụ naanị otu ụlọ ahụ mepụtara ha, yabụ na enweghị nchegbu ọ bụla.
    ///
    /// Ọ bụrụ na ntinye abụghị NA, mgbe ahụ enweghi nchegbu ebugharị.
    ///
    /// Ọ bụrụ na ị chọghị ịma banyere mgbama mgbaàmà (o yikarịrị ka ọ bụ), yabụ na enweghị nchegbu ọ bụla.
    ///
    /// Rịba ama na ọrụ a dị iche na nkedo `as`, nke na-anwa ichebe ọnụọgụ *ọnụọgụ*, ọ bụghị uru ntakịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // OBI SAFETY: `u32` bu datatype ochie karie ka anyi gha esi na ya transmute
        // Ọ na-enyo na nsogbu nchekwa na sNaN bụ overblown!Kpọọ!
        unsafe { mem::transmute(v) }
    }

    /// Weghachite nnọchite ebe nchekwa nke nọmba a na-ese n'elu mmiri dị ka usoro byte na nnukwu-endian (network) byte order.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Weghachite ihe ncheta nke nọmba a na-ese n'elu mmiri dị ka usoro site na obere usoro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Weghachite ihe ncheta nke nọmba a na-ese n'elu mmiri dị ka usoro ihe eji eme ihe na usoro ihe ọmụmụ.
    ///
    /// Dika eji eji ihe eji eme ihe eji eme ihe, a gha eji [`to_be_bytes`] ma obu [`to_le_bytes`], dika o kwesiri.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Weghachite ihe ncheta nke nọmba a na-ese n'elu mmiri dị ka usoro ihe eji eme ihe na usoro ihe ọmụmụ.
    ///
    ///
    /// [`to_ne_bytes`] ekwesịrị ịhọrọ karịa nke a mgbe ọ bụla enwere ike.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // OBI SAFETY: `f32` bu datatype ochie kariri nke mere anyi nwere ike ighachi ya
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Mepụta a ese n'elu mmiri mgbe uru site ya yiri ka a byte n'usoro na nnukwu endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Mepụta uru esere mmiri site na nnochi ya dị ka usoro byte na obere endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Mepụta uru ihe na-ese n'elu mmiri site na nnochi ya dị ka ihe eji eme ihe na endian.
    ///
    /// Dika eji ihe eji eme ihe eji eme ihe eji eme ihe, okwesiri ighota iji [`from_be_bytes`] ma obu [`from_le_bytes`], dika o kwesiri.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Weghachite ịhazi iwu n'etiti onwe na ụkpụrụ ndị ọzọ.
    /// N'adịghị ka ọkọlọtọ elele anya na-ese n'etiti eserese na-ese n'elu mmiri, ntụnyere a na-ewepụta usoro ịtụle usoro iwu niile nke akọwapụtara na IEEE 754 (nyochagharị 2008).
    /// A na-enye ụkpụrụ ahụ iwu iji soro:
    /// - Na-adịghị mma jụụ Na
    /// - Ihe ngosi na-adịghị mma NaN
    /// - Enweghị njedebe
    /// - Nọmba na-adịghị mma
    /// - Nọmba ndị na-adịghị mma
    /// - Efu efu
    /// - Ezigbo efu
    /// - Positive subnormal nọmba
    /// - Positive nọmba
    /// - Enweghị njedebe
    /// - Ezi akara ngosi NA
    /// - Ezigbo jụụ NaN
    ///
    /// Rịba ama na ọrụ a anaghị ekwenye mgbe niile na mmejuputa [`PartialOrd`] na [`PartialEq`] nke `f32`.Karịsịa, ha na-ele zero na-adịghị mma na nke ziri ezi anya dị ka nha anya, ebe `total_cmp` adịghị.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // N'ihe banyere ihe ndị na-adịghị mma, tụgharịa ụda niile ma e wezụga ihe ịrịba ama iji nweta nhazi yiri nke ahụ dị ka ọnụ ọgụgụ abụọ nke agbakwunye
        //
        // Gịnị kpatara ọrụ a?IEEE 754 sere n'elu nwere mpaghara atọ:
        // Banye bit, exponent na mantissa.Ntọala nke onye na-emepụta ihe na nke mantissa n'ozuzu ya nwere ihe onwunwe nke iwu ha nwere nha na ọnụọgụ ọnụọgụ ebe akọwapụtara ogo ahụ.
        // A naghị akọwapụta ịdị ukwuu na ụkpụrụ NA, mana IEEE 754 totalOrder na-akọwapụta ụkpụrụ NaN ịgbaso usoro ntanye ahụ.Nke a na-eduga n'usoro akọwapụtara na nkọwa doc.
        // Otú ọ dị, ihe nnọchiteanya nke ịdị ukwuu bụ otu maka ọnụ ọgụgụ na-adịghị mma ma dị mma-naanị akara ngosi dị iche.
        // Iji were tụnyere ụgbọ mmiri ahụ dị ka ọnụ ọgụgụ ndị a bịanyere aka n'akwụkwọ, ọ dị mkpa ka anyị tụgharịa onye na-ebu ya na mpempe akwụkwọ mantissa ma ọ bụrụ na ọnụọgụ adịghị mma.
        // Anyị na-agbanwe ọnụọgụ na nọmba "two's complement".
        //
        // Ime na flipping, anyị rụọ a nkpuchi na XOR megide ya.
        // Anyị na-agbakọ ihe nkpuchi "all-ones except for the sign bit" site na ụkpụrụ ndị a bịanyere aka na ya: aka nri na-agbanwe-na-agbatị ọnụ ọgụgụ ahụ, yabụ anyị bụ "fill" nkpuchi ahụ na akara ngosi, wee gbanwee gaa na ntinye aka na-agbanyekwu otu ihe efu.
        //
        // On mma ụkpụrụ, nkpuchi bụ niile efù, n'ihi ya, ọ bụ a dịghị-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Machibido a uru ka ụfọdụ nkeji ma ọ bụrụ na ọ bụ Na.
    ///
    /// Alaghachi `max` ma ọ bụrụ na `self` ukwuu `max`, na `min` ma ọ bụrụ na `self` bụ ihe na-erughị `min`.
    /// Ma ọ bụghị nke a laghachiri `self`.
    ///
    /// Rịba ama na ọrụ a laghachiri NaN ma ọ bụrụ na uru mbụ bụ NaN.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `min > max`, `min` bụ NaN, ma ọ bụ `max` bụ NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}