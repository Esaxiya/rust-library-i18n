//! Na-adịgide adịgide maka ụdị ọnụọgụ abụọ nke 32-bit.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Code ọhụrụ kwesịrị iji ihe ndị metụtara ya ozugbo na ụdị oge ochie.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }