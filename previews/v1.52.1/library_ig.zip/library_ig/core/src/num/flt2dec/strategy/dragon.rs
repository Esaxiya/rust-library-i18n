//! Ihe fọrọ nke nta ka ọ bụrụ kpọmkwem (mana ọ kachasị nke kachasị mma) ntụgharị Rust nke Ọgụgụ nke 3 nke "Mbipụta Nọmba Na-ese Ihe Ngwa Ngwa Ngwa Ngwa Ngwa Ngwa" [^ 1].
//!
//!
//! [^1]: Burger, RG na Dybvig, RK 1996. Mpempe akwụkwọ na-ese n'elu mmiri
//!   ọsọ ọsọ na n'ụzọ ziri ezi.SIGPLAN Abụghị.31, 5 (Mee. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// precalculated arrays nke 'Digit`s maka 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// naanị enwere ike iji ya mee ihe mgbe `x < 16 * scale`;`scaleN` kwesịrị ịbụ `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Kasị nso mode mode mmejuputa iwu.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // nọmba `v` ka usoro mara:
    // - hà nhata `mant * 2^exp`;
    // - tupu `(mant - 2 *minus)* 2^exp` n'ụdị mbụ;na
    // - soro `(mant + 2 *plus)* 2^exp` n'ụdị mbụ.
    //
    // doro anya, `minus` na `plus` enweghị ike ịbụ efu.(maka enweghị oke, anyị na-eji ụkpụrụ dị iche iche apụta.) Anyi na-ewerekwa na opekata mpe otu ọnụọgụ, ya bụ, `mant` enweghị ike ịbụ efu.
    //
    // nke a pụtakwara na nọmba ọ bụla dị n'etiti `low = (mant - minus)*2^exp` na `high = (mant + plus)* 2^exp` ga-egosi na nọmba ọnụ ọgụgụ a na-ese n'elu mmiri, nwere oke gụnyere mgbe mbụ mantissa dị (ya bụ, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` bụ `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // atụmatụ `k_0` site na ntinye mbụ na-enye afọ ojuju `10^(k_0-1) < high <= 10^(k_0+1)`.
    // uko agbụ `k` eju afọ `10^(k-1) < high <= 10^k` na gbakọọ mgbe e mesịrị.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // tọghata `{mant, plus, minus} * 2^exp` n'ụdị nke obere ka:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // kewaa `mant` site na `10^k`.ugbu a `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // idozi mgbe `mant + plus > scale` (ma ọ bụ `>=`).
    // anyị anaghị emezi `scale`, ebe ọ bụ na anyị nwere ike ịmịba mmụba nke mbụ kama.
    // ugbu a `scale < mant + plus <= scale * 10` na anyi di njikere igbanye digits.
    //
    // dee na `d[0]`*nwere ike* na-efu, mgbe `scale - plus < mant < scale`.
    // na nke a ọnọdụ ịchịkọta ọnọdụ (`up` n'okpuru) ga-amalite ozugbo.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // dakọtara na ịpị `scale` site na 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` maka ọnụọgụ ọnụọgụ.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // ndị na-enweghị atụ, ebe `d[0..n-1]` bụ ọnụọgụ mepụtara ruo ugbu a:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (yabụ `mant / scale < 10`) ebe `d[i..j]` dị mkpirisi maka `` d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // n'ịwa otu ọbula: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // nke a bụ mfe nkọwa nke gbanwetụrụ dragọn algọridim.
        // a na-ewepu ọtụtụ esemokwu etiti na arụmụka zuru oke maka mma.
        //
        // bido na ndi gbanwere gbanwere, dika anyi emelitere `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // chee na `d[0..n-1]` bụ mkpụmkpụ mkpụmkpụ n'etiti `low` na `high`, ya bụ, `d[0..n-1]` na-emeju afọ abụọ ndị a mana `d[0..n-2]` anaghị:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: digits gburugburu na `v`);na
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (onu ogugu ikpe azu bu ezi okwu).
        //
        // ọnọdụ nke abụọ dị mfe na `2 * mant <= scale`.
        // idozi ndi enweghi ikike n`usoro nke `mant`, `low` na `high` n`enye uzo di nfe nke onodu mbu: `-plus < mant < minus`.
        // ebe ọ bụ na `-plus < 0 <= mant`, anyị nwere ezigbo mkpirisi kachasị dị nso mgbe `mant < minus` na `2 * mant <= scale`.
        // (nke mbụ na-aghọ `mant <= minus` mgbe mbụ mantissa bụ ọbụna.)
        //
        // mgbe nke abụọ adịghị jide ('2 * mant> scale`), anyị kwesịrị dịkwuo ikpeazụ ọbula.
        // nke a ezuru iji weghachi ọnọdụ ahụ: anyị amalarịrị na ọgbọ ntanetị na-ekwe nkwa `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // na nke a, ọnọdụ izizi ghọrọ `-plus < mant - scale < minus`.
        // kemgbe `mant < scale` mgbe ọgbọ ahụ gasịrị, anyị nwere `scale < mant + plus`.
        // (ọzọ, nke a ghọrọ `scale <= mant + plus` mgbe mbụ mantissa bụ ọbụna.)
        //
        // na mpempe:
        // - kwụsị ma gbaa `down` gburugburu (debe ọnụọgụ abụọ dịka) mgbe `mant < minus` (ma ọ bụ `<=`).
        // - nkwụsị ma gbaa `up` gburugburu (welie ọnụọgụ ikpeazụ) mgbe `scale < mant + plus` (ma ọ bụ `<=`).
        // - na-amụba ma ọ bụghị.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // anyị nwere mkpirikpi nnochite anya, gaba na gburugburu

        // weghachite ndi enweghi ike.
        // nke a na-eme ka algọridim na-akwụsị mgbe niile: `minus` na `plus` na-abawanye mgbe niile, mana `mant` na-egbutu modulo `scale` na `scale`.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ingchịkọta na-eme mgbe m) naanị ọnọdụ nchịkọta na-ebute, ma ọ bụ ii) enwere ọnọdụ abụọ ahụ ma kee ya ka ọ dị mma ịchọrọ.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ma ọ bụrụ na ịgbakọta na-agbanwe ogologo, onye na-agbanwe agbanwe kwesịrị ịgbanwe.
        // ọ dị ka ọnọdụ a siri ike afọ ojuju (ikekwe ọ gaghị ekwe omume), mana anyị na-echekwa ma na-agbanwe agbanwe ebe a.
        //
        // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Kpọmkwem na ofu mode mmejuputa iwu maka Dragọn.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // atụmatụ `k_0` site na ntinye mbụ na-enye afọ ojuju `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // kewaa `mant` site na `10^k`.ugbu a `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup mgbe `mant + plus >= scale`, ebe `plus / scale = 10^-buf.len() / 2`.
    // iji mee ka ọ bụrụ na ọ bụ, anyị na-eji `mant + floor(plus) >= scale` eme ihe.
    // anyị anaghị emezi `scale`, ebe ọ bụ na anyị nwere ike ịmịba mmụba nke mbụ kama.
    // ọzọ na nke kasị nso algọridim, `d[0]` pụrụ efu ma a ga-emecha mechie elu.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // dakọtara na ịpị `scale` site na 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ọ bụrụ na anyị na-arụ ọrụ na njedebe ikpeazụ-ọnụọgụ, anyị kwesịrị ime ka nchekwa ahụ dị mkpụmkpụ tupu nsụgharị ahụ iji zere ịgbagharị abụọ.
    //
    // mara na anyị ga-ebuwanye ihe nchekwa ahụ mgbe ịchikọtara!
    let mut len = if k < limit {
        // oops, anyị enweghị ike imepụta otu mkpụrụ *.
        // nke a bụ na o kwere omume mgbe, sịnụ, anyị nwere ihe dị ka 9.5 na ya a na-mechie 10.
        // anyị weghachite ihe nchekwa efu, ewezuga ikpe na-esote nke na-eme mgbe `k == limit` ma nwee imepụta otu ọnụọgụ.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` maka ọnụọgụ ọnụọgụ.
        // (nke a nwere ike ịdị oke ọnụ, yabụ gbakọọ ha mgbe nchekwa adịghị.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // na-eso digits niile bụ ihe efu, anyị na-akwụsị ebe a adịghị * na-agbalị ịrụ mgbakọta!kama, mejupụta ọnụọgụ ndị fọdụrụnụ.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ichikota ma oburu na anyi kwusi n`etiti onu ogugu ma oburu na akara ndi a bu puku ise ..., lelee onu ogugu ma gbalita igha rue (ya bu, zere ichikota mgbe onu ogugu abuo kariri).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` bidoro.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ma ọ bụrụ na ịgbakọta na-agbanwe ogologo, onye na-agbanwe agbanwe kwesịrị ịgbanwe.
        // mana a rịọrọ anyị ọnụọgụ ọnụọgụ ọnụọgụ, yabụ agbanweela nchekwa ...
        // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... belụsọ na a rịọrọ anyị ka anyị dozie ya.
            // anyị kwesịrị ịlele nke ahụ, ọ bụrụ na nchekwa mbụ ahụ adịghịzi, enwere ike ịgbakwunye ọnụọgụ ọzọ mgbe `k == limit` (ikpe edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}