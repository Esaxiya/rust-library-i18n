/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ebe nke a bu ihe edere nke oma, nke a bu ihe nzuzo nke emere ka o doo anya maka ule.
// ekpughela anyị.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Algọridim dijitalụ.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// The kacha nta size nke echekwa dị mkpa maka kasị nso mode.
///
/// Ọ bụ obere ihe na-enweghị isi, mana nke a bụ otu gbakwunye ọnụ ọgụgụ kachasị elu nke akara ọnụọgụ ntụpọ dị mkpa site na usoro algọridim na nsonaazụ kachasị dị mkpirikpi.
///
/// Formulakpụrụ ziri ezi bụ `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Mgbe `d` nwere ntụpọ digits, dịkwuo ikpeazụ ọbula na mgba ebu.
/// Laghachi a digit ọzọ mgbe ọ na-eme ka ogologo gbanwee.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] niile bu nine
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 gbaa gburugburu 1000..000 na onye na-ebupụta ngwa ngwa
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ihe efu echekwa gburugburu (a bit iju ma ezi uche)
            Some(b'1')
        }
    }
}

/// Akụkụ akụkụ.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Ọnụọgụ ọnụọgụ nọmba efu.
    Zero(usize),
    /// Nọmba nkịtị rue 5 digits.
    Num(u16),
    /// A verbatim oyiri nke nyere bytes.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Laghachi kpomkwem byte ogologo nke nyere akụkụ.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Na-ede akụkụ n'ime nchekwa echekwa.
    /// Weghachite ọnụ ọgụgụ nke ederede edepụtara, ma ọ bụ `None` ma ọ bụrụ na nchekwa ahụ ezughị.
    /// (Ọ ka nwere ike ịhapụ akwụkwọ edemede edepụtara na nchekwa, adaberela na nke ahụ.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Haziri N'ihi nwere otu ma ọ bụ karịa akụkụ.
/// Enwere ike idere nke a na nchekwa nchekwa ma ọ bụ gbanwee ya na eriri ekenyela.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Mpempe byte nke na-anọchite anya akara, ma ọ bụ `""`, `"-"` ma ọ bụ `"+"`.
    pub sign: &'static str,
    /// Mathazi akụkụ ka sụgharịrị mgbe a ịrịba ama na ịnara efu padding.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Laghachighachiri kpọmkwem otu ogologo ụzọ e jikọtara ọnụ ha rụpụtara.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Na-ede akụkụ niile a haziri ahazi n'ime nchekwa ahụ.
    /// Weghachite ọnụ ọgụgụ nke ederede edepụtara, ma ọ bụ `None` ma ọ bụrụ na nchekwa ahụ ezughị.
    /// (Ọ ka nwere ike ịhapụ akwụkwọ edemede edepụtara na nchekwa, adaberela na nke ahụ.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// A na-enye usoro aha akara elekọtara ọnụ ntụ `0.<...buf...> * 10^exp` n'ime akara ntụpọ yana opekata mpe ọnụọgụ nke mkpụrụ pere mpe.
///
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche ma weghachite otu akụkụ nke akụkụ edere.
///
/// `frac_digits` nwere ike dị obere karịa ọnụọgụ ọnụọgụ ọnụọgụgụ na `buf`;
/// a ga-eleghara ya anya ma bipụta nọmba zuru ezu.A na-eji ya ebipụta mkpụrụ ndụ ndị ọzọ mgbe emechara ọnụọgụ.
/// Yabụ `frac_digits` nke 0 pụtara na ọ ga-ebipụta ọnụọgụ enyere na enweghị ihe ọ bụla.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ma ọ bụrụ na enwere mgbochi na ọnọdụ ọnụọgụ ikpeazụ, a na-ewere `buf` ka ọ bụrụ onye aka ekpe ya na ụmụ irighiri mebere.
    // ọnụọgụ nke efu efu, `nzeroes`, ruru `max(0, exp + frac_digits - buf.len())`, nke mere na ọnọdụ nke ọnụọgụ ikpeazụ `exp - buf.len() - nzeroes` abụghị karịa `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |zero | |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` na-agbakọ n'otu n'otu maka nke ọ bụla iji zere ijupụta.
    //

    if exp <= 0 {
        // ntụpọ ntụpọ bụ tupu enye nọmba: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // SAFETY: Anyị bidoro ihe `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // SAFETY: Anyị bidoro ihe `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ntụpọ ntụpọ dị n'ime mkpụrụ ọnụọgụ: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // SAFETY: Anyị bidoro ihe `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: Anyị bidoro ihe `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ntụpọ ntụpọ bụ mgbe sụgharịrị mkpụrụ: [1234][____0000] ma ọ bụ [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // SAFETY: Anyị bidoro ihe `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SAFETY: Anyị bidoro ihe `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Formats the given decimal digits `0.<...buf...>*10^exp` into the exponential form with Formats the given decimal digits `0.<...buf...>* 10^exp` in the exponential form with opekata mpe ọnụọgụ ọnụọgụ enyere akara.
///
/// Mgbe `upper` bụ `true`, na exponent ga-prefixed site `E`;ma ọ bụghị nke ahụ bụ `e`.
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche ma weghachite otu akụkụ nke akụkụ edere.
///
/// `min_digits` nwere ike ịbụ ihe na-erughị ọnụ ọgụgụ nke nọmba dị mkpa na `buf`;
/// a ga-eleghara ya anya ma bipụta nọmba zuru ezu.A na-eji ya ebipụta mkpụrụ ndụ ndị ọzọ mgbe emechara ọnụọgụ.
/// Yabụ, `min_digits == 0` pụtara na ọ ga-ebipụta ọnụọgụ enyere na ihe ọ bụla.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // zere igba mmiri mgbe exp bụ i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // NCHEKWA: anyị dị initialized ọcha `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Banye formatting nhọrọ.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Mbipụta `-` naanị maka ihe na-adịghị mma na-abụghị efu.
    Minus, // -inf -1 0 0 1 inf nan
    /// Mbipụta `-` naanị maka ụkpụrụ ọjọọ ọ bụla (gụnyere efu na-adịghị mma).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Mbipụta `-` maka ụkpụrụ na-abaghị uru, ma ọ bụ `+` ma ọ bụghị.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nanụ
    /// Mbipụta `-` maka ụkpụrụ ọjọọ ọ bụla (gụnyere efu na-adịghị mma), ma ọ bụ `+` ma ọ bụghị.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Weghachite eriri steti steti kwekọrọ na akara a ga-ahazi.
/// O nwere ike ịbụ ma ọ bụ `""`, `"+"` ma ọ bụ `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Formats nyere floating point number into the decimal form with at least given number of fractional digits.
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche a na-enye ya ma jiri ya tinye ihe nchekwa dị ka ọkọ.
/// `upper` ka eji eme ihe ugbu a mana ọ hapụrụ maka mkpebi future iji gbanwee ikpe nke ụkpụrụ na-enweghị oke, ya bụ, `inf` na `nan`.
///
/// Akụkụ mbụ a ga-enye bụ `Part::Sign` mgbe niile (nke nwere ike ịbụ eriri efu ma ọ bụrụ na enweghị nsụgharị ọ bụla).
///
/// `format_shortest` kwesịrị ịbụ ọrụ ọnụọgụ ọgbọ.
/// Ọ kwesịrị ịlaghachi akụkụ nke echekwa na ọ malitere.
/// Eleghị anya ị ga-achọ `strategy::grisu::format_shortest` maka nke a.
///
/// `frac_digits` nwere ike dị obere karịa ọnụọgụ ọnụọgụ ọnụọgụgụ na `v`;
/// a ga-eleghara ya anya ma bipụta nọmba zuru ezu.A na-eji ya ebipụta mkpụrụ ndụ ndị ọzọ mgbe emechara ọnụọgụ.
/// Yabụ `frac_digits` nke 0 pụtara na ọ ga-ebipụta ọnụọgụ enyere na enweghị ihe ọ bụla.
///
/// Bata echekwa kwesịrị ịdịkarịa ala `MAX_SIG_DIGITS` bytes ogologo.
/// Ekwesịrị inwe ma ọ dịkarịa ala akụkụ 4 dịnụ, n'ihi ikpe kachasị njọ dị ka `[+][0.][0000][2][0000]` na `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Formats nyere floating ebe nọmba n'ime ntụpọ ụdị ma ọ bụ ndị exponential ụdị, dabere na dapụtara exponent.
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche a na-enye ya ma jiri ya tinye ihe nchekwa dị ka ọkọ.
/// `upper` a na-eji iji chọpụta ikpe nke ụkpụrụ na-enweghị oke (`inf` na `nan`) ma ọ bụ ikpe nke prefix mbupu (`e` ma ọ bụ `E`).
/// Akụkụ mbụ a ga-enye bụ `Part::Sign` mgbe niile (nke nwere ike ịbụ eriri efu ma ọ bụrụ na enweghị nsụgharị ọ bụla).
///
/// `format_shortest` kwesịrị ịbụ ọrụ ọnụọgụ ọgbọ.
/// Ọ kwesịrị ịlaghachi akụkụ nke echekwa na ọ malitere.
/// Eleghị anya ị ga-achọ `strategy::grisu::format_shortest` maka nke a.
///
/// `dec_bounds` bụ tuple `(lo, hi)` dị ka ọnụ ọgụgụ a na-ahazi dị ka ntụpọ naanị mgbe `10^lo <= V < 10^hi`.
/// Mara na nke a bụ ihe doro anya * `V` kama ọ bụ ezigbo `v`!N'ihi ya, onye ọ bụla ebipụtara ebipụta n'ụdị enweghị ike ịdị na nso a, na-ezere ọgba aghara ọ bụla.
///
///
/// Bata echekwa kwesịrị ịdịkarịa ala `MAX_SIG_DIGITS` bytes ogologo.
/// Ekwesịrị inwe ma ọ dịkarịa ala akụkụ 6 dị, n'ihi ikpe kachasị njọ dị ka `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Alaghachikwute a kama crude approximation (elu agbụ) maka kacha echekwa size gbakọọ si nyere decoded exponent.
///
/// Kwụsị bụ:
///
/// - mgbe `exp < 0`, ogologo kachasị bụ `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - mgbe `exp >= 0`, ogologo kachasị bụ `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` bụ ihe na-erughị `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, nke ọzọ na-erughị `20 + (1 + exp* log_10 x)`.
/// Anyị na-eji eziokwu ndị `log_10 2 < 5/16` na `log_10 5 < 12/16`, nke zuru oke maka ebumnuche anyị.
///
/// Gịnị mere anyị ji chọọ ihe a?Ọrụ `format_exact` ga-ejupụta nchekwa niile belụsọ na njedebe nke njedebe ikpeazụ, mana enwere ike ọnụọgụ nke ọnụọgụ a rịọrọ bụ ihe nzuzu buru ibu (sịnụ, ọnụọgụ 30,000).
///
/// Ọnụ ọgụgụ ka ukwuu nke nchekwa ga-ejupụta na zeroes, yabụ na anyị achọghị igbunye ihe nchekwa niile tupu oge eruo.
/// N'ihi ya, maka arụmụka ọ bụla,
/// Ohere nke 826 ga-ezu maka `f64`.Tụlee nke a na ọnụ ọgụgụ dị adị maka ikpe kachasị njọ: 770 bytes (mgbe `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Formats nyere sere n'elu mgbe ọnụ ọgụgụ n'ime exponential ụdị na kpọmkwem nyere ọnụ ọgụgụ nke ịrịba digits.
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche a na-enye ya ma jiri ya tinye ihe nchekwa dị ka ọkọ.
/// `upper` A na-eji ya iji chọpụta ikpe nke mbupụ prefix (`e` ma ọ bụ `E`).
/// Akụkụ mbụ a ga-enye bụ `Part::Sign` mgbe niile (nke nwere ike ịbụ eriri efu ma ọ bụrụ na enweghị nsụgharị ọ bụla).
///
/// `format_exact` kwesịrị ịbụ ọrụ ọnụọgụ ọgbọ.
/// Ọ kwesịrị ịlaghachi akụkụ nke echekwa na ọ malitere.
/// Eleghị anya ị ga-achọ `strategy::grisu::format_exact` maka nke a.
///
/// Ihe nchekwa byte kwesịrị ịbụ opekata mpe `ndigits` bytes ọ gwụla ma `ndigits` buru ibu nke na naanị ọnụọgụ ọnụọgụ ọnụọgụ ga-ede.
/// (Ebe ntinye maka `f64` bụ ihe dịka 800, yabụ 1000 bytes ga-ezu.) Ekwesịrị inwe opekata mpe akụkụ 6 dị, n'ihi ikpe kachasị njọ dị ka `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Atsdị nyere floating point number into the decimal form with exactly given number of fractional digits.
/// A na-echekwa nsonaazụ ya na akụkụ dị iche iche a na-enye ya ma jiri ya tinye ihe nchekwa dị ka ọkọ.
/// `upper` ka eji eme ihe ugbu a mana ọ hapụrụ maka mkpebi future iji gbanwee ikpe nke ụkpụrụ na-enweghị oke, ya bụ, `inf` na `nan`.
/// Akụkụ mbụ a ga-enye bụ `Part::Sign` mgbe niile (nke nwere ike ịbụ eriri efu ma ọ bụrụ na enweghị nsụgharị ọ bụla).
///
/// `format_exact` kwesịrị ịbụ ọrụ ọnụọgụ ọgbọ.
/// Ọ kwesịrị ịlaghachi akụkụ nke echekwa na ọ malitere.
/// Eleghị anya ị ga-achọ `strategy::grisu::format_exact` maka nke a.
///
/// The byte echekwa ga-ezu maka mmepụta ma `frac_digits` bụ otú nnukwu na nani ofu ọnụ ọgụgụ nke mkpụrụ ga-ebi dere.
/// (Ebe ntinye maka `f64` bụ ihe dịka 800, na 1000 bytes kwesịrị ezu.) E kwesiri inwe opekata mpe akụkụ 4 dị, n'ihi ikpe kachasị njọ dị ka `[+][0.][0000][2][0000]` na `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SAFETY: Anyị bidoro ihe `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SAFETY: Anyị bidoro ihe `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // ọ *nwere ike* na `frac_digits` dị oke ọchị.
            // `format_exact` ga-ejedebe nsụgharị nsụgharị ọtụtụ n'oge na nke a, n'ihi na `maxlen` na-ejedebe anyị.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // enweghi ike izute mmachi ahụ, yabụ na nke a kwesịrị ịza efu n'agbanyeghị agbanyeghị `exp`.
                // nke a anaghị agụnye ikpe na mmachi ahụ ezutela naanị mgbe a gbakọchara ya;ọ bụ okwu ikpe na `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // SAFETY: Anyị bidoro ihe `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // SAFETY: Anyị bidoro ihe `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}