//! Ntughari uru onyogho na-ese n`elu uzo ya na oghere uzo ya.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Decoded unsigned oke uru, dị ka nke ahụ:
///
/// - Uru mbụ dị na `mant * 2^exp`.
///
/// - Onu ogugu obula sitere na `(mant - minus)*2^exp` rue `(mant + plus)* 2^exp` gha abia na nke mbu.
/// Ogologo a gụnyere naanị mgbe `inclusive` bụ `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Akpịrịkpa mantissa.
    pub mant: u64,
    /// Nsogbu njehie dị ala.
    pub minus: u64,
    /// Oke njehie dị elu.
    pub plus: u64,
    /// Onye na-emekọrịta ihe na isi 2.
    pub exp: i16,
    /// Eziokwu mgbe oke njehie gụnyere.
    ///
    /// Na IEEE 754, nke a bụ eziokwu mgbe mbụ mantissa dị ọbụna.
    pub inclusive: bool,
}

/// Decoded unsigned uru.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, ma nke oma ma ọ bụ nke ọjọọ.
    Infinite,
    /// Odo, ma odi nma ma obu nke ojoo.
    Zero,
    /// Onu ogugu na ubi ndi ozo decoded.
    Finite(Decoded),
}

/// Flodị ụdị mmiri nwere ike ịbụ ``decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Opekempe uru normalized uru.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Weghachite ihe ịrịba ama (nke bụ eziokwu mgbe ọ na-adịghị mma) na uru `FullDecoded` site na ọnụ ọgụgụ na-ese n'elu mmiri.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // agbata obi: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode na-echekwa onye na-ewe ihe mgbe niile, ya mere a na-atụ mantissa maka subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // agbata obi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ebe maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // agbata obi: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}