//! Ntughari Rust nke Grisu3 algorithm nke achoputara na "Obughari onu ogugu onu ogugu na ngwa ngwa na ndi mmadu" [^ 1].
//! Ọ na-eji ihe dịka 1KB nke tebụl precomputed, na n'aka nke ya, ọ dị oke ọsọ maka ọtụtụ ntinye.
//!
//! [^1]: Florian Loitsch.2010. Printing-ese n'elu mmiri-ebe nọmba ngwa ngwa na
//!   n'ụzọ ziri ezi na ọnụ ọgụgụ.SIGPLAN Abụghị.45, 6 (June 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// lee ihe emere na `format_shortest_opt` maka ebumnuche.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-m;e=4* m, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Nyere `x > 0`, laghachi `(k, 10^k)` nke `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Kasị mkpụmkpụ mode mmejuputa maka Grisu.
///
/// Ọ laghachiri `None` mgbe ọ ga-alọghachi ihe nnọchiteanya na-enweghị uche na uzọ ọzọ.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // anyị kwesịrị dịkarịa ala atọ ibe n'ibe nke ọzọ nkenke

    // bido na ụkpụrụ eji emezi ihe na nke ndi ozo
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // chọta `cached = 10^minusk` ọ bụla dịka `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ebe ọ bụ na `plus` dị mma, nke a pụtara `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // nyere nhọrọ anyị nke `ALPHA` na `GAMMA`, nke a na-etinye `plus * cached` n'ime `[4, 2^32)`.
    //
    // o doro anya na ọ bụ ihe na-achọsi ike iji bulie `GAMMA - ALPHA`, nke mere na anyị achọghị ọtụtụ ikike echekwara nke 10, mana enwere ụfọdụ echiche:
    //
    //
    // 1. anyi choro idobe `floor(plus * cached)` n'ime `u32` ebe o choro nkewa di oke onu.
    //    (nke a abụghị ihe a na-apụghị izere ezere, achọrọ ihe fọdụrụ maka atụmatụ ziri ezi.)
    // 2.
    // ndị fọdụrụnụ nke `floor(plus * cached)` ugboro ugboro na-amụba site na 10, na ọ gaghị tojupụta.
    //
    // nke mbụ na-enye `64 + GAMMA <= 32`, ebe nke abụọ na-enye `10 * 2^-ALPHA <= 2^64`;
    // -60 na -32 bụ oke kachasị na mgbochi a, na V8 na-ejikwa ha.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // ọnụ ọgụgụ fps.a na-enye ndị maximal njehie nke 1 ulp (gosi Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-ezigbo ọnụọgụ nke mwepu
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 afọ | | afọ 1 || 1 afọ | | afọ 1 || 1 afọ | | afọ 1 |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // n'elu `minus`, `v` na `plus` bụ *ọnụọgụgụ*(njehie <1 ulp).
    // dị ka anyị na-amaghị njehie bụ nke oma ma ọ bụ na-adịghị mma, anyị na-eji abụọ approximations spaced ohiha na nwere maximal njehie nke 2 ọnya.
    //
    // "unsafe region" bụ oge na-emesapụ aka nke anyị na-ewepụta na mbụ.
    // na "safe region" bụ a mgbanwe nkeji nke naanị ihe anyị na-anabata.
    // anyị na-amalite site na repr ziri ezi n'ime mpaghara a na-ejighị n'aka, ma gbalịa ịchọta repr kacha nso na `v` nke dịkwa n'ime mpaghara nchekwa.
    // ọ bụrụ na anyị enweghị ike, anyị na-ahapụ.
    //
    let plus1 = plus.f + 1;
    // ka plus0 = plus.f, 1;//naanị maka nkọwa ka minus0 = minus.f + 1;//naanị maka nkọwa
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // nneme

    // kewaa `plus1` na akuku na nkpirisi.
    // akụkụ dị iche iche ga-adaba na u32, ebe ọ bụ na ikike echekwara `plus < 2^32` na `plus.f` nkịtị bụ mgbe niile na-erughị `2^64 - 2^4` n'ihi nkenke chọrọ.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // gbakọọ `10^max_kappa` kachasị ukwuu karịa `plus1` (yabụ `plus1 < 10^(max_kappa+1)`).
    // nke a bụ akara elu nke `kappa` n'okpuru.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Usoro iwu 6.2: ma ọ bụrụ na `k` bụ integer kachasị
    // `0 <= y mod 10^k <= y - x`,              mgbe ahụ `V = floor(y / 10^k) * 10^k` dị na `[x, y]` na otu n`ime mkpirisi kachasị dị nso (ya na ọnụọgụ pere mpe nke ọnụọgụ dị mkpa) na oke ahụ.
    //
    //
    // chọta ogologo ọnụọgụ `kappa` n'etiti `(minus1, plus1)` dị ka Theorem 6.2.
    // Enwere ike ịnabata usoro 6.2 iji wepu `x` site na ịchọrọ `y mod 10^k < y - x` kama.
    // (dịka, `x` =32000, `y` =32777; `kappa` =2 ebe ọ bụ na 'y mod 10 ^ 3=777 <y, x=777`.) algorithm na-adabere na usoro nkwenye mechara iji wepu `y`.
    //
    let delta1 = plus1 - minus1;
    // ka delta1int=(delta1>> e) ka were;//naanị maka nkọwa
    let delta1frac = delta1 & ((1 << e) - 1);

    // mee akụkụ dị mkpa, ebe ị na-elele maka izi ezi na nke ọ bụla.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ọnụọgụgụ ka a sụgharịrị
    loop {
        // anyị nwere ma ọ dịkarịa ala otu mkpụrụ iji nye, dịka `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ọ na-esote na `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // kewaa `remainder` site na `10^kappa`.ha abuo site na `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; anyị achọtala `kappa` ziri ezi.
            let ten_kappa = (ten_kappa as u64) << e; // Onu ogugu 10 ^ kappa laghachi na ndi mmadu
            return round_and_weed(
                // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // agbaji akaghị mgbe anyị sụgharịrị njikọ niile.
        // ọnụọgụgụ nke ọnụọgụ bụ `max_kappa + 1` dị ka `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // weghachite ndi anaghi agbanwe
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // na-eme akụkụ pere mpe, ma na-enyocha maka izi ezi na nke ọ bụla.
    // oge a anyị na-adabere na ịba ụba ugboro ugboro, dịka nkewa ga-efunahụ nkenke.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ọnụọgụ nke ọzọ kwesịrị ịdị ịrịba ama ka anyị nwalere na tupu ịpụ ndị na-adịghị agbanwe agbanwe, ebe `m = max_kappa + 1` (#nke mkpụrụ na akụkụ dị mkpa):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // agaghị ejupụta, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // kewaa `remainder` site na `10^kappa`.
        // ha abuo site na `2^e / 10^kappa`, ya mere nke ikpe azu bu ebe a.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // nkewa doro anya
            return round_and_weed(
                // SAFETY: anyị bidoro ebe nchekwa ahụ dị n'elu.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // weghachite ndi anaghi agbanwe
        kappa -= 1;
        remainder = r;
    }

    // anyị mepụtara ọnụọgụ niile dị mkpa nke `plus1`, mana ejighị n'aka ma ọ bụ nke kachasị mma.
    // dịka ọmụmaatụ, ọ bụrụ na `minus1` bụ 3.14153 ... na `plus1` bụ 3.14158 ..., enwere ụzọ dị mkpirikpi dị iche iche 5 sitere na 3.14154 ruo 3.14158 mana naanị anyị nwere nke kachasị.
    // anyi aghaghi ibelata onu ogugu ikpeazu ma lelee ma nke a bu ezigbo repr.
    // enwere ọtụtụ ndị chọrọ 9 (..1 ka ..9), yabụ na nke a bụ ngwa ngwa.("rounding" oge)
    //
    // arụ ọrụ ahụ na-enyocha ma ọ bụrụ na "optimal" repr a dị n'ime usoro ọnya ahụ, yana kwa, ọ ga-ekwe omume na "second-to-optimal" repr nwere ike bụrụ ezigbo ezigbo n'ihi njehie na-agbakọta.
    // na nke ọ bụla nke a laghachiri `None`.
    // ("weeding" oge)
    //
    // arụmụka niile dị ebe a bụ uru `k` bara uru (mana ọ pụtara), nke mere na:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (na kwa, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (na kwa, `threshold > plus1v` site na ndi agbanweghi mbu)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // mepụta nnabata abụọ na `v` (n'ezie `plus1 - v`) n'ime ọnya 1.5.
        // ihe nnọchi anya ga-abụ nnọchite anya kachasị nso na ha abụọ.
        //
        // ebe a ejiri `plus1 - v` ebe a na-eme ngụkọta maka `plus1` iji zere overflow/underflow (yabụ aha ndị yiri aha).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ọnya)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ọnya)

        // belata ọnụọgụ ikpeazụ ma kwụsị na nnọchite anya kacha nso na `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // anyị na-arụ ọrụ na ọnụọgụ ọnụọgụ `w(n)`, nke dị na `plus1 - plus1 % 10^kappa`.mgbe na-agba ọsọ akaghị ahụ `n` oge, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // anyị `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (otú 'fọdụrụnụ= plus1w(0)`) mfe akwụkwọ ndenye ego.
            // mara na `plus1w(n)` na-abawanye mgbe niile.
            //
            // anyị nwere ọnọdụ atọ iji kwụsị.nke ọ bụla n'ime ha ga-eme ka akaghị enweghị ike ịga n'ihu, mana anyị nwere opekata mpe otu nnọchite anya dị mma nke amara dịkarịrị nso na `v + 1 ulp`.
            // anyị ga-egosipụta ha dịka TC1 site na TC3 maka mkpụmkpụ.
            //
            // TC1: `w(n) <= v + 1 ulp`, ntụgharị, nke a bụ nke ikpeazụ repr nke nwere ike ịbụ nke kacha nso.
            // nke a yiri `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // jikọtara ya na TC2 (nke na-enyocha ma ọ bụrụ `w(n+1)` is valid), nke a na-egbochi mwepu enwere ike na ngụkọta oge nke `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ya bu, osote repr adighi agba aka na `v`.
            // nke a yiri `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // aka ekpe nwere ike iju, mana anyị maara `threshold > plus1v`, yabụ ọ bụrụ na TC1 bụ ụgha, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` na anyị nwere ike ịnwale nwale ma ọ bụrụ `threshold - plus1w(n) < 10^kappa` kama.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ya bụ, repr ọzọ bụ
            // adịghị nso `v + 1 ulp` karịa ugbu a repr.
            // nyere `z(n) = plus1v_up - plus1w(n)`, nke a bụrụ `abs(z(n)) <= abs(z(n+1))`.ọzọ na-ewere na TC1 bụ ụgha, anyị nwere `z(n) > 0`.anyị nwere ikpe abụọ iji tụlee:
            //
            // - mgbe `z(n+1) >= 0`: TC3 na-aghọ `z(n) <= z(n+1)`.
            // ka `plus1w(n)` na-abawanye, `z(n)` kwesịrị ibelata na nke a bụ ụgha.
            // - mgbe `z(n+1) < 0`:
            //   - TC3a: ihe nkwekọrịta bụ `plus1v_up < plus1w(n) + 10^kappa`.na-ewere na TC2 bụ ụgha, `threshold >= plus1w(n) + 10^kappa` ya mere na ọ nweghị ike ijupụta.
            //   - TC3b: TC3 ghọrọ `z(n) <= -z(n+1)`, ntụgharị, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ihe efu TC1 na-enye `plus1v_up > plus1w(n)`, ya mere o nweghi ike iju ma obu juo mgbe anakpo ya na TC3a.
            //
            // n'ihi ya, anyị kwesịrị ịkwụsị mgbe `TC1 || TC2 || (TC3a && TC3b)`.ndị na-esonụ dị ka ya inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // nke kacha nso repr enweghị ike ịkwụsị na `0`
                plus1w += ten_kappa;
            }
        }

        // lelee ma ọ bụrụ na nnọchite nke a bụkwa nnọchi anya kacha nso `v - 1 ulp`.
        //
        // nke a bụ otu ihe na ọnọdụ ịkwụsị `v + 1 ulp`, yana `plus1v_up` niile nọchiri `plus1v_down` kama.
        // njupụta nyocha jidesiri.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ugbu a anyị nwere nnọchite anya kacha nso na `v` n'etiti `plus1` na `minus1`.
        // nke a na-emesapụ aka, agbanyeghị, yabụ anyị jụrụ `w(n)` ọ bụla n'etiti `plus0` na `minus0`, ya bụ, `plus1 - plus1w(n) <= minus0` ma ọ bụ `plus1 - plus1w(n) >= plus0`.
        // anyị na-eji eziokwu nke `threshold = plus1 - minus1` na `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Kasị mkpụmkpụ mode mmejuputa maka Grisu na Dragọn fallback.
///
/// Ekwesịrị iji nke a maka ọtụtụ ikpe.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETY: Onye na-agbaziri agbaziri agbaziri amachaghị ka anyị jiri `buf`
    // na nke abụọ branch, yabụ anyị na-agbagha oge ndụ ebe a.
    // Mana anyi na-eji `buf` eme ihe ma oburu na `format_shortest_opt` laghachiri `None` ya mere na odi nma.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Kpọmkwem na ofu mode mmejuputa iwu maka Grisu.
///
/// Ọ laghachiri `None` mgbe ọ ga-alọghachi ihe nnọchiteanya na-enweghị uche na uzọ ọzọ.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // anyị kwesịrị dịkarịa ala atọ ibe n'ibe nke ọzọ nkenke
    assert!(!buf.is_empty());

    // normalize na ọnụ ọgụgụ `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // kewaa `v` na akuku na nkpirisi.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // `v` ochie na `v` ọhụrụ (nke `10^-k` na-atụ) nwere njehie nke <1 ulp (Theorem 5.1).
    // dị ka anyị na-amaghị njehie bụ nke ọma ma ọ bụ na-adịghị mma, anyị na-eji abụọ approximations spaced ohiha na nwere maximal njehie nke 2 ọnya (otu ihe kasị nso ikpe).
    //
    //
    // ihe mgbaru ọsọ bụ ịchọta kpọmkwem ahazi usoro nke digits na-ahụkarị ma `v - 1 ulp` na `v + 1 ulp`, nke mere na anyị na-maximally obi ike.
    // ma ọ bụrụ na nke a agaghị ekwe omume, anyị amaghị nke ọ bụla bụ ezigbo ndozi maka `v`, yabụ anyị na-ahapụ ma daa azụ.
    //
    // `err` akọwapụtara dị ka `1 ulp * 2^e` ebe a (otu ihe ahụ na ọnya ahụ na `vfrac`), anyị ga-atụle ya mgbe ọ bụla `v` gafere.
    //
    //
    //
    let mut err = 1;

    // gbakọọ `10^max_kappa` kachasị ukwuu karịa `v` (yabụ `v < 10^(max_kappa+1)`).
    // nke a bụ akara elu nke `kappa` n'okpuru.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ọ bụrụ na anyị na-arụ ọrụ na njedebe ikpeazụ-ọnụọgụ, anyị kwesịrị ime ka nchekwa ahụ dị mkpụmkpụ tupu nsụgharị ahụ iji zere ịgbagharị abụọ.
    //
    // mara na anyị ga-ebuwanye ihe nchekwa ahụ mgbe ịchikọtara!
    let len = if exp <= limit {
        // oops, anyị enweghị ike imepụta otu mkpụrụ *.
        // nke a bụ na o kwere omume mgbe, sịnụ, anyị nwere ihe dị ka 9.5 na ya a na-mechie 10.
        //
        // na ụkpụrụ anyị nwere ike ịkpọ `possibly_round` ozugbo na nchekwa na-enweghị ihe ọ bụla, mana ịlele `max_ten_kappa << e` site na 10 nwere ike ime ka ọ gafee.
        //
        // otu a ka anyị si adaba ebe a ma mepee njehie site na 10.
        // nke a ga-eme ka ọnụego ụgha na-adịghị mma, mana naanị ntakịrị, * dị nnọọ ntakịrị;
        // ọ nwere ike bụrụ ihe puru iche mgbe mantissa buru ibu karịa ọnụọgụ 60.
        //
        // SAFETY: `len=0`, yabụ ọrụ nke ibido ncheta a abụghị obere ihe.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // mee akụkụ dị mkpa.
    // njehie ahụ bụ nke nta nke nta, yabụ na ọ dịghị anyị mkpa ịlele ya n'akụkụ a.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ọnụọgụgụ ka a sụgharịrị
    loop {
        // mgbe niile ka anyị nwere opekata mpe otu mkpụrụ iji nye ndị na-adịghị agbanwe agbanwe:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ọ na-esote na `remainder = vint % 10^(kappa+1)`)
        //
        //

        // kewaa `remainder` site na `10^kappa`.ha abuo site na `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // echekwa zuru?na-agba ọsọ na-agbafe na ihe ndị ọzọ.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: anyị bidoro `len` ọtụtụ bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // agbaji akaghị mgbe anyị sụgharịrị njikọ niile.
        // ọnụọgụgụ nke ọnụọgụ bụ `max_kappa + 1` dị ka `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // weghachite ndi anaghi agbanwe
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // mee akụkụ nke pere mpe.
    //
    // na ụkpụrụ anyị nwere ike ịga n'ihu na ọnụọgụ ikpeazụ dị ma lelee maka izi ezi.
    // dị mwute ikwu na anyị na-arụ ọrụ na oke-sized integers, anyị mkpa ụfọdụ criterion ịchọpụta nile.
    // V8 na-eji `remainder > err`, nke na-aghọ ụgha mgbe mbụ `i` dị ịrịba ama nke `v - 1 ulp` na `v` dị iche.
    // agbanyeghị nke a na-ajụ ọtụtụ ntinye na-adịghị mma.
    //
    // ebe ọ bụ na usoro nke oge a nwere nchọpụta ọfụma ziri ezi, anyị na-eji njirimara siri ike:
    // anyị na-aga n'ihu ruo `err` karịrị `10^kappa / 2`, nke mere na oke n'etiti `v - 1 ulp` na `v + 1 ulp` nwere ihe nnọchi anya abụọ ma ọ bụ karịa.
    //
    // nke a bụ ihe atụ na nyocha abụọ mbụ sitere na `possibly_round`, maka ntụaka.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // ndị na-enweghị atụ, ebe `m = max_kappa + 1` (#nke mkpụrụ na akụkụ dị mkpa):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // agaghị ejupụta, `2^e * 10 < 2^64`
        err *= 10; // agaghị ejupụta, `err * 10 < 2^e * 5 < 2^64`

        // kewaa `remainder` site na `10^kappa`.
        // ha abuo site na `2^e / 10^kappa`, ya mere nke ikpe azu bu ebe a.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // echekwa zuru?na-agba ọsọ na-agbafe na ihe ndị ọzọ.
        if i == len {
            // SAFETY: anyị bidoro `len` ọtụtụ bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // weghachite ndi anaghi agbanwe
        remainder = r;
    }

    // nchịkọta ọzọ abaghị uru (`possibly_round` maa adaghị), yabụ anyị hapụrụ.
    return None;

    // anyị mepụtara ihe niile `v` rịọrọ, nke kwesịrị ịbụ otu akara nke `v - 1 ulp` kwekọrọ.
    // ugbu a, anyị na-enyocha ma ọ bụrụ na e nwere ihe nnọchianya pụrụ iche nke `v - 1 ulp` na `v + 1 ulp` na-ekerịta;nke a nwere ike ịbụ otu ihe ahụ iji mepụta ọnụọgụ, ma ọ bụ ụdị agbakọ ndị ahụ.
    //
    // ma ọ bụrụ na nso nwere ọtụtụ nnọchi anya nke otu ogologo, anyị enweghị ike ijide n'aka na anyị ga-alaghachi `None` kama.
    //
    // arụmụka niile dị ebe a bụ uru `k` bara uru (mana ọ pụtara), nke mere na:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ANY: : akpa `len` bytes nke `buf` ga-amalite.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ọnya | 1 afọ |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (maka ntụaka, akara ntụpọ na-egosi ọnụọgụ ziri ezi maka nnọchite ga-ekwe omume na ọnụọgụ enyere nke ọnụọgụ.)
        //
        //
        // njehie buru oke ibu na enwere opekata mpe ụzọ atọ dị n'etiti `v - 1 ulp` na `v + 1 ulp`.
        // anyị enweghị ike ịchọpụta nke ziri ezi.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ọnya | 1 afọ |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // n'eziokwu, 1/2 ulp zuru oke iwebata ihe nnọchiteanya abụọ nwere ike.
        // (cheta na anyị chọrọ nnọchite pụrụ iche maka `v - 1 ulp` na ``v + 1 ulp` '') nke a agaghị ejupụta, dịka `ulp < ten_kappa` site na nyocha mbụ.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       :------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 afọ | | afọ 1 |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ọ bụrụ na `v + 1 ulp` dị nso na nnọchite anya (nke dị na `buf`), mgbe ahụ anyị nwere ike ịlaghachi na nchekwa.
        // mara na `v - 1 ulp`*nwere ike* pekarịrị ihe nnọchite ugbu a, mana dịka `1 ulp < 10^kappa / 2`, ọnọdụ a zuru oke:
        // ohere dị n'etiti `v - 1 ulp` na nnọchite nke ugbu a enweghị ike ịgafe `10^kappa / 2`.
        //
        // ọnọdụ ya na `remainder + ulp < 10^kappa / 2`.
        // ebe ọ bụ na nke a nwere ike ịfefe n'ụzọ dị mfe, buru ụzọ lelee ma ọ bụrụ `remainder < 10^kappa / 2`.
        // anyị enyochaworị na `ulp < 10^kappa / 2`, ma ọ bụrụhaala na `10^kappa` eruteghị ka emechara, nyocha nke abụọ dị mma.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: onye na-akpọ anyị malitere ncheta ahụ.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------fọduru------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ọnya | 1 afọ |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // n'aka nke ọzọ, ọ bụrụ na `v - 1 ulp` dị nso na nnọchi anya mechiri emechi, anyị kwesịrị ịchịkọta ma laghachi.
        // maka otu ihe ahụ anyị achọghị ịlele `v + 1 ulp`.
        //
        // ọnọdụ ya na `remainder - ulp >= 10^kappa / 2`.
        // ọzọ anyị na-ebu ụzọ lelee ma ọ bụrụ `remainder > ulp` (mara na nke a abụghị `remainder >= ulp`, dị ka `10^kappa` adịghị efu).
        //
        // marakwa na `remainder - ulp <= 10^kappa`, yabụ nlele nke abụọ anaghị ejupụta.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ANY SA: onye na-akpọ anyị ga-ebido ebe nchekwa ahụ.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // tinye sọọsọ ọnụọgụ ọzọ mgbe a rịọrọ anyị ka ọ kapịrị ọnụ.
                // anyị kwesịrị ịlele nke ahụ, ọ bụrụ na nchekwa mbụ ahụ adịghịzi, enwere ike ịgbakwunye ọnụọgụ ọzọ mgbe `exp == limit` (ikpe edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ANY: : anyị na onye na-akpọ anyị malitere icheta ihe ahụ.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ma ọ bụghị na a ga-ebibi anyị (yabụ, ụfọdụ ụkpụrụ dị n'etiti `v - 1 ulp` na `v + 1 ulp` na-agbakọta ma ndị ọzọ na-agbakọta) ma kwụsị.
        //
        None
    }
}

/// Kpọmkwem na ofu mode mmejuputa iwu maka Grisu na Dragọn fallback.
///
/// Ekwesịrị iji nke a maka ọtụtụ ikpe.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETY: Onye na-agbaziri agbaziri agbaziri amachaghị ka anyị jiri `buf`
    // na nke abụọ branch, yabụ anyị na-agbagha oge ndụ ebe a.
    // Mana anyi na-eji `buf` eme ihe ma oburu na `format_exact_opt` laghachiri `None` ya mere na odi nma.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}