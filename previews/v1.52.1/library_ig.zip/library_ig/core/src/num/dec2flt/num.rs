//! Ọrụ bara uru maka bignums ndị na-enweghị oke nghọta iji gbanwee ụzọ.

// FIXME Aha modul a bụ ihe nwute, ebe ndị ọzọ modul na-ebubata `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Nwalee ma iwepucha ihe niile dị ntakịrị karịa `ones_place` na-ewebata ezighi ezi metụtara, enweghị, ma ọ bụ karịa 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ọ bụrụ na ọnụọgụ ndị ọzọ fọdụrụ bụ efu, ọ bụ= 0.5 ULP, ma ọ bụghị> 0.5 Ọ bụrụ na enweghị ọnụọgụ ọzọ (ọkara_bit==0), n'okpuru ga-alaghachikwa nha.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Gbanwee eriri ASCII nke nwere naanị ọnụọgụ ntụpọ na `u64`.
///
/// Anaghị enyocha ego maka odide ma ọ bụ ihe odide na-abaghị uru, yabụ ọ bụrụ na onye na-akpọ oku anaghị akpachara anya, nsonaazụ ya bụ ụgha ma nwee ike panic (n'agbanyeghị na ọ gaghị abụ `unsafe`).
/// Tụkwasị na nke a, a na-emeso ụdọ efu dị ka efu.
/// Ọrụ a dị n'ihi na
///
/// 1. iji `FromStr` na `&[u8]` chọrọ `from_utf8_unchecked`, nke dị njọ, na
/// 2. ijikọta nsonaazụ nke `integral.parse()` na `fractional.parse()` dị mgbagwoju anya karịa ọrụ a dum.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Gbanwee eriri ASCII dijital n'ime bignum.
///
/// Dị ka `from_str_unchecked`, ọrụ a dabere na parser igbo ahihia na-abụghị nọmba.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Wepu a bignum n'ime 64 bit integer.Panics ma ọ bụrụ na ọnụ ọgụgụ buru oke ibu.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extracts a nso nke ibe n'ibe.

/// Index 0 bụ nke pere mpe dị ntakịrị ma oke dị na ọkara-emeghe ka ọ dị na mbụ.
/// Panics ma ọ bụrụ na a gwa gị ka ị wepụkwuo ihe karịa ka ọ dabara n'ụdị nloghachi.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}