//! Algọridim dị iche iche site na akwụkwọ.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Onu ogugu di nkpa na Fp
const P: u32 = 64;

// Naanị anyị na-echekwa ngosiputa kachasị mma maka ndị niile na-ebugharị ya, yabụ enwere ike hapụ nnweta "h" na ọnọdụ metụtara ya.
// Nke a trades arụmọrụ maka di na nwunye kilobytes nke ohere.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Na ọtụtụ architectures, sere n'elu ebe arụmọrụ nwere ihe doro bit size, ya mere nkenke nke mgbakọ na-ekpebisi ike na a kwa-operation ndabere.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Na x86, a na-eji x87 FPU mee ihe maka ọrụ mmiri ma ọ bụrụ na mgbakwunye SSE/SSE2 adịghị.
// x87 FPU na-arụ ọrụ na ntanetị 80 ziri ezi na ndabara, nke pụtara na arụmọrụ ga-aga 80 bits na-eme ka ịmegharị okpukpu abụọ ga-eme mgbe a na-egosipụta ụkpụrụ dị ka
//
// 32/64 bit ise n'elu ụkpụrụ.Iji merie nke a, FPU akara okwu enwere ike ịtọ ya ka a na-eme mgbakọ ahụ na nkenke chọrọ.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Ihe owuwu eji echekwa uru mbu nke okwu FPU, ka enwere ike weghachi ya mgbe atuputara ihe a.
    ///
    ///
    /// x87 FPU bụ ihe ntinye 16-bits onye ubi ya bụ ndị a:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Akwụkwọ maka mpaghara niile dị na Akwụkwọ Ntuziaka Software nke Onye Mmepụta Software nke IA-32 (Mpịakọta 1).
    ///
    /// Naanị ubi nke dị mkpa maka koodu na-esonụ bụ PC, Nkọwapụta Nhazi.
    /// Ala a na-ekpebi nkenke arụmọrụ nke FPU rụrụ.
    /// Enwere ike ịtọ ya:
    ///  - 0b00, otu nkenke ntụgharị, 32-ibe
    ///  - 0b10, nkenke abuo dika, 64-ibe
    ///  - 0b11, nkenke agbatị agbatị ntụgharị, 80-ibe (ọnọdụ ndabara) Uru 0b01 debeere ma ghara iji ya.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: etinyegoro nkuzi `fldcw` ka nwee ike rụọ ọrụ ọfụma
        // `u16` ọ bụla
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Anyị na-eji syntax ATT iji kwado LLVM 8 na LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Setịpụrụ nkenke ubi nke FPU ka `T` wee laghachi `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Gbakọọ uru maka nkenke Control ubi nke kwesịrị ekwesị maka `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 ibe n'ibe
            _ => 0x0300, // ndabere, 80 ibe n'ibe
        };

        // Nweta uru mbụ nke okwu njikwa iji weghachite ya ma emechaa, mgbe usoro `FPUControlWord` kwụsịrị SAFETY: enyochala nkuzi `fnstcw` iji nwee ike ịrụ ọrụ nke ọma na `u16` ọ bụla.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Anyị na-eji syntax ATT iji kwado LLVM 8 na LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Debe okwu akara na nkenke chọrọ.
        // A na-enweta nke a site na ikpuchi nkenke ochie ahụ (bits 8 na 9, 0x300) ma dochie ya na ọkọlọtọ nkenke nke agbakọtara n'elu.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Zọ ngwangwa nke Bellerophon n'iji igwe na-eju eju na igwe.
///
/// Nke a na-amịpụta n'ime ọrụ dị iche iche ka e wee nwaa ya tupu ịme bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Anyị na-atụle uru bara uru na MAX_SIG na njedebe, nke a bụ naanị ịjụ ọsọ ọsọ ọsọ, ma dịkwa ọnụ ala (ma wepu koodu ndị ọzọ na ichegbu onwe gị maka ide mmiri).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Fastzọ ọsọ ọsọ na-adabere na mgbakọ na mwepụ na-eme ka ọnụọgụ ziri ezi na-enweghị usoro ọ bụla.
    // Na x86 (na-enweghị SSE ma ọ bụ SSE2) nke a chọrọ nkenke nke nchịkọta x87 FPU ka ọ gbanwee ka ọ gbanye 64/32 bit ozugbo.
    // Ọrụ `set_precision` na-elezi anya ịtọ ntọala na ụkpụrụ ụlọ nke chọrọ ịtọ ya site na ịgbanwe ọnọdụ ụwa (dịka okwu njikwa nke x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Okwu ikpe e <0 enweghị ike apịaji na branch ọzọ.
    // Ike na-adịghị mma na-eme ka akụkụ akụkụ ọnụọgụ abụọ na ọnụọgụ abụọ, nke a na-agbakọta, nke na-akpata ezigbo (na mgbe ụfọdụ dị oke mkpa!) Nsonaazụ na njedebe ikpeazụ.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algọridim Bellerophon bụ obere koodu ziri ezi site na ọnụọgụ ọnụọgụ na-enweghị isi.
///
/// Ọ na-agba `` f '' ka ọ na-ese n'elu mmiri nke nwere ntakịrị ntakịrị ihe 64 ma baa ya ụba site na mma kacha mma nke `10^e` (n'otu usoro iji ese mmiri).Nke a na-ezukarị iji nweta nsonaazụ ziri ezi.
/// Otú ọ dị, mgbe n'ihi bụ nso gara ọkara n'etiti abụọ n'akụkụ (ordinary) floats, na compound ịchịkọta njehie si amụba abụọ mkpachi n'aka n'ihi ike oyi site na a ole na ole ibe n'ibe.
/// Mgbe nke a mere, usoro algọridim R na-edozi ihe.
///
/// A na-eme "close to halfway" aka-wavy kpọmkwem site na nyocha ọnụọgụ na akwụkwọ.
/// N'okwu Clinger:
///
/// > Slop, nke egosiputara na nkeji nke obere ihe pere mpe, bu ihe agnyere nke mehiere
/// > akwakọba n'oge oge na-ese n'elu mmiri na-agbakọ agbako f * 10 ^ e.(Slop bụ
/// > ọ bụghị ihe agbụ maka ezi njehie, mana ókè dị n'etiti etiti z na
/// > ihe kacha mma enwere ike iji mee ihe na-eji p. bara uru.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Okwu ikpe abs(e) <log5(2^N) dị na fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Oke ugwu o zuru ezu ime ihe di iche mgbe o na-agota na nbe?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algọridim na-agbanwe agbanwe nke na-eme ka ihe dị mma nke `f * 10^e`.
///
/// Ntughari ọ bụla na-enweta otu nkeji na njedebe ikpeazụ, nke ga-ewe ogologo oge iji gbakọta ma ọ bụrụ na `z0` dị nwayọ nwayọ.
/// O di nwute, mgbe ejiri ya mee ihe maka Bellerophon, achoputara ihe ichoro site na otutu ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Choo otutu ndi mmadu `x`, `y` dika `x / y` bu `(f *10^e) / (m* 2^k)`.
        // Nke a abụghị naanị na-egbochi ịmekọrịta ihe ịrịba ama nke `e` na `k`, anyị na-ewepụkwa ike nke mmadụ abụọ na-ahụkarị na `10^e` na `2^k` iji mee ka ọnụ ọgụgụ dị obere.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Edere ihe a ntakịrị ihe n'ihi na nhụsianya anyị anaghị akwado ọnụọgụ na-adịghị mma, yabụ anyị na-eji ọnụ ahịa zuru oke + ozi akara.
        // Ntughari na m_digits enweghị ike ịmubiga ókè.
        // Ọ bụrụ na `x` ma ọ bụ `y` buru ibu nke na anyị kwesịrị ichegbu onwe anyị banyere njupụta, mgbe ahụ ha bukwara oke na `make_ratio` belatara obere akụkụ ahụ site na ihe 2 ^ 64 ma ọ bụ karịa.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Achọghị x ọzọ, chekwaa clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Achọrọ y, mepụta otu.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Nyere `x = f` na `y = m` ebe `f` na-anọchi anya ọnụọgụ ọnụọgụ ntinye dị ka ọ dị na mbụ na `m` bụ ihe pụtara ihe na-ese n'elu mmiri, mee ka `x / y` nhata `(f *10^e) / (m* 2^k)`, ikekwe belata site na ike nke abụọ ha abụọ nwekọrọ ọnụ.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, belụsọ na anyị na-ebelata nta ahụ site na ike ụfọdụ nke abụọ.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Nke a enweghị ike ijupụta n'ihi na ọ chọrọ `e` dị mma na `k` na-adịghị mma, nke nwere ike ime naanị maka ụkpụrụ dịkarịsịrị 1, nke pụtara na `e` na `k` ga-adị ntakịrị.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Nke a enweghị ike ijupụta ma, lee n'elu.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ọzọ na-ebelata site na ike nkịtị nke abụọ.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// N'uche, Algọridim M bụ ụzọ kachasị mfe iji tọghata ntụpọ na mmiri.
///
/// Anyị na-etolite nhatanha nke `f * 10^e`, wee tụfuo n'ike nke abụọ rue mgbe ọ ga-enye ezigbo nnabata mmiri.
/// Xary ọnụọgụ ọnụọgụ abụọ `k` bụ ọnụọgụ nke ugboro anyị gbakọtara ọnụ ọgụgụ ma ọ bụ denominator na abụọ, ya bụ, oge niile `f *10^e` na `(u / v)* 2^k`.
/// Mgbe anyị chọpụtara ihe dị mkpa, naanị anyị ga-agagharị site na inyocha ihe fọdụrụ nke nkewa ahụ, nke emere na ọrụ enyemaka ọzọ n'okpuru.
///
///
/// Nke a algọridim dị oke nwayọ, ọbụlagodi na njikarịcha akọwapụtara na `quick_start()`.
/// Agbanyeghị, ọ kachasị mfe nke algọridim ahụ iji megharịa maka nsonaazụ, mmiri mmiri, na nsonaazụ ndị ọzọ.
/// Mmejuputa iwu a weghaara mgbe Bellerophon na algorithm R juputara.
/// Chọpụta mmiri mmiri na njupụta dị mfe: Nhazi ahụ ka bụ ihe dị oke mkpa, mana enwetala onye ngosi minimum/maximum.
/// N'ihe banyere ịba ụba, anyị na-alaghachi azụ.
///
/// Ijikwa underflow na subnormals bụ trickier.
/// Otu nnukwu nsogbu bụ na, yana opekata mpe ihe ngosi, ihe ruru nwere ike ibu oke ibu maka ihe bara uru.
/// Hụ underflow() maka nkọwa.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME njikarịcha na-ekwe omume: na-achịkọta big_to_fp ka anyị nwee ike ime ihe yiri nke fp_to_float(big_to_fp(u)) ebe a, naanị na-enweghị nchịkọta abụọ.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Anyị ga-akwụsị na opekata mpe ihe, ma ọ bụrụ na anyị echere ruo `k < T::MIN_EXP_INT`, mgbe ahụ anyị ga-apụ site na ọnụọgụ abụọ.
            // Dị mwute ikwu na nke a pụtara na anyị ga-special-ikpe nkịtị nọmba na nke kacha nta exponent.
            // FIXME chọta usoro mara mma karị, mana gbaa ọsọ `tiny-pow10` iji jide n'aka na ọ bụ eziokwu!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Skips karịrị ọtụtụ algorithm M iterations site na ịlele bit ogologo.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ogologo bit bụ atụmatụ nke isi abụọ logarithm, na log(u / v) = log(u), log(v).
    // Ebumnuche ahụ kwụsịrị na ọtụtụ 1, ma na-eme atụmatụ mgbe niile, yabụ njehie na log(u) na log(v) bụ otu akara ma kagbuo (ma ọ bụrụ na ha abụọ buru ibu).
    // Yabụ njehie nke log(u / v) bụkwa nke kachasị.
    // Ebumnuche lekwasịrị anya bụ otu ebe u/v dị na oke-mkpa.Ya mere ọnọdụ nkwụsị anyị bụ log2(u / v) ịbụ ihe dị mkpa, plus/minus otu.
    // FIXME I lee anya nke abụọ nwere ike imezi atụmatụ ahụ ma zere ụfọdụ nkewa.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow ma ọ bụ subnormal.Hapụ ya na isi ọrụ.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ọfufe.Hapụ ya na isi ọrụ.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratio abụghị ihe dị oke mkpa na nke kacha nta, yabụ anyị kwesịrị iwepụ oke bits ma gbanwee ihe ngosi ahụ.
    // Uru dị ugbu a dị ka nke a:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q akpịrị.(anọchi anya rem)
    //
    // Ya mere, mgbe ihe ndị a mechiri emechi bụ!= 0.5 ULP, ha na-ekpebi ịgagharị n'onwe ha.
    // Mgbe ha nha nha ma nke fọdụrụ bụ nke efu, ọnụ ahịa ka kwesiri ịkọkọta.
    // Naanị mgbe ihe ndị a mechiri emechi bụ 1/2 na nke fọdụrụ bụ efu, anyị nwere ọnọdụ ọkara ọkara.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Nkịtị-to-even, obfuscated site na iji gbaa gburugburu dabere na ndị fọdụrụ nke a nkewa.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}