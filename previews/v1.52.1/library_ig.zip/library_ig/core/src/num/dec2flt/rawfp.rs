//! Iberibe ihe na IEEE 754 na-ese n'elu mmiri.Nọmba adịghị mma anaghị achọ ya.
//! Nkịtị sere n'elu ebe nọmba nwere a mejupụtara onodi ka (frac, exp) dị otú ahụ na uru bụ 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ebe N bụ ọnụ ọgụgụ nke ibe n'ibe.
//!
//! Subnormals dịtụ iche ma dị egwu, mana otu ụkpụrụ ahụ metụtara.
//!
//! N'ebe a, Otú ọ dị, anyị na-anọchi anya ha dị ka (sig, k) na f mma, nke mere na uru ahụ bụ f *
//! 2 <sup>e</sup> .E wezụga ime "hidden bit" ka ọ pụta ìhè, nke a gbanwere onye ntụgharị site na nke a na-akpọ ngbanwe mantissa.
//!
//! N`uzo ozo, a na ede dika floats dika (1) mana n`ebe a ka edere ha dika (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Anyi na-akpo (1) the **fractional representation** na (2) the **integral representation**.
//!
//! Ọtụtụ ọrụ dị na modulu a na-ejikwa nọmba nkịtị.Omume dec2flt na-eji nwayọ na-ewe ụzọ nwayọ nwayọ-(algorithm M) maka obere pere mpe ma pere mpe.
//! Algọridim ahụ chọrọ naanị next_float() nke na-edozi subnormals na zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Ihe inyeaka trait iji zere imepụta ihe niile koodu ntugharị maka `f32` na `f64`.
///
/// Hụ nkọwa modulu nne na nna maka ihe kpatara nke a ji dị mkpa.
///
/// Kwesịrị ka **tinye ya n'ọrụ** maka ụdị ndị ọzọ ma ọ bụ jiri ya mee ihe na mpụga usoro dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Useddị nke `to_bits` na `from_bits` ji.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Na-emefe transmutation na ntinye.
    fn to_bits(self) -> Self::Bits;

    /// Na-emefe ntụgharị site na ntanetị.
    fn from_bits(v: Self::Bits) -> Self;

    /// Laghachi otu udi nọmba a dara.
    fn classify(self) -> FpCategory;

    /// Laghachi mantissa, mbido ma banye dị ka ọnụ ọgụgụ.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Ntughari n'elu mmiri.
    fn unpack(self) -> Unpacked;

    /// Nkedo site na obere integer nke enwere ike ịnọchite anya ya.
    /// Panic ma ọ bụrụ na enweghi ike ịnọchite anya ya, koodu ọzọ dị na modul a anaghị ekwe ka nke ahụ mee.
    fn from_int(x: u64) -> Self;

    /// Nweta uru 10 <sup>e</sup> site na tebụl akwadoro.
    /// Panics maka `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ihe aha ahụ na-ekwu.
    /// Ọ dị mfe ịme koodu siri ike karịa ịtụgharị uche n'ihe omimi ma nwee olile anya na LLVM na-agbanwe ya mgbe niile.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Onye na-eche nche na-ejikọ aka na ọnụọgụ ntinye nke ntinye nke na-enweghị ike ịmubiga oke ma ọ bụ efu ma ọ bụ
    /// subnormals.Eleghị anya, ihe nnọchi anya decimal nke kachasị uru kwesịrị, ya mere aha ahụ.
    const MAX_NORMAL_DIGITS: usize;

    /// Mgbe ọnụọgụ ọnụọgụ ọnụọgụ kachasị dị mkpa nwere ọnụ ọgụgụ dị elu karịa nke a, ọnụ ọgụgụ na-agagharị na njedebe.
    ///
    const INF_CUTOFF: i64;

    /// Mgbe ndị kasị dị ịrịba ntụpọ ọbula nwere ebe uru na-erughị a, ọnụ ọgụgụ na-na-mechie ka efu.
    ///
    const ZERO_CUTOFF: i64;

    /// Ọnụ ọgụgụ nke ibe na expires.
    const EXP_BITS: u8;

    /// Ọnụ ọgụgụ nke ibe na ihe bara uru,*gụnyere* bit zoro ezo.
    const SIG_BITS: u8;

    /// Ọnụ ọgụgụ nke ibe na ihe bara uru,*ewepu* bit zoro ezo.
    const EXPLICIT_SIG_BITS: u8;

    /// Oke kachasịrị iwu na-egosipụta ihe pere mpe.
    const MAX_EXP: i16;

    /// Opekempe onye na-eme iwu n'ụzọ na-anọchite anya fractional, ewepu subnormals
    const MIN_EXP: i16;

    /// `MAX_EXP` maka ihe nnọchiteanya, yabụ, site na itinye ngbanwe.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (ntụgharị, na dechapụ echiche ọjọọ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` maka ihe nnọchiteanya, yabụ, site na itinye ngbanwe.
    const MIN_EXP_INT: i16;

    /// Oke kachasị dị mkpa na nnọchite anya.
    const MAX_SIG: u64;

    /// Obere ihe dị mkpa dị mkpa na nnọchite anya.
    const MIN_SIG: u64;
}

// Ọ bụkarịrị ebe mgbatị maka #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Laghachi mantissa, mbido ma banye dị ka ọnụ ọgụgụ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Ọpụpụ onye na-agbanwe agbanwe + mantissa gbanwere
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ejighi n'aka ma `as` gbara gburugburu na nyiwe niile.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Laghachi mantissa, mbido ma banye dị ka ọnụ ọgụgụ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Ọpụpụ onye na-agbanwe agbanwe + mantissa gbanwere
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ejighi n'aka ma `as` gbara gburugburu na nyiwe niile.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Atọghata `Fp` ka kacha nso igwe ise n'elu ụdị.
/// Anaghị edozi nsonaazụ ndị ọzọ.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f bụ 64 bit, ya mere xe nwere mgbanwe mantissa nke 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Gharia ihe 64-bit putara na ibe T::SIG_BITS na ọkara rue.
/// Anaghi eme ihe mmefu.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Gbanwee mgbanwe mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Ntughari nke `RawFloat::unpack()` maka ọnụ ọgụgụ nkịtị.
/// Panics ma ọ bụrụ na ihe pụtara ma ọ bụ onye ngosipụta adịghị adaba maka ọnụọgụ ederede.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Wepu bit zoro ezo
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Gbanwee onye na-eme ihe ma na-eme mgbanwe
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Hapụ akara aka na 0 ("+"), ọnụọgụ anyị niile dị mma
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Rụọ ihe ọdịiche.Anabatara mantissa nke 0 ma wuo efu.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Encoded exporter bụ 0, ihe ịrịba ama bit bụ 0, n'ihi ya, naanị anyị ga-edegharịrị ibe n'ibe.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Odika bignum na Fp.Agba gburugburu n'ime 0.5 ULP na ọkara ruo ọbụna.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Anyị na-ebipu ihe niile tupu ọnụọgụ `start`, yabụ, anyị na-agbanwe ntụgharị nke ọma site na `start`, yabụ na ọ bụ onye nwe ihe anyị chọrọ.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Gburugburu (half-to-even) dabere na ibe n'ibe.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Achọta ọtụtụ ihe na-ese n'elu mmiri na-adịkarị obere karịa esemokwu ahụ.
/// Anaghị edozi subnormals, efu, ma ọ bụ na-ebuba mmiri.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Chọta obere ọnụọgụ ụgbọ mmiri na-ebu ibu karịa esemokwu ahụ.
// Ọrụ a bụ saturating, ntụgharị, next_float(inf) ==inf.
// N'adịghị ka ọtụtụ koodu na modul a, ọrụ a na-arụ efu, subnormals, na infinities.
// Agbanyeghị, dịka koodu ndị ọzọ niile ebe a, ọ naghị emeso NaN na ọnụọgụ adịghị mma.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Nke a dị oke mma ịbụ eziokwu, mana ọ na-arụ ọrụ.
        // 0.0 bụ koodu dị ka mkpụrụ-efu niile.Submormals bụ 0x000m ... m ebe m bụ mantissa.
        // Karịsịa, nke obere obere ihe bụ 0x0 ... 01 na nke kachasị bụ 0x000F ... F.
        // The kasị nta nkịtị nọmba bụ 0x0010 ... 0, otú a nkuku ikpe na-arụ ọrụ dị ka nke ọma.
        // Ọ bụrụ na mmụba ahụ juputara na mantissa ahụ, ibu ahụ na-ebu ihe a na-eme ka ọ bụrụ ihe anyị chọrọ, na ihe ndị ahụ na-eme ka ọ bụrụ efu.
        // N'ihi nkwekọrịta zoro ezo bit, nke a bụkwa kpọmkwem ihe anyị chọrọ!
        // Na mmechi, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}