macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Obere uru nke enwere ike ịnọchite anya ụdị ntanetị a.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Uru kachasị nwere ike ịnọchite anya ụdị ntanetị a.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Hà nke integer ụdị na ibe n'ibe.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Na-atụgharị eriri iberi na ntọala enyere na ntanetị.
        ///
        /// A na-atụ anya na eriri ahụ ga-abụ nhọrọ `+` nhọrọ nke ọnụọgụ ga-esote.
        ///
        /// Idu ndu ma na-esochi oghere na-anọchi anya mmejọ.
        /// Nọmba bụ ngalaba nke mkpụrụedemede ndị a, dabere na `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ọrụ a panics ma ọ bụrụ na `radix` adịghị na nso site na 2 ruo 36.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Weghachite ọnụ ọgụgụ ndị na nnọchite ọnụọgụ abụọ nke `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Weghachite ọnụ ọgụgụ nke efu na nnochi ọnụọgụ abụọ nke `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Weghachite ọnụ ọgụgụ nke na-eduga efu na nnọchite ọnụọgụ abụọ nke `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Weghachite ọnụ ọgụgụ nke efu efu na nnọchi ọnụọgụ nke `self`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Weghachite ọnụ ọgụgụ ndị na-eduga na nnọchite ọnụọgụ abụọ nke `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Weghachite ọnụ ọgụgụ nke ndị na-eso ụzọ na nnọchite ọnụọgụ abụọ nke `self`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Na-agbanwe ego ndị a n'akụkụ aka ekpe site na ego a kapịrị ọnụ, `n`, na-ekechi ibe n'ibe ahụ na njedebe nke nọmba ahụ.
        ///
        ///
        /// Biko mara na nke a abụghị ọrụ dịka onye na-agbanwe ọrụ `<<`!
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Na-agbanye ihe ndị a gaa n'aka nri site na ego a kapịrị ọnụ, `n`, na-ekechi ibe n'ibe ahụ na mmalite nke integer na-akpata.
        ///
        ///
        /// Biko mara na nke a abụghị ọrụ dịka onye ọrụ ngbanwe `>>`!
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Na-agbanwe usoro iwu nke integer.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ka m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Na-agbanwe usoro nke ibe na ntanetị.
        /// Nke pere mpe dị ntakịrị bụrụ nke kachasị dị oke mkpa, nke abụọ pere mpe-dị ntakịrị bụrụ nke abụọ dị oke mkpa, wdg.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ka m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Atọghata integer si na nnukwu endian gaa na endianness ahụ.
        ///
        /// Na nnukwu endian nke a bụ a-op.
        /// Na obere endian na bytes na-gbanwere.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma ọ bụrụ cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ozo {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Atọghata integer si obere endian ka endianness ahụ.
        ///
        /// Na obere endian nke a bụ a-op.
        /// Na nnukwu endian bytes na-agbanwe.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma ọ bụrụ na cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ozo {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Tọghata `self` ka nnukwu endian si zube si endianness.
        ///
        /// Na nnukwu endian nke a bụ a-op.
        /// Na obere endian na bytes na-gbanwere.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma ọ bụrụ cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ọzọ { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ma ọ bụ ghara?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Tọghata `self` ka obere endian si zube endianness.
        ///
        /// Na obere endian nke a bụ a-op.
        /// Na nnukwu endian bytes na-agbanwe.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma ọ bụrụ na cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ọzọ { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Mgbakwunye integer agbakwunyere.
        /// Na-agbakọ `self + rhs`, na-alọghachi `None` ma ọ bụrụ na tojupụtara mere.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Mgbakwunye integer a na-enyochaghị.Na-agbakọ `self + rhs`, na-eche na ọ gafere karịa.
        /// Nke a na-ebute omume a na-akọwaghị mgbe
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Mwepu ntinye integer.
        /// Na-agbakọ `self - rhs`, na-alọghachi `None` ma ọ bụrụ na tojupụtara mere
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Mwepu ntinye integerNa-agbakọ `self - rhs`, na-eche na ọ gafere karịa.
        /// Nke a na-ebute omume a na-akọwaghị mgbe
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Ntughari onu ogugu.
        /// Na-agbakọ `self * rhs`, na-alọghachi `None` ma ọ bụrụ na tojupụtara mere.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Enweghi otutu ntinye aka.Na-agbakọ `self * rhs`, na-eche na ọ gafere karịa.
        /// Nke a na-ebute omume a na-akọwaghị mgbe
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Enyocha integer nkewa.
        /// Gụọ `self / rhs`, weghachite `None` ma ọ bụrụ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div by zero ka enyochala na akara a na-edeghi aha enweghi ozo
                // usoro ọdịda maka nkewa
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Enyocha nkewa Euclidean.
        /// Gụọ `self.div_euclid(rhs)`, weghachite `None` ma ọ bụrụ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Integer fọdụrụnụ.
        /// Gụọ `self % rhs`, weghachite `None` ma ọ bụrụ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div by zero ka enyochala na akara a na-edeghi aha enweghi ozo
                // usoro ọdịda maka nkewa
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Enyocha Euclidean modulo.
        /// Gụọ `self.rem_euclid(rhs)`, weghachite `None` ma ọ bụrụ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Enyocha nha.Ngwakọta `-self`, na-alọghachi `None` belụsọ na `onwe==
        /// 0`.
        ///
        /// Rịba ama na ịgha ụdị nọmba ọ bụla dị mma ga-ejupụta.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Lelee nnofega aka ekpe.
        /// Na-agbakọ `self << rhs`, na-alọghachi `None` ma ọ bụrụ na `rhs` buru ibu karịa ma ọ bụ hà nha ọnụ ọgụgụ bits na `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Enyocha nnofega aka nri.
        /// Na-agbakọ `self >> rhs`, na-alọghachi `None` ma ọ bụrụ na `rhs` buru ibu karịa ma ọ bụ hà nha ọnụ ọgụgụ bits na `self`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Lelee mbanye.
        /// Na-agbakọ `self.pow(exp)`, na-alọghachi `None` ma ọ bụrụ na tojupụtara mere.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ebe exp!=0, n`ikpeazụ, exp ga-abụ 1.
            // Na-emekọ ihe ikpeazụ nke onye na-ebugharị ya iche, ebe ọ bụ na ịtọ ntọala ya emesịa adịghị mkpa ma nwee ike ibute njupụta na-enweghị isi.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating integer mgbakwunye.
        /// Gbasara `self + rhs`, saturating na ọnụọgụ ọnụọgụ kama ịjuju.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturating integer mwepu.
        /// Gbasara `self - rhs`, saturating na ọnụọgụ ọnụọgụ kama ịjuju.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Saturating integer ọtụtụ.
        /// Gbasara `self * rhs`, saturating na ọnụọgụ ọnụọgụ kama ịjuju.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Saturating integer exponentiationation.
        /// Gbasara `self.pow(exp)`, saturating na ọnụọgụ ọnụọgụ kama ịjuju.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Wrapping (modular) mgbakwunye.
        /// Ngwunye `self + rhs`, na-agbanye gburugburu na njedebe nke ụdị ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Wrapping (modular) mwepu.
        /// Ngwunye `self - rhs`, na-agbanye gburugburu na njedebe nke ụdị ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Ichipu (modular) multiplication.
        /// Ngwunye `self * rhs`, na-agbanye gburugburu na njedebe nke ụdị ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// Biko rịba ama na a na-ekenye ihe atụ a n'etiti ụdị ntanetị.
        /// Kedu nke kọwara ihe eji eji `u8` eme ebe a.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Wrapping (modular) nkewa.Gbasara `self / rhs`.
        /// Ikpuchi nkewa na ụdị a na-edeghị aha bụ nkewa nkịtị.
        /// Onweghi uzo imechi nwere ike ime.
        /// Ọrụ a dị, nke mere na a na-atụle arụmọrụ niile na arụmọrụ na-arụ ọrụ.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Ichipu nkewa Euclidean.Gbasara `self.div_euclid(rhs)`.
        /// Ikpuchi nkewa na ụdị a na-edeghị aha bụ nkewa nkịtị.
        /// Onweghi uzo imechi nwere ike ime.
        /// Ọrụ a dị, nke mere na a na-atụle arụmọrụ niile na arụmọrụ na-arụ ọrụ.
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, nke a hà ka `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Wrapping (modular) fọdụrụnụ.Gbasara `self % rhs`.
        /// Ware fọdụrụ ngụkọta oge na unsigned ụdị bụ nanị mgbe fọdụrụnụ ngụkọta oge.
        ///
        /// Onweghi uzo imechi nwere ike ime.
        /// Ọrụ a dị, nke mere na a na-atụle arụmọrụ niile na arụmọrụ na-arụ ọrụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Wrapping Euclidean usoro.Gbasara `self.rem_euclid(rhs)`.
        /// Wrap modulo ngụkọta oge na unsigned ụdị dị nnọọ mgbe nile fọdụrụnụ ngụkọta oge.
        /// Onweghi uzo imechi nwere ike ime.
        /// Ọrụ a dị, nke mere na a na-atụle arụmọrụ niile na arụmọrụ na-arụ ọrụ.
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, nke a hà ka `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ihichapu (modular) negation.
        /// Ngwunye `-self`, na-agbanye gburugburu na njedebe nke ụdị ahụ.
        ///
        /// Ebe ọ bụ na ụdị ndị a na-edeghị aha na-enweghị ihe nhata ọ bụla ngwa niile nke ọrụ a ga-agbanye (ewezuga `-0`).
        /// Maka ụkpụrụ pere mpe karịa nke kwekọrọ na nke kachasị nke nsonaazụ bụ otu ihe ahụ dị ka ịtụba akara aka kwekọrọ.
        ///
        /// Largerkpụrụ ọ bụla buru ibu dị ka `MAX + 1 - (val - MAX - 1)` ebe `MAX` bụ ụdị kachasị akara aka.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// Biko rịba ama na a na-ekenye ihe atụ a n'etiti ụdị ntanetị.
        /// Kedu nke kọwara ihe eji eji `i8` eme ebe a.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise nnofega-aka ekpe;
        /// na-amịpụta `self << mask(rhs)`, ebe `mask` na-ewepụ ihe ọ bụla dị elu nke `rhs` nke ga-eme ka ngbanwe ahụ gafee bitwidth nke ụdị.
        ///
        /// Rịba ama na nke a abụghị * otu ihe dị ka ntụgharị-aka ekpe;a na-egbochi RHS nke ngbanwe ngbanwe-aka ekpe na ụdị nke ụdị ahụ, karịa ọnụọgụ ndị si na LHS weghachite na nsọtụ ọzọ.
        /// Intedị integer oge gboo na-arụ ọrụ [`rotate_left`](Self::rotate_left), nke nwere ike ịbụ ihe ịchọrọ kama.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // NCHEKWA: na masking site bitsize nke ụdị ana achi achi na anyị anaghị ịgbanwee
            // gabiga ókè
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-n'efu bitwise mgbanwe-nri;
        /// na-amịpụta `self >> mask(rhs)`, ebe `mask` na-ewepụ ihe ọ bụla dị elu nke `rhs` nke ga-eme ka ngbanwe ahụ gafee bitwidth nke ụdị.
        ///
        /// Rịba ama na nke a abụghị * otu ihe ahụ dị ka ntụgharị-ikike;a na-egbochi RHS nke ngbanwe ngbanwe-ikike ka ọ bụrụ ụdị nke ụdị ahụ, karịa ọnụọgụ ndị si na LHS weghachite na nsọtụ ọzọ.
        /// Intedị integer oge gboo na-arụ ọrụ [`rotate_right`](Self::rotate_right), nke nwere ike ịbụ ihe ịchọrọ kama.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // NCHEKWA: na masking site bitsize nke ụdị ana achi achi na anyị anaghị ịgbanwee
            // gabiga ókè
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Wrapping (modular) ngabiga.
        /// Ngwunye `self.pow(exp)`, na-agbanye gburugburu na njedebe nke ụdị ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ebe exp!=0, n`ikpeazụ, exp ga-abụ 1.
            // Na-emekọ ihe ikpeazụ nke onye na-ebugharị ya iche, ebe ọ bụ na ịtọ ntọala ya emesịa adịghị mkpa ma nwee ike ibute njupụta na-enweghị isi.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Na-agụta `self` + `rhs`
        ///
        /// Weghachite obere ntanye nke mgbakwunye yana boolean na-egosi ma ọnụọgụ ego ga-eme.
        /// Ọ bụrụ na ọ ga-ejupụta ebe a ga-eweghachi uru ahụ ejiri ya.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Na-agụta `self`, `rhs`
        ///
        /// Weghachite obere mkpirisi nke mwepu yana boolean na-egosi ma mwepu ego ga-eme.
        /// Ọ bụrụ na ọ ga-ejupụta ebe a ga-eweghachi uru ahụ ejiri ya.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Na-agụta ọtụtụ nke `self` na `rhs`.
        ///
        /// Weghachite obere ntughari ya na otu a na-egosi ma onu ogugu enwere ike ime.
        /// Ọ bụrụ na ọ ga-ejupụta ebe a ga-eweghachi uru ahụ ejiri ya.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// Biko rịba ama na a na-ekenye ihe atụ a n'etiti ụdị ntanetị.
        /// Kedu nke kọwara ihe eji eji `u32` eme ebe a.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Na-agụta divisor ahụ mgbe ejiri `self` kee `rhs`.
        ///
        /// Weghachite obere mpempe akwụkwọ nke a yana nke boolean na-egosi ma mwepu ga-emejupụta.
        /// Rịba ama na maka ọnụọgụ ndị na-edeghị aha abanyeghị, yabụ uru nke abụọ bụ `false`.
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Na-agụta ọnụ ọgụgụ nke ngalaba Euclidean `self.div_euclid(rhs)`.
        ///
        /// Weghachite obere mpempe akwụkwọ nke a yana nke boolean na-egosi ma mwepu ga-emejupụta.
        /// Rịba ama na maka ọnụọgụ ndị na-edeghị aha abanyeghị, yabụ uru nke abụọ bụ `false`.
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, nke a hà ka `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Na-agụta ihe fọdụrụnụ mgbe `self` kewara `rhs`.
        ///
        /// Weghachite obere nkpuru ego nke ihe fọdụrụnụ mgbe o kesara ya na otu boolean na-egosi ma ọnụọgụ ego ọ ga-eme.
        /// Rịba ama na maka ọnụọgụ ndị na-edeghị aha abanyeghị, yabụ uru nke abụọ bụ `false`.
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Na-agụta `self.rem_euclid(rhs)` fọdụrụnụ dịka ọ bụrụ site na nkewa Euclidean.
        ///
        /// Alaghachi a tuple nke modulo mgbe nkerisi tinyere a boolean-egosi ma ihe som ejupụta ga-eme.
        /// Rịba ama na maka ọnụọgụ ndị na-edeghị aha abanyeghị, yabụ uru nke abụọ bụ `false`.
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, ọrụ a na `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negates onwe na ihe jubigakwara ejiji.
        ///
        /// Weghachi `!self + 1` n'iji arụ ọrụ iji weghachi uru nke na-anọchite anya mmebi nke uru a na-edeghị aha.
        /// Rịba ama na maka ụkpụrụ ndị a na-edeghị aha na-asọpụrụ na-apụta mgbe niile, mana negating 0 anaghị ejupụta.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Na-agbanwe onwe ya site na obere `rhs`.
        ///
        /// Alaghachi a tuple nke gbanwere version nke onwe tinyere a boolean na-egosi ma nnofega uru bụ ibu ma ọ bụ hà ọnụ ọgụgụ nke ibe n'ibe.
        /// Ọ bụrụ na uru ngbanwe dị oke oke, mgbe ahụ, a na-echekwa uru (N-1) ihu ebe N bụ ọnụ ọgụgụ nke ibe, ma jiri uru a rụọ ọrụ ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Na-agbanwe onwe ya site na brik `rhs`.
        ///
        /// Alaghachi a tuple nke gbanwere version nke onwe tinyere a boolean na-egosi ma nnofega uru bụ ibu ma ọ bụ hà ọnụ ọgụgụ nke ibe n'ibe.
        /// Ọ bụrụ na uru ngbanwe dị oke oke, mgbe ahụ, a na-echekwa uru (N-1) ihu ebe N bụ ọnụ ọgụgụ nke ibe, ma jiri uru a rụọ ọrụ ahụ.
        ///
        /// # Examples
        ///
        /// Njiji ojiji
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Na-ewelite onwe gị na ike nke `exp`, na-eji exponentiation site na squaring.
        ///
        /// Alaghachi a tuple nke exponentiation tinyere a bool egosi ma nile mere.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, eziokwu));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scchacha oghere maka ịchekwa nsonaazụ nke rubububigara ókè.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ebe exp!=0, n`ikpeazụ, exp ga-abụ 1.
            // Na-emekọ ihe ikpeazụ nke onye na-ebugharị ya iche, ebe ọ bụ na ịtọ ntọala ya emesịa adịghị mkpa ma nwee ike ibute njupụta na-enweghị isi.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Na-ewelite onwe gị na ike nke `exp`, na-eji exponentiation site na squaring.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ebe exp!=0, n`ikpeazụ, exp ga-abụ 1.
            // Na-emekọ ihe ikpeazụ nke onye na-ebugharị ya iche, ebe ọ bụ na ịtọ ntọala ya emesịa adịghị mkpa ma nwee ike ibute njupụta na-enweghị isi.
            //
            //
            acc * base
        }

        /// Na-eme nkewa Euclidean.
        ///
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, nke a hà ka `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Na-agụta ihe fọdụrụnụ nke `self (mod rhs)`.
        ///
        /// Ebe ọ bụ na, maka ọnụ ọgụgụ dị mma, nkọwa niile a na-ahụkarị banyere nkewa bụ otu, nke a hà ka `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ọrụ a ga-panic ma ọ bụrụ na `rhs` bụ 0.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Laghachi `true` ma ọ bụrụ na ọ bụ naanị `self == 2^k` maka ụfọdụ `k`.
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Alaghachi otu ihe na-erughị esote ike nke abụọ.
        // (Maka 8u8 ike ọzọ nke abụọ bụ 8u8 na maka 6u8 ọ bụ 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Usoro a enweghị ike iju, dị ka ọ dị na `next_power_of_two` na-erubiga ókè kama ọ na-akwụsị ịlaghachi oke uru nke ụdị ahụ, ma nwee ike ịlaghachi 0 maka 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAFETY: Maka `p > 0`, ọ gaghị enwe ike idozi efu efu.
            // Nke ahụ pụtara na ngbanwe ahụ dị oke oke, ụfọdụ ndị nrụpụta (dị ka intel pre-haswell) nwere arụ ọrụ ctlz nke ọma karịa mgbe esemokwu ahụ abụghị efu.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Weghachite obere ike nke abụọ kariri ma ọ bụ hara ka `self`.
        ///
        /// Mgbe nloghachi uru tojubigara (ntụgharị, `self > (1 << (N-1))` maka ụdị `uN`), ya panics na ọnọdụ nbipu ma nweghachi uru na-agbanye na 0 na ọnọdụ ntọhapụ (naanị ọnọdụ nke usoro nwere ike ịlaghachi 0).
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Weghachite obere ike nke abụọ kariri ma ọ bụ hara ka `n`.
        /// Ọ bụrụ na ike na-esote nke abụọ dị ukwuu karịa uru kachasị nke ụdị ahụ, `None` laghachiri, ma ọ bụghị na ike nke abụọ kechiri na `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Weghachite obere ike nke abụọ kariri ma ọ bụ hara ka `n`.
        /// Ọ bụrụ na ike na-esote nke abụọ dị ukwuu karịa uru kachasị nke ụdị ahụ, uru nloghachi na-agbanye na `0`.
        ///
        ///
        /// # Examples
        ///
        /// Njiji ojiji:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Weghachite ihe ncheta nke integer a dị ka ihe eji ede ihe na nnukwu-endian (network) byte order.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Weghachite nnọchite ebe nchekwa nke nọmba a dị ka usoro ihe eji eme ihe nke obere obere.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Weghachite nnọchite ebe nchekwa nke nọmba a dị ka usoro ihe eji eme ihe nke ọma.
        ///
        /// Dika eji eji ihe eji eme ihe eji eme ihe, a gha eji [`to_be_bytes`] ma obu [`to_le_bytes`], dika o kwesiri.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, ọ bụrụ na cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ozo {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: const ụda n'ihi na integers bụ larịị ochie datatypes otú anyị nwere ike mgbe niile
        // transmute ha ka ha bido
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: integers bụ akwụkwọ ochie datatypes ka anyị nwee ike ịtụgharị ha na mgbe niile
            // arrays nke bytes
            unsafe { mem::transmute(self) }
        }

        /// Weghachite nnọchite ebe nchekwa nke nọmba a dị ka usoro ihe eji eme ihe nke ọma.
        ///
        ///
        /// [`to_ne_bytes`] ekwesịrị ịhọrọ karịa nke a mgbe ọ bụla enwere ike.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ka bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, ọ bụrụ na cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ozo {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: integers bụ akwụkwọ ochie datatypes ka anyị nwee ike ịtụgharị ha na mgbe niile
            // arrays nke bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Mepụta nwa amaala endian integer uru site na nnochi ya dị ka byte array na nnukwu endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// jiri std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ntinye=ezumike;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Mepụta nwa amaala endian integer uru site na nnochi ya dị ka byte array na obere endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// jiri std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ntinye=ezumike;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Mepụta nwa amaala endian integer uru sitere na nnochite ebe nchekwa ya dị ka byte array na nwa afọ endianness.
        ///
        /// Dika eji ihe eji eme ihe eji eme ihe eji eme ihe, okwesiri ighota iji [`from_be_bytes`] ma obu [`from_le_bytes`], dika o kwesiri.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } ozo {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// jiri std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ntinye=ezumike;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: const ụda n'ihi na integers bụ larịị ochie datatypes otú anyị nwere ike mgbe niile
        // transmute ha
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: ọnụ ọgụgụ dị iche iche bụ nke ochie ochie nke mere na anyị nwere ike ịtụgharị ha mgbe niile
            unsafe { mem::transmute(bytes) }
        }

        /// Koodu ohuru kwesiri ịhọrọ iji ya
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Alaghachi kasị nta uru na ike ga-anọchi anya a integer ụdị.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Koodu ohuru kwesiri ịhọrọ iji ya
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Alaghachi ndị kasị ibu uru na ike na-anọchi anya nke a integer ụdị.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}