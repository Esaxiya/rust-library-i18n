//! Rordị njehie maka ntụgharị gaa n'ụdị dị mkpa.

use crate::convert::Infallible;
use crate::fmt;

/// Thedị njehie ahụ laghachitere mgbe mgbanwe ụdị njikọ gbanwere.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Dakọtara kama ịmanye iji jide n'aka na koodu dịka `From<Infallible> for TryFromIntError` dị n'elu ga-arụ ọrụ mgbe `Infallible` ghọrọ aha utu `!`.
        //
        //
        match never {}
    }
}

/// Njehie nke enwere ike weghachite mgbe ị na-enyocha integer.
///
/// Ejiri njehie a dị ka ụdị njehie maka ọrụ `from_str_radix()` na ụdị integer oge ochie, dịka [`i8::from_str_radix`].
///
/// # Ihe nwere ike ịkpata ya
///
/// N'ime ihe ndị ọzọ, enwere ike ịtụba `ParseIntError` n'ihi na ọ na-eduga ma ọ bụ na-esochi ebe ọcha dị na eriri eg, mgbe a na-enweta ya site na ntinye ọkọlọtọ.
///
/// Iji usoro [`str::trim()`] na-eme ka o doo anya na ọ dịghị ebe ọcha na-anọgide tupu ịpị.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum ịchekwa ụdị njehie dị iche iche nwere ike ime ka ọnụọgụ nọmba ghara ịda.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Uru a na-atụgharị enweghị ihe ọ bụla.
    ///
    /// N'ime ihe ndị ọzọ, a ga-ewu ụdị a mgbe ị na-atụgharị eriri efu.
    Empty,
    /// Nwere ọnụọgụ na-enweghị isi na gburugburu ya.
    ///
    /// N'ime ihe ndị ọzọ, a ga-ewu ụdị a mgbe ị na-atụgharị eriri nwere char na-abụghị ASCII.
    ///
    /// A na-ewu ụdịdị a mgbe `+` ma ọ bụ `-` na-ezighi ezi n'ime eriri ma ọ bụ n'onwe ya ma ọ bụ n'etiti ọnụ ọgụgụ.
    ///
    ///
    InvalidDigit,
    /// Integer buru oke ibu ịchekwa ụdị ụdị ọnụọgụ.
    PosOverflow,
    /// Integer pere mpe iji chekwaa ụdị ọnụọgụ iche.
    NegOverflow,
    /// Uru bụ Zero
    ///
    /// A ga-ebupụta ụdị a mgbe eriri eriri nwere uru nke efu, nke ga-abụ iwu na-akwadoghị maka ụdị ndị na-abụghị efu.
    ///
    Zero,
}

impl ParseIntError {
    /// Mepụta ihe zuru ezu banyere ịkọwapụta otu integer na-ada ada.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}