//! Libcore Z0 na-egbochi00
//!
//! Ebumnuche a maka ndị ọrụ nke libcore nke na-ejikọtaghị libstd.
//! Nke a modul na-dị ndabara mgbe `#![no_std]` na-eji na n'otu ụzọ ahụ dị ka ọkọlọtọ ọbá akwụkwọ prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Nchịkọta 2015 nke isi prelude.
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versiondị 2018 nke isi prelude.
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 20dị 2021 nke isi prelude.
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Tinyekwuo ihe.
}