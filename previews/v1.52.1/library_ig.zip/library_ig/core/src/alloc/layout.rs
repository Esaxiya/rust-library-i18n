use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ọ bụ ezie na ejiri ọrụ a n'otu ebe ma nwee ike ịkọwapụta ya, mbọ ndị gara aga iji mee nke a mere ka rustc jiri nwayọ:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Ntọala nke ngọngọ nke ebe nchekwa.
///
/// Ihe atụ nke `Layout` na-akọwa otu nhazi nke ebe nchekwa.
/// Ị na-ewu a `Layout` elu dị ka ihe input inye ihe allocator.
///
/// Nhazi niile nwere oke jikọtara ya na itinye aka na ike.
///
/// (Cheta na layouts bụ *bụghị* chọrọ nwere ndị na-abụghị-zero size, ọ bụ ezie na `GlobalAlloc` achọ na niile na ebe nchekwa na-arịọ na-na-abụghị efu na size.
/// Onye na-akpọ oku ga-ekwenyerịrị na ọnọdụ dị ka nke a zutere, jiri ndị na-ekenye ndị nwere ihe ọ bụla chọrọ, ma ọ bụ jiri ntanetị `Allocator` dị nro.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // oke nke ebe nchekwa achọrọ, nke tụrụ na bytes.
    size_: usize,

    // nhazi nke ebe nchekwa achọrọ, tụrụ na bytes.
    // anyị na-ahụ na nke a bụ ike-abụọ, n'ihi na API dị ka `posix_memalign` chọrọ ya na ọ bụ ihe mgbochi kwesịrị ekwesị ịmanye ndị nrụpụta okirikiri.
    //
    //
    // (Agbanyeghị, anyị anaghị achọ itinye aha=> sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) analogously
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Na-ewu `Layout` site na `size` na `align` nyere, ma ọ bụ laghachi `LayoutError` ma ọ bụrụ na ọnọdụ nke ọ bụla esoghị:
    ///
    /// * `align` agaghị abụ efu,
    ///
    /// * `align` ga-abụ ike nke abụọ,
    ///
    /// * `size`, mgbe a na-achịkọta ya na ọtụtụ `align` kacha nso, agaghị agabiga (yabụ, uru gbara gburugburu ga-erughị ma ọ bụ hara ka `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Ike-nke-abua-egosi mmezi!=0.)

        // Ahazi elu size:
        //   size_rounded_up=(size + mmezi, 1)&! (mmezi, 1);
        //
        // Anyị maara site n'elu na nhazi ahụ!=0.
        // Ọ bụrụ na-agbakwunye (mmezi, 1) anaghị jubiga ókè, mgbe ịchịkọta ga-adị mma.
        //
        // Ọzọ,&-masking na! (Mmezi, 1) ga-wepụ anya naanị ala-iji-ibe n'ibe.
        // Yabụ ọ bụrụ na tojupụtara na nchikota,&&-mask enweghị ike iwepu ihe iji mezie ọgbụgba ahụ.
        //
        //
        // N'elu na-egosi na ịlele maka nchikota ọnụ ọgụgụ dị mkpa ma zuru oke.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: ọnọdụ nke `from_size_align_unchecked` anọwo
        // enyocha n'elu.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Mepụta a okirikiri nhọrọ ukwuu, gafere niile ego.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchekwa dị ka ọ na-anaghị enyocha nkwenye sitere na [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // MGBE AH: : onye na-akpọ oku ga-ekwenye na `align` karịrị efu.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// The kacha nta size na bytes maka a na ebe nchekwa ngọngọ nke a layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Opekempe byte itinye n'ọnọdụ maka nchekwa ebe nchekwa nke a okirikiri nhọrọ ukwuu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Na-ewu `Layout` kwesịrị ekwesị maka ijide uru nke ụdị `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // NCHEKWA: na mmezi na-ekwe nkwa site Rust na-a ike nke abụọ na
        // size + mmezi ngwakọta na-ekwe nkwa dabara anyị adreesị ohere.
        // N'ihi ya jiri onye na-ewughị ihe ebe a iji zere itinye koodu na panics ma ọ bụrụ na ejighị ya nke ọma.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Na-ewepụta okirikiri nhọrọ ukwuu na-akọwa ndekọ nke enwere ike iji kesaa usoro nkwado maka `T` (nke nwere ike ịbụ trait ma ọ bụ ụdị ọzọ anaghị enyocha dị ka iberi).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: lee echiche dị na `new` maka ihe kpatara nke a jiri ụdị dị iche iche na-adịghị mma
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Na-ewepụta okirikiri nhọrọ ukwuu na-akọwa ndekọ nke enwere ike iji kesaa usoro nkwado maka `T` (nke nwere ike ịbụ trait ma ọ bụ ụdị ọzọ anaghị enyocha dị ka iberi).
    ///
    /// # Safety
    ///
    /// Ọrụ a dị mma ịkpọ ma ọ bụrụ na ọnọdụ ndị a jide:
    ///
    /// - Ọ bụrụ na `T` bụ `Sized`, ọrụ a na-adị mma ịkpọ mgbe niile.
    /// - Ọ bụrụ na unsized ọdụ nke `T` bụ:
    ///     - a [slice], ogologo nke ọdụ ọdụ ahụ ga-abụrịrị ihe ntinye ọnụ, yana ogo nke uru niile * (ogologo ogologo ọdụ dị ogologo), ga-adaba na `isize`.
    ///     - a [trait object], mgbe ahụ vtable akụkụ nke pointer ga-arụtụ aka na a nti vtable maka ụdị `T` enwetara site na ihe unsizing coersion, na size nke *dum uru*(ike ọdụ ogologo + statically sized nganiihu) ga-dabara na `isize`.
    ///
    ///     - ihe (unstable) [extern type], mgbe ahụ ọrụ a dị mma ịkpọ oku, mana nwere ike panic ma ọ bụ weghachite uru na-ezighi ezi, ebe ọ bụ na amaghị ụdị nhazi ụzọ.
    ///     Nke a bụ otu omume ahụ dị ka [`Layout::for_value`] na ntinye aka na ọdụ.
    ///     - ma ọbụghị, anaghị ekwe ka akpọọ ọrụ a.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ANY SA: anyị na-agafe ihe ndị dị mkpa maka ọrụ ndị a na onye na-akpọ oku
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: lee echiche dị na `new` maka ihe kpatara nke a jiri ụdị dị iche iche na-adịghị mma
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mepụta `NonNull` nke na-agbanye agba mana ahaziri nke ọma maka nhazi nke a.
    ///
    /// Rịba ama na uru pointer nwere ike na-anọchite anya pointer ziri ezi, nke pụtara na nke a agaghị eji dị ka uru sentinel "not yet initialized".
    /// Tydị nke dị lazily na-ekenye ga-agbaso ụzọ mmalite site n'ụzọ ndị ọzọ.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // NCHEKWA: mmezi na-ekwe nkwa na-na-abụghị efu
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Emepụta a layout akọwa ihe ndekọ ahụ ike ijide a uru nke otu layout ka `self`, ma na-na-na-kwekọọ na itinye n'ọnọdụ `align` (tụrụ na bytes).
    ///
    ///
    /// Ọ bụrụ na `self` enwetala usoro nkwekọrịta, wee laghachi `self`.
    ///
    /// Rịba ama na usoro a anaghị agbakwunye ihe ọ bụla na mkpokọta nha, n'agbanyeghị ma nhazi nke laghachiri nwere nhazi dị iche.
    /// Yabụ, ọ bụrụ na `K` nwere nha 16, `K.align_to(32)` ka * ka nwere nha 16.
    ///
    /// Weghachite njehie ma ọ bụrụ na njikọta nke `self.size()` na `align` e nyere megidere ọnọdụ ndị edepụtara na [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Alaghachi ego nke padding anyị ga-fanye mgbe `self` iji hụ na ndị na-esonụ na adreesị ga-egbo `align` (tụrụ na bytes).
    ///
    /// ịmaatụ, ọ bụrụ na `self.size()` bụ 9, mgbe ahụ `self.padding_needed_for(4)` laghachiri 3, n'ihi na nke ahụ bụ opekempe ọnụọgụ nke bytes nke padding chọrọ iji nweta adreesị 4 jikọtara (na-eche na ngọngọ ebe nchekwa kwekọrọ na-amalite na adreesị 4-kwekọrịtara).
    ///
    ///
    /// Nloghachi uru nke ọrụ a enweghị ihe ọ pụtara ma ọ bụrụ na `align` abụghị ike-nke-abụọ.
    ///
    /// Rịba ama na uru nke uru a laghachiri chọrọ `align` ka ọ ga-erughị ma ọ bụ hara nhata nke adreesị mmalite maka ebe nchekwa niile ekenyela.Otu ụzọ iji gboo mgbochi a bụ iji hụ na `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Achịkọta uru bụ:
        //   len_rounded_up=(len + mmezi, 1)&! (mmezi, 1);
        // na mgbe ahụ anyị na-eweghachi padding dị iche: `len_rounded_up - len`.
        //
        // Anyị na-eji usoro mgbakọ na mwepụ na mpaghara niile:
        //
        // 1. mmezi ga-abụ> 0, yabụ kwadozie, 1 na-arụ ọrụ.
        //
        // 2.
        // `len + align - 1` nwere ike jubiga ókè na ọtụtụ `align - 1`, yabụ&-mask nwere `!(align - 1)` ga-ahụ na n'ihe banyere njupụta, `len_rounded_up` ga-abụ 0.
        //
        //    N'ihi ya, laghachi padding, mgbe agbakwunyere `len`, amịrị 0, nke trivially afọ itinye n'ọnọdụ `align`.
        //
        // (N'ezie, ịnwa ịtọọ ebe nchekwa nke oke ya na mpempe akwụkwọ ya n'ụzọ dị n'elu kwesịrị ime ka onye na-ekenye ya iwepụta njehie n'agbanyeghị.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Emepụta a layout site ịchịkọta a hà layout ruo a multiple nke layout si itinye n'ọnọdụ.
    ///
    ///
    /// Nke a dakọtara na ịgbakwunye nsonaazụ nke `padding_needed_for` na nha ugbua.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Nke a enweghị ike ijupụta.Na-ehota site na onye na-agbanwe agbanwe nke nhazi:
        // > `size`, mgbe achikota ya na otutu kacha nso nke `align`,
        // > ga dịghị ejupụta (ie, na ahazi uru ga-erughị
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Na-emepụta okirikiri nhọrọ ukwuu na-akọwa ndekọ maka `n` oge nke `self`, yana ọnụọgụ kwesịrị ekwesị dị n'etiti nke ọ bụla iji hụ na enyere ọkwa ọ bụla nha ya na nhazi ya.
    /// Na ihe ịga nke ọma, laghachi `(k, offs)` ebe `k` bụ nhazi nke usoro ahụ na `offs` bụ ebe dị anya n'etiti mmalite nke mmewere ọ bụla na usoro ahụ.
    ///
    /// Na mgbakọ som, laghachi `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Nke a enweghị ike ijupụta.Na-ehota site na onye na-agbanwe agbanwe nke nhazi:
        // > `size`, mgbe achikota ya na otutu kacha nso nke `align`,
        // > ga dịghị ejupụta (ie, na ahazi uru ga-erughị
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align ka amagoro na ọ dị ire ma tinyelarị_size
        // padded ugbua.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Na-emepụta okirikiri nhọrọ ukwuu na-akọwa ndekọ maka `self` sochiri `next`, gụnyere ihe ọ bụla dị mkpa iji hụ na `next` ga-arụzi nke ọma, mana *enweghị trailing padding*.
    ///
    /// Iji mee ka nhazi C na-anọchite anya `repr(C)`, ị kwesịrị ịkpọ `pad_to_align` mgbe ị gbatịchara atụmatụ ahụ na mpaghara niile.
    /// (Enweghị ụzọ iji kwekọọ na ndabara nnọchite anya Rust ndegharị `repr(Rust)`, as it is unspecified.)
    ///
    /// Rịba ama na nhazi nke nhazi ga-abụ nke kachasị nke nke `self` na `next`, iji hụ na nhazi nke akụkụ abụọ ahụ.
    ///
    /// Alaghachi `Ok((k, offset))`, ebe `k` bụ layout nke concatenated ndekọ na `offset` bụ ikwu na ọnọdụ, na bytes, nke na mmalite nke `next` agbakwunyere n'ime concatenated ndekọ (anya isi na ihe ndekọ onwe ya na-amalite mgbe dechapụ 0).
    ///
    ///
    /// Na mgbakọ som, laghachi `LayoutError`.
    ///
    /// # Examples
    ///
    /// Iji gbakọọ nhazi nke usoro `#[repr(C)]` na njedebe nke ubi site na nhazi nke ubi ya:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Cheta imecha ya na `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // nwalee na ọ na-arụ ọrụ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Mepụta nhazi nke na-akowa ihe edere banyere `n` instances nke `self`, na enweghi ntanye n'etiti onodu obula.
    ///
    /// Rịba ama na, n'adịghị ka `repeat`, `repeat_packed` anaghị ekwe nkwa na a ga-emezi `self` ugboro ugboro, ọbụlagodi na ihe atụ `self` enyere.
    /// Yabụ, ọ bụrụ na ejiri nhazi nke `repeat_packed` weghachite wepụta otu usoro, ọ gaghị ekwe nkwa na ihe niile dị n'usoro ga-arụzi nke ọma.
    ///
    /// Na mgbakọ som, laghachi `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Emepụta a layout akọwa ndekọ maka `self` sochiri `next` na ọ dịghị ọzọ na padding n'etiti abụọ.
    /// Ebe ọ bụ na etinyeghị padding, nhazi nke `next` adịghị mkpa, ma etinyeghị ya *ma ọlị* n'ime nhazi ahụ.
    ///
    ///
    /// Na mgbakọ som, laghachi `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Emepụta a layout akọwa ndekọ maka a `[T; n]`.
    ///
    /// Na mgbakọ som, laghachi `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Ntọala ndị enyere `Layout::from_size_align` ma ọ bụ ụfọdụ ndị na-ewu `Layout` adịghị afọ ojuju ihe mgbochi ederede.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Anyị mkpa a maka downstream impl nke trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}