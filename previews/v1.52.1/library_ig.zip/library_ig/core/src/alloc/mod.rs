//! Nkesa ebe nchekwa APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Njehie `AllocError` na-egosi ọdịda oke nke nwere ike ịbụ n'ihi ike ọgwụgwụ ma ọ bụ ihe na-ezighi ezi mgbe ị na-ejikọ arụmụka ntinye na ntinye a.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Anyị mkpa a maka downstream impl nke trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Mmejuputa nke `Allocator` nwere ike igbunye, too, belata ma gbasaa uzo data akaputara site na [`Layout`][].
///
/// `Allocator` Ezubere iji mejuputa ya na ZSTs, amaokwu, ma obu ihe omuma ihe n'ihi na inwe onye na-ekenye ihe dika `MyAlloc([u8; N])` enweghi ike imeghari, na-emeghi ihe omuma ihe na ebe nchekwa.
///
/// N'adịghị ka [`GlobalAlloc`][], a na-ekwe ka ekenye oke na `Allocator`.
/// Ọ bụrụ na onye na-ekenye ego na-akwadoghị nke a (dị ka jemalloc) ma ọ bụ weghachite poloter efu (dịka `libc::malloc`), ihe a ga-ejide ya.
///
/// ### Ugbu ekenyela ebe nchekwa
///
/// Ụfọdụ n'ime ụzọ na-achọ ka a na ebe nchekwa ngọngọ ga *ugbu ekenyela* via ihe allocator.Nke a pụtara na:
///
/// * na-amalite okwu maka na ebe nchekwa ngọngọ e mbụ laghachi site [`allocate`], [`grow`], ma ọ bụ [`shrink`], na
///
/// * Enweghi ike imeghari ebe nchekwa, ebe ebe a na-etinyezi ihe ndi ozo site na ibufe ya na [`deallocate`] ma obu gbanwee ya site na ibufe ya na [`grow`] ma obu [`shrink`] nke laghachiri `Ok`.
///
/// Ọ bụrụ na `grow` ma ọ bụ `shrink` alọghachila `Err`, pointer gafere ga-adị irè.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memory kwesịrị ekwesị
///
/// Ụfọdụ n'ime ụzọ na-achọ ka a layout *kwesịrị ekwesị* a nchekwa ngọngọ.
/// Ihe ọ pụtara maka okirikiri nhọrọ ukwuu na "fit" ebe nchekwa ngọngọ pụtara (ma ọ bụ otu ihe, maka ngọngọ ebe nchekwa na "fit" nhazi) bụ na ọnọdụ ndị a ga-ejide:
///
/// * A gha ekenye ihe mgbochi ahu site na itinye otu uzo dika [`layout.align()`], ma
///
/// * [`layout.size()`] enyere enyere ga-adaba na `min ..= max` nso, ebe:
///   - `min` bụ size nke layout kasị nso nso-eji na-igbunye ngọngọ, na
///   - `max` bụ nke kachasị ọhụrụ eweghachiri na [`allocate`], [`grow`], ma ọ bụ [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ihe ncheta echetara site na onye na-ekenye ihe ga-arụtụ aka na ebe nchekwa dị mma ma jigide ha dị irè ruo mgbe ihe atụ na clones ya niile kwụsịrị,
///
/// * cloning ma ọ bụ ịkwaga onye na-ekenye ihe agaghị emebi ihe nchekwa ebe nchekwa weghachitere site na onye na-ekenye ya.Onye na-ekenye cloned ga-akpa àgwà dịka otu onye na-ekenye ego, na
///
/// * pointer ọ bụla na ebe nchekwa nke bụ [*currently allocated*] enwere ike ịfefe ya na usoro ọ bụla ọzọ nke onye na-ekenye ihe.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Agbalị igbunye ihe mgbochi nke ebe nchekwa.
    ///
    /// Na ihe ịga nke ọma, na-alaghachikwute [`NonNull<[u8]>`][NonNull] nha nha na ndọtị nke `layout`.
    ///
    /// Ogweghachi azụ nwere ike ịnwe oke karịa nke `layout.size()` kwuru, ma ọ nwere ike ọ gaghị ebido ọdịnaya ya.
    ///
    /// # Errors
    ///
    /// Inglaghachi `Err` na-egosi na nchekwa ọ bụla agwụla ma ọ bụ `layout` anaghị ezute oke nke oke ma ọ bụ nrụgide ndọtị.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi `Err` na ike ọgwụgwụ karịa ịtụ ụjọ ma ọ bụ iwepụ afọ, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Na-akpa àgwà dị ka `allocate`, ma ana achi achi na laghachi na ebe nchekwa bụ efu-initialized.
    ///
    /// # Errors
    ///
    /// Inglaghachi `Err` na-egosi na nchekwa ọ bụla agwụla ma ọ bụ `layout` anaghị ezute oke nke oke ma ọ bụ nrụgide ndọtị.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi `Err` na ike ọgwụgwụ karịa ịtụ ụjọ ma ọ bụ iwepụ afọ, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` weghachite ebe nchekwa dị irè
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates ebe nchekwa referents by `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` ga-egosiputa ngọngọ nke nchekwa [*currently allocated*] site na onye na-ekenye ya, yana
    /// * `layout` ga [*fit*] na ngọngọ nke ebe nchekwa.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Mgbalị ịgbatị ebe nchekwa.
    ///
    /// Weghachite [`NonNull<[u8]>`][NonNull] ọhụrụ nwere pointer na nha nke nchekwa e kenyere.The pointer adabara ejide data kọwara `new_layout`.
    /// Iji mezuo nke a, na allocator nwere ike ịgbatị oke referenced site `ptr` dabara ọhụrụ layout.
    ///
    /// Ọ bụrụ na a na-alaghachikwuru `Ok`, mgbe ahụ, nwe nke ebe nchekwa ngọngọ referenced site `ptr` e zigara a allocator.
    /// The ebe nchekwa nwere ike ma ọ ndị a tọhapụrụ, na a ga-atụle unusable ma ọ e zigara azụ nke bere ọzọ via nloghachi uru nke usoro a.
    ///
    /// Ọ bụrụ na usoro a na-alaghachikwuru `Err`, mgbe ahụ, nwe nke ebe nchekwa ngọngọ bụghị e zigara a allocator, na ọdịnaya nke ebe nchekwa ngọngọ bụ unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` ga-egosipụta ngọngọ nke ebe nchekwa [*currently allocated*] site na nkewa a.
    /// * `old_layout` ga [*fit*] na ngọngọ nke ebe nchekwa (Mkparịta ụka `new_layout` ekwesịghị ịba ya.).
    /// * `new_layout.size()` ga-adị ukwuu karịa ma ọ bụ hà `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Alaghachi `Err` ma ọ bụrụ na ndị ọhụrụ layout adịghị izute allocator hà nakwa itinye n'ọnọdụ ụlọ nke allocator, ma ọ bụ ma ọ bụrụ na na-eto eto ma ada ada.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi `Err` na ike ọgwụgwụ karịa ịtụ ụjọ ma ọ bụ iwepụ afọ, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: n'ihi na `new_layout.size()` aghaghi ibu ma ọ bụ hara nhata
        // `old_layout.size()`, ma ndị ochie na ndị ọhụrụ na ebe nchekwa oke na irè n'ihi na-agụ ma na-ede maka `old_layout.size()` bytes.
        // Ọzọkwa, ebe ọ bụ na e kenyebeghị onyinye ochie ahụ, ọ nweghị ike ijikọ `new_ptr`.
        // Yabụ, ịkpọku na `copy_nonoverlapping` dị mma.
        // Nkwekorita nchekwa maka `dealloc` ga-akwado onye na-akpọ oku.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Na-eme omume dị ka `grow`, ma na-ahụkwa na e debere ọdịnaya ọhụrụ na efu tupu eweghachite ya.
    ///
    /// The ebe nchekwa ngọngọ ga-ebu na-esonụ ọdịnaya mgbe a ọma oku
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` na-echekwa site na oke oke.
    ///   * Bytes `old_layout.size()..old_size` ga-echekwa ma ọ bụ zeroed, dabere na mmejupụta nkewapụta.
    ///   `old_size` na-ezo aka nha nke ebe nchekwa ahụ tupu oku `grow_zeroed`, nke nwere ike ibu karịa nha ahụ arịrịọ mbụ mgbe enyere ya.
    ///   * Bytes `old_size..new_size` abaghị uru.`new_size` na-ezo aka nha nke ebe nchekwa echekwara site na oku `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` ga-egosipụta ngọngọ nke ebe nchekwa [*currently allocated*] site na nkewa a.
    /// * `old_layout` ga [*fit*] na ngọngọ nke ebe nchekwa (Mkparịta ụka `new_layout` ekwesịghị ịba ya.).
    /// * `new_layout.size()` ga-adị ukwuu karịa ma ọ bụ hà `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Alaghachi `Err` ma ọ bụrụ na ndị ọhụrụ layout adịghị izute allocator hà nakwa itinye n'ọnọdụ ụlọ nke allocator, ma ọ bụ ma ọ bụrụ na na-eto eto ma ada ada.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi `Err` na ike ọgwụgwụ karịa ịtụ ụjọ ma ọ bụ iwepụ afọ, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: n'ihi na `new_layout.size()` aghaghi ibu ma ọ bụ hara nhata
        // `old_layout.size()`, ma ndị ochie na ndị ọhụrụ na ebe nchekwa oke na irè n'ihi na-agụ ma na-ede maka `old_layout.size()` bytes.
        // Ọzọkwa, ebe ọ bụ na e kenyebeghị onyinye ochie ahụ, ọ nweghị ike ijikọ `new_ptr`.
        // Yabụ, ịkpọku na `copy_nonoverlapping` dị mma.
        // Nkwekorita nchekwa maka `dealloc` ga-akwado onye na-akpọ oku.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mgbalị iji belata ebe nchekwa.
    ///
    /// Weghachite [`NonNull<[u8]>`][NonNull] ọhụrụ nwere pointer na nha nke nchekwa e kenyere.The pointer adabara ejide data kọwara `new_layout`.
    /// Iji mezuo nke a, onye na-ekenye ihe nwere ike ịbelata oke nke `ptr` rụtụrụ aka iji dabaa nhazi ọhụrụ.
    ///
    /// Ọ bụrụ na a na-alaghachikwuru `Ok`, mgbe ahụ, nwe nke ebe nchekwa ngọngọ referenced site `ptr` e zigara a allocator.
    /// The ebe nchekwa nwere ike ma ọ ndị a tọhapụrụ, na a ga-atụle unusable ma ọ e zigara azụ nke bere ọzọ via nloghachi uru nke usoro a.
    ///
    /// Ọ bụrụ na usoro a na-alaghachikwuru `Err`, mgbe ahụ, nwe nke ebe nchekwa ngọngọ bụghị e zigara a allocator, na ọdịnaya nke ebe nchekwa ngọngọ bụ unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` ga-egosipụta ngọngọ nke ebe nchekwa [*currently allocated*] site na nkewa a.
    /// * `old_layout` ga [*fit*] na ngọngọ nke ebe nchekwa (Mkparịta ụka `new_layout` ekwesịghị ịba ya.).
    /// * `new_layout.size()` ga-nta karịa ma ọ bụ hà `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Weghachite `Err` ma ọ bụrụ na nhazi ọhụrụ anaghị ezute oke oke na ntinye nke onye na-ekenye ihe, maọbụ ọ bụrụ na ịda mba ma ọ daa.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi `Err` na ike ọgwụgwụ karịa ịtụ ụjọ ma ọ bụ iwepụ afọ, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: n'ihi na `new_layout.size()` ga-adị ala karịa ma ọ bụ hara nhata
        // `old_layout.size()`, ma nke ochie ma ebe nchekwa ohuru bara uru maka aguru ya ma edekwa ya maka `new_layout.size()` bytes.
        // Ọzọkwa, ebe ọ bụ na e kenyebeghị onyinye ochie ahụ, ọ nweghị ike ijikọ `new_ptr`.
        // Yabụ, ịkpọku na `copy_nonoverlapping` dị mma.
        // Nkwekorita nchekwa maka `dealloc` ga-akwado onye na-akpọ oku.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mepụta ihe nkwụnye "by reference" maka ihe atụ nke `Allocator`.
    ///
    /// The laghachi nkwụnye nwekwara implements `Allocator` na ga nanị gbaziri a.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}