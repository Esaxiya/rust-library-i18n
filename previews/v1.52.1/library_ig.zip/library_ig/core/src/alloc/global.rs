use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Onye na-ekenye ihe nchekwa nwere ike ịdenye aha dị ka ndabara ọbá akwụkwọ ọkọlọtọ site na njirimara `#[global_allocator]`.
///
/// Ụfọdụ n'ime ụzọ na-achọ ka a na ebe nchekwa ngọngọ ga *ugbu ekenyela* via ihe allocator.Nke a pụtara na:
///
/// * na-amalite okwu maka na ebe nchekwa ngọngọ e mbụ laghachi site a gara aga oku na oke usoro dị ka `alloc`, na
///
/// * ebugharịla ebe nchekwa nchekwa ahụ, ebe a na-emegharị ihe mgbochi ma ọ bụ site na ịgafe usoro nhazi dịka `dealloc` ma ọ bụ site na ịfefe ya na usoro nhazi nke na-eweghachi ihe na-abụghị null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait bụ `unsafe` trait maka ọtụtụ ebumnuche, ndị na-emejuputa iwu ga-ahụrịrị na ha na-agbaso nkwekọrịta ndị a:
///
/// * Ọ bụ undefined omume ma ọ bụrụ na zuru ụwa ọnụ allocators tụsaratụ.Enwere ike ibuli mmachi a na future, mana ugbu a, panic sitere na ọrụ ndị a nwere ike ibute nchedo nchekwa.
///
/// * `Layout` gbara ajụjụ na ịgbakọ n`ozuzu ga-abụ eziokwu.A na-ahapụ ndị na-akpọ trait a ịdabere na nkwekọrịta akọwapụtara na usoro ọ bụla, na ndị na-eme ihe ga-ahụrịrị na ụdị nkwekọrịta ahụ ga-abụ eziokwu.
///
/// * Ị nwere ike ịdabere na allocations n'ezie na-eme, ọbụna ma ọ bụrụ na e nwere doro obo allocations na isi iyi.
/// The optimizer nwere ike ịchọpụta ejibeghi allocations na ọ pụrụ ma kpochapụ kpamkpam ma ọ bụ kwaga tojupụtara na otú mgbe akpọkukwa allocator.
/// Onye njikarịcha nwere ike ịchekwu na oke agaghị agha agha, yabụ koodu nke na-ada ada n'ihi ọdịda ọdịda nwere ike rụọ ọrụ na mberede n'ihi na onye ọrụ njikarịcha na-arụ ọrụ na mkpa maka oke.
/// N'ikwu n'ụzọ doro anya, ihe atụ koodu na-esote adịghị mma, n'agbanyeghị ma onye na-ekenye gị omenala na-enye gị ohere ịgụta ego ole emere.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Rịba ama na njikarịcha ndị a kpọtụrụ aha n'elu abụghị naanị njikarịcha enwere ike itinye n'ọrụ.Ị nwere ike n'ozuzu bụghị ịdabere na obo allocations eme ma ọ bụrụ na ha nwere ike wepụrụ na-enweghị na-agbanwe agbanwe usoro omume.
///   Ma oke ego ọ ga-eme ma ọ bụ na ọ bụghị so na mmemme mmemme ahụ, ọbụlagodi na enwere ike ịchọpụta ya site na onye na-ekenye ego na-etinye oke site na ibipụta ma ọ bụ na-enwe mmetụta ndị ọzọ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Keera ebe nchekwa dị ka `layout` nyere.
    ///
    /// Alaghachi a pointer na ọhụrụ ekenyela na ebe nchekwa, ma ọ bụ ihe efu iji gosi oke oke.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchekwa n'ihi na omume a na-akọwaghị nwere ike ịpụta ma ọ bụrụ na onye na-akpọ oku anaghị achọpụta na `layout` nwere nha efu.
    ///
    /// (Mgbakwunye subtraits nwere ike ịnye oke oke na akparamagwa, dịka, ịkwado adreesị sentinel ma ọ bụ ntụpọ efu na-aza maka arịrịọ oke oke.)
    ///
    /// The ekenyela ngọngọ nke na ebe nchekwa nwere ike ma ọ bụ ghara initialized.
    ///
    /// # Errors
    ///
    /// Laghachi akara null na-egosi na ncheta adịghị agwụ ma ọ bụ `layout` anaghị ezute oke nkesa a ma ọ bụ ihe ndozi.
    ///
    /// A na-agba ndị na-eme ihe ume ka ịlaghachi azụ na ike ọgwụgwụ karịa ịwepụ afọ ime, mana nke a abụghị iwu siri ike.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate ngọngọ nke na ebe nchekwa na nyere `ptr` pointer na nyere `layout`.
    ///
    /// # Safety
    ///
    /// Nke a ọrụ bụ nwedịrị ike ịta n'ihi undefined omume nwere ike ime ma ọ bụrụ nke bere anaghị hụ na niile nke ndị na-esonụ:
    ///
    ///
    /// * `ptr` ga-egosiputa ngọngọ nke ebe nchekwa nke enyere site na nke a,
    ///
    /// * `layout` ga-abụ otu layout e ji igbunye na ngọngọ nke na ebe nchekwa.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Na-akpa àgwà dị ka `alloc`, ma ana achi achi na ọdịnaya na-setịpụrụ efu tupu e laghachi.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchekwa maka otu ihe kpatara `alloc` bụ.
    /// Otú ọ dị na ekenyela oghere nke ebe nchekwa na-ekwe nkwa na-initialized.
    ///
    /// # Errors
    ///
    /// Iweghachi a null pointer na-egosi na ma na ebe nchekwa na-agwụ ma ọ bụ `layout` adịghị izute allocator si size ma ọ bụ itinye n'ọnọdụ ụlọ, dị nnọọ ka na `alloc`.
    ///
    /// A na-agba ndị ahịa na-achọ iweghachi mgbakọ na nzaghachi maka njehie oke ume ịkpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // MGBE: nkwekọrịta nchekwa maka `alloc` ga-akwado onye na-akpọ oku.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // Nchekwa: dị ka oke ịga nke ọma, mpaghara si `ptr`
            // nke size `size` na-ekwe nkwa na-nti n'ihi na-ede.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Gbanyụọ ma ọ bụ tolite ngọngọ nke ebe nchekwa na `new_size` enyere.
    /// A kọwara ngọngọ site na pointer `ptr` nyere na `layout`.
    ///
    /// Ọ bụrụ na nke a weghachite pointer na-enweghị isi, mgbe ahụ ebunyela onye nwe ihe nchekwa a nke `ptr` rụtụrụ aka na onye na-ekenye ya.
    /// Ncheta ahụ nwere ike ọ gaghị enwe ike iwepụta ya, ma a ga-ewere ya ka ọ ghara iji ya rụọ ọrụ (ma ọ bụrụ na agbanyeghị ya na onye na-akpọ oku ọzọ site na nloghachi nke usoro a).
    /// Ejiri `layout` nyefee ihe ncheta ohuru, ma jiri `size` emelitere na `new_size`.
    /// Ekwesịrị iji nhazi ọhụrụ a mee ihe mgbe ị na-ekewa nchekwa nchekwa ọhụụ na `dealloc`.
    /// The nso `0..min(layout.size(), new_size) 'nke ọhụrụ nchekwa ngọngọ na-ekwe nkwa na ha nwere otu ụkpụrụ dị ka ihe mbụ ngọngọ.
    ///
    /// Ọ bụrụ na usoro a laghachiri na null, mgbe ahụ enwetabeghị ikike nke ebe nchekwa a na onye na-ekenye ya, na agbanweghị ọdịnaya nke ebe nchekwa ahụ.
    ///
    /// # Safety
    ///
    /// Nke a ọrụ bụ nwedịrị ike ịta n'ihi undefined omume nwere ike ime ma ọ bụrụ nke bere anaghị hụ na niile nke ndị na-esonụ:
    ///
    /// * `ptr` Ekwesịrị ịkekọrịta ugbu a site na nke a,
    ///
    /// * `layout` ga-abụ otu layout e ji igbunye na ngọngọ nke na ebe nchekwa,
    ///
    /// * `new_size` aghaghi ibu kariri efu.
    ///
    /// * `new_size`, mgbe mechie elu ka kacha nso multiple nke `layout.align()`, ga dịghị ejupụta (ie, na ahazi uru ga-erughị `usize::MAX`).
    ///
    /// (Mgbakwunye subtraits nwere ike ịnye oke oke na akparamagwa, dịka, ịkwado adreesị sentinel ma ọ bụ ntụpọ efu na-aza maka arịrịọ oke oke.)
    ///
    /// # Errors
    ///
    /// Ihe nloghachi na-abaghị uru ma ọ bụrụ na nhazi ọhụrụ anaghị ezute oke na nhazi nke onye na-ekenye ihe, ma ọ bụ ọ bụrụ na nhazigharị na-adaghị.
    ///
    /// Implementations na-ume laghachi null na ebe nchekwa gwụrụ kama panicking ma ọ bụ aborting, ma nke a abụghị a na nlezianya chọrọ.
    /// (Kpọsị: ọ bụ iwu * iji mezuo trait a n'elu isi ụlọ akwụkwọ na-enye oke ala nke na-eme ka ike gwụ ike.)
    ///
    /// A na-agba ndị ahịa na-achọ iwepụ ngụkọta azịza maka mmegharị ọnọdụ na-akpọ ọrụ [`handle_alloc_error`], kama ịkpọku `panic!` ma ọ bụ ihe yiri ya ozugbo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // MGBE: onye na-akpọ oku ga-ekwenye na `new_size` anaghị awụfe.
        // `layout.align()` na-abịa site a `Layout` na si otú a na-ekwe nkwa na-nti.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // MGBE: onye na-akpọ oku ga-ekwenye na `new_layout` karịrị efu.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // MGBE AH: : mgbochi mbu ekenyeghi ike imeghari ngọngọ ahọpụtara ọhụrụ.
            // Nkwekorita nchekwa maka `dealloc` ga-akwado onye na-akpọ oku.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}