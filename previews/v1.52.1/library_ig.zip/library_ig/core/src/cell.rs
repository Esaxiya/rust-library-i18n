//! Ekekọrịta akpa nwere ike ịdị na ya.
//!
//! Nchedo nchekwa Rust dabere na iwu a: N'iburu ihe `T`, ọ ga-ekwe omume ịnweta otu n'ime ndị a:
//!
//! - Inwe ọtụtụ ederede na-enweghị ike ịgbanwe agbanwe (`&T`) na ihe ahụ (a makwaara dị ka **aliasing**).
//! - Inwe otu ihe edeturu ederede (`&mut T`) na ihe (a makwaara dị ka **mutability**).
//!
//! Nke a na-akwanye site Rust compiler.Agbanyeghị, enwere ọnọdụ ebe iwu a anaghị agbanwe agbanwe.Mgbe ụfọdụ, achọrọ ka ị nweta ọtụtụ ntụnye aka n`otu ihe ma tụgharịa ya.
//!
//! E nwere ike ịnwe ihe ndị nwere ike ịgbanwe dị ka ihe ga-eme ka mmadụ kwe ka ọ gbanwee ya, ọbụlagodi na enweghị aha ya.Ma [`Cell<T>`] na [`RefCell<T>`] kwere na-eme nke a na a otu-threaded ụzọ.
//! Agbanyeghị, `Cell<T>` ma ọ bụ `RefCell<T>` enweghị nchekwa (ha anaghị etinye [`Sync`] n'ọrụ).
//! Ọ bụrụ na ị chọrọ ime aliasing na mutation n'etiti multiple eri ọ bụ ike iji [`Mutex<T>`], [`RwLock<T>`] ma ọ bụ [`atomic`] ụdị.
//!
//! Ueskpụrụ nke ụdị `Cell<T>` na `RefCell<T>` nwere ike gbanwee site na ntụgharị ederede (ntụgharị
//! nkịtị `&T` ụdị), ebe ihe ka ọtụtụ Rust ụdị naanị ike mutated site pụrụ iche ('&mut T`) zoro.
//! Anyị na-asị na `Cell<T>` na `RefCell<T>` enye 'ime mutability', na iche na-ahụkarị Rust ụdị na ngosi 'ketara mutability'.
//!
//! Celldị sel abịa na ekpomeekpo abụọ: `Cell<T>` na `RefCell<T>`.`Cell<T>` na-etinye ikike imebi n`ime site n`ime ka ụkpụrụ dị n`ime ma pụọ na `Cell<T>`.
//! Iji jiri ntụaka karịa ụkpụrụ, mmadụ ga-eji ụdị `RefCell<T>`, nweta mkpọchi edemede tupu ọ gbanwee.`Cell<T>` na-enye ụzọ iji weghachite ma gbanwee uru dị n'ime ugbu a:
//!
//!  - Maka ụdị nke mejuputara [`Copy`], usoro [`get`](Cell::get) weghachite uru dị n'ime ugbu a.
//!  - Maka ụdị nke mejupụtara [`Default`], usoro [`take`](Cell::take) na-anọchi uru dị ugbu a na [`Default::default()`] wee weghachite uru a gbanwere.
//!  - N'ihi na ụdị, na [`replace`](Cell::replace) usoro-anọchi ugbu a n'ime ime uru na-alaghachi na-anọchi uru na [`into_inner`](Cell::into_inner) usoro erichapụ ihe `Cell<T>` na-alaghachi ime uru.
//!  Tụkwasị na nke ahụ, usoro [`set`](Cell::set) na-anọchi uru dị n'ime, na-ahapụ uru a gbanwere.
//!
//! `RefCell<T>` na-eji ndụ Rust eme ihe iji mejuputa 'ịgbazinye ego siri ike', usoro nke ga-eme ka mmadụ nwee ike ịnwe ohere nwa oge, nke pụrụ iche, nke nwere ike ịgbanwe na uru dị n'ime.
//! Akwụkwọ maka ``RefCell<T>`` A na-enyocha '' n'oge oge ', n'adịghị ka ụdị akwụkwọ Rust nke ala a na-enyocha kpam kpam, na-achịkọta oge.
//! Ebe ọ bụ na mgbazinye `RefCell<T>` dị ike ọ ga-ekwe omume ịnwa ịgbazite ego agbaziri ego agbaziri agbaziri;mgbe nke a mere na ọ na-apụta na eri panic.
//!
//! # Mgbe ịhọrọ ime ime
//!
//! Mgbanwe a na-ahụkarị nke a ketara eketa, ebe mmadụ ga-enwerịrị ohere pụrụ iche iji wee gbanwee uru, bụ otu n'ime ihe ndị bụ isi asụsụ na-enyere Rust aka ịtụgharị uche n'ụzọ siri ike maka ịkpọtụrụ aha, na-egbochi ọpịpịa mkpọtụ.
//! N'ihi nke ahụ, a na-ahọrọ mgbanwe mutụrụ ketara eketa, na ntụgharị dị n'ime ụlọ bụ ihe ikpeazụ.
//! Ebe ọ bụ na ụdị sel na-eme ka mmụba gbanwee ebe a ga-ajụ ya, enwere oge mgbe mgbanwe dị n'ime nwere ike bụrụ ihe kwesịrị ekwesị, ma ọ bụ ọbụlagodi * a ga-eji ya, eg
//!
//! * Ewebata mutability 'inside' nke ihe immutable
//! * Mmejuputa iwu-nkọwa nke ezi uche-immutable ụzọ.
//! * Mutating implementations nke [`Clone`].
//!
//! ## Ewebata mutability 'inside' nke ihe immutable
//!
//! Ọtụtụ ụdị smart pointer, gụnyere [`Rc<T>`] na [`Arc<T>`], na-enye ihe nwere ike ịkọkọ ma kesaa n'etiti ọtụtụ ndị ọzọ.
//! Maka ụkpụrụ ndị dị na ya nwere ike ịba ụba-aha, ha nwere ike gbaziri naanị `&`, ọ bụghị `&mut`.
//! Enweghị mkpụrụ ndụ ọ ga-abụ ihe na-agaghị ekwe omume ịgbanwe data n'ime ihe ọgụgụ isi ndị a ma ọlị.
//!
//! Ọ bụ ihe a na-ahụkarị mgbe ahụ itinye `RefCell<T>` n'ime ụdị pointer na-akọrọ iji weghachite mutability:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Mepụta ngọngọ ọhụrụ iji belata njedebe nke ịgbazinye ego siri ike
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Rịba ama na ọ bụrụ na anyị ekwebeghị ka ego mgbazinye nke ebe nchekwa ahụ gabiga, mgbe ahụ mgbazinye ego ga-eme ka panic dị ike.
//!     //
//!     // Nke a bụ nsogbu dị egwu n'iji `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Mara na ihe atụ a jiri `Rc<T>` ma ọ bụghị `Arc<T>`.Gbanwee<T>'s bụ maka ihe eji eme otu.Tụlee iji [`RwLock<T>`] ma ọ bụ [`Mutex<T>`] ma ọ bụrụ na ịchọrọ ịkekọrịta mutability na ọnọdụ ọtụtụ-threaded.
//!
//! ## Mmejuputa mmejuputa atumatu nke usoro eji agbanwe agbanwe
//!
//! Mgbe ụfọdụ, ọ nwere ike ịchọ ka ịghara ikpughe na API na enwere mmụba na-eme "under the hood".
//! Nke a nwere ike ịbụ n'ihi na ezi uche na-arụ ọrụ bụ immutable, ma eg, caching agha mmejuputa ịrụ mutation;ma ọ bụ n'ihi na ị ga-eji mutation mejuputa a trait usoro na mbụ kọwaa na-`&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Oké ọnụ mgbakọ na-aga ebe a
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutating implementations nke `Clone`
//!
//! Nke a bụ nanị a pụrụ iche, ma nkịtị, bụrụ na nke gara aga: nzuzo mutability maka arụmọrụ na-egosi ịbụ immutable.
//! A na-atụ anya ka usoro [`clone`](Clone::clone) ghara ịgbanwe isi iyi, wee kwupụta iji `&self`, ọ bụghị `&mut self`.
//! Ya mere, ọ bụla mutation na-eme `clone` usoro ga-eji cell ụdị.
//! Ka ihe atụ, [`Rc<T>`] ekwusi ya akwụkwọ na-adabere n'ime a `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Ebe nchekwa echetara.
///
/// # Examples
///
/// N'ihe atụ a, ị ga-ahụ na `Cell<T>` na-enyere mmụba aka n'ime ihe anaghị agbanwe agbanwe.
/// Ndị ọzọ okwu, ọ na-enyere "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // NJ njehie: `my_struct` bụ immutable
/// // my_struct.regular_field =ohwo ohuru;
///
/// // ỌR: : ọ bụ ezie `my_struct` anaghị agbanwe agbanwe, `special_field` bụ `Cell`,
/// // nke nwere ike mgbe niile-mutated
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Mepụta `Cell<T>`, yana uru `Default` maka T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Na-emepụta `Cell` ọhụrụ nwere uru enyere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Setịpụrụ bara uru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Gbanwee ụkpụrụ nke sel abụọ.
    /// Dị iche na `std::mem::swap` bụ na ọrụ a na-adịghị achọ `&mut` akwụkwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: Nke a nwere ike ịdị ize ndụ ma ọ bụrụ na akpọ ya na eri dị iche iche, mana `Cell`
        // bụ `!Sync` yabụ na nke a agaghị eme.
        // Nke a na-agaghị mebie pointers kemgbe `Cell` na-eme ka n'aka na ihe ọ bụla ọzọ ga-atụ n'ime ma nke ndị a 'Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Dochie uru dị na `val`, wee weghachite ochie nke bara uru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // NCHEKWA: Nke a nwere ike ime ka data agbụrụ ma ọ bụrụ na a na-akpọ site na a iche iche na eri,
        // ma `Cell` bụ `!Sync` otú a ga-eme eme.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Na-ekpughe uru ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Laghachi otu nnomi nke uru bara uru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // NCHEKWA: Nke a nwere ike ime ka data agbụrụ ma ọ bụrụ na a na-akpọ site na a iche iche na eri,
        // ma `Cell` bụ `!Sync` otú a ga-eme eme.
        unsafe { *self.value.get() }
    }

    /// Mmelite nke nwere uru iji a ọrụ na-alaghachi ọhụrụ uru.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Weghachite pointer raw nye ihe data na-akpata na sel a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Laghachi a mutable akwụkwọ na-akpata data.
    ///
    /// Oku a na-agbaziri `Cell` n'ụzọ dị egwu (na mkpokọta oge) nke na-ekwe nkwa na anyị nwere naanị ntụle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Alaghachi a `&Cell<T>` si a `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` ana achi achi uzo puru iche.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ewe uru nke cell, na-ahapụ `Default::default()` n'ọnọdu-ya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Weghachite `&[Cell<T>]` site na `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // Nchekwa: `Cell<T>` nwere otu ebe nchekwa dị ka `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// A mutable ebe nchekwa ọnọdụ na dynamically ndenye ego gbaziri iwu
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Njehie nke [`RefCell::try_borrow`] weghachitere.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Njehie nke [`RefCell::try_borrow_mut`] weghachitere.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive ụkpụrụ na-anọchi anya na ọnụ ọgụgụ nke `Ref` n'ọrụ.Kpụrụ ọjọọ na-anọchi anya ọnụ ọgụgụ nke `RefMut` nọ n'ọrụ.
// Otutu ``RefMut`s nwere ike na-aru oru n'otu oge ma oburu na ha na-ezo aka na ihe di iche, nke na-ewepughi ihe nke `RefCell` (dika, uzo di iche nke uzo).
//
// `Ref` na `RefMut` bụ okwu abụọ na nha, yabụ na ọ nwere ike ọ gaghị ezuru ``Ref`s '' ma ọ bụ 'RefMut`s dị adị gafee ọkara nke `usize`.
// Yabụ, `BorrowFlag` nwere ike ọ gaghị erubiga ma ọ bụ juba.
// Agbanyeghị, nke a abụghị nkwa, dịka mmemme mmemme nwere ike mepụta ugboro ugboro wee mem::forget ``Ref`s ma ọ bụ '' RefMut`s.
// N'ihi ya, ihe niile koodu ga n'ụzọ doro anya na ịlele maka ejupụta na underflow iji zere unsafety, ma ọ bụ ọ dịghị ihe ọzọ na-akpa àgwà ziri ezi na ihe omume ahụ nile ma ọ bụ underflow itịbe (eg, hụ BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Na-emepụta `RefCell` ọhụrụ nke nwere `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Erepịakwa ndị `RefCell`, iweghachiri ọbọp uru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ebe ọ bụ na ọrụ a na-ewere `self` (`RefCell`) site na ọnụ ahịa, onye nchịkọta ahụ gosipụtara n'ụzọ doro anya na ọ naghị agbazi ugbu a.
        //
        self.value.into_inner()
    }

    /// Dochie uru a fụchiri ya na nke ọhụrụ, weghachite nke ochie, na-enweghị nke ọ bụla n`ime ha.
    ///
    ///
    /// Nke a ọrụ kwekọrọ na [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a gbaziri ugbu a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Dochie uru a fụchiri ya na nke ọhụrụ gbakọtara na `f`, na-eweghachi ego ochie, na-enweghị ịkọwa otu.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a gbaziri ugbu a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Gbanwee uru nke `self` nwere uru nke `other` kechiri, na-enweghị ịkọwa otu.
    ///
    ///
    /// Nke a ọrụ kwekọrọ na [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably agbaziri na ọbọp uru.
    ///
    /// Mgbazinye ego na-adịgide ruo mgbe `Ref` laghachiri.
    /// Enwere ike ịgbazinye ọtụtụ agbazinye ego n'otu oge.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a ugbu a mutably biiri.
    /// Maka ụdị dị iche iche na-anaghị atụ ụjọ, jiri [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ihe omuma nke panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Onu ogugu na-ebinye ego nke ọbọp, weghachite njehie ma ọ bụrụ na etinyere uru ahụ ugbu a.
    ///
    ///
    /// Mgbazinye ego na-adịgide ruo mgbe `Ref` laghachiri.
    /// Enwere ike ịgbazinye ọtụtụ agbazinye ego n'otu oge.
    ///
    /// Nke a bụ ndị na-abụghị panicking variant nke [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: `BorrowRef` ana achi achi na enwere uzo enweghi ike ịgbanwe
            // na uru mgbe gbaziri.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Na-agbazinye ego ejiri uru.
    ///
    /// Mgbazinye na-adịgide ruo mgbe `RefMut` laghachiri ma ọ bụ niile `` RefMut '' nke sitere na ya pụọ.
    ///
    /// Enwere ike ịgbazighi uru ebe mgbazinye ego nọ n'ọrụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a gbaziri ugbu a.
    /// N'ihi na a na-abụghị panicking variant, iji [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ihe omuma nke panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably agbaziri na ọbọp uru, na-alọta njehie ma ọ bụrụ na uru a ugbu a biiri.
    ///
    ///
    /// Mgbazinye na-adịgide ruo mgbe `RefMut` laghachiri ma ọ bụ niile `` RefMut '' nke sitere na ya pụọ.
    /// Enwere ike ịgbazighi uru ebe mgbazinye ego nọ n'ọrụ.
    ///
    /// Nke a bụ ndị na-abụghị panicking variant nke [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SAFETY: `BorrowRef` na-ekwe nkwa nnweta pụrụ iche.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Weghachite pointer raw nye ihe data na-akpata na sel a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Laghachi a mutable akwụkwọ na-akpata data.
    ///
    /// Oku a na-agbaziri `RefCell` n'ụzọ dị egwu (na mkpokọta-oge) ya mere ọ dịghị mkpa maka nlele ike.
    ///
    /// Otú ọ dị, kpachara anya: usoro a na-atụ anya `self` ka ọ bụrụ ihe na-agbanwe agbanwe, nke n'ozuzu ya abụghị mgbe ị na-eji `RefCell`.
    ///
    /// Lelee usoro [`borrow_mut`] kama ọ bụrụ na `self` anaghị agbanwe agbanwe.
    ///
    /// Ọzọkwa, biko mara na usoro a bụ nanị maka ọnọdụ pụrụ iche na-abụkarị bụghị ihe ị chọrọ.
    /// Ọ bụrụ na enwere obi abụọ, jiri [`borrow_mut`] kama.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Wepu nsonaazụ nke ndị nche gbara agba na steeti mgbazinye ego nke `RefCell`.
    ///
    /// Nke a oku yiri [`get_mut`] ma ihe pụrụ iche.
    /// Ọ na-ebinye `RefCell` n'ụzọ ziri ezi iji hụ na enweghị mgbazinye dị wee megharịa steeti na-esochi ụgwọ.
    /// Nke a dị mkpa ma ọ bụrụ na agbazinyela ụfọdụ ego mgbazinye `Ref` ma ọ bụ `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Onu ogugu na-ebinye ego nke ọbọp, weghachite njehie ma ọ bụrụ na etinyere uru ahụ ugbu a.
    ///
    /// # Safety
    ///
    /// N`adịghị ka `RefCell::borrow`, usoro a enweghị nchekwa n`ihi na ọ naghị alọghachite `Ref`, si otú a hapụ ịhapụ mbinye ego mgbazinye emetụbeghị.
    /// N'iji obi mgbazinye ego `RefCell` mgbe ntụzigharị nke usoro a dị ndụ bụ omume na-akọwaghị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // NCHEKWA: Anyị na-elele na ọ dịghị onye na-arụsi ọrụ na-ede ugbu a, ma ọ bụ
            // nke bere na ibu ọrụ iji hụ na ọ dịghị onye na-ede ruo mgbe laghachi akwụkwọ bụ agaghịkwa eji.
            // Ọzọkwa, `self.value.get()` na-ezo aka na uru ekesịpde `self` na si otú a na-ekwe nkwa na-nti maka ndụ nke `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ewe ọbọp uru, na-ahapụ `Default::default()` n'ọnọdu-ya.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a gbaziri ugbu a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru a ugbu a mutably biiri.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Mepụta `RefCell<T>`, yana uru `Default` maka T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru na ma `RefCell` a ugbu a biiri.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Mentba ụba mbinye ego nwere ike ime ka ọnụọgụgụ na-abụghị ọgụgụ (<=0) n'ọnọdụ ndị a:
            // 1. Ọ bụ <0, ya bụ na e nwere akwụkwọ ibinye ego, yabụ na anyị enweghị ike ikwe ka a gụọ gbaziri n'ihi akwụkwọ ntụzịaka Rust
            // 2.
            // Ọ bụ isize::MAX (na max ego nke na-agụ na-ewere) na ọ jubigakwara ókè n'ime isize::MIN (na max ego nke na-ede na-ewere) otú anyị nwere ike ekwe ka ihe ndị ọzọ na-agụ Borrow n'ihi isize ike na-anọchi anya ọtụtụ agụ agbaziri (a nwere ike na-eme ma ọ bụrụ ị mem::forget karịa a obere mgbe nile ego nke 'Ref`s, nke bụ ezi omume)
            //
            //
            //
            //
            None
        } else {
            // Incrementing Borrow nwere ike ịkpata a na-agụ uru (> 0) na okwu ikpe ndị a:
            // 1. Ọ bụ=0, ya bụ na ebinweghị ya, na anyị na-ewere mbido agụ mbụ
            // 2. Ọ bụ> 0 na <isize::MAX, ntụgharị
            // e nwere ndị na-agụ na-ewere, na isize bụ nnukwu iji na-anọchi anya na-enwe otu ihe na-agụ Borrow
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Ebe ọ bụ na nke a Ref dị, anyị maara na mbinye ego ọkọlọtọ bụ a na-agụ gbaziri.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Gbochie ebe mgbazinye ego ibubighara n`ime ide ihe.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Na-ekpuchi akara mgbazinye ego maka uru na igbe `RefCell`.
/// Adị mpempe akwụkwọ maka uru gbazitere immutably si `RefCell<T>`.
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Mbipụta a `Ref`.
    ///
    /// `RefCell` abanyelarịrị kpamkpam, yabụ na nke a enweghị ike ịda.
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `Ref::clone(...)`.
    /// Ntinye `Clone` ma ọ bụ usoro ga-egbochi ojiji nke `r.borrow().clone()` iji mejupụta ọdịnaya nke `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Na-eme ka a ọhụrụ `Ref` maka a akụrụngwa nke biiri data.
    ///
    /// `RefCell` abanyelarịrị kpamkpam, yabụ na nke a enweghị ike ịda.
    ///
    /// Nke a bụ ihe metụtara ọrụ na kwesịrị na-eji dị ka `Ref::map(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Na-eme ka a ọhụrụ `Ref` maka nhọrọ akụrụngwa nke biiri data.
    /// A laghachiri onye nche mbụ dị ka `Err(..)` ma ọ bụrụ na mmechi ahụ laghachiri `None`.
    ///
    /// `RefCell` abanyelarịrị kpamkpam, yabụ na nke a enweghị ike ịda.
    ///
    /// Nke a bụ ihe metụtara ọrụ na kwesịrị na-eji dị ka `Ref::filter_map(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Kewaa a `Ref` n'ime otutu 'Ref`s maka uzo di iche iche nke biiri data.
    ///
    /// `RefCell` abanyelarịrị kpamkpam, yabụ na nke a enweghị ike ịda.
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `Ref::map_split(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Tọghatara n'ime a akwụkwọ kwuru na-apụtaghị ìhè na data.
    ///
    /// The akpata `RefCell` nwere ike mgbe a ga-mutably biiri si ọzọ na ga na-apụta na-ama immutably biiri.
    ///
    /// Ọ bụghị a ezi echiche ihihi karịa a mgbe nile ọnụ ọgụgụ nke e zoro.
    /// The `RefCell` nwere ike immutably biiri ọzọ ma ọ bụrụ na naanị a nta ọtụtụ ntapu mere na ngụkọta.
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `Ref::leak(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Site na ichezọ Ref a, anyị ga-ahụ na ihe mgbazinye ego na RefCell enweghị ike ịlaghachi UNUSED n`ime oge `'b` niile.
        // Restọgharị usoro nyocha usoro nyocha ga-achọ ntụgharị aka pụrụ iche na RefCell biiri.
        // Ọ dịghị ihe ọzọ mutable zoro nwere ike kere si mbụ cell.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Na-eme `RefMut` ohuru maka akụrụngwa nke data binyere, eg, iche iche enum.
    ///
    /// The `RefCell` na-ama mutably biiri, otú a na-apụghị ịda ada.
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `RefMut::map(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): idozi ego mgbazinye
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Na-eme ka a ọhụrụ `RefMut` maka nhọrọ akụrụngwa nke biiri data.
    /// A laghachiri onye nche mbụ dị ka `Err(..)` ma ọ bụrụ na mmechi ahụ laghachiri `None`.
    ///
    /// The `RefCell` na-ama mutably biiri, otú a na-apụghị ịda ada.
    ///
    /// Nke a bụ ihe metụtara ọrụ na kwesịrị na-eji dị ka `RefMut::filter_map(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): idozi ego mgbazinye
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // NCHEKWA: ọrụ esetịpụ jidesie nanị akwụkwọ maka oge
        // nke ya oku site na `orig`, na pointer na-na-de-referenced n'ime nke ọrụ oku mgbe ikwe ka nanị akwụkwọ iji gbapụ.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: same as above.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Na-ekewa a `RefMut` n'ime otutu 'RefMut`s maka ihe dị iche iche nke data ahụ agbaziri.
    ///
    /// A na-agbazinye `RefCell` na-akpata ya ma gbazite ya ruo mgbe ha laghachiri 'RefMut`s.
    ///
    /// The `RefCell` na-ama mutably biiri, otú a na-apụghị ịda ada.
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `RefMut::map_split(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Tọghata n'ime a mutable akwụkwọ na-akpata data.
    ///
    /// A na-enweghị ike ịgbazite `RefCell` na-akpata ya, ọ ga-apụtarịrịrịrị na agbaziri agbaziri agbaziri, na-eme ka nlọghachi laghachi naanị n'ime.
    ///
    ///
    /// Nke a bụ ọrụ metụtara metụtara nke kwesịrị iji dị ka `RefMut::leak(...)`.
    /// Usoro ga-egbochi usoro nke otu aha na ọdịnaya nke `RefCell` eji site `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Site na ichefu BorrowRefMut a anyi n`achoputa na mbinye ego mgbazinye na RefCell enweghị ike ịlaghachi UNUSED n`ime oge ndụ `'b`.
        // Restọgharị usoro nyocha usoro nyocha ga-achọ ntụgharị aka pụrụ iche na RefCell biiri.
        // Ọ dịghị ihe ọzọ e dere n'Akwụkwọ Nsọ nwere ike kere si mbụ cell n'ime na ndụ, na-eme ugbu a Borrow naanị akwụkwọ maka ndị fọdụrụ ndụ.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: N'adịghị ka BorrowRefMut::clone, a na-akpọ ọhụụ ka o mepụta nke mbụ
        // ntụgharị ederede, yabụ na ugbu a agaghị enwe ntụnye aka.
        // N'ihi ya, mgbe mmepụta oyiri increments na mutable refcount, ebe a anyị na-n'ụzọ doro anya na naanị ekwe na-aga site ejibeghi na ejibeghi, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones a `BorrowRefMut`.
    //
    // Nke a dị ire ma ọ bụrụ na ejiri `BorrowRefMut` nke ọ bụla soro akara ntụgharị na-agbanwe agbanwe, nke enweghị ihe mbido.
    //
    // Nke a anọghị na mmepụta oyiri nke na koodu ahụ anaghị akpọ nke a kpam kpam.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Gbochie Borrow counter si underflowing.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Mpempe akwụkwọ mkpuchi maka uru gbaziri site na `RefCell<T>`.
///
/// Hụ [module-level documentation](self) maka ihe ndị ọzọ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Isi nke oge gboo maka ime mgbanwe na Rust.
///
/// Ọ bụrụ na ị nwere a akwụkwọ `&T`, mgbe ahụ, ejikari na Rust na compiler anamde optimizations dabeere na ihe ọmụma na `&T` isi ka immutable data.Na-agbanwe data ahụ, dịka ọmụmaatụ site na utu aha ma ọ bụ site na ịtụgharị `&T` n'ime `&mut T`, a na-ahụta omume a na-akọwaghị.
/// `UnsafeCell<T>` opts-nke immutability nkwa maka `&T`: a na-akọrọ akwụkwọ `&UnsafeCell<T>` pụrụ izo aka data a na-mutated.Nke a na-akpọ "interior mutability".
///
/// Typesdị ndị ọzọ niile na-ekwe ka mmụba n'ime, dịka `Cell<T>` na `RefCell<T>`, na-eji `UnsafeCell` emechi data ha.
///
/// Rịba ama na ọ bụ naanị `UnsafeCell` na-emetụta mmesi ike na-enweghị atụ maka ederede ederede.Ihe puru iche nke ekwesiri ighota maka ihe edeturu ngbanwe adigh emetuta ya.E *dịghị* iwu iji nwetere aliasing `&mut`, ọbụna na `UnsafeCell<T>`.
///
/// `UnsafeCell` API n'onwe ya dị mfe nke ọma: [`.get()`] na-enye gị pointer raw `*mut T` na ọdịnaya ya.Ọ bụ ruo _you_ ka abstraction mmebe iji na raw pointer n'ụzọ ziri ezi.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Iwu ziri ezi nke Rust na-agbanwe agbanwe, mana isi okwu anaghị ese okwu:
///
/// - Ọ bụrụ n `imepụta nchekwa echekwara na ndụ `'a` (ma ọ bụ `&T` ma ọ bụ `&mut T` akwụkwọ ndụ) nke enwere ike ịnweta ya site na koodu nchekwa (dịka ọmụmaatụ, n`ihi na ị weghachitere ya), ị gaghị abanye data n`ụzọ ọ bụla na-emegide ntụaka ahụ maka ndị fọdụrụnụ nke `'a`.
/// Dịka ọmụmaatụ, nke a pụtara na ọ bụrụ na ị were `*mut T` site na `UnsafeCell<T>` wee tụba ya na `&T`, mgbe ahụ data dị na `T` ga-anọgide na-agbanwe agbanwe (gbanwee ihe ọ bụla `UnsafeCell` data dị n'ime `T`, n'ezie) ruo mgbe oge nrụtụ aka ahụ ga-agwụ.
/// N'otu aka ahụ, ọ bụrụ na ị mepụtara a `&mut T` akwụkwọ na a tọhapụrụ mma code, mgbe ahụ, ị ga-ịnweta data n'ime `UnsafeCell` ruo na akwụkwọ expires.
///
/// - Na oge niile, ị ga-ezere agbụrụ data.Ọ bụrụ na multiple eri nwere ohere otu `UnsafeCell`, mgbe ahụ, ọ bụla na-ede ga nwere a kwesịrị ekwesị na-eme tupu mmekọrita niile ọzọ accesses (ma ọ bụ ojiji atomics).
///
/// Iji nyere na kwesịrị ekwesị imewe, ndị na-esonụ ndapụta na-n'ụzọ doro anya kwuru, iwu maka otu-threaded koodu:
///
/// 1. Enwere ike ịtọhapụ ederede `&T` na koodu nchekwa ma ebe ahụ ọ nwere ike ibikọ ọnụ na amaokwu `&T` ndị ọzọ, mana ọ bụghị na `&mut T`
///
/// 2. A `&mut T` akwụkwọ nwere ike tọhapụrụ mma koodu nyere abughi ọzọ `&mut T` ma `&T` co-dịrị na ya.A `&mut T` ga-enwe mgbe nile pụrụ iche.
///
/// Rịba ama na ebe ị na-agbanwe ọdịnaya nke `&UnsafeCell<T>` (ọbụlagodi na ihe `&UnsafeCell<T>` ndị ọzọ na-ezo aka na cell) ọ dị mma (ọ bụrụhaala na ị na-eme ka ndị ọrụ a dị elu karịa ụzọ ọzọ), ọ ka bụ omume a na-akọwaghị inwe ọtụtụ aha nnabata `&mut UnsafeCell<T>`.
/// Nke ahụ bụ, `UnsafeCell` bụ a fụchie iji nwere a pụrụ iche mmekọrịta _shared_ accesses (_i.e._, site na `&UnsafeCell<_>` akwụkwọ);ọ dịghị anwansi bụla mgbe emeso _exclusive_ accesses (_e.g._, site na `&mut UnsafeCell<_>`): ma cell ma ọ bụ ọbọp uru nwere ike aliased maka oge nke na `&mut` agbazite ihe.
///
/// Ihe ngosi [`.get_mut()`] gosipụtara nke a, nke bụ _safe_ getter nke na-eweta `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Nke a bụ ihe atụ na-egosipụta etu esi agbanwe ụda ọdịnaya nke `UnsafeCell<_>` n'agbanyeghị agbanyeghị ọtụtụ ntụnye aha na-akpọ cell:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Nweta otutu/nkesa aka banyere otu `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: N'ime akwukwo a, odighi aka ozo banyere ihe ndi 'x',
///     // otú anyị bụ n'ụzọ dị irè pụrụ iche.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- gbaziri-+
///     *p1_exclusive += 27; // |
/// } // <---------- enweghị ike ịgafe ebe a -------------------+
///
/// unsafe {
///     // SAFETY: N'ime oke a, ọ dịghị onye na-atụ anya inwe ohere ịnweta ọdịnaya '' x ',
///     // yabụ na anyị nwere ike ịnweta ọtụtụ ohere ịkekọrịta n'otu oge.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// The atụ na-esonụ na-ewepụtakarị eziokwu na nanị ohere ihe `UnsafeCell<T>` pụtara nanị ohere ya `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // na-enweta nanị,
///                         // `UnsafeCell` bụ a uzo dịghị-op fụchie, otú ọ dịghị mkpa maka `unsafe` ebe a.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Nweta a ide-oge-enyocha ihe pụrụ iche banyere `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Site na ntinye aka, anyi nwere ike gbanwee ihe di n'ime n'efu.
/// *p_unique.get_mut() = 0;
/// // Ma obu, dika:
/// x = UnsafeCell::new(0);
///
/// // Mgbe anyị nwere uru, anyị nwere ike wepụ ọdịnaya maka free.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Na-ewu ihe atụ ọhụrụ nke `UnsafeCell` nke ga-emechi uru a kapịrị ọnụ.
    ///
    ///
    /// Niile ịnweta uru dị n'ime site na ụzọ bụ `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Na-ekpughe uru ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Alụta mutable pointer na ọbọp uru.
    ///
    /// Nke a pụrụ ịbụ na nkedo ka a pointer nke ụdị ọ bụla.
    /// Gbaa mbọ hụ na ohere ahụ dị iche (enweghị ntụaka arụ ọrụ, ntụgharị ma ọ bụ na ọ bụghị) mgbe a na-atụgharị ya na `&mut T`, ma hụ na enweghị mmụba ma ọ bụ aha ndị na-agbanwe agbanwe na-aga mgbe a na-atụba `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Anyị nwere ike tufuo pointer na `UnsafeCell<T>` ka `T` n'ihi #[repr(transparent)].
        // Nke a na-eji ọnọdụ pụrụ iche nke libstd mee ihe, enweghị nkwa maka koodu onye ọrụ na nke a ga-arụ ọrụ na nsụgharị future nke nchịkọta ahụ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Laghachi a mutable akwụkwọ na-akpata data.
    ///
    /// Oku a na-agbaziri `UnsafeCell` n'ụzọ dị egwu (na mkpokọta oge) nke na-ekwe nkwa na anyị nwere naanị ntụnye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Alụta mutable pointer na ọbọp uru.
    /// Ihe dị iche na [`get`] bụ na ọrụ a na-anabata a raw pointer, nke bụ bara uru iji zere ihe e kere eke nke nwa oge zoro.
    ///
    /// Enwere ike itunye ya na pointer nke ụdị ọ bụla.
    /// Gbaa mbọ hụ na nnweta ahụ pụrụ iche (enweghị ntụaka arụ ọrụ, ntụgharị ma ọ bụ na ọ bụghị) mgbe a na-atụgharị ya na `&mut T`, ma hụ na enweghị mmụba ma ọ bụ aha ndị na-agbanwe agbanwe na-aga mgbe a na-atụba `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Jiri nwayọọ nwayọọ na initialization nke ihe `UnsafeCell` achọ `raw_get`, dị ka na-akpọ `get` ga-achọ na-eke a banyere uninitialized data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Anyị nwere ike tufuo pointer na `UnsafeCell<T>` ka `T` n'ihi #[repr(transparent)].
        // Nke a na-eji ọnọdụ pụrụ iche nke libstd mee ihe, enweghị nkwa maka koodu onye ọrụ na nke a ga-arụ ọrụ na nsụgharị future nke nchịkọta ahụ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Mepụta `UnsafeCell`, yana uru `Default` maka T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}