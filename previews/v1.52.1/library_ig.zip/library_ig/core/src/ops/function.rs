/// Versiondị nke onye na-akpọ oku na-ewe onye na-adịghị agbanwe agbanwe.
///
/// Enwere ike ịkpọ oge nke `Fn` ugboro ugboro na-enweghị ọnọdụ ntụgharị.
///
/// *Agaghị eme ka trait (`Fn`) a nwee mgbagwoju anya na [function pointers] (`fn`).*
///
/// `Fn` na-emejuputa atumatu na-akpaghị aka site na closures nke naanị immutable zoro aka weghaara variables ma ọ bụ na-adịghị kpọọ ihe ọ bụla, nakwa dị ka (safe) [function pointers] (na ụfọdụ caveats, hụ ha akwụkwọ maka nkọwa ndị ọzọ).
///
/// Na mgbakwunye, maka ụdị `F` nke na-etinye `Fn`, `&F` na-etinyekwa `Fn`, kwa.
///
/// Ebe ọ bụ na [`FnMut`] na [`FnOnce`] bụ supertraits nke `Fn`, ihe atụ ọ bụla nke `Fn` nwere ike iji dị ka oke ebe [`FnMut`] ma ọ bụ [`FnOnce`] na-atụ anya.
///
/// Iji `Fn` ka a ibikwa mgbe ị chọrọ ịnabata a oke nke ọrụ-dị ka ụdị na mkpa na-akpọ ya ugboro ugboro na-enweghị mutating ala (eg, mgbe akpọ ya concurrently).
/// Ọ bụrụ na ị na-eme adịghị mkpa dị otú ahụ siri ike chọrọ, iji [`FnMut`] ma ọ bụ [`FnOnce`] dị ka ókè.
///
/// Hụ [chapter on closures in *The Rust Programming Language*][book] maka ụfọdụ ozi ndị ọzọ gbasara isiokwu a.
///
/// Ihe ndetu bụ syntax pụrụ iche maka `Fn` traits (dịka ọmụmaatụ
/// `Fn(usize, bool) -> were``.Ndị nwere mmasị na nkọwapụta teknụzụ nke a nwere ike zoo aka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Na-akpọ mmechi
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Iji oke `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // nke mere na regex pụrụ ịdabere na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Na-arụ ọrụ oku.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versiondị nke onye na-akpọ oku na-ewe nnata nwere ike ịgbanwe.
///
/// Enwere ike ịkpọ oge nke `FnMut` ugboro ugboro ma nwee ike ịgbanwe ọnọdụ.
///
/// `FnMut` emejuputara na akpaghị aka site na mmechi nke na-ewere ntụgharị ntụgharị uche na ndị gbanwere agbanwe, yana ụdị niile na-emejuputa [`Fn`], dịka, (safe) [function pointers] (ebe `FnMut` bụ isi nke [`Fn`]).
/// Ọzọkwa, ọ bụla ụdị `F` na achụ nta `FnMut`, `&mut F` achụ nta `FnMut`, kwa.
///
/// Ebe [`FnOnce`] bụ supertrait nke `FnMut`, enwere ike iji `FnMut` mee ihe atụ ebe [`FnOnce`] tụrụ anya ya, ebe [`Fn`] bụ subtrait nke `FnMut`, enwere ike iji [`Fn`] mee ihe ebe `FnMut` tụrụ anya.
///
/// Jiri `FnMut` dị ka ụdọ mgbe ịchọrọ ịnabata oke nke ụdị ọrụ yana ịchọrọ ịkpọ ya ugboro ugboro, ma kwe ka ọ gbanwee ọnọdụ.
/// Ọ bụrụ na ị na-achọghị na-oke na mutate ala, iji [`Fn`] ka a ibikwa;ma ọ bụrụ na ịchọghị ịkpọ ya ugboro ugboro, jiri [`FnOnce`].
///
/// Hụ [chapter on closures in *The Rust Programming Language*][book] maka ụfọdụ ozi ndị ọzọ gbasara isiokwu a.
///
/// Ihe ndetu bụ syntax pụrụ iche maka `Fn` traits (dịka ọmụmaatụ
/// `Fn(usize, bool) -> were``.Ndị nwere mmasị na nkọwapụta teknụzụ nke a nwere ike zoo aka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Na-akpọ mmechi mmechi
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Iji oke `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // nke mere na regex pụrụ ịdabere na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Na-arụ ọrụ oku.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versiondị nke onye na-akpọ oku na-ewe onye na-enweta uru bara uru.
///
/// Ihe nke `FnOnce` nwere ike na-akpọ, ma o nwere ike ịbụ callable otutu ugboro.N'ihi nke a, ma ọ bụrụ na naanị ihe mara banyere a ụdị bụ na ọ na implements `FnOnce`, ọ nwere ike na-akpọ ozugbo.
///
/// `FnOnce` na-emejuputa atumatu na-akpaghị aka site na closures nke nwere ike na-aṅụ weghaara variables, nakwa dị ka ihe nile ụdị na mejuputa [`FnMut`], eg, (safe) [function pointers] (ebe `FnOnce` bụ a supertrait nke [`FnMut`]).
///
///
/// Ebe ọ bụ na [`Fn`] na [`FnMut`] bụ subtraits nke `FnOnce`, enwere ike iji ihe atụ ọ bụla nke [`Fn`] ma ọ bụ [`FnMut`] ebe a tụrụ anya `FnOnce`.
///
/// Jiri `FnOnce` dịka ụdọ mgbe ịchọrọ ịnabata oke nke ụdị ọrụ yana naanị ị ga-akpọ ya otu oge.
/// Ọ bụrụ na ị chọrọ na-akpọ ndị oke ugboro ugboro, na-eji [`FnMut`] ka a ibikwa;ọ bụrụ na ịchọrọ ka ọ ghara ịgbanwe ọnọdụ, jiri [`Fn`].
///
/// Hụ [chapter on closures in *The Rust Programming Language*][book] maka ụfọdụ ozi ndị ọzọ gbasara isiokwu a.
///
/// Ihe ndetu bụ syntax pụrụ iche maka `Fn` traits (dịka ọmụmaatụ
/// `Fn(usize, bool) -> were``.Ndị nwere mmasị na nkọwapụta teknụzụ nke a nwere ike zoo aka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Iji a `FnOnce` oke
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` na-erepịa mgbanwe dị na ya, yabụ enweghị ike ịgba ọsọ karịa otu oge.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Attgbalị ịkpọku `func()` ọzọ ga-atụfu njehie `use of moved value` maka `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` enweghị ike ịkpọku ugbu a
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // nke mere na regex pụrụ ịdabere na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Thedị laghachiri mgbe ejiri onye ọrụ oku.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Na-arụ ọrụ oku.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}