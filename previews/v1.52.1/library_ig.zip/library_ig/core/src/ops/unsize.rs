use crate::marker::Unsize;

/// Trait nke na-egosi na nke a bụ pointer ma ọ bụ ihe mkpuchi maka otu, ebe enwere ike ịrụ ọrụ na pointee.
///
/// Hụ [DST coercion RFC][dst-coerce] na [the nomicon entry on coercion][nomicon-coerce] maka nkọwa ndị ọzọ.
///
/// N'ihi builtin pointer ụdị, pointers ka `T` ga amanye ka pointers ka `U` ma ọ bụrụ na `T: Unsize<U>` site n'ịtụgharị si a mkpa pointer ka a abụba pointer.
///
/// Maka ụdị dị iche iche, ịmanye ebe a na-arụ ọrụ site na ịmanye `Foo<T>` ka `Foo<U>` nyere ihe gbasara `CoerceUnsized<Foo<U>> for Foo<T>` dị.
/// Enwere ike dee ederede dị otú a ma ọ bụrụ na `Foo<T>` nwere naanị otu mpaghara na-abụghị phantomdata metụtara `T`.
/// Ọ bụrụ na ụdị nke ubi ahụ bụ `Bar<T>`, mmejuputa `CoerceUnsized<Bar<U>> for Bar<T>` ga-adị.
/// Nchịkọta mmanye ga-arụ ọrụ site na ịmanye oghere `Bar<T>` n'ime `Bar<U>` ma jupụta n'akụkụ ndị ọzọ site na `Foo<T>` iji mepụta `Foo<U>`.
/// Nke a ga-akụda ihe n'ụzọ dị irè ma dozie ya.
///
/// N'ozuzu, maka smart pointers ị ga-mejuputa `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, na nhọrọ `?Sized` agbụ na `T` onwe ya.
/// Maka ụdị mpempe akwụkwọ nke na-etinye `T` ozugbo dị ka `Cell<T>` na `RefCell<T>`, ị nwere ike itinye `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` n'ọrụ ozugbo.
///
/// Nke a ga-ekwe ka mmanye ụdị dị ka `Cell<Box<T>>` ọrụ.
///
/// [`Unsize`][unsize] A na-eji ya akara ụdị nke nwere ike ịmanye DST ma ọ bụrụ n'azụ ntụpọ.Emejuputara ya na akpaghị aka site na onye nchikota oru.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Nke a na-eji maka ihe nchekwa, na-elele na a usoro si erite ụdị nwere ike zipụrụ on.
///
/// Ihe omuma nke trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}