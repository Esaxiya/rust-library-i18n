/// A trait maka ịhazi omume nke onye ọrụ `?`.
///
/// Typedị nke mmejuputa `Try` bụ nke nwere ụzọ canonical iji lee ya anya na usoro success/failure dichotomy.
/// trait a na-enye ohere wepu ihe ịga nke ọma ma ọ bụ ọdịda ọdịda ahụ site na ihe atụ dị ma mepụta ọhụụ ọhụrụ site na uru ma ọ bụ ọdịda.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ofdị nke uru a mgbe a lere anya dị ka ihe ịga nke ọma.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ofdị nke uru a mgbe a lere ya anya dị ka okpu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Gbasara onye ọrụ "?".A nloghachi nke `Ok(t)` pụtara na egbu ga-anọgide na-ejikarị, na n'ihi `?` bụ uru `t`.
    /// Nloghachi nke `Err(e)` pụtara na ogbugbu kwesịrị branch na-abanye n'ime `catch`, ma ọ bụ si na ọrụ ahụ laghachi.
    ///
    /// Ọ bụrụ na eweghachitere nsonaazụ `Err(e)`, uru `e` ga-abụ "wrapped" n'ụdị nloghachi nke oghere na-agbanye (nke ga-etinye `Try` n'onwe ya).
    ///
    /// Kpọmkwem, a laghachiri uru `X::from_error(From::from(e))`, ebe `X` bụ ụdị nloghachi nke ọrụ mkpuchi.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kechie uru njehie iji wuo nsonaazụ mejupụtara.
    /// Dịka ọmụmaatụ, `Result::Err(x)` na `Result::from_error(x)` bụ otu.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kechie ihe OK uru iji rụọ ọtụtụ ihe mejupụtara, N'ihi.
    /// Dịka ọmụmaatụ, `Result::Ok(x)` na `Result::from_ok(x)` bụ otu.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}