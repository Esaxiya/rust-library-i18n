use crate::marker::Unpin;
use crate::pin::Pin;

/// Ihe si na generator na-amaliteghachi.
///
/// Nke a enum na-ahụ si `Generator::resume` usoro na-egosi na o kwere omume laghachi ụkpụrụ nke a generator.
/// Ugbu a nke a kwekọrọ na (`Yielded`) nkwụsịtụ ma ọ bụ nkwụsị (`Complete`) nkwụsị.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Na generator bu nwere uru.
    ///
    /// Na steeti a na-egosi na a generator a kwụsịtụrụ, na a na-kwekọrọ na a `yield` nkwupụta.
    /// The uru na-nyere na nke a variant kwekọrọ na okwu ebe `yield` na-enye ohere generators inye a uru ọ bụla ha na-ekwe.
    ///
    ///
    Yielded(Y),

    /// Igwe jenerato mezuru ya na nweghachi azu.
    ///
    /// Ọnọdụ a na-egosi na onye jenerato ejirila ọnụ ahịa enyere ya rụọ ọrụ.
    /// Ozugbo onye na-enye ọkụ weghachite `Complete`, a na-ahụta ya dị ka ihe mmemme programmer iji kpọọ `resume` ọzọ.
    ///
    Complete(R),
}

/// The trait emejuputa atumatu oru site builtin generator ụdị.
///
/// Ndị na-emepụta ọkụ, nke a na-akpọkarị coroutines, bụ ugbu a ihe ngosipụta asụsụ asụsụ na Rust.
/// Kwukwara na [RFC 2033] generators na-ugbu a bu n'obi bụ isi na-enye a ụlọ ngọngọ n'ihi async/await syntax ma ga-abụ na ịgbatị na-na-na-enye ihe ergonomic definition maka iterators na ndị ọzọ na primitives.
///
///
/// Ntughari okwu na ihe omuma banyere ndi na-emeputa ihe enweghi ike igha acho RFC ozo maka ime ka odi.Otú ọ dị, n'oge a, syntax ahụ bụ mmechi-dị ka:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// More akwụkwọ nke generators nwere ike dị na-ejighị n'aka akwụkwọ.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Ofdị uru onye na-enye ọkụ na-amịpụta ihe a.
    ///
    /// Nke a metụtara ụdị kwekọrọ na `yield` okwu na ụkpụrụ nke na-ekwe ka-laghachiri oge ọ bụla a generator zaa.
    ///
    /// Dịka ọmụmaatụ onye iterator-as-a-generator ga-enwe ụdị a dịka `T`, a na-atụgharị ụdị ahụ.
    ///
    type Yield;

    /// The ụdị uru a generator laghachi.
    ///
    /// Nke a kwekọrọ n'ụdị eweghachitere site na igwe jenerato ma jiri nkwupụta `return` ma ọ bụ n'ụzọ doro anya dị ka okwu ikpeazụ nke onye na-eweta ihe nkịtị.
    /// Dịka ọmụmaatụ futures ga-eji nke a dị ka `Result<T, E>` ka ọ na-anọchite anya future emechara.
    ///
    ///
    type Return;

    /// Gbanwee mmezu nke igwe na-enye ọkụ.
    ///
    /// Ọrụ a ga-amalite ịmalite ogbugbu nke igwe ma ọ bụ bido mbido ma ọ bụrụ na ọ mabeghị ya.
    /// Oku a ga-alaghachi azụ na njedebe ikpeazụ nke jenerato, na-amaliteghachi na-egbu site na `yield` kachasị ọhụrụ.
    /// Igwe na-enye ọkụ ga-aga n'ihu na-arụ ọrụ ruo mgbe ọ rụpụtara ma ọ bụ laghachi, n'oge ahụ ọrụ a ga-alaghachi.
    ///
    /// # Laghachi uru
    ///
    /// The `GeneratorState` enum si ọrụ a na-egosi ihe ala na generator bu na mgbe ọ laghachiri.
    /// Ọ bụrụ na ndị `Yielded` variant na-laghachi mgbe ahụ generator ruru a nkwusioru uche na a bara uru e amịghịkwa si.
    /// Generators na steeti a dị maka resumption na a gasịrị mgbe.
    ///
    /// Ọ bụrụ na `Complete` na-laghachi mgbe ahụ generator ka kpamkpam okokụre na uru nyere.Ọ bụ ihe na-abaghị uru maka na generator ga-maliteghachi ọzọ.
    ///
    /// # Panics
    ///
    /// Ọrụ a nwere ike panic ma ọ bụrụ na akpọrọ ya mgbe ejirila ụdị `Complete` laghachi na mbụ.
    /// Ọ bụ ezie na ederede nkịtị na asụsụ ga-ekwe nkwa panic na ịmaliteghachi mgbe `Complete` gasịrị, nke a anaghị ekwe nkwa maka mmejuputa niile nke `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}