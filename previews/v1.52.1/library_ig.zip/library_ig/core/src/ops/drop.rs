/// Koodu omenala n'ime nbibi.
///
/// Mgbe uru adịghịzi mkpa, Rust ga-agba "destructor" na uru ahụ.
/// Kacha nkịtị n'ụzọ na a bara uru na-adịkwaghị mkpa bụ mgbe ọ na-aga nke akporo.Destructors nwere ike ka na-agba ọsọ na ọnọdụ ndị ọzọ, ma anyị na-aga na-elekwasị anya akporo maka ihe atụ ebe a.
/// Iji mụta banyere ụfọdụ n'ime okwu ndị ahụ, biko lee ngalaba [the reference] maka ndị na-ebibi ihe.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Onye nbibi a nwere ihe abuo:
/// - A oku na-aga `Drop::drop` maka na uru, ma ọ bụrụ na a pụrụ iche `Drop` trait na-emejuputa atumatu maka ya ụdị.
/// - Ihe "drop glue" a na-akpaghị aka nke na-akpọ oku mbibi nke mpaghara niile nke uru a.
///
/// Dika Rust na akpaghi oku na-akpo mbibi nke ubi nile di n'ime, odighi imejuputa `Drop` otutu oge.
/// Mana enwere ụfọdụ ebe ọ bara uru, dịka ọmụmaatụ maka ụdị nke na-ejikwa akụ.
/// Na akụ nwere ike na ebe nchekwa, o nwere ike ịbụ a file descriptor, ọ pụrụ ịbụ a netwọk anya.
/// Ozugbo uru nke ụdị ahụ agaghịzi eji, ọ kwesịrị "clean up" akụ ya site na ịhapụ ebe nchekwa ma ọ bụ mechie faịlụ ma ọ bụ oghere.
/// Nke a bụ ọrụ nke a destructor, ya mere ọrụ nke `Drop::drop`.
///
/// ## Examples
///
/// Iji hụ destructors ke edinam, ka na-a lee anya na-esonụ omume:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust ga-akpa na-akpọ `Drop::drop` maka `_x` wee ma `_x.one` na `_x.two`, nke pụtara na-agba ọsọ a ga-ebipụta
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Ọbụna ma ọ bụrụ na anyị ewepụ mmejuputa nke `Drop` maka `HasTwoDrop`, a ka na-akpọ ndị na-ebibi ubi ya.
/// Nke a ga-eme ka
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## I nweghi ike ịkpọ onwe gị `Drop::drop`
///
/// N'ihi `Drop::drop` a na-eji ọcha a bara uru, o nwere ike ịdị ize ndụ iji nke a bara uru mgbe usoro a na-akpọ.
/// Dika `Drop::drop` anaghi enweta ihe ntinye ya, Rust gbochiri njiri eme ihe site n`ighara ikwe ka ikpoputa `Drop::drop` ozugbo.
///
/// Ndị ọzọ okwu, ma ọ bụrụ na ị na-agbalị ka n'ụzọ doro anya na-akpọ `Drop::drop` na n'elu ihe atụ, ị ga-esi a compiler njehie.
///
/// Y`oburu n`acho ikpo oku n`ebipu uru, enwere ike iji [`mem::drop`] mee ihe.
///
/// [`mem::drop`]: drop
///
/// ## Dobe iwu
///
/// Kedu nke abụọ `HasDrop` anyị dara mbụ, ọ bụ ezie?N'ihi structs, ọ bụ otu ihe ka ha na-kwuru, sị: mbụ `one`, mgbe ahụ, `two`.
/// Ọ bụrụ n'ịchọrọ ịnwale nke a n'onwe gị, ịnwere ike gbanwee `HasDrop` dị n'elu iji nwee ụfọdụ data, dị ka integer, werezie ya na `println!` n'ime `Drop`.
/// Omume a bu nkwa nke asusu.
///
/// N'adịghị ka structs, a na-atụgharị mgbanwe dị iche iche na mpaghara nke ọzọ:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Nke a ga-ebipụta
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Biko lee [the reference] maka iwu niile.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` na `Drop` bụ nanị
///
/// Cannot nweghị ike imejuputa [`Copy`] na `Drop` n'otu ụdị.Dị ndị bụ `Copy` na-emepụta ihe n'ụzọ zuru ezu site na onye nchịkọta ihe, na-eme ka o sie ike ịkọ mgbe, na ugboro ole a ga-egbu ya.
///
/// Dị ka ndị dị otú ahụ, ndị a na ụdị ike nwere destructors.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Na-ebibi onye nbibi maka ụdị a.
    ///
    /// A na-akpọ usoro a n'ụzọ doro anya mgbe uru bara ụba, na enweghị ike ịkpọ ya n'ụzọ doro anya (nke a bụ njehie nchịkọta [E0040]).
    /// Otú ọ dị, [`mem::drop`] ọrụ na prelude ike ga-eji na-akpọ ndị esemokwu si `Drop` mmejuputa.
    ///
    /// Mgbe usoro a na-akpọ, `self` erubeghị a deallocated.
    /// Nke ahụ ga-eme ma usoro ahụ gwụchara.
    /// Ọ bụrụ na nke a abụghị ikpe, `self` ga-abụ akwụkwọ ntanye.
    ///
    /// # Panics
    ///
    /// Nyere na [`panic!`] ga-akpọ `drop` ka ọ na-agbatị, [`panic!`] ọ bụla na ntinye `drop` nwere ike iwepụ.
    ///
    /// Rịba ama na ọbụlagodi na panics a, a na-ewere uru ahụ ka a ga-adaba;
    /// ị gaghị eme ka akpọọ `drop` ọzọ.
    /// Nke a na-ejikarị onye na-achịkọta ihe na-akpaghị aka, mana mgbe ị na-eji koodu enweghị nchekwa, oge ụfọdụ nwere ike ime na akpaghị aka, ọkachasị mgbe ị na-eji [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}