/// Ejiri maka arụmọrụ na-agbanwe agbanwe, dị ka `*v`.
///
/// Na mgbakwunye na iji ya maka arụmọrụ deferencing doro anya na onye ọrụ (unary) `*` na ọnọdụ ndị na-adịghị agbanwe agbanwe, a na-ejikwa `Deref` eme ihe n'ụzọ zuru oke site na nchịkọta ahụ n'ọtụtụ ọnọdụ.
/// A na-akpọ usoro a ['`Deref` coercion'][more].
/// Na ọnọdụ mgbanwe, a na-eji [`DerefMut`] eme ihe.
///
/// Imejuputa `Deref` maka ihe ngosi di nma na-eme ka inweta data di n`azu ha di nma, o bu ya mere ha ji etinye `Deref`.
/// N'aka nke ọzọ, e mere iwu gbasara `Deref` na [`DerefMut`] iji kwado ndị na-egosi ihe ọgụgụ isi.
/// Maka nke a,**``Deref` kwesịrị ka emejuputa ya maka smart pointers** iji zere ọgba aghara.
///
/// Maka ebumnuche ndị ọzọ,**trait a ekwesịghị ịda mba**.Ọdịda n'oge ntụgharị akwụkwọ nwere ike bụrụ ihe mgbagwoju anya mgbe akpọrọ `Deref` n'ụzọ zuru ezu.
///
/// # More na mmanye `Deref`
///
/// Ọ bụrụ na `T` mejuputa `Deref<Target = U>`, na `x` bụ uru nke ụdị `T`, mgbe ahụ:
///
/// * N'ebe a na-apụghị ịgbanwe agbanwe, `*x` (ebe `T` abụghị ntụpọ ma ọ bụ pointer raw raw) bụ `* Deref::deref(&x)`.
/// * A na-amanye ụkpụrụ nke ụdị `&T` n'ụkpụrụ nke ụdị `&U`
/// * `T` n'ụzọ doro anya na-etinye usoro (immutable) niile nke ụdị `U`.
///
/// Maka nkọwa ndị ọzọ, gaa na [the chapter in *The Rust Programming Language*][book] yana ngalaba ntinye aka na [the dereference operator][ref-deref-op], [method resolution] na [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ihe owuwu nwere otu ubi nke enwere ike inweta ya site na ide ihe.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ihe ụdị mgbe dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Derefere uru ọ bara.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Ejiri maka arụmọrụ dereferencing arụmọrụ, dị ka `*v = 1;`.
///
/// Na mgbakwunye na iji ya maka arụmọrụ deferencing doro anya na onye ọrụ (unary) `*` na ọnọdụ ndị nwere ike ịgbanwe, `DerefMut` na-ejikwa ya n'ụzọ zuru oke site na nchịkọta ahụ n'ọtụtụ ọnọdụ.
/// A na-akpọ usoro a ['`Deref` coercion'][more].
/// N'ebe a na-apụghị ịgbanwe agbanwe, a na-eji [`Deref`] eme ihe.
///
/// Mmejuputa `DerefMut` maka smart pointers eme ka mutating na data n'azu ha adaba, nke bụ ya mere ha mejuputa `DerefMut`.
/// N'aka nke ọzọ, e mere iwu gbasara [`Deref`] na `DerefMut` iji kwado ndị na-egosi ihe ọgụgụ isi.
/// Maka nke a,**``DerefMut` kwesiri ka emejuputa ya maka smart pointers** iji zere ọgba aghara.
///
/// Maka ebumnuche ndị ọzọ,**trait a ekwesịghị ịda mba**.Ọdịda n'oge dereferencing nwere ike nnọọ anya mgbe `DerefMut` na-akpọku obi kpamkpam.
///
/// # More na mmanye `Deref`
///
/// Ọ bụrụ na `T` implements `DerefMut<Target = U>`, na `x` bụ a uru nke ụdị `T`, mgbe ahụ:
///
/// * N'ebe a na-agbanwe agbanwe, `*x` (ebe `T` abụghị ntụpọ ma ọ bụ akara pointer) bụ `* DerefMut::deref_mut(&mut x)`.
/// * Kpụrụ nke ụdị `&mut T` na-amanye ụkpụrụ nke ụdị `&mut U`
/// * `T` obi kpamkpam implements niile (mutable) ụzọ nke ụdị `U`.
///
/// Maka nkọwa ndị ọzọ, gaa na [the chapter in *The Rust Programming Language*][book] yana ngalaba ntinye aka na [the dereference operator][ref-deref-op], [method resolution] na [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// A struct na a otu ubi nke bụ ịgbanwe site dereferencing na struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Di iche dere dere uru.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Na-egosi na a struct nwere ike ji mee ka a na usoro-erite, na-enweghị `arbitrary_self_types` mma.
///
/// Nke a na-etinye usoro stdlib pointer dị ka `Box<T>`, `Rc<T>`, `&T`, na `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}