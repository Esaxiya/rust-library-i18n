#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// The version of [Unicode](http://www.unicode.org/) na Unicode akụkụ nke `char` na `str` ụzọ na-dabere na.
///
/// A na-ewepụta ụdị ọhụrụ nke Unicode mgbe niile ma na-agbaso ụzọ niile n'ọbá akwụkwọ ọkọlọtọ dabere na Unicode na-emelite.
/// Ya mere omume nke ụfọdụ usoro `char` na `str` na uru nke oge a na-agbanwe oge.
/// Nke a abụghị * elere anya dị ka mgbanwe mgbanwe.
///
/// The version Nọmba atụmatụ a kọwara [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Maka ojiji na liballoc, anaghị ebupụ ya ọzọ na libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;