//! Mọdụl a na-eme `Any` trait, nke na-enyere mpịnye ume nke ụdị `'static` ọ bụla site na ntụgharị uche oge.
//!
//! `Any` enwere ike iji ya onwe ya nweta `TypeId`, ma nwekwaa ihe ndi ozo mgbe eji ya dika ihe trait.
//! Dị ka `&dyn Any` (ihe trait gbaziri), ọ nwere usoro `is` na `downcast_ref`, iji nwalee ma ọ bụrụ na uru dị na ya bụ nke e nyere ya, yana iji nweta nrụtụ aka maka uru dị n'ime ya dịka ụdị.
//! Ka `&mut dyn Any`, e nwekwara ndị `downcast_mut` usoro, n'ihi na a mutable akwụkwọ kwuru na n'ime uru.
//! `Box<dyn Any>` na-agbakwunye usoro `downcast`, nke na-anwa ịtụgharị na `Box<T>`.
//! Hụ akwụkwọ [`Box`] maka nkọwa zuru ezu.
//!
//! Rịba ama na `&dyn Any` ejedebeghị na-anwale ma a uru bụ nke a kpọmkwem ihe ụdị, na ike ga-eji nwalee ma a ụdị mejuputa a trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers na `dyn Any`
//!
//! Otu omume ị ga-ebu n'uche mgbe ị na-eji `Any` dị ka ihe trait, ọkachasị ụdị dị ka `Box<dyn Any>` ma ọ bụ `Arc<dyn Any>`, bụ na nanị ịkpọ `.type_id()` na uru ga-emepụta `TypeId` nke *akpa*, ọ bụghị ihe trait dị n'okpuru.
//!
//! Enwere ike izere nke a site na ịtụgharị pointer smart n'ime `&dyn Any` kama, nke ga-eweghachi ihe `TypeId` ahụ.
//! Ọmụmaatụ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // O yikarịrị ka ị ga-achọ nke a:
//! let actual_id = (&*boxed).type_id();
//! // ... karịa nke a:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tụlee a ọnọdụ ebe anyị chọrọ na-apụ a uru ebe a ọrụ.
//! Anyị maara na ọ bara uru anyị na-arụ ọrụ na achụ nta Debug, ma anyị na-amaghị ya ihe ụdị.Anyị chọrọ inye pụrụ iche ọgwụgwọ ụfọdụ ụdị: na nke a ibi akwụkwọ si ogologo nke Eriri ji tupu ha uru.
//! Anyị amaghị ụdị ihe bara uru anyị bara n'otu oge, yabụ anyị kwesịrị iji oge ngosipụta kama.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Ọrụ logger maka ụdị ọ bụla nke na-etinye Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Gbalịa ịgbanwe uru anyị na `String`.
//!     // Ọ bụrụ na ọ gara nke ọma, anyị chọrọ iwepụta ogologo String` yana uru ọ bara.
//!     // Ọ bụrụ na ọ bụghị, ọ bụ ụdị dị iche: naanị bipụta ya na-achọghị mma.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ọrụ a chọrọ abanye ya oke si tupu na-arụ ọrụ na ya.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... rụọ ọrụ ọzọ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait ọ bụla
///////////////////////////////////////////////////////////////////////////////

/// A trait i emomi ike dee.
///
/// Ọtụtụ ụdị na-etinye `Any` n'ọrụ.Otú ọ dị, ọ bụla ụdị nke nwere a na-abụghị `'static` akwụkwọ adịghị.
/// Hụ [module-level documentation][mod] maka nkọwa ndị ọzọ.
///
/// [mod]: crate::any
// trait a abụghị ihe nchekwa, agbanyeghị na anyị dabere na nkọwapụta nke ọrụ `type_id` naanị na koodu nchekwa (dịka, `downcast`).Dị ka ọ dị, nke ahụ ga-abụ nsogbu, mana n'ihi na naanị impen nke `Any` bụ a blanket mmejuputa iwu, ọ dịghị ndị ọzọ koodu nwere ike mejuputa `Any`.
//
// Anyị nwere ike plausibly ka a trait nwedịrị ike ịta-ọ ga-akpata breakage, ebe anyị na-achịkwa niile implementations-ma anyị na-ahọrọ na-na dị ka nke ahụ bụ ma adịghị mkpa n'ezie na ike na-emegharị ndị ọrụ banyere ihe dị iche nke nwedịrị ike ịta traits na nwedịrị ike ịta ụzọ (ie, `type_id` ka ga-adị mma ịkpọ, mana anyị nwere ike gosipụta otu a na dọkụmentị)
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ọkọkpọhi `TypeId` nke `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Methodszọ ndọtị maka ihe ọ bụla trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Gbaa mbọ hụ na n'ihi nke eg, isonyere a na eri nwere ike e biri ebi na ya mere eji na `unwrap`.
// Enwere ike agaghịzi achọzi gị ma ọ bụrụ na izipụ ọrụ na nkwalite.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Alaghachi `true` ma ọ bụrụ na ndị boxed ụdị bụ otu ihe ahụ dị ka `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Nweta `TypeId` nke ụdị ọrụ a na-instantiated na.
        let t = TypeId::of::<T>();

        // Nweta `TypeId` nke ụdị na trait ihe (`self`).
        let concrete = self.type_id();

        // Tụlee ma ``TypeId`s on ohiha.
        t == concrete
    }

    /// Laghachigoro ụfọdụ ntụpọ ọkpọ ma ọ bụrụ na ọ bụ ụdị `T`, ma ọ bụ `None` ọ bụrụ na ọ bụghị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: dị ịlele ma anyị na-atụ aka n'ụdị ziri ezi, anyị nwere ike ịdabere na ya
            // na ịlele maka nchekwa nchekwa n'ihi na anyị na-emejuputa atumatu ọ bụla maka niile ụdị;mba ndị ọzọ na impls nwere ike ịdị ka ha ga-emegideghị anyị impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Laghachi ụfọdụ mutable akwụkwọ banyere ọkpọ uru ma ọ bụrụ na ọ bụ nke ụdị `T`, ma ọ bụ `None` ma ọ bụrụ na ọ bụghị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: dị ịlele ma anyị na-atụ aka n'ụdị ziri ezi, anyị nwere ike ịdabere na ya
            // na ịlele maka nchekwa nchekwa n'ihi na anyị na-emejuputa atumatu ọ bụla maka niile ụdị;mba ndị ọzọ na impls nwere ike ịdị ka ha ga-emegideghị anyị impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Gaanụ n'ihu na usoro akọwapụtara na ụdị `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID na ya ụzọ
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` na-anọchi anya ihe nchọpụta pụrụ iche nke ụwa maka otu ụdị.
///
/// `TypeId` ọ bụla bụ ihe na-adịghị mma nke na-anaghị ekwe ka nyocha ihe dị n'ime kama ọ na-ekwe ka arụmọrụ ndị bụ isi dịka cloning, tụnyere, mbipụta, na igosi.
///
///
/// `TypeId` dị ugbu a maka ụdị nke na-enye `'static`, mana enwere ike wepu njedebe a na future.
///
/// Mgbe `TypeId` implements `Hash`, `PartialOrd`, na `Ord`, ọ bụ uru na-arịba ama na hashes na ịtụ ịdị iche iche n'etiti Rust releases.
/// Kpachara anya maka ịdabere na ha n'ime koodu gị!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// - Alaghachi na `TypeId` nke ụdị nke a ọnyà ọrụ e instantiated na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Alaghachi aha a ụdị dị ka a eriri iberi.
///
/// # Note
///
/// Emere nke a maka iji nyocha.
/// Edepụtaghị kpọmkwem ọdịnaya na usoro nke eriri a laghachiri, ewezuga ịbụ nkọwa kachasị mma nke ụdị ahụ.
/// Ka ihe atụ, n'etiti ndị ndido urụk na `type_name::<Option<String>>()` wee laghachi na-`"Option<String>"` na `"std::option::Option<std::string::String>"`.
///
///
/// Achọpụtaghị eriri azụ laghachi dị ka ihe nchọpụta pụrụ iche nke ụdị dịka ọtụtụ ụdị nwere ike ịpụta na otu ụdị aha.
/// N'otu aka ahụ, ọ dịghị nkwa na n'akụkụ nile nke a ụdị ga-egosi na laghachi eriri: n'ihi na ihe atụ, ndụ specifiers na-ugbu a na-adịghị gụnyere.
/// Ke adianade do, mmepụta nwere ike ịgbanwe n'etiti nsụgharị nke compiler.
///
/// The ugbu a, mmejuputa iwu-eji otu akụrụngwa dị ka compiler nchọpụta nsogbu na debuginfo, ma nke a na-ekwe nkwa.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Laghachi aha ụdị nke a rụpụtara-ka bara uru dị ka eriri iberi.
/// Nke a bụ otu ihe ahụ dị ka `type_name::<T>()`, ma ike-eji ebe ụdị a agbanwe abụghị mfe dị.
///
/// # Note
///
/// Nke a na-zubere maka achọpụta ọrịa were.The kpọmkwem ọdịnaya na format nke eriri na-akọwapụtaghị, ndị ọzọ karịa ịbụ a kasị mma-mgbalị nkọwa nke ụdị.
/// Ka ihe atụ, `type_name_of_val::<Option<String>>(None)` ike laghachi `"Option<String>"` ma ọ bụ `"std::option::Option<std::string::String>"`, ma ọ bụghị `"foobar"`.
///
/// Ke adianade do, mmepụta nwere ike ịgbanwe n'etiti nsụgharị nke compiler.
///
/// Ọrụ a na-adịghị edozi trait akpọkwa, nke pụtara na `type_name_of_val(&7u32 as &dyn Debug)` nwere ike ịlaghachi `"dyn Debug"`, ma ọ bụghị `"u32"`.
///
/// Ekwesighi iche ụdị aha ahụ dị ka ihe nchọpụta pụrụ iche nke ụdị;
/// otutu ụdị nwere ike ịkekọrịta otu ụdị aha.
///
/// The ugbu a, mmejuputa iwu-eji otu akụrụngwa dị ka compiler nchọpụta nsogbu na debuginfo, ma nke a na-ekwe nkwa.
///
/// # Examples
///
/// Mbipụta ndabara integer na ise n'elu ụdị.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}