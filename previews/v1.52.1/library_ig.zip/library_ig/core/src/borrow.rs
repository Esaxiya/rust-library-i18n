//! Modul maka ịrụ ọrụ na data agbaziri agbaziri.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait maka agbazinye data.
///
/// Na Rust, ọ bụ ihe a na-ahụkarị ịnye ụdị nnọchi anya nke ụdị maka usoro ojiji dị iche iche.
/// Dịka ọmụmaatụ, enwere ike ịhọrọ ebe nchekwa na njikwa maka uru dị ka ihe kwesịrị ekwesị maka otu ojiji site na ụdị pointer [`Box<T>`] ma ọ bụ [`Rc<T>`].
/// Beyond ndị a ọnyà wrappers na ike ga-eji na ihe ọ bụla ụdị, ụfọdụ ụdị-enye nhọrọ na-emenye enye nwere oké ọnụ arụmọrụ.
/// Otu ihe atụ maka ụdị dị otú ahụ bụ [`String`] nke na-agbakwunye ikike ịgbatị eriri na [`str`] bụ isi.
/// Nke a chọrọ idobe ozi ndị ọzọ enweghị isi maka eriri dị mfe, a na-agaghị agbanwe agbanwe.
///
/// Ndị a na ụdị na-enye ohere ka akpata data site zoro aka na ụdị na data.A na-ekwu na ha 'gbaziri dị ka' ụdị ahụ.
/// Ka ihe atụ, a [`Box<T>`] nwere ike biiri ka `T` mgbe a [`String`] nwere ike biiri ka `str`.
///
/// Pesdị na-egosiputa na enwere ike ịgbaziri ha dị ka ụdị `T` ụfọdụ site na itinye `Borrow<T>`, na-enye ntụnyere `T` na usoro trait nke [`borrow`].A ụdị free gbaziri dị ka ọtụtụ dị iche iche.
/// Y`oburu n`acho iweghari ego dika udiri-kwe ka emegharia data, o gha emejuputa [`BorrowMut<T>`].
///
/// Ọzọ, mgbe na-enye implementations n'ihi ọzọ traits, ọ chọrọ ka a ga-atụle ma hà ga-akpa àgwà yiri ndị nke kpatara ụdị dị ka a N'ihi ya nke na-eme dị ka a yiri ihe na-akpata ụdị.
/// Ọnyà koodu a na-eji `Borrow<T>` mgbe ọ na-adabere ná yiri omume nke ndị a ọzọ trait implementations.
/// Ndị a traits ga-abụ na-egosi dị ka ndị ọzọ trait bounds.
///
/// Karịsịa `Eq`, `Ord` na `Hash` ga-adịrị nha maka ụkpụrụ agbaziri agbaziri na nke nwere: `x.borrow() == y.borrow()` kwesịrị inye otu nsonaazụ dịka `x == y`.
///
/// Ọ bụrụ na ọnyà koodu naanị kwesịrị ọrụ niile ụdị na ike inye a banyere yiri ụdị `T`, ọ bụ mgbe mma iji [`AsRef<T>`] dị ka ihe na ụdị nwere ike n'enweghị mejuputa ya.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Dịka nchịkọta data, [`HashMap<K, V>`] nwere ma igodo na ụkpụrụ.Ọ bụrụ na isi ihe kpọmkwem data na ọbọp ke a ijikwa ụdị na ụdị ụfọdụ, ọ ga-Otú ọ dị, ka ga-ekwe omume ịchọ a uru iji a banyere isi nke data.
/// Dịka ọmụmaatụ, ọ bụrụ na igodo ahụ bụ eriri, yabụ enwere ike ịchekwa ya na map hash dị ka [`String`], ebe ọ ga-ekwe omume ịchọ iji [`&str`][`str`].
/// Yabụ, `insert` kwesịrị ịrụ ọrụ na `String` ebe `get` kwesịrị inwe ike iji `&str`.
///
/// Ubé mfe, mkpa akụkụ nke `HashMap<K, V>` anya dị ka nke a:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // ahapụla ubi
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Map niile hash bụ ọnụọgụ karịa ụdị ụdị `K`.N'ihi na ndị a igodo na-echekwara na hash map, nke a na ụdị nwere aka na isi nke data.
/// Mgbe inserting a isi-uru na ụzọ, na map na-nyere ndị dị otú a `K` na mkpa iji chọta ezi hash ịwụ na-elele ma ọ bụrụ na ndị isi bụ na-ama ugbu dabeere na `K`.Ya mere, ọ chọrọ `K: Hash + Eq`.
///
/// Mgbe ị na-achọ uru na eserese ngosi, agbanyeghị, ịnwe ntụnye aka na `K` dị ka isi ihe ị ga-achọ ga-achọ ka mepụta ụdị uru a.
/// N'ihi na eriri igodo, a ga-apụta a `String` uru kwesịrị ka a kere naanị maka search maka otu ebe naanị a `str` dị.
///
/// Kama nke ahụ, usoro `get` bụ ọnyà karịa ụdị isi data data, akpọrọ `Q` na mbinye aka usoro dị n'elu.Ọ na-ekwu na `K` agbaziri ka a `Q` site na-achọ na `K: Borrow<Q>`.
/// Site Ọzọkwa chọrọ ka `Q: Hash + Eq`, ọ na-egosi na chọrọ na `K` na `Q` nwere implementations nke `Hash` na `Eq` traits na-emepụta yiri ihe.
///
/// Mmejuputa nke `get` dabere na mmejuputa atumatu nke `Hash` site na ichoputa ihe nkpuchi isi site na ịkpọ `Hash::hash` na uru `Q` n'agbanyeghị na etinyere igodo ahụ dabere na uru hash gbakọrọ site na `K`.
///
///
/// N'ihi ya, na-hash map oge izu ma ọ bụrụ na a `K` wrapping a `Q` uru na-arụpụta a dị iche iche hash karịa `Q`.Iji maa atụ, were ya na ị nwere ụdị nke na-eyiri eriri ma jiri mkpụrụ edemede ASCII leghaara ikpe ha anya:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// N'ihi na abụọ hà ụkpụrụ mkpa iji na-emepụta otu hash uru, mmejuputa `Hash` kwesịrị ileghara ascii ikpe, kwa:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` nwere ike itinye `Borrow<str>` n'ọrụ?Ọ na-emekwa nwere ike inye a banyere a eriri iberi via ya ẹdude ekesịpde eriri.
/// Ma n'ihi na ya `Hash` mmejuputa iwu dị nnọọ iche, ọ na-akpa àgwà dị iche iche si `str` na Ya mere ga N'eziokwu, mejuputa `Borrow<str>`.
/// Ọ bụrụ n`ịchọrọ ikwe ka ndị ọzọ nweta `str` bụ isi, ọ nwere ike ime nke ahụ site na `AsRef<str>` nke anaghị ebu ihe ọ bụla chọrọ.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Onweghi ego na-ebiri site na uru enwere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait maka iji ego gbazinye data.
///
/// Dị ka a ibe [`Borrow<T>`] a trait na-enye ohere a ụdị gbaziri dị ka ihe kpatara ụdị site n'inye a mutable akwụkwọ.
/// Lee [`Borrow<T>`] maka ozi ndị ọzọ na-agbaziri dị ka ọzọ ụdị.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Na-agbazinye ego site na uru bara uru.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}