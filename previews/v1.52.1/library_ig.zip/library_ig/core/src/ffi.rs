#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Utilities metụtara mba ọzọ ọrụ interface (FFI) bindings.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Ẹkot C si `void` ụdị mgbe eji dị ka a [pointer].
///
/// Na isi, `*const c_void` bụ C na `const void*` na `*mut c_void` bụ C na `void*`.
/// Nke sị, na nke a bụ *bụghị* otu dị ka C si `void` nloghachi ụdị, nke bụ Rust si `()` ụdị.
///
/// Iji gosipụta ihe atụ n'ụdị FFI, rue mgbe `extern type` kwụsiri ike, a na-atụ aro ka ị jiri newtype wrapper gburugburu ihe efu efu.
///
/// Hụ [Nomicon] maka nkọwa.
///
/// Otu nwere ike iji `std::os::raw::c_void` ma ọ bụrụ na ha chọrọ na-akwado ochie Rust compiler ala 1.1.0.
/// Mgbe Rust 1.30.0 gasịrị, ebugharịrị ọzọ na nkọwa a.
/// Maka ozi ọzọ, biko gụọ [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, maka LLVM ịmata adabaghi pointer ụdị nakwa ọrụ dị ka malloc(), anyị mkpa nwere na ọ na-anọchi anya dị ka i8 * na LLVM bitcode.
// Ihe enum eji eme ihe ebe a na-eme nke a ma gbochie iji ụdị "raw" eme ihe site na inwe onodu di iche.
// Anyị kwesịrị abụọ variants, n'ihi na compiler ọdọhọde banyere repr àgwà ma na anyị mkpa ọ dịkarịa ala otu variant ka ma ọ bụghị enum ga-n'enweghị onye bi na ma ọ dịkarịa ala dereferencing dị pointers ga-UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Ntọala nhazi nke `va_list`.
// Aha ahụ bụ WIP, na-eji `VaListImpl` maka ugbu a.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant n'elu `'f`, otú onye ọ bụla `VaListImpl<'f>` ihe na-kegide n'ógbè ọrụ ọ kọwaa
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Abi mmejuputa iwu a `va_list`.
/// Hụ [AArch64 Procedure Call Standard] maka nkọwa ndị ọzọ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Abi mmejuputa iwu a `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Abi mmejuputa iwu a `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// A fụchie maka a `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ụka a `VaListImpl` n'ime a `VaList` na bụ ọnụọgụ abụọ-dakọtara na C si `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ụka a `VaListImpl` n'ime a `VaList` na bụ ọnụọgụ abụọ-dakọtara na C si `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Ekwesiri iji VaArgSafe trait mee ihe na ihu ọha, agbanyeghị, a gaghị ekwe ka trait n'onwe ya mee ihe na mpụga usoro a.
// Ikwe ọrụ mejuputa trait maka a ọhụrụ ụdị (si otú ikwe ka va_arg intrinsic ka ga-eji na a ọhụrụ ụdị) yiri ka ime ka undefined omume.
//
// FIXME(dlrobertson): Iji na-eji ndị VaArgSafe trait na a ọha interface ma hụ na ọ nwere ike ọ gaghị eji ọzọ, ndị trait kwesịrị ịbụ n'ihu ọha n'ime a onwe modul.
// Ozugbo RFC 2145 e emejuputa anya n'ime rụọ ọrụ a.
//
//
//
//
mod sealed_trait {
    /// Trait nke na-ekwe ka ụdị ndị e kwere ka iji [super::VaListImpl::arg] mee ihe.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Advance na-esote arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Mbipụta ndị `va_list` na ugbu a ebe.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // NCHEKWA: nke bere ga-akwado nchekwa nkwekọrịta maka `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // EGO: Anyị na-edegara `MaybeUninit` akwụkwọ, yabụ amalitela yana `assume_init` bụ iwu
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: a ga-akpọ `va_end`, ma e nweghị ọcha ụzọ
        // ekwe nkwa na `drop` mgbe ego n'anya inlined n'ime ya bere, otú ahụ `va_end` ga aka kpọmkwem na-akpọ site na otu ọrụ dị ka kwekọrọ ekwekọ `va_copy`.
        // `man va_end` na-ekwu na C na-achọ a, na LLVM ihu ọma ndị a na-C semantics, anyị kwesịrị ijide n'aka na `va_end` na-mgbe na-akpọ site na otu ọrụ dị ka `va_copy`.
        //
        // Maka nkọwa ndị ọzọ, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Nke a na-arụ ọrụ ugbu a, ebe ọ bụ na `va_end` enweghị ihe ọ bụla na ebumnuche LLVM dị ugbu a.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Ibibi arglist `ap` mgbe initialization na `va_start` ma ọ bụ `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Detuo ọnọdụ nke ugbu a arglist `src` na arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Ibu esemokwu nke ụdị `T` si `va_list` `ap` na increment esemokwu `ap` ihe na.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}