//! Compiler intrinsics.
//!
//! Nkọwa kwekọrọ na `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! The kwekọrọ ekwekọ const implementations nọ `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Isi intrinsics
//!
//! Note: mgbanwe ọ bụla na constness nke intrinsics ga-atụle ndị otu asụsụ.
//! Nke a na-agụnye mgbanwe nkwụsi ike nke constness.
//!
//! Iji mee ka ihe intrinsic usable na ide-oge, otu mkpa iṅomi mmejuputa si <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ka `compiler/rustc_mir/src/interpret/intrinsics.rs` na tinye a `#[rustc_const_unstable(feature = "foo", issue = "01234")]` na intrinsic.
//!
//!
//! Ọ bụrụ na ekwesịrị iji ihe eji eme ihe sitere na `const fn` nwere njirimara `rustc_const_stable`, njirimara nke intrinsic ga-abụ `rustc_const_stable`, kwa.
//! Mgbanwe dị otú ahụ ka a ghara ime enweghị T-lang alo, n'ihi na ọ mee a feature n'ime asụsụ a na-apụghị replicated na ọrụ koodu enweghị compiler support.
//!
//! # Volatiles
//!
//! Ihe omimi dị iche iche na-enye arụmọrụ emere iji mee ihe na I/O ebe nchekwa, bụ nke ejiri n'aka na onye nchịkọta ahụ agaghị eweghachi ya.Lee LLVM akwụkwọ na [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ngwurugwu atomic na-enye arụmọrụ atomic a na-ejikarị arụ ọrụ na okwu igwe, nwere ọtụtụ ihe nchekwa ebe nchekwa.Ha na-erube isi semantics ka C++ 11.Lee LLVM akwụkwọ na [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A ngwa ngwa ntu ala na ebe nchekwa ịtụ:
//!
//! * Nweta, a mgbochi nke inweta a mkpọchi.Readsgụ na-agụ na-esote na-ewere ọnọdụ mgbe mgbochi ahụ.
//! * Hapụ, ihe mgbochi maka ịhapụ mkpọchi.Bu ụzọ na-agụ na-ede-ewere ọnọdụ tupu mgbochi.
//! * Sequentially agbanwe agbanwe, sequentially agbanwe agbanwe arụmọrụ na-ekwe nkwa na-eme ka.Nke a bụ ọnọdụ ọkọlọtọ maka ịrụ ọrụ na ụdị atọmịk ma dakọtara na Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// A na-eji mbubata ndị a maka ime ka njikọ intra-doc dị mfe
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // NCHEKWA: ahụ `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ndị a intrinsics iri raw pointers n'ihi na ha mutate aliased ebe nchekwa, nke bụ irè n'ihi na ma `&` ma ọ bụ `&mut`.
    //

    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::SeqCst`] dị ka ma ndị `success` na `failure` kwa.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::Acquire`] dị ka ma ndị `success` na `failure` kwa.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::Release`] ka `success` na [`Ordering::Relaxed`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::AcqRel`] ka `success` na [`Ordering::Acquire`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::Relaxed`] dị ka ma ndị `success` na `failure` kwa.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::SeqCst`] ka `success` na [`Ordering::Relaxed`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::SeqCst`] ka `success` na [`Ordering::Acquire`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// Ejiri ụdị [`atomic`] a kwụsiri ike na ụdị [`atomic`] site na usoro `compare_exchange` site na ịgafe [`Ordering::Acquire`] dị ka `success` na [`Ordering::Relaxed`] dị ka usoro `failure`.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange` usoro site na-agafe [`Ordering::AcqRel`] ka `success` na [`Ordering::Relaxed`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange_weak` usoro site na-agafe [`Ordering::SeqCst`] dị ka ma ndị `success` na `failure` kwa.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange_weak` usoro site na-agafe [`Ordering::Acquire`] dị ka ma ndị `success` na `failure` kwa.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// Ejiri ụdị [`atomic`] a kwụsiri ike na ụdị [`atomic`] site na usoro `compare_exchange_weak` site na ịgafe [`Ordering::Release`] dị ka `success` na [`Ordering::Relaxed`] dị ka usoro `failure`.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// Ejiri ụdị [`atomic`] a kwụsiri ike na ụdị [`atomic`] site na usoro `compare_exchange_weak` site na ịgafe [`Ordering::AcqRel`] dị ka `success` na [`Ordering::Acquire`] dị ka usoro `failure`.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// Ejiri ụdị [`atomic`] ahụ kwụsie ike na ụdị [`atomic`] site na usoro `compare_exchange_weak` site na ịgafe [`Ordering::Relaxed`] dị ka mpaghara `success` na `failure`.
    ///
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange_weak` usoro site na-agafe [`Ordering::SeqCst`] ka `success` na [`Ordering::Relaxed`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange_weak` usoro site na-agafe [`Ordering::SeqCst`] ka `success` na [`Ordering::Acquire`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `compare_exchange_weak` usoro site na-agafe [`Ordering::Acquire`] ka `success` na [`Ordering::Relaxed`] ka `failure` kwa.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Na-echekwa uru ma ọ bụrụ na uru dị ugbu a bụ nke `old`.
    ///
    /// Ejiri ụdị [`atomic`] a kwụsiri ike na ụdị [`atomic`] site na usoro `compare_exchange_weak` site na ịgafe [`Ordering::AcqRel`] dị ka `success` na [`Ordering::Relaxed`] dị ka usoro `failure`.
    /// Ọmụmaatụ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Na-eburu uru pointer dị ugbu a.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `load` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Na-eburu uru pointer dị ugbu a.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `load` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Na-eburu uru pointer dị ugbu a.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `load` site na ịgafe [`Ordering::Relaxed`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Echekwa uru na kwuru kpọmkwem ebe nchekwa na ọnọdụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `store` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Echekwa uru na kwuru kpọmkwem ebe nchekwa na ọnọdụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `store` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Echekwa uru na kwuru kpọmkwem ebe nchekwa na ọnọdụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `store` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Na-echekwa uru na ọnọdụ ebe nchekwa akọwapụtara, na-eweghachi uru ochie.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `swap` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-echekwa uru na ọnọdụ ebe nchekwa akọwapụtara, na-eweghachi uru ochie.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `swap` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-echekwa uru na ọnọdụ ebe nchekwa akọwapụtara, na-eweghachi uru ochie.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `swap` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-echekwa uru na ọnọdụ ebe nchekwa akọwapụtara, na-eweghachi uru ochie.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `swap` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-echekwa uru na ọnọdụ ebe nchekwa akọwapụtara, na-eweghachi uru ochie.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `swap` site na ịgafe [`Ordering::Relaxed`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Na-agbakwụnye na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_add` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-agbakwụnye na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_add` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-agbakwụnye na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_add` site na ịgafe [`Ordering::Release`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-agbakwụnye na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_add` site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Na-agbakwụnye na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_add` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Wepụ site ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_sub` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Wepụ site ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_sub` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Wepụ site ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_sub` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Wepụ site ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_sub` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Wepụ site ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_sub` site na ịgafe [`Ordering::Relaxed`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise na na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_and` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_and` site na ịgafe [`Ordering::Acquire`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_and` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_and` site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_and` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`AtomicBool`] site na usoro `fetch_nand` site na ịgafe [`Ordering::SeqCst`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`AtomicBool`] site na usoro `fetch_nand` site na ịgafe [`Ordering::Acquire`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`AtomicBool`] site na usoro `fetch_nand` site na ịgafe [`Ordering::Release`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`AtomicBool`] ụdị site na `fetch_nand` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand na uru dị ugbu a, weghachite uru gara aga.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`AtomicBool`] ụdị site na `fetch_nand` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ma ọ bụ na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_or` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma ọ bụ na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_or` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma ọ bụ na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_or` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma ọ bụ na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_or` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma ọ bụ na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_or` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_xor` site na ịgafe [`Ordering::SeqCst`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_xor` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_xor` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// Thedị nke a kwụsiri ike dị na ụdị [`atomic`] site na usoro `fetch_xor` site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor na ugbu a bara uru, na-alọta na aga na uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] ụdị site na `fetch_xor` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oke na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// Ejiri ụdị ụdị nke a dị na [`atomic`] nke etinyere aka site na usoro `fetch_max` site na ịgafe [`Ordering::Acquire`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// Ejiri ụdị ụdị nke a dị na [`atomic`] nke etinyere aka site na usoro `fetch_max` site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na ugbu a uru.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kacha nta na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// Ejiri ụdị ụdị nke a dị na [`atomic`] nke etinyere aka site na usoro `fetch_min` site na ịgafe [`Ordering::SeqCst`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// Ejiri ụdị ụdị nke a dị na [`atomic`] nke etinyere aka site na usoro `fetch_min` site na ịgafe [`Ordering::Acquire`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru iji a bịanyere aka tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] aka integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kacha nta na ugbu a bara uru na-eji ihe unsigned tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::SeqCst`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru na-eji ihe unsigned tụnyere.
    ///
    /// Ihe odide a kwudosiri ike na ụdị [`atomic`] a na-agbanyeghị aka site na usoro `fetch_min` site na ịgafe [`Ordering::Acquire`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru na-eji ihe unsigned tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru na-eji ihe unsigned tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kacha nta na ugbu a bara uru na-eji ihe unsigned tụnyere.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_min` usoro site na-agafe [`Ordering::Relaxed`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oke na uru dị ugbu a site na iji ntụnyere aha na-enweghị atụ.
    ///
    /// Ihe odide a kwudosiri ike na ụdị [`atomic`] a na-agbanyeghị aka site na usoro `fetch_max` site na ịgafe [`Ordering::SeqCst`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na uru dị ugbu a site na iji ntụnyere aha na-enweghị atụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::Acquire`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na uru dị ugbu a site na iji ntụnyere aha na-enweghị atụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::Release`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na uru dị ugbu a site na iji ntụnyere aha na-enweghị atụ.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic`] unsigned integer ụdị site na `fetch_max` usoro site na-agafe [`Ordering::AcqRel`] ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oke na uru dị ugbu a site na iji ntụnyere aha na-enweghị atụ.
    ///
    /// Ihe nkwụsi ike nke mkpụrụedemede a dị na ụdị XVXXXXXXXXX nke na-edeghị aha site na usoro `fetch_max` site na ịgafe [`Ordering::Relaxed`] dị ka `order`.
    /// Ọmụmaatụ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// The `prefetch` intrinsic bụ a ndumodu na koodu generator itinye a prefetch ntụziaka ma ọ bụrụ na-akwado;ma ọ bụghị, ọ bụ a dịghị-op.
    /// Prefetches enweghị mmetụta na omume mmemme ma ọ nwere ike ịgbanwe njirimara arụmọrụ ya.
    ///
    /// Mkparịta ụka `locality` ga-abụrịrị ọnụ ọgụgụ na-agbanwe agbanwe mgbe niile ma bụrụkwa nkọwapụta oge ebe sitere na (0), enweghị mpaghara, ruo (3), na-echekwa mpaghara dị oke nchekwa.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic bụ a ndumodu na koodu generator itinye a prefetch ntụziaka ma ọ bụrụ na-akwado;ma ọ bụghị, ọ bụ a dịghị-op.
    /// Prefetches enweghị mmetụta na omume mmemme ma ọ nwere ike ịgbanwe njirimara arụmọrụ ya.
    ///
    /// Mkparịta ụka `locality` ga-abụrịrị ọnụ ọgụgụ na-agbanwe agbanwe mgbe niile ma bụrụkwa nkọwapụta oge ebe sitere na (0), enweghị mpaghara, ruo (3), na-echekwa mpaghara dị oke nchekwa.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic bụ a ndumodu na koodu generator itinye a prefetch ntụziaka ma ọ bụrụ na-akwado;ma ọ bụghị, ọ bụ a dịghị-op.
    /// Prefetches enweghị mmetụta na omume mmemme ma ọ nwere ike ịgbanwe njirimara arụmọrụ ya.
    ///
    /// Mkparịta ụka `locality` ga-abụrịrị ọnụ ọgụgụ na-agbanwe agbanwe mgbe niile ma bụrụkwa nkọwapụta oge ebe sitere na (0), enweghị mpaghara, ruo (3), na-echekwa mpaghara dị oke nchekwa.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic bụ a ndumodu na koodu generator itinye a prefetch ntụziaka ma ọ bụrụ na-akwado;ma ọ bụghị, ọ bụ a dịghị-op.
    /// Prefetches enweghị mmetụta na omume mmemme ma ọ nwere ike ịgbanwe njirimara arụmọrụ ya.
    ///
    /// Mkparịta ụka `locality` ga-abụrịrị ọnụ ọgụgụ na-agbanwe agbanwe mgbe niile ma bụrụkwa nkọwapụta oge ebe sitere na (0), enweghị mpaghara, ruo (3), na-echekwa mpaghara dị oke nchekwa.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ogige atọm.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic::fence`] site agafe [`Ordering::SeqCst`] ka `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ogige atọm.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic::fence`] site agafe [`Ordering::Acquire`] ka `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ogige atọm.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic::fence`] site agafe [`Ordering::Release`] ka `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ogige atọm.
    ///
    /// Thedị nke a kwadoro dị na [`atomic::fence`] site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A compiler-na-na ebe nchekwa mgbochi.
    ///
    /// Memory accesses dịghị mgbe a ga reordered gafee a mgbochi site compiler, ma ọ dịghị ntụziaka ga-enwupụta maka ya.
    /// Nke a dabara adaba maka arụmọrụ na otu eri ahụ enwere ike ibute, dịka mgbe gị na ndị na-ahụ mgbaama na-emekọrịta ihe.
    ///
    /// Thedị nke a kwadoro dị na [`atomic::compiler_fence`] site na ịgafe [`Ordering::SeqCst`] dị ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A compiler-na-na ebe nchekwa mgbochi.
    ///
    /// Memory accesses dịghị mgbe a ga reordered gafee a mgbochi site compiler, ma ọ dịghị ntụziaka ga-enwupụta maka ya.
    /// Nke a dabara adaba maka arụmọrụ na otu eri ahụ enwere ike ibute, dịka mgbe gị na ndị na-ahụ mgbaama na-emekọrịta ihe.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic::compiler_fence`] site agafe [`Ordering::Acquire`] ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A compiler-na-na ebe nchekwa mgbochi.
    ///
    /// Memory accesses dịghị mgbe a ga reordered gafee a mgbochi site compiler, ma ọ dịghị ntụziaka ga-enwupụta maka ya.
    /// Nke a dabara adaba maka arụmọrụ na otu eri ahụ enwere ike ibute, dịka mgbe gị na ndị na-ahụ mgbaama na-emekọrịta ihe.
    ///
    /// The Nọsi'ike mbipute a intrinsic dị na [`atomic::compiler_fence`] site agafe [`Ordering::Release`] ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A compiler-na-na ebe nchekwa mgbochi.
    ///
    /// Memory accesses dịghị mgbe a ga reordered gafee a mgbochi site compiler, ma ọ dịghị ntụziaka ga-enwupụta maka ya.
    /// Nke a dabara adaba maka arụmọrụ na otu eri ahụ enwere ike ibute, dịka mgbe gị na ndị na-ahụ mgbaama na-emekọrịta ihe.
    ///
    /// Thedị nke a kwadoro dị na [`atomic::compiler_fence`] site na ịgafe [`Ordering::AcqRel`] dị ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsic na-erite ya pụtara site na àgwà mmasị ka ọrụ.
    ///
    /// Ka ihe atụ, dataflow ojiji a igba static assertions ka `rustc_peek(potentially_uninitialized)` ga-abụọ-ego na dataflow n'ezie compute na ọ uninitialized na mgbe ahụ na-achịkwa oruru.
    ///
    ///
    /// Nke a intrinsic kwesịghị iji mpụga nke compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts ogbugbu nke usoro.
    ///
    /// Ihe omuma ndi ozo nke enyi na ndi mmadu bu [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Na-agwa ndị optimizer na a na koodu bụghị pụrụ ime eme, na-eme n'ihu optimizations.
    ///
    /// NB, nke bụ ihe dị iche iche si `unreachable!()` nnukwu: N'adịghị ka nnukwu, nke panics mgbe ọ na-gburu, ya bụ *undefined omume* iru koodu-akara na ọrụ a.
    ///
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Na-agwa ndị optimizer na a ọnọdụ bụ eziokwu mgbe nile.
    /// Ọ bụrụ na ọnọdụ bụ ụgha, omume na-undefined.
    ///
    /// Ọ dịghị koodu eme n'ihi na nke a intrinsic, ma optimizer ga na-agbalị iji chebe ya (na ya ọnọdụ) n'etiti gafee, nke nwere ike igbochi njikarịcha nke gbara ya gburugburu na koodu ma belata arụmọrụ.
    /// Ọ na-ekwesịghị-eji ma ọ bụrụ na ndị invariant nwere ike chọpụtara site na optimizer na ya, ma ọ bụ ma ọ bụrụ na ọ na-adịghị eme ka ọ bụla dị ịrịba optimizations.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Hints na compiler na branch ọnọdụ yiri ka ịbụ eziokwu.
    /// Alaghachi uru gafere ya.
    ///
    /// Uru ọ bụla ọzọ karịa na `if` okwu ga-eleghị anya enweghị mmetụta.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hints na compiler na branch ọnọdụ nwere ike ịbụ ụgha.
    /// Alaghachi uru gafere ya.
    ///
    /// Uru ọ bụla ọzọ karịa na `if` okwu ga-eleghị anya enweghị mmetụta.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Kpere a breakpoint ọnyà, mee nnyocha site a debugger.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn breakpoint();

    /// The size nke a ụdị na bytes.
    ///
    /// More kpọmkwem, a na-dechapụ na bytes n'etiti soje ihe nke otu ụdị, gụnyere itinye n'ọnọdụ padding.
    ///
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// The kacha nta itinye n'ọnọdụ nke a ụdị.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// The họọrọ itinye n'ọnọdụ nke a ụdị.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// The size nke referenced uru bytes.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ntughari achọrọ nke uru a kpọtụrụ aha.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Alụta a static eriri iberi nwere aha nke a ụdị.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Nweta ihe nchọpụta zuru ụwa ọnụ pụrụ iche na ụdị akọwapụtara.
    /// Ọrụ a ga-alaghachi na otu uru maka a ụdị n'agbanyeghị bụla crate ọ na-akpọku.
    ///
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A nche maka nwedịrị ike ịta na ọrụ a na-apụghị mgbe a ga-egbu ma ọ bụrụ na `T` bụ n'enweghị onye bi na:
    /// Nke a ga-statically ma panic, ma ọ bụ ime ihe ọ bụla.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A nche maka nwedịrị ike ịta na ọrụ a na-apụghị mgbe a ga-egbu ma ọ bụrụ na `T` anaghị ekwe efu-initialization: Nke a ga-statically ma panic, ma ọ bụ ime ihe ọ bụla.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn assert_zero_valid<T>();

    /// A nche maka nwedịrị ike ịta na ọrụ a na-apụghị mgbe a ga-egbu ma ọ bụrụ na `T` nwere ghara ịdị irè bit ihe nakawa etu esi: Nke a ga-statically ma panic, ma ọ bụ ime ihe ọ bụla.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn assert_uninit_valid<T>();

    /// Nweta mkpado `Location` na-egosi ebe akpọrọ ya.
    ///
    /// Tụlee iji [`core::panic::Location::caller`](crate::panic::Location::caller) kama.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Na-akpali a uru nke akporo na-enweghị na-agba ọsọ dobe mama.
    ///
    /// Nke a dị naanị n'ihi [`mem::forget_unsized`];nkịtị `forget` eji `ManuallyDrop` kama.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets na ibe n'ibe nke a bara uru nke otu ụdị dị ka ọzọ ụdị.
    ///
    /// Typesdị abụọ ahụ aghaghị inwe otu nha.
    /// Ma mbụ, ma ọ bụ ndị N'ihi ya, nwere ike ịbụ ihe [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` bụ ihe kwekọrọ na ntụgharị nke otu ụdị na nke ọzọ.Ọ mbipụta ndị ibe n'ibe si iyi uru n'ime ebe uru, mgbe na-echefu na mbụ.
    /// Ọ bụ Ẹkot C si `memcpy` n'okpuru hundu, dị nnọọ ka `transmute_copy`.
    ///
    /// Ebe ọ bụ na `transmute` bụ ọrụ bara uru, nhazi nke ụkpụrụ gbanwere * abụghị nsogbu.
    /// Dị ka ihe ọ bụla ọzọ ọrụ, na compiler ama ana achi achi ma `T` na `U` na-ekwesị kwekọọ.
    /// Otú ọ dị, mgbe transmuting ụkpụrụ na *ebe ọzọ*(dị ka pointers, kwuru, igbe ...), nke bere nwere iji hụ kwesịrị ekwesị itinye n'ọnọdụ nke a kapịrị ọnụ-ka ụkpụrụ.
    ///
    /// `transmute` bụ **incredibly** nwedịrị ike ịta.E nwere a buru ibu ọtụtụ ụzọ na-eme ka [undefined behavior][ub] na ọrụ a.`transmute` kwesịrị ịbụ njedebe ikpeazụ.
    ///
    /// [nomicon](../../nomicon/transmutes.html) nwere akwụkwọ ndị ọzọ.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// E nwere ihe ole na ole na `transmute` bụ n'ezie bara uru maka.
    ///
    /// Na-atụgharị pointer na pointer ọrụ.Nke a bụ *bụghị* obere ka ígwè ọrụ ebe ọrụ pointers na data pointers nwere dị iche iche nha.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Inyịme a ndụ, ma ọ bụ shortening ihe invariant ndụ.Nke a emewokwa, nnọọ nwedịrị ike ịta Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Enwela obi nkoropụ: ọtụtụ ojiji nke `transmute` nwere ike-enweta site ọzọ n'aka.
    /// N'okpuru ebe a na-ahụkarị ngwa nke `transmute` nke ike-anọchi na odi mfe chepụtara.
    ///
    /// Agbanye raw bytes(`&[u8]`) ka `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // were `u32::from_ne_bytes` kama
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ma ọ bụ jiri `u32::from_le_bytes` ma ọ bụ `u32::from_be_bytes` kọwaa endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Agbanye a pointer n'ime a `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Jiri ihe `as` nkedo kama
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Agbanye a `*mut T` n'ime ihe `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Jiri a reborrow kama
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Tụgharị `&mut T` n'ime `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ugbu a, na-etinye ọnụ `as` na reborrowing, lee chaining nke `as` `as` bụghị transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Tụgharị `&str` n'ime `&[u8]`:
    ///
    /// ```
    /// // nke a abụghị ụzọ dị mma iji mee nke a.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Nwere ike iji `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ma ọ bụ, dị na-eji a byte eriri, ọ bụrụ na ị nwere ịchịkwa eriri nkịtị
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Agbanye a `Vec<&T>` n'ime a `Vec<Option<&T>>`.
    ///
    /// Iji transmute n'ime ụdị ọdịnaya nke a akpa, ị ga-eme ka n'aka na-emerụ ihe ọ bụla nke na akpa si invariants.
    /// N'ihi `Vec`, nke a pụtara na ma na size *na itinye n'ọnọdụ* nke dị n'ime ụdị nwere ka dakọtara.
    /// Ọzọ containers nwere ike na-adabere size nke ụdị, itinye n'ọnọdụ, ma ọ bụ ọbụna `TypeId`, nke ikpe transmuting gaghị ekwe omume na niile na-enweghị emebi akpa invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // mmepụta oyiri na vector dị ka anyị ga-iwerekwa ha emechaa
    /// let v_clone = v_orig.clone();
    ///
    /// // Iji transmute: a na-adabere ná unspecified data layout nke `Vec`, nke bụ ihe ọjọọ echiche na ike ime ka Undefined Àgwà.
    /////
    /// // Otú ọ dị, ọ bụ ọ na-otu.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Nke a bụ ụzọ akwadoro, nchekwa.
    /// // Ọ na-edepụta vector niile, agbanyeghị, na usoro ọhụrụ.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Nke a bụ kwesịrị ekwesị ọ dịghị-oyiri, nwedịrị ike ịta ụzọ "transmuting" a `Vec`, na-enweghị ịdabere na data layout.
    /// // Kama ịkpọ `transmute` n'ụzọ nkịtị, anyị na-eme ihe ngosi, mana n'ihe gbasara ịtụgharị ụdị nke mbụ (`&i32`) na nke ọhụrụ (`Option<&i32>`), nke a nwere otu ọkwa ahụ.
    /////
    /// // E wezụga ozi nyere n'elu, na-ịkpọ [`from_raw_parts`] akwụkwọ.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Melite nke a mgbe akwadoro vec_into_raw_parts.
    ///     // Gbaa mbọ hụ na mbụ vector na-adịghị ama esịn.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Mmejuputa `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // E nwere ọtụtụ ụzọ na-eme nke a, na e nwere ọtụtụ nsogbu ndị na-esonụ (transmute) ụzọ.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // mbụ: transmute na-adịghị pịnye mma;ihe niile o choro bu na T na
    ///         // U bụ nke otu size.
    ///         // Nke abụọ, n'ebe a, na i nwere abụọ mutable zoro arutu aka na otu na ebe nchekwa.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Nke a ego n'anya Bibie nke ụdị nchekwa nsogbu;`&mut *` ga* naanị *-enye gị ihe `&mut T` site na `&mut T` ma ọ bụ `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Otú ọ dị, ị ka nwere ihe abụọ mutable zoro arutu aka na otu na ebe nchekwa.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Nke a bụ otú ọkọlọtọ n'ọbá akwụkwọ na-eme ya.
    /// // Nke a bụ usoro kachasị mma, ma ọ bụrụ na ịchọrọ ịme ihe dị ka nke a
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Nke a nwere ntụaka atọ nwere ike ịtụgharị n'otu aka ahụ.`slice`, na rvalue ret.0, na rvalue ret.1.
    ///         // `slice` anaghị eji ya eme ihe mgbe `let ptr = ...` gasịrị, yabụ mmadụ nwere ike ịgwọ ya dị ka "dead", yabụ, ị nwere naanị mpekere abụọ nwere ike ịgbanwe.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ezie na nke a na-eme intrinsic const iduro, anyị nwere ụfọdụ koodu omenala na const fn
    // ndenye ego na gbochie ya iji n'ime `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Alaghachi `true` ma ọ bụrụ n'ezie ụdị nyere dị ka `T` achọ dobe mama;alaghachi `false` ma ọ bụrụ n'ezie ụdị nyere maka `T` implements `Copy`.
    ///
    ///
    /// Ọ bụrụ na ụdị ahụ adịchaghị mkpa ịhapụ nkedo ma ọ bụ na-etinye `Copy` n'ọrụ, mgbe ahụ akọwapụtaghị uru ọrụ a bara.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Na-agụta ihe depụtara site na pointer.
    ///
    /// A na-etinye nke a n'ọrụ dị ka ihe dị mkpa iji zere ịtụgharị na site na integer, ebe ntụgharị ahụ ga-atụfu ozi aha.
    ///
    /// # Safety
    ///
    /// Ma ndị na-amalite ma na-akpata pointer ga-abụ ma na ókè ma ọ bụ otu byte gara aga na njedebe nke ihe ekenyela ihe.
    /// Ọ bụrụ na ma pointer bụ nke ókè ma ọ bụ som ejupụta emee mgbe ọ bụla ọzọ na ojiji nke laghachi uru ga-eme undefined omume.
    ///
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Wepụtara dechapụ si a pointer, nwere ike wrapping.
    ///
    /// Nke a na-emejuputa atumatu dị ka ihe intrinsic zere n'ịtụgharị gaa na site na ihe integer, ebe ọ bụ na akakabarede egbochi ụfọdụ optimizations.
    ///
    /// # Safety
    ///
    /// N'adịghị ka ndị `offset` intrinsic, a intrinsic anaghị machibido dapụtara pointer ka uche n'ime ma ọ bụ otu byte gara aga na njedebe nke ihe ekenyela ihe, na ọ na-eyiri abụọ inyeaka som.
    /// Ihe uru idịghe nti ka e jiri ya na-ohere na ebe nchekwa.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kwekọrọ na `llvm.memcpy.p0i8.0i8.*` kwesịrị ekwesị, nwere nha nke `count`*`size_of::<T>()` na nhazi nke
    ///
    /// `min_align_of::<T>()`
    ///
    /// The obodo oke ka atọrọ ka `true`, n'ihi ya, ọ ga-kachasị si ma size bụ hà efu.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Kwadoro na `llvm.memmove.p0i8.0i8.*` kwesịrị ekwesị, nke nwere `count* size_of::<T>()` na nhazi nke
    ///
    /// `min_align_of::<T>()`
    ///
    /// The obodo oke ka atọrọ ka `true`, n'ihi ya, ọ ga-kachasị si ma size bụ hà efu.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ẹkot kwesịrị ekwesị `llvm.memset.p0i8.*` intrinsic, na a size of `count* size_of::<T>()` na itinye n'ọnọdụ nke `min_align_of::<T>()`.
    ///
    ///
    /// The obodo oke ka atọrọ ka `true`, n'ihi ya, ọ ga-kachasị si ma size bụ hà efu.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Na-arụ ọrụ na-agbanwe agbanwe site na pointer `src`.
    ///
    /// Dị nke a kwadoro bụ [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Anamde a obodo store na `dst` pointer.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Na-arụ ọrụ na-ebugharị site na pointer `src` Achọghị ịkọwapụta akara aka.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Anamde a obodo store na `dst` pointer.
    /// The pointer adịghị chọrọ ka kwekọọ.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// - Alaghachi na square mgbọrọgwụ nke ihe `f32`
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// - Alaghachi na square mgbọrọgwụ nke ihe `f64`
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Jụrụ otu `f32` na integer ike.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Welite `f64` na ike integer.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// - Alaghachi na-enweghị ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// - Alaghachi na-enweghị ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Laghachi cosine nke `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// - Alaghachi na cosine nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Jụrụ otu `f32` na `f32` ike.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Jụrụ otu `f64` na `f64` ike.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// - Alaghachi na exponential nke ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// - Alaghachi na exponential nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Alaghachi 2 akpọlite ndị ike nke `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Alaghachi 2 akpọlite ndị ike nke `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Alaghachi eke logarithm nke ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Alaghachi eke logarithm nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Alaghachi isi 10 logarithm nke ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Alaghachi isi 10 logarithm nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Alaghachi isi 2 logarithm nke ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Alaghachi isi 2 logarithm nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Alaghachi `a * b + c` maka `f32` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Alaghachi `a * b + c` maka `f64` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Laghachi kpamkpam uru nke `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Alaghachi ndị zuru uru nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// - Alaghachi na nke kacha nta nke abụọ `f32` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// - Alaghachi na nke kacha nta nke abụọ `f64` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Weghachite kacha nke abụọ `f32` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Weghachite kacha nke abụọ `f64` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Mbipụta ihe ịrịba ama si `y` ka `x` maka `f32` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Mbipụta ihe ịrịba ama si `y` ka `x` maka `f64` ụkpụrụ.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Alaghachi kasị integer erughị ma ọ bụ tụnyere ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Weghachite onu ogugu zuru oke na ihe kariri ma obu hara nhata `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Alaghachi kasị nta integer ukwuu karịa ma ọ bụ tụnyere ihe `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Laghachi obere ntanetịime karịa ma ọ bụ hara nhata `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Weghachi integer nke `f32`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// - Alaghachi na integer akụkụ nke ihe `f64`.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Alaghachi kacha nso integer na `f32`.
    /// Nwere ike bulie ihe na-enweghị isi ma ọ bụrụ na esemokwu a abụghị ọnụ ọgụgụ.
    pub fn rintf32(x: f32) -> f32;
    /// Alaghachi kacha nso integer na `f64`.
    /// Nwere ike bulie ihe na-enweghị isi ma ọ bụrụ na esemokwu a abụghị ọnụ ọgụgụ.
    pub fn rintf64(x: f64) -> f64;

    /// Alaghachi kacha nso integer na `f32`.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Alaghachi kacha nso integer na `f64`.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Alaghachi kacha nso integer na `f32`.Agba ọkara ụzọ ikpe n'ebe efu.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Alaghachi kacha nso integer na `f64`.Agba ọkara ụzọ ikpe n'ebe efu.
    ///
    /// Thedị nke a kwụsiri ike bụ
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ise n'elu mgbakwunye na-enye ohere optimizations dabeere algebraic iwu.
    /// Ka iche na ntinye ndị nwere oke.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Mwepu nke mmiri na-enye ohere njikarịcha dabere na iwu algebraic.
    /// Ka iche na ntinye ndị nwere oke.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Nkpako nke mmiri nke na-enye ohere njikarịcha dabere na iwu algebraic.
    /// Ka iche na ntinye ndị nwere oke.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ise n'elu nkewa na-enye ohere optimizations dabeere algebraic iwu.
    /// Ka iche na ntinye ndị nwere oke.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ise n'elu fọdụrụnụ na-enye ohere optimizations dabeere algebraic iwu.
    /// Ka iche na ntinye ndị nwere oke.
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Tọghatara na LLVM si fptoui/fptosi, nke nwere ike ịlaghachi undef maka ụkpụrụ si nso
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Nọsi'ike ka [`f32::to_int_unchecked`] na [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Alaghachi ọnụ ọgụgụ nke ibe n'ibe setịpụrụ ihe integer ụdị `T`
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `count_ones` usoro.
    /// Ọmụmaatụ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Alaghachi ọnụ ọgụgụ nke na-eduga unset ibe n'ibe (zeroes) na integer ụdị `T`.
    ///
    /// Versionsdị nsụgharị nke nsụgharị a dị na integer primitive site na usoro `leading_zeros`.
    /// Ọmụmaatụ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// An `x` na uru `0` ga-alaghachi na bit obosara nke `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Dị ka `ctlz`, mana enweghị nchekwa dịka ọ na-alaghachi `undef` mgbe enyere `x` na uru `0`.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Weghachite onu ogugu nke uzo (zeroes) nke di na `T`.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `trailing_zeros` usoro.
    /// Ọmụmaatụ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// An `x` na uru `0` ga-alaghachi na bit obosara nke `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Dị ka `cttz`, ma mmezi-nwedịrị ike ịta dị ka ọ na-alaghachi `undef` mgbe e nyere ihe `x` na uru `0`.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Ndakpọ nke bytes na integer ụdị `T`.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `swap_bytes` usoro.
    /// Ọmụmaatụ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Na-eweghachite bits na ụdị `T`.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `reverse_bits` usoro.
    /// Ọmụmaatụ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Anamde enyocha integer mgbakwunye.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `overflowing_add` usoro.
    /// Ọmụmaatụ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Anamde enyocha integer mwepu
    ///
    /// Versionsdị nke echekwara nke a dị na ntanetị oge niile site na usoro `overflowing_sub`.
    /// Ọmụmaatụ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Anamde enyocha integer multiplication
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `overflowing_mul` usoro.
    /// Ọmụmaatụ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Anamde kpọmkwem nkewa, dapụtara na undefined omume ebe `x % y != 0` ma ọ bụ `y == 0` ma ọ bụ `x == T::MIN && y == -1`
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Anamde ihe kpacharaghị nkewa, dapụtara na undefined omume ebe `y == 0` ma ọ bụ `x == T::MIN && y == -1`
    ///
    ///
    /// Ihe mkpuchi dị mma maka nke a dị na integer primitive site na usoro `checked_div`.
    /// Ọmụmaatụ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Weghachite ihe fọdụrụnụ nkewa a na-achọpụtaghị, na-ebute omume anaghị akọwa mgbe `y == 0` ma ọ bụ `x == T::MIN && y == -1`
    ///
    ///
    /// Nchekwa wrappers a intrinsic dị na integer primitives site na `checked_rem` usoro.
    /// Ọmụmaatụ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Anamde ihe kpacharaghị ekpe mgbanwe, na-akpata undefined omume mgbe `y < 0` ma ọ bụ `y >= N`, ebe N bụ obosara nke T na ibe n'ibe.
    ///
    ///
    /// Nchekwa wrappers a intrinsic dị na integer primitives site na `checked_shl` usoro.
    /// Ọmụmaatụ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Anamde ihe kpacharaghị nri mgbanwe, na-akpata undefined omume mgbe `y < 0` ma ọ bụ `y >= N`, ebe N bụ obosara nke T na ibe n'ibe.
    ///
    ///
    /// Nchekwa wrappers a intrinsic dị na integer primitives site na `checked_shr` usoro.
    /// Ọmụmaatụ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Alaghachi n'ihi ihe kpacharaghị mgbakwunye, dapụtara na undefined omume mgbe `x + y > T::MAX` ma ọ bụ `x + y < T::MIN`.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Weghachite nsonaazụ nke mwepu a na-enyochaghị, na-ebute omume anaghị akọwa mgbe `x - y > T::MAX` ma ọ bụ `x - y < T::MIN`.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Alaghachi n'ihi ihe kpacharaghị multiplication, dapụtara na undefined omume mgbe `x *y > T::MAX` ma ọ bụ `x* y < T::MIN`.
    ///
    ///
    /// Nke a intrinsic adịghị a ufọk ufene counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Anamde bugharia ekpe.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `rotate_left` usoro.
    /// Ọmụmaatụ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Anamde bugharia nri.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `rotate_right` usoro.
    /// Ọmụmaatụ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Alaghachi (a + b) mod 2 <sup>N,</sup> ebe N bụ obosara nke T na ibe n'ibe.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `wrapping_add` usoro.
    /// Ọmụmaatụ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Alaghachi (a, b) mod 2 <sup>N,</sup> ebe N bụ obosara nke T na ibe n'ibe.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `wrapping_sub` usoro.
    /// Ọmụmaatụ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Alaghachi (a * b) mod 2 <sup>N,</sup> ebe N bụ obosara nke T na ibe n'ibe.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `wrapping_mul` usoro.
    /// Ọmụmaatụ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, ide na ọnụọgụ ókè.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `saturating_add` usoro.
    /// Ọmụmaatụ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, ide na ọnụọgụ ókè.
    ///
    /// The Nọsi'ike nsụgharị nke a intrinsic dị na integer primitives site na `saturating_sub` usoro.
    /// Ọmụmaatụ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Alaghachi uru nke discriminant maka variant na 'v';
    /// ma ọ bụrụ na `T` nwere dịghị discriminant, laghachi `0`.
    ///
    /// The Nọsi'ike mbipute a intrinsic bụ [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Alaghachi ọnụ ọgụgụ nke variants nke ụdị `T` ikpu ka a `usize`;
    /// ma ọ bụrụ na `T` nwere dịghị variants, laghachi `0`.N'enweghị onye bi na variants ga-ọgugu.
    ///
    /// The na-ike-Nọsi'ike mbipute a intrinsic bụ [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Ihe Rust nke "try catch" nke na-akpo pointer `try_fn` na pointer data `data`.
    ///
    /// The atọ arumaru a ọrụ na-akpọ ma ọ bụrụ na a panic emee.
    /// Ọrụ a na-ewe data pointer na a pointer ka lekwasịrị-kpọmkwem wezụga ihe na e jidere.
    ///
    /// Maka ozi ọzọ ahụ compiler si iyi nakwa dị ka std si catch mmejuputa.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Na-ewepụta ụlọ ahịa `!nontemporal` dịka LLVM (lee docs ha).
    /// Eleghị anya ga-aghọ ike.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Lee akwụkwọ nke `<*const T>::offset_from` maka nkọwa.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Hụ akwụkwọ nke `<*const T>::guaranteed_eq` maka nkọwa.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Lee akwụkwọ nke `<*const T>::guaranteed_ne` maka nkọwa.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Igbunye na ide oge.Ghara-akpọ na Oge ojiri gaa.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ụfọdụ ọrụ na-kọwaa ebe a n'ihi na ha na mmadụ na mberede ọkọdọ mere dị na a modul na mụ.
// Hụ <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` nwekwara dara n'ime nke a, Atiya, ma ọ pụghị ọbọp n'ihi na ego na `T` na `U` nwere otu size.)
//

/// Akwụkwọ ndọrọ ego ma `ptr` na-ọma kwekọọ na-akwanyere `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Mbipụta `count *size_of::<T>()` bytes si `src` ka `dst`.The isi iyi na ebe kwesịrị* bụghị * yitewere.
///
/// N'ihi na n'ógbè ebe nchekwa nke nwere ike yitewere, iji [`copy`] kama.
///
/// `copy_nonoverlapping` bụ semantically Ẹkot C si [`memcpy`], ma na esemokwu iji swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// A na-akọwaghị omume ma ọ bụrụ na e mebie nke ọ bụla n'ime ọnọdụ ndị a:
///
/// * `src` ga-[valid] maka agụ nke `count * size_of::<T>()` bytes.
///
/// * `dst` ga-[valid] maka na-ede nke `count * size_of::<T>()` bytes.
///
/// * Ma `src` na `dst` ga-ekwesị kwekọọ.
///
/// * N'ógbè ebe nchekwa malite na `src` na a size of 'gụọ *
///   size_of: :<T>() 'Bytes kwesịrị *bụghị* yitewere na mpaghara nke ebe nchekwa na-amalite na `dst` na otu size.
///
/// Dị ka [`read`], `copy_nonoverlapping` emepụta a bitwise oyiri nke `T`, n'agbanyeghị ma `T` bụ [`Copy`].
/// Ọ bụrụ na `T` bụghị [`Copy`], iji *ma* ụkpụrụ na mpaghara malite na `*src` na region malite na `* dst` nwere ike [violate memory safety][read-ownership].
///
///
/// Rịba ama na ọbụlagodi ma ọ bụrụ na nza depụtaghachiri n'ụzọ dị irè (`` gụọ * size_of: :<T>() ') Bụ `0`, na pointers ga-abụghị Null na n'ụzọ kwesịrị ekwesị kwekọọ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Iji aka mejuputa [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Nkea niile ọcha nke `src` n'ime `dst`, na-ahapụ `src` efu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Gbaa mbọ hụ na `dst` nwere ezu ike jide niile `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Oku ka ewezuga ya bụ nchekwa mgbe niile n'ihi na `Vec` agaghị enyefe ihe karịrị `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` na-enweghị ịhapụ ọdịnaya ya.
///         // Anyị na-eme nke a ụzọ, na-ezere nsogbu bụrụ na ihe n'ihu ala panics.
///         src.set_len(0);
///
///         // The abụọ na mpaghara ike yitewere n'ihi mutable zoro emela utu aha, na abụọ dị iche iche vectors ike nwere otu ebe nchekwa.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Mara `dst` na ọ na-ejide ọdịnaya nke `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Igosi ndị a ndenye ego naanị na ọsọ oge
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ọ bụghị panicking na-codegen mmetụta nta.
        abort();
    }*/

    // SAFETY: nkwekọrịta nchekwa maka `copy_nonoverlapping` ga-abụrịrị
    // kwadoro site na nke bere.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Mbipụta `count * size_of::<T>()` bytes si `src` ka `dst`.The isi iyi na ebe ike yitewere.
///
/// Ọ bụrụ na isi mmalite na ebe njedebe *agatụbeghị*, [`copy_nonoverlapping`] enwere ike iji ya kama.
///
/// `copy` bụ ihe kwekọrọ na C's [`memmove`], mana iji gbanye esemokwu.
/// Iṅomi na-ewe ebe dị ka ma ọ bụrụ na ndị bytes e depụtaghachiri si `src` ka a nwa oge n'usoro wee depụtaghachiri si n'usoro na `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// A na-akọwaghị omume ma ọ bụrụ na e mebie nke ọ bụla n'ime ọnọdụ ndị a:
///
/// * `src` ga-[valid] maka agụ nke `count * size_of::<T>()` bytes.
///
/// * `dst` ga-[valid] maka na-ede nke `count * size_of::<T>()` bytes.
///
/// * Ma `src` na `dst` ga-ekwesị kwekọọ.
///
/// Dị ka [`read`], `copy` emepụta a bitwise oyiri nke `T`, n'agbanyeghị ma `T` bụ [`Copy`].
/// Ọ bụrụ na `T` bụghị [`Copy`], iji ma ọ bụ na ụkpụrụ na mpaghara malite na `*src` na region malite na `* dst` nwere ike [violate memory safety][read-ownership].
///
///
/// Rịba ama na ọbụlagodi ma ọ bụrụ na nza depụtaghachiri n'ụzọ dị irè (`` gụọ * size_of: :<T>() ') Bụ `0`, na pointers ga-abụghị Null na n'ụzọ kwesịrị ekwesị kwekọọ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Rụọ ọrụ nke ọma ike a Rust vector si nwedịrị ike ịta echekwa:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ga-n'ụzọ ziri ezi kwekọọ maka ya ụdị na-abụghị efu.
/// /// * `ptr` ga-nti maka agụ nke `elts` contiguous ihe nke ụdị `T`.
/// /// * Agaghị eji ihe ndị ahụ eme ihe mgbe ị kpọchara ọrụ a belụsọ na `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: Nzuzo anyi choro na isi iyi ya kwesiri,
///     // na `Vec::with_capacity` ana achi achi na anyị nwere usable ohere dee ha.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: Anyị ji ike a kee ya na mbụ,
///     // na `copy` gara aga amalitela ihe ndị a.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Igosi ndị a ndenye ego naanị na ọsọ oge
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ọ bụghị panicking na-codegen mmetụta nta.
        abort();
    }*/

    // MGBE: nkwekọrịta nchekwa maka `copy` ga-akwado onye na-akpọ oku.
    unsafe { copy(src, dst, count) }
}

/// Tent `count * size_of::<T>()` bytes nke na ebe nchekwa na-amalite na `dst` ka `val`.
///
/// `write_bytes` yiri C si [`memset`], ma na-esetịpụrụ `count * size_of::<T>()` bytes ka `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// A na-akọwaghị omume ma ọ bụrụ na e mebie nke ọ bụla n'ime ọnọdụ ndị a:
///
/// * `dst` ga-[valid] maka na-ede nke `count * size_of::<T>()` bytes.
///
/// * `dst` ga-n'ụzọ ziri ezi kwekọọ.
///
/// Ọzọkwa, nke bere ga-hụ na ede `count * size_of::<T>()` bytes na nyere n'ógbè ebe nchekwa na-arụpụta a nti uru nke `T`.
/// Iji a n'ógbè ebe nchekwa mesịa dị ka a `T` na e dere ihe ghara ịdị irè uru nke `T` bụ undefined omume.
///
/// Rịba ama na ọbụlagodi ma ọ bụrụ na nza depụtaghachiri nke ọma (`` gụọ * size_of: :<T>() ') Bụ `0`, na pointer ga-abụghị Null na n'ụzọ kwesịrị ekwesị kwekọọ.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Na-eke ihe ghara ịdị irè uru:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Leaks uru bara uru enwere site na iji nhicha null kọwaa `Box<T>`.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // N'oge a, na-eji ma ọ bụ na idobe `v` arụpụta undefined omume.
/// // drop(v); // ERROR
///
/// // Ọbụna-eri eri `v` "uses" ya, n'ihi ya bụ undefined omume.
/// // mem::forget(v); // ERROR
///
/// // N'ezie, `v` abaghị uru dịka usoro ndị na-adịghị agbanwe agbanwe si agbanwe agbanwe, yabụ * ọrụ ọ bụla na-emetụ ya bụ omume a na-akọwaghị.
/////
/// // ka v2 =v;//NR ERR.
///
/// unsafe {
///     // Ka anyị kama na-etinye na a nti uru
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ugbu a igbe ahụ dị mma
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // NCHEKWA: nchekwa nkwekọrịta maka `write_bytes` ga-kwadoro site na nke bere.
    unsafe { write_bytes(dst, val, count) }
}