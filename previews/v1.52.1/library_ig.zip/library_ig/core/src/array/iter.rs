//! Na-akọwapụta ihe nyocha nke `IntoIter` nwere maka nhazi.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A site-uru [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Nke a bụ usoro anyị na-emegharị.
    ///
    /// Ihe ndị nwere ndeksi `i` ebe `alive.start <= i < alive.end` amabeghị ma ọ bụ ndenye ndenye ziri ezi.
    /// Ihe ndị nwere Indices `i < alive.start` ma ọ bụ `i >= alive.end` amunyelarịrịrịrịrịrị na ha agaghị enwerịrị ike ọzọ!Ihe ndị ahụ nwụrụ anwụ nwedịrị ike ịnọ na steeti amaghị!
    ///
    ///
    /// Ya mere ndi agbanwe agbanwe bu:
    /// - `data[alive]` dị ndụ (yabụ nwere ezigbo ihe)
    /// - `data[..alive.start]` na `data[alive.end..]` anwụọla (yabụ agụọla ihe ndị ahụ ma agaghị emetụ ya aka ọzọ!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// The ọcha na `data` ahụ e amịghịkwa ma.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Emepụta ọhụrụ iterator n'elu nyere `array`.
    ///
    /// *Mara*: usoro a nwere ike ịdọrọ na future, mgbe [`IntoIterator` is implemented for arrays][array-into-iter] gasịrị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // The ụdị `value` bụ a `i32` ebe a, kama `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: Ntughari ebe a di ezi nchebe.Docs nke `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` na-ekwe nkwa nwere otu size na itinye n'ọnọdụ
        // > dị ka `T`.
        //
        // The Docs ọbụna na-egosi a transmute si otu n'usoro nke `MaybeUninit<T>` na otu n'usoro nke `T`.
        //
        //
        // Na na, a initialization afọ ndị invariants.

        // FIXME(LukasKalbertodt): jiri `mem::transmute` mee ihe ebe a, ozugbo ọ na-arụ ọrụ na mkpụrụ ndụ ihe nketa:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Tupu mgbe ahụ, anyị nwere ike iji `mem::transmute_copy` ike a bitwise oyiri ka a dị iche iche ụdị, mgbe ahụ chefuo `array` mere na ọ bụghị ama esịn.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Alaghachi ihe immutable slice of niile ọcha ahụ e amịghịkwa ma.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // NCHEKWA: Anyị maara na ihe niile dị n'eluigwe na ụwa n'ime `alive` na-ekwesị initialized.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Alaghachi a mutable slice of niile ọcha ahụ e amịghịkwa ma.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // NCHEKWA: Anyị maara na ihe niile dị n'eluigwe na ụwa n'ime `alive` na-ekwesị initialized.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Nweta eserese na-esote site n'ihu.
        //
        // Ịba `alive.start` site 1 ekwusi invariant banyere `alive`.
        // Otú ọ dị, n'ihi na mgbanwe a, maka a obere oge, ndụ mpaghara bụghị `data[alive]` ọzọ, ma `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Gụọ ihe ndị na mmewere si n'usoro.
            // NCHEKWA: `idx` bụ index n'ime mbụ "alive" n'ógbè
            // n'usoro.Agụ nke a mmewere n'aka na `data[idx]` Ẹda dị ka nwụrụ anwụ ugbu a (ie adịghị emetụ).
            // Ka `idx` bụ mmalite nke ndụ-mpaghara, na ndụ mpaghara bụ ugbu a `data[alive]` ọzọ, na-eweghachiri niile invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Nweta esote index si azụ.
        //
        // Ibelata `alive.end` site na 1 na-ekwusi ike na-enweghị atụ gbasara `alive`.
        // Agbanyeghị, n'ihi mgbanwe a, maka obere oge, mpaghara dị ndụ abụghị `data[alive]` ọzọ, mana `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Gụọ ihe ndị na mmewere si n'usoro.
            // NCHEKWA: `idx` bụ index n'ime mbụ "alive" n'ógbè
            // n'usoro.Agụ nke a mmewere n'aka na `data[idx]` Ẹda dị ka nwụrụ anwụ ugbu a (ie adịghị emetụ).
            // Dika `idx` bụ njedebe nke mpaghara ndụ, mpaghara dị ndụ bụ `data[alive]` ọzọ, weghachite ndị enweghị mgbanwe ọ bụla.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: Nke a dị mma: `as_mut_slice` laghachiri kpọmkwem na nkebi
        // nke ihe ebugharị na-apụbeghị ma na-anọgide na-adaba.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Agaghị agbanye mmiri n'ihi na ọ bụ onye na-agbanwe agbanwe `` live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// The iterator n'ezie akụkọ ziri ezi ogologo.
// Ọnụ ọgụgụ nke "alive" ihe (nke a ka ga-enye) bụ ogologo nke `alive` ahụ.
// Nke a nso decremented n'ogologo na ma `next` ma ọ bụ `next_back`.
// 1 na-agbadata ya mgbe niile na usoro ndị ahụ, mana ọ bụrụ na a laghachiri `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Cheta, anyị na-adịghị mkpa n'ezie ka dakọtara kpọmkwem otu ndụ nso, otú ahụ ka anyị nwere ike dị nnọọ mmepụta oyiri n'ime dechapụ 0 n'agbanyeghị ebe `self` bụ.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Mmepụta oyiri niile dị ndụ ọcha.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Dee a mmepụta oyiri n'ime ọhụrụ n'usoro, mgbe imelite ya ndụ nso.
            // Ọ bụrụ na cloning panics, anyị ga-n'ụzọ ziri ezi dobe gara aga ihe.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Naanị bipụta ihe ndị na-amịpụtabeghị: anyị enweghị ike ịnweta ihe ndị mepụtara ọzọ.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}