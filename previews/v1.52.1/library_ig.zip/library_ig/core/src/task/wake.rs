#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` na-enye ohere ka onye nrụpụta ọrụ ga-emepụta [`Waker`] nke na-enye omume edemede ahaziri.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// O nwere pointer data na [virtual function pointer table (vtable)][vtable] nke na-emezi omume nke `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A data pointer, nke nwere ike iji ya iji chekwaa aka ike data dị ka chọrọ site executor.
    /// Nke a nwere ike ịbụ ịmaatụ
    /// a ụdị-ehichapu pointer na `Arc` na-ejikọta ya na ọrụ.
    /// The uru nke a na ubi ego n'anya ebe niile na ọrụ na-akụkụ nke vtable dị ka ndị mbụ oke.
    ///
    data: *const (),
    /// Virtual ọrụ pointer table na customizes omume nke a waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Emepụta ọhụrụ `RawWaker` si nyere `data` pointer na `vtable`.
    ///
    /// Enwere ike iji pointer `data` iji chekwaa data aka ike dị ka onye chọrọ ya chọrọ.Nke a nwere ike ịbụ ịmaatụ
    /// a ụdị-ehichapu pointer na `Arc` na-ejikọta ya na ọrụ.
    /// Uru nke pointer a ga-agafe na ọrụ niile nke bụ akụkụ nke `vtable` dịka ntọala izizi.
    ///
    /// `vtable` na-ahazi omume nke `Waker` nke emepụtara site na `RawWaker`.
    /// Maka ọrụ ọ bụla na `Waker`, a ga-akpọ ọrụ metụtara ya na `vtable` nke mgbakwasị `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// A virtual ọrụ pointer table (vtable) na ezipụta omume nke a [`RawWaker`].
///
/// Pointer gafere na ọrụ niile n'ime vtable bụ `data` pointer si ihe [`RawWaker`] na-agbanye.
///
/// Ọrụ ndị dị n'ime ihe a bụ naanị ka akpọọ na `data` pointer nke ihe [`RawWaker`] rụrụ nke ọma site na ntinye [`RawWaker`].
/// Na-akpọ otu n'ime ndị dị na ọrụ site na iji ihe ọ bụla ọzọ `data` pointer ga-eme ka undefined omume.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// A ga-akpọ ọrụ a mgbe [`RawWaker`] nwere cloned, dịka mgbe [`Waker`] nke echekwara [`RawWaker`] na-akụ cloned.
    ///
    /// Mmejuputa oru a aghaghi ijigide ihe nile achoro maka ihe omuma a nke [`RawWaker`] na oru ndi ozo.
    /// Akpọ `wake` na dapụtara [`RawWaker`] kwesịrị ịrụpụta a wakeup nke otu ọrụ ahụ ga-e awoken site mbụ [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// A ga-akpọ ọrụ a mgbe akpọrọ `wake` na [`Waker`].
    /// Ọ ga-eteta ọrụ metụtara [`RawWaker`] a.
    ///
    /// Mmejuputa ọrụ a ga-eme ka hụ na hapụ ọ bụla ego na na-metụtara nke a atụ nke a [`RawWaker`] na metụtara ọrụ.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ọrụ a ga-akpọ mgbe `wake_by_ref` a na-akpọ na [`Waker`].
    /// Ọ ga-eteta ọrụ metụtara [`RawWaker`] a.
    ///
    /// Ọrụ a yiri `wake`, mana agaghị eripịa ihe ngosi data enyere.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// A na-akpọ ọrụ a mgbe [`RawWaker`] dara.
    ///
    /// Mmejuputa ọrụ a ga-eme ka hụ na hapụ ọ bụla ego na na-metụtara nke a atụ nke a [`RawWaker`] na metụtara ọrụ.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Mepụta `RawWakerVTable` ọhụrụ site na ọrụ `clone`, `wake`, `wake_by_ref` na `drop`.
    ///
    /// # `clone`
    ///
    /// A ga-akpọ ọrụ a mgbe [`RawWaker`] nwere cloned, dịka mgbe [`Waker`] nke echekwara [`RawWaker`] na-akụ cloned.
    ///
    /// Mmejuputa oru a aghaghi ijigide ihe nile achoro maka ihe omuma a nke [`RawWaker`] na oru ndi ozo.
    /// Akpọ `wake` na dapụtara [`RawWaker`] kwesịrị ịrụpụta a wakeup nke otu ọrụ ahụ ga-e awoken site mbụ [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// A ga-akpọ ọrụ a mgbe akpọrọ `wake` na [`Waker`].
    /// Ọ ga-eteta ọrụ metụtara [`RawWaker`] a.
    ///
    /// Mmejuputa ọrụ a ga-eme ka hụ na hapụ ọ bụla ego na na-metụtara nke a atụ nke a [`RawWaker`] na metụtara ọrụ.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ọrụ a ga-akpọ mgbe `wake_by_ref` a na-akpọ na [`Waker`].
    /// Ọ ga-eteta ọrụ metụtara [`RawWaker`] a.
    ///
    /// Ọrụ a yiri `wake`, mana agaghị eripịa ihe ngosi data enyere.
    ///
    /// # `drop`
    ///
    /// A na-akpọ ọrụ a mgbe [`RawWaker`] dara.
    ///
    /// Mmejuputa ọrụ a ga-eme ka hụ na hapụ ọ bụla ego na na-metụtara nke a atụ nke a [`RawWaker`] na metụtara ọrụ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` nke ọrụ asynchronous.
///
/// Ugbu a, `Context` naanị na-eje ozi na-enye ohere a `&Waker` nke ike-eji na-eteta na ugbu a ọrụ.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Gbaa mbọ hụ na anyị na-future-àmà megide ndịiche mgbanwe site na-ese na ndụ na-invariant (esemokwu-ọkwá ndụ bụ contravariant mgbe laghachi-ọkwá ndụ bụ covariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Mepụta `Context` ọhụrụ site na `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Laghachi na `Waker` maka ọrụ ugbu a.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` bụ aka maka iteta ọrụ site na ịgwa onye ga-eme ya na ọ dịla njikere ịgba ọsọ.
///
/// Ihe aka a na-ekpuchi ihe atụ [`RawWaker`], nke na-akọwapụta omume ịmụrụ anya nke onye na-eme ihe.
///
///
/// Achụ nta [`Clone`], [`Send`], na [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Bilie ọrụ metụtara na `Waker` a.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // The n'ezie wakeup oku na-n'inyefe site a virtual ọrụ oku mmejuputa nke a na-egosipụta ya site na executor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Unu akpọkwala `drop`-na waker ga gwusia site `wake`.
        crate::mem::forget(self);

        // SAFETY: Nke a dị mma n'ihi na `Waker::from_raw` bụ naanị ụzọ
        // iji malite `wake` na `data` chọrọ onye ọrụ iji kweta na nkwekọrịta `RawWaker` kwadoro.
        //
        unsafe { (wake)(data) };
    }

    /// Kulie ozi metụtara na a `Waker` enweghị irepịa `Waker`.
    ///
    /// Nke a yiri `wake`, mana enwere ike ọ gaghị adị obere na nke ahụ `Waker` nwere.
    /// Ekwesịrị ịhọrọ usoro a iji kpọọ `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // The n'ezie wakeup oku na-n'inyefe site a virtual ọrụ oku mmejuputa nke a na-egosipụta ya site na executor.
        //

        // SAFETY: lee `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Laghachi `true` ma ọ bụrụ na `Waker` a na `Waker` ọzọ ebilitela otu ọrụ.
    ///
    /// Ọrụ a na-arụ ọrụ na ntọala kachasị mma, ma nwee ike ịghaghachi ụgha ọbụlagodi mgbe ndị Waker ga-akpọte otu ọrụ ahụ.
    /// Otú ọ dị, ọ bụrụ na ọrụ a na-alaghachikwuru `true`, ọ na-ekwe nkwa na 'Waker`s ga-akpọte otu ọrụ.
    ///
    /// Ọrụ a bụ isi maka ebumnuche njikarịcha.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Mepụta `Waker` ọhụrụ site na [`RawWaker`].
    ///
    /// Nke omume nke laghachi `Waker` na-undefined ma ọ bụrụ na nkwekọrịta kọwaa ['RawWaker`]' s na ['RawWakerVTable`]' s akwụkwọ na-adịghị kwadoro.
    ///
    /// Ya mere, usoro a enweghị nchebe.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: Nke a dị mma n'ihi na `Waker::from_raw` bụ naanị ụzọ
            // ka initialize `clone` na `data` chọrọ ka onye ọrụ na-ekweta na nkwekọrịta nke [`RawWaker`] na-kwadoro.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: Nke a dị mma n'ihi na `Waker::from_raw` bụ naanị ụzọ
        // ka initialize `drop` na `data` chọrọ ka onye ọrụ na-ekweta na nkwekọrịta nke `RawWaker` na-kwadoro.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}