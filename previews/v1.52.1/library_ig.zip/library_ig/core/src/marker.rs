//! Oge ochie traits na ụdị na-anọchite anya isi Njirimara nke ụdị.
//!
//! Rust ụdị nwere ike nkewa dị iche iche bara uru n'ụzọ dị ka ha intrinsic Njirimara.
//! A na-egosipụta ọkwa ọkwa ndị a dị ka traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Ụdị na ike ga-agafere gafee eri ókè.
///
/// Nke a trait na-akpaghị aka na-emejuputa atumatu mgbe compiler ekpebi na ọ bụ ihe kwesịrị ekwesị.
///
/// Otu ihe atụ nke a na-abụghị `Send` ụdị bụ akwụkwọ-agụta pointer [`rc::Rc`][`Rc`].
/// Ọ bụrụ na abụọ eri anwa mmepụta oyiri ['Rc`] s na mgbe otu akwụkwọ-gua uru, ha nwere ike na-agbalị imelite akwụkwọ ọnụ n'otu oge, nke bụ [undefined behavior][ub] n'ihi [`Rc`] adịghị eji atọm arụmọrụ.
///
/// Ya na nwa nwanne nna [`sync::Arc`][arc] eme iji atọm arụmọrụ (ịba ụfọdụ efefe) ma si otú a `Send`.
///
/// Lee [the Nomicon](../../nomicon/send-and-sync.html) maka nkọwa ndị ọzọ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Ụdị na a mgbe nile na-size mara na ide oge.
///
/// All ụdị kwa nwere ihe isịne agbụ nke `Sized`.The pụrụ iche syntax `?Sized` nwere ike iji na-ewepụ a agbụ ma ọ bụrụ na ọ na-ekwesịghị ekwesị.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//njehie: sized na-adịghị emejuputa maka [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// The otu iche bụ isịne `Self` ụdị a trait.
/// A trait anaghị nwere ihe isịne `Sized` agbụ dị ka nke a bụ na-emegide [trait ihe] s ebe, site definition, na trait kwesịrị ọrụ na ihe niile kwere omume implementors, ma si otú nwere ike ịbụ ọ bụla size.
///
///
/// Agbanyeghị na Rust ga-ahapụ gị ka ị kee `Sized` na trait, ịgaghị enwe ike iji ya mepụta ihe trait ma emechaa:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ka y: &dyn Ogwe= &Impl;//njehie: na trait `Bar` enweghị ike ime n'ime ihe
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // maka an-ihe atụ, nke na-achọ na `[T]: !Default` enwe evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Ụdị na ike "unsized" ka a dynamically-sized ụdị.
///
/// Ka ihe atụ, sized n'usoro ụdị `[i8; 2]` implements `Unsize<[i8]>` na `Unsize<dyn fmt::Debug>`.
///
/// All implementations nke `Unsize` na-nyere na-akpaghị aka site na compiler.
///
/// `Unsize` na-emejuputa atumatu maka:
///
/// - `[T; N]` bụ `Unsize<[T]>`
/// - `T` bụ `Unsize<dyn Trait>` mgbe `T: Trait`
/// - `Foo<..., T, ...>` bụ `Unsize<Foo<..., U, ...>>` ma ọ bụrụ na:
///   - `T: Unsize<U>`
///   - Foo bu ihe owuwu
///   - Naanị mpaghara ikpeazụ nke `Foo` nwere ụdị metụtara `T`
///   - `T` abụghị akụkụ nke ụdị ọ bụla ọzọ ubi
///   - `Bar<T>: Unsize<Bar<U>>`, ma ọ bụrụ na ndị ikpeazụ ubi nke `Foo` nwere ụdị `Bar<T>`
///
/// `Unsize` a na-eji na [`ops::CoerceUnsized`] na-ekwe ka "user-defined" containers dị ka [`Rc`] nwere dynamically-sized ụdị.
/// Hụ [DST coercion RFC][RFC982] na [the nomicon entry on coercion][nomicon-coerce] maka nkọwa ndị ọzọ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Chọrọ trait maka constants eji na ụkpụrụ ọkụ.
///
/// Ụdị ọ bụla na-erite `PartialEq` akpaghị aka implements a trait, * n'agbanyeghị nke ma ya ụdị-kwa mejuputa `Eq`.
///
/// Ọ bụrụ na ihe `const` nwere ụdị ụfọdụ nke anaghị etinye trait a, ụdị ahụ ma (1.) anaghị etinye `PartialEq` (nke pụtara na oge niile agaghị enye usoro ntụnyere ahụ, nke usoro akara koodu chere dị), ma ọ bụ (2.) ọ na-emejuputa *nke ya* version of `PartialEq` (nke anyị iche adịghị ekwekọ a bughi-hara nhata tụnyere).
///
///
/// Na nke ọ bụla n'ime ihe atụ abụọ dị n'elu, anyị na-ajụ ojiji nke ihe dị otú a mgbe niile na egwuregwu egwuregwu.
///
/// Hụkwa [structural match RFC][RFC1445], na [issue 63438] nke kpaliri ịkwaga site na njiri mara njiri mara trait a.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Chọrọ trait maka constants eji na ụkpụrụ ọkụ.
///
/// Ụdị ọ bụla na-erite `Eq` akpaghị aka implements a trait, * n'agbanyeghị nke ma ya ụdị parameters mejuputa `Eq`.
///
/// Nke a bụ a hack na-arụ ọrụ na gburugburu a mmachi anyị ụdị usoro.
///
/// # Background
///
/// Anyị chọrọ na-achọ ka ụdị nke consts eji na ụkpụrụ ọkụ nwere àgwà `#[derive(PartialEq, Eq)]`.
///
/// Na a karịa ezigbo ụwa, anyị nwere ike ịlele ahụ a chọrọ site nnọọ achọpụta na nyere ụdị achụ nta ma ndị `StructuralPartialEq` trait * na ndị `Eq` trait.
/// Agbanyeghị, ịnwere ike ịnwe ADT nke *eme*`derive(PartialEq, Eq)`, ma bụrụkwa okwu anyị chọrọ ka onye nchịkọta ahụ nabata, mana ụdị mgbe niile anaghị emejuputa `Eq`.
///
/// Ya bụ, a ikpe dị ka nke a:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (The nsogbu na n'elu koodu bụ na `Wrap<fn(&())>` anaghị mejuputa `PartialEq`, ma ọ bụ `Eq`, n'ihi na 'maka <' a> fn(&'a _)` does not implement those traits.)
///
/// Ya mere, anyị na-apụghị ịdabere na ghọgbuo ego maka `StructuralPartialEq` na mere `Eq`.
///
/// Dị ka a hack ọrụ gburugburu a, anyị na-eji abụọ dị iche iche traits agbara site ọ bụla nke abụọ na-erite (`#[derive(PartialEq)]` na `#[derive(Eq)]`) na ego na ha abụọ bụ ugbu dị ka akụkụ nke bughi-egwuregwu atule.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Whosedị nke ụkpụrụ ha nwere ike ịmegharị naanị site na i copomi bits.
///
/// Site ndabara, agbanwe bindings nwere 'kwapụ semantics.'Yabụ:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` abanyela na `y`, yabụ enweghị ike iji ya
///
/// // println! ("{: ?}", x);//njehie: ojiji nke kpaliri uru
/// ```
///
/// Otú ọ dị, ọ bụrụ na a ụdị achụ nta `Copy`, ọ kama nwere 'idetuo semantics':
///
/// ```
/// // Anyị nwere ike na-erite a `Copy` mmejuputa.
/// // `Clone` bụkwa chọrọ, dị ka ọ bụ a supertrait nke `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` bụ a oyiri nke `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ọ dị mkpa iburu n'obi na ndị a na-atụ abụọ, naanị ihe dị iche bụ ma ị na-ekwe ka ohere `x` mgbe ọrụ ahụ.
/// N'okpuru enyeghachi ya okpukpu anọ, ma otu ma a aga pụrụ ịkpata ibe n'ibe na-depụtaghachiri na ebe nchekwa, ọ bụ ezie na nke a na-mgbe ụfọdụ kachasị pụọ.
///
/// ## Kedụ ka m ga-esi mejuputa `Copy`?
///
/// E nwere ụzọ abụọ iji mejuputa `Copy` gị ụdị.The mfe bụ iji `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// I nwekwara ike ime eme `Copy` na `Clone` aka:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// E nwere obere ihe dị iche n'etiti abụọ: na `derive` atụmatụ ga-etinye a `Copy` agbụ na ụdị kwa, nke a na-bụghị mgbe niile chọrọ.
///
/// ## Gịnị bụ ihe dị iche n'etiti `Copy` na `Clone`?
///
/// Mbipụta eme kpam kpam, n'ihi na ihe atụ dị ka akụkụ nke ihe omume `y = x`.Omume nke `Copy` abụghị nnukwu ibu;ọ bụ mgbe niile a dị mfe bit-maara ihe oyiri.
///
/// Cloning bụ ihe doro anya ihe, `x.clone()`.Mmejuputa [`Clone`] nwere ike inye ọ bụla ụdị-kpọmkwem omume dị mkpa ka e nwee ụkpụrụ n'enweghị nsogbu.
/// Ka ihe atụ, mmejuputa [`Clone`] maka [`String`] kwesịrị iṅomi kapịrị ọnụ-ka eriri echekwa na obo.
/// A mfe bitwise oyiri nke [`String`] ụkpụrụ ga nanị idetuo pointer, na-eduga a abụọ free ala akara.
/// Maka nke a, [`String`] bụ [`Clone`] mana ọ bụghị `Copy`.
///
/// [`Clone`] bụ a supertrait nke `Copy`, mere ihe niile nke bụ `Copy` ga-mejuputa [`Clone`].
/// Ọ bụrụ na a ụdị bụ `Copy` mgbe ya [`Clone`] mmejuputa naanị chọrọ ịlaghachi `*self` (ịhụ atụ n'elu).
///
/// ## Mgbe ike m ụdị abụ `Copy`?
///
/// A ụdị nwere ike ime eme `Copy` ma ọ bụrụ na niile nke ya mmiri mejuputa `Copy`.Ka ihe atụ, a struct nwere ike ịbụ `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Nhazi nwere ike ịbụ `Copy`, na [`i32`] bụ `Copy`, yabụ `Point` tozuru oke ịbụ `Copy`.
/// Site iche, tụlee
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// The struct `PointList` ike mejuputa `Copy`, n'ihi [`Vec<T>`] bụghị `Copy`.Ọ bụrụ na anyị na-agbali iji na-erite a `Copy` mmejuputa iwu, anyị ga-enweta ihe njehie:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Nnwekọrịta zoro (`&T`) nwekwara `Copy`, otú a ụdị nwere ike ịbụ `Copy`, ọbụna mgbe o nwere na-akọrọ zoro nke ụdị `T` na-*bụghị*`Copy`.
/// Tụlee struct, nke nwere ike ime eme `Copy`, n'ihi na ọ na-esetịpụ a *na-akọrọ akwụkwọ* ka anyị na-abụghị `Copy` ụdị `PointList` si n'elu:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Mgbe *enweghị ike* ụdị m bụ `Copy`?
///
/// Ụfọdụ ụdị ike-depụtaghachiri n'enweghị nsogbu.Ka ihe atụ, a na-edegharị `&mut T` ga ịmepụta otu aliased mutable akwụkwọ.
/// Iomi [`String`] ga-eme oyiri ọrụ maka ijikwa ihe nchekwa '' String`], na-eduga na ọnye abụọ.
///
/// Generalizing ikpeazụ ikpe, ụdị ọ bụla mmejuputa [`Drop`] nwere ike ịbụ `Copy`, n'ihi na ọ na-ijikwa ụfọdụ akụ e wezụga ya [`size_of::<T>`] bytes.
///
/// Ọ bụrụ na ị na-agbalị ime eme `Copy` on a struct ma ọ bụ enum nwere ndị na-abụghị `Copy` data, ị ga-njehie [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Mgbe * ga m ụdị abụ `Copy`?
///
/// N'ikwu ya n'ozuzu, ọ bụrụ na gị ụdị _can_ mejuputa `Copy`, ọ kwesịrị.
/// Buru n'uche na ọ na mmejuputa `Copy` bụ akụkụ nke ọha na eze API gị ụdị.
/// Ọ bụrụ na ụdị wee ghọọ ndị na-abụghị `Copy` na future, ọ pụrụ ịbụ ihe amamihe dị na wepụ `Copy` mmejuputa iwu ugbu a, iji zere a na-agbasa API mgbanwe.
///
/// ## Agbakwunyere na mmejuputa iwu
///
/// Na mgbakwunye na [implementors listed below][impls], ndị na-esonụ ụdị nwekwara mejuputa `Copy`:
///
/// * Itemdị ihe ọrụ (ya bụ, ụdị dị iche iche akọwapụtara maka ọrụ ọ bụla)
/// * Podị pointer na-arụ ọrụ (eg, `fn() -> i32`)
/// * Hazienụ ụdị, maka niile nha, ma ọ bụrụ na ihe ụdị nwekwara implements `Copy` (eg, `[i32; 123456]`)
/// * Tuple ụdị, ma ọ bụrụ na onye ọ bụla akụrụngwa nwekwara implements `Copy` (eg, `()`, `(i32, bool)`)
/// * Mmechi ụdị, ma ọ bụrụ na ha weghara dịghị uru site na gburugburu ebe obibi ma ọ bụ ma ọ bụrụ na ndị nile dị otú weghaara ụkpụrụ mejuputa `Copy` onwe ha.
///   Cheta na variables weghaara akọrọ akwụkwọ mgbe niile mejuputa `Copy` (ọbụna ma ọ bụrụ na ndị referent adịghị), mgbe variables weghaara mutable akwụkwọ mgbe mejuputa `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Nke a na-enye ohere na-edegharị a ụdị nke na-adịghị mejuputa `Copy` n'ihi adịghị enwe afọ ojuju ná ndụ ókè (edegharị `A<'_>` mgbe naanị `A<'static>: Copy` na `A<'_>: Clone`).
// Anyị nwere àgwà a n'ebe a n'ihi na ugbu a bụ naanị n'ihi na e nwere nnọọ ole na ole ẹdude specializations on `Copy` na ugbua adị na ọkọlọtọ Ọbá akwụkwọ, na e nweghị ụzọ ka n'enweghị nwere nke a bụ omume ugbu a.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Erite nnukwu amụba ihe impl nke trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Ụdị nke na ọ bụ nchebe na ike zoro n'etiti eri.
///
/// Nke a trait na-akpaghị aka na-emejuputa atumatu mgbe compiler ekpebi na ọ bụ ihe kwesịrị ekwesị.
///
/// The kpọmkwem definition bụ: a ụdị `T` bụ [`Sync`] ma ọ bụrụ na naanị ma ọ bụrụ na `&T` bụ [`Send`].
/// Ndị ọzọ okwu, ma ọ bụrụ na ọ dịghị ekwe omume nke [undefined behavior][ub] (gụnyere data agbụrụ) mgbe agafe `&T` zoro n'etiti eri.
///
/// Dị ka onye ga na-atụ anya, oge ochie na ụdị dị ka [`u8`] na [`f64`] niile [`Sync`], na ndị dị mfe nchịkọta ụdị nwere ha, dị ka tuples, structs na enums.
/// More ihe atụ nke isi [`Sync`] ụdị gụnyere "immutable" ụdị dị ka `&T`, na ndị na mfe ketara mutability, dị ka [`Box<T>`][box], [`Vec<T>`][vec] na ọtụtụ ndị ọzọ collection ụdị.
///
/// (Usoro ọnyà ga-abụ [`Sync`] ka akpa ha bụrụ '' Sync`].)
///
/// A dịtụ ijuanya n'ihi definition bụ na `&mut T` bụ `Sync` (ma ọ bụrụ na `T` bụ `Sync`) n'agbanyeghị na o yiri ka na pụrụ inye unsynchronized mutation.
/// The atọ bụ na a mutable akwụkwọ n'azụ a na-akọrọ akwụkwọ (ya bụ, `& &mut T`) na-agụ-na-, dị ka ma ọ bụrụ na ọ bụ ndị a `& &T`.
/// N'ihi ya ọ dịghị ize ndụ nke a data agbụrụ.
///
/// Ụdị ndị na-adịghị `Sync` bụ ndị nwere "interior mutability" na a na-abụghị eri-mma n'ụdị, ndị dị ka [`Cell`][cell] na [`RefCell`][refcell].
/// Typesdị ndị a na-enye ohere maka ngbanwe nke ọdịnaya ha ọbụna site na ntụgharị, nkere aha.
/// Ka ihe atụ na-`set` usoro on [`Cell<T>`][cell] ewe `&self`, n'ihi ya, ọ na-achọ naanị a na-akọrọ akwụkwọ [`&Cell<T>`][cell].
/// The usoro anamde dịghị mmekọrịta, si otú [`Cell`][cell] nwere ike ịbụ `Sync`.
///
/// Ihe atụ ọzọ nke a na-abụghị `Sync` ụdị bụ akwụkwọ-agụta pointer [`Rc`][rc].
/// N'inye nkọwa ọ bụla [`&Rc<T>`][rc], ị nwere ike mmepụta oyiri [`Rc<T>`][rc] ọhụrụ, na-agbanwe ntụgharị ederede na ụzọ na-abụghị atomic.
///
/// N'ihi na mgbe na mgbe otu onye na-eme mkpa eri-mma n'ime ime mutability, Rust enye [atomic data types], nakwa dị ka doro kpochidoro via [`sync::Mutex`][mutex] na [`sync::RwLock`][rwlock].
/// Ndị a na ụdị hụ na ihe ọ bụla mutation ike akpata data agbụrụ, n'ihi ya ụdị ndị `Sync`.
/// N'otu aka ahụ, [`sync::Arc`][arc] enye a na eri-mma analogue nke [`Rc`][rc].
///
/// Ọ bụla na ụdị na ime mutability ga-eji [`cell::UnsafeCell`][unsafecell] fụchie gburugburu value(s) nke ike-mutated site a na-akọrọ akwụkwọ.
/// Ịghara-eme nke a bụ [undefined behavior][ub].
/// Ka ihe atụ, ['transmute`][transmute]-ing si `&T` ka `&mut T` bụ ghara ịdị irè.
///
/// Lee [the Nomicon][nomicon-send-and-sync] maka nkọwa ndị ọzọ banyere `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ozugbo support ịgbakwunye ndetu na `rustc_on_unimplemented` ala na beta, na ọ e akp elele ma a mmechi bụ n'ebe ọ bụla chọrọ yinye, ịgbatị ya dị ka ndị dị otú ahụ (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Efu-sized ụdị eji akara ihe na "act like" ha nwere a `T`.
///
/// Agbakwunye a `PhantomData<T>` ubi gị ụdị agwa compiler na gị ụdị-eme dị ka ọ bụ ezie na ọ na-echekwa a uru nke ụdị `T`, ọ bụ ezie na ọ na-eme n'ezie.
/// Nke a na-eji ozi mgbe Mgbakọ ụfọdụ nchekwa Njirimara.
///
/// Maka nkọwa miri emi nke otu esi eji `PhantomData<T>`, biko lee [the Nomicon](../../nomicon/phantom-data.html).
///
/// # A ghastly dee 👻👻👻
///
/// Ọ bụ ezie na ha abụọ nwere aha ndị na-atụ ụjọ, `PhantomData` na 'ụdị phantom' nwere njikọ, mana ọ bụghị otu.A phantom ụdị oke bụ nanị a ụdị oke nke a na-agaghị eji.
/// Na Rust, a na-akpatakarị na compiler ntamu, na ngwọta bụ tinye a "dummy" were site n'ụzọ nke `PhantomData`.
///
/// # Examples
///
/// ## Ejibeghi ndụ parameters
///
/// Ikekwe ihe eji eme ihe maka `PhantomData` bụ ihe eji arụ ọrụ nke enweghị ndụ ọfụma, nke a na-abụkarị akụkụ nke koodu anaghị echedo.
/// Ka ihe atụ, ebe a bụ a struct `Slice` na nwere ihe abụọ pointers nke ụdị `*const T`, presumably-atụ n'ime otu n'usoro ebe:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ebumnuche bụ na isi data bụ nanị nti maka ndụ `'a`, otú `Slice` ekwesịghị ndụ karịa `'a`.
/// Otú ọ dị, nke a nzube na-adịghị owụt ke koodu, ebe ọ bụ na e nweghị nwaanyị nke ndụ `'a` na ya mere ọ na-adịghị anya ihe data ya na-emetụta.
/// Anyị nwere ike idozi nke a site n'ịgwa compiler ime dị ka ma ọ bụrụ na ndị `Slice` struct ẹdude a akwụkwọ `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Nke a na-n'aka na-achọ ndị annotation `T: 'a`, na-egosi na ihe ọ bụla e zoro aka na `T` bụ nti n'elu ndụ `'a`.
///
/// Mgbe initializing a `Slice` ị nanị enye uru `PhantomData` ubi `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ejibeghi ụdị parameters
///
/// Ọ eme mgbe ụfọdụ na i nwere ejibeghi ụdị kwa nke na-egosi ihe ụdị data a struct bụ "tied" na, ọ bụ ezie na data bụghị ya na-dị na struct onwe ya.
/// Nke a bụ ihe atụ ebe nke a malitere na [FFI].
/// The mba ọzọ interface ojiji ịṅụ nke ụdị `*mut ()` na-ezo aka Rust ụkpụrụ nke dị iche iche.
/// Anyị soro Rust ụdị eji a phantom ụdị oke na struct `ExternalResource` nke eyiri a handle.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ownership na dobe ego
///
/// Agbakwụnye, a ubi nke ụdị `PhantomData<T>` na-egosi na gị na ụdị nwere data nke ụdị `T`.Nke a na n'aka na-egosi na mgbe gị ụdị na-ama esịn, ọ nwere ike idebe otu ma ọ bụ karịa ihe nke ụdị `T`.
/// Nke a nwere na-amị na Rust compiler si [drop check] analysis.
///
/// Ọ bụrụ na gị struct adịghị n'ezie *nke* na data nke ụdị `T`, ọ dị mma iji a akwụkwọ ụdị, dị ka `PhantomData<&'a T>` (ideally) ma ọ bụ `PhantomData<*const T>` (ma ọ bụrụ na ọ dịghị ndụ na-emetụta), ka ọ ghara igosi nwe.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-n'ime trait eji mee ihe iji gosi ụdị nke ndị agbụrụ enum na-akpa oke.
///
/// Nke a trait na-akpaghị aka na-emejuputa atumatu maka ọ bụla ụdị na-adịghị tinye ọ bụla di na [`mem::Discriminant`].
/// Ọ bụ **undefined omume** ka transmute n'etiti `DiscriminantKind::Discriminant` na `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// The ụdị nke discriminant, nke ga-igbo trait bounds chọrọ `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-esịtidem trait mee iji chọpụta ma a ụdị nwere bụla `UnsafeCell` internally, ma ọ bụghị site na indirection.
///
/// Nke a na-emetụta, n'ihi na ihe atụ, ma a `static` nke na ụdị na-enịm ke na-agụ-na-static ebe nchekwa ma ọ bụ writable static ebe nchekwa.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Ụdị nwere ike n'enweghị kpaliri mgbe a pinned.
///
/// Rust onwe ya enweghị echiche nke bụrụnụ ndị kwụ chịm ụdị, na weere Nkea (eg, site ọrụ ma ọ bụ [`mem::replace`]) mgbe niile na-adị mma.
///
/// The [`Pin`][Pin] ụdị a na-eji kama iji gbochie Nkea site na ụdị usoro.Pointers `P<T>` ọbọp na [`Pin<P<T>>`][Pin] fụchie apụghị kwapụrụ.
/// Lee [`pin` module] akwụkwọ maka ozi ndị ọzọ na pinning.
///
/// Mejuputa atumatu `Unpin` trait maka `T` abọli mmachibido nke pinning kwụsịrị ụdị, nke ahụ na-enye ohere na-akpụ akpụ `T` si [`Pin<P<T>>`][Pin] na ọrụ dị ka [`mem::replace`].
///
///
/// `Unpin` nwere enweghị ihe ọ na niile nke na-abụghị pinned data.
/// Karịsịa, [`mem::replace`] ji obi ụtọ na-akpali `!Unpin` data (ọ na-arụ ọrụ maka ihe ọ bụla `&mut T`, ọ bụghị naanị mgbe `T: Unpin`).
/// Otú ọ dị, i nwere ike iji [`mem::replace`] on data ọbọp n'ime a [`Pin<P<T>>`][Pin] n'ihi na ị nwere ike ghara inwe ndị `&mut T` gị mkpa n'ihi na, na *na* bụ ihe na-eme ka usoro ihe a na-arụ ọrụ.
///
/// Ya mere nke a, n'ihi na ihe atụ, nwere ike na-eme na ụdị mmejuputa `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Anyị kwesịrị a mutable akwụkwọ na-akpọ `mem::replace`.
/// // Anyị nwere ike ịnweta ntụgharị dị otú ahụ site na (implicitly) na-akpọ `Pin::deref_mut`, mana nke ahụ ga-ekwe omume n'ihi na `String` na-eme `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Nke a trait na-akpaghị aka na-emejuputa atumatu maka fọrọ nke nta ka ọ bụla ụdị.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Markdị akara akara nke anaghị etinye `Unpin` n'ọrụ.
///
/// Ọ bụrụ na a ụdị nwere a `PhantomPinned`, ọ ga-mejuputa `Unpin` ndabara.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ntinye nke `Copy` maka ụdị oge ochie.
///
/// Implementations na-apụghị kọwara Rust na-emejuputa atumatu na `traits::SelectionContext::copy_clone_conditions()` na `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Nnwekọrịta zoro nwere ike depụtaghachiri, ma mutable zoro *ike*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}