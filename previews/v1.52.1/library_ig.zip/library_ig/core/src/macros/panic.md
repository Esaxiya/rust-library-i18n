Panics nke ugbu a na eri.

Nke a na-enye ohere a usoro kwụsị ozugbo ma nye nzaghachi ka nke bere nke usoro ihe omume.
`panic!` ga-eji mgbe a mmemme esịmde ihe unrecoverable ala.

Nke a nnukwu bụ n'ụzọ zuru okè na-ekwu na ọnọdụ na atụ koodu na na ule.
`panic!` chiri anya kegide na `unwrap` usoro nke ma [`Option`][ounwrap] na [`Result`][runwrap] enums.
Ma implementations akpọ `panic!` mgbe ha na-atọrọ ka [`None`] ma ọ bụ [`Err`] olumba.

Mgbe na-eji `panic!()` i nwere ike dee a eriri payload, nke na-wuru iji [`format!`] syntax.
Na payload na-eji mgbe ịgbanye panic n'ime akpọ Rust eri, na-eme na eri ka panic kpamkpam.

The omume nke ndabara `std` hook, ie
koodu nke na-agba ozugbo mgbe akpọrọ panic, bụ ibipụta ozi nkwụnye ụgwọ na `stderr` yana ozi file/line/column nke oku `panic!()`.

Nwere ike kpagbuo panic hook na-eji [`std::panic::set_hook()`].
Inside na hook a panic nwere ike inweta dị ka a `&dyn Any + Send`, bụ nke nwere ma a `&str` ma ọ bụ `String` maka mgbe `panic!()` invocations.
Iji panic na a uru nke ọzọ ndị ọzọ ụdị, [`panic_any`] nwere ike ji mee.

[`Result`] enum na-abụkarị ihe ngwọta ka mma iji gbakee site na njehie karịa iji `panic!` macro.
Ekwesịrị iji nnukwu ihe a zere ịga n'ihu n'iji ụkpụrụ na-ezighi ezi, dịka site na isi mmalite.
Ihe ọmụma zuru ezu banyere njehie njikwa na-hụrụ na [book].

Lee nwekwara nnukwu [`compile_error!`], maka ịzụlite njehie n'oge chịkọtara.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Ntinye ugbu a

Ọ bụrụ na isi eri panics ọ ga chupu gị niile eri na-agwụ gị omume na koodu `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





