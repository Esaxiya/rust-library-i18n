//! Arụ ọrụ maka ịtụ na tụnyere.
//!
//! Nke a modul nwere dị iche iche ngwaọrụ nke iwu na-atụnyere ụkpụrụ.Na nchịkọta:
//!
//! * [`Eq`] na [`PartialEq`] bụ traits na-enye gị ohere ịkọwa ngụkọta na nha anya nha anya n'etiti ụkpụrụ, karị.
//! Imejuputa ha buru ibu na ndi oru `==` na `!=`.
//! * [`Ord`] na [`PartialOrd`] bụ traits na-ekwe ka ị na-akọwa ngụkọta na ele mmadụ anya n'ihu orderings n'etiti ụkpụrụ, karị.
//!
//! Imejuputa ha buru ibu na ndi oru `<`, `<=`, `>` na `>=`.
//! * [`Ordering`] bụ ihe enum laghachi site na isi ọrụ nke [`Ord`] na [`PartialOrd`], na-akọwa ihe ịtụ.
//! * [`Reverse`] bụ ihe owuwu nke na-enye gị ohere ịgbanwe usoro ịtụfe nke ọma.
//! * [`max`] na [`min`] bụ ọrụ na Mee anya nke [`Ord`] na-ekwe ka ị chọta karịa ma ọ bụ nke kacha nta nke abụọ ụkpụrụ.
//!
//! Maka nkọwa ndị ọzọ, lee akwụkwọ dị iche iche nke ihe ọ bụla na listi.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait maka hara nhata atụnyere nke bụ [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait a na-enye ohere maka ịha nha anya, maka ụdị ndị na-enweghị njikọ zuru oke.
/// Iji maa atụ, na nọmba nọmba sere ese `NaN != NaN`, yabụ ụdị esere ese na-eme `PartialEq` mana ọ bụghị [`trait@Eq`].
///
/// Chie, nke ịha nhata ga-(niile `a`, `b`, `c` nke ụdị `A`, `B`, `C`):
///
/// - **symmetric**: ma ọ bụrụ na `A: PartialEq<B>` na `B: PartialEq<A>`, mgbe ahụ,**'a==b`pụtara' b==a`**;na
///
/// - **Transitive**: ma ọ bụrụ na `A: PartialEq<B>` na `B: PartialEq<C>` na 'A:
///   NkeziEq<C>``, wee **''==b` na `b == c` pụtara 'a==c`**.
///
/// Rịba ama na anaghị amanye `B: PartialEq<A>` (symmetric) na `A: PartialEq<C>` (transitive) impls ka ọ dịrị, mana ihe ndị a achọrọ na-emetụta oge ọ bụla ha dị.
///
/// ## Derivable
///
/// Nke a trait ike ga-eji na `#[derive]`.Mgbe ``erite`d na structs, ihe abụọ dị nhatanha ma mpaghara niile hara nhata, na ahaghị nha ma ọ bụrụ na mpaghara ọ bụla ahaghị.Mgbe ``derive`d na enum, ụdị ọ bụla dị iche na ya onwe ya, ọ bụghị aha ndị ọzọ.
///
/// ## Kedụ ka m ga-esi mejuputa `PartialEq`?
///
/// `PartialEq` naanị achọ [`eq`] usoro na-emejuputa atumatu;[`ne`] kọwaa okwu nke ya ndabara.Ọ bụla ntuziaka mmejuputa [`ne`]*kwesịrị* na-asọpụrụ ndị na-achị na [`eq`] bụ a siri ike inverse nke [`ne`];ya bụ, `!(a == b)` ma ọ bụrụ na naanị ma ọ bụrụ na `a != b`.
///
/// Ntinye nke `PartialEq`, [`PartialOrd`] na [`Ord`] * ga-ekwenye na ibe ha.Ọ dị mfe ịme ka ha kwenye na mberede site na ị nweta ụfọdụ traits ma jiri aka mejuputa ndị ọzọ.
///
/// Ihe nlere dika ihe omuma maka ngalaba nke akwukwo abuo dika akwukwo dika ISBN ha, obu ezie na uzo di iche:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Olee otú m pụrụ tụnyere abụọ dị iche iche?
///
/// The ụdị i nwere ike iji tụnyere na-achịkwa 'PartialEq` si ụdị oke.
/// Dị ka ihe atụ, ka tweak anyị gara aga koodu a bit:
///
/// ```
/// // Na-enweta ngwa<BookFormat>==<BookFormat>atụnyere
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Mejuputa<Book>==<BookFormat>atụnyere
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Mejuputa<BookFormat>==<Book>atụnyere
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Site n'ịgbanwe `impl PartialEq for Book` ka `impl PartialEq<BookFormat> for Book`, anyị na-ekwe ka ``BookFormat`s tụnyere '' Book`s.
///
/// A tụnyere dị ka otu n'elu, nke leghaara ụfọdụ ubi nke struct, pụrụ ịdị ize ndụ.Ọ nwere ike ibute ngbaghara na-atụghị anya ya maka ihe achọrọ maka mmekọrita ele mmadụ anya n'ihu.
/// Iji maa atụ, ọ bụrụ na anyị edebe usoro nke `PartialEq<Book>` maka `BookFormat` ma tinye ntinye nke `PartialEq<Book>` maka `Book` (ma ọ bụ site na `#[derive]` ma ọ bụ site na ntuziaka site na ihe atụ mbụ) mgbe ahụ nsonaazụ ga-emebi transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Nke a na usoro ule `self` na `other` ji na-hà, na a na-eji site `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Nke a na usoro na-anwale maka `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Erite nnukwu amụba ihe impl nke trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait maka nha anya nha nke bụ [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Nke a pụtara, na na mgbakwunye na `a == b` na `a != b` ịbụ echesinụ inverses, na ịha nhata ga-(niile `a`, `b` na `c`):
///
/// - reflexive: `a == a`;
/// - symmetric: `a == b` pụtara `b == a`;na
/// - transitive: `a == b` na `b == c` pụtara `a == c`.
///
/// Nke a ihe onwunwe ike-enyocha site na compiler, ya mere `Eq` pụtara [`PartialEq`], na ọ dịghị mmezi ụzọ.
///
/// ## Derivable
///
/// Enwere ike iji trait a mee ihe na `#[derive]`.
/// Mgbe 'derive`d, n'ihi `Eq` nwere adịghị mmezi ụzọ, ọ bụ naanị ịgwa ndị compiler na nke a bụ ihe narị afọ ise tupu mmekọrita kama a ele mmadụ anya n'ihu narị afọ ise tupu mmekọrita.
///
/// Rịba ama na `derive` atụmatụ achọ ihe niile ubi na-`Eq`, nke a na ọ bụghị mgbe niile chọrọ.
///
/// ## Kedụ ka m ga-esi mejuputa `Eq`?
///
/// Ọ bụrụ na ịnweghị ike iji atụmatụ `derive`, kọwaa na ụdị gị na-eme `Eq`, nke enweghị usoro:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // a na-eji usoro a naanị site na#[nweta] iji kwupụta na akụkụ ọ bụla nke ụdị mejupụtara#[deriving] onwe ya, akụrụngwa na-eweta ugbu a pụtara ime nkwupụta a na-enweghị iji usoro na trait a fọrọ nke nta ka ọ ghara ikwe omume.
    //
    //
    // Agaghị eji aka mejuputa nke a.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Erite nnukwu amụba ihe impl nke trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: a na-eji ihe owuwu a naanị site na#[nweta]
// na-ekwu na ọ bụla akụrụngwa nke a ụdị achụ nta Eq.
//
// Nke a struct ga-egosi na ọrụ koodu.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// An `Ordering` bụ n'ihi nke a tụnyere n'etiti abụọ ụkpụrụ.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// An ịtụ ebe a tụnyere uru bụ ihe na-erughị ọzọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Ordertụ ebe tụnyere uru bara uru na nke ọzọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// An ịtụ ebe a tụnyere uru dị ukwuu karịa ọzọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Alaghachi `true` ma ọ bụrụ na ịtụ bụ `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Alaghachi `true` ma ọ bụrụ na ịtụ abụghị `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Laghachi `true` ma ọ bụrụ na ịtụ ịtụ bụ ụdị `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Laghachi `true` ma ọ bụrụ na ịtụ ịtụ bụ ụdị `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Weghachite `true` ma ọ bụrụ na ịtụ ịtụ bụ ụdị `Less` ma ọ bụ `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Alaghachi `true` ma ọ bụrụ na ịtụ bụ ma ndị `Greater` ma ọ bụ `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Ndakpọ nke `Ordering`.
    ///
    /// * `Less` bụrụ `Greater`.
    /// * `Greater` na-aghọ `Less`.
    /// * `Equal` na-aghọ `Equal`.
    ///
    /// # Examples
    ///
    /// Basic omume:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Usoro a nwere ike iji gbanwee ihe atụ:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // dozie usoro dị iche iche site na nke kachasị nta.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Agbụ abụọ ịtụ.
    ///
    /// Laghachi `self` mgbe ọ bụghị `Equal`.Ma ọ bụghị laghachi `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chains ịtụ na nyere ọrụ.
    ///
    /// Laghachi `self` mgbe ọ bụghị `Equal`.
    /// Ma ọ bụghị na-akpọ `f` na-alaghachikwuru N'ihi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Ihe inyeaka maka nhazi usoro.
///
/// Ihe owuwu a bụ ihe inyeaka iji rụọ ọrụ dịka [`Vec::sort_by_key`] ma enwere ike iji ya gbanwee akụkụ nke igodo.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait maka ụdị na-etolite [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Usoro bụ usoro zuru ezu ma ọ bụrụ (ọ bụ maka `a`, `b` na `c`):
///
/// - ngụkọta na akpàràkpà: kpọmkwem otu nke `a < b`, `a == b` ma ọ bụ `a > b` bụ eziokwu;na
/// - transitive, `a < b` na `b < c` pụtara `a < c`.Otu ga-ejide maka `==` na `>`.
///
/// ## Derivable
///
/// Enwere ike iji trait a mee ihe na `#[derive]`.
/// Mgbe ``erite`d na structs, ọ ga-emepụta usoro [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) dabere na usoro nkwupụta elu na-ala nke ndị otu ahụ.
///
/// Mgbe `` na-enweta na enum, a na-enye ndị dị iche iche iwu site na usoro ịkpa oke ha na-elu ruo na ala.
///
/// ## Lexicographical tụnyere
///
/// Nkọwapụta lexicographical bụ ọrụ na njirimara ndị a:
///  - Ejiri usoro abụọ tụnyere ihe site na mmewere.
///  - Ihe mbu nke emegideritara na akowa usoro nke lexicographically pekariri ma obu kari nke ozo.
///  - Ọ bụrụ na otu usoro bụ a nganiihu nke ọzọ, ndị mkpumkpu usoro bụ lexicographically obere karịa ndị ọzọ.
///  - Ọ bụrụ na usoro abụọ nwere ihe ha nhata ma bụrụ otu ogologo, mgbe ahụ usoro ahụ ga-aha nha anya.
///  - Ihe efu usoro bụ lexicographically obere karịa ihe ọ bụla na-abụghị efu usoro.
///  - Abụọ efu usoro ndị lexicographically hà.
///
/// ## Olee otú m pụrụ mejuputa `Ord`?
///
/// `Ord` chọrọ ka ụdị ahụ bụrụkwa [`PartialOrd`] na [`Eq`] (nke chọrọ [`PartialEq`]).
///
/// Mgbe ahụ ị ga-esi kọwaa ihe mmejuputa iwu maka [`cmp`].Ị nwere ike na ọ bara uru iji [`cmp`] gị ụdị ubi.
///
/// Ntinye nke [`PartialEq`], [`PartialOrd`] na `Ord` * ga-ekwenye na ibe ha.
/// Nke ahụ bụ, `a.cmp(b) == Ordering::Equal` ma ọ bụrụ na naanị ma ọ bụrụ na `a == b` na `Some(a.cmp(b)) == a.partial_cmp(b)` niile `a` na `b`.
/// Ọ dị mfe mmadụ na mberede-eme ka ha na-ekwekọrịtaghị site aṅụrị ụfọdụ nke traits na aka mejuputa atumatu ndị ọzọ.
///
/// Nke a bụ ihe atụ ebe ịchọrọ ịhazi ndị mmadụ naanị elu, na-eleghara `id` na `name` anya:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Nke a na usoro na-alaghachikwuru ihe [`Ordering`] n'etiti `self` na `other`.
    ///
    /// Site mgbakọ ahụ, `self.cmp(&other)` laghachi na ịtụ abịa okwu `self <operator> other` ma ọ bụrụ na eziokwu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Tụnyere na-alaghachikwuru onye kacha abụọ ụkpụrụ.
    ///
    /// Weghachi arụmụka nke abụọ ma ọ bụrụ na ntụnyere na-ekpebi ha ka ha hara nhata.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Na-atụle ma weghachite opekempe nke ụkpụrụ abụọ.
    ///
    /// Alaghachi mbụ esemokwu ma ọ bụrụ na e jiri ya tụnyere na-ekpebi ka ha hà.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Machibido a bara uru a na-nkeji.
    ///
    /// Alaghachi `max` ma ọ bụrụ na `self` ukwuu `max`, na `min` ma ọ bụrụ na `self` bụ ihe na-erughị `min`.
    /// Ma ọ bụghị nke a laghachiri `self`.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Nweta macro na-ewepụta ihe nke trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait maka ụkpụrụ na a pụrụ iji tụnyere maka a ụdị-iji.
///
/// Ntụle ahụ ga-eju afọ, maka `a`, `b` na `c` niile:
///
/// - asymmetry: ma ọ bụrụ na `a < b` mgbe `!(a > b)`, nakwa dị ka `a > b` negosi `!(a < b)`;na
/// - transitivity: `a < b` na `b < c` pụtara `a < c`.Otu kwesịrị jide ma `==` na `>`.
///
/// Cheta na ndị a chọrọ pụtara na trait a ga-emejuputa atumatu symmetrically na transitively: ma ọ bụrụ na `T: PartialOrd<U>` na `U: PartialOrd<V>` mgbe `U: PartialOrd<T>` na 'T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Enwere ike iji trait a mee ihe na `#[derive]`.Mgbe 'derive`d on structs, ọ ga-emepụta a lexicographic ịtụ dabeere na n'elu-na-ala nkwupụta ka nke struct si òtù.
/// Mgbe `` na-enweta na enum, a na-enye ndị dị iche iche iwu site na usoro ịkpa oke ha na-elu ruo na ala.
///
/// ## Olee otú m pụrụ mejuputa `PartialOrd`?
///
/// `PartialOrd` naanị chọrọ mmejuputa usoro [`partial_cmp`], yana ndị ọzọ sitere na mmejuputa ndabara.
///
/// Otú ọ dị ọ na-anọgide na o kwere omume mejuputa ndị ọzọ iche iche maka ụdị nke na-adịghị a ngụkọta iji.
/// Iji maa atụ, maka nọmba na-ese n'elu mmiri, `NaN < 0 == false` na `NaN >= 0 == false` (cf.
/// IEEE 754-2008 ngalaba 5.11).
///
/// `PartialOrd` chọrọ ka ụdị gị bụrụ [`PartialEq`].
///
/// Ntinye nke [`PartialEq`], `PartialOrd` na [`Ord`] * ga-ekwenye na ibe ha.
/// Ọ dị mfe mmadụ na mberede-eme ka ha na-ekwekọrịtaghị site aṅụrị ụfọdụ nke traits na aka mejuputa atumatu ndị ọzọ.
///
/// Ọ bụrụ na gị na ụdị bụ [`Ord`], i nwere ike ime eme [`partial_cmp`] site na iji [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Ị nwekwara ike na ọ bara uru iji [`partial_cmp`] gị ụdị ubi.
/// Nke a bụ ihe atụ nke ụdị `Person` ndị nwere oghere `height` na-ese n'elu mmiri nke bụ naanị ubi a ga-eji mee ihe maka ịhazi:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Usoro a na-eweghachi usoro n'etiti ụkpụrụ `self` na `other` ma ọ bụrụ na ọ dị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Mgbe ntụnyere agaghị ekwe omume:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Usoro a na-anwale ihe na-erughị (maka `self` na `other`) ma ndị ọrụ `<` na-eji ya.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Nke a na usoro ule na-erughị ma ọ bụ hà (maka `self` na `other`) na a na-eji site na `<=` ọrụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Nke a na usoro na-anwale ukwuu karịa (maka `self` na `other`) na a na-eji site na `>` ọrụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Nke a na usoro na-anwale ukwuu karịa ma ọ bụ hà (maka `self` na `other`) na a na-eji site na `>=` ọrụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Erite nnukwu amụba ihe impl nke trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Na-atụle ma weghachite opekempe nke ụkpụrụ abụọ.
///
/// Alaghachi mbụ esemokwu ma ọ bụrụ na e jiri ya tụnyere na-ekpebi ka ha hà.
///
/// Internally na-eji utu aha ka [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Laghachi nke kacha nta nke abụọ ụkpụrụ na-akwanyere ndị kwuru kpọmkwem ọrụ ọrụ.
///
/// Alaghachi mbụ esemokwu ma ọ bụrụ na e jiri ya tụnyere na-ekpebi ka ha hà.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Weghachi mmewere nke na-enye opekempe uru site na ọrụ akọwapụtara.
///
/// Alaghachi mbụ esemokwu ma ọ bụrụ na e jiri ya tụnyere na-ekpebi ka ha hà.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Tụnyere na-alaghachikwuru onye kacha abụọ ụkpụrụ.
///
/// Weghachi arụmụka nke abụọ ma ọ bụrụ na ntụnyere na-ekpebi ha ka ha hara nhata.
///
/// Internally na-eji utu aha ka [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Weghachite ihe kachasị elu nke ụkpụrụ abụọ gbasara ọrụ nyocha akọwapụtara.
///
/// Weghachi arụmụka nke abụọ ma ọ bụrụ na ntụnyere na-ekpebi ha ka ha hara nhata.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Weghachite mmewere nke na-enye oke kachasị na ọrụ akọwapụtara.
///
/// Weghachi arụmụka nke abụọ ma ọ bụrụ na ntụnyere na-ekpebi ha ka ha hara nhata.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Mmejuputa PartialEq, Eq, PartialOrd na ORD maka oge ochie ụdị
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // The iji ebe a bụ ihe dị mkpa na-n'ịwa ọzọ ezigbo mgbakọ.
                    // Hụ <https://github.com/rust-lang/rust/issues/63758> maka ama ndị ọzọ.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Nkedo ihe dị na i8 na ịtụgharị ihe dị iche na ịtụ ahịa na-ewepụta nzukọ kacha mma.
            //
            // Lee <https://github.com/rust-lang/rust/issues/66780> maka ihe Ama.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool dị ka i8 laghachi 0 ma ọ bụ 1, yabụ ọdịiche enweghị ike ịbụ ihe ọ bụla
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &egosi

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}