//! Umengwụ ụkpụrụ na otu oge initialization nke static data.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// A cell nke ike-e dere na naanị otu ugboro.
///
/// N'adịghị ka `RefCell`, a `OnceCell` naanị-enye na-akọrọ `&T` zoro aka ya uru.
/// N'adịghị ka `Cell`, a `OnceCell` adịghị achọ na-edegharị ma ọ bụ dochie uru iji nweta ya.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: edere na otu oge.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Na-emepụta cell efu ọhụrụ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Ọkọkpọhi banyere isi uru.
    ///
    /// Alaghachi `None` ma ọ bụrụ na cell bụ ihe efu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // NCHEKWA: Safe ruru 'inner` si invariant
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Ọkọkpọhi mutable banyere isi uru.
    ///
    /// Alaghachi `None` ma ọ bụrụ na cell bụ ihe efu.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // Nchekwa: Nchekwa n'ihi na anyị nwere ohere pụrụ iche
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Setịpụrụ ọdịnaya nke cell na `value`.
    ///
    /// # Errors
    ///
    /// Nke a na usoro na-alaghachikwuru `Ok(())` ma ọ bụrụ na cell tọgbọ chakoo na `Err(value)` ma ọ bụrụ na ọ bụ zuru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // NCHEKWA: Safe n'ihi na anyị nwere ike ghara overlapping mutable agbaziri
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAFETY: Nke a bụ naanị ebe anyị debere oghere, enweghị agbụrụ
        // n'ihi reentrancy/concurrency kwere omume, anyị na-na na-enyocha na oghere bụ ugbu a `None`, otú a, dee ekwusi 'inner` si invariant.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Alụta ọdịnaya nke cell, initializing ya `f` ma ọ bụrụ na cell tọgbọ chakoo.
    ///
    /// # Panics
    ///
    /// Ọ bụrụ na `f` panics, na panic na-propagated na bere ubé, na cell-anọgide uninitialized.
    ///
    ///
    /// Ọ bụ ihe na njehie reentrantly initialize na cell site `f`.Ime otú apụta na a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Alụta ọdịnaya nke cell, initializing ya `f` ma ọ bụrụ na cell tọgbọ chakoo.
    /// Ọ bụrụ na ndị cell tọgbọ chakoo na `f` okpu, njehie a laghachi.
    ///
    /// # Panics
    ///
    /// Ọ bụrụ na `f` panics, na panic na-propagated na bere ubé, na cell-anọgide uninitialized.
    ///
    ///
    /// Ọ bụ ihe na njehie reentrantly initialize na cell site `f`.Ime otú apụta na a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Cheta na *Ụfọdụ* forms of reentrant initialization pụrụ iduga UB (lee `reentrant_init` ule).
        // M kwere na dị nnọọ wepụ a `assert`, mgbe idebe `set/get` ga-ụda, ma o yiri ka mma panic, kama ndopuyo iji agadi uru.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Na-erepịakwa sel ahụ, na-eweghachi uru a fụchiri afụchi.
    ///
    /// Laghachi `None` ma ọ bụrụ na cell dị efu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // N'ihi `into_inner` ewe `self` site uru, na compiler statically gosiri na ọ na-adịghị ugbu a biiri.
        // N'ihi ya, ọ bụ nchebe pụọ `Option<T>`.
        self.inner.into_inner()
    }

    /// Ewe uru na nke a `OnceCell`, akpụ akpụ ya azụ ihe uninitialized ala.
    ///
    /// Enweghị mmetụta na-alaghachikwuru `None` ma ọ bụrụ na ndị `OnceCell` bụghị e initialized.
    ///
    /// Safety na-ekwe nkwa site na-achọ a mutable akwụkwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// A uru nke a na-initialized ke akpa ohere.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   njikere initializing
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Emepụta ọhụrụ umengwụ uru na nyere initializing ọrụ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Magbuo nwale nke a umengwụ uru ma laghachi a banyere N'ihi.
    ///
    ///
    /// Nke a bụ Ẹkot `Deref` impl, ma ọ bụ Ụfọdụ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Emepụta ọhụrụ umengwụ uru iji `Default` ka initializing ọrụ.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}