//! Nke a bụ ihe esịtidem modul ji site ifmt!Oge ojiri gaa.Ndị a owuwu na-emitted ka static arrays ka precompile format urụk n'ihu nke oge.
//!
//! Nkọwa ndị a yiri nke `ct` ha, mana ha dị iche na enwere ike ekenye ha nke ọma ma bụrụ nke kachasị ntakịrị maka oge
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ekwe Omume alignments na ike ga-rịọrọ dị ka akụkụ nke a formatting agbasachaghị.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Na-egosi na ọdịnaya kwesịrị ekpe-kwekọọ.
    Left,
    /// Na-egosi na ọdịnaya kwesịrị ngụpụta.
    Right,
    /// Na-egosi na ọdịnaya kwesịrị center-kwekọọ.
    Center,
    /// Ọ dịghị itinye n'ọnọdụ e rịọrọ.
    Unknown,
}

/// Eji [width](https://doc.rust-lang.org/std/fmt/#width) na [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// E gosipụtara ọnụ ọgụgụ nkịtị, na-echekwa uru ahụ
    Is(usize),
    /// Kpọmkwem iji `$` na `*` syntaxes, na-echekwa na index n'ime `args`
    Param(usize),
    /// Akọwapụtaghị ya
    Implied,
}