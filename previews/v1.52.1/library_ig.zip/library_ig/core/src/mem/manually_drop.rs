use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A fụchie ka inhibit compiler si na-akpaghị aka na-akpọ 'T` si destructor.
/// Nke a fụchie bụ 0-na-eri.
///
/// `ManuallyDrop<T>` bụ n'okpuru otu layout optimizations ka `T`.
/// N'ihi ya, o nwere *dịghị mmetụta* na echiche na compiler eme banyere ya.
/// Iji maa atụ, ibido `ManuallyDrop<&mut T>` na [`mem::zeroed`] bụ agwa akọwaghị.
/// Ọ bụrụ na ị chọrọ ka aka uninitialized data, iji [`MaybeUninit<T>`] kama.
///
/// Rịba ama na ịnweta uru n'ime a `ManuallyDrop<T>` bụ nchebe.
/// Nke a pụtara na a `ManuallyDrop<T>` onye ọdịnaya e ama esịn ga gụrụ site a ọha mma API.
/// N'otu aka ahụ, `ManuallyDrop::drop` bụ nwedịrị ike ịta.
///
/// # `ManuallyDrop` ma dobe iwu.
///
/// Rust nwere a mma-kọwaa [drop order] nke ụkpụrụ.
/// Iji jide n'aka na a tụbara ubi ma ọ bụ ndị obodo n'otu usoro, hazigharị nkwupụta ndị ahụ nke iwu dobe bụ nke ziri ezi.
///
/// Enwere ike iji `ManuallyDrop` iji chịkwaa usoro nkwụsị, mana nke a chọrọ koodu na-adịghị mma ma sie ike ịme nke ọma na nkwụsị.
///
///
/// Ka ihe atụ, ọ bụrụ na ị chọrọ iji jide n'aka na a kpọmkwem ubi na-ama esịn mgbe ndị ọzọ, eme ka ọ na ndị ikpeazụ ubi nke a struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ga-ama esịn mgbe `children`.
///     // Rust emesi na ubi na-ama esịn na iji nke nkwupụta ahụ.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Kechie a bara uru-aka ama esịn.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Ka nwere ike ịrụ ọrụ n'enweghị nsogbu na uru ahụ
    /// assert_eq!(*x, "Hello");
    /// // Ma `Drop` agaghị na-agba ọsọ a
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extracts uru si `ManuallyDrop` akpa.
    ///
    /// Nke a na-enye ohere uru-ama esịn ọzọ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Nke a dara `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Ewe uru site `ManuallyDrop<T>` akpa si.
    ///
    /// Nke a na usoro na-isi zubere maka kwapụsịrị ụkpụrụ ke dobe.
    /// Kama iji [`ManuallyDrop::drop`] iji aka idebe nke bara uru, i nwere ike iji usoro a na-uru na-eji ya Otú ọ dị chọrọ.
    ///
    /// Mgbe ọ bụla o kwere omume, ọ bụ mma iji [`into_inner`][`ManuallyDrop::into_inner`] kama, nke na-egbochi duplicating ọdịnaya nke `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Nke a ọrụ semantically akpali si ẹdude uru enweghị egbochi n'ihu ojiji, na-ahapụ ala nke a akpa na-agbanweghi agbanwe.
    /// Ọ bụ ọrụ gị iji hụ na a `ManuallyDrop` na-adịghị eji ọzọ.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // NCHEKWA: anyị na-agụ site na a akwụkwọ, nke na-ekwe nkwa
        // ịbụ nti maka agụ.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Iji aka tụlee nwere uru.Nke a bụ kpọmkwem Ẹkot akpọ [`ptr::drop_in_place`] na a pointer na ẹdude uru.
    /// Dị ka ndị dị otú ahụ, ma ọ bụrụ na e dere uru bụ a juru n'ọnụ struct, na destructor ga-akpọ na-ebe na-enweghị na-akpụ akpụ na uru, ma si otú a pụrụ iji ihe n'enweghị dobe [pinned] data.
    ///
    /// Ọ bụrụ n`inwere ikike, ịnwere ike iji [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ọrụ a na-ebibi mbibi nke uru dị.
    /// Ndị ọzọ karịa mgbanwe nke onye mbibi ahụ mere n'onwe ya, a na-ahapụ ebe nchekwa ahụ na-agbanwe agbanwe, yabụ ruo na nchịkọta ahụ ka na-ejide obere ụkpụrụ nke bara uru maka ụdị `T`.
    ///
    ///
    /// Otú ọ dị, nke a "zombie" uru ekwesịghị gụrụ mma koodu, na ọrụ a na-ekwesịghị na-akpọ ihe karịrị otu ugboro.
    /// Iji jiri a uru mgbe ọ e ama esịn, ma ọ bụ idebe a uru otutu ugboro, nwere ike ime ka Undefined Àgwà (dabere na ihe `drop` eme).
    /// Nke a na-ejikari gbochiri site ụdị usoro, ma ọrụ nke `ManuallyDrop` ga na-akwado ndị di na-enweghị aka nke compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // NCHEKWA: anyị na-atụnye uru kwuru site a mutable akwụkwọ
        // nke a na-ekwe nkwa na-nti nke na-ede.
        // Ọ dịịrị onye na-akpọ oku ijide n'aka na `slot` adaghị ọzọ.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}