use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A fụchie ụdị iji rụọ uninitialized ihe nke `T`.
///
/// # Initialization agbanwe
///
/// The compiler, n'ozuzu, putara na a agbanwe na-ekwesị initialized dị ka chọrọ nke agbanwe si ụdị.Iji maa atụ, a ga-ahazigharị ihe ntụgharị nke ụdị ntụzịaka na-abụghị NULL.
/// Nke a bụ ihe invariant na ga niile * ga-kwadoro, ọbụna nwedịrị ike ịta koodu.
/// N'ihi ya, na-ebido ngbanwe ụdị ụdị nrụpụta na-akpata [undefined behavior][ub] ozugbo, n'agbanyeghị ma a na-etinye akwụkwọ ahụ iji nweta ebe nchekwa:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // omume a na-akọwaghị!⚠️
/// // Ẹkot koodu na `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // omume a na-akọwaghị!⚠️
/// ```
///
/// Nke a na-emegbu ndị compiler maka iche iche optimizations, dị ka eliding ọsọ-oge-achọpụtazi na optimizing `enum` layout.
///
/// N'otu aka ahụ, kpamkpam uninitialized ebe nchekwa nwere ike ọ bụla ọdịnaya, mgbe a `bool` ga-enwe mgbe nile `true` ma ọ bụ `false`.N'ihi ya, na-eke ihe uninitialized `bool` bụ undefined omume:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // omume a na-akọwaghị!⚠️
/// // Ẹkot koodu na `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // omume a na-akọwaghị!⚠️
/// ```
///
/// Ọzọkwa, uninitialized ebe nchekwa pụrụ iche na ọ na-adịghị ga-a ofu uru ("fixed" pụtara "it won't change without being written to").Ịgụ otu uninitialized byte otutu ugboro nwere ike inye dị iche iche pụta.
/// Nke a na-eme ka ọ undefined omume nwere uninitialized data na a agbanwe ọbụna ma ọ bụrụ na agbanwe nwere integer ụdị, nke ma pụrụ ijide ọ bụla *ofu* bit nlereanya:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // omume a na-akọwaghị!⚠️
/// // Koodu kwekọrọ na `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // omume a na-akọwaghị!⚠️
/// ```
/// (Rịba ama na iwu ndị ejikọtaghị ọnụ ọgụgụ na-emeghị emechabeghị, mana ruo mgbe ha dị, ọ ga-adị mma ka ị zere ha.)
///
/// Na n'elu nke, na-echeta na ọtụtụ ụdị ndị ọzọ invariants n'ofè naanị a na-atụle initialized na ụdị larịị.
/// Dị ka ihe atụ, a '1`-initialized [`Vec<T>`] a na-ewere initialized (n'okpuru ugbu a, mmejuputa iwu; a esoghị a ufọk ufene nkwa) n'ihi na naanị chọrọ na compiler maara banyere ya bụ na data pointer ga-abụghị null.
/// Mepụta `Vec<T>` dị otú ahụ anaghị akpata *omume* a na-akọwaghị ozugbo, kama ọ ga-eme ka omume a na-akọwaghị rụọ ọrụ na-enweghị nchebe (gụnyere idobe ya).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` eje ozi iji na-eme ka nwedịrị ike ịta code obibi uninitialized data.
/// Ọ bụ ihe mgbaàmà na-na compiler na-egosi na data ebe a wee na bụghị * ga initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Mepụta ihe n'ụzọ doro anya uninitialized akwụkwọ.
/// // The compiler maara na data n'ime a `MaybeUninit<T>` nwere ike ghara ịdị irè, na ya mere nke a abụghị UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Dọba ya ka a irè uru.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Wepụ initialized data-a na-na-ekwe *mgbe* ọma initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// The compiler mgbe maara na ihe ọ bụla na-ekwesịghị ịdị echiche ma ọ bụ optimizations a koodu.
///
/// I nwere ike na-eche nke `MaybeUninit<T>` dị ka ndị a bit dị ka `Option<T>` ma na-enweghị ihe ọ bụla nke na-agba ọsọ na-nsuso na-enweghị ihe ọ bụla nke nchekwa akwụkwọ ndenye ego.
///
/// ## out-pointers
///
/// Ị nwere ike iji `MaybeUninit<T>` mejuputa "out-pointers": kama ịlọta data si a ọrụ, na-agafe ya a pointer ka ụfọdụ (uninitialized) ebe nchekwa na-etinye n'ihi n'ime.
/// Nke a nwere ike bara uru mgbe ọ dị mkpa ka nke bere na akara otú ebe nchekwa n'ihi na-echekwara na ego n'anya ekenyela, na ị chọrọ iji zere na-enweghị isi Nkea.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` anaghị dobe ochie ọdịnaya, nke dị mkpa.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ugbu a, anyị maara na amalitela `v`!Nke a na-emekwa ka n'aka na vector ego n'anya n'ụzọ kwesịrị ekwesị ama esịn.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing otu n'usoro mmewere-site-mmewere
///
/// `MaybeUninit<T>` nwere ike iji initialize a nnukwu n'usoro mmewere-site-mmewere:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Mepụta ihe uninitialized n'usoro nke `MaybeUninit`.
///     // `assume_init` dị mma n'ihi na ụdị anyị na-azọrọ na anyị bidoro ebe a bụ ụyọkọ nke ``MayUninit`s, nke na-achọghị mbido.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Idobe a `MaybeUninit` ka ihe ọ bụla.
///     // N'ihi ya iji raw pointer ọrụ kama `ptr::write` adịghị akpata ochie uninitialized uru-ama esịn.
/////
///     // Ọzọkwa ma ọ bụrụ na e nwere a panic n'oge a loop, anyị nwere a na ebe nchekwa na-ehi ehi, ma ọ dịghị ebe nchekwa na nchekwa nke.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ihe niile na-initialized.
///     // Gbanye usoro ahụ na ụdị izizi.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// I nwekwara ike na-arụ ọrụ na-ezughị ezu initialized arrays, nke a pụrụ ịhụ na ala-larịị datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Mepụta ihe uninitialized n'usoro nke `MaybeUninit`.
/// // `assume_init` dị mma n'ihi na ụdị anyị na-azọrọ na anyị bidoro ebe a bụ ụyọkọ nke ``MayUninit`s, nke na-achọghị mbido.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Gụọnụ nọmba nke ihe ndị anyị kenyere.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // N'ihi na onye ọ bụla ihe na n'usoro, dobe ma ọ bụrụ na anyị na-ekenyela ya.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing a struct ubi-site-ubi
///
/// Ị nwere ike iji `MaybeUninit<T>`, na [`std::ptr::addr_of_mut`] nnukwu, ka initialize structs ubi site n'ọhia:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing na `name` ubi
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing na `list` ubi Ọ bụrụ na e a panic ebe a, mgbe ahụ `String` na `name` ubi leaks.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // All na ubi na-initialized, otú anyị na-akpọ `assume_init`-enweta ihe initialized Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` na-ekwe nkwa nwere otu size, itinye n'ọnọdụ, na Abi ka `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Agbanyeghị, cheta na ụdị *nke nwere*`MaybeUninit<T>` abughi otu usoro;Rust anaghị ekwenye n'ozuzu na ubi nke `Foo<T>` nwere otu usoro dị ka `Foo<U>` ọbụlagodi na `T` na `U` nwere otu nha na nhazi.
///
/// Ọzọkwa n'ihi ọ bụla bit uru bụ irè n'ihi na a `MaybeUninit<T>` na compiler ike ide non-zero/niche-filling optimizations, nwere ike n'ihi na ibu size:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ọ bụrụ na `T` bụ FFI-mma, mgbe ahụ, n'ihi ya, bụ `MaybeUninit<T>`.
///
/// Mgbe `MaybeUninit` bụ `#[repr(transparent)]` (egosi na ọ na-emesi otu size, itinye n'ọnọdụ, na Abi ka `T`), nke a na-eme *bụghị* ịgbanwe ọ bụla nke gara aga caveats.
/// `Option<T>` na `Option<MaybeUninit<T>>` nwere ike inwe nha dị iche iche, na ụdị nwere ụdị ụdị `T` nwere ike ịtọpụta (ma too) dị iche karịa na ubi ahụ bụ `MaybeUninit<T>`.
/// `MaybeUninit` bụ a n'otu ụdị, na `#[repr(transparent)]` na ịlụ bụ ejighị n'aka (lee [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// N'ime oge ahụ, kpọmkwem di nke `#[repr(transparent)]` na ịlụ nwere ike webata, na `MaybeUninit` nwere ike ma ọ bụ wee ghara ịnọgide `#[repr(transparent)]`.
/// Nke sị, `MaybeUninit<T>` ga niile * nkwa na o nwere otu size, itinye n'ọnọdụ, na Abi ka `T`;ọ bụ naanị na ụzọ `MaybeUninit` si eme ihe ahụ na-ekwe nkwa nwere ike ịgbanwe.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang ihe mere anyị nwere ike kechie ndị ọzọ ụdị na ya.Nke a bara uru maka ndị na-enye ọkụ.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ọ bụghị na-akpọ `T::clone()`, anyị amaghị ma ọ bụrụ na anyị na-initialized ezuru na.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ejiri `MaybeUninit<T>` ohuru bido na uru enyere.
    /// Ọ bụ nchebe na-akpọ [`assume_init`] na nloghachi uru nke ọrụ a.
    ///
    /// Cheta na idobe a `MaybeUninit<T>` ga-akpọ 'T` si dobe koodu.
    /// Ọ bụ ọrụ gị iji jide n'aka na `T` ego n'anya ama esịn ọ bụrụ na ọ ọkọdọ initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Emepụta ọhụrụ `MaybeUninit<T>` na uninitialized ala.
    ///
    /// Cheta na idobe a `MaybeUninit<T>` ga-akpọ 'T` si dobe koodu.
    /// Ọ bụ ọrụ gị iji jide n'aka na `T` ego n'anya ama esịn ọ bụrụ na ọ ọkọdọ initialized.
    ///
    /// Lee [type-level documentation][MaybeUninit] maka ihe atụ ụfọdụ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Mepụta usoro `MaybeUninit<T>` ọhụrụ, na steeti amaghị.
    ///
    /// Note: na a future Rust version usoro a nwere ike ịghọ enweghị isi mgbe n'usoro nkịtị syntax na-enye ohere [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// The atụ n'okpuru ike mgbe na-eji `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Alaghachi a (ikekwe nta) slice of data na n'ezie na-agụ
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // NCHEKWA: An uninitialized `[MaybeUninit<_>; LEN]` bụ nti.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Mepụta `MaybeUninit<T>` ọhụrụ na steeti amaghị, ebe nchekwa na-ejupụta `0` bytes.Ọ dabere na `T` ma nke ahụ emeelarị maka mbido kwesịrị ekwesị.
    ///
    /// Ka ihe atụ, `MaybeUninit<usize>::zeroed()` na-initialized, ma `MaybeUninit<&'static i32>::zeroed()` bụghị n'ihi na e kwuru okwu banyere ga-abụ null.
    ///
    /// Cheta na idobe a `MaybeUninit<T>` ga-akpọ 'T` si dobe koodu.
    /// Ọ bụ ọrụ gị iji jide n'aka na `T` ego n'anya ama esịn ọ bụrụ na ọ ọkọdọ initialized.
    ///
    /// # Example
    ///
    /// Correct ojiji nke ọrụ a: initializing a struct na efu, ebe niile ubi nke struct nwere ike jide bit-ụkpụrụ 0 ka a nti uru.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Ezughị oke* ojiji nke ọrụ a: akpọ `x.zeroed().assume_init()` mgbe `0` bụghị a nti bit-ụkpụrụ maka ụdị:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inside a ụzọ, anyị na ike a `NotZero` nke na-adịghị nwere nti discriminant.
    /// // Nke a bụ undefined omume.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // NCHEKWA: `u.as_mut_ptr()` ezo ekenyela ebe nchekwa.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Setịpụrụ uru nke `MaybeUninit<T>`.
    /// Nke a na-edochi ọ bụla gara aga uru enweghị idobe ya, ya mere kpachara anya ka anyị ghara iji nke a ugboro abụọ ma na ị chọrọ ikwu na-agba ọsọ ahụ destructor.
    ///
    /// Maka nkasi obi gị, nke a na-alaghachikwa aka ntụgharị ihu na ọdịnaya dị na `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // NCHEKWA: Anyị dị nnọọ initialized a bara uru.
        unsafe { self.assume_init_mut() }
    }

    /// Na-enweta pointer na uru dị.
    /// Gụ ihe na pointer a ma ọ bụ ịtụgharị ya na nrụtụ aka bụ akparamaagwa agwa belụsọ na ebuputara `MaybeUninit<T>`.
    /// Ide ihe na ncheta na ihe atụ (non-transitively) a na-ezo aka bụ omume na-akọwaghị (ma e wezụga n'ime `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Mepụta a akwụkwọ n'ime `MaybeUninit<T>`.Nke a bụ dịkwa mma n'ihi na anyị initialized ya.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Ezughị oke* ojiji nke usoro a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Anyị kere a banyere ihe uninitialized vector!Nke a bụ undefined omume.⚠️
    /// ```
    ///
    /// (Cheta na ndị na-achịkwa gburugburu ebe e kwuru banyere uninitialized data na-adịghị fọrọ ma, ma ruo mgbe ha, ọ bụ ihe amamihe izere ha.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` na `ManuallyDrop`-ma `repr(transparent)` otú anyị nwere ike kpụọ pointer.
        self as *const _ as *const T
    }

    /// Alụta mutable pointer na ẹdude uru.
    /// Gụ ihe na pointer a ma ọ bụ ịtụgharị ya na nrụtụ aka bụ akparamaagwa agwa belụsọ na ebuputara `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Mepụta a akwụkwọ n'ime `MaybeUninit<Vec<u32>>`.
    /// // Nke a bụ dịkwa mma n'ihi na anyị initialized ya.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Ezughị oke* ojiji nke usoro a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Anyị kere a banyere ihe uninitialized vector!Nke a bụ undefined omume.⚠️
    /// ```
    ///
    /// (Cheta na ndị na-achịkwa gburugburu ebe e kwuru banyere uninitialized data na-adịghị fọrọ ma, ma ruo mgbe ha, ọ bụ ihe amamihe izere ha.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` na `ManuallyDrop`-ma `repr(transparent)` otú anyị nwere ike kpụọ pointer.
        self as *mut _ as *mut T
    }

    /// Extracts uru si `MaybeUninit<T>` akpa.Nke a bụ oké ụzọ hụ na data ga-ama esịn, n'ihi na n'ihi `T` bụ isiokwu na-emebu dobe njikwa.
    ///
    /// # Safety
    ///
    /// Ọ bụ ruo nke bere na nkwa na `MaybeUninit<T>` n'ezie bụ na ihe initialized ala.Kpọ nke a mgbe amabeghị ọdịnaya zuru oke na-ebute omume anaghị akọwagha ozugbo.
    /// The [type-level documentation][inv] nwere ihe ọmụma banyere initialization invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Na n'elu nke, na-echeta na ọtụtụ ụdị ndị ọzọ invariants n'ofè naanị a na-atụle initialized na ụdị larịị.
    /// Dị ka ihe atụ, a '1`-initialized [`Vec<T>`] a na-ewere initialized (n'okpuru ugbu a, mmejuputa iwu; a esoghị a ufọk ufene nkwa) n'ihi na naanị chọrọ na compiler maara banyere ya bụ na data pointer ga-abụghị null.
    ///
    /// Mepụta `Vec<T>` dị otú ahụ anaghị akpata *omume* a na-akọwaghị ozugbo, kama ọ ga-eme ka omume a na-akọwaghị rụọ ọrụ na-enweghị nchebe (gụnyere idobe ya).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Ezughị oke* ojiji nke usoro a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` amalitebeghị amalite, yabụ akara ikpeazụ a kpatara omume na-enweghị nkọwa.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // MGBE: onye na-akpọ oku ga-ekwenye na amalitela `self`.
        // Nke a pụtakwara na `self` ga-a `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Agụ uru site `MaybeUninit<T>` akpa.Ihe `T` bụ isiokwu na-emebu dobe njikwa.
    ///
    /// Mgbe ọ bụla enwere ike, ọ ka mma iji [`assume_init`] kama, nke na-egbochi ịmegharị ọdịnaya nke `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ọ dịịrị onye na-akpọ oku ka o doo anya na `MaybeUninit<T>` dị na steeti amalitela.Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume.
    /// The [type-level documentation][inv] nwere ihe ọmụma banyere initialization invariant.
    ///
    /// Ọzọkwa, nke a na-ahapụ otu otu data ahụ dị na `MaybeUninit<T>`.
    /// Mgbe na-eji otutu mbipụta nke data (site na-akpọ `assume_init_read` otutu ugboro, ma ọ bụ ụzọ na-akpọ `assume_init_read` wee [`assume_init`]), ọ bụ gị na ọrụ iji hụ na ahụ data pụrụ n'ezie na-apụghị imepụta.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` bụ `Copy`, otú ahụ ka anyị nwere ike na-agụ ọtụtụ ugboro.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Mbipụta uru `None` dị mma, yabụ anyị nwere ike ịgụ ọtụtụ oge.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Ezughị oke* ojiji nke usoro a:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Anyị ugbu a kere abụọ mbipụta nke otu vector, na-eduga a abụọ-free ⚠️ mgbe ha ma esi ama esịn!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // MGBE: onye na-akpọ oku ga-ekwenye na amalitela `self`.
        // Agụ site `self.as_ptr()` bụ nchebe ebe ọ bụ na `self` ga-initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Tụlee nwere uru ebe.
    ///
    /// Ọ bụrụ na ị nwere nwe nke `MaybeUninit`, i nwere ike iji [`assume_init`] kama.
    ///
    /// # Safety
    ///
    /// Ọ dịịrị onye na-akpọ oku ka o doo anya na `MaybeUninit<T>` dị na steeti amalitela.Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume.
    ///
    /// Na n'elu nke, niile ọzọ invariants nke ụdị `T` ga-oyụhọ, dị ka `Drop` mmejuputa `T` (ma ọ bụ ndị nọ na ya) nwere ike na-adabere na nke a.
    /// Dị ka ihe atụ, a '1`-initialized [`Vec<T>`] a na-ewere initialized (n'okpuru ugbu a, mmejuputa iwu; a esoghị a ufọk ufene nkwa) n'ihi na naanị chọrọ na compiler maara banyere ya bụ na data pointer ga-abụghị null.
    ///
    /// Idobe dị otú ahụ a `Vec<T>` Otú ọ dị ga-eme ka undefined omume.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: onye na-akpọ oku ga-ekwusi ike na amalitela `self` na
        // afọ niile invariants nke `T`.
        // Idobe uru na ebe ahụ dị nchebe ma ọ bụrụ na nke ahụ bụ ikpe.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Alụta a na-akọrọ banyere ẹdude uru.
    ///
    /// Nke a nwere ike bara uru mgbe anyị chọrọ iji nweta a `MaybeUninit` na e initialized ma enweghị nwe nke `MaybeUninit` (egbochi ojiji nke `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume: ọ bụ nke bere na nkwa na `MaybeUninit<T>` n'ezie bụ na ihe initialized ala.
    ///
    ///
    /// # Examples
    ///
    /// ### Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ugbu a, na anyị `MaybeUninit<_>` mara ka initialized, ọ bụ dịkwa mma ka ike a na-akọrọ banyere ya:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // NCHEKWA: `x` e initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Ezughị oke* usages nke usoro a:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Anyị kere a banyere ihe uninitialized vector!Nke a bụ undefined omume.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize na `MaybeUninit` iji `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Reference na uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // MGBE: onye na-akpọ oku ga-ekwenye na amalitela `self`.
        // Nke a pụtakwara na `self` ga-a `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Alụta mutable (unique) akwụkwọ kwuru na ẹdude uru.
    ///
    /// Nke a nwere ike bara uru mgbe anyị chọrọ iji nweta a `MaybeUninit` na e initialized ma enweghị nwe nke `MaybeUninit` (egbochi ojiji nke `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume: ọ bụ nke bere na nkwa na `MaybeUninit<T>` n'ezie bụ na ihe initialized ala.
    /// Ihe atụ, `.assume_init_mut()` ike ga-eji na initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Correct ojiji nke usoro a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes niile * na bytes nke input echekwa.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ugbu a, anyị maara na amalitela `buf`, yabụ na anyị nwere ike `.assume_init()` ya.
    /// // Otú ọ dị, iji `.assume_init()` nwere ike ịkpalite a `memcpy` nke 2048 bytes.
    /// // Iji na-ekwu anyị echekwa e initialized enweghị edegharị ya, anyị na-kwalite na `&mut MaybeUninit<[u8; 2048]>` ka a `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // NCHEKWA: `buf` e initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ugbu a, anyị nwere ike iji `buf` dị ka a nkịtị iberi:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Ezughị oke* usages nke usoro a:
    ///
    /// Ị nwere ike iji `.assume_init_mut()` ka initialize a uru:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Anyị kere a (mutable) banyere ihe uninitialized `bool`!
    ///     // Nke a bụ undefined omume.⚠️
    /// }
    /// ```
    ///
    /// Dịka ọmụmaatụ, ịnweghị ike [`Read`] n'ime nchekwa echeghị echebe:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) banyere uninitialized ebe nchekwa!
    ///                             // Nke a bụ undefined omume.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ma ọ bụ i nwere ike iji kpọmkwem ubi ohere ime ubi-site-ubi gradual initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) banyere uninitialized ebe nchekwa!
    ///                  // Nke a bụ undefined omume.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) banyere uninitialized ebe nchekwa!
    ///                  // Nke a bụ undefined omume.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Anyị na-adabere ugbu a na ihe ahụ dị n'elu na-ezighi ezi, ya bụ, anyị nwere ntụnye aka maka data na-enweghị atụ (dịka, na `libcore/fmt/float.rs`)
    // Anyị kwesịrị ime mkpebi ikpeazụ gbasara iwu tupu ị kwụsie ike.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // MGBE: onye na-akpọ oku ga-ekwenye na amalitela `self`.
        // Nke a pụtakwara na `self` ga-a `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extracts ụkpụrụ si otu n'usoro nke `MaybeUninit` containers.
    ///
    /// # Safety
    ///
    /// Ọ bụ ruo nke bere na nkwa na niile na ihe nke n'usoro na-na-initialized ala.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // NCHEKWA: Ugbu a mma dị ka anyị initialised niile ọcha
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Onye na-akpọ oku na-ekwe nkwa na ebido ihe niile dị n'usoro
        // * `MaybeUninit<T>` na T na-ekwe nkwa na otu layout
        // * MaybeUnint anaghị idebe, otú e nweghị abụọ-atọhapụ Ma si otú ntọghata bụ nchebe
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Anya isi niile ọcha na-initialized, na-a iberi ha.
    ///
    /// # Safety
    ///
    /// Ọ bụ ruo nke bere na-ekwe nkwa na `MaybeUninit<T>` ọcha n'ezie na ihe initialized ala.
    ///
    /// Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume.
    ///
    /// Lee [`assume_init_ref`] maka nkọwa ndị ọzọ na-atụ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // NCHEKWA: nēfe iberi ka a `*const [T]` bụ nchebe ebe ọ bụ na nke bere jide n'aka na
        // `slice` bụ initialized, and`MaybeUninit` na-ekwe nkwa nwere otu layout ka `T`.
        // The pointer nwetara bụ nti ebe ọ na-ezo aka na ebe nchekwa ekesịpde `slice` nke bụ a akwụkwọ ma si otú na-ekwe nkwa na-nti nke na-agụ.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Anya isi niile ọcha na-initialized, na-a mutable iberi ha.
    ///
    /// # Safety
    ///
    /// Ọ bụ ruo nke bere na-ekwe nkwa na `MaybeUninit<T>` ọcha n'ezie na ihe initialized ala.
    ///
    /// Akpọ nke a mgbe ọdịnaya bụ ma n'ụzọ zuru ezu initialized akpata undefined omume.
    ///
    /// Lee [`assume_init_mut`] maka nkọwa ndị ọzọ na-atụ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // NCHEKWA: yiri nchekwa deturu maka `slice_get_ref`, ma anyị nwere a
        // mutable akwụkwọ nke a na-ekwe nkwa na-nti nke na-ede.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Alụta pointer mbụ mmewere nke n'usoro.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Alụta mutable pointer mbụ mmewere nke n'usoro.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Mbipụta ndị ọcha si `src` ka `this`, na-alọghachi a mutable akwụkwọ kwuru na ugbu a initalized ọdịnaya nke `this`.
    ///
    /// Ọ bụrụ na `T` anaghị mejuputa `Copy`, iji [`write_slice_cloned`]
    ///
    /// Nke a bụ yiri [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na abụọ Mpekere nwere dị iche iche ogologo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // NCHEKWA: anyị ka depụtaghachiri niile ọcha nke len n'ime mapụtara ikike
    /// // ihe mbụ src.len() nke vec dị ugbu a.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] na&[Ma eleghị anya, Uninit<T>] Nwere otu layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // NCHEKWA: Valid ọcha nwere nanị e depụtaghachiri n'ime `this` n'ihi ya, ọ na-initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones ihe ndị sitere na `src` na `this`, na-eweghachite ntụgharị ntụgharị maka ọdịnaya dị na `this` ugbu a.
    /// Agaghị ahapụ ihe ọ bụla etinyegoro initali.
    ///
    /// Ọ bụrụ na `T` achụ nta `Copy`, ojiji [`write_slice`]
    ///
    /// Nke a bụ yiri [`slice::clone_from_slice`] ma adịghị dobe ẹdude ọcha.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na abụọ Mpekere nwere dị iche iche ogologo, ma ọ bụ ma ọ bụrụ na mmejuputa `Clone` panics.
    ///
    /// Ọ bụrụ na e a panic, ama cloned ọcha ga-ama esịn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // NCHEKWA: anyị ka cloned niile ọcha nke len n'ime mapụtara ikike
    /// // ihe mbụ src.len() nke vec dị ugbu a.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // n'adịghị copy_from_slice nke a adịghị na-akpọ clone_from_slice na iberi nke a bụ n'ihi `MaybeUninit<T: Clone>` anaghị mejuputa mmepụta oyiri.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // NCHEKWA: a raw iberi ga-ebu naanị initialized akpọkwa
                // ọ bụ ya mere, a na-ahapụ ya ka ọ dobe ya.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Anyị kwesịrị ịkọwapụ ha n'ụzọ doro anya n'otu ogologo
        // maka ókè ịlele ka elided, na optimizer ga-n'ịwa memcpy maka mfe ikpe (atụ T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // nche dị mkpa b/c panic nwere ike ime n'oge a mmepụta oyiri
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // NCHEKWA: Valid ọcha nwere nanị e dere n'ime `this` n'ihi ya, ọ na-initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}