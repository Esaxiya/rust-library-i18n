//! Ọrụ ndị bụ isi maka ịnagide ncheta.
//!
//! Nke a modul nwere ọrụ maka querying size na itinye n'ọnọdụ nke ụdị, initializing na emeghari ebe nchekwa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Alụrụ na "forgets" banyere uru **enweghị na-agba ọsọ ya destructor**.
///
/// Ọ bụla ego uru ejisie, dị ka obo ebe nchekwa ma ọ bụ a file ahụ, ga-ekpetekwa ruo mgbe ebighị ebi unreachable ala.Otú ọ dị, ọ na-adịghị ekwe nkwa na pointers a ebe nchekwa ga-anọgide na nti.
///
/// * Ọ bụrụ na ị chọrọ ihihi ebe nchekwa, ịhụ [`Box::leak`].
/// * Ọ bụrụ na ịchọrọ inweta pointer rawị na ebe nchekwa, lee [`Box::into_raw`].
/// * Ọ bụrụ na ị chọrọ pụrụ nke a bara uru nke ọma, na-agba ọsọ ya destructor, hụ [`mem::drop`].
///
/// # Safety
///
/// `forget` na-adịghị akara dị ka `unsafe`, n'ihi Rust si nchekwa di anaghị agụnye a nkwa na destructors ga mgbe nile na-agba ọsọ.
/// Dị ka ihe atụ, a mmemme nwere ike ịmepụta a akwụkwọ okirikiri iji [`Rc`][rc], ma ọ bụ na-akpọ [`process::exit`][exit] ka ụzọ ọpụpụ na-enweghị na-agba ọsọ destructors.
/// N'ihi ya, ikwe `mem::forget` si mma code anaghị fundamentally ịgbanwe Rust si nchekwa di.
///
/// Nke sị, na-eri eri ego dị ka ebe nchekwa ma ọ bụ I/O ihe na-abụkarị ekwesighi.
/// Mkpa a na-abịa na ụfọdụ iji ọrụ pụrụ iche maka FFI ma ọ bụ koodu enweghị nchekwa, mana ọbụlagodi, [`ManuallyDrop`] na-ahọrọkarị.
///
/// N'ihi na na-echefu a uru na-ekwe, ọ bụla `unsafe` koodu ị dee ga-ekwe ka ihe a ga-ekwe omume.Ị nwere ike laghachi a uru na-atụ anya na nke bere ga-bụchaghị na-agba ọsọ na uru nke destructor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ihe nchekwa nke `mem::forget` bụ iji gbochie mbibi nke otu `Drop` trait mebere.Ka ihe atụ, a ga-ihihi a `File`, ie
/// weghachite oghere nke onye na-agbanwe agbanwe mana ọ gaghị emechi usoro usoro usoro:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Nke a bụ uru mgbe ndị nwe nke na-apụtaghị ìhè akụ e mbụ zigara code mpụga nke Rust ihe atụ, site n'ibufe raw file descriptor ka C koodu.
///
/// # Mmekọrịta `ManuallyDrop`
///
/// Mgbe `mem::forget` nwekwara ike-eji nyefee *ebe nchekwa* nwe, ime otú ahụ na njehie-ewekarị.
/// [`ManuallyDrop`] ekwesịrị iji ya kama.Dị ka ihe atụ, a koodu:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Mee a `String` iji ọdịnaya nke `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ihihi `v` n'ihi ya ebe nchekwa na-now jisiri site `s`
/// mem::forget(v);  // Njehie, v bụ ghara ịdị irè ma ga gafere na otu ọrụ
/// assert_eq!(s, "Az");
/// // `s` na-obi kpamkpam ama esịn na ya na ebe nchekwa deallocated.
/// ```
///
/// E nwere ihe abụọ mbipụta na n'elu ihe atụ:
///
/// * Ọ bụrụ na ndị ọzọ koodu e kwukwara n'etiti ndị na-ewu `String` na ịkpọku ndị `mem::forget()`, a panic n'ime ya ga-eme ka a abụọ free n'ihi na otu na ebe nchekwa a na-eme site ma `v` na `s`.
/// * Mgbe akpọchara `v.as_mut_ptr()` ma nyefee ikike nke data na `s`, uru `v` abaghị uru.
/// Ọbụna mgbe a uru na-dị nnọọ kpaliri ka `mem::forget` (nke agaghị enyocha ya), ụfọdụ ụdị nwere iwu siri ike chọrọ na ụkpụrụ ha na-eme ka ha ghara ịdị irè mgbe dangling ma ọ bụ agaghịkwa ekesịpde.
/// Iji ụkpụrụ na-abaghị uru n'ụzọ ọ bụla, gụnyere ịfefe ya ma ọ bụ weghachite ha na ọrụ, bụ omume a na-akọwaghị ma nwee ike mebie echiche ndị nchịkọta ahụ.
///
/// Tụgharị na `ManuallyDrop` na-ezere nsogbu abụọ:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Tupu anyị ebugharị `v` n'ime akụkụ ya, gbaa mbọ hụ na ọ daghị!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ugbu a disassemble `v`.Ndị a arụmọrụ ike panic, otú e nwere ike ịbụ a-ehi ehi.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // N'ikpeazụ, na-ewu a `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` na-obi kpamkpam ama esịn na ya na ebe nchekwa deallocated.
/// ```
///
/// `ManuallyDrop` na-egbochi igbochi okpukpu abụọ n'ihi na anyị gbanyụọ `` mbibi '' tupu ịme ihe ọ bụla.
/// `mem::forget()` anaghị ekwe ka nke a n'ihi na ọ na-eri arụmụka ya, na-amanye anyị ịkpọ ya naanị mgbe anyị wepụsịrị ihe ọ bụla anyị chọrọ na `v`.
/// Ọbụna ma ọ bụrụ na ebuputara panic n'etiti iwu nke `ManuallyDrop` na iwuli eriri (nke na-enweghị ike ime na koodu ahụ dị ka egosiri), ọ ga-ebute ntanye ma ọ bụghị okpukpu abụọ.
/// N'ikwu ya n'ụzọ ọzọ, `ManuallyDrop` na-ehie ụzọ n'akụkụ ihi ụra karịa ihie ụzọ n'akụkụ (ịdaba abụọ).
///
/// Ọzọkwa, `ManuallyDrop` na-egbochi anyị inwe "touch" `v` mgbe anyị nyefesịrị ndị nwe na `s`-usoro ikpeazụ nke mmekọrịta na `v` iji tụfuo ya na-enweghị na-agba ọsọ onye mbibi ya kpamkpam zere.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Dị ka [`forget`], ma na-anabata ụkpụrụ a na-enyochaghị.
///
/// Ọrụ a bụ naanị shim nke ezubere iwepụ mgbe njirimara `unsized_locals` kwụsiri ike.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Laghachi nha otu udiri bytes.
///
/// Karịsịa, nke a bụ deeti na bytes n'etiti ihe ndị sochiri n'otu n'usoro nke ụdị ihe ahụ gụnyere ntinye nhazi.
///
/// Ya mere, maka ụdị `T` na ogologo `n`, `[T; n]` nwere nha `n * size_of::<T>()`.
///
/// Na mkpokọta, nha nke ụdị adịghị akwụsi ike n`akụkụ mkpokọta, mana ụdị dị iche iche dịka nke ochie.
///
/// Tebụl na-esonụ na-enye nha maka oge ochie.
///
/// |dị |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 agba |4
///
/// Ọzọkwa, `usize` na `isize` nwere otu nha.
///
/// Xdị `*const T`, `&T`, `Box<T>`, `Option<&T>`, na `Option<Box<T>>` niile nwere otu nha.
/// Ọ bụrụ na `T` dị nha, ụdị ndị ahụ niile nwere nha otu `usize`.
///
/// Mgbanwe nke pointer adịghị agbanwe nha ya.Dị ka ndị dị otú ahụ, `&T` na `&mut T` nwere otu size.
/// N'otu aka ahụ maka `*const T` na `* mut T`.
///
/// # Nha nke ihe `#[repr(C)]`
///
/// Ihe nnọchianya `C` maka ihe nwere nhazi akọwapụtara.
/// Site na nhazi a, oke ihe anaghị akwụsi ike ma ọ bụrụhaala na mpaghara niile nwere oke anụ.
///
/// ## Nha nke Oke
///
/// Maka `structs`, a na-ekpebi nha site na algorithm na-esonụ.
///
/// Maka mpaghara ọ bụla na nhazi nke enyere iwu site na nkwupụta iwu:
///
/// 1. Tinye nha nke ubi.
/// 2. Gbaa gburugburu nke ugbu a na otutu kacha nso nke [alignment] ọzọ.
///
/// N'ikpeazụ, gbaa gburugburu ihe owuwu ahụ na nke kacha nso nke [alignment] ya.
/// Ndọtị nke ihe owuwu na-abụkarị nhazi kachasị ukwuu nke mpaghara ya niile;enwere ike gbanwee nke a site na iji `repr(align(N))`.
///
/// N'adịghị ka `C`, a naghị erugharị okirikiri efu ruo otu byte nha.
///
/// ## Nha nke Enums
///
/// Enums ndị na-enweghị data ndị ọzọ karịa onye na-akpa ókè nwere otu nha nke C enums n`elu ikpo okwu a chịkọtara ha.
///
/// ## Nha nke ịlụ
///
/// Nha nke njikọ dị nha nke kachasị ukwuu.
///
/// N'adịghị ka `C`, a na-ejikọtaghị ịlụ ndị ọrụ efu ruo otu byte nha.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ụfọdụ primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // ụfọdụ arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer size hara nhata
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Iji `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // The size nke mbụ ubi bụ 1, otú tinye 1 na size.Size bụ 1.
/// // Itinye n'ọnọdụ nke abụọ ubi bụ 2, otú tinye 1 na size maka padding.Size bụ 2.
/// // Nha nke abụọ bụ 2, ya mere tinye 2 na nha.Size bụ 4.
/// // Itinye n'ọnọdụ nke atọ ubi bụ 1, otú tinye 0 na size maka padding.Nha bụ 4.
/// // The size nke atọ ubi bụ 1, otú tinye 1 na size.Size bụ 5.
/// // N'ikpeazụ, itinye n'ọnọdụ nke struct bụ 2 (n'ihi na ndị kasị ibu itinye n'ọnọdụ n'etiti ya na ubi bụ 2), ya mere, tinye 1 na size maka padding.
/// // Size bụ 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs na-agbaso otu iwu.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Rịba ama na reordering ubi ike belata size.
/// // Anyị nwere ike wepu ma na padding bytes site n'itinye `third` tupu `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union size bụ size nke kasị ubi.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Afiak size nke-ka uru na bytes.
///
/// Nke a na-abụkarị otu ihe ahụ `size_of::<T>()`.
/// Agbanyeghị, mgbe `T`*enweghị* oke ama ama ama, eg, [`[T]`][slice] slice ma ọ bụ [trait object], yabụ `size_of_val` enwere ike iji nweta ogo a maara nke ọma.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` bụ ntụaka, yabụ na ọ bụ pointer ziri ezi
    unsafe { intrinsics::size_of_val(val) }
}

/// Afiak size nke-ka uru na bytes.
///
/// Nke a na-abụkarị otu ihe ahụ `size_of::<T>()`.Agbanyeghị, mgbe `T`*enweghị* oke ama ama, dịka ịmaatụ, iberibe [`[T]`][slice] ma ọ bụ [trait object], yabụ `size_of_val_raw` enwere ike iji nweta ogo a maara nke ọma.
///
/// # Safety
///
/// Ọrụ a dị mma ịkpọ ma ọ bụrụ na ọnọdụ ndị a jide:
///
/// - Ọ bụrụ na `T` bụ `Sized`, ọrụ a na-adị mma ịkpọ mgbe niile.
/// - Ọ bụrụ na unsized ọdụ nke `T` bụ:
///     - a [slice], ogologo ogologo ọdụdụ ahụ ga-abụrịrị ọnụọgụ zuru ezu, na ogo nke uru niile * (ogologo ogologo ọdụ dị ogologo), ga-adaba na `isize`.
///     - a [trait object], mgbe ahụ akụkụ vtable nke pointer ga-arụtụ aka na vtable ziri ezi nke mmanye na-enweghị atụ, na nha nke * uru niile (ogologo ọdụ dị ogologo + prefix dị oke) ga-adaba na `isize`.
///
///     - ihe (unstable) [extern type], mgbe ahụ ọrụ a dị mma ịkpọ oku, mana nwere ike panic ma ọ bụ weghachite uru na-ezighi ezi, ebe ọ bụ na amaghị ụdị nhazi ụzọ.
///     Nke a bụ otu omume dị ka [`size_of_val`] na ntinye aka na ụdị nwere ọdụ ụdị mpụga.
///     - ma ọbụghị, anaghị ekwe ka akpọọ ọrụ a.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // MGBE AH the: onye na-akpọ oku ga-enwerịrị pointer ziri ezi
    unsafe { intrinsics::size_of_val(val) }
}

/// Weghachite [ABI] choro obere mwepụta nke ụdị.
///
/// Ntughari ọ bụla banyere uru nke ụdị `T` ga-abụrịrị otutu nke nọmba a.
///
/// Nke a bụ nghazi eji maka ebe arụ.O nwere ike pere mpe karịa mmasị.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Weghachitere [ABI] chọrọ mmezi pere mpe nke ụdị uru nke `val` rụtụrụ aka.
///
/// Ntughari ọ bụla banyere uru nke ụdị `T` ga-abụrịrị otutu nke nọmba a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val bụ akwụkwọ nrụnye, yabụ ọ bụ pointer ziri ezi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Weghachite [ABI] choro obere mwepụta nke ụdị.
///
/// Ntughari ọ bụla banyere uru nke ụdị `T` ga-abụrịrị otutu nke nọmba a.
///
/// Nke a bụ nghazi eji maka ebe arụ.O nwere ike pere mpe karịa mmasị.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Weghachitere [ABI] chọrọ mmezi pere mpe nke ụdị uru nke `val` rụtụrụ aka.
///
/// Ntughari ọ bụla banyere uru nke ụdị `T` ga-abụrịrị otutu nke nọmba a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val bụ akwụkwọ nrụnye, yabụ ọ bụ pointer ziri ezi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Weghachitere [ABI] chọrọ mmezi pere mpe nke ụdị uru nke `val` rụtụrụ aka.
///
/// Ntughari ọ bụla banyere uru nke ụdị `T` ga-abụrịrị otutu nke nọmba a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ọrụ a dị mma ịkpọ ma ọ bụrụ na ọnọdụ ndị a jide:
///
/// - Ọ bụrụ na `T` bụ `Sized`, ọrụ a na-adị mma ịkpọ mgbe niile.
/// - Ọ bụrụ na unsized ọdụ nke `T` bụ:
///     - a [slice], ogologo ogologo ọdụdụ ahụ ga-abụrịrị ọnụọgụ zuru ezu, na ogo nke uru niile * (ogologo ogologo ọdụ dị ogologo), ga-adaba na `isize`.
///     - a [trait object], mgbe ahụ akụkụ vtable nke pointer ga-arụtụ aka na vtable ziri ezi nke mmanye na-enweghị atụ, na nha nke * uru niile (ogologo ọdụ dị ogologo + prefix dị oke) ga-adaba na `isize`.
///
///     - ihe (unstable) [extern type], mgbe ahụ ọrụ a dị mma ịkpọ oku, mana nwere ike panic ma ọ bụ weghachite uru na-ezighi ezi, ebe ọ bụ na amaghị ụdị nhazi ụzọ.
///     Nke a bụ otu omume dị ka [`align_of_val`] na ntinye aka na ụdị nwere ọdụ ụdị mpụga.
///     - ma ọbụghị, anaghị ekwe ka akpọọ ọrụ a.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // MGBE AH the: onye na-akpọ oku ga-enwerịrị pointer ziri ezi
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Laghachi `true` ma ọ bụrụ na idobe ụkpụrụ nke ụdị `T` metụtara.
///
/// Nke a bụ naanị njikarịcha njikarịcha, ma enwere ike itinye ya n'ọrụ n'ụzọ siri ike:
/// Ọ nwere ike ịlaghachi `true` maka ụdị ndị na-achọghị ka a daa ha.
/// Dika nke a na-alọghachi `true` mgbe niile ga-abụ mmezigharị arụmọrụ nke ọrụ a.Agbanyeghị ọ bụrụ na ọrụ a laghachiri `false` n'ezie, ị nwere ike ijide n'aka na idobe `T` enweghị mmetụta ọ bụla.
///
/// Mmezu nke ihe dị ka mkpokọta, nke dị mkpa iji aka ha dobe data ha, kwesịrị iji ọrụ a iji zere na-enweghị isi na-anwa idobe ọdịnaya ha niile mgbe ebibiri ha.
///
/// Nke a nwere ike ọ gaghị eme mgbanwe na ntọhapụ na-ewuli (ebe akaghị nke na-enweghị mmetụta ọ bụla na-achọpụta ma wepu ya ngwa ngwa), mana ọ na-abụkarị nnukwu mmeri maka mmebi arụ.
///
/// Rịba ama na [`drop_in_place`] na-eme nlele a, yabụ ọ bụrụ na ọrụ gị nwere ike belata na obere obere oku [`drop_in_place`], iji nke a enweghị isi.
/// Karịsịa rịba ama na ị nwere ike [`drop_in_place`] iberi, nke ahụ ga-emekwa otu nlele_drop maka ụkpụrụ niile.
///
/// Dị dị ka Vec ya mere naanị `drop_in_place(&mut self[..])` na-enweghị iji `needs_drop` mee ihe n'ụzọ doro anya.
/// Tydị dịka [`HashMap`], n'aka nke ọzọ, ga-adaba ụkpụrụ otu n'otu oge ma kwesịrị iji API a.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Nke a bụ ihe atụ nke otu nchịkọta nwere ike isi jiri `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // dobe data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Weghachite uru nke ụdị `T` nke akara-efu niile.
///
/// Nke a pụtara na, dịka ọmụmaatụ, a naghị enwe zeroed padding byte na `(u8, u16)`.
///
/// Enweghị nkwa ọ bụla na ụdị ọ bụla na-anọchite anya ụkpụrụ bara uru nke ụdị `T` ụfọdụ.
/// Ọmụmaatụ, usoro ihe nhọta niile abụghị uru bara uru maka ụdị nrụtụ aka (``&T`, `&mut T`) na ntụpọ ọrụ.
/// Iji `zeroed` n'ụdị dị otú ahụ na-akpata [undefined behavior][ub] ozugbo n'ihi na [the Rust compiler assumes][inv] na enwere uru bara uru na agbanwe agbanwe ọ na-ahụta mmalite.
///
///
/// Nke a nwere otu mmetụta dịka [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ọ bara uru maka FFI mgbe ụfọdụ, mana a ga-ezere ya n'ozuzu.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ziri ezi ojiji nke ọrụ a: mbido integer na efu.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Ojiji *ezighi ezi* nke ọrụ a: ịmalite ịkọwa okwu na efu.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefined omume!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ọzọkwa!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // Nchedo: onye na-akpọ oku ga-ekwusi ike na uru efu ọ bụla bara uru maka `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Na-agafe Rust na-echekwa ncheta nke ọma site na ịme ka ị mepụta uru nke ụdị `T`, ebe ị na-emeghị ihe ọ bụla.
///
/// **Ọrụ a dara.** Jiri [`MaybeUninit<T>`] kama.
///
/// Ihe kpatara mbelata bụ na enweghị ike iji ọrụ ahụ n'ụzọ ziri ezi: ọ nwere otu mmetụta dịka [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Dị ka [`assume_init` documentation][assume_init] na-akọwa, [the Rust compiler assumes][inv] na ụkpụrụ dị iche iche na-amalite nke ọma.
/// N'ihi ya, na-akpọ eg
/// `mem::uninitialized::<bool>()` na-akpata omume a na-akọwaghị ozugbo maka ịlaghachi `bool` nke na-abụghị ma ọ bụ `true` ma ọ bụ `false`.
/// Nke ka njọ, ncheta enweghị ncheta dị ka ihe eweghachitere ebe a bụ ihe pụrụ iche na onye nchịkọta ahụ maara na ọ nweghị uru a kapịrị ọnụ.
/// Nke a na-eme ka ọ ghara ịkọwapụta omume ka ị ghara ị nweta data na-agbanwe agbanwe ọ bụrụgodi na mgbanwe ahụ nwere ụdị ntanetị.
/// (Rịba ama na iwu ndị ejikọtaghị ọnụ ọgụgụ na-emeghị emechabeghị, mana ruo mgbe ha dị, ọ ga-adị mma ka ị zere ha.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // Nchedo: onye na-akpọ oku ga-ekwusi ike na uru a na-ejikọtaghị na ọ dị irè maka `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Gbanwee ụkpụrụ na ọnọdụ abụọ nwere ike ịgbanwe agbanwe, na-enweghị ịkọwapụta otu.
///
/// * Ọ bụrụ na ịchọrọ igbanye na nke ndabara ma ọ bụ dummy uru, lee [`take`].
/// * Ọ bụrụ na ịchọrọ ịgbanwe na uru agafela, weghachite uru ochie, lee [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // EKPERE: Ebuputala ndi na-eziputa ihe site na ntughari ederede na-eju afọ
    // mgbochi na `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Dochie `dest` na uru ndabara nke `T`, weghachite uru `dest` gara aga.
///
/// * Ọ bụrụ na ịchọrọ iji dochie ụkpụrụ nke mgbanwe abụọ, lee [`swap`].
/// * Ọ bụrụ na ịchọrọ iji dochie ya na uru gafere karịa nke ndabara, lee [`replace`].
///
/// # Examples
///
/// Ihe omuma di nfe:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` na-enye ohere ịnweta nnweta nke usoro ihe owuwu site na iji akara "empty" dochie ya.
/// Na-enweghị `take` ị nwere ike ịbanye na nsogbu dịka:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Rịba ama na `T` anaghị etinye [`Clone`] n'ọrụ, yabụ na ọ nweghịdị ike iji mmepụta oyiri ma tọgharịa `self.buf`.
/// Mana `take` enwere ike iji wepu uru mbụ nke `self.buf` sitere na `self`, wee kwe ka eweghachite ya:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Bugharịa `src` na `dest` edepụtara, weghachite uru `dest` gara aga.
///
/// Enweghị uru ọ bụla.
///
/// * Ọ bụrụ na ịchọrọ iji dochie ụkpụrụ nke mgbanwe abụọ, lee [`swap`].
/// * Ọ bụrụ na ịchọrọ iji dochie anya ọnụọgụ ndabara, lee [`take`].
///
/// # Examples
///
/// Ihe omuma di nfe:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` na-enye ohere oriri nke a struct ọhia dochie ya ọzọ bara uru.
/// Na-enweghị `replace` ị nwere ike ịbanye na nsogbu dịka:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Rịba ama na `T` anaghị etinye [`Clone`] n'ọrụ, yabụ na anyị enweghị ike ọbụna mmepụta oyiri `self.buf[i]` iji zere ngagharị ahụ.
/// Mana `replace` enwere ike iji wepu uru mbụ dị na ndeksi ahụ site na `self`, wee kwe ka eweghachite ya:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Anyị na-agụ site na `dest` mana dee `src` na ya ozugbo,
    // dị ka nke ochie uru na-adịghị oyiri.
    // Onweghi ihe ewepuru ma onweghi ihe ebe a panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Achọpụta uru.
///
/// Nke a na-eme nke a site n'ịkpọ arụmụka arụmụka nke [`Drop`][drop].
///
/// Nke a anaghị eme ihe ọ bụla maka ụdị nke mejuputa `Copy`, dịka ọmụmaatụ
/// integers.
/// E coomi ụdị ụkpụrụ a na _then_ wee banye na ọrụ ahụ, yabụ uru ahụ ka dị mgbe ọrụ a kpọchara.
///
///
/// Ọrụ a abụghị anwansi;akọwaputara ya dika
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ebe ọ bụ na ebugharị `_x` na ọrụ ahụ, ọ na-adaba na akpaghị aka tupu ọrụ ahụ alaghachi.
///
/// [drop]: Drop
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // n'ụzọ doro anya na idebe nke vector
/// ```
///
/// Ebe ọ bụ na [`RefCell`] na-akwado iwu mgbazinye oge, `drop` nwere ike ịhapụ mgbazinye [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // hapụ ịhapụ mutable gbaziri na oghere a
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integers na ndị ọzọ ụdị mmejuputa [`Copy`] bụ unaffected site `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // a oyiri nke `x` na-akpali na-ama esịn
/// drop(y); // a oyiri nke `y` na-akpali na-ama esịn
///
/// println!("x: {}, y: {}", x, y.0); // ka dị
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Prekọwa `src` dị ka nke nwere ụdị `&U`, wee gụ `src` na-enweghị ebugharị uru dị.
///
/// Ọrụ a ga-eche na ihe ngosi `src` dị mma maka [`size_of::<U>`][size_of] bytes site na ịtụgharị `&T` na `&U` wee gụ `&U` (belụsọ na emere nke a n'ụzọ ziri ezi ọbụlagodi mgbe `&U` na-eme ka ihe nkwekọ siri ike karịa `&T`).
/// Ọ ga-emepụta nchekwa nke enweghị uru kama ịpụ na `src`.
///
/// Ọ bụghị nchịkọta oge ma ọ bụrụ na `T` na `U` nwere nha dị iche iche, mana a na-agba ya ume ka ọ kpọọ ọrụ a naanị ebe `T` na `U` nwere otu nha.Ọrụ a na-ebute [undefined behavior][ub] ma ọ bụrụ na `U` karịrị `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Detuo data si 'foo_array' ma na-emeso ya dị ka a 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Gbanwee depụtaghachiri data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ọdịnaya nke 'foo_array' ekwesịghị gbanwere
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ọ bụrụ U nwere elu itinye n'ọnọdụ chọrọ, src ghara kwesịrịnụ kwekọọ.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` bụ ntụnye aka nke a ga-akwụ ụgwọ maka ịgụ.
        // Onye na-akpọ oku ga-ekwenye na mmụgharị ahụ dị mma.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` bụ ntụnye aka nke a ga-akwụ ụgwọ maka ịgụ.
        // Anyị dị nnọọ enyocha na `src as *const U` E nwere kwekọọ.
        // Onye na-akpọ oku ga-ekwenye na mmụgharị ahụ dị mma.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Padị na-anọchite anya mmadụ nke enum.
///
/// Hụ ọrụ [`discriminant`] na modul a maka ozi ndị ọzọ.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Enweghi ike inweta mmeputa trait a n'ihi na anyi achoghi oke iwu na T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Weghachite uru di iche iche na-amata ụdịdị enum dị na `v`.
///
/// Ọ bụrụ na `T` abụghị enum, ịkpọ ọrụ a agaghị ebute omume anaghị akọwapụta, mana ekwupụtaghị uru nloghachi.
///
///
/// # Stability
///
/// Ihe iche iche nke onye nwere ike gbanwee nwere ike gbanwee ma ọ bụrụ na nkọwa enum gbanwere.
/// Onye na-akpa oke iche iche agaghị agbanwe n'etiti mkpokọta yana otu nchịkọta.
///
/// # Examples
///
/// Enwere ike iji nke a tụnyere enum ndị na-ebu data, na-eleghara data ahụ anya:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Weghachite onu ogugu di iche na ụdị enum ụdị `T`.
///
/// Ọ bụrụ na `T` abụghị enum, ịkpọ ọrụ a agaghị ebute omume anaghị akọwapụta, mana ekwupụtaghị uru nloghachi.
/// N'otu aka ahụ, ọ bụrụ na `T` bụ enum nwere ọtụtụ ụdị karịa `usize::MAX` ọnụọgụ azụghị akọwapụta.
/// Agaghị agụta ọnụọgụ ndị na-ebighi ebi.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}