use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// An interface maka emeso asynchronous iterators.
///
/// Nke a bụ isi iyi trait.
/// N'ihi na ihe banyere echiche nke mmiri iyi n'ozuzu, biko hụ [module-level documentation].
/// Karịsịa, ị pụrụ ịchọ ịmata otú [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Ofdị ihe ndị a na-amịpụta site na mmiri iyi.
    type Item;

    /// Anwa dọpụtaara ọzọ uru nke a iyi, ịdenye ugbu a ọrụ wakeup ma ọ bụrụ na uru bụ ma dị, na-alọta `None` ma ọ bụrụ na iyi bụ ike ọgwụgwụ.
    ///
    /// # Laghachi uru
    ///
    /// Enwere ọtụtụ ụkpụrụ ịlaghachi azụ, nke ọ bụla na-egosi ọkwa iyi dị iche:
    ///
    /// - `Poll::Pending` Ọ pụtara na uru iyi a na-esote erubeghị.Mmejuputa iwu ga-eme ka o doo anya na oru di ugbu a ga-amara gi ọkwa mgbe ogugu ozo n`abia di njikere.
    ///
    /// - `Poll::Ready(Some(val))` pụtara na iyi ahụ emeela nke ọma, `val`, ma nwee ike mepụta ụkpụrụ ọzọ na oku `poll_next` sochiri.
    ///
    /// - `Poll::Ready(None)` pụtara na iyi ahụ akwụsịla, na `poll_next` ekwesịghị ịkpọku ọzọ.
    ///
    /// # Panics
    ///
    /// Ozugbo a iyi ka okokụre (laghachi `Ready(None)` from `poll_next`), akpọ ya `poll_next` usoro ọzọ nwere ike panic, igbochi ruo mgbe ebighị ebi, ma ọ bụ na-akpata ọzọ di iche iche nke nsogbu; ndị `Stream` trait nsị dịghị chọrọ na mmetụta nke ndị dị otú ahụ a na oku.
    ///
    /// Otú ọ dị, dị ka ndị `poll_next` usoro a na-akara `unsafe`, Rust si emebu iwu ide: oku ga ọlị ime ka undefined omume (ebe nchekwa nrụrụ aka, na-ekwesịghị ịdị ojiji nke `unsafe` ọrụ, ma ọ bụ ndị dị ka), n'agbanyeghị nke iyi na-ala.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Laghachi ókè gafere ogologo iyi ahụ fọdụrụnụ.
    ///
    /// Kpọmkwem, `size_hint()` weghachite tuple ebe ihe mbụ bụ obere ala, ihe nke abụọ bụ elu.
    ///
    /// The ọkara nke abụọ nke tuple na-laghachi bụ ihe ['Option`]' <'[' usize`] '>'.
    /// A [`None`] ebe a n'aka na ma na e nwere mba mara elu agbụ, ma ọ bụ nke elu-agbụ ibu karịa [`usize`].
    ///
    /// # mmejuputa iwu-ndetu
    ///
    /// Enweghi mmanye mmanye na mmezu iyi na-amuta otutu ihe ekwuputara.Mmiri iyi na-adọkpụ nwere ike ịbelata obere ala ma ọ bụ karịa nke elu nke ihe.
    ///
    /// `size_hint()` na-isi bu n'obi ga-eji optimizations dị ka na-edebe ohere maka ndị ọcha nke miri-iyi, ma agaghị ike obi ka eg, hapụ idenye aha ókè-achọpụtazi na nwedịrị ike ịta koodu.
    /// Na-ekwesịghị ịdị mmejuputa `size_hint()` ghara iduga ebe nchekwa na nchekwa imebi.
    ///
    /// Nke ahụ kwuru, mmejuputa iwu kwesịrị inye atụmatụ ziri ezi, n'ihi na ọ bụghị na ọ ga-abụ mmebi nke usoro trait.
    ///
    /// Ndabara mmejuputa na-alaghachi ``(0, '[`` Ọ dịghị onye]]' ') nke ziri ezi maka iyi ọ bụla.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}