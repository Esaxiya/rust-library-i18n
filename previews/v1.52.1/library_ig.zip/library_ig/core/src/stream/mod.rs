//! Composable asynchronous iteration.
//!
//! Ọ bụrụ na futures bụ asynchronous ụkpụrụ, mgbe iyi asynchronous iterators.
//! Ọ bụrụ n'ịchọtala onwe gị n'ụdị ụdị asynchronous ụfọdụ, ma chọọ ịrụ ọrụ na ngwungwu nke nnakọta a, ị ga-agba ọsọ ọsọ na 'streams'.
//! Iyi na-kpamkpam eji n'akpaala okwu asynchronous Rust code, otú ọ bụ ọnụ ahịa na-aghọ maara na ha.
//!
//! Tupu na-akọwa ihe, ka okwu banyere otú nke a modul na-ahaziri:
//!
//! # Organization
//!
//! A na-ahazi usoro a site na ụdị:
//!
//! * [Traits] bụ isi òkè: ndị a traits kọwaa ụdị iyi adị na ihe ị pụrụ ime ha.Usoro nke traits ndị a bara uru itinye oge ọmụmụ ihe ọzọ.
//! * Ọrụ na-enye ụfọdụ ụzọ enyemaka iji mepụta ụfọdụ iyi.
//! * Structs na-abụkarị ụdị nloghachi nke ụzọ dị iche iche na traits nke modul a.Ị ga na-emekarị chọrọ anya na usoro na-emepụta `struct`, kama `struct` onwe ya.
//! Ihe zuru ezu banyere ihe mere, na-ahụ '[mmejuputa Stream](#mmejuputa-stream)'.
//!
//! [Traits]: #traits
//!
//! Ọ bụ ya!Ka anyị gwuo n'ime iyi.
//!
//! # Stream
//!
//! Obi na nkpuru obi nke modul a bu [`Stream`] trait.Isi nke [`Stream`] dị ka nke a:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! N'adịghị ka `Iterator`, `Stream` na-eme ka a dị iche n'etiti ndị [`poll_next`] usoro nke na-eji mgbe mmejuputa a `Stream`, na a (to-be-implemented) `next` usoro nke na-eji mgbe na-ewe a iyi.
//!
//! Bụghịkwa nke `Stream` na mkpa iji tụlee `next`, nke mgbe a na-akpọ, na-alaghachikwuru a future nke amịrị `Option<Stream::Item>`.
//!
//! The future laghachi site `next` ga-ekwenyere `Some(Item)` dị ka ogologo dị ka e nwere ọcha, na mgbe ha na-na na na niile e ndikpa mba, ga-ekwenyere `None` na-egosi na iteration na-okokụre.
//! Ọ bụrụ na anyị na-eche na ihe asynchronous iji dozie, future ga-echere ruo mgbe iyi ahụ dị njikere ịmị ọzọ.
//!
//! Mmiri nke ọ bụla nwere ike ịhọrọ ịmaliteghachi iteration, yabụ ịkpọ `next` ọzọ nwere ike ọ gaghị emesị nyeghachi `Some(Item)` oge ụfọdụ.
//!
//! Nkọwa zuru oke nke '' Stream` '' gụnyere ọtụtụ ụzọ ndị ọzọ, mana ha bụ usoro ndabara, wuru n'elu [`poll_next`], yabụ ị ga-enweta ha n'efu.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Mmejuputa Osimiri
//!
//! Mepụta mmiri nke gị gụnyere usoro abụọ: ịmepụta `struct` iji jide steeti iyi ahụ, wee mejuputa [`Stream`] maka `struct` ahụ.
//!
//! Ka a stream aha ya bụ `Counter` nke mkpa si `1` ka `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Nke mbụ, ihe gbasara ya:
//!
//! /// Iyi nke na-aguta site na otu rue ise
//! struct Counter {
//!     count: usize,
//! }
//!
//! // anyị chọrọ ka ọnụ ọgụgụ anyị bido n`otu, yabụ ka anyị tinye usoro new() iji nyere aka.
//! // Nke a adịchaghị mkpa, mana ọ dị mma.
//! // Cheta na anyị na-amalite `count` na efu, anyị ga-ahụ ihe mere na `poll_next()`'s mmejuputa n'okpuru.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Mgbe ahụ, anyị na-emejuputa `Stream` maka `Counter` anyị:
//!
//! impl Stream for Counter {
//!     // anyị ga-agụta na usize
//!     type Item = usize;
//!
//!     // poll_next() bụ naanị usoro achọrọ
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Mee ka ọnụ ọgụgụ anyị bawanye.Nke a bụ ihe mere anyị malitere na efu.
//!         self.count += 1;
//!
//!         // Lelee ka ị hụ ma anyị agụchaala ma ọ bụ na anyị agụchabeghị.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Iyi *umengwụ*.Nke a pụtara na naanị ịmepụta mmiri adịghị _do_ dum.Onweghi ihe na-eme ruo mgbe ị kpọrọ `next`.
//! Nke a na-abụ ihe mgbagwoju anya mgbe ụfọdụ mgbe ị na-emepụta mmiri naanị maka mmetụta ya.
//! Onye nchịkọta ahụ ga-adọ anyị aka ná ntị banyere ụdị omume a:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;