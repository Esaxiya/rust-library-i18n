//! The `Clone` trait maka ụdị na apụghị ịbụ 'obi kpamkpam depụtaghachiri'.
//!
//! Na Rust, ụfọdụ ụdị dị mfe bụ "implicitly copyable" na mgbe ị kenyere ha ma ọ bụ nyefee ha dị ka arụmụka, onye nata ga-enweta otu, na-ahapụ uru mbụ na ebe.
//! Typesdị ndị a anaghị achọ ka ekenye ha ka ha copyomie ma ha enweghị ndị na-eme ihe (yabụ, ha enweghị igbe ndị nwere ma ọ bụ mejuputa [`Drop`]), yabụ onye nchịkọta ahụ weere ha dị ọnụ ala ma dịkwa mma idetuo.
//!
//! N'ihi na ndị ọzọ na ụdị akwụkwọ ga-mere n'ụzọ doro anya, site ná mgbakọ mejuputa atumatu [`Clone`] trait na akpọ [`clone`] usoro.
//!
//! [`clone`]: Clone::clone
//!
//! Basic ojiji atụ:
//!
//! ```
//! let s = String::new(); // Dị eriri na-eme ka mmepụta oyiri
//! let copy = s.clone(); // n'ihi ya, anyị nwere ike mmepụta oyiri
//! ```
//!
//! Iji mejuputa Mmepụta oyiri trait, ị nwekwara ike iji `#[derive(Clone)]`.Ihe Nlereanya:
//!
//! ```
//! #[derive(Clone)] // anyị ịgbakwunye mmepụta oyiri trait ka Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ma ugbu a, anyị nwere ike mmepụta oyiri ya!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// A nkịtị trait maka ike n'ụzọ doro anya na oyiri ihe.
///
/// Si dị nnọọ iche [`Copy`] na na [`Copy`] bụ isịne na oké ọnụ, mgbe `Clone` bụ mgbe doro na nwere ike ma ọ ga-ada ọnụ.
/// Iji mezuo njirimara ndị a, Rust anaghị enye gị ohere ịmegharia [`Copy`], mana ịnwere ike weghachite `Clone` ma gbaa koodu adịghị mma.
///
/// Ebe `Clone` zuru oke karịa [`Copy`], ị nwere ike ịme ihe ọ bụla [`Copy`] ga-abụ `Clone` na-akpaghị aka.
///
/// ## Derivable
///
/// Nke a trait ike ga-eji na `#[derive]` ma ọ bụrụ na niile ubi bụ `Clone`.The 'derive`d mmejuputa [`Clone`] akpọ [`clone`] na onye ọ bụla ubi.
///
/// [`clone`]: Clone::clone
///
/// N'ihi na a ọnyà struct, `#[derive]` implements `Clone` dabere site na-agbakwụnye agbụ `Clone` na ọnyà kwa.
///
/// ```
/// // `derive` mejuputa Mmepụta oyiri maka Readinggụ ihe<T>mgbe T bụ mmepụta oyiri.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kedụ ka m ga-esi mejuputa `Clone`?
///
/// Ụdị ndị na-[`Copy`] kwesịrị nwere a na-adịchaghị mkpa, mmejuputa iwu nke `Clone`.Nhazi ọzọ:
/// ọ bụrụ `T: Copy`, `x: T`, na `y: &T`, mgbe ahụ `let x = y.clone();` yiri `let x = *y;`.
/// Ntinye akwụkwọ ntuziaka kwesịrị ịkpachara anya ịkwado onye a na-enweghị ike ịgbanwe agbanwe;Otú ọ dị, nwedịrị ike ịta koodu ga ịdabere na ya iji hụ na ebe nchekwa na nchekwa.
///
/// Otu ihe atụ bụ a ọnyà struct ejide a ọrụ pointer.N'okwu a, mmejuputa nke `Clone` enweghị ike `` nweta '', mana enwere ike itinye ya n'ọrụ dị ka:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Agbakwunyere na mmejuputa iwu
///
/// Na mgbakwunye na [implementors listed below][impls], ụdị ndị a na-etinye `Clone`:
///
/// * Itemdị ihe ọrụ (ya bụ, ụdị dị iche iche akọwapụtara maka ọrụ ọ bụla)
/// * Podị pointer na-arụ ọrụ (eg, `fn() -> i32`)
/// * Typesdị dị iche iche, maka nha niile, ma ọ bụrụ na ụdị ihe ahụ mejuputara `Clone` (dịka, `[i32; 123456]`)
/// * Tuple ụdị, ma ọ bụrụ na onye ọ bụla akụrụngwa nwekwara implements `Clone` (eg, `()`, `(i32, bool)`)
/// * Typesdị mmechi, ọ bụrụ na ha enwetaghị uru ọ bụla site na gburugburu ma ọ bụ ọ bụrụ na ụdị ụdị ejidere dị otú ahụ mejuputa `Clone` n'onwe ha.
///   Rịba ama na mgbanwe ndị ejidere site na ntinye aha na-emejuputa `Clone` mgbe niile (ọbụlagodi ma ọ bụrụ na onye na-edeghachi aha ya), ebe mgbanwe ndị ejidere na ntụgharị ederede enweghị ike itinye `Clone` n'ọrụ.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Weghachite otu uru.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str mejuputa oyiri
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Anamde idetuo-ọrụ si `source`.
    ///
    /// `a.clone_from(&b)` dakọtara na `a = b.clone()` na arụmọrụ, mana enwere ike ịgabiga iji jiri akụ nke `a` wee zere ịkekọrịta na-enweghị isi.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Nweta macro na-ewepụta ihe nke trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ndị a structs na-eji nanị site#[erite] ka na-ekwu na ọ bụla akụrụngwa nke a ụdị achụ nta mmepụta oyiri ọ bụ Copy.
//
//
// Usoro iwu ndị a agaghị apụta na koodu ọrụ.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ntinye nke `Clone` maka ụdị oge ochie.
///
/// Implementations na-apụghị kọwara Rust na-emejuputa atumatu na `traits::SelectionContext::copy_clone_conditions()` na `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Enwere ike ịkọwara mmadụ ọnụ, mana ntụgharị ngbanwe *enweghị ike*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Enwere ike ịkọwara mmadụ ọnụ, mana ntụgharị ngbanwe *enweghị ike*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}