// eleghara-dozie-filelength a file fọrọ nke nta nanị mejupụtara ndị definition nke `Iterator`.
// Anyị nwere ike awaghị na n'ime multiple faịlụ.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// An interface maka emeso iterators.
///
/// Nke a bụ isi iterator trait.
/// N'ihi na ihe banyere echiche nke iterators n'ozuzu, biko hụ [module-level documentation].
/// Karịsịa, ị pụrụ ịchọ ịmata otú [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// The ụdị ndị ọcha a na-iterated n'elu.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Na-aga n`ihu na ite ite na-abia ọzọ uru.
    ///
    /// Weghachite [`None`] mgbe agachara iteration.
    /// Onye iterator implementations nwere ike ịhọrọ maliteghachi iteration, na-akpọ `next()` ọzọ nwere ike ma ọ emecha na-amalite na-alọta [`Some(Item)`] ọzọ ụfọdụ ebe.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A oku na-aga next() laghachi ọzọ uru ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ma ọ dịghị onye ọ bụla ozugbo ọ gafere.
    /// assert_eq!(None, iter.next());
    ///
    /// // More oku nwere ike ma ọ laghachi `None`.Ebe a, ha na-ekpe.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Alaghachi ókè na ndị fọdụrụ ogologo nke iterator.
    ///
    /// Kpọmkwem, `size_hint()` weghachite tuple ebe ihe mbụ bụ obere ala, ihe nke abụọ bụ elu.
    ///
    /// The ọkara nke abụọ nke tuple na-laghachi bụ ihe ['Option`]' <'[' usize`] '>'.
    /// A [`None`] ebe a n'aka na ma na e nwere mba mara elu agbụ, ma ọ bụ nke elu-agbụ ibu karịa [`usize`].
    ///
    /// # mmejuputa iwu-ndetu
    ///
    /// Ọ na-adịghị manyere na ihe iterator mmejuputa iwu-amịrị ndị kwuru nọmba nke ọcha.A adọkpụ iterator pụrụ inweta ihe na-erughị ala-agbụ ma ọ bụ karịa nke elu-agbụ nke ọcha.
    ///
    /// `size_hint()` na-isi bu n'obi ga-eji optimizations dị ka na-edebe ohere maka ihe nke iterator, ma agaghị ike obi ka eg, hapụ idenye aha ókè-achọpụtazi na nwedịrị ike ịta koodu.
    /// Na-ekwesịghị ịdị mmejuputa `size_hint()` ghara iduga ebe nchekwa na nchekwa imebi.
    ///
    /// Nke ahụ kwuru, mmejuputa iwu kwesịrị inye atụmatụ ziri ezi, n'ihi na ọ bụghị na ọ ga-abụ mmebi nke usoro trait.
    ///
    /// The ndabere mmejuputa iwu-alaghachi '(0,' ['None`]') 'nke bụ eziokwu maka ihe ọ bụla iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// A ihe mgbagwoju atụ:
    ///
    /// ```
    /// // The ọbụna nọmba efu iri.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Anyị nwere ike iterate si efu ka ugboro iri.
    /// // Ebe ọ maara na ọ ise kpọmkwem gaghị ekwe omume na-enweghị ekpede filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ka anyị tinye ise ọzọ nọmba na chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ugbu a ma ókè na-amụba site na ise
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Iweghachi `None` maka eriri elu:
    ///
    /// ```
    /// // enweghi ngwụcha iterator enweghị elu agbụ na kacha ekwe omume ala ibikwa
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Erepịakwa ndị iterator, agụta ọnụ ọgụgụ iterations na-alọta ya.
    ///
    /// Usoro a ga-akpọ [`next`] ugboro ugboro rue mgbe [`None`] zutere, weghachite ugboro ole ọ hụrụ [`Some`].
    /// Cheta na [`next`] ka na-akpọ dịkarịa ala otu ugboro ọbụna ma ọ bụrụ iterator adịghị ihe ọ bụla dị n'eluigwe na ụwa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overflow Àgwà
    ///
    /// The usoro na-eme dịghị nche megide ọtọde, otú na-agụta ihe nke ihe iterator na ihe karịrị [`usize::MAX`] ọcha ma na-arụpụta ihe na-ezighị ezi n'ihi ma ọ bụ panics.
    ///
    /// Ọ bụrụ na debug assertions na-nyeere, a panic na-ekwe nkwa.
    ///
    /// # Panics
    ///
    /// Nke a ọrụ ike panic ma ọ bụrụ na ndị iterator nwere ihe karịrị [`usize::MAX`] ọcha.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Erepịakwa ndị iterator, alaghachi ikpeazụ mmewere.
    ///
    /// Nke a na usoro ga-enyocha iterator ruo mgbe ọ na-alaghachi [`None`].
    /// Mgbe na-eme otú ahụ, ọ na-eme soro nke ugbu a mmewere.
    /// Mgbe [`None`] na-laghachi, `last()` ga-atụgharị ikpeazụ mmewere ya hụrụ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Ọganihu nke iterator site `n` ọcha.
    ///
    /// Usoro a ga-atụsi ikwu `n` ọcha site na-akpọ [`next`] ruo `n` ugboro ruo mgbe [`None`] na-okosobode.
    ///
    /// `advance_by(n)` ga-alaghachi [`Ok(())`][Ok] ma ọ bụrụ na ndị iterator ọma Ọganihu site `n` ọcha, ma ọ bụ [`Err(k)`][Err] ma ọ bụrụ na [`None`] na-okosobode, ebe `k` bụ ọnụ ọgụgụ nke ndị ọcha na iterator bụ elu site n'ihu na-agba ọsọ nke ọcha (ie
    /// ogologo nke iterator).
    /// Rịba ama na `k` bụ mgbe ihe na-erughị `n`.
    ///
    /// Kpọ `advance_by(0)` anaghị eri ihe ọ bụla ma weghachite [`Ok(())`][Ok] mgbe niile.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // naanị `&4` e ọsọsọp
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Alaghachi na 'n`th mmewere nke iterator.
    ///
    /// Dị ka ọtụtụ indexing arụmọrụ, ọnụ na-amalite site efu, ya mere, `nth(0)` laghachi mbụ uru, `nth(1)` nke abụọ, na na na.
    ///
    /// Rịba ama na ihe niile bu ụzọ, yana ihe eji laghachi, ga-eri ya site na iterator.
    /// Nke ahụ pụtara na a ga-atụfu ihe ndị bu ụzọ, yana ịkpọku `nth(0)` ọtụtụ oge na otu iterator ga-alọghachi ihe dị iche iche.
    ///
    ///
    /// `nth()` ga-alaghachi [`None`] ma ọ bụrụ na `n` ukwuu ma ọ bụ hà ogologo nke iterator.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Akpọ `nth()` otutu ugboro anaghị weghachi ndị iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Iweghachi `None` ma ọ bụrụ na e nwere ihe na-erughị `n + 1` ọcha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Na-emepụta ihe iterator malite n'otu, ma na-abata site nyere ego na onye ọ bụla iteration.
    ///
    /// Note 1: The mbụ mmewere nke iterator ga-laghachiri, n'agbanyeghị nke nzọụkwụ nyere.
    ///
    /// Cheta 2: The oge na nke leghaara ọcha na-wetara bụ ofu.
    /// `StepBy` na-akpa agwa dị ka usoro `next(), nth(step-1), nth(step-1),…`, mana nwekwara onwe ya ịkpa agwa dị ka usoro ahụ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Kedu ụzọ na-eji nwere ike ịgbanwe ihe ụfọdụ iterators maka arụmọrụ ihe.
    /// Secondzọ nke abụọ ga-eme ka onye ahụ kwalite ya tupu oge eruo ma nwee ike iri ọtụtụ ihe.
    ///
    /// `advance_n_and_return_first` bụ Ẹkot:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// The usoro a ga panic ma ọ bụrụ na e nyere nzọụkwụ bụ `0`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Ewe abụọ iterators na-emepụta a ọhụrụ iterator n'elu ma na usoro.
    ///
    /// `chain()` ga-alaghachi a ọhụrụ iterator nke ga-akpa iterate n'elu ụkpụrụ si akpa iterator wee n'elu ụkpụrụ nke abụọ iterator.
    ///
    /// Na ọzọ okwu, ọ njikọ abụọ iterators ọnụ, na a yinye.🔗
    ///
    /// [`once`] na-ejikarị imeghari a otu uru n'ime a yinye ọzọ di iche iche nke iteration.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ebe ọ bụ na arụmụka ahụ na `chain()` na-eji [`IntoIterator`], anyị nwere ike ịgafe ihe ọ bụla nwere ike ịtụgharị gaa na [`Iterator`], ọ bụghị naanị [`Iterator`] n'onwe ya.
    /// Iji maa atụ, Mpekere (`&[T]`) mejuputa [`IntoIterator`], yabụ enwere ike ibufe ya na `chain()` ozugbo:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ọ bụrụ n'iji Windows API rụọ ọrụ, ị nwere ike ịchọọ [`OsStr`] ka `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips elu' abụọ iterators n'ime otu iterator nke abụọ.
    ///
    /// `zip()` laghachi a ọhụrụ iterator ga-enyefe karịrị abụọ ndị ọzọ iterators, na-alọghachi a tuple ebe mbụ mmewere si mbụ iterator, na ihe nke abụọ na-abịa site nke abụọ iterator.
    ///
    ///
    /// N'ikwu ya n'ụzọ ọzọ, ọ na-ezipụ ndị na-emegharị ihe abụọ ọnụ, n'otu.
    ///
    /// Ọ bụrụ na ma iterator laghachi [`None`], [`next`] si zipped iterator ga-alaghachi [`None`].
    /// Ọ bụrụ na ndị mbụ iterator laghachi [`None`], `zip` ga Egbubikwala na `next` agaghị na-akpọ nke abụọ iterator.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ebe ọ bụ na esemokwu na `zip()` eji [`IntoIterator`], anyị nwere ike gafee ọ bụla a pụrụ ghọọ [`Iterator`], ọ bụghị naanị ihe [`Iterator`] onwe ya.
    /// Ka ihe atụ, Mpekere (`&[T]`) mejuputa [`IntoIterator`], na otú nwere ike gafere ka `zip()` ozugbo:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` a na-eji na zip enweghi ngwụcha iterator ka a nwere oke otu.
    /// Nke a na-arụ ọrụ n'ihi na ndị nwere oke iterator ga-emecha laghachi [`None`], agwụcha mkpọchi uwe.Zipping na `(0..)` nwere ike ile anya a ọtụtụ dị ka [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Emepụta ọhụrụ iterator nke nsị a oyiri nke `separator` n'etiti n'akụkụ ihe nke mbụ iterator.
    ///
    /// Ọ bụrụ na `separator` anaghị mejuputa [`Clone`] ma ọ bụ mkpa na-agbakọrọ oge ọ bụla, na-eji [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Ihe mbụ sitere na `a`.
    /// assert_eq!(a.next(), Some(&100)); // The separator.
    /// assert_eq!(a.next(), Some(&1));   // The ọzọ mmewere si `a`.
    /// assert_eq!(a.next(), Some(&100)); // The separator.
    /// assert_eq!(a.next(), Some(&2));   // Ihe ikpeazụ si `a`.
    /// assert_eq!(a.next(), None);       // The iterator agwụla.
    /// ```
    ///
    /// `intersperse` pụrụ ịbụ nnọọ uru isonyere ihe iterator si ihe eji a nkịtị mmewere:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Emepụta ọhụrụ iterator nke nsị ihe item N'ịbụ `separator` n'etiti n'akụkụ ihe nke mbụ iterator.
    ///
    /// The mmechi ga-akpọ kpọmkwem mgbe oge ọ bụla ihe na-enịm n'etiti abụọ n'akụkụ ihe si akpata iterator;
    /// kpọmkwem, mmechi adịghị na-akpọ ma ọ bụrụ na isi iterator zaa erughị abụọ ihe na mgbe ikpeazụ item na-amịghịkwa.
    ///
    ///
    /// Ọ bụrụ na ndị iterator si item achụ nta [`Clone`], ọ pụrụ ịdị mfe iji [`intersperse`].
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // The mbụ mmewere si `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // The ọzọ mmewere si `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ihe ikpeazụ si na `v`.
    /// assert_eq!(it.next(), None);               // The iterator agwụla.
    /// ```
    ///
    /// `intersperse_with` ike ga-eji na ọnọdụ ebe ndị separator kwesịrị agbakọrọ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // The mmechi mutably agbaziri gbara ya gburugburu na-n'ịwa otu ihe.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Ewe a mmechi na-emepụta ihe iterator nke na-achọ na mmechi na onye ọ bụla mmewere.
    ///
    /// `map()` na-eme ka otu onye na-ede ya gbanwee ghọọ onye ọzọ, site n'arụmụka ya:
    /// ihe na-implements [`FnMut`].Ọ na-a ọhụrụ iterator nke na-akpọ nke a mmechi na onye ọ bụla mmewere nke mbụ iterator.
    ///
    /// Ọ bụrụ na ị bụ ezi na-eche echiche na ụdị, ị nwere ike na-eche nke `map()` dị ka nke a:
    /// Ọ bụrụ na ị nwere onye na-ekwu okwu nke na-enye gị ụdị nke ụdị `A` ụfọdụ, ma ịchọrọ onye ọzọ nke ụdị `B` ọzọ, ịnwere ike iji `map()`, na-agafe mmechi nke were `A` wee laghachi `B`.
    ///
    ///
    /// `map()` bụ echiche nke yiri a [`for`] akaghị.Otú ọ dị, dị ka `map()` bụ umengwụ, ọ na-kacha mma eji mgbe ị na-ama na-arụ ọrụ ndị ọzọ iterators.
    /// Ọ bụrụ na ị na-eme ụfọdụ ụdị looping maka a akụkụ mmetụta, ọ na-ewere ihe n'akpaala okwu iji [`for`] karịa `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ọ bụrụ na ị na-eme ụfọdụ ụdị akụkụ mmetụta, na-ahọrọ [`for`] ka `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // adịghị eme nke a:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ọ ga-adịghị ọbụna igbu, dị ka ọ bụ umengwụ.Rust ga adọ aka ná ntị banyere nke a.
    ///
    /// // Kama nke ahụ, na-eji maka:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kpọọ a mmechi na onye ọ bụla mmewere nke ihe iterator.
    ///
    /// Nke a bụ Ẹkot eji a [`for`] loop na iterator, ọ bụ ezie `break` na `continue`-agaghị ekwe omume site na a mmechi.
    /// Ọ bụ n'ozuzu ọzọ n'akpaala okwu iji a `for` loop, ma `for_each` nwere ike ịbụ ihe ọzọ ke ngutali mgbe nhazi ihe na njedebe nke ogologo iterator ígwè.
    ///
    /// Mgbe ụfọdụ `for_each` nwekwara ike ịdị na-agbakarị a akaghị, n'ihi na ọ ga-eji esịtidem iteration on nkwụnye ka `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// N'ihi na ndị dị otú ahụ a obere atụ, a `for` loop nwere ike Cleaner, ma `for_each` pụrụ ịbụ mma na-a ọtọ style na ogologo iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Na-emepụta ihe iterator nke na-eji a mmechi iji chọpụta ma ọ bụrụ na ihe mmewere ga-amịghịkwa.
    ///
    /// Nyere mmewere mmechi ga-alọghachi `true` ma ọ bụ `false`.The laghachi iterator ga-ekwenyere naanị ndị ọcha n'ihi na nke mmechi laghachi eziokwu.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// N'ihi na mmechi ahụ gafere `filter()` na-ewere ntụaka, na ọtụtụ ndị na-emegharị ihe na-atụgharị aka karịa, nke a na-eduga n'ọnọdụ nwere ike ịme mgbagwoju anya, ebe ụdị mmechi ahụ bụ ntụaka abụọ:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // chọrọ abụọ * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ọ nkịtị ka kama iji destructuring na esemokwu iyipu pụọ otu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ma&na *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ma ọ bụ ma:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // abụọ &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// nke n'ígwé ndị a.
    ///
    /// Rịba ama na `iter.filter(f).next()` bụ Ẹkot `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Na-emepụta ihe iterator na ma nzacha na map.
    ///
    /// Onye na-edeghachi ihe azụ laghachiri naanị `` uru '' nke njedebe mmechi weghachiri `Some(value)`.
    ///
    /// `filter_map` nwere ike ji mee ka n'agbụ nke [`filter`] na [`map`] ọzọ nkenke.
    /// The atụ n'okpuru na-egosi otú a `map().filter().map()` nwere ike shortened ka a otu oku `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ebe a bụ otu ihe atụ, ma na [`filter`] na [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Na-emepụta ihe iterator nke na-enye ugbu a iteration ọnụ nakwa dị ka na-esote uru.
    ///
    /// The iterator laghachi zaa ụzọ abụọ `(i, val)`, ebe `i` bụ ugbu a index nke iteration na `val` bụ uru laghachi site iterator.
    ///
    ///
    /// `enumerate()` na-eme ka ọnụ ọgụgụ ya dị ka [`usize`].
    /// Ọ bụrụ na ị chọrọ ịgụ site a dị iche iche sized integer, na [`zip`] ọrụ na-enye yiri arụmọrụ.
    ///
    /// # Overflow Àgwà
    ///
    /// The usoro na-eme dịghị izere ọtọde, otú depụtasịrị karịa [`usize::MAX`] ọcha ma na-arụpụta ihe na-ezighị ezi n'ihi ma ọ bụ panics.
    /// Ọ bụrụ na debug assertions na-nyeere, a panic na-ekwe nkwa.
    ///
    /// # Panics
    ///
    /// The laghachi iterator nwere ike panic ma ọ bụrụ na ndị na-ike-laghachi index ga-erubiga a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Na-emepụta ihe iterator nke nwere ike iji [`peek`] ka anya na-esote mmewere nke iterator enweghị ewe ya.
    ///
    /// Na-agbakwụnye, a [`peek`] usoro ihe iterator.Lee ya akwụkwọ maka ozi ndị ọzọ.
    ///
    /// Note na-apụtaghị ìhè na iterator ka na merela agadi mgbe [`peek`] a na-akpọ nke mbụ: Iji weghachite ọzọ mmewere, [`next`] a na-akpọ na-apụtaghị ìhè na iterator, n'ihi ya ọ bụla mmetụta (ie
    ///
    /// ọ bụla ọzọ karịa ikutere ọzọ uru) nke [`next`] usoro ga-eme.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ahapụ anyị ịhụ n'ime future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // anyị nwere ike peek() otutu ugboro, ndị iterator agaghị tupu
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // mgbe iterator na-okokụre, otú peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Na-emepụta ihe iterator na ['skip`] s ọcha dabeere na a predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` na-ewere mmechi dị ka esemokwu.Ọ ga-akpọ nke a mmechi na onye ọ bụla mmewere nke iterator, ma na-eleghara ihe ruo mgbe ọ na-alaghachi `false`.
    ///
    /// Mgbe `false` na-laghachi, `skip_while()`'s ọrụ dị n'elu, na ndị ọzọ nke ọcha na-amịghịkwa.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// N'ihi na mmechi ebe `skip_while()` ewe a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, nke a na-eduga a ikekwe anya ọnọdụ, ebe ụdị nke mmechi arumaru a abụọ akwụkwọ:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // chọrọ abụọ * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kwụsị mgbe mbụ `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // mgbe nke a gaara ụgha, ebe ọ bụ na anyị na-ama nwetara a ụgha, skip_while() adịghị mee ihe ọ bụla ọzọ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Na-emepụta ihe iterator na zaa ọcha dabeere na a predicate.
    ///
    /// `take_while()` na-ewere mmechi dị ka esemokwu.Ọ ga-akpọ nke a mmechi na onye ọ bụla mmewere nke iterator, ma na-ekwe ihe mgbe ọ na-alaghachi `true`.
    ///
    /// Mgbe `false` na-laghachi, `take_while()`'s ọrụ dị n'elu, na ndị ọzọ nke ọcha na-eleghara anya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// N'ihi na mmechi ebe `take_while()` ewe a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, nke a na-eduga a ikekwe anya ọnọdụ, ebe ụdị nke mmechi bụ a abụọ akwụkwọ:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // chọrọ abụọ * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kwụsị mgbe mbụ `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Anyị nwere ọtụtụ ihe ọcha na ndị na-erughị karịa efu, ma ebe ọ bụ na anyị na-ama nwetara a ụgha, take_while() adịghị mee ihe ọ bụla ọzọ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// N'ihi `take_while()` kwesịrị anya na uru iji hụ ma ọ bụrụ na ọ ga-gụnyere ma ọ bụ, na-ewe iterators ga-ahụ na ọ na-ewepụ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` anọghịzi, n'ihi na a na-ere ya iji hụ ma ọ bụrụ na ịghaghachi azụ kwesịrị ịkwụsị, mana etinyeghị ya n'ime iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Na-emepụta onye na-ekwu okwu nke na-ewepụta ihe dabere na amụma na eserese.
    ///
    /// `map_while()` na-ewere mmechi dị ka esemokwu.
    /// Ọ ga-akpọ nke a mmechi na onye ọ bụla mmewere nke iterator, ma na-ekwe ihe mgbe ọ na-alaghachi [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lee otu ihe atụ, mana ya na [`take_while`] na [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kwụsị mgbe mbụ [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Anyị nwere ọtụtụ ihe ọcha nke nwere ike dabara na u32 (4, 5), ma `map_while` laghachi `None` maka `-3` (dị ka `predicate` laghachi `None`) na `collect` akwụsị na mbu `None` okosobode.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// N'ihi `map_while()` kwesịrị anya na uru iji hụ ma ọ bụrụ na ọ ga-gụnyere ma ọ bụ, na-ewe iterators ga-ahụ na ọ na-ewepụ:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `-3` bụ agaghịkwa e, n'ihi na ọ bụ iwesa iji hụ ma ọ bụrụ na ndị iteration kwesịrị ịkwụsị, ma e enịm azụ n'ime iterator.
    ///
    /// Rịba ama na n'adịghị ka [`take_while`] a iterator bụ **bụghị** fused.
    /// Ọ na-akọwapụtaghị ihe a iterator alaghachi mgbe mbụ [`None`] na-laghachi.
    /// Ọ bụrụ na ị mkpa gwakọtara iterator, iji [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Na-emepụta ihe iterator na skips mbụ `n` ọcha.
    ///
    /// Mgbe ha na e gwusiri, na ike nke ọcha na-amịghịkwa.
    /// Kama imebi usoro a ozugbo, kama kpochapụ usoro `nth`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Na-emepụta ihe iterator na-amịrị ya mbụ `n` ọcha.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` a na-eji na enweghi ngwụcha iterator, ime ya oke:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ọ bụrụ na ihe na-erughị `n` ọcha dị, `take` ga-amachi ya na nke nke kpatara iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ihe ntinye ihe eji eme ihe dika [`fold`] nke na ejide steeti ma weputa ihe omuma ohuru.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ewe abụọ arụmụka: mbụ uru nke osisi esịtidem ala, na a mmechi na abụọ arụmụka, mbụ ịbụ a mutable banyere esịtidem ala na nke-abua ihe iterator mmewere.
    ///
    /// The mmechi nwere ike ekenye esịtidem ala ka òkè ala n'etiti iterations.
    ///
    /// On iteration, mmechi ga-etinyere na onye ọ bụla mmewere nke iterator na nloghachi uru site mmechi, ihe [`Option`], na-amịghịkwa site iterator.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // onye ọ bụla iteration, anyị ga ba uba na ala site na mmewere
    ///     *state = *state * x;
    ///
    ///     // mgbe ahụ, anyị ga-ekwenye na ekwenyeghị na steeti
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Na-emepụta ihe iterator na-arụ ọrụ dị ka map, ma bibie kpara akwụ Ọdịdị.
    ///
    /// The [`map`] nkwụnye bụ nnọọ uru, ma ọ bụ naanị mgbe mmechi esemokwu na-arụpụta ihe.
    /// Ọ bụrụ na ọ na-arụpụta ihe iterator kama, e nwere bụ onye amara oyi akwa nke indirection.
    /// `flat_map()` ga-ewepu akwa a ozo n`onwe ya.
    ///
    /// I nwere ike na-eche nke `flat_map(f)` dị ka ọmụmụ gbasara asụsụ Ẹkot ['map`] ping, na mgbe [' flatten`] u ka na `map(f).flatten()`.
    ///
    /// Ụzọ ọzọ nke na-eche banyere `flat_map()`: ['map`]' s mmechi alaghachi otu ihe maka onye ọ bụla mmewere, na `flat_map()`'s mmechi alaghachi ihe iterator maka onye ọ bụla mmewere.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() laghachi onye iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Emepụta iterator na flattens nested structure.
    ///
    /// Nke a bụ bara uru mgbe ị na-enwe ihe iterator nke iterators ma ọ bụ ihe iterator nke ihe na nwere ike ghọọ iterators na ị chọrọ iji wepu otu larịị nke indirection.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Nkewa na mgbe abadaba:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() laghachi onye iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// I nwekwara ike ideghari a na okwu nke [`flat_map()`], nke ka mma na nke a ebe ọ bụ na-egosi nzube ọzọ n'ụzọ doro anya:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() laghachi onye iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Abadaba naanị ewepu otu larịị nke nesting na a oge:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// N'ebe a, anyị na-ahụ na `flatten()` anaghị ịrụ a "deep" iha aha.
    /// Kama nke ahụ, naanị otu larịị nke nesting na-ewepụ.Nke ahụ bụ, ọ bụrụ na ị `flatten()` a atọ akụkụ n'usoro, n'ihi abụọ ga na-akụkụ na-adịghị otu onye akụkụ.
    /// Iji nweta a otu akụkụ Ọdịdị, i nwere na-`flatten()` ọzọ.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Na-emepụta ihe iterator nke na-agwụ mgbe mbụ [`None`].
    ///
    /// Mgbe onye nyocha laghachiri [`None`], oku future nwere ike ọ gaghị ewepụta [`Some(T)`] ọzọ.
    /// `fuse()` adapts ihe iterator, huu na mgbe a [`None`] e nyere, ọ ga-mgbe nile laghachi [`None`] ruo mgbe ebighị ebi.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ihe iterator nke alternates n'etiti Ụfọdụ na Ọ dịghị onye
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ma ọ bụrụ na ọ bụ ọbụna, Some(i32), ọzọ Ọ dịghị onye
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // anyị pụrụ ịhụ anyị iterator na-aga
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Otú ọ dị, anyị ozugbo anyị gwakọta ya ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ọ ga-mgbe nile laghachi `None` mgbe mbụ oge.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ihe na onye ọ bụla mmewere nke ihe iterator, agafe uru on.
    ///
    /// Mgbe na-eji iterators, ị ga na-yinye ọtụtụ n'ime ha ọnụ.
    /// Na-arụ ọrụ dị otú ahụ koodu, ị pụrụ iji lelee ihe na-eme na akụkụ dị iche iche na mmetụta dị aṅaa.Ime na, fanye a oku ka `inspect()`.
    ///
    /// Ọ bụ ihe nkịtị maka `inspect()` na-eji dị a debugging ngwá ọrụ karịa adị ke ikpeazụ unu koodu, ma ngwa nwere ike ịhụ na ọ bara uru na ọnọdụ ụfọdụ mgbe njehie mkpa ka a wee banye tupu e tụfuo.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // a iterator usoro bụ mgbagwoju.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ka tinye ụfọdụ inspect() oku ichoputa ihe na-eme
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Nke a ga-ebipụta:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Na-egbu osisi na njehie n'ihu tụfuo ha:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Nke a ga-ebipụta:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Na-emebi iterator, karịa iri ya.
    ///
    /// Nke a bara uru iji kwe ka itinye ndị na-emegharị iterator ka na-ejigide nwe nke mbụ iterator.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ọ bụrụ na anyị nwaa iji ya ọzọ, ọ gaghị arụ ọrụ.
    /// // Ndị na-esonụ akara enye "njehie: ojiji nke kpaliri uru: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ka na-agbalị na ọzọ
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // kama, anyị tinye na a .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ugbu a na nke a bụ nnọọ mma:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Agbanwe ihe iterator n'ime a collection.
    ///
    /// `collect()` nwere ike ọ bụla iterable, na-atụgharị ya a mkpa collection.
    /// Nke a bụ otu n'ime usoro siri ike karị n'ọbá akwụkwọ ọkọlọtọ, nke eji na ọnọdụ dị iche iche.
    ///
    /// Ihe ndị kasị mkpa ụkpụrụ nke `collect()` na-eji bụ gbanwee otu collection n'ime ọzọ.
    /// Were nchịkọta, kpọọ [`iter`] na ya, mee ụyọkọ mgbanwe, wee jiri `collect()` na njedebe.
    ///
    /// `collect()` nwekwara ike ike ihe nke ụdị ndị na-adịghị ahụkarị ịnakọta.
    /// Dị ka ihe atụ, a [`String`] nwere ike wuru si ['char`] s, na ihe iterator nke [`Result<T, E>`][`Result`] ihe nwere ike ikpokọta n'ime `Result<Collection<T>, E>`.
    ///
    /// Hụ ihe atụ n'okpuru maka ndị ọzọ.
    ///
    /// N'ihi `collect()` bụ otú ofụri ofụri, ọ nwere ike ime ka nsogbu na ụdị inference.
    /// Dị ka ndị dị otú ahụ, `collect()` bụ otu n'ime ugboro ole na ole ị ga-ahụ syntax ịhụnanya mara ya dị ka 'turbofish': `::<>`.
    /// Nke a na-enyere ndị inference algọridim ịghọta kpọmkwem nke collection ị na-agbalị na-anakọta n'ime.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Cheta na anyị mkpa na `: Vec<i32>` na n'aka ekpe n'akụkụ.Nke a bụ n'ihi na anyị nwere ike na-anakọta n'ime ka ihe atụ, a [`VecDeque<T>`] kama:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Iji 'turbofish' kama annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// N'ihi `collect()` naanị na-eche banyere ihe ị na-achịkọta n'ime, ị nwere ike ka na-eji a ele mmadụ anya n'ihu ụdị ndumodu, `_`, na turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Iji `collect()` mee [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ọ bụrụ na ị nwere ndepụta nke [`Nsonaazụ<T, E>'][`` N'ihi' 's, ị nwere ike iji `collect()` iji hụ ma ọ bụrụ na onye ọ bụla n'ime ha ada:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // na-enye anyị njehie mbụ
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // na-enye anyị ndepụta azịza
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Erepịakwa ihe iterator, eke abụọ collections site na ya.
    ///
    /// The predicate ebe `partition()` ike ịlaghachi `true`, ma ọ bụ `false`.
    /// `partition()` laghachi a ụzọ, ihe niile nke ndị ọcha nke na ọ laghachi `true`, na ihe nile nke ndị ọcha nke na ọ laghachi `false`.
    ///
    ///
    /// Lee nwekwara [`is_partitioned()`] na [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders ọcha nke a iterator *na-ebe* dị ka nyere predicate, dị otú ahụ na ndị niile na nloghachi `true` ebu ndị niile na nloghachi `false`.
    ///
    /// Alaghachi ọnụ ọgụgụ nke `true` ọcha hụrụ.
    ///
    /// The ikwu iji nke partitioned ihe na-adịghị nọgidere na-enwe.
    ///
    /// Lee nwekwara [`is_partitioned()`] na [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Nkebi na-ebe n'etiti evens na emegide
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ka anyị kwesịrị iche banyere ọnụ oké?Nanị ụzọ nwere ihe karịrị
        // `usize::MAX` Ntughari ntụgharị nwere ZST, nke na-abaghị uru nkewa ...

        // A mmechi "factory" ọrụ adị zere genericity na `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Ugboro ugboro chọta mbụ `false` na gbanwee ya na nke ikpeazụ `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na ndị ọcha nke a iterator na-partitioned dị ka nyere predicate, dị otú ahụ na ndị niile na nloghachi `true` ebu ndị niile na nloghachi `false`.
    ///
    ///
    /// Lee nwekwara [`partition()`] na [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ma ihe niile na-anwale `true`, ma ọ bụ ndị mbụ nkebiahiri akwụsị na `false` na anyị chọpụta na e nweghị ihe `true` ihe mgbe na.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator usoro na-emetụta a ọrụ dị ka ogologo dị ka ọ na-alaghachi ịga nke ọma, na-amị a otu, ikpeazụ uru.
    ///
    /// `try_fold()` ewe abụọ arụmụka: mbụ uru, na a mmechi na abụọ arụmụka: ihe 'accumulator', na ihe mmewere.
    /// The mmechi ma alaghachi ịga nke ọma, na-uru na accumulator kwesịrị nwere maka ọzọ iteration, ma ọ bụ na ọ na-alaghachikwuru ọdịda, na njehie uru na-propagated azụ nke bere ozugbo (short-circuiting).
    ///
    ///
    /// The mbụ uru bụ uru na accumulator ga nwere na mbụ na-akpọ oku.Ọ bụrụ na ime ihe mmechi n'ọnọdu megide bụla mmewere nke iterator, `try_fold()` laghachi ikpeazụ accumulator dị ka ihe ịga nke ọma.
    ///
    /// Ịkpakọba bụ bara uru mgbe ọ bụla i nwere a collection of ihe, ma na-achọ imepụta otu uru site na ya.
    ///
    /// # Rịba ama ndị na-arụ ọrụ
    ///
    /// Ọtụtụ nke ọzọ (forward) ụzọ nwere ndabere implementations na okwu nke onye a, ya mere, na-agbalị ime eme nke a n'ụzọ doro anya na ọ bụrụ na ọ nwere ike ime ihe dị mma karịa ndabara `for` loop mmejuputa.
    ///
    /// Akpan akpan, na-agbalị ka a oku na-aga `try_fold()` na esịtidem akụkụ nke a iterator emi esịnede.
    /// Ọ bụrụ na multiple oku na-mkpa, na `?` ọrụ nwere ike ịbụ adaba n'ihi chaining na accumulator uru tinyere, ma lezie anya ọ bụla invariants mkpa ịnọgide na-agbaso n'ihu ndị n'oge alaghachi.
    /// Nke a bụ a `&mut self` usoro, otú iteration kwesịrị ịbụ resumable mgbe ọkụkụ njehie ebe a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // na-enyocha nchikota nke niile ọcha nke na n'usoro
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Mkpokọta a na-ejupụta mgbe ị na-agbakwunye ihe 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // N'ihi na ọ na-adịghị circuited, fọdụrụ ọcha bụ ka dị site iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator usoro na-emetụta a ikom na-ezughị ọrụ na-onye ọ bụla ihe na iterator, nkwụsị na mbụ njehie na-alọta na njehie.
    ///
    ///
    /// Enwere ike iche na nke a dị ka ụdị ọdịda [`for_each()`] ma ọ bụ ụdị [`try_fold()`] enweghị steeti.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ọ na-adịghị circuited, otú ahụ fọdụrụ ihe ka nọ iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Ogige ọ bụla mmewere n'ime ihe accumulator site n'itinye ihe ọrụ, na-alọta ikpeazụ N'ihi.
    ///
    /// `fold()` ewe abụọ arụmụka: mbụ uru, na a mmechi na abụọ arụmụka: ihe 'accumulator', na ihe mmewere.
    /// The mmechi laghachi uru na accumulator kwesịrị nwere maka ọzọ iteration.
    ///
    /// The mbụ uru bụ uru na accumulator ga nwere na mbụ na-akpọ oku.
    ///
    /// Mgbe itinye a mmechi ka ọ bụla mmewere nke iterator, `fold()` laghachi na accumulator.
    ///
    /// Nke a na ime ihe na-akpọ mgbe ụfọdụ 'reduce' ma ọ bụ 'inject'.
    ///
    /// Ịkpakọba bụ bara uru mgbe ọ bụla i nwere a collection of ihe, ma na-achọ imepụta otu uru site na ya.
    ///
    /// Note: `fold()`, na usoro ndị yiri ya nke na-agafe ihe niile edepụtara, nwere ike ọ gaghị akwụsị maka ndị na-enweghị ngwụcha na-enweghị njedebe, ọbụlagodi na traits nke nsonaazụ ya bụ nke nwere oke oke.
    ///
    /// Note: [`reduce()`] ike ga-eji na-eji nke mbụ mmewere dị ka mbụ uru, ma ọ bụrụ na ndị accumulator ụdị na item ụdị bụ otu ihe.
    ///
    /// # Rịba ama ndị na-arụ ọrụ
    ///
    /// Ọtụtụ nke ọzọ (forward) ụzọ nwere ndabere implementations na okwu nke onye a, ya mere, na-agbalị ime eme nke a n'ụzọ doro anya na ọ bụrụ na ọ nwere ike ime ihe dị mma karịa ndabara `for` loop mmejuputa.
    ///
    ///
    /// Akpan akpan, na-agbalị ka a oku na-aga `fold()` na esịtidem akụkụ nke a iterator emi esịnede.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // nchikota ihe nile nke usoro a
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ka ije site onye ọ bụla nzọụkwụ nke iteration ebe a:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ya mere, anyị ikpeazụ N'ihi ya, `6`.
    ///
    /// Ọ bụ ndị mmadụ na onye na-eji iterators a ọtụtụ iji a `for` loop na a ndepụta nke ihe ndị na-ewuli elu a N'ihi.Ndị nwere ike ghọọ `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // maka loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ha na-na otu
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ebelata ọcha a otu otu, site ugboro ugboro n'itinye a mbenata ọrụ.
    ///
    /// Ọ bụrụ na iterator bụ ihe efu, laghachi [`None`];ma ọ bụghị, weghachite nsonaazụ nke mbelata ahụ.
    ///
    /// N'ihi iterators na ọ dịkarịa ala otu mmewere, nke a bụ otu ihe ahụ dị ka [`fold()`] mbụ mmewere nke iterator dị ka mbụ uru, mpịachi ọ bụla ụdi mmewere n'ime ya.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Chọta karịa ogo uru:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Ule ma ọ bụrụ na akụkụ ọ bụla nke iterator kwekọrọ na prediate.
    ///
    /// `all()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.Ọ na-emetụta mmechi a na ihe ọ bụla nke iterator, ọ bụrụ na ha niile laghachiri `true`, yabụ `all()` na-emekwa.
    /// Ọ bụrụ na ọ bụla n'ime ha laghachi `false`, ọ laghachi `false`.
    ///
    /// `all()` dị mkpụmkpụ-circuiting;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo ọ hụrụ a `false`, nyere na n'agbanyeghị ihe ọzọ na-eme, nsonaazụ ga-abụ `false`.
    ///
    ///
    /// Ihe efu iterator laghachi `true`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Nkwụsị na mbụ `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Ule ma ọ bụrụ na ọ bụla mmewere nke iterator ọkụ a predicate.
    ///
    /// `any()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.Ọ na-emetụta mmechi a na ihe ọ bụla nke iterator, ma ọ bụrụ na onye ọ bụla n'ime ha laghachiri `true`, yabụ `any()` laghachiri.
    /// Ọ bụrụ na ha niile laghachiri `false`, ọ laghachiri `false`.
    ///
    /// `any()` bẹ mkpụkpu-a;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo ọ chọtara a `true`, nyere na n'agbanyeghị ihe ọzọ na-eme, ọ ga-abụ `true`.
    ///
    ///
    /// Ihe efu iterator laghachi `false`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Nkwụsị na `true` mbụ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Searches maka ihe mmewere nke ihe iterator na afọ a predicate.
    ///
    /// `find()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.
    /// Ọ na-emetụta nke a mmechi ka onye ọ bụla mmewere nke iterator, na ọ bụrụ na ihe ọ bụla nke ha laghachi `true`, mgbe ahụ, `find()` laghachi [`Some(element)`].
    /// Ọ bụrụ na ha niile laghachi `false`, ọ laghachi [`None`].
    ///
    /// `find()` bẹ mkpụkpu-a;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo na-emechi emechi laghachi `true`.
    ///
    /// N'ihi `find()` ewe a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, nke a na-eduga a ikekwe anya n'ọnọdụ ebe arumaru a abụọ akwụkwọ.
    ///
    /// Ị pụrụ ịhụ nke a pụrụ isi kwuo na ihe atụ ndị dị n'okpuru, na `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Nkwụsị na `true` mbụ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Rịba ama na `iter.find(f)` bụ Ẹkot `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Emetụta ọrụ na-ọcha nke iterator na-alaghachikwuru mbụ na-abụghị onye ọ bụla N'ihi.
    ///
    ///
    /// `iter.find_map(f)` bụ Ẹkot `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Emetụta ọrụ na-ọcha nke iterator na-alaghachikwuru mbụ ezi n'ihi ma ọ bụ ndị mbụ njehie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Searches maka ihe mmewere na iterator, alaghachi ya index.
    ///
    /// `position()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.
    /// Ọ na-emetụta nke a mmechi ka onye ọ bụla mmewere nke iterator, na ọ bụrụ na otu n'ime ha na-alaghachi `true`, mgbe ahụ, `position()` laghachi [`Some(index)`].
    /// Ọ bụrụ na ha nile laghachi `false`, ọ laghachi [`None`].
    ///
    /// `position()` dị mkpụmkpụ-circuiting;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo ọ chọtara a `true`.
    ///
    /// # Overflow Àgwà
    ///
    /// The usoro na-eme dịghị nche megide ọtọde, ma ọ bụrụ na e nwere karịa [`usize::MAX`]-abụghị kenha ọcha, ọ ma na-arụpụta ihe na-ezighị ezi n'ihi ma ọ bụ panics.
    ///
    /// Ọ bụrụ na debug assertions na-nyeere, a panic na-ekwe nkwa.
    ///
    /// # Panics
    ///
    /// Nke a ọrụ ike panic ma ọ bụrụ na ndị iterator nwere ihe karịrị `usize::MAX`-abụghị kenha ọcha.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Nkwụsị na `true` mbụ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // The laghachi index adabere iterator ala
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Searches maka ihe mmewere na iterator si nri, na-alọta ya index.
    ///
    /// `rposition()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.
    /// Ọ na-emetụta nke a mmechi ka onye ọ bụla mmewere nke iterator, malite na ọgwụgwụ, na ọ bụrụ na otu n'ime ha na-alaghachi `true`, mgbe ahụ, `rposition()` laghachi [`Some(index)`].
    ///
    /// Ọ bụrụ na ha nile laghachi `false`, ọ laghachi [`None`].
    ///
    /// `rposition()` dị mkpụmkpụ-circuiting;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo ọ chọtara a `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Nkwụsị na `true` mbụ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ọ dịghị mkpa maka nile ịlele ebe a, n'ihi na `ExactSizeIterator` na-egosi na ọnụ ọgụgụ nke ndị ọcha ọkụ n'ime a `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Alaghachi kacha mmewere nke ihe iterator.
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha, ndị ikpeazụ mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Ologhachi kacha nta mmewere nke iterator.
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha nta, akpa mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Weghachite mmewere nke na-enye oke kachasị na ọrụ akọwapụtara.
    ///
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha, ndị ikpeazụ mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Alaghachi mmewere na-enye karịa ogo uru na-akwanyere ndị kwuru kpọmkwem tụnyere ọrụ.
    ///
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha, ndị ikpeazụ mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Weghachi mmewere nke na-enye opekempe uru site na ọrụ akọwapụtara.
    ///
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha nta, akpa mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Alaghachi mmewere nke na-enye nke kacha nta uru na-akwanyere ndị kwuru kpọmkwem tụnyere ọrụ.
    ///
    ///
    /// Ọ bụrụ na ọtụtụ ọcha bụ dokwara kacha nta, akpa mmewere na laghachi.
    /// Ọ bụrụ na iterator bụ ihe efu, [`None`] laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ndakpọ ihe iterator ntụziaka.
    ///
    /// Emekarị, iterators iterate site n'aka ekpe gaa n'aka nri.
    /// Mgbe iji `rev()`, ihe iterator ga kama iterate si ikike ekpe.
    ///
    /// Nke a bụ nanị kwe omume ma ọ bụrụ na ndị iterator nwere njedebe, ka `rev()` na-arụ ọrụ na ['DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Atọghata ihe iterator nke abụọ abụọ a ụzọ nke containers.
    ///
    /// `unzip()` erepịakwa ihe dum iterator nke ụzọ abụọ, na-amị abụọ collections: onye si ekpe ọcha nke ụzọ abụọ, na otu onye si nri ọcha.
    ///
    ///
    /// Ọrụ a bụ, na ụfọdụ uche, onye na-abụghị nke [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Na-emepụta ihe iterator nke mbipụta ya nile ọcha.
    ///
    /// Nke a bụ bara uru mgbe ị na-enwe ihe iterator n'elu `&T`, ma, ị chọrọ onye iterator n'elu `T`.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copied bụ otu ihe ahụ dị ka .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Na-emepụta ihe iterator nke ['clone`] s niile ya ọcha.
    ///
    /// Nke a bụ bara uru mgbe ị na-enwe ihe iterator n'elu `&T`, ma, ị chọrọ onye iterator n'elu `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned bụ otu ihe ahụ dị ka .map(|&x| x), maka integers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Akuko ihe iterator n'akwụsịghị akwụsị.
    ///
    /// Kama nkwụsị na [`None`], na iterator ga kama amalite ọzọ, site ná mmalite.Mgbe iterating ọzọ, ọ ga-amalite na mmalite ọzọ.Na ọzọ.
    /// Na ọzọ.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Na-agukọta ihe dị iche iche nke iterator.
    ///
    /// Ewe onye ọ bụla mmewere, kwukwara, sị ha ọnụ, na-alaghachikwuru N'ihi.
    ///
    /// Ihe efu iterator laghachi efu uru nke ụdị.
    ///
    /// # Panics
    ///
    /// Mgbe akpọ `sum()` na a oge ochie integer ụdị a na-laghachi, usoro a ga-panic ma ọ bụrụ mgbakọ ọtọde na debug assertions na-nyeere.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates n'elu dum iterator, amụba niile ọcha
    ///
    /// Ihe efu iterator laghachi onye uru nke ụdị.
    ///
    /// # Panics
    ///
    /// Mgbe a na-akpọ `product()` na ụdị integer oge ochie ka eweghachitere, usoro ga-panic ma ọ bụrụ na agbakọjupụtara ngụkọta na mwepu nkwenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) tụnyere ndị ọcha nke a [`Iterator`] na ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) na-atụle ihe nke [`Iterator`] a na nke nke ọzọ n'ihe gbasara ọrụ ntụnyere akọwapụtara.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) tụnyere ndị ọcha nke a [`Iterator`] na ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) na-atụle ihe nke [`Iterator`] a na nke nke ọzọ n'ihe gbasara ọrụ ntụnyere akọwapụtara.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] hà ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] hà ndị nke ọzọ na-akwanyere ndị kwuru kpọmkwem hara nhata ọrụ.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] bụ ahaghị ka ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] bụ [lexicographically](Ord#lexicographical-comparison) obere karịa ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] bụ [lexicographically](Ord#lexicographical-comparison) obere ma ọ bụ tụnyere ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Na-ekpebi ma ọ bụrụ na ndị ọcha nke a [`Iterator`] bụ [lexicographically](Ord#lexicographical-comparison) ukwuu karịa ndị nke ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Kpebisie ike ma ọ bụrụ na ihe nke [`Iterator`] a bụ [lexicographically](Ord#lexicographical-comparison) dị ukwuu karịa ma ọ bụ hara ka nke onye ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na ndị ọcha nke a iterator na-ota.
    ///
    /// Nke ahụ bụ, maka ihe ọ bụla `a` na ihe na-eso ya `b`, `a <= b` ga-ejide.Ọ bụrụ na ndị iterator amịrị kpọmkwem efu ma ọ bụ onye na mmewere, `true` na-laghachi.
    ///
    /// Cheta na ọ bụrụ na `Self::Item` bụ naanị `PartialOrd`, ma ọ bụghị `Ord`, n'elu definition na-egosi na ọrụ a na-alaghachikwuru `false` ma ọ bụrụ na abụọ ọ bụla consecutive ihe ndị tụnyere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na ndị ọcha nke a iterator na-ota iji nyere comparator ọrụ.
    ///
    /// Kama iji `PartialOrd::partial_cmp`, ọrụ a na-eji nyere `compare` ọrụ ikpebi ịtụ nke abụọ ọcha.
    /// E wezụga na, ọ bụ Ẹkot [`is_sorted`];-ahụ ya akwụkwọ maka ozi ndị ọzọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na ndị ọcha nke a iterator na-ota iji nyere isi mmịpụta ọrụ.
    ///
    /// Kama nke atụnyere iterator si ọcha ozugbo, ọrụ a na-eji tụnyere mkpịsị ugodi nke ọcha, dị ka akọwapụtara site `f`.
    /// E wezụga na, ọ bụ Ẹkot [`is_sorted`];-ahụ ya akwụkwọ maka ozi ndị ọzọ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Lee [TrustedRandomAccess]
    // The pụrụ iche na aha bụ izere aha collisions na usoro mkpebi ahụ #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}