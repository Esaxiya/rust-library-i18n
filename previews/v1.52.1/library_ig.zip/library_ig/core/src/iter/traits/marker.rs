/// An iterator na mgbe nile na-aga n'ihu na-ekwenyere `None` mgbe okụre.
///
/// Na-akpọ ọzọ na a gwakọtara iterator na laghachiri `None` ozugbo na-ekwe nkwa iji laghachi [`None`] ọzọ.
/// Nke a trait ga-emejuputa atumatu oru site niile iterators na-akpa àgwà otú a n'ihi na ọ na-enye ohere optimizing [`Iterator::fuse()`].
///
///
/// Note: Na mkpokọta, ikwesighi iji `FusedIterator` mee ihe na njedebe ma ọ bụrụ na ịchọrọ onye ejiri ya.
/// Kama nke ahụ, i kwesịrị nnọọ akpọ [`Iterator::fuse()`] na iterator.
/// Ọ bụrụ na etinyere iterator ahụ, ihe mkpuchi [`Fuse`] ọzọ ga-abụ ọghọm na enweghị ntaramahụhụ arụmọrụ.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// An iterator na-akọ ezi ogologo iji size_hint.
///
/// The iterator akọ a size ndumodu ebe ọ bụ ma kpọmkwem (ala agbụ bụ hà elu agbụ), ma ọ bụ nke elu-agbụ bụ [`None`].
///
/// The elu ibikwa kwesịrị ịbụ naanị [`None`] ma ọ bụrụ n'ezie iterator ogologo bụ ibu karịa [`usize::MAX`].
/// Na ikpe, na ala-agbụ ga-[`usize::MAX`], dapụtara na a [`Iterator::size_hint()`] nke `(usize::MAX, None)`.
///
/// The iterator ga-emepụta kpọmkwem ọnụ ọgụgụ nke ihe ọ kọrọ ma ọ bụ diverge tupu iru ọgwụgwụ.
///
/// # Safety
///
/// Nke a trait ga na-emejuputa atumatu mgbe nkwekọrịta na-kwadoro.
/// Bụghịkwa nke a trait ga inyocha [`Iterator::size_hint()`]’s elu agbụ.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// An iterator na mgbe na-ekwenye ekwenye ihe ga-emeela dịkarịa ala otu mmewere si ya akpata [`SourceIter`].
///
/// Na-akpọ ihe ọ bụla usoro na Ọganihu ndị iterator, eg
/// [`next()`] ma ọ bụ [`try_fold()`], na-ekwe nkwa na maka nke ọ bụla, ọ dịkarịa ala otu uru nke isi iyi nke iterator apụla na nsonaazụ nke usoro iterator nwere ike ịtinye n'ọnọdụ ya, na-eche na nrụgide nrụrụ nke isi mmalite na-ekwe ka ntinye dị otú ahụ.
///
/// Ndị ọzọ okwu a trait na-egosi na ihe iterator pipeline nwere ike ikpokọta ebe.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}