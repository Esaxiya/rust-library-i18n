/// Akakabarede si [`Iterator`].
///
/// Site na itinye `FromIterator` maka otu ụdị, ị kọwapụtara otu esi emepụta ya site na iterator.
/// Nke a bụ nkịtị maka ụdị nke na-akọwa a collection of ụdị ụfọdụ.
///
/// [`FromIterator::from_iter()`] bụ adịkarịghị na-akpọ n'ụzọ doro anya, na a na-kama na-eji site [`Iterator::collect()`] usoro.
///
/// Lee [`Iterator::collect()`]'s akwụkwọ maka ihe atụ.
///
/// Leekwa: [`IntoIterator`].
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Iji [`Iterator::collect()`] ka obi kpamkpam iji `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Mmejuputa `FromIterator` gị ụdị:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Nchịkọta ihe atụ, nke ahụ bụ naanị ihe mkpuchi na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka anyị nye ya ụfọdụ ụzọ ka anyị nwee ike ịmepụta otu ma tinye ihe na ya.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // na anyị ga-mejuputa FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ugbu a, anyị nwere ike ime ka a ọhụrụ iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... na-eme ka a MyCollection si na ya
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // nnata ọrụ kwa!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Emepụta a uru site na iterator.
    ///
    /// Hụ [module-level documentation] maka ihe ndị ọzọ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Nchigharị n'ime ihe [`Iterator`].
///
/// Site na itinye `IntoIterator` maka ụdị, ị kọwapụtara otu a ga-esi gbanwee ya na iterator.
/// Nke a bụ nkịtị maka ụdị nke na-akọwa a collection of ụdị ụfọdụ.
///
/// Otu uru nke mmejuputa `IntoIterator` bụ na gị na ụdị uche [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Leekwa: [`FromIterator`].
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Mmejuputa `IntoIterator` maka ụdị gị:
///
/// ```
/// // Nchịkọta ihe atụ, nke ahụ bụ naanị ihe mkpuchi na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka anyị nye ya ụfọdụ ụzọ ka anyị nwee ike ịmepụta otu ma tinye ihe na ya.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // na anyị ga-mejuputa IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ugbu a, anyị nwere ike ime ka a ọhụrụ collection ...
/// let mut c = MyCollection::new();
///
/// // ... tinye ụfọdụ stof ya ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... na-agbanwezi ya ka ọ buru Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ọ bụ ọsọ iji `IntoIterator` ka a trait bound.Nke a na-enye ohere ka ụdị nchịkọta ntinye gbanwee, ọ bụrụhaala na ọ ka bụ ite ite.
/// Ọzọ ókè nwere ike kpọmkwem site na-egbochi na
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// The ụdị ndị ọcha a na-iterated n'elu.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kedu ụdị ite ite anyị na-atụgharị nke a?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Na-emepụta ihe iterator si a uru.
    ///
    /// Hụ [module-level documentation] maka ihe ndị ọzọ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Ịgbatị a collection na ọdịnaya nke ihe iterator.
///
/// Iterators emepụta a usoro nke ụkpụrụ, na collections nwekwara ike-dị ka a usoro nke ụkpụrụ.
/// `Extend` trait jikọtara ọdịiche a, na-enye gị ohere ịgbatị nchịkọta site na itinye ọdịnaya nke onye na-aza ajụjụ ahụ.
/// Mgbe ị na-agbatị mkpokọta na igodo dị ugbu a, a na-emelite ntinye ahụ ma ọ bụ, n'ihe gbasara nchịkọta nke na-enye ohere ọtụtụ ntinye na igodo nha anya, etinyere ntinye ahụ.
///
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// // Ị nwere ike ịgbatị a eriri na ụfọdụ chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Mmejuputa `Extend`:
///
/// ```
/// // Nchịkọta ihe atụ, nke ahụ bụ naanị ihe mkpuchi na Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ka anyị nye ya ụfọdụ ụzọ ka anyị nwee ike ịmepụta otu ma tinye ihe na ya.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ebe MyCollection nwere a ndepụta i32s, anyị mejuputa ịgbatị maka i32
/// impl Extend<i32> for MyCollection {
///
///     // Nke a bụ a bit mfe na ihe ụdị mbinye aka: anyị nwere ike na-akpọ ịgbatị na ihe ọ bụla nke nwere ike ghọọ ihe Iterator nke na-enye anyị i32s.
///     // N'ihi na anyị kwesịrị i32s itinye MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Mmejuputa bụ nnọọ n'ụzọ kwụ ọtọ: loop site iterator, na add() onye ọ bụla mmewere onwe anyị.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ka ịgbatị anyị collection na atọ ọzọ nọmba
/// c.extend(vec![1, 2, 3]);
///
/// // anyị na kwukwara a ọcha na na ọgwụgwụ
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Gbatịrị a collection na ọdịnaya nke ihe iterator.
    ///
    /// Dị ka nke a bụ naanị na a chọrọ usoro nke a trait, na [trait-level] Docs nwere nkọwa ndị ọzọ.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // Ị nwere ike ịgbatị a eriri na ụfọdụ chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Gbatịrị a collection na kpọmkwem otu mmewere.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Na-echekwa ikike na nchịkọta maka ọnụọgụ nke ihe ndị ọzọ enyere.
    ///
    /// The ndabere mmejuputa iwu-eme ihe ọ bụla.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}