use crate::ops::{ControlFlow, Try};

/// An iterator ike mkpụrụ ọcha si ma nsọtụ.
///
/// Ihe na-achụ nta `DoubleEndedIterator` nwere otu extra ike n'ihi ihe ndị na achụ nta [`Iterator`]: ike na-na-iri 'Item`s si azụ, nakwa dị ka n'ihu.
///
///
/// Ọ dị mkpa iburu n'uche na ọrụ azụ na azụ na-arụ ọrụ n'otu ụdị, ma ghara ịgafe: ịghaghachi agafe mgbe ha zutere n'etiti.
///
/// Na a yiri ejiji na [`Iterator`] protocol, otu ugboro a `DoubleEndedIterator` laghachi [`None`] si a [`next_back()`], akpọ ya ọzọ nwere ike ma ọ mgbe laghachi [`Some`] ọzọ.
/// [`next()`] na [`next_back()`] bụ kennyeghari n'ihi nzube a.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Ewepu na-alaghachi ihe mmewere si na njedebe nke iterator.
    ///
    /// Alaghachi `None` mgbe e nweghị ọzọ ọcha.
    ///
    /// Akwụkwọ [trait-level] nwere nkọwa ndị ọzọ.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// The ọcha amịghịkwa site 'DoubleEndedIterator`si ụzọ nwere ike dị iche na ndị amịghịkwa site [' Iterator`] 's ụzọ:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ọganihu ndị iterator si azụ site `n` ọcha.
    ///
    /// `advance_back_by` bụ reverse version of [`advance_by`].Usoro a ga-atụsi ikwu `n` ọcha malite na azụ site na-akpọ [`next_back`] ruo `n` ugboro ruo mgbe [`None`] na-okosobode.
    ///
    /// `advance_back_by(n)` ga-alaghachi [`Ok(())`] ma ọ bụrụ na ndị iterator ọma Ọganihu site `n` ọcha, ma ọ bụ [`Err(k)`] ma ọ bụrụ na [`None`] na-okosobode, ebe `k` bụ ọnụ ọgụgụ nke ndị ọcha na iterator bụ elu site n'ihu na-agba ọsọ nke ọcha (ie
    /// ogologo nke iterator).
    /// Rịba ama na `k` bụ mgbe ihe na-erughị `n`.
    ///
    /// Akpọ `advance_back_by(0)` anaghị na-aṅụ ọ bụla ọcha na mgbe laghachi [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // naanị `&3` e ọsọsọp
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Laghachi 'n`th element site na njedebe nke iterator.
    ///
    /// Nke a bụ nnoo nwesịrị version of [`Iterator::nth()`].
    /// Ọ bụ ezie na dị ka ọtụtụ indexing arụmọrụ, ọnụ na-amalite site efu, ya mere, `nth_back(0)` laghachi mbụ uru site ọgwụgwụ, `nth_back(1)` nke abụọ, na na na.
    ///
    ///
    /// Rịba ama na ihe niile dị n'eluigwe na ụwa n'etiti ọgwụgwụ na laghachi mmewere ga-iwesa, gụnyere laghachi mmewere.
    /// Nke a pụtakwara na-akpọ `nth_back(0)` otutu ugboro na otu iterator ga-alaghachi dị iche iche ọcha.
    ///
    /// `nth_back()` ga-alaghachi [`None`] ma ọ bụrụ na `n` ukwuu ma ọ bụ hà ogologo nke iterator.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Akpọ `nth_back()` otutu ugboro anaghị weghachi ndị iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Iweghachi `None` ma ọ bụrụ na e nwere ihe na-erughị `n + 1` ọcha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Nke a bụ reverse version of [`Iterator::try_fold()`]: ọ na-ewe ihe malite na azụ nke iterator.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // N'ihi na ọ na-adịghị circuited, fọdụrụ ọcha bụ ka dị site iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator usoro na ebelata iterator si ọcha na-otu, ikpeazụ uru, malite na azụ.
    ///
    /// Nke a bụ reverse version of [`Iterator::fold()`]: ọ na-ewe ihe malite na azụ nke iterator.
    ///
    /// `rfold()` ewe abụọ arụmụka: mbụ uru, na a mmechi na abụọ arụmụka: ihe 'accumulator', na ihe mmewere.
    /// The mmechi laghachi uru na accumulator kwesịrị nwere maka ọzọ iteration.
    ///
    /// The mbụ uru bụ uru na accumulator ga nwere na mbụ na-akpọ oku.
    ///
    /// Mgbe itinye mmechi a n'ọrụ na ihe ọ bụla nke iterator, `rfold()` na-alaghachi na accumulator.
    ///
    /// Nke a na ime ihe na-akpọ mgbe ụfọdụ 'reduce' ma ọ bụ 'inject'.
    ///
    /// Ịkpakọba bụ bara uru mgbe ọ bụla i nwere a collection of ihe, ma na-achọ imepụta otu uru site na ya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // nchikota nke niile ọcha nke a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ihe atụ a na-ewuli a eriri, malite na mbụ uru na aka iso na onye ọ bụla mmewere si azụ ruo n'ihu:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Searches maka ihe mmewere nke ihe iterator si azụ na afọ a predicate.
    ///
    /// `rfind()` ewe a mmechi nke chighariworo `true` ma ọ bụ `false`.
    /// Ọ na-emetụta mmechi a na ihe ọ bụla nke iterator, na-amalite na njedebe, ma ọ bụrụ na onye ọ bụla n'ime ha alọghachi `true`, mgbe ahụ `rfind()` laghachiri [`Some(element)`].
    /// Ọ bụrụ na ha niile laghachi `false`, ọ laghachi [`None`].
    ///
    /// `rfind()` bẹ mkpụkpu-a;na ndị ọzọ okwu, ọ ga-akwụsị nhazi ozugbo na-emechi emechi laghachi `true`.
    ///
    /// N'ihi `rfind()` ewe a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, nke a na-eduga a ikekwe anya n'ọnọdụ ebe arumaru a abụọ akwụkwọ.
    ///
    /// Ị pụrụ ịhụ nke a pụrụ isi kwuo na ihe atụ ndị dị n'okpuru, na `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Nkwụsị na `true` mbụ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // anyị ka nwere ike iji `iter`, dị ka e nwere ndị ọzọ ọcha.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}