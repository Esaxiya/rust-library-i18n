/// Otu iterator maara ogologo ya.
///
/// Ọtụtụ ['Iterator`] s na-amaghị otú ọtụtụ mgbe, ha ga-iterate, ma ụfọdụ na-eme.
/// Ọ bụrụ na onye iterator maara otú ọtụtụ ugboro na ọ pụrụ iterate, na-enye ohere na ọmụma ike bara uru.
/// Ka ihe atụ, ọ bụrụ na ị chọrọ iterate azu azu, ezi mmalite ga-ama ebe ọgwụgwụ bụ.
///
/// Mgbe mmejuputa ihe `ExactSizeIterator`, ị ga-mejuputa [`Iterator`].
/// Mgbe na-eme otú ahụ, mmejuputa [`Iterator::size_hint`] ga * laghachi kpọmkwem size nke iterator.
///
/// Usoro [`len`] nwere ndabara mmejuputa iwu, yabụ na ị gaghị etinye ya n'ọrụ.
/// Agbanyeghị, ịnwere ike ịnye mmejuputa arụmọrụ karịa nke ndabara, yabụ ịbelata ya n'okwu a nwere ezi uche.
///
///
/// Cheta na nke a trait bụ a mma trait na dị ka ndị dị otú ahụ na-eme *bụghị* na *ike* nkwa na laghachi ogologo bụ nke ziri ezi.
/// Nke a pụtara na `unsafe` code **ga bụghị** adabere correctness nke [`Iterator::size_hint`].
/// The-ejighị n'aka na-aṅụkwa [`TrustedLen`](super::marker::TrustedLen) trait enye a ọzọ nkwa.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// // oke nwere oke mara ugboro ole ọ ga-ekwupụta ya
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Na [module-level docs], anyị na-emejuputa atumatu ihe [`Iterator`], `Counter`.
/// Ka anyị mejuputa `ExactSizeIterator` maka ya dị ka nke ọma:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Anyị nwere ike mfe gbakọọ fọdụrụ nọmba nke iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ma ugbu a, anyị nwere ike iji ya!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Alaghachi kpọmkwem ogologo nke iterator.
    ///
    /// Ntinye ya na-achota na onye nyocha ahụ ga-alọghachite kpọmkwem `len()` karịa oge [`Some(T)`] uru, tupu ịlaghachi [`None`].
    ///
    /// Nke a na usoro nwere a ndabere mmejuputa iwu, otú ị na-emekarị na-ekwesịghị ime eme ya ozugbo.
    /// Otú ọ dị, ọ bụrụ na ị nwere ike inye a rụọ ọrụ nke ọma, mmejuputa iwu, i nwere ike ime otú ahụ.
    /// Lee [trait-level] Docs maka otu ihe atụ.
    ///
    /// Ọrụ a nwere otu nchekwa di ka [`Iterator::size_hint`] ọrụ.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // oke nwere oke mara ugboro ole ọ ga-ekwupụta ya
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Nke a mkwuputa bụ gabiga ókè iji chebe onwe, ma ọ achọpụtazi invariant
        // ekwe nkwa site trait.
        // Ọ bụrụ na nke a trait ndị rust-esịtidem, anyị nwere ike iji debug_assert !;assert_eq!ga-elele niile Rust ọrụ implementations kwa.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Alaghachi `true` ma ọ bụrụ na ndị iterator bụ ihe efu.
    ///
    /// Nke a na usoro nwere a ndabere mmejuputa iwu iji [`ExactSizeIterator::len()`], otú ị na-adịghị mkpa iji mejuputa ya onwe gị.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}