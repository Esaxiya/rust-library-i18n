//! Composable mpụga iteration.
//!
//! Ọ bụrụ na ị na-na na hụrụ onwe gị na a collection of ụdị ụfọdụ, na ọ dị mkpa ka ịrụ ịwa na ndị ọcha nke si collection, ị ga-ngwa ngwa na-agba ọsọ n'ime 'iterators'.
//! Iterators na-kpamkpam eji n'akpaala okwu Rust code, otú ọ bụ ọnụ ahịa na-aghọ maara na ha.
//!
//! Tupu na-akọwa ihe, ka okwu banyere otú nke a modul na-ahaziri:
//!
//! # Organization
//!
//! A na-ahazi usoro a site na ụdị:
//!
//! * [Traits] bụ isi òkè: ndị a traits kọwaa ụdị iterators adị na ihe ị pụrụ ime ha.Usoro nke traits ndị a bara uru itinye oge ọmụmụ ihe ọzọ.
//! * [Functions] - enye ụfọdụ na-enye aka ụzọ ịmepụta ụfọdụ bụ isi iterators.
//! * [Structs] bụkarị ụdị nloghachi nke ụzọ dị iche iche na traits nke modul a.Ị ga na-emekarị chọrọ anya na usoro na-emepụta `struct`, kama `struct` onwe ya.
//! Ihe zuru ezu banyere ihe mere, na-ahụ '[mmejuputa Iterator](#mmejuputa-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ọ bụ ya!Ka igwu n'ime iterators.
//!
//! # Iterator
//!
//! The obi na mkpụrụ obi nke a modul bụ [`Iterator`] trait.The isi nke [`Iterator`] anya dị ka nke a:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! An iterator nwere a usoro, [`next`], nke mgbe a na-akpọ, na-alaghachikwuru ihe ['Option`]'<Item>'.
//! [`next`] ga-alaghachi [`Some(Item)`] dị ka ogologo dị ka e nwere ọcha, na mgbe ha na-na na na niile e ndikpa mba, ga-alaghachi `None` na-egosi na iteration na-okokụre.
//! Onye iterators nwere ike ịhọrọ maliteghachi iteration, na-akpọ [`next`] ọzọ nwere ike ma ọ emecha na-amalite na-alọta [`Some(Item)`] ọzọ ụfọdụ ebe (atụ, ịhụ [`TryIter`]).
//!
//!
//! ['Iterator`]' s full definition na-agụnye a ọnụ ọgụgụ nke ndị ọzọ ụzọ ka nke ọma, ma ha na-ndabere ụzọ, wuru n'elu [`next`], na otú ị ga-esi ha maka free.
//!
//! Iterators nwekwara composable, na ya nkịtị ka yinye ha ọnụ ime ihe mgbagwoju iche nke nhazi.Hụ ngalaba [Adapters](#adapters) n'okpuru maka nkọwa ndị ọzọ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Formsdị atọ nke iteration
//!
//! E nwere ụzọ atọ a na-ahụkarị nke nwere ike ịmepụta ndị na-emegharị ihe na nchịkọta:
//!
//! * `iter()`, nke iterates n'elu `&T`.
//! * `iter_mut()`, nke na-agabiga `&mut T`.
//! * `into_iter()`, nke iterates n'elu `T`.
//!
//! Ihe dị iche iche na ọkọlọtọ n'ọbá akwụkwọ nwere ike ime eme otu ma ọ bụ karịa nke atọ, ebe kwesịrị ekwesị.
//!
//! # mmejuputa Iterator
//!
//! Na-eke ihe iterator nke gị onwe gị na-agụnye nzọụkwụ abụọ: na-eke a `struct` jide iterator si ala, na mgbe ahụ na mmejuputa [`Iterator`] maka na `struct`.
//! Nke a bụ ihe mere e nwere ọtụtụ 'struct`s a modul: n'ebe otu onye maka otu iterator na iterator nkwụnye.
//!
//! Ka ihe iterator aha ya bụ `Counter` nke mkpa si `1` ka `5`:
//!
//! ```
//! // Nke mbụ, ihe gbasara ya:
//!
//! /// An iterator nke na-adabere n'ebe onye na-ise
//! struct Counter {
//!     count: usize,
//! }
//!
//! // anyị chọrọ ka ọnụ ọgụgụ anyị bido n`otu, yabụ ka anyị tinye usoro new() iji nyere aka.
//! // Nke a adịchaghị mkpa, mana ọ dị mma.
//! // Cheta na anyị na-amalite `count` na efu, anyị ga-ahụ ihe mere na `next()`'s mmejuputa n'okpuru.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Mgbe ahụ, anyị na-mejuputa `Iterator` maka anyị `Counter`:
//!
//! impl Iterator for Counter {
//!     // anyị ga-agụta na usize
//!     type Item = usize;
//!
//!     // next() bụ naanị usoro achọrọ
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Mee ka ọnụ ọgụgụ anyị bawanye.Nke a bụ ihe mere anyị malitere na efu.
//!         self.count += 1;
//!
//!         // Lelee ka ị hụ ma anyị agụchaala ma ọ bụ na anyị agụchabeghị.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ma ugbu a, anyị nwere ike iji ya!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Akpọ [`next`] otú a na-akawanye ugboro ugboro.Rust nwere a mmepụta nke nwere ike na-akpọ [`next`] gị iterator, ruo mgbe ọ esịmde `None`.Ka ayi gabiga na-esote.
//!
//! Mara kwa na `Iterator` na-enye usoro ntinye dị ka `nth` na `fold` nke na-akpọ `next` n'ime.
//! Otú ọ dị, ọ dịkwa ike dee a omenala mmejuputa usoro dị ka `nth` na `fold` ma ọ bụrụ na ihe iterator nwere ike compute ha ọzọ rụọ ọrụ nke ọma na-enweghị-akpọ `next`.
//!
//! # `for` loops na `IntoIterator`
//!
//! Rust si `for` loop syntax bụ n'ezie sugar maka iterators.Ebe a bụ a isi atụ nke `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Nke a ga-ebipụta nọmba site na ise, onye ọ bụla na ha onwe ha akara.Ma ị ga-achọpụta ihe a: ọ dịghị mgbe anyị na-akpọ ihe ọ bụla na anyị vector na-emepụta ihe iterator.Gịnị na-enye?
//!
//! E nwere ihe a trait na ọkọlọtọ ọbá akwụkwọ n'ịtụgharị ihe n'ime ihe iterator: [`IntoIterator`].
//! Nke a trait nwere otu usoro, [`into_iter`], nke atọghata ihe mmejuputa [`IntoIterator`] n'ime ihe iterator.
//! Ka anyị a anya na `for` loop ọzọ, na ihe na compiler atọghata ya:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-shuga n'ókè nke a n'ime:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Nke mbụ, anyị na-akpọ `into_iter()` na uru.Mgbe ahụ, anyị dakọtara na iterator na-alọghachi, na-akpọ [`next`] ugboro ugboro ruo mgbe anyị hụrụ `None`.
//! N'oge ahụ, anyị na-`break` nke akaghị, na anyị na-na-mere iterating.
//!
//! N'ebe ahụ bụ otu ọzọ aghụghọ bit ebe a: ọkọlọtọ n'ọbá akwụkwọ nwere ihe na-akpali, mmejuputa iwu nke [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Na ọzọ okwu, ihe niile ['Iterator`] s mejuputa [`IntoIterator`], site nnọọ na-alọta onwe ha.Nke a pụtara ihe abụọ:
//!
//! 1. Ọ bụrụ na ị na-ede ihe [`Iterator`], ị nwere ike iji ya na a `for` akaghị.
//! 2. Ọ bụrụ na ị na-na-eke a collection, mmejuputa [`IntoIterator`] n'ihi na ọ ga-ekwe gị collection na-eji na na `for` akaghị.
//!
//! # Iterating site akwụkwọ
//!
//! Ebe ọ bụ na [`into_iter()`] ewe `self` site uru, iji a `for` loop na iterate n'elu a collection erichapụ na collection.Ọtụtụ mgbe, i nwere ike chọrọ iterate n'elu a collection enweghị ewe ya.
//! Ọtụtụ collections na-enye ụzọ na-enye iterators n'elu kwuru, conventionally akpọ `iter()` na `iter_mut()` karị:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ka bu oru a.
//! ```
//!
//! Ọ bụrụ na a collection ụdị `C` enye `iter()`, ọ na-na-implements `IntoIterator` maka `&C`, na mmejuputa iwu-na dị nnọọ na-akpọ `iter()`.
//! N'otu aka ahụ, a collection `C` na-enye `iter_mut()` n'ozuzu implements `IntoIterator` maka `&mut C` site n'ikenye ka `iter_mut()`.Nke a na-enyere a adaba shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // otu dị ka `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // otu dị ka `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ọ bụ ezie na ọtụtụ nchịkọta na-enye `iter()`, ọ bụghị ha niile na-enye `iter_mut()`.
//! Ka ihe atụ, mutating mkpịsị ugodi nke a [`HashSet<T>`] ma ọ bụ [`HashMap<K, V>`] nwere ike na-etinye collection n'ime ihe ekwekọghị ala ma ọ bụrụ na isi hashes mgbanwe, otú a collections naanị-enye `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ọrụ nke na-[`Iterator`] ma laghachi ọzọ [`Iterator`] na-akpọ 'iterator nkwụnye', dị ka ha na-na na a odidi nke 'nkwụnye
//! pattern'.
//!
//! Common iterator nkwụnye gụnyere [`map`], [`take`], na [`filter`].
//! Maka ndị ọzọ, lee akwụkwọ ha.
//!
//! Ọ bụrụ na onye iterator nkwụnye panics, na iterator ga-ihe unspecified (ma ebe nchekwa dị mma) steeti.
//! Nke a na steeti a na-adịghị ekwe nkwa na-anọ otu gafee nsụgharị nke Rust, otú ị ga-ezere ịdabere kpọmkwem ụkpụrụ laghachi site iterator nke suke.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (na iterator [adapters](#adapters)) bụ *umengwụ*. Nke a pụtara na dị nnọọ na-eke ihe iterator anaghị _do_ a dum ọtụtụ. Ọ dịghị ihe n'ezie na-eme ruo mgbe ị na-akpọ [`next`].
//! Nke a bụ na mgbe ụfọdụ a isi iyi nke aghara mgbe na-eke ihe iterator naanị n'ihi ya mmetụta.
//! Ka ihe atụ, [`map`] usoro-akpọ a mmechi na onye ọ bụla mmewere ya iterates n'elu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Nke a agaghị ibipụta ọ bụla ụkpụrụ, dị ka anyị na-kere ihe iterator, kama iji ya.The compiler ga adọ aka ná ntị anyị banyere ụdị omume:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! The n'akpaala okwu ụzọ dee a [`map`] maka ya mmetụta bụ iji a `for` loop ma ọ bụ na-akpọ [`for_each`] usoro:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Zọ ọzọ a na-ahụkarị iji nyochaa iterator bụ iji usoro [`collect`] mepụta mkpokọta ọhụrụ.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ọ bụghị iwu na ndị na-eme nnyocha ga-ejedebe.Dị ka ihe atụ, na-emeghe-biri nso enweghi ngwụcha iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ọ bụ ọsọ na-eji [`take`] iterator nkwụnye na-atụgharị enweghi ngwụcha iterator n'ime a nwere oke otu:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Nke a ga-ebipụta nọmba `0` site `4`, onye ọ bụla na ha onwe ha akara.
//!
//! Buru n'uche na ụzọ na enweghi ngwụcha iterators, ọbụna ndị nke a na e nwere ike kpebisie ike mathematically na oke oge, nwere ike ọ gaghị chupu.
//! Kpọmkwem, usoro dịka [`min`], nke n'ozuzu ya chọrọ ịgafe ihe ọ bụla na iterator, nwere ike ghara ịlaghachi nke ọma maka ndị na-enweghị njedebe na-enweghị ngwụcha.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh dịghị!Enweghi ngwụcha akaghị!
//! // `ones.min()` akpata enweghi ngwụcha akaghị, otú ahụ ka anyị ga-adịghị eru a!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;