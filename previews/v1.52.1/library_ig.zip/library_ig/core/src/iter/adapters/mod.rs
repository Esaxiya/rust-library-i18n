use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Nke a trait enye transitive ohere iyi-ogbo na ihe interator-nkwụnye pipeline n'okpuru ọnọdụ ndị na
/// * onye iterator `S` n'onwe ya na-etinye `SourceIter<Source = S>` n'ọrụ
/// * enwere ntinye ndị nnọchianya nke trait a maka ihe nkwụnye ọ bụla na pipeline n'etiti isi iyi na onye na-azụ pipeline.
///
/// Mgbe isi iyi bụ inwe iterator struct (akpọkarị `IntoIter`) mgbe a nwere ike bara uru n'ihi na ọkachamara [`FromIterator`] implementations ma ọ bụ na-agbake fọdụrụ ọcha mgbe iterator e ikpe okụre.
///
///
/// Cheta na implementations-adịchaghị mkpa ka na-enye ohere ime-kasị isi iyi nke a pipeline.A stateful n'etiti nkwụnye nwere ike ịnụ ọkụ n'obi na-enyocha a akụkụ nke pipeline na-ekpughe ya esịtidem nchekwa dị ka isi iyi.
///
/// The trait bụ nwedịrị ike ịta n'ihi implementers ga na-akwado ndị ọzọ nchekwa Njirimara.
/// Hụ [`as_inner`] maka nkọwa.
///
/// # Examples
///
/// - Ewepụta a ikpe iwesa isi:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// A isi iyi ogbo ihe iterator pipeline.
    type Source: Iterator;

    /// Weghachite isi iyi nke ite ite pipeline.
    ///
    /// # Safety
    ///
    /// Implementations nke kwesịrị laghachi otu mutable akwụkwọ maka ndụ ha na ha, ma ọ bụrụ na-anọchi a bere.
    /// Listi ọkpọ oku nwere ike naanị dochie akwụkwọ mgbe ha kwụsịrị iteration na dobe iterator pipeline mgbe adịrị isi iyi.
    ///
    /// Nke a pụtara iterator nkwụnye pụrụ ịdabere na isi iyi na-na-agbanwe agbanwe mgbe iteration ma ha apụghị ịdabere na ya na ha na dobe implementations.
    ///
    /// Mmejuputa usoro a n'aka nkwụnye napụrụ onwe-na-ohere ha isi iyi na ike na-adabere na di mere dabeere na usoro erite ụdị.
    /// The enweghị nanị ohere na-na-achọ na ihe nkwụnye ga na-akwado isi iyi ọha API ọbụna mgbe ha nwere ohere ya internals.
    ///
    /// Listi ọkpọ oku n'aka ga-atụ anya na isi iyi na-ke ọ bụla ala na bụ na-agbanwe agbanwe na ya n'ihu ọha API kemgbe ihe nkwụnye ọdụ n'agbata ya na isi iyi nwere otu ohere.
    /// Karịsịa ihe nkwụnye ọkụ nwere ike iri ihe karịa ihe dị mkpa.
    ///
    /// The n'ozuzu mgbaru ọsọ nke ndị a chọrọ bụ ka n'ji nke a pipeline ojiji
    /// * ihe ọ bụla na-anọgide na isi iyi mgbe iteration akwụsịla
    /// * ebe nchekwa na aghọwo ejibeghi ndị ịka a na-ewe iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// An iterator nkwụnye na-arụpụta mmepụta ka ogologo dị ka akpata iterator arụpụta `Result::Ok` ụkpụrụ.
///
///
/// Ọ bụrụ na njehie na-enwe, iterator akwụsị na njehie na-echekwara.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Hazie nyere iterator dị ka ma ọ bụrụ na ya amịghịkwa a `T` kama a `Result<T, _>`.
/// Ọ bụla njehie ga-akwụsị n'ime iterator na mkpokọta N'ihi ga-abụ ihe njehie.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}