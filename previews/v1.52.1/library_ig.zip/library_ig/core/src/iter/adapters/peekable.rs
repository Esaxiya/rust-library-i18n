use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// An iterator na a `peek()` nke chighariworo nhọrọ banyere esote mmewere.
///
///
/// Nke a `struct` na-kere site [`peekable`] usoro on [`Iterator`].
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Cheta peek peek, ma ọ bụrụgodi na O nweghi.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable ga-echeta ma ọ bụrụ na ọnweghị onye ọ bụla hụrụ na usoro `.peek()`.
// Ọ na-ekwenye na `.peek();.peek();` ma ọ bụ `.peek();.next();` na-akwalite naanị ihe na-akpata ite na otu oge.
// Nke a anaghị eme n'onwe ya ka ọ bụrụ na ọ bụ ya.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Alaghachi a akwụkwọ kwuru na next() uru enweghị ịka ndị iterator.
    ///
    /// Dị ka [`next`], ọ bụrụ na e a uru, ọ na-ọbọp na a `Some(T)`.
    /// Ma ọ bụrụ na iteration dị n'elu, `None` na-laghachi.
    ///
    /// [`next`]: Iterator::next
    ///
    /// N'ihi `peek()` laghachi a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, e nwere ike a ikekwe anya ọnọdụ ebe nloghachi uru bụ a abụọ akwụkwọ.
    /// Ị pụrụ ịhụ nke a pụrụ isi kwuo na ihe atụ ndị dị n'okpuru.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ahapụ anyị ịhụ n'ime future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // The iterator anaghị ọganihu ọbụna ma ọ bụrụ na anyị na-`peek` otutu ugboro
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Mgbe iterator na-okokụre, otú `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Alaghachi a mutable akwụkwọ kwuru na next() uru enweghị ịka ndị iterator.
    ///
    /// Dị ka [`next`], ọ bụrụ na e a uru, ọ na-ọbọp na a `Some(T)`.
    /// Ma ọ bụrụ na iteration dị n'elu, `None` na-laghachi.
    ///
    /// N'ihi `peek_mut()` laghachi a akwụkwọ, na ọtụtụ iterators iterate n'elu kwuru, e nwere ike a ikekwe anya ọnọdụ ebe nloghachi uru bụ a abụọ akwụkwọ.
    /// Ị pụrụ ịhụ nke a pụrụ isi kwuo na ihe atụ ndị dị n'okpuru.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Dị ka ọ dị na `peek()`, anyị nwere ike ịhụ n'ime future na-enweghị ịga n'ihu na iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Peek n'ime iterator na ịtọ uru n'azụ mutable akwụkwọ.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Uru anyị tinyere ga-apụtakwa ọzọ dị ka onye na-emegharị ahụ na-aga n`ihu.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Gwusia ma laghachi ọzọ uru nke a iterator ma ọ bụrụ na a ọnọdụ bụ eziokwu.
    /// Ọ bụrụ na `func` laghachi `true` maka uru ọzọ nke iterator a, rie ma weghachi ya.
    /// Ma ọ bụghị, laghachi `None`.
    /// # Examples
    /// Na-aṅụ a nọmba ma ọ bụrụ na ọ bụ hà 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // The mbụ item nke iterator bụ 0;na-aṅụ ya.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // The ọzọ ihe laghachi bụ ugbu a 1, otú `consume` ga-alaghachi `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` azọpụta uru nke ọzọ ihe ma ọ bụrụ na ọ bụ hà `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Na-aṅụ ọ bụla ọnụ ọgụgụ na-erughị 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Rụọ nọmba niile na-erughị 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Uru ọzọ a laghachi ga-abụ 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Ebe ọ bụ na anyị na-akpọ `self.next()`, anyị iwesa `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Na-aṅụ na-alaghachi na ọzọ ihe ma ọ bụrụ na ọ bụ hà `expected`.
    /// # Example
    /// Na-aṅụ a nọmba ma ọ bụrụ na ọ bụ hà 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // The mbụ item nke iterator bụ 0;na-aṅụ ya.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // The ọzọ ihe laghachi bụ ugbu a 1, otú `consume` ga-alaghachi `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` azọpụta uru nke ọzọ ihe ma ọ bụrụ na ọ bụ hà `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // NCHEKWA: nwedịrị ike ịta ọrụ ebugharị ka nwedịrị ike ịta ọrụ na otu chọrọ
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}