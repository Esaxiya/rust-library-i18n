use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Ihe na nwere echiche nke *nọchiri* na *ụzọ* arụmọrụ.
///
/// The *nọchiri* ọrụ Nkea kwupụta ụkpụrụ na tụnyere ukwuu.
/// The *ụzọ* ọrụ Nkea kwupụta ụkpụrụ na tụnyere nta.
///
/// # Safety
///
/// Nke a trait bụ `unsafe` n'ihi ya, mmejuputa iwu ga-ziri ezi maka nchekwa nke `unsafe trait TrustedLen` implementations, na-arụpụta nke iji nke a trait nwere ike n'ụzọ ndị ọzọ obi site `unsafe` koodu na-ezi ma na-emezu ihe e depụtara ibu ọrụ.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Alaghachi ọnụ ọgụgụ nke *nọchiri* nzọụkwụ chọrọ iji na-enweta site `start` ka `end`.
    ///
    /// Alaghachi `None` ma ọ bụrụ na ọnụ ọgụgụ nke nzọụkwụ ga-erubiga `usize` (ma ọ bụ enweghị nsọtụ, ma ọ bụ ma ọ bụrụ na `end` dịghị mgbe ọ ga-ruru).
    ///
    ///
    /// # Invariants
    ///
    /// N'ihi na ọ bụla `a`, `b`, na `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ma oburu na ma oburu na `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ma oburu na ma oburu na `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` naanị ma ọ bụrụ na `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` ma ọ bụrụ na naanị ma ọ bụrụ na `a == b`
    ///   * Cheta na `a <= b` anaghị _not_ gosiri `steps_between(&a, &b) != None`;
    ///     nke a bụ ikpe mgbe ọ ga-achọ ihe karịrị `usize::MAX` emee iji `b`
    /// * `steps_between(&a, &b) == None` ma ọ bụrụ `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Alaghachi uru na a ga-enwetara site na-ewere *nọchiri* nke `self` `count` ugboro.
    ///
    /// Ọ bụrụ na nke a ga-etozu oke nke ụkpụrụ `Self` na-akwado, laghachi `None`.
    ///
    /// # Invariants
    ///
    /// N'ihi na ọ bụla `a`, `n`, na `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// N'ihi na ọ bụla `a`, `n`, na `m` ebe `n + m` adịghị ejupụta:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// N'ihi na ọ bụla `a` na `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Alaghachi uru na a ga-enwetara site na-ewere *nọchiri* nke `self` `count` ugboro.
    ///
    /// Ọ bụrụ na nke a ga-erubiga nso nke ụkpụrụ na-akwado site `Self`, ọrụ a na-ekwe ka panic, Kechie, ma ọ bụ eme.
    ///
    /// The aro omume na panic mgbe debug assertions na-nyeere, na kechie ma ọ bụ ahụ mejupụta ma ọ bụghị.
    ///
    /// Nwedịrị ike ịta code ekwesịghị ịdabere na correctness omume mgbe nile.
    ///
    /// # Invariants
    ///
    /// Maka `a`, `n`, na `m`, ebe anaghị erubiga oke:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// N'ihi na ọ bụla `a` na `n`, ebe ọ dịghị ejupụta emee:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Alaghachi uru na a ga-enwetara site na-ewere *nọchiri* nke `self` `count` ugboro.
    ///
    /// # Safety
    ///
    /// Ọ bụ undefined omume n'ihi na nke a na ime ihe na-erubiga nso nke ụkpụrụ na-akwado site `Self`.
    /// Ọ bụrụ na i nwere ike ekwe nkwa na a ga-ejupụta, ojiji `forward` ma ọ bụ `forward_checked` kama.
    ///
    /// # Invariants
    ///
    /// Maka `a` ọ bụla:
    ///
    /// * ma ọ bụrụ na e nwere `b` dị otú ahụ na `b > a`, ọ bụ nchebe na-akpọ `Step::forward_unchecked(a, 1)`
    /// * ma ọ bụrụ na e nwere `b`, `n` dị otú ahụ na `steps_between(&a, &b) == Some(n)`, ọ bụ nchebe na-akpọ `Step::forward_unchecked(a, m)` maka ihe ọ bụla `m <= n`.
    ///
    ///
    /// N'ihi na ọ bụla `a` na `n`, ebe ọ dịghị ejupụta emee:
    ///
    /// * `Step::forward_unchecked(a, n)` bụ Ẹkot `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Alaghachi uru na a ga-enwetara site na-ewere * ụzọ nke `self` `count` ugboro.
    ///
    /// Ọ bụrụ na nke a ga-etozu oke nke ụkpụrụ `Self` na-akwado, laghachi `None`.
    ///
    /// # Invariants
    ///
    /// N'ihi na ọ bụla `a`, `n`, na `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// N'ihi na ọ bụla `a` na `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Alaghachi uru na a ga-enwetara site na-ewere * ụzọ nke `self` `count` ugboro.
    ///
    /// Ọ bụrụ na nke a ga-erubiga nso nke ụkpụrụ na-akwado site `Self`, ọrụ a na-ekwe ka panic, Kechie, ma ọ bụ eme.
    ///
    /// The aro omume na panic mgbe debug assertions na-nyeere, na kechie ma ọ bụ ahụ mejupụta ma ọ bụghị.
    ///
    /// Nwedịrị ike ịta code ekwesịghị ịdabere na correctness omume mgbe nile.
    ///
    /// # Invariants
    ///
    /// Maka `a`, `n`, na `m`, ebe anaghị erubiga oke:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// N'ihi na ọ bụla `a` na `n`, ebe ọ dịghị ejupụta emee:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Alaghachi uru na a ga-enwetara site na-ewere * ụzọ nke `self` `count` ugboro.
    ///
    /// # Safety
    ///
    /// Ọ bụ undefined omume n'ihi na nke a na ime ihe na-erubiga nso nke ụkpụrụ na-akwado site `Self`.
    /// Ọ bụrụ na ịnweghị ike ikwenye na nke a agaghị ejupụta, jiri `backward` ma ọ bụ `backward_checked` kama.
    ///
    /// # Invariants
    ///
    /// Maka `a` ọ bụla:
    ///
    /// * ọ bụrụ na enwere `b` dị ka `b < a`, ọ ga-adị mma ịkpọ `Step::backward_unchecked(a, 1)`
    /// * ma ọ bụrụ na e nwere `b`, `n` dị otú ahụ na `steps_between(&b, &a) == Some(n)`, ọ bụ nchebe na-akpọ `Step::backward_unchecked(a, m)` maka ihe ọ bụla `m <= n`.
    ///
    ///
    /// N'ihi na ọ bụla `a` na `n`, ebe ọ dịghị ejupụta emee:
    ///
    /// * `Step::backward_unchecked(a, n)` bụ Ẹkot `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Ndị a bụ ndị ka na-na nnukwu-eme n'ihi na integer literals ka mkpebi dị iche iche.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // NCHEKWA: nke bere nwere nkwa na `start + n` adịghị nile.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ANY: onye na-akpọ oku ga-ekwe nkwa na `start - n` anaghị ejupụta.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Na debug ewuli, ịkpalite a panic on nile.
            // Nke a ga-ebuli kpamkpam na ntọhapụ na-ewuli.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Ime wrapping ná mgbakọ na mwepụ na-ekwe ka eg `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Na debug ewuli, ịkpalite a panic on nile.
            // Nke a ga-ebuli kpamkpam na ntọhapụ na-ewuli.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Ime wrapping ná mgbakọ na mwepụ na-ekwe ka eg `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Nke a dabere na $u_narrower <=jiri
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ọ bụrụ n adịghịpụrụ, `unsigned_start + n` dịkwa oke
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // oburu na n out aka ozo, `unsigned_start - n` dikwa
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Nke a na-adabere ná $i_narrower <=usize
                        //
                        // Nkedo na isize gbatịrị obosara ma na-echebe ihe ịrịba ama.
                        // Iji wrapping_sub na isize ohere na nkedo na usize ka compute ihe dị iche nwere ike dabara n'ime nso nke isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping ịṅụ ikpe dị ka `Step::forward(-120_i8, 200) == Some(80_i8)`, ọ bụ ezie na 200 bụ nke iche maka i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Mgbakwunye tojuru
                            }
                        }
                        // Ọ bụrụ na n bụ nke nso nke eg
                        // u8, mgbe ahụ, ọ bụ ibu karịa dum nso maka i8 bụ dum otú `any_i8 + n` bụchaghị ọtọde i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping ịṅụ ikpe dị ka `Step::forward(-120_i8, 200) == Some(80_i8)`, ọ bụ ezie na 200 bụ nke iche maka i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // mwepu jubigakwara ókè
                            }
                        }
                        // Ọ bụrụ na n bụ nke nso nke eg
                        // u8, mgbe ahụ, ọ bụ ibu karịa dum nso maka i8 bụ dum otú `any_i8 - n` bụchaghị ọtọde i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ọ bụrụ na ọdịiche dị oke oke maka eg
                            // i128, ọ na-etinyecha-kwa nnukwu maka usize ole na ole ibe n'ibe.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // NCHEKWA: nchapụta a bụ ezigbo unicode scalar
            // (N'okpuru 0x110000 na ọ bụghị na 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // NCHEKWA: nchapụta a bụ ezigbo unicode scalar
        // (N'okpuru 0x110000 na ọ bụghị na 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // NCHEKWA: nke bere ga-ekwe nkwa na a na-adịghị ejupụta
        // nso nke ụkpụrụ maka char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // NCHEKWA: nke bere ga-ekwe nkwa na a na-adịghị ejupụta
            // nso nke ụkpụrụ maka char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // NCHEKWA: n'ihi na nke gara aga nkwekọrịta, nke a na-ekwe nkwa
        // site na onye na-akpọ oku ka ọ bụrụ ezigbo char.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // NCHEKWA: nke bere ga-ekwe nkwa na a na-adịghị ejupụta
        // nso nke ụkpụrụ maka char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // NCHEKWA: nke bere ga-ekwe nkwa na a na-adịghị ejupụta
            // nso nke ụkpụrụ maka char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // NCHEKWA: n'ihi na nke gara aga nkwekọrịta, nke a na-ekwe nkwa
        // site na onye na-akpọ oku ka ọ bụrụ ezigbo char.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: Naanị enyocha prekondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAFETY: Naanị enyocha prekondition
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ndị a macros n'ịwa `ExactSizeIterator` impls dị iche iche dị iche iche ụdị.
//
// * `ExactSizeIterator::len` a chọrọ ka mgbe nile laghachi kpọmkwem `usize`, otú ọ dịghị nso nwere ike ịbụ ogologo oge karịa `usize::MAX`.
//
// * N'ihi na integer ụdị `Range<_>` a bụ ikpe maka ụdị mkpafa karịa ma ọ bụ ka obosara `usize`.
//   Maka ụdị ọnụọgụ na `RangeInclusive<_>` nke a bụ ikpe maka ụdị dị iche iche * karịa `usize` ebe eg
//   `(0..=u64::MAX).len()` ga-abu `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ndị a bụ incorect kwa na echiche n'elu, ma wepụ ha ga-abụ a na-agbasa mgbanwe dị ka ha na-gbasie ike Rust 1.0.0.
    // Yabụ dịka
    // `(0..66_000_u32).len()` n'ihi na ihe atụ ga-ikpokọta enweghị njehie ma ọ bụ ịdọ aka ná ntị na 16-bit nyiwe, ma anọgide na-enye a na-ezighị ezi pụta.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ndị a bụ incorect kwa na echiche n'elu, ma wepụ ha ga-abụ a na-agbasa mgbanwe dị ka ha na-gbasie ike Rust 1.26.0.
    // Yabụ dịka
    // `(0..=u16::MAX).len()` n'ihi na ihe atụ ga-ikpokọta enweghị njehie ma ọ bụ ịdọ aka ná ntị na 16-bit nyiwe, ma anọgide na-enye a na-ezighị ezi pụta.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: Naanị enyocha prekondition
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAFETY: Naanị enyocha prekondition
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: Naanị enyocha prekondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: Naanị enyocha prekondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: Naanị enyocha prekondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: Naanị enyocha prekondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}