use crate::iter::{FusedIterator, TrustedLen};

/// Emepụta ọhụrụ iterator na akuko ihe nke ụdị `A` anọgide site n'itinye nyere mmechi, na repeater, `F: FnMut() -> A`.
///
/// The `repeat_with()` ọrụ na-akpọ ndị repeater n'elu na n'elu ọzọ.
///
/// Enweghi ngwụcha iterators ka `repeat_with()` na-eji na ihe nkwụnye ka [`Iterator::take()`], iji mee ka ha nwere oke.
///
/// Ọ bụrụ na mmewere ụdị nke iterator gị mkpa achụ nta [`Clone`], na ọ bụ OK na-iyi mmewere na ebe nchekwa, ị kwesịrị ị na kama iji [`repeat()`] ọrụ.
///
///
/// An iterator emepụta site `repeat_with()` bụghị a [`DoubleEndedIterator`].
/// Ọ bụrụ na ịchọrọ `repeat_with()` iji weghachite [`DoubleEndedIterator`], biko mepee okwu GitHub na-akọwa iji okwu gị.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::iter;
///
/// // ka anyị chee na anyị nwere ụfọdụ uru nke ụdị na-abụghị `Clone` ma ọ bụ nke achọghị ịnwe ebe nchekwa naanị n'ihi na ọ dị oke ọnụ:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // a akpan akpan uru ruo mgbe ebighị ebi:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Iji mutation na-aga nwere oke:
///
/// ```rust
/// use std::iter;
///
/// // Site na nke isii gaa na ike nke atọ nke abụọ:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... na ugbu a anyị na-mere
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// An iterator na akuko ihe nke ụdị `A` anọgide site n'itinye nyere mmechi `F: FnMut() -> A`.
///
///
/// Nke a `struct` na-kere site [`repeat_with()`] ọrụ.
/// Lee akwukwo ya maka ihe ndi ozo.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}