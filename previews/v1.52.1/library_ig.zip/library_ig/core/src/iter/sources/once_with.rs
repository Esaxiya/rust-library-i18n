use crate::iter::{FusedIterator, TrustedLen};

/// Na-emepụta ihe iterator na lazily site a uru kpọmkwem ozugbo site n'ịkpọku ndị nyere mmechi.
///
/// Nke a na-ejikarị imeghari a otu uru generator n'ime a [`chain()`] nke ọzọ di iche iche nke iteration.
/// Ma eleghị anya, ị nwere iterator na mkpuchite fọrọ nke nta niile, ma ị chọrọ onye amara pụrụ iche ikpe.
/// Ma eleghị anya, i nwere a ọrụ nke na-arụ ọrụ iterators, ma gị na mkpa iji hazie otu uru.
///
/// N'adịghị ka [`once()`], ọrụ a ga-lazily n'ịwa uru na-arịọ arịrịọ.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::iter;
///
/// // na otu onye bụ ndị owu kasị ama nọmba
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // dị nnọọ otu, nke ahụ bụ ihe niile anyị na-enweta
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining ọnụ na ọzọ iterator.
/// Ka anyi kwuo na anyi choro ichota ya na faili o bula nke akwukwo `.foo`, kamakwa faịlụ nhazi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // anyị mkpa iji tọghata otu iterator nke DirEntry-s na iterator nke PathBufs, otú anyị na-eji map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ugbu a, anyị iterator naanị anyị config file
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kee ndị na-emegharị ihe abụọ ahụ ọnụ n'otu nnukwu iterator
/// let files = dirs.chain(config);
///
/// // a ga-enye anyị niile nke faịlụ na .foo nakwa dị ka .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Otu iterator na-ewepụta otu ụdị nke ụdị `A` site na itinye mmechi mmechi nyere `F: FnOnce() -> A`.
///
///
/// Nke a `struct` na-kere site [`once_with()`] ọrụ.
/// Lee akwukwo ya maka ihe ndi ozo.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}