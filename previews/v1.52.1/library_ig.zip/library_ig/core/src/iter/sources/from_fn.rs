use crate::fmt;

/// Emepụta ọhụrụ iterator ebe ọ bụla iteration akpọ ndị nyere mmechi `F: FnMut() -> Option<T>`.
///
/// Nke a na-enye ohere ịmepụta onye na-ede akwụkwọ na omume ọ bụla na-enweghị iji syntax verbose nke ịmepụta ụdị raara onwe ya nye na itinye [`Iterator`] trait n'ọrụ maka ya.
///
/// Note na `FromFn` iterator adịghị eme ka echiche banyere nke omume nke mmechi, ya mere conservatively anaghị mejuputa [`FusedIterator`], ma ọ bụ na-akpagbu ihe [`Iterator::size_hint()`] si ya ndabere `(0, None)`.
///
///
/// The mmechi nwere ike iji captures na ya gburugburu ebe obibi iji soro ala gafee iterations.Dabere na otú ndị iterator na-eji, nke a pụrụ ịchọ ikwu [`move`] isiokwu na mmechi.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ka re-mejuputa counter iterator si [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Mee ka ọnụ ọgụgụ anyị bawanye.Nke a bụ ihe mere anyị malitere na efu.
///     count += 1;
///
///     // Lelee ka ị hụ ma anyị agụchaala ma ọ bụ na anyị agụchabeghị.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// An iterator ebe ọ bụla iteration akpọ ndị nyere mmechi `F: FnMut() -> Option<T>`.
///
/// Nke a `struct` na-kere site [`iter::from_fn()`] ọrụ.
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}