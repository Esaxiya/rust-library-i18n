use crate::iter::{FusedIterator, TrustedLen};

/// Emepụta ite ite na-amị otu mmewere otu oge.
///
/// Nke a na-ejikarị imeghari a otu uru n'ime a [`chain()`] nke ọzọ di iche iche nke iteration.
/// Ma eleghị anya, ị nwere iterator na mkpuchite fọrọ nke nta niile, ma ị chọrọ onye amara pụrụ iche ikpe.
/// Ma eleghị anya, i nwere a ọrụ nke na-arụ ọrụ iterators, ma gị na mkpa iji hazie otu uru.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::iter;
///
/// // na otu onye bụ ndị owu kasị ama nọmba
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // dị nnọọ otu, nke ahụ bụ ihe niile anyị na-enweta
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining ọnụ na ọzọ iterator.
/// Ka anyi kwuo na anyi choro ichota ya na faili o bula nke akwukwo `.foo`, kamakwa faịlụ nhazi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // anyị mkpa iji tọghata otu iterator nke DirEntry-s na iterator nke PathBufs, otú anyị na-eji map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ugbu a, anyị iterator naanị anyị config file
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // kee ndị na-emegharị ihe abụọ ahụ ọnụ n'otu nnukwu iterator
/// let files = dirs.chain(config);
///
/// // a ga-enye anyị niile nke faịlụ na .foo nakwa dị ka .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Otu iterator nke na-ewepụta mmezi otu oge.
///
/// Nke a `struct` na-kere site [`once()`] ọrụ.Lee ya akwụkwọ maka ndị ọzọ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}