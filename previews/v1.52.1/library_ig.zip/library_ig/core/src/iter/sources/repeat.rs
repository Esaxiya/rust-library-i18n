use crate::iter::{FusedIterator, TrustedLen};

/// Emepụta ọhụrụ iterator na anọgide akuko a otu mmewere.
///
/// The `repeat()` ọrụ akuko a otu uru n'elu na n'elu ọzọ.
///
/// Enweghi ngwụcha iterators ka `repeat()` na-eji na ihe nkwụnye ka [`Iterator::take()`], iji mee ka ha nwere oke.
///
/// Ọ bụrụ na mmewere ụdị nke iterator gị mkpa anaghị mejuputa `Clone`, ma ọ bụ ọ bụrụ na ị na-achọghị na-ugboro ugboro mmewere na ebe nchekwa, ị nwere ike kama iji [`repeat_with()`] ọrụ.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::iter;
///
/// // nọmba anọ 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Yup, ka anọ
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Xga na njedebe [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ikpeazụ atụ bụ ọtụtụ fours.Ka anyị na anọ na fours.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... na ugbu a anyị na-mere
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// An iterator na akuko ihe mmewere n'akwụsịghị akwụsị.
///
/// Emebere `struct` a site na ọrụ [`repeat()`].Lee ya akwụkwọ maka ndị ọzọ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}