#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Nwere struct nkọwa maka layout nke compiler wuru na-na ụdị.
//!
//! Enwere ike iji ha dị ka ebumnuche nke ntụgharị na koodu echekwaghị eche maka iji dochie ndị na-anọchite anya ya.
//!
//!
//! Nkọwa ha kwesiri ikwekọ na ABI akọwapụtara na `rustc_middle::ty::layout`.
//!

/// Ihe nnọchianya nke ihe trait dị ka `&dyn SomeTrait`.
///
/// Ihe owuwu a nwere otu uzo dika `&dyn SomeTrait` na `Box<dyn AnotherTrait>`.
///
/// `TraitObject` na-ekwe nkwa iji kwekọọ layouts, ma ọ bụghị ya bụ ụdị trait akpọkwa (eg, ubi ha na-adịghị mfe na a `&dyn SomeTrait`) ma ọ bụ ka ọ na-achịkwa na layout (agbanwe agbanwe definition agaghị agbanwe layout nke a `&dyn SomeTrait`).
///
/// Emere ya naanị ka ejiri ya kọwaa koodu echekwaghị echekwesịrị iji jikwaa nkọwa ogo ala.
///
/// Enweghị ụzọ isi zoo aka na ihe niile trait na-arụ ọrụ, yabụ otu ụzọ esi mepụta ụkpụrụ nke ụdị a bụ ọrụ dịka [`std::mem::transmute`][transmute].
/// N'otu aka ahụ, nanị ụzọ ịmepụta a ezi trait ihe si a `TraitObject` uru bụ na `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing a trait object with myismatched types-otu ebe vtable na-adabaghị na ụdị nke uru data pointer na-ezo aka nke ukwuu nwere ike iduga n'omume a na-akọwaghị.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // otu ihe atụ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ka compiler ka a trait ihe
/// let object: &dyn Foo = &value;
///
/// // lee anya nnochi anya
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // pointer data bu adreesị nke `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // rụọ ihe ọhụrụ, na-atụ aka na `i32` dị iche, na-akpachara anya iji `i32` vtable si `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // Ọ kwesịrị ịrụ ọrụ dịka a ga-asị na anyị wuru ihe trait site na `other_value` ozugbo
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}