//! impl nwere {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Kachasị akara koodu dị elu `char` nwere ike ịnwe.
    ///
    /// `char` bụ [Unicode Scalar Value], nke pụtara na ọ bụ [Code Point], mana ọ bụ naanị ndị nọ n`ime oke ụfọdụ.
    /// `MAX` bụ akara koodu kachasị dị elu nke ahụ bụ [Unicode Scalar Value] ziri ezi.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` A na-eji () na Unicode na-anọchite anya mmejọ mmezi.
    ///
    /// Ọ nwere ike ime, dịka ọmụmaatụ, mgbe ị na-enye UTF-8 bytes na-arịa ọrịa na [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// The version of [Unicode](http://www.unicode.org/) na Unicode akụkụ nke `char` na `str` ụzọ na-dabere na.
    ///
    /// A na-ewepụta ụdị ọhụrụ nke Unicode mgbe niile ma na-agbaso ụzọ niile n'ọbá akwụkwọ ọkọlọtọ dabere na Unicode na-emelite.
    /// Ya mere omume nke ụfọdụ usoro `char` na `str` na uru nke oge a na-agbanwe oge.
    /// Nke a abụghị * elere anya dị ka mgbanwe mgbanwe.
    ///
    /// The version Nọmba atụmatụ a kọwara [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Na-emepụta onye na-ekwu okwu banyere ihe akara koodu UTF-16 na `iter`, na-eweghachi ihe nkwụghachi ụgwọ dị ka ``Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// A lossy decoder nwere ike enwetara site dochie `Err` pụta nnọchi agwa:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Atọghata a `u32` ka a `char`.
    ///
    /// Cheta na ihe niile 'char`s bụ nti [' u32`] s, na ike ga-achụpụ onye na-
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Agbanyeghị, agbara abụghị eziokwu: ọbụghị ezigbo ihe niile [``u32`] s nwere ezigbo '' char`s.
    /// `from_u32()` ga-alaghachi `None` ma ọ bụrụ na ndenye bụghị a nti uru maka a `char`.
    ///
    /// Maka nsụgharị a na-ejighị n'aka nke ọrụ a nke na-eleghara ndenye ego ndị a anya, lee [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Iweghachi `None` mgbe input bụghị a nti `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Atọghata a `u32` ka a `char`, leghara ndaba.
    ///
    /// Cheta na ihe niile 'char`s bụ nti [' u32`] s, na ike ga-achụpụ onye na-
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Agbanyeghị, agbara abụghị eziokwu: ọbụghị ezigbo ihe niile [``u32`] s nwere ezigbo '' char`s.
    /// `from_u32_unchecked()` ga-eleghara nke a anya ma tụnye ya na `char` na nzuzo, ikekwe mepụta nke na-enweghị isi.
    ///
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo, ebe ọ nwere ike rụọ ụkpụrụ `char` na-abaghị uru.
    ///
    /// Maka ọdịdị dị mma nke ọrụ a, lee ọrụ [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Gbanwee otu ọnụọgụ na radix e nyere na `char`.
    ///
    /// A 'radix' ebe a na-akpọkwa 'base' mgbe ụfọdụ.
    /// A radix nke abụọ na-egosi ọnụọgụ ọnụọgụ abụọ, radix nke iri, ntụpọ, na radix nke iri na isii, hexadecimal, iji nye ụfọdụ ụkpụrụ bara uru.
    ///
    /// Aka ike radices na-akwado.
    ///
    /// `from_digit()` ga-alaghachi `None` ma ọ bụrụ na ndenye bụghị a ọbula na nyere mgbọrọgwụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na enyere radix karịrị 36.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Ntụpọ 11 bụ otu ọnụọgụ na ntọala 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Iweghachi `None` mgbe ntinye abụghị ọnụọgụ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Na-agafe nnukwu radix, na-akpata panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na a `char` bụ a ọbula na nyere mgbọrọgwụ.
    ///
    /// A 'radix' ebe a na-akpọkwa 'base' mgbe ụfọdụ.
    /// A radix nke abụọ na-egosi ọnụọgụ ọnụọgụ abụọ, radix nke iri, ntụpọ, na radix nke iri na isii, hexadecimal, iji nye ụfọdụ ụkpụrụ bara uru.
    ///
    /// Aka ike radices na-akwado.
    ///
    /// E jiri ya tụnyere [`is_numeric()`], ọrụ a na-amata mkpụrụedemede `0-9`, `a-z` na `A-Z` naanị.
    ///
    /// 'Digit' akọwapụtara ka ọ bụrụ naanị mkpụrụedemede ndị a:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Maka nghọta zuru ezu banyere 'digit', lee [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na enyere radix karịrị 36.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Na-agafe nnukwu radix, na-akpata panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Gbanwee `char` ka ọnụọgụ dị na radix enyere.
    ///
    /// A 'radix' ebe a na-akpọkwa 'base' mgbe ụfọdụ.
    /// A radix nke abụọ na-egosi ọnụọgụ ọnụọgụ abụọ, radix nke iri, ntụpọ, na radix nke iri na isii, hexadecimal, iji nye ụfọdụ ụkpụrụ bara uru.
    ///
    /// Aka ike radices na-akwado.
    ///
    /// 'Digit' akọwapụtara ka ọ bụrụ naanị mkpụrụedemede ndị a:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Alaghachi `None` ma ọ bụrụ na ndị `char` adịghị ezo aka a ọbula na nyere mgbọrọgwụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na enyere radix karịrị 36.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Gafe nsonaazụ na-abụghị ọnụọgụ na-ada:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Na-agafe nnukwu radix, na-akpata panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // a na-ekewa koodu a ebe a iji meziwanye ngwa ngwa maka ikpe ebe `radix` na-agbanwe agbanwe na 10 ma ọ bụ obere
        //
        let val = if likely(radix <= 10) {
            // Ọ bụrụ na bụghị a ọbula, a ọnụ ọgụgụ dị ukwuu karịa mgbọrọgwụ ga-kere.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ọlaghachi onye ite ite na-eweta hexadecimal Unicode mgbapụ nke a agwa dị ka 'char`s.
    ///
    /// Nke a ga-agbapụ mkpụrụedemede na nkọwapụta Rust nke ụdị `\u{NNNNNN}` ebe `NNNNNN` bụ nnọchi anya hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ma ọ bụ-u 1 ana achi achi na maka c==0 koodu computes na otu ọbula ga-ebipụta ma na (nke bụ otu ihe) ezere (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ndeksi nke ihe kachasi elu hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ogologo version of `escape_debug` na optionally kwe gbapụrụ agbapụ Extended Grapheme codepoints.
    /// Nke a na-enye ohere ka anyị na-usoro odide ka nonspacing akara mma mgbe ha na-na na mmalite nke a eriri.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Alaghachi ihe iterator na-amịrị ndị nkịtị ụzọ mgbapụ koodu nke a agwa dị ka 'char`s.
    ///
    /// Nke a ga-agbanahụ odide yiri `Debug` implementations nke `str` ma ọ bụ `char`.
    ///
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Alaghachi ihe iterator na-amịrị ndị nkịtị ụzọ mgbapụ koodu nke a agwa dị ka 'char`s.
    ///
    /// A na-ahọrọ ndabara ahụ na enweghị mmasị maka ịmepụta ezigbo akwụkwọ nke iwu kwadoro n'ọtụtụ asụsụ, gụnyere C++ 11 yana asụsụ ndị ezinụlọ C.
    /// Iwu ahụ bụ:
    ///
    /// * Tab gbapuru dika `\t`.
    /// * Riageghaghachi azụ gbapụrụ dị ka `\r`.
    /// * Ntanetị Line gbapụrụ dịka `\n`.
    /// * Ntughari okwu gbapuru dika `\'`.
    /// * Ugboro abụọ see okwu gbapụrụ dịka `\"`.
    /// * Backslash agbapụla dị ka `\\`.
    /// * Ọ bụla agwa na 'printable ascii' nso `0x20` .. `0x7e` yana idobe okirikiri na-adịghị lanahụrụ.
    /// * A na-enye mkpụrụedemede ndị ọzọ hexadecimal Unicode mgbapụ;lee [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Alaghachi ọnụ ọgụgụ nke bytes a `char` ga-mkpa ma ọ bụrụ na itinye na koodu na UTF-8.
    ///
    /// Ọnụ ọgụgụ nke bytes a na-adịkarị n'etiti 1 na 4, gụnyere.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Xdị `&str` na-ekwe nkwa na ọdịnaya ya bụ UTF-8, yabụ anyị nwere ike iji tụnyere ogologo ọ ga-ewe ma ọ bụrụ na akara koodu ọ bụla nọchitere anya dị ka `char` na nke `&str` n'onwe ya:
    ///
    ///
    /// ```
    /// // ka chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ma nwere ike na-anọchi anya dị ka atọ bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // dị ka a &str, abụọ ndị a na-itinye na koodu na UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // anyị pụrụ ịhụ na ha na-isii bytes ngụkọta ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... dị ka &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Weghachite ọnụọgụ koodu koodu 16-bit a `char` ga-achọ ma ọ bụrụ na koodu na UTF-16.
    ///
    ///
    /// Lee akwụkwọ maka [`len_utf8()`] n'ihi na ihe nkowa nke a echiche.
    /// Nke a ọrụ bụ a mirror, ma n'ihi UTF-16 kama UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// - Ebu ụzọ amata nke a agwa ka UTF-8 n'ime nyere byte echekwa, na mgbe ahụ laghachi na subslice nke echekwa na e dere ihe itinye na koodu agwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na nchekwa ahụ ezughị oke.
    /// Ihe nchekwa ogologo anọ dị oke iji zoo `char` ọ bụla.
    ///
    /// # Examples
    ///
    /// Ma nke ihe atụ ndị a, 'ß' ewe abụọ bytes encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Nchekwa nke pere mpe:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // NCHEKWA: `char` bụghị a surrogate, otú a bụ nti UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// - Ebu ụzọ amata nke a agwa ka UTF-16 n'ime nyere `u16` echekwa, na mgbe ahụ laghachi na subslice nke echekwa na e dere ihe itinye na koodu agwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na nchekwa ahụ ezughị oke.
    /// A echekwa nke ogologo 2 bụ nnukwu iji encode ọ bụla `char`.
    ///
    /// # Examples
    ///
    /// Ma nke ihe atụ ndị a, '𝕊' ewe abụọ 'u16`s encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Nchekwa nke pere mpe:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Alaghachi `true` ma ọ bụrụ na a `char` nwere `Alphabetic` onwunwe.
    ///
    /// `Alphabetic` a kọwara n'Isi nke 4 (Agwa Properties) nke [Unicode Standard] na kpọmkwem na [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ịhụnanya bụ ọtụtụ ihe, ma ọ bụghị alphabetic
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Alaghachi `true` ma ọ bụrụ na a `char` nwere `Lowercase` onwunwe.
    ///
    /// `Lowercase` a kọwara n'Isi nke 4 (Agwa Properties) nke [Unicode Standard] na kpọmkwem na [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Akwụkwọ edemede na akara edemede dị iche iche nke China enweghị ikpe, yabụ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Laghachi `true` ma ọ bụrụ na `char` a nwere ihe onwunwe `Uppercase`.
    ///
    /// `Uppercase` a kọwara n'Isi nke 4 (Agwa Properties) nke [Unicode Standard] na kpọmkwem na [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Akwụkwọ edemede na akara edemede dị iche iche nke China enweghị ikpe, yabụ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Laghachi `true` ma ọ bụrụ na `char` a nwere ihe onwunwe `White_Space`.
    ///
    /// `White_Space` akọwapụtara na [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // oghere na-adịghị emebi emebi
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Laghachi `true` ma ọ bụrụ na `char` a mejupụtara ma ọ bụ [`is_alphabetic()`] ma ọ bụ [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Laghachi `true` ma ọ bụrụ na `char` a nwere ụdị izugbe maka akara njikwa.
    ///
    /// Control codes (koodu ihe na general udi nke `Cc`) kọwara n'Isi nke 4 (Agwa Properties) nke [Unicode Standard] na kpọmkwem na [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // U + 009C, eriri TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Alaghachi `true` ma ọ bụrụ na a `char` nwere `Grapheme_Extend` onwunwe.
    ///
    /// `Grapheme_Extend` kọwara na [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ma kọwaa ya na [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Laghachi `true` ma ọ bụrụ na `char` a nwere otu edemede izugbe maka nọmba.
    ///
    /// The n'ozuzu na edemede maka nọmba (`Nd` maka ntụpọ digits, `Nl` maka akwụkwọ ozi-dị ka ọnụọgụ odide, na `No` maka ndị ọzọ ọnụọgụ odide) na-kpọmkwem na [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Alaghachi ihe iterator na-amịrị ndị lowercase nkewa nke a `char` dị ka otu ma ọ bụ karịa
    /// `char`s.
    ///
    /// Ọ bụrụ na nke a `char` adịghị a lowercase nkewa, na iterator amịrị otu `char`.
    ///
    /// Ọ bụrụ na nke a `char` nwere otu-na-otu lowercase nkewa nyere site [Unicode Character Database][ucd] [`UnicodeData.txt`], na iterator zaa na `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ọ bụrụ na `char` a chọrọ nlebara anya pụrụ iche (dịka ọtụtụ ``char`s) '' onye a na-ekwu okwu na-enye `` char '' nke [`SpecialCasing.txt`] nyere.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Nke a na ime ihe rụrụ onkondishional nkewa enweghị eduzikwa.Nke ahụ bụ, a gbanwere ntụgharị na-adabereghị n'okwu na asụsụ.
    ///
    /// Na [Unicode Standard], Chapter 4 (Agwa Properties) eneme ikpe nkewa n'ozuzu na Ibuot 3 (Conformance) banyere ndabere algọridim maka ikpe akakabarede.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Mgbe ụfọdụ, n'ihi bụ ihe karịrị otu agwa:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ihe odide na-enweghị ma mkpụrụedemede ukwu na nke pere mpe na-agbanwe onwe ha.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Alaghachi ihe iterator na-amịrị ndị uppercase nkewa nke a `char` dị ka otu ma ọ bụ karịa
    /// `char`s.
    ///
    /// Ọ bụrụ na nke a `char` adịghị a uppercase nkewa, na iterator amịrị otu `char`.
    ///
    /// Ọ bụrụ na `char` a nwere nkebi otu na otu nke [Unicode Character Database][ucd] [`UnicodeData.txt`] nyere, onye na-eme ihe ahụ na-eweta `char` ahụ.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ọ bụrụ na `char` a chọrọ nlebara anya pụrụ iche (dịka ọtụtụ ``char`s) '' onye a na-ekwu okwu na-enye `` char '' nke [`SpecialCasing.txt`] nyere.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Nke a na ime ihe rụrụ onkondishional nkewa enweghị eduzikwa.Nke ahụ bụ, a gbanwere ntụgharị na-adabereghị n'okwu na asụsụ.
    ///
    /// Na [Unicode Standard], Chapter 4 (Agwa Properties) eneme ikpe nkewa n'ozuzu na Ibuot 3 (Conformance) banyere ndabere algọridim maka ikpe akakabarede.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Mgbe ụfọdụ, n'ihi bụ ihe karịrị otu agwa:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ihe odide na-enweghị ma mkpụrụedemede ukwu na nke pere mpe na-agbanwe onwe ha.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Note na anọkwaghị n'ógbè
    ///
    /// Na Turkish, ihe nhata 'i' na Latin nwere uzo ise kari abuo:
    ///
    /// * 'Dotless': M/ı, mgbe ụfọdụ, e dere m
    /// * 'Dotted': M/m
    ///
    /// Rịba ama na obere ntụpọ 'i' bụ otu ihe ahụ dị ka Latin.Ya mere:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Uru `upper_i` ebe a dabere na asụsụ ederede: ọ bụrụ na anyị nọ na `en-US`, o kwesịrị ịbụ `"I"`, mana ọ bụrụ na anyị nọ na `tr_TR`, ọ ga-abụ `"İ"`.
    /// `to_uppercase()` anaghị echebara nke a echiche, ya mere:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// na-ejide asụsụ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Na-elele ma ọ bụrụ na uru ahụ dị na ọkwa ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Na-eme ka a oyiri nke uru ya ascii elu ikpe Ẹkot.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'a' na 'z' na 'A' na 'Z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji uppercase uru na-ebe, na-eji [`make_ascii_uppercase()`].
    ///
    /// Iji mkpụrụedemede ASCII buru ibu na mgbakwunye na mkpụrụedemede ndị na-abụghị ASCII, jiri [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Na-eme ka a oyiri nke uru ya ascii obere Ẹkot.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'A' na 'Z' na 'a' na 'z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji lowercase uru na-ebe, na-eji [`make_ascii_lowercase()`].
    ///
    /// Iji rida mkpụrụedemede ASCII dị obere na mgbakwunye na mkpụrụedemede ndị na-abụghị ASCII, jiri [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Nyochaa na ụkpụrụ abụọ bụ egwuregwu ASCII na-enweghị isi.
    ///
    /// Ẹkot `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Atọghata ụdị ya ascii elu ikpe Ẹkot na-ebe.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'a' na 'z' na 'A' na 'Z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Ka ịlaghachi na a ọhụrụ uppercased uru enweghị modifying ẹdude otu, na-eji [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Atọghata ụdị a na ASCII obere okwu ya na ebe ya.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'A' na 'Z' na 'a' na 'z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Ka ịlaghachi na a ọhụrụ lowercased uru enweghị modifying ẹdude otu, na-eji [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na uru bụ ihe ascii alphabetic agwa:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ma ọ bụ
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Na-achọpụtazi ma ọ bụrụ na uru bụ ASCII uppercase agwa:
    /// U + 0041 'A' ..=U-005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Na-achọpụtazi ma ọ bụrụ na uru bụ ASCII lowercase agwa:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Na-elele ma ọ bụrụ na uru bụ ASCII alphanumeric agwa:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ma ọ bụ
    /// - U + 0061 'a' ..=U + 007A 'z', ma ọ bụ
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Nyochaa ma ọ bụrụ na uru bụ ọnụọgụ ọnụọgụ ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Na-elele ma ọ bụrụ na uru bụ ASCII hexadecimal ọbula:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ma ọ bụ
    /// - U + 0041 'A' ..=U + 0046 'F', ma ọ bụ
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na uru bụ ihe ascii akara edemede agwa:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ma ọ bụ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ma ọ bụ
    /// - U + 005B ..=U + 0060 '' [\] ^ _ ``, ma ọ bụ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na uru bụ ihe ascii graphic agwa:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na uru bụ ihe ascii whitespace agwa:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FEM FEED, ma ọ bụ U + 000D CARRIAGE RITURN.
    ///
    /// Rust jiri WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Enwere ọtụtụ nkọwa ndị ọzọ na ojiji zuru oke.
    /// Ihe atụ, [the POSIX locale][pct] agụnye U + 000B vetikal taabụ nakwa dị ka niile n'elu odide, ma-si otu specification-[ndabara na-achị n'ihi "field splitting" na Bourne shell][bfs] weere *naanị* ohere, kwụ taabụ, na EZIOKWU na-eri nri dị ka whitespace.
    ///
    ///
    /// Ọ bụrụ na ị na-ede mmemme nke ga-ahazi usoro faịlụ dị ugbu a, lelee etu nkọwa ahụ si kọwaa ọcha ọcha tupu iji ọrụ a.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Lelee ma ọ bụrụ na uru bụ ASCII akara agwa:
    /// U + 0000 NUL ..=U + 001F unit separator, ma ọ bụ U + 007F ihichapụ.
    /// Cheta na ọtụtụ ascii whitespace odide ndị akara odide, ma ohere ọ bụghị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// - Ebu ụzọ amata a raw u32 uru dị ka UTF-8 n'ime nyere byte echekwa, na mgbe ahụ laghachi na subslice nke echekwa na e dere ihe itinye na koodu agwa.
///
///
/// N'adịghị ka `char::encode_utf8`, usoro a na-ejikwa koodu akara na ntanetị.
/// (Creatmepụta `char` na ebe nchekwa bụ UB.) Nsonaazụ dị mma [generalized UTF-8] mana ọ bụghị UTF-8 ziri ezi.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ma ọ bụrụ na nchekwa ahụ ezughị oke.
/// Ihe nchekwa ogologo anọ dị oke iji zoo `char` ọ bụla.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// - Ebu ụzọ amata a raw u32 uru dị ka UTF-16 n'ime nyere `u16` echekwa, na mgbe ahụ laghachi na subslice nke echekwa na e dere ihe itinye na koodu agwa.
///
///
/// N'adịghị ka `char::encode_utf16`, usoro a na-ejiri codepoints na surrogate nso.
/// (Ịmepụta a `char` na surrogate nso UB.)
///
/// # Panics
///
/// Panics ma ọ bụrụ na nchekwa ahụ ezughị oke.
/// A echekwa nke ogologo 2 bụ nnukwu iji encode ọ bụla `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: ogwe aka ọ bụla na-enyocha ma enwere oke ibe iji dee n'ime
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP dara
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ntughari ugbo elu na-abanye n'ime ihe ndi ozo.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}