//! Omume mgbanwe.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Atọghata a `u32` ka a `char`.
///
/// Rịba ama na ihe niile [``char`] niile dịịrị ['' u32`], ma nwee ike itufu ya
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Otú ọ dị, agbara abụghị eziokwu: niile abụghị nti ['u32`] s na-nti [' char`] s.
/// `from_u32()` ga-alaghachi `None` ma ọ bụrụ na ntinye abaghị uru maka [`char`].
///
/// Maka nsụgharị a na-ejighị n'aka nke ọrụ a nke na-eleghara ndenye ego ndị a anya, lee [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Iweghachi `None` mgbe input bụghị a nti [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Atọghata a `u32` ka a `char`, leghara ndaba.
///
/// Rịba ama na ihe niile [``char`] niile dịịrị ['' u32`], ma nwee ike itufu ya
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Otú ọ dị, agbara abụghị eziokwu: niile abụghị nti ['u32`] s na-nti [' char`] s.
/// `from_u32_unchecked()` ga-eleghara a, na blindly ikpu ka [`char`], ikekwe na-eke ihe ghara ịdị irè otu.
///
///
/// # Safety
///
/// Ọrụ a enweghị nchedo, ebe ọ nwere ike rụọ ụkpụrụ `char` na-abaghị uru.
///
/// Maka ọdịdị dị mma nke ọrụ a, lee ọrụ [`from_u32`].
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ANY SA: onye na-akpọ oku ga-ekwenye na `i` bụ uru ahịa bara uru.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Gbanwee [`char`] ka ọ bụrụ [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Atọghata a [`char`] n'ime a [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The Ịsaka bụ casted uru nke koodu ebe, mgbe ahụ, efu-akp 64 bit.
        // Hụ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Atọghata a [`char`] n'ime a [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The Ịsaka bụ casted uru nke koodu ebe, mgbe ahụ, efu-akp 128 bit.
        // Hụ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Maapụ byte na 0x00 ..=0xFF na `char` nke akara koodu ya nwere otu uru, na U + 0000 ..=U + 00FF.
///
/// Ezubere Unicode nke mere na nke a na-agbanwe usoro ọfụma site na iji koodu agwa nke IANA kpọrọ ISO-8859-1.
/// Nke a na koodu dakọtara na ASCII.
///
/// Rịba ama na nke a dị iche na ISO/IEC 8859-1 aka
/// ISO 8859-1 (nke nwere obere mkpirisi), nke na-ahapụ ụfọdụ "blanks", ụkpụrụ byte nke anaghị ekenye agwa ọ bụla.
/// ISO-8859-1 (na IANA otu) nyere ha ka ha na C0 na C1 akara Koodu.
///
/// Rịba ama na nke a bụkwa * dịkwa iche na Windows-1252 aka
/// peeji peeji 1252, nke bụ nnukwu ISO/IEC 8859-1 nke nyere ụfọdụ (ọ bụghị ihe niile!) oghere na akara edemede na ihe odide Latin dị iche iche.
///
/// Iji na-emegharị ihe n'ihu, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, na `windows-1252` niile aliases maka a superset nke Windows-1252 na ihe jupụtara n'ime ndị fọdụrụ blanks na kwekọrọ ekwekọ C0 na C1 akara Koodu.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Gbanwee [`u8`] ka ọ bụrụ [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Njehie nke nwere ike laghachi mgbe parsing a Ịsaka.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // NCHEKWA: enyocha na ọ bụ a iwu unicode uru
            Ok(unsafe { transmute(i) })
        }
    }
}

/// The njehie ụdị laghachi mgbe a akakabarede si u32 ka Ịsaka ada ada.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Gbanwee otu ọnụọgụ na radix e nyere na `char`.
///
/// A 'radix' ebe a na-akpọkwa 'base' mgbe ụfọdụ.
/// A radix nke abụọ na-egosi ọnụọgụ ọnụọgụ abụọ, radix nke iri, ntụpọ, na radix nke iri na isii, hexadecimal, iji nye ụfọdụ ụkpụrụ bara uru.
///
/// Aka ike radices na-akwado.
///
/// `from_digit()` ga-alaghachi `None` ma ọ bụrụ na ndenye bụghị a ọbula na nyere mgbọrọgwụ.
///
/// # Panics
///
/// Panics ma ọ bụrụ na enyere radix karịrị 36.
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Ntụpọ 11 bụ otu ọnụọgụ na ntọala 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Iweghachi `None` mgbe ntinye abụghị ọnụọgụ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Na-agafe nnukwu radix, na-akpata panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}