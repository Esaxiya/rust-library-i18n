use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ma na-abụghị efu ma covariant.
///
/// Nke a na-abụkarị ihe ziri ezi iji mee ihe mgbe ị na-arụ usoro data site na iji ntụnye ntụpọ, mana ọ na-adịkarị ize ndụ iji n'ihi ihe mgbakwunye ya.Y`oburu n`ichoghi ma I kwesiri iji `NonNull<T>`, jiri `*mut T`!
///
/// N'adịghị ka `*mut T`, ihe nrụpụta ga-abụrịrị ihe na-abaghị uru, ọbụlagodi ma ọ bụrụ na ajụghị pointer.Nke a bụ ka enums wee nwee ike iji uru a amachibidoro dị ka onye na-akpa oke-`Option<NonNull<T>>` nwere nha otu `* mut T`.
/// Agbanyeghị, pointer ahụ ka nwere ike ịgbatị ma ọ bụrụ na edeghị ya.
///
/// N'adịghị ka `*mut T`, a họọrọ `NonNull<T>` ka ọ bụrụ ihe gafere `T`.Nke a na-eme ka o kwe omume iji `NonNull<T>` mgbe ị na-ewu ụdị ndị na-agbanwe agbanwe, mana na-ewebata ihe ize ndụ nke enweghị nsogbu ma ọ bụrụ na ejiri ya n'ụdị nke na-ekwesịghị ịbụ nke covariant.
/// (E mere nhọrọ na-abụghị maka `*mut T` ọ bụ ezie na ọ ga-abụ naanị site na teknụzụ, ọ ga-abụ naanị ịkpọ oku ọrụ adịghị mma.)
///
/// Covariance ziri ezi maka ọtụtụ ihe nchebe, dịka `Box`, `Rc`, `Arc`, `Vec` na `LinkedList`.Nke a bụ ikpe n'ihi na ha na-enye a ọha API na-eso ndị nkịtị na-akọrọ XOR mutable iwu nke Rust.
///
/// Ọ bụrụ na gị na ụdị ike n'enweghị enwe covariant, ị ga-hụ na ọ nwere ụfọdụ ndị ọzọ n'ubi iji nye invariance.Ọtụtụ mgbe ubi a ga-abụ ụdị [`PhantomData`] dị ka `PhantomData<Cell<T>>` ma ọ bụ `PhantomData<&'a mut T>`.
///
/// Cheta na `NonNull<T>` nwere a `From` atụ maka `&T`.Agbanyeghị, nke a anaghị agbanwe eziokwu ahụ na ntụgharị site na (pointer sitere na a) ntụnye aka akọrọ bụ omume na-akọwaghị belụsọ na mmụba ahụ mere n'ime [`UnsafeCell<T>`].Otu na-aga na-eke a mutable akwụkwọ si a na-akọrọ akwụkwọ.
///
/// Mgbe ị na-eji ihe atụ `From` a na-enweghị `UnsafeCell<T>`, ọ bụ ọrụ gị iji hụ na anaghị akpọ `as_mut`, na anaghị eji `as_ptr` maka mmụba.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ntụaka abụghị `Send` n'ihi na data ha na-ezo aka nwere ike ịnye aha.
// NB, ihe ngosi a abughi ihe ekwesighi, kama o kwesiri inye ozi ezighi ezi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ntụaka abụghị `Sync` n'ihi na data ha na-ezo aka nwere ike ịnye aha.
// NB, ihe ngosi a abughi ihe ekwesighi, kama o kwesiri inye ozi ezighi ezi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Mepụta `NonNull` ọhụrụ na-agbanye agba, mana ahaziri nke ọma.
    ///
    /// Nke a bara uru maka ịmalite ụdị nke na-etinye umengwụ, dịka `Vec::new` na-eme.
    ///
    /// Rịba ama na uru pointer nwere ike ịnọchite anya pointer ziri ezi na `T`, nke pụtara na nke a agaghị eji dị ka uru "not yet initialized" sentinel.
    /// Tydị nke dị lazily na-ekenye ga-agbaso ụzọ mmalite site n'ụzọ ndị ọzọ.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // NCHEKWA: mem::align_of() laghachi a abụghị-zero usize bụ nke a na casted
        // a * mut T.
        // Yabụ, `ptr` abụghị ihe efu na ọnọdụ ịkpọ oku new_unchecked() bụ ihe a na-akwanyere ùgwù.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Weghachite otu ederede zoro aka na uru ahụ.N'ụzọ dị iche na [`as_ref`], a na-adịghị achọ na uru nwere na-initialized.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Weghachite ederede pụrụ iche na uru ahụ.N'adịghị ka [`as_mut`], nke a achọghị ka amalite ụkpụrụ ahụ.
    ///
    /// N'ihi na Amalite Ijekọ counterpart ahụ [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Mepụta `NonNull` ọhụrụ.
    ///
    /// # Safety
    ///
    /// `ptr` ga-ndị na-abụghị null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ANY: onye na-akpọ oku ga-ekwenye na `ptr` abụghị ihe efu.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Mepụta `NonNull` ọhụrụ ma ọ bụrụ na `ptr` abụghị ihe efu.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: A na-enyocha pointer ahụ ma ọ nweghị isi
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Na-arụ otu ọrụ ahụ dị ka [`std::ptr::from_raw_parts`], belụsọ na e weghachite pointer `NonNull`, ma ọ bụghị pointer `*const` raw raw.
    ///
    ///
    /// Hụ akwụkwọ nke [`std::ptr::from_raw_parts`] maka nkọwa ndị ọzọ.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // NCHEKWA: The N'ihi nke `ptr::from::raw_parts_mut` bụ ndị na-abụghị null n'ihi `data_address` bụ.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompose pointer (ikekwe n'obosara) n'ime adreesị na metadata.
    ///
    /// Enwere ike ịmegharị pointer na [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nweta pointer `*mut` na-akpata.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Alaghachi a na-akọrọ banyere uru.Ọ bụrụ na uru ahụ enweghị ike ịmalite, a ga-eji [`as_uninit_ref`] mee ihe kama.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Ntuziaka ga-atụ aka n'ihe atụ nke `T`.
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    /// (The akụkụ banyere ịbụ initialized bụ ma n'ụzọ zuru ezu kpebiri, ma ruo mgbe ọ bụ, nanị mma obibia bụ iji hụ na ha na-n'ezie initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        unsafe { &*self.as_ptr() }
    }

    /// Alaghachi a pụrụ iche akwụkwọ maka uru.Ọ bụrụ na uru nwere ike uninitialized, [`as_uninit_mut`] ga-eji kama.
    ///
    /// Maka onye ịkọkọrịta ọnụ hụrụ [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Ntuziaka ga-atụ aka n'ihe atụ nke `T`.
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    /// (The akụkụ banyere ịbụ initialized bụ ma n'ụzọ zuru ezu kpebiri, ma ruo mgbe ọ bụ, nanị mma obibia bụ iji hụ na ha na-n'ezie initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka a mutable akwụkwọ.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nkedo onye na-egosi ụdị ọzọ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` bu pointer `NonNull` nke n`abughi ihe efu
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Mepụta mpempe akwụkwọ na-enweghị isi si na mkpa pointer na ogologo.
    ///
    /// Mkparịta ụka `len` bụ ọnụọgụ nke **ihe**, ọ bụghị ọnụọgụ nke bytes.
    ///
    /// Ọrụ a dị mma, mana ịkọgharị uru nloghachi bụ enweghị nchedo.
    /// Hụ akwụkwọ nke [`slice::from_raw_parts`] maka iberibe nchekwa nchekwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ike a iberi pointer mgbe malite na a pointer na mbụ mmewere
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Rịba ama na ihe atụ a na-egosipụta iji usoro a, mana `` hapụ ibe= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // NCHEKWA: `data` bụ a `NonNull` pointer nke bụ bụchaghị na-abụghị null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Alaghachi ogologo nke a na-abụghị null raw iberi.
    ///
    /// Ihe eweghachitere bụ ọnụọgụ nke **ihe**, ọ bụghị ọnụọgụ nke bytes.
    ///
    /// Arụ ọrụ a dị mma, ọbụlagodi mgbe enweghị ike ịnye ya iberi ihe na-enweghị isi n'ihi na onye nwe ya enweghị adreesị ziri ezi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Alaghachi a ndị na-abụghị null pointer ka iberi si echekwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Anyị maara na `self` abụghị ihe efu.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Weghachite pointer raw na mpempe akwụkwọ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Alaghachiri a na-akọrọ banyere iberi nke ikekwe uninitialized ụkpụrụ.N'ụzọ dị iche na [`as_ref`], a na-adịghị achọ na uru nwere na-initialized.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Ihe akara aka ga-abụ [valid] maka agụ maka `ptr.len() * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
    ///
    ///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
    ///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.
    ///
    ///     * A ga-aharịrị onye na-atụtụ ihe ọbụlagodi mpekere efu.
    ///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
    ///
    ///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
    ///
    /// * Mkpokọta `ptr.len() * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
    ///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// Leekwa [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Alaghachi a pụrụ iche akwụkwọ maka iberi nke ikekwe uninitialized ụkpụrụ.N'adịghị ka [`as_mut`], nke a achọghị ka amalite ụkpụrụ ahụ.
    ///
    /// Maka onye ịkọkọrịta ọnụ hụrụ [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na ihe ndị a niile bụ eziokwu:
    ///
    /// * Nchịkọta ga-abụ [valid] maka ịgụ ma na-ede maka `ptr.len() * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
    ///
    ///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
    ///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.
    ///
    ///     * A ga-aharịrị onye na-atụtụ ihe ọbụlagodi mpekere efu.
    ///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
    ///
    ///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
    ///
    /// * Mkpokọta `ptr.len() * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
    ///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// Leekwa [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Nke a bụ mma dị ka `memory` bụ irè n'ihi na-agụ ma na-ede maka `memory.len()` ọtụtụ bytes.
    /// // Rịba ama na a naghị ekwe ka ịkpọ `memory.as_mut()` ebe a ka ọdịnaya nwere ike ịbụ enweghị nchekwube.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// O weghachite pointer raw na ihe mmeju ma obu mechie, na-emeghi nyocha.
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke ma ọ bụ mgbe `self` anaghị edepụta ya bụ *[omume a na-akọwaghị]* ọ bụrụgodi na ejighị pointer na-akpata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // Nchedo: onye na-akpọ oku na-achọpụta na `self` nwere ike ịgbagha na `index` na-ókè.
        // N'ihi ya, na n'ihi pointer nwere ike ịbụ adịghị ịre.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // Nchekwa: A Pụrụ iche pointer-apụghị ịbụ ihe efu, otú ahụ ka ọnọdụ maka
        // new_unchecked() na-akwanyere ugwu.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Ntughari ederede na-aghaghi ibu ihe efu.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Ntuziaka enweghị ike ịbụ ihe efu, yabụ ọnọdụ maka
        // new_unchecked() na-akwanyere ugwu.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}