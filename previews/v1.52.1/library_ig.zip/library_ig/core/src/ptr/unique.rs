use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ihe nkpuchi gburugburu `*mut T` na-enweghị isi nke na-egosi na onye nwere ihe mkpuchi a nwere onye na-ede akwụkwọ.
/// Bara uru maka iwulite abstractions dị ka `Box<T>`, `Vec<T>`, `String`, na `HashMap<K, V>`.
///
/// N'adịghị ka `*mut T`, `Unique<T>` akpa àgwà "as if" na ọ bụ otu ihe atụ nke `T`.
/// Ọ implements `Send`/`Sync` ma ọ bụrụ na `T` bụ `Send`/`Sync`.
/// Ọ na-egosi ụdị ike aliasing di ihe atụ nke `T` pụrụ ịtụ anya:
/// na referent nke pointer ekwesịghị gbanwetụrụ enweghị a pụrụ iche ụzọ ya inwe Unique.
///
/// Y`oburu n`inweghi n`aka ma o ziri ezi iji `Unique` maka ebum n`uche gi, tulee iji `NonNull`, nke n`adighi ike.
///
///
/// N'adịghị ka `*mut T`, ihe na-enwerịrị ihe ị na-ekwu agaghị abụ ihe efu, ọbụlagodi ma ọ bụrụ na ajụghị pointer.
/// Nke a bụ ka enums wee nwee ike iji uru a amachibidoro dị ka onye na-akpa oke-`Option<Unique<T>>` nwere nha otu `Unique<T>`.
/// Agbanyeghị, pointer ahụ ka nwere ike ịgbatị ma ọ bụrụ na edeghị ya.
///
/// N'adịghị ka `*mut T`, `Unique<T>` dị na `T`.
/// Nke a mgbe niile kwesịrị ịbụ ziri ezi maka ihe ọ bụla ụdị nke kwekọrọ Unique si aliasing chọrọ.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ihe nrịba ama a enweghị ihe ọ ga-esi na ọdịiche pụta, mana ọ dị mkpa
    // maka dropck ịghọta na anyị na-ezi uche nwere a `T`.
    //
    // Maka nkọwa, lee:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointers bụ `Send` ma ọ bụrụ na `T` bụ `Send` n'ihi na data ha ọmụmaatụ bụ unaliased.
/// Cheta na nke a aliasing invariant na-unenforced site ụdị usoro;na abstraction iji `Unique` ga manye ya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointers bụ `Sync` ma ọ bụrụ na `T` bụ `Sync` n'ihi na data ha ọmụmaatụ bụ unaliased.
/// Cheta na nke a aliasing invariant na-unenforced site ụdị usoro;na abstraction iji `Unique` ga manye ya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Mepụta `Unique` ọhụrụ na-agbanye agba, mana ahaziri nke ọma.
    ///
    /// Nke a bara uru maka ịmalite ụdị nke na-etinye umengwụ, dịka `Vec::new` na-eme.
    ///
    /// Rịba ama na uru pointer nwere ike ịnọchite anya pointer ziri ezi na `T`, nke pụtara na nke a agaghị eji dị ka uru "not yet initialized" sentinel.
    /// Tydị nke dị lazily na-ekenye ga-agbaso ụzọ mmalite site n'ụzọ ndị ọzọ.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() weghachite pointer ziri ezi na-enweghị isi.Na
        // a na-akwanyere ọnọdụ ịkpọ new_unchecked() ùgwù.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Mepụta `Unique` ọhụrụ.
    ///
    /// # Safety
    ///
    /// `ptr` ga-ndị na-abụghị null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ANY: onye na-akpọ oku ga-ekwenye na `ptr` abụghị ihe efu.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Mepụta `Unique` ọhụrụ ma ọ bụrụ na `ptr` abụghị ihe efu.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: A chọpụtalarị pointer ahụ ma ọ nweghị isi.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nweta pointer `*mut` na-akpata.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences ọdịnaya.
    ///
    /// Ihe ga-eme ka ndụ gị dịrị na nke onwe ya mere nke a na-eme "as if" ọ bụ n'ezie atụ nke T nke a na-agbaziri.
    /// Ọ bụrụ na achọrọ ogologo ndụ (unbound), jiri `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        unsafe { &*self.as_ptr() }
    }

    /// Jiri otutu wepu ọdịnaya a.
    ///
    /// Ihe ga-eme ka ndụ gị dịrị na nke onwe ya mere nke a na-eme "as if" ọ bụ n'ezie atụ nke T nke a na-agbaziri.
    /// Ọ bụrụ na achọrọ ogologo ndụ (unbound), jiri `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka a mutable akwụkwọ.
        unsafe { &mut *self.as_ptr() }
    }

    /// Nkedo onye na-egosi ụdị ọzọ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() na-emepụta ihe ọhụụ pụrụ iche na mkpa
        // onye enyere gi ka o ghara idi efu.
        // Ebe ọ bụ na anyị na-agafe onwe anyị dị ka pointer, ọ gaghị abụ ihe efu.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Ntughari ederede na-aghaghi ibu ihe efu
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}